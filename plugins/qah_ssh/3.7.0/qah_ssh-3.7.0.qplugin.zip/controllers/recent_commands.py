"""
Author: Acxel Orozco
Date: 2026-02-07
Description: Command history manager for SSH terminal with JSON storage

This module provides command history functionality with:
- Save last commands to JSON file
- Navigate history with up/down arrow keys
- Persistent storage across sessions
- Configurable maximum history size
"""

import json
import logging
from pathlib import Path
from datetime import datetime
from typing import List, Optional
from PySide6.QtCore import Qt, QObject


class CommandHistory:
    """Manages command history for SSH terminal"""
    
    def __init__(self, temp_dir: Path, max_history: int = 1000):
        """
        Initialize command history manager
        
        Args:
            temp_dir: Directory to store history file
            max_history: Maximum number of commands to keep in history
        """
        self.temp_dir = temp_dir
        self.max_history = max_history
        self.history_file = temp_dir / "command_history.json"
        self.commands: List[str] = []
        self.current_index: int = -1
        self.current_input: str = ""
        
        # Load existing history
        self.load_history()
    
    def load_history(self):
        """Load command history from JSON file"""
        try:
            if self.history_file.exists():
                with open(self.history_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.commands = data.get('commands', [])
                    
                    # Ensure we don't exceed max history
                    if len(self.commands) > self.max_history:
                        self.commands = self.commands[-self.max_history:]
                    
                    logging.info(f"Loaded {len(self.commands)} commands from history")
        except Exception as e:
            logging.error(f"Failed to load command history: {e}")
            self.commands = []
    
    def save_history(self):
        """Save command history to JSON file"""
        try:
            # Ensure temp directory exists
            self.temp_dir.mkdir(parents=True, exist_ok=True)
            
            with open(self.history_file, 'w', encoding='utf-8') as f:
                json.dump({
                    'commands': self.commands,
                    'last_updated': datetime.now().isoformat(),
                    'max_history': self.max_history
                }, f, indent=2, ensure_ascii=False)
            
            logging.info(f"Saved {len(self.commands)} commands to history")
        except Exception as e:
            logging.error(f"Failed to save command history: {e}")
    
    def add_command(self, command: str):
        """
        Add a command to history
        
        Args:
            command: Command string to add
        """
        if not command or not command.strip():
            return
        
        # Don't add if it's the same as the last command
        if self.commands and self.commands[-1] == command:
            return
        
        # Remove duplicate if it exists elsewhere
        if command in self.commands:
            self.commands.remove(command)
        
        # Add to end of list
        self.commands.append(command)
        
        # Trim to max history size
        if len(self.commands) > self.max_history:
            self.commands = self.commands[-self.max_history:]
        
        # Save to disk
        self.save_history()
        
        # Reset navigation index
        self.reset_navigation()
    
    def get_previous_command(self, current_input: str = "") -> Optional[str]:
        """
        Get previous command in history (up arrow)
        
        Args:
            current_input: Current text in input field
            
        Returns:
            Previous command or None if at start
        """
        if not self.commands:
            return None
        
        # If we're starting navigation, save current input
        if self.current_index == -1:
            self.current_input = current_input
            self.current_index = len(self.commands) - 1
        elif self.current_index > 0:
            self.current_index -= 1
        else:
            # Already at first command
            return self.commands[0] if self.commands else None
        
        return self.commands[self.current_index] if 0 <= self.current_index < len(self.commands) else None
    
    def get_next_command(self) -> Optional[str]:
        """
        Get next command in history (down arrow)
        
        Returns:
            Next command, empty string if at end, or None if no history
        """
        if not self.commands or self.current_index == -1:
            return None
        
        if self.current_index < len(self.commands) - 1:
            self.current_index += 1
            return self.commands[self.current_index]
        else:
            # At end of history, restore original input
            original_input = self.current_input
            self.reset_navigation()
            return original_input if original_input else None
    
    def reset_navigation(self):
        """Reset navigation index to start"""
        self.current_index = -1
        self.current_input = ""
    
    def get_all_commands(self) -> List[str]:
        """Get all commands in history"""
        return self.commands.copy()
    
    def clear_history(self):
        """Clear all command history"""
        self.commands = []
        self.reset_navigation()
        self.save_history()
        logging.info("Command history cleared")
    
    def search_commands(self, search_term: str) -> List[str]:
        """
        Search commands containing search term
        
        Args:
            search_term: Term to search for
            
        Returns:
            List of matching commands
        """
        if not search_term:
            return self.commands.copy()
        
        return [cmd for cmd in self.commands if search_term.lower() in cmd.lower()]
    
    def get_stats(self) -> dict:
        """Get statistics about command history"""
        return {
            'total_commands': len(self.commands),
            'max_history': self.max_history,
            'file_path': str(self.history_file),
            'file_exists': self.history_file.exists()
        }
    
class CommandInputEventFilter(QObject):
    """Event filter for command input to handle up/down arrow keys"""
    
    def __init__(self, command_input, command_history):
        super().__init__()
        self.command_input = command_input
        self.command_history = command_history
    
    def eventFilter(self, obj, event):
        if event.type() == event.type().KeyPress:
            if event.key() == Qt.Key_Up:
                # Get previous command
                current_text = self.command_input.text()
                prev_command = self.command_history.get_previous_command(current_text)
                if prev_command is not None:
                    self.command_input.setText(prev_command)
                return True
            elif event.key() == Qt.Key_Down:
                # Get next command
                next_command = self.command_history.get_next_command()
                if next_command is not None:
                    self.command_input.setText(next_command)
                return True
        return False