"""SSH command terminal: input, output, command history button."""

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QTextEdit, QToolButton,
    QApplication, QStyle,
)
from PySide6.QtCore import Signal

from ..controllers.recent_commands import CommandInputEventFilter
from .workers import SSHWorker


class TerminalPanel(QWidget):
    status_message = Signal(str)             # to parent (optional)
    cd_requested = Signal(str)               # terminal wants to `cd`

    def __init__(self, command_history, parent=None):
        super().__init__(parent)
        self.command_history = command_history
        self.ssh_client = None
        self.current_path = "/home"
        self._workers = []
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)

        toolbar = QHBoxLayout()
        toolbar.addWidget(QLabel("Remote Terminal"))
        toolbar.addStretch()
        self.history_btn = QToolButton()
        self.history_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_FileDialogDetailedView)
        )
        self.history_btn.setToolTip("Command History")
        self.history_btn.setEnabled(False)
        toolbar.addWidget(self.history_btn)
        layout.addLayout(toolbar)

        self.command_input = QLineEdit()
        self.command_input.setPlaceholderText(
            "Example: ls -la, qsub job.sh, squeue, cd /scratch (Use ↑/↓ for history)"
        )
        self.command_input.returnPressed.connect(self.execute)
        layout.addWidget(self.command_input)

        self.command_event_filter = CommandInputEventFilter(
            self.command_input, self.command_history
        )
        self.command_input.installEventFilter(self.command_event_filter)

        self.execute_btn = QPushButton("Execute Command")
        self.execute_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_MediaPlay)
        )
        self.execute_btn.clicked.connect(self.execute)
        self.execute_btn.setEnabled(False)
        layout.addWidget(self.execute_btn)

        self.output = QTextEdit()
        self.output.setReadOnly(True)
        self.output.setFontFamily("Courier New")
        self.output.setStyleSheet("font-size: 10pt;")
        layout.addWidget(self.output)

    # -------- connection API --------
    def set_connected(self, ssh_client, current_path=None):
        self.ssh_client = ssh_client
        if current_path is not None:
            self.current_path = current_path
        self.execute_btn.setEnabled(ssh_client is not None)
        self.history_btn.setEnabled(ssh_client is not None)

    def set_current_path(self, path: str):
        self.current_path = path

    def append(self, text: str):
        self.output.append(text)

    # -------- terminal execution --------
    def execute(self):
        if not self.ssh_client:
            self.append("[Warning] Connect to the cluster first.\n")
            return
        command = self.command_input.text().strip()
        if not command:
            return

        self.command_input.clear()
        self.command_history.reset_navigation()

        if command.startswith("cd "):
            target = command[3:].strip() or "~"
            self.command_history.add_command(command)
            self.cd_requested.emit(target)
            return

        self.command_history.add_command(command)
        full = f"cd {self.current_path} && {command}"
        self.output.append(f"\n$ {command}")
        self.output.append(f"   (in: {self.current_path})")

        self.execute_btn.setEnabled(False)
        w = SSHWorker(self.ssh_client, full)
        self._workers.append(w)
        w.output.connect(self._append_if_nonempty)
        w.error.connect(lambda t: self.output.append(f"[Error] {t}"))
        w.finished.connect(lambda: self.execute_btn.setEnabled(True))
        w.finished.connect(lambda: self._cleanup_worker(w))
        w.start()

    def _append_if_nonempty(self, text):
        if text.strip():
            self.output.append(text)

    def _cleanup_worker(self, w):
        if w in self._workers:
            self._workers.remove(w)

    def cancel_pending(self):
        for w in list(self._workers):
            try:
                w.quit()
                w.wait(2000)
            except Exception:
                pass
        self._workers.clear()