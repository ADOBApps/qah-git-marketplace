"""Background transfer worker for the QAH SSH transfer queue.

Each job runs in its own QThread and opens its own SFTP channel from the
existing SSH client. The browser keeps its own SFTP client for navigation, so
listing and other browser actions stay responsive while a queued transfer
runs.
"""

from __future__ import annotations

import os
import shlex
import stat
import tarfile
import tempfile
import threading
import time
from pathlib import Path, PurePosixPath

from PySide6.QtCore import QThread, Signal


CHUNK_SIZE = 1024 * 1024
LARGE_FILE_THRESHOLD = 100 * 1024 * 1024
PROGRESS_INTERVAL = 0.10


class TransferCancelled(RuntimeError):
    """Raised inside the worker when the user cancels the current job."""


class TransferWorker(QThread):
    """Run one queued upload/download without blocking the Qt GUI thread."""

    progress = Signal(int, int)   # current bytes, total bytes
    label = Signal(str)
    done = Signal(bool, str)      # success, detail

    def __init__(self, ssh_client, kind: str, payload: dict, parent=None):
        super().__init__(parent)
        self.ssh_client = ssh_client
        self.kind = kind
        self.payload = dict(payload or {})
        self._cancel = threading.Event()

    def cancel(self) -> None:
        self._cancel.set()

    def _check_cancel(self) -> None:
        if self._cancel.is_set():
            raise TransferCancelled("Canceled")

    def _set_label(self, text: str) -> None:
        self.label.emit(str(text))

    def _report(self, current: int, total: int) -> None:
        self.progress.emit(max(0, int(current)), max(0, int(total)))

    # -- thread entry ---------------------------------------------------
    def run(self) -> None:
        sftp = None
        try:
            if self.ssh_client is None:
                raise RuntimeError("The SSH connection is not available.")
            sftp = self.ssh_client.open_sftp()
            if self.kind == "upload_files":
                self._upload_files(sftp)
            elif self.kind == "upload_folder":
                self._upload_folder(sftp)
            elif self.kind == "download":
                self._download(sftp)
            else:
                raise ValueError(f"Unknown transfer kind: {self.kind}")
            self.done.emit(True, "Complete")
        except TransferCancelled:
            self.done.emit(False, "Canceled")
        except Exception as exc:
            self.done.emit(False, str(exc))
        finally:
            if sftp is not None:
                try:
                    sftp.close()
                except Exception:
                    pass

    # -- upload ---------------------------------------------------------
    def _upload_files(self, sftp) -> None:
        files = [Path(path) for path in self.payload.get("files", [])]
        remote_dir = str(self.payload.get("remote_dir") or ".")
        sizes = []
        total = 0
        for path in files:
            try:
                size = path.stat().st_size
            except OSError:
                size = 0
            sizes.append(size)
            total += size
        self._report(0, max(total, 1))
        done = 0
        for index, (path, size) in enumerate(zip(files, sizes), 1):
            self._check_cancel()
            remote = (PurePosixPath(remote_dir) / path.name).as_posix()
            self._set_label(
                f"Uploading file {index} of {len(files)}: {path.name}"
            )
            self._put(sftp, path, remote, done, max(total, 1))
            done += size
            self._report(done, max(total, 1))

    def _upload_folder(self, sftp) -> None:
        local_dir = Path(self.payload.get("local_dir") or ".")
        remote_dir = str(self.payload.get("remote_dir") or ".")
        files = []
        total = 0
        for root, _dirs, names in os.walk(local_dir):
            for name in names:
                path = Path(root) / name
                try:
                    size = path.stat().st_size
                except OSError:
                    size = 0
                files.append((path, size))
                total += size
        self._report(0, max(total, 1))
        base_remote = PurePosixPath(remote_dir) / local_dir.name
        self._ensure_remote_dir(sftp, base_remote.as_posix())
        done = 0
        for index, (path, size) in enumerate(files, 1):
            self._check_cancel()
            try:
                rel = path.relative_to(local_dir)
            except ValueError:
                continue
            remote = (base_remote / PurePosixPath(rel.as_posix())).as_posix()
            self._ensure_remote_dir(sftp, str(PurePosixPath(remote).parent))
            self._set_label(
                f"Uploading file {index} of {len(files)}: {rel.name}"
            )
            self._put(sftp, path, remote, done, max(total, 1))
            done += size
            self._report(done, max(total, 1))

    def _put(self, sftp, local: Path, remote: str, done: int, total: int) -> None:
        size = 0
        try:
            size = local.stat().st_size
        except OSError:
            pass

        def callback(transferred, _total):
            if self._cancel.is_set():
                return False
            self._report(done + int(transferred), total)
            return True

        try:
            sftp.put(local.as_posix(), remote, callback=callback)
        except Exception:
            if self._cancel.is_set():
                try:
                    sftp.remove(remote)
                except Exception:
                    pass
                raise TransferCancelled("Canceled")
            raise
        self._report(done + size, total)

    # -- download -------------------------------------------------------
    def _download(self, sftp) -> None:
        entries = list(self.payload.get("entries", []))
        dest = Path(self.payload.get("dest") or ".")
        if self.payload.get("compress"):
            self._download_compressed(sftp, entries, dest)
            return

        plan = []
        for entry in entries:
            self._check_cancel()
            remote = str(entry.get("path") or "")
            name = str(entry.get("name") or PurePosixPath(remote).name)
            if entry.get("is_dir"):
                self._enumerate_remote_dir(
                    sftp, remote, dest / name, plan
                )
            else:
                try:
                    size = sftp.stat(remote).st_size
                except Exception:
                    size = 0
                plan.append((remote, dest / name, size, False))

        total = sum(item[2] for item in plan if not item[3])
        self._report(0, max(total, 1))
        done = 0
        errors = []
        for remote, local, size, is_dir in plan:
            self._check_cancel()
            if is_dir:
                local.mkdir(parents=True, exist_ok=True)
                continue
            self._set_label(
                f"Downloading {PurePosixPath(remote).name} "
                f"({self._format_size(size)})..."
            )
            try:
                local.parent.mkdir(parents=True, exist_ok=True)
                self._get_file(sftp, remote, local, size, done, max(total, 1))
            except TransferCancelled:
                self._write_placeholder(local)
                raise
            except Exception as exc:
                errors.append(f"{PurePosixPath(remote).name}: {exc}")
                self._write_placeholder(local)
            done += size
            self._report(done, max(total, 1))
        if errors:
            raise RuntimeError(
                f"{len(errors)} download(s) failed; first: {errors[0]}"
            )

    def _get_file(
        self, sftp, remote: str, local: Path, size: int, done: int, total: int
    ) -> None:
        if size > LARGE_FILE_THRESHOLD:
            self._get_large(sftp, remote, local, size, done, total)
            return

        def callback(transferred, _total):
            if self._cancel.is_set():
                return False
            self._report(done + int(transferred), total)
            return True

        try:
            sftp.get(remote, local.as_posix(), callback=callback)
        except Exception:
            if self._cancel.is_set():
                raise TransferCancelled("Canceled")
            raise
        self._check_cancel()
        self._report(done + size, total)

    def _get_large(
        self, sftp, remote: str, local: Path, size: int, done: int, total: int
    ) -> None:
        transferred = 0
        last_update = 0.0
        with sftp.open(remote, "rb") as source, open(local, "wb") as target:
            try:
                source.seek(0)
            except Exception:
                pass
            while True:
                self._check_cancel()
                data = source.read(CHUNK_SIZE)
                if not data:
                    break
                target.write(data)
                transferred += len(data)
                now = time.time()
                if now - last_update >= PROGRESS_INTERVAL:
                    self._report(done + transferred, total)
                    last_update = now
        self._check_cancel()
        self._report(done + transferred, total)

    def _download_compressed(self, sftp, entries, dest: Path) -> None:
        if not entries:
            return
        names = []
        for entry in entries:
            name = str(entry.get("name") or "")
            if not name or "\n" in name or "\r" in name:
                raise RuntimeError(f"Unsupported remote name: {name!r}")
            names.append(name)
        base_dir = str(entries[0].get("cwd") or ".")
        quoted = " ".join(shlex.quote(name) for name in names)
        cwd = shlex.quote(base_dir)
        command = (
            'tmp=$(mktemp "${TMPDIR:-/tmp}/qah_ssh_dl_XXXXXX.tar.gz") || exit 1; '
            f'tar -czf "$tmp" -C {cwd} -- {quoted} '
            '|| { rm -f "$tmp"; exit 2; }; '
            'printf "\\n__QAH_ARCHIVE__%s\\n" "$tmp"'
        )
        self._set_label("Compressing selected files on the cluster...")
        _stdin, stdout, stderr = self.ssh_client.exec_command(command)
        output = stdout.read().decode("utf-8", errors="replace")
        error = stderr.read().decode("utf-8", errors="replace")
        self._check_cancel()
        marker = "__QAH_ARCHIVE__"
        if marker not in output:
            detail = error.strip() or output.strip() or "unknown error"
            raise RuntimeError(
                f"Compressed download failed on the cluster: {detail}"
            )
        remote_archive = output.rsplit(marker, 1)[1].strip().splitlines()[0].strip()
        if not remote_archive:
            raise RuntimeError("Compressed download returned no archive path.")

        local_root = Path(tempfile.mkdtemp(prefix="qah_ssh_download_"))
        local_archive = local_root / "download.tar.gz"
        try:
            size = sftp.stat(remote_archive).st_size
            self._set_label("Downloading compressed archive...")
            self._report(0, max(size, 1))
            self._get_file(sftp, remote_archive, local_archive, size, 0, max(size, 1))
            self._check_cancel()
            count = self._extract_tar_safe(local_archive, dest)
            self._set_label(f"Extracted {count} item(s)")
        finally:
            try:
                sftp.remove(remote_archive)
            except Exception:
                pass
            try:
                import shutil
                shutil.rmtree(local_root, ignore_errors=True)
            except Exception:
                pass

    # -- remote helpers -------------------------------------------------
    def _enumerate_remote_dir(self, sftp, remote_dir, local_dir: Path, plan) -> None:
        plan.append((remote_dir, local_dir, 0, True))
        try:
            entries = sftp.listdir_attr(remote_dir)
        except Exception as exc:
            self._set_label(f"Could not list {remote_dir}: {exc}")
            return
        for entry in entries:
            remote = str(PurePosixPath(remote_dir) / entry.filename)
            local = local_dir / entry.filename
            if stat.S_ISDIR(entry.st_mode):
                self._enumerate_remote_dir(sftp, remote, local, plan)
            else:
                plan.append((remote, local, entry.st_size, False))

    def _ensure_remote_dir(self, sftp, remote_dir: str) -> None:
        if remote_dir in ("/", "", "."):
            return
        try:
            sftp.stat(remote_dir)
            return
        except IOError:
            pass
        parent = PurePosixPath(remote_dir).parent.as_posix()
        self._ensure_remote_dir(sftp, parent)
        try:
            sftp.mkdir(remote_dir)
        except Exception:
            pass

    @staticmethod
    def _write_placeholder(path: Path) -> None:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, "wb"):
                pass
        except Exception:
            pass

    @staticmethod
    def _format_size(size: int) -> str:
        value = float(size or 0)
        for unit in ("B", "KB", "MB", "GB", "TB"):
            if value < 1024 or unit == "TB":
                return f"{value:.1f} {unit}" if unit != "B" else f"{int(value)} B"
            value /= 1024
        return f"{int(size)} B"

    def _extract_tar_safe(self, archive_path: Path, dest_root: Path) -> int:
        dest = dest_root.resolve()
        dest.mkdir(parents=True, exist_ok=True)
        count = 0
        with tarfile.open(archive_path, "r:gz") as archive:
            for member in archive.getmembers():
                self._check_cancel()
                name = member.name.replace("\\", "/")
                path = PurePosixPath(name)
                if not name or name in (".", "./"):
                    continue
                if path.is_absolute() or ".." in path.parts:
                    raise ValueError(f"Unsafe path in archive: {name!r}")
                if member.issym() or member.islnk():
                    self._set_label(f"Skipped link in archive: {name}")
                    continue
                target = (dest.joinpath(*path.parts)).resolve()
                if dest not in target.parents and target != dest:
                    raise ValueError(f"Unsafe path in archive: {name!r}")
                if member.isdir():
                    target.mkdir(parents=True, exist_ok=True)
                elif member.isfile():
                    source = archive.extractfile(member)
                    if source is None:
                        continue
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with source, open(target, "wb") as output:
                        import shutil
                        shutil.copyfileobj(source, output)
                    count += 1
        return count
