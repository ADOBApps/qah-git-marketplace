"""
Author: Acxel Orozco
Date: 2026-10-21
Last modification: 2026-10-24
Description: SSH cluster connector — thin coordinator over widgets/dialogs.

This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
QAH is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
Copyright (C) [2026] Acxel David Orozco Baldomero
"""

import sys
from pathlib import PurePosixPath

import paramiko

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QSplitter, QTabWidget,
    QMessageBox, QApplication, QScrollArea,
)
from PySide6.QtCore import Qt, QThread
from PySide6.QtGui import QAction

from .controllers.recent_commands import CommandHistory
from .controllers.recent_users import SSHInfoHistory
from .controllers.temporal_files import TempFileManager
from .widgets.connection_panel import ConnectionPanel
from .widgets.file_browser import FileBrowser
from .widgets.terminal_panel import TerminalPanel
from .widgets.temp_files_panel import TempFilesPanel
from .widgets.text_editor import SimpleTextEditor
from .widgets.workers import SFTPWorker
from .dialogs import (
    show_command_history_dialog,
    show_user_history_dialog,
    show_credential_manager_dialog,
)


class EnhancedClusterConnectorWithEditor(QWidget):
    def __init__(self, plugin_instance=None):
        super().__init__()
        self.plugin = plugin_instance
        self.ssh_client = None
        self.sftp_client = None
        self.current_path = PurePosixPath("/home")

        self.temp_manager = TempFileManager()
        self.command_history = CommandHistory(self.temp_manager.temp_dir)
        self.user_history = SSHInfoHistory(self.temp_manager.temp_dir)

        self._workers = []

        self.init_ui()
        self.setup_shortcuts()
        self.temp_manager.cleanup_old_files()

    # -------- worker tracking (for readfile, upload_edited, etc.) --------
    def _track(self, worker):
        self._workers.append(worker)
        worker.finished.connect(lambda: self._untrack(worker))
        worker.error.connect(lambda _msg: self._untrack(worker))
        return worker

    def _untrack(self, worker):
        if worker in self._workers:
            self._workers.remove(worker)

    # -------- UI --------
    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content.setMinimumSize(900, 620)

        splitter = QSplitter(Qt.Vertical)

        # Header container (scrollable, small)
        self.connection_panel = ConnectionPanel(self.user_history)
        self.connection_panel.connect_requested.connect(self.connect_ssh)
        self.connection_panel.disconnect_requested.connect(self.disconnect_ssh)
        self.connection_panel.user_history_requested.connect(self.show_user_history)
        self.connection_panel.credential_manager_requested.connect(
            self.show_credential_manager
        )

        header_scroll = QScrollArea()
        header_scroll.setWidgetResizable(True)
        header_scroll.setWidget(self.connection_panel)

        # Tabs
        self.main_tabs = QTabWidget()

        # Browser + Terminal
        browser_terminal = QWidget()
        bt_layout = QVBoxLayout(browser_terminal)
        h_split = QSplitter(Qt.Horizontal)

        self.file_browser = FileBrowser()
        self.file_browser.status_message.connect(self._append_log)
        self.file_browser.error_dialog.connect(
            lambda msg: QMessageBox.warning(self, "Error", msg)
        )
        self.file_browser.file_open_in_editor.connect(self.open_remote_in_editor)
        self.file_browser.directory_changed.connect(self._on_directory_changed)

        self.terminal = TerminalPanel(self.command_history)
        self.terminal.cd_requested.connect(self.file_browser.change_dir)
        self.terminal.history_btn.clicked.connect(self.show_command_history)

        h_split.addWidget(self.file_browser)
        h_split.addWidget(self.terminal)
        h_split.setSizes([500, 500])
        bt_layout.addWidget(h_split)

        self.main_tabs.addTab(browser_terminal, "SSH Browser")

        # Transfer queue (second tab; editor actions select the editor widget)
        queue_tab = QWidget()
        queue_layout = QVBoxLayout(queue_tab)
        queue_layout.addWidget(self.file_browser.detach_queue_panel(), 1)
        self.main_tabs.addTab(queue_tab, "Transfer Queue")

        # Text editor
        self.editor = SimpleTextEditor()
        self.editor.set_main_window(self)
        self.editor.upload_requested.connect(self.on_editor_upload_requested)
        self.main_tabs.addTab(self.editor, "Text Editor")

        # Temp files
        self.temp_panel = TempFilesPanel(self.temp_manager)
        self.temp_panel.open_in_editor.connect(self.open_temp_in_editor)
        self.temp_panel.upload_requested.connect(self.upload_temp_to_server)
        self.main_tabs.addTab(self.temp_panel, "Temporary Files")

        splitter.addWidget(header_scroll)
        splitter.addWidget(self.main_tabs)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([280, 720])
        content_layout.addWidget(splitter)
        self.scroll_area.setWidget(content)
        layout.addWidget(self.scroll_area)

    def setup_shortcuts(self):
        self.upload_shortcut = QAction("Upload", self)
        self.upload_shortcut.setShortcut("Ctrl+U")
        self.upload_shortcut.triggered.connect(self.file_browser.upload_file)
        self.addAction(self.upload_shortcut)

        self.download_shortcut = QAction("Download", self)
        self.download_shortcut.setShortcut("Ctrl+D")
        self.download_shortcut.triggered.connect(self.file_browser.download_selected)
        self.addAction(self.download_shortcut)

        self.edit_shortcut = QAction("Edit", self)
        self.edit_shortcut.setShortcut("Ctrl+E")
        self.edit_shortcut.triggered.connect(self.file_browser._edit_selected)
        self.addAction(self.edit_shortcut)

        self.refresh_shortcut = QAction("Refresh", self)
        self.refresh_shortcut.setShortcut("F5")
        self.refresh_shortcut.triggered.connect(self.file_browser.refresh)
        self.addAction(self.refresh_shortcut)

        self.delete_shortcut = QAction("Delete", self)
        self.delete_shortcut.setShortcut("Delete")
        self.delete_shortcut.triggered.connect(self.file_browser.delete_selected)
        self.addAction(self.delete_shortcut)

    # -------- connection --------
    def connect_ssh(self, host: str, port: int, username: str, password: str):
        if not host or not username:
            QMessageBox.warning(self, "Warning", "Host and Username are required.")
            return
        self._append_log(f"Connecting to {host}:{port} as {username}...\n")
        self.connection_panel.set_status(f"Connecting to {host}...")
        self.connection_panel.set_connected(False)

        try:
            self.ssh_client = paramiko.SSHClient()
            self.ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            self.ssh_client.connect(
                host, port=port, username=username, password=password,
                look_for_keys=True, allow_agent=True, timeout=30,
            )
            self.sftp_client = self.ssh_client.open_sftp()
            try:
                self.current_path = PurePosixPath(self.sftp_client.normalize("."))
            except Exception:
                self.current_path = PurePosixPath("/home")

            self.connection_panel.set_status(
                f"Connected to {host}:{port} as {username}"
            )
            self._append_log(
                f"Connected to {host}:{port} as {username}\n"
                f"Current directory: {self.current_path}\n"
            )
            self.connection_panel.set_connected(True)

            self.file_browser.set_connected(
                self.sftp_client, str(self.current_path), ssh_client=self.ssh_client
            )
            self.terminal.set_connected(self.ssh_client, str(self.current_path))
            self.temp_panel.set_connected(self.sftp_client)
            self.temp_panel.refresh()

            self.user_history.add_shh_info(host, port, username, password)

        except paramiko.AuthenticationException as e:
            self.connection_panel.set_status("Authentication failed")
            self._append_log(f"Authentication failed: {e}\n")
            QMessageBox.critical(
                self, "Authentication Error",
                f"Authentication failed: {e}\n\n"
                "Please check your username and password.",
            )
            self._reset_connection_state()
        except paramiko.SSHException as e:
            self.connection_panel.set_status("Connection failed")
            self._append_log(f"SSH connection failed: {e}\n")
            QMessageBox.critical(self, "SSH Error", str(e))
            self._reset_connection_state()
        except Exception as e:
            self.connection_panel.set_status("Connection failed")
            self._append_log(f"Connection Error: {e}\n")
            QMessageBox.critical(self, "Connection Error", str(e))
            self._reset_connection_state()

    def _reset_connection_state(self):
        try:
            if self.ssh_client:
                self.ssh_client.close()
        except Exception:
            pass
        self.ssh_client = None
        self.sftp_client = None
        self.connection_panel.set_connected(False)
        self.file_browser.set_connected(None)
        self.terminal.set_connected(None)
        self.temp_panel.set_connected(None)

    def disconnect_ssh(self):
        self.file_browser.cancel_pending()
        self.terminal.cancel_pending()
        for w in list(self._workers):
            try:
                if isinstance(w, SFTPWorker):
                    w.cancel()
                w.quit()
                w.wait(2000)
            except Exception:
                pass
        self._workers.clear()

        if self.ssh_client:
            try:
                self.ssh_client.close()
                self._append_log("SSH connection closed.\n")
            except Exception:
                pass
        self.ssh_client = None
        self.sftp_client = None
        self.connection_panel.set_status("Disconnected")
        self.file_browser.set_connected(None)
        self.terminal.set_connected(None)
        self.temp_panel.set_connected(None)
        self.connection_panel.set_connected(False)

    # -------- helpers --------
    def _append_log(self, text: str):
        self.terminal.append(text.rstrip("\n"))

    def _on_directory_changed(self, new_path: str):
        self.current_path = PurePosixPath(new_path)
        self.terminal.set_current_path(new_path)

    # -------- editor / temp file bridges --------
    def open_remote_in_editor(self, remote_path: str):
        """Open a file from the browser in the editor (download first)."""
        filename = PurePosixPath(remote_path).name
        self.main_tabs.setCurrentWidget(self.editor)
        self.editor.file_label.setText(f"Downloading {filename}...")
        self.editor.status_bar.showMessage(f"Downloading {filename} from server...")

        worker = self._track(
            SFTPWorker(self.sftp_client, "readfile", remote_path=remote_path)
        )
        worker.file_content_ready.connect(self._on_file_content_ready)
        worker.error.connect(self._on_edit_download_error)
        worker.start()

    def _on_file_content_ready(self, filename, content, remote_path):
        temp_path = self.temp_manager.create_temp_file(
            remote_path, content.encode("utf-8")
        )
        self.editor.load_temp_file(temp_path, remote_path)
        self.editor.status_bar.showMessage(f"Loaded {filename} for editing")
        self.temp_panel.refresh()
        QMessageBox.information(
            self, "Success",
            f"File '{filename}' downloaded to temporary storage and opened in editor.",
        )

    def _on_edit_download_error(self, error_msg):
        QMessageBox.critical(self, "Error", f"Failed to download file: {error_msg}")
        self.editor.file_label.setText("Error loading file")
        self.editor.status_bar.showMessage("Download failed")

    def open_temp_in_editor(self, temp_path: str, remote_path: str):
        from pathlib import Path
        self.main_tabs.setCurrentWidget(self.editor)
        self.editor.load_temp_file(Path(temp_path), remote_path)

    def upload_temp_to_server(self, temp_path: str, remote_path: str):
        self.upload_edited_file(__import__("pathlib").Path(temp_path), remote_path)

    def on_editor_upload_requested(self, local_temp_path: str, remote_path: str):
        from pathlib import Path
        self.upload_edited_file(Path(local_temp_path), remote_path)

    def upload_edited_file(self, local_temp_path, remote_path: str):
        from pathlib import Path
        from datetime import datetime
        if not self.sftp_client:
            QMessageBox.warning(self, "Warning", "Connect to the cluster first.")
            return
        try:
            filename = PurePosixPath(remote_path).name
            self.connection_panel.set_status(f"Uploading {filename}...")
            self._append_log(f"Uploading edited file: {filename}\n")

            with open(local_temp_path, "rb") as f:
                content = f.read()
            with self.sftp_client.open(remote_path, "wb") as f:
                f.write(content)

            self.connection_panel.set_status(f"Uploaded {filename}")
            self._append_log(f"Successfully uploaded: {filename}\n")

            temp_path_str = str(local_temp_path)
            if temp_path_str in self.temp_manager.temp_files:
                self.temp_manager.temp_files[temp_path_str]["last_modified"] = (
                    datetime.now()
                )

            QMessageBox.information(
                self, "Success",
                f"File uploaded successfully to:\n{remote_path}",
            )
            self.file_browser.refresh()
            self.temp_panel.refresh()
        except Exception as e:
            self._append_log(f"[Error] Failed to upload file: {e}\n")
            self.connection_panel.set_status("Upload failed")
            QMessageBox.critical(self, "Error", f"Failed to upload file: {e}")

    # -------- dialogs --------
    def show_command_history(self):
        show_command_history_dialog(
            self, self.command_history,
            on_pick_command=lambda cmd: self.terminal.command_input.setText(cmd),
        )

    def show_user_history(self):
        def pick(info):
            self.connection_panel.fill_form(
                info.get("host", ""),
                info.get("port", 22),
                info.get("user", ""),
                info.get("password", ""),
            )
        show_user_history_dialog(self, self.user_history, on_pick_user=pick)

    def show_credential_manager(self):
        def on_use(host, port, user, password):
            self.connection_panel.fill_form(host, port, user, password)
        show_credential_manager_dialog(self, self.user_history, on_use=on_use)

    # -------- lifecycle --------
    def closeEvent(self, event):
        self.file_browser.cancel_pending()
        self.terminal.cancel_pending()
        for w in list(self._workers):
            try:
                if isinstance(w, SFTPWorker):
                    w.cancel()
                w.quit()
                w.wait(2000)
            except Exception:
                pass
        self._workers.clear()
        if self.ssh_client:
            try:
                self.ssh_client.close()
            except Exception:
                pass
        self.temp_manager.cleanup_old_files()
        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = EnhancedClusterConnectorWithEditor()
    window.setWindowTitle("Enhanced Cluster Connector with Text Editor")
    window.resize(1400, 900)
    window.show()
    sys.exit(app.exec())