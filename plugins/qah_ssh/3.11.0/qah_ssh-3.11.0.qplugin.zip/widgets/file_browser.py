"""Remote file browser: tree, navigation, upload/download/edit/delete."""

import os
import re
import shlex
import shutil
import stat
import tarfile
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from datetime import datetime

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTreeWidget, QTreeWidgetItem, QFileDialog, QMessageBox,
    QHeaderView, QAbstractItemView, QProgressDialog, QMenu,
    QApplication, QStyle, QInputDialog, QCheckBox, QGroupBox,
    QProgressBar,
)
from PySide6.QtCore import Qt, Signal, QCoreApplication, QEventLoop, QTimer
from PySide6.QtGui import QFont, QIcon

from .workers import SFTPWorker, SSHWorker, SortableItem
from .transfer_worker import TransferWorker


# Tune these if you need different behavior
CHUNK_SIZE = 1024 * 1024                    # 1 MB per read/write
PROGRESS_UPDATE_INTERVAL = 0.10             # seconds between GUI updates
LARGE_FILE_THRESHOLD = 100 * 1024 * 1024    # >100 MB uses chunked mode

UPLOAD_FILTER = (
    "Any files (*);;"
    "All Files (*.*);;"
    "Quantum Files (*.inp *.orca *.in *.pw);;"
    "VASP Files (INCAR* POSCAR* POTCAR* KPOINTS* CONTCAR* DOSCAR* "
    "EIGENVAL* IBZKPT* OSZICAR* PCDAT*);;"
    "Text Files (*.txt *.py *.sh);;"
    "Data Files (*.dat *.csv *.json)"
)

# Qt's QProgressDialog is int32-backed; anything larger overflows.
_MAX_INT = 2_147_483_647


def _make_progress(parent, label: str, total_bytes: int, title: str):
    """
    Build a QProgressDialog that survives totals larger than INT32_MAX.

    Returns (dialog, scale) where `scale` = number of real bytes per progress
    unit. The dialog's maximum equals `max(int(total_bytes / scale), 1)`, so
    setting `int(real_bytes / scale)` reaches 100% exactly when all bytes are
    transferred. Callers should still push `progress.maximum()` at the end of
    a batch to guarantee the bar fills even if rounding left it at N-1.
    """
    total = max(int(total_bytes), 1)
    if total <= _MAX_INT:
        scale = 1
    else:
        scale = (total // _MAX_INT) + 1

    progress_max = max(int(total // scale), 1)
    progress = QProgressDialog(label, "Cancel", 0, progress_max, parent)
    progress.setWindowTitle(title)
    progress.setWindowModality(Qt.WindowModal)
    progress.setAutoClose(True)
    progress.setValue(0)
    return progress, scale


def _progress_scale(total_bytes: int):
    """Return (scale, progress_maximum) for Qt's int32-backed widgets."""
    total = max(int(total_bytes), 1)
    if total <= _MAX_INT:
        scale = 1
    else:
        scale = (total // _MAX_INT) + 1
    return scale, max(int(total // scale), 1)


@dataclass
class TransferJob:
    """One upload/download request waiting in the transfer queue."""

    kind: str                    # upload_files | upload_folder | download
    title: str
    payload: dict
    total: int = 0
    status: str = "Queued"       # Queued | Running | Done | Error | Canceled
    detail: str = ""
    cancel_requested: bool = False
    scale: int = 1
    item: object = field(default=None, repr=False)


class FileBrowser(QWidget):
    file_open_in_editor = Signal(str)   # remote_path
    directory_changed = Signal(str)     # new path
    status_message = Signal(str)        # append to terminal log
    error_dialog = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.sftp_client = None
        self.ssh_client = None
        self.current_path = PurePosixPath("/home")
        self._workers = []
        self._tar_worker = None
        self._tar_progress = None
        self._queue_jobs = []
        self._queue_current = None
        self._queue_worker = None
        self._queue_paused = False
        self._queue_cancel_all = False
        self._init_ui()

    # -------- worker tracking --------
    def _track(self, worker):
        self._workers.append(worker)
        worker.finished.connect(lambda: self._untrack(worker))
        worker.error.connect(lambda _msg: self._untrack(worker))
        return worker

    def _untrack(self, worker):
        if worker in self._workers:
            self._workers.remove(worker)

    def cancel_pending(self):
        self._queue_cancel_all = True
        self._queue_paused = True
        if self._queue_current is not None:
            self._queue_current.cancel_requested = True
        worker = self._queue_worker
        if worker is not None:
            try:
                worker.cancel()
                if worker.wait(5000):
                    self._queue_worker = None
            except Exception:
                pass
        for w in list(self._workers):
            try:
                if isinstance(w, SFTPWorker):
                    w.cancel()
                w.quit()
                w.wait(2000)
            except Exception:
                pass
        self._workers.clear()

    # -------- UI --------
    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Remote File Browser"))

        nav = QHBoxLayout()
        self.back_btn = QPushButton("Back")
        self.back_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_ArrowBack))
        self.back_btn.clicked.connect(self.go_back)
        self.back_btn.setEnabled(False)

        self.up_btn = QPushButton("Up")
        self.up_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_ArrowUp))
        self.up_btn.clicked.connect(self.go_back)
        self.up_btn.setEnabled(False)

        self.home_btn = QPushButton("Home")
        self.home_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_DirHomeIcon))
        self.home_btn.clicked.connect(self.go_home)
        self.home_btn.setEnabled(False)

        self.refresh_btn = QPushButton("Refresh")
        self.refresh_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_BrowserReload))
        self.refresh_btn.clicked.connect(self.refresh)
        self.refresh_btn.setEnabled(False)

        nav.addWidget(self.back_btn)
        nav.addWidget(self.up_btn)
        nav.addWidget(self.home_btn)
        nav.addWidget(self.refresh_btn)
        nav.addStretch()
        layout.addLayout(nav)

        self.path_label = QLabel(str(self.current_path))
        self.path_label.setFont(QFont("Courier New", 10))
        self.path_label.setStyleSheet("background-color: #f0f0f0; padding: 3px;")
        layout.addWidget(self.path_label)

        self.tree = QTreeWidget()
        self.tree.setSortingEnabled(True)
        self.tree.setSortingEnabled(False)
        self.tree.setHeaderLabels(["Name", "Size", "Type", "Modified"])
        self.tree.header().setSectionResizeMode(QHeaderView.Interactive)
        self.tree.header().setSectionsClickable(True)
        self.tree.header().setSortIndicatorShown(True)
        self.tree.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.tree.itemDoubleClicked.connect(self._on_item_double_clicked)
        self.tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._show_context_menu)
        layout.addWidget(self.tree)

        btns = QHBoxLayout()
        self.new_folder_btn = QPushButton("New Folder")
        self.new_folder_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_FileDialogNewFolder)
        )
        self.new_folder_btn.clicked.connect(self.create_new_folder)
        self.new_folder_btn.setEnabled(False)

        self.upload_folder_btn = QPushButton("Upload Folder")
        self.upload_folder_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_DirIcon)
        )
        self.upload_folder_btn.clicked.connect(self.upload_folder)
        self.upload_folder_btn.setEnabled(False)

        self.upload_file_btn = QPushButton("Upload File")
        self.upload_file_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_ArrowUp)
        )
        self.upload_file_btn.clicked.connect(self.upload_file)
        self.upload_file_btn.setEnabled(False)

        self.download_btn = QPushButton("Download")
        self.download_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_ArrowDown)
        )
        self.download_btn.clicked.connect(self.download_selected)
        self.download_btn.setEnabled(False)

        self.queue_check = QCheckBox("Queue transfers")
        self.queue_check.setToolTip(
            "When checked, Upload File, Upload Folder and Download add jobs to "
            "the Transfer Queue tab instead of running immediately."
        )

        self.compress_check = QCheckBox("Compress on server (tar.gz)")
        self.compress_check.setChecked(True)
        self.compress_check.setToolTip(
            "Create one tar.gz archive on the cluster, download it, and extract "
            "it locally. Recommended for folders and text/data files; turn it "
            "off for files that are already compressed."
        )
        self.compress_check.setEnabled(False)

        self.edit_btn = QPushButton("Edit in Text Editor")
        self.edit_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_FileIcon)
        )
        self.edit_btn.clicked.connect(self._edit_selected)
        self.edit_btn.setEnabled(False)

        self.delete_btn = QPushButton("Delete")
        self.delete_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_TrashIcon)
        )
        self.delete_btn.clicked.connect(self.delete_selected)
        self.delete_btn.setEnabled(False)

        for b in (self.new_folder_btn, self.upload_folder_btn,
                  self.upload_file_btn, self.download_btn,
                  self.edit_btn, self.delete_btn):
            btns.addWidget(b)
        btns.addWidget(self.queue_check)
        btns.addWidget(self.compress_check)
        btns.addStretch()
        layout.addLayout(btns)

        queue_box = QGroupBox("Transfer Queue")
        qv = QVBoxLayout(queue_box)
        self.queue_tree = QTreeWidget()
        self.queue_tree.setHeaderLabels(["Job", "Status", "Detail"])
        self.queue_tree.setRootIsDecorated(False)
        self.queue_tree.setAlternatingRowColors(True)
        self.queue_tree.setMinimumHeight(180)
        self.queue_tree.header().setSectionResizeMode(0, QHeaderView.Stretch)
        self.queue_tree.header().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.queue_tree.header().setSectionResizeMode(2, QHeaderView.Stretch)
        self.queue_tree.itemSelectionChanged.connect(self._update_queue_buttons)
        qv.addWidget(self.queue_tree)

        self.queue_detail_label = QLabel("Queue is empty.")
        self.queue_detail_label.setStyleSheet("color: #6c757d;")
        self.queue_detail_label.setWordWrap(True)
        qv.addWidget(self.queue_detail_label)

        self.queue_progress = QProgressBar()
        self.queue_progress.setRange(0, 1)
        self.queue_progress.setValue(0)
        qv.addWidget(self.queue_progress)

        hint = QLabel(
            "Add jobs from SSH Browser with <b>Queue transfers</b> checked. "
            "These buttons control the queue."
        )
        hint.setWordWrap(True)
        hint.setStyleSheet("color: #6b7280;")
        qv.addWidget(hint)

        row = QHBoxLayout()
        self.queue_pause_btn = QPushButton("Pause")
        self.queue_pause_btn.setToolTip(
            "Finish the current transfer, then wait before the next job"
        )
        self.queue_pause_btn.clicked.connect(self._toggle_queue_pause)
        row.addWidget(self.queue_pause_btn)
        self.queue_cancel_btn = QPushButton("Stop current")
        self.queue_cancel_btn.setToolTip("Stop the active transfer")
        self.queue_cancel_btn.clicked.connect(self._cancel_current_transfer)
        row.addWidget(self.queue_cancel_btn)
        self.queue_stop_all_btn = QPushButton("Stop all")
        self.queue_stop_all_btn.setToolTip(
            "Stop the active transfer and cancel every waiting job"
        )
        self.queue_stop_all_btn.clicked.connect(self._stop_all_transfers)
        row.addWidget(self.queue_stop_all_btn)
        self.queue_retry_btn = QPushButton("Retry")
        self.queue_retry_btn.setToolTip(
            "Requeue the selected finished, failed or canceled job"
        )
        self.queue_retry_btn.clicked.connect(self._retry_selected_transfer)
        row.addWidget(self.queue_retry_btn)
        self.queue_clear_btn = QPushButton("Clear")
        self.queue_clear_btn.setToolTip("Remove finished, failed and canceled jobs")
        self.queue_clear_btn.clicked.connect(self._clear_finished_transfers)
        row.addWidget(self.queue_clear_btn)
        row.addStretch(1)
        qv.addLayout(row)

        self.queue_box = queue_box
        layout.addWidget(queue_box)

    def detach_queue_panel(self) -> QWidget:
        """Remove the queue group from the browser layout for a separate tab."""
        box = self.queue_box
        layout = self.layout()
        if layout is not None:
            layout.removeWidget(box)
        box.setParent(None)
        return box

    # -------- connection API --------
    def set_connected(self, sftp_client, initial_path=None, ssh_client=None):
        self.sftp_client = sftp_client
        self.ssh_client = ssh_client
        if initial_path:
            self.current_path = PurePosixPath(initial_path)
        enabled = sftp_client is not None
        for b in (self.back_btn, self.up_btn, self.home_btn, self.refresh_btn,
                  self.new_folder_btn, self.upload_folder_btn, self.upload_file_btn,
                  self.download_btn, self.edit_btn, self.delete_btn):
            b.setEnabled(enabled)
        self.compress_check.setEnabled(enabled and ssh_client is not None)
        if enabled:
            self._queue_cancel_all = False
            self.refresh()
            self._maybe_start_next_transfer()
        else:
            self._queue_cancel_all = True
            self._queue_paused = True
            self.queue_pause_btn.setText("Resume")
            self.tree.clear()
            self.path_label.setText("Disconnected")

    # -------- listing --------
    def refresh(self):
        if not self.sftp_client:
            return
        for w in list(self._workers):
            if isinstance(w, SFTPWorker) and w.operation == "listdir":
                w.cancel()
        self.tree.clear()
        self.status_message.emit(f"Refreshing file list in: {self.current_path}\n")
        worker = self._track(
            SFTPWorker(self.sftp_client, "listdir", str(self.current_path))
        )
        worker.file_list_ready.connect(self._populate)
        worker.error.connect(self._on_sftp_error)
        worker.start()

    def _populate(self, files):
        self.tree.setSortingEnabled(False)
        self.tree.clear()
        files_sorted = sorted(
            files, key=lambda f: (not stat.S_ISDIR(f.st_mode), f.filename.lower())
        )
        for f in files_sorted:
            is_dir = stat.S_ISDIR(f.st_mode)
            size_str = self._format_size(f.st_size) if not is_dir else ""
            file_type = "Directory" if is_dir else "File"
            modified = (
                datetime.fromtimestamp(f.st_mtime).strftime("%Y-%m-%d %H:%M")
                if f.st_mtime else ""
            )
            item = SortableItem([f.filename, size_str, file_type, modified])
            item.setData(0, Qt.UserRole + 1, f.filename.lower())
            item.setData(1, Qt.UserRole + 1, 0 if is_dir else int(f.st_size))
            item.setData(2, Qt.UserRole + 1, 0 if is_dir else 1)
            item.setData(3, Qt.UserRole + 1, int(f.st_mtime) if f.st_mtime else 0)
            item.setIcon(
                0,
                QApplication.style().standardIcon(
                    QStyle.SP_DirIcon if is_dir else QStyle.SP_FileIcon
                ),
            )
            item.setData(0, Qt.UserRole, f.filename)
            self.tree.addTopLevelItem(item)
        self.tree.setSortingEnabled(True)
        self.path_label.setText(str(self.current_path))

    @staticmethod
    def _format_size(size_bytes):
        for unit in ["B", "KB", "MB", "GB", "TB"]:
            if size_bytes < 1024.0:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.1f} PB"

    def _on_sftp_error(self, msg):
        self.status_message.emit(f"[Error] SFTP Error: {msg}\n")
        self.error_dialog.emit(msg)

    # -------- navigation --------
    def _on_item_double_clicked(self, item, _column):
        filename = item.data(0, Qt.UserRole)
        if item.text(2) == "Directory":
            self._chdir(str(self.current_path / filename))
        else:
            self.status_message.emit(f"File: {filename}\n")

    def _chdir(self, target: str):
        worker = self._track(SFTPWorker(self.sftp_client, "chdir", target))
        worker.finished.connect(self._on_chdir_ok)
        worker.error.connect(self._on_chdir_error)
        worker.start()

    def _on_chdir_ok(self, new_path):
        self.current_path = PurePosixPath(new_path)
        self.directory_changed.emit(new_path)
        self.refresh()
        self.status_message.emit(f"Directory changed to: {new_path}\n")

    def _on_chdir_error(self, msg):
        self.error_dialog.emit(f"Could not change directory:\n{msg}")
        self.status_message.emit(f"[Error] cd error: {msg}\n")

    def go_back(self):
        parent = self.current_path.parent
        if parent and parent != self.current_path:
            self._chdir(str(parent))

    def go_home(self):
        self._chdir("~")

    def change_dir(self, target: str):
        if not target:
            target = "~"
        if target.startswith("~"):
            self._chdir(target)
        elif not PurePosixPath(target).is_absolute():
            self._chdir(str(self.current_path / target))
        else:
            self._chdir(target)

    # -------- file operations --------
    def _edit_selected(self):
        items = self.tree.selectedItems()
        if not items:
            QMessageBox.warning(self, "Warning", "Select a file to edit.")
            return
        item = items[0]
        if item.text(2) == "Directory":
            QMessageBox.warning(self, "Warning", "Cannot edit directories.")
            return
        filename = item.data(0, Qt.UserRole)
        self.file_open_in_editor.emit(str(self.current_path / filename))

    # ==================================================================
    # TRANSFER QUEUE
    # ==================================================================
    def _refresh_queue(self):
        self.queue_tree.clear()
        for job in self._queue_jobs:
            item = QTreeWidgetItem([job.title, job.status, job.detail])
            item.setToolTip(0, job.title)
            item.setToolTip(2, job.detail)
            self.queue_tree.addTopLevelItem(item)
            job.item = item
        if self._queue_current is None and not self._queue_jobs:
            self.queue_detail_label.setText("Queue is empty.")
        self._update_queue_buttons()

    def _selected_queue_job(self):
        items = self.queue_tree.selectedItems()
        if not items:
            return None
        index = self.queue_tree.indexOfTopLevelItem(items[0])
        if 0 <= index < len(self._queue_jobs):
            return self._queue_jobs[index]
        return None

    def _update_queue_buttons(self):
        running = self._queue_current is not None
        pending = any(job.status == "Queued" for job in self._queue_jobs)
        finished = any(
            job.status in ("Done", "Error", "Canceled") for job in self._queue_jobs
        )
        selected = self._selected_queue_job()
        retry = bool(
            selected is not None
            and selected is not self._queue_current
            and selected.status in ("Done", "Error", "Canceled")
        )
        self.queue_cancel_btn.setEnabled(running)
        self.queue_pause_btn.setEnabled(running or pending)
        self.queue_stop_all_btn.setEnabled(running or pending)
        self.queue_retry_btn.setEnabled(retry)
        self.queue_clear_btn.setEnabled(finished)
        self.queue_pause_btn.setText(
            "Resume" if self._queue_paused else "Pause"
        )

    def _enqueue_transfer(self, kind, title, payload, total=0):
        job = TransferJob(
            kind=kind, title=title, payload=payload, total=int(total)
        )
        self._queue_jobs.append(job)
        self.status_message.emit(f"[Queue] Added: {title}\n")
        self._refresh_queue()
        self._maybe_start_next_transfer()

    def _maybe_start_next_transfer(self):
        if (
            self._queue_current is not None
            or self._queue_paused
            or self._queue_cancel_all
            or self.sftp_client is None
            or self.ssh_client is None
        ):
            return
        job = next(
            (item for item in self._queue_jobs if item.status == "Queued"),
            None,
        )
        if job is None:
            return
        self._queue_current = job
        job.status = "Running"
        job.cancel_requested = False
        job.scale = 1
        self.queue_progress.setRange(0, 0)
        self.queue_detail_label.setText(job.title)
        self._refresh_queue()
        worker = TransferWorker(
            self.ssh_client, job.kind, job.payload
        )
        worker.progress.connect(
            lambda current, total, j=job: self._on_queue_progress(
                j, current, total
            )
        )
        worker.label.connect(
            lambda text, j=job: self._on_queue_label(j, text)
        )
        worker.done.connect(
            lambda ok, detail, j=job, w=worker: self._on_queue_done(
                j, ok, detail, w
            )
        )
        worker.finished.connect(worker.deleteLater)
        self._queue_worker = worker
        worker.start()

    def _on_queue_progress(self, job, current, total):
        if job is not self._queue_current:
            return
        total = max(int(total), 0)
        if total <= 0:
            self.queue_progress.setRange(0, 0)
            return
        if total != job.total or job.scale <= 0:
            job.total = total
            job.scale, maximum = _progress_scale(total)
            self.queue_progress.setRange(0, maximum)
        self.queue_progress.setValue(int(current / job.scale))

    def _on_queue_label(self, job, text):
        if job is not self._queue_current:
            return
        job.detail = str(text).replace("\n", " ")
        self.queue_detail_label.setText(job.detail)

    def _on_queue_done(self, job, ok, detail, worker):
        if self._queue_worker is worker:
            self._queue_worker = None
        if job.cancel_requested or detail == "Canceled":
            self._finish_transfer(job, "Canceled", "Canceled by user")
        elif ok:
            self._finish_transfer(job, "Done", detail or "Complete")
        else:
            self.status_message.emit(
                f"[Error] Queue job failed: {job.title}: {detail}\n"
            )
            self._finish_transfer(job, "Error", detail or "Failed")

    def _finish_transfer(self, job: TransferJob, status: str, detail: str):
        job.status = status
        job.detail = detail
        if self._queue_current is job:
            self._queue_current = None
        if status == "Done":
            self.queue_progress.setRange(0, 1)
            self.queue_progress.setValue(1)
        else:
            self.queue_progress.setRange(0, 1)
            self.queue_progress.setValue(0)
        self.queue_detail_label.setText(
            f"{job.title}: {status}"
            + (f" — {detail}" if detail and detail != "Complete" else "")
        )
        self._refresh_queue()
        if status == "Done" and job.kind.startswith("upload"):
            self.refresh()
        self.status_message.emit(f"[Queue] {job.title}: {status}\n")
        QTimer.singleShot(80, self._maybe_start_next_transfer)

    def _toggle_queue_pause(self):
        if self._queue_paused:
            self._queue_paused = False
            self._queue_cancel_all = False
            self.status_message.emit("[Queue] Resumed.\n")
            self._refresh_queue()
            self._maybe_start_next_transfer()
        else:
            self._queue_paused = True
            self.status_message.emit(
                "[Queue] Paused after the current transfer.\n"
            )
            self._refresh_queue()

    def _cancel_current_transfer(self):
        job = self._queue_current
        if job is None:
            return
        job.cancel_requested = True
        job.detail = "Cancelling..."
        self.queue_detail_label.setText(f"Cancelling: {job.title}")
        if self._queue_worker is not None:
            try:
                self._queue_worker.cancel()
            except Exception:
                pass
        self._refresh_queue()

    def _stop_all_transfers(self):
        self._queue_paused = True
        job = self._queue_current
        if job is not None:
            job.cancel_requested = True
            job.detail = "Stopping..."
            if self._queue_worker is not None:
                try:
                    self._queue_worker.cancel()
                except Exception:
                    pass
        for waiting in self._queue_jobs:
            if waiting.status == "Queued":
                waiting.status = "Canceled"
                waiting.detail = "Stopped before start"
                waiting.cancel_requested = True
        self.queue_detail_label.setText(
            "Stopping all transfers..." if job is not None else "Queue stopped."
        )
        self.status_message.emit("[Queue] Stopping all transfers.\n")
        self._refresh_queue()

    def _retry_selected_transfer(self):
        job = self._selected_queue_job()
        if job is None or job is self._queue_current:
            return
        if job.status not in ("Done", "Error", "Canceled"):
            return
        job.status = "Queued"
        job.detail = ""
        job.cancel_requested = False
        job.total = 0
        job.scale = 1
        self._queue_paused = False
        self._queue_cancel_all = False
        self.status_message.emit(f"[Queue] Requeued: {job.title}\n")
        self._refresh_queue()
        self._maybe_start_next_transfer()

    def _clear_finished_transfers(self):
        self._queue_jobs = [
            job
            for job in self._queue_jobs
            if job.status not in ("Done", "Error", "Canceled")
        ]
        self._refresh_queue()

    def enqueue_upload_files(self):
        if not self.sftp_client:
            QMessageBox.warning(self, "Warning", "Connect to the cluster first.")
            return
        local_files, _ = QFileDialog.getOpenFileNames(
            self, "Select files to queue for upload", "", UPLOAD_FILTER
        )
        if not local_files:
            return
        total = 0
        for path in local_files:
            try:
                total += Path(path).stat().st_size
            except OSError:
                pass
        remote_dir = str(self.current_path)
        self._enqueue_transfer(
            "upload_files",
            f"Upload {len(local_files)} file(s) to {remote_dir}",
            {"files": list(local_files), "remote_dir": remote_dir},
            total,
        )

    def enqueue_upload_folder(self):
        if not self.sftp_client:
            QMessageBox.warning(self, "Warning", "Connect to the cluster first.")
            return
        local_dir = QFileDialog.getExistingDirectory(
            self, "Select folder to queue for upload"
        )
        if not local_dir:
            return
        local_path = Path(local_dir)
        files = []
        total = 0
        for root, _dirs, names in os.walk(local_dir):
            for name in names:
                path = Path(root) / name
                files.append(str(path))
                try:
                    total += path.stat().st_size
                except OSError:
                    pass
        remote_dir = str(self.current_path)
        self._enqueue_transfer(
            "upload_folder",
            f"Upload folder {local_path.name} to {remote_dir}",
            {
                "local_dir": str(local_path),
                "files": files,
                "remote_dir": remote_dir,
            },
            total,
        )

    def enqueue_download(self):
        if not self.sftp_client:
            QMessageBox.warning(self, "Warning", "Connect to the cluster first.")
            return
        items = self.tree.selectedItems()
        if not items:
            QMessageBox.warning(
                self, "Warning", "Select files or folders to download."
            )
            return
        local_dir = QFileDialog.getExistingDirectory(
            self, "Select download destination"
        )
        if not local_dir:
            return
        entries = []
        base = str(self.current_path)
        for item in items:
            name = str(item.data(0, Qt.UserRole) or "")
            if not name:
                continue
            entries.append(
                {
                    "name": name,
                    "path": str(PurePosixPath(base) / name),
                    "cwd": base,
                    "is_dir": item.text(2) == "Directory",
                }
            )
        if not entries:
            return
        compress = bool(self.compress_check.isChecked())
        if compress and self.ssh_client is None:
            compress = False
            self.status_message.emit(
                "[Warning] Compressed download needs the SSH command channel; "
                "queueing a normal download instead.\n"
            )
        self._enqueue_transfer(
            "download",
            f"Download {len(entries)} item(s) to {Path(local_dir)}",
            {"entries": entries, "dest": str(local_dir), "compress": compress},
        )

    # ==================================================================
    # DOWNLOAD — recursive folders + chunked files + INT32-safe progress
    # ==================================================================
    def download_selected(self):
        if not self.sftp_client:
            QMessageBox.warning(self, "Warning", "Connect to the cluster first.")
            return
        if self.queue_check.isChecked():
            self.enqueue_download()
            return
        items = self.tree.selectedItems()
        if not items:
            QMessageBox.warning(self, "Warning", "Select files or folders to download.")
            return
        local_dir = QFileDialog.getExistingDirectory(self, "Select download destination")
        if not local_dir:
            return
        dest_root = Path(local_dir)

        if self.compress_check.isChecked():
            if self.ssh_client is None:
                self.status_message.emit(
                    "[Warning] Compressed download needs the SSH command channel; "
                    "using normal download.\n"
                )
            else:
                self._download_compressed(items, dest_root)
                return

        # First pass: enumerate everything so the progress bar has a total
        plan = []   # (remote_path, local_path, size, is_dir)
        for item in items:
            filename = item.data(0, Qt.UserRole)
            remote_path = str(self.current_path / filename)
            if item.text(2) == "Directory":
                self._enumerate_remote_dir(remote_path, dest_root / filename, plan)
            else:
                try:
                    size = self.sftp_client.stat(remote_path).st_size
                except Exception:
                    size = 0
                plan.append((remote_path, dest_root / filename, size, False))

        if not plan:
            self.status_message.emit("[Info] Nothing to download.\n")
            return

        total_bytes = sum(p[2] for p in plan if not p[3])
        file_count = sum(1 for p in plan if not p[3])
        self.status_message.emit(
            f"Downloading {file_count} file(s), total {self._format_size(total_bytes)}\n"
        )

        progress, scale = _make_progress(
            self, "Preparing download...", total_bytes, "Batch Download"
        )
        downloaded_any = self._download_plan(
            plan, dest_root, progress, scale, total_bytes
        )
        if downloaded_any:
            # Guarantee 100% even if integer division left it short
            progress.setValue(progress.maximum())
            self.status_message.emit("Download complete.\n")

    def _download_plan(self, plan, dest_root, progress, scale, total_bytes):
        """Transfer a prepared (remote, local, size, is_dir) plan."""
        accumulated = 0
        downloaded_any = False
        handled_any = False
        for remote_path, local_path, size, is_dir in plan:
            if progress.wasCanceled():
                self.status_message.emit(
                    "[Canceled] Batch download stopped by user.\n"
                )
                break
            if is_dir:
                local_path.mkdir(parents=True, exist_ok=True)
                handled_any = True
                continue

            progress.setLabelText(
                f"Downloading {PurePosixPath(remote_path).name} "
                f"({self._format_size(size)})..."
            )
            ok = self._download_one(
                remote_path, local_path, size,
                progress, accumulated, total_bytes, scale,
            )
            if ok:
                downloaded_any = True
            accumulated += size
            progress.setValue(int(accumulated / scale))
        if any(not entry[3] for entry in plan):
            return downloaded_any
        return handled_any

    def _download_items_worker(self, entries, dest_root: Path, compress, progress):
        """Build a plan for queued entries and transfer it."""
        if compress and self.ssh_client is not None:
            return self._download_compressed_sync(entries, dest_root, progress)
        plan = []
        for entry in entries:
            remote_path = entry["path"]
            if entry.get("is_dir"):
                self._enumerate_remote_dir(
                    remote_path, dest_root / entry["name"], plan
                )
            else:
                try:
                    size = self.sftp_client.stat(remote_path).st_size
                except Exception:
                    size = 0
                plan.append(
                    (remote_path, dest_root / entry["name"], size, False)
                )
        if not plan:
            self.status_message.emit("[Info] Nothing to download.\n")
            return True
        total_bytes = sum(p[2] for p in plan if not p[3])
        scale = progress.configure(total_bytes)
        return self._download_plan(
            plan, dest_root, progress, scale, total_bytes
        )

    # -------- compressed download (tar.gz on cluster) --------
    def _download_compressed(self, items, dest_root: Path):
        """Create one tar.gz on the cluster, download it and extract locally."""
        if not self.sftp_client or not self.ssh_client:
            QMessageBox.warning(self, "Warning", "Connect to the cluster first.")
            return
        if self._tar_worker is not None and self._tar_worker.isRunning():
            QMessageBox.information(
                self, "Busy", "A compressed download is already being prepared."
            )
            return
        names = []
        for item in items:
            name = str(item.data(0, Qt.UserRole) or "")
            if not name or "\n" in name or "\r" in name:
                QMessageBox.warning(self, "Warning", f"Unsupported remote name: {name!r}")
                return
            names.append(name)
        if not names:
            QMessageBox.warning(self, "Warning", "Select files or folders to download.")
            return

        quoted_names = " ".join(shlex.quote(name) for name in names)
        cwd = shlex.quote(str(self.current_path))
        command = (
            'tmp=$(mktemp "${TMPDIR:-/tmp}/qah_ssh_dl_XXXXXX.tar.gz") || exit 1; '
            f'tar -czf "$tmp" -C {cwd} -- {quoted_names} '
            '|| { rm -f "$tmp"; exit 2; }; '
            'printf "\\n__QAH_ARCHIVE__%s\\n" "$tmp"'
        )

        self._tar_output = ""
        self._tar_stderr = ""
        self._tar_dest = dest_root
        self._tar_worker = None

        progress = QProgressDialog(
            "Compressing selected files on the cluster...", "", 0, 0, self
        )
        progress.setWindowTitle("Compressed Download")
        progress.setWindowModality(Qt.WindowModal)
        progress.setCancelButton(None)
        progress.setMinimumDuration(0)
        progress.show()
        QCoreApplication.processEvents()
        self._tar_progress = progress

        worker = self._track(SSHWorker(self.ssh_client, command))
        worker.output.connect(self._on_tar_output)
        worker.error.connect(self._on_tar_error)
        worker.finished.connect(self._on_tar_finished)
        self._tar_worker = worker
        worker.start()

    def _on_tar_output(self, text: str):
        self._tar_output += text

    def _on_tar_error(self, text: str):
        self._tar_stderr += text

    def _on_tar_finished(self):
        progress = getattr(self, "_tar_progress", None)
        if progress is not None:
            progress.close()
        self._tar_progress = None
        output = getattr(self, "_tar_output", "")
        stderr = getattr(self, "_tar_stderr", "")
        marker = "__QAH_ARCHIVE__"
        if marker not in output:
            detail = stderr.strip() or output.strip() or "unknown error"
            self.status_message.emit(
                f"[Error] Compressed download failed on the cluster: {detail}\n"
            )
            QMessageBox.critical(
                self,
                "Compressed download failed",
                "The cluster could not create the tar.gz archive.\n\n"
                f"{detail[-2000:]}\n\n"
                "Check that 'tar' and 'gzip' are available on the cluster, "
                "or disable 'Compress on server' and use a normal download.",
            )
            return

        remote_archive = output.rsplit(marker, 1)[1].strip().splitlines()[0].strip()
        if not remote_archive:
            self.status_message.emit("[Error] Compressed download returned no archive path.\n")
            return

        dest_root = getattr(self, "_tar_dest", Path.home())
        local_root = Path(tempfile.mkdtemp(prefix="qah_ssh_download_"))
        local_archive = local_root / "download.tar.gz"
        try:
            try:
                size = self.sftp_client.stat(remote_archive).st_size
            except Exception:
                size = 0
            self.status_message.emit(
                f"[Info] Cluster archive ready: {remote_archive} "
                f"({self._format_size(size)})\n"
            )
            progress2, scale = _make_progress(
                self,
                "Downloading compressed archive...",
                size,
                "Compressed Download",
            )
            ok = self._download_one(
                remote_archive, local_archive, size, progress2, 0, size, scale
            )
            progress2.setValue(progress2.maximum())
            progress2.close()
            if not ok:
                self.status_message.emit(
                    "[Canceled] Compressed download canceled; remote archive removed.\n"
                )
                return
            try:
                count = self._extract_tar_safe(local_archive, dest_root)
            except Exception as exc:
                self.status_message.emit(
                    f"[Error] Could not extract {remote_archive}: {exc}\n"
                )
                QMessageBox.critical(
                    self,
                    "Extraction failed",
                    f"The archive downloaded but could not be extracted:\n\n{exc}",
                )
                return
            self.status_message.emit(
                f"Compressed download complete: {count} item(s) extracted to "
                f"{dest_root}\n"
            )
        finally:
            try:
                self.sftp_client.remove(remote_archive)
            except Exception:
                self.status_message.emit(
                    f"[Warning] Could not remove remote temp archive: {remote_archive}\n"
                )
            shutil.rmtree(local_root, ignore_errors=True)
            self._tar_worker = None

    def _run_ssh_command_blocking(self, command: str):
        """Run an SSH command and wait while keeping the Qt event loop alive."""
        if self.ssh_client is None:
            return "", "The SSH command channel is not available."
        output = []
        errors = []
        worker = SSHWorker(self.ssh_client, command)
        worker.output.connect(output.append)
        worker.error.connect(errors.append)
        loop = QEventLoop()
        worker.finished.connect(loop.quit)
        self._track(worker)
        worker.start()
        loop.exec()
        try:
            worker.wait(2000)
        except Exception:
            pass
        return "".join(output), "".join(errors)

    def _download_compressed_sync(self, entries, dest_root: Path, progress):
        """Queued compressed download: tar on the cluster, then download/extract."""
        if not self.sftp_client or not self.ssh_client:
            self.status_message.emit(
                "[Error] Compressed download needs SFTP and SSH channels.\n"
            )
            return False
        if not entries:
            return False
        names = []
        for entry in entries:
            name = str(entry.get("name") or "")
            if not name or "\n" in name or "\r" in name:
                self.status_message.emit(
                    f"[Error] Unsupported remote name: {name!r}\n"
                )
                return False
            names.append(name)
        base_dir = str(entries[0].get("cwd") or self.current_path)
        quoted_names = " ".join(shlex.quote(name) for name in names)
        cwd = shlex.quote(base_dir)
        command = (
            'tmp=$(mktemp "${TMPDIR:-/tmp}/qah_ssh_dl_XXXXXX.tar.gz") || exit 1; '
            f'tar -czf "$tmp" -C {cwd} -- {quoted_names} '
            '|| { rm -f "$tmp"; exit 2; }; '
            'printf "\\n__QAH_ARCHIVE__%s\\n" "$tmp"'
        )

        progress.setMaximum(0)
        progress.setLabelText("Compressing selected files on the cluster...")
        output, stderr = self._run_ssh_command_blocking(command)
        marker = "__QAH_ARCHIVE__"
        if marker not in output:
            detail = stderr.strip() or output.strip() or "unknown error"
            self.status_message.emit(
                f"[Error] Compressed download failed on the cluster: {detail}\n"
            )
            return False
        remote_archive = output.rsplit(marker, 1)[1].strip().splitlines()[0].strip()
        if not remote_archive:
            self.status_message.emit(
                "[Error] Compressed download returned no archive path.\n"
            )
            return False
        if progress.wasCanceled():
            try:
                self.sftp_client.remove(remote_archive)
            except Exception:
                pass
            return False

        local_root = Path(tempfile.mkdtemp(prefix="qah_ssh_download_"))
        local_archive = local_root / "download.tar.gz"
        try:
            try:
                size = self.sftp_client.stat(remote_archive).st_size
            except Exception:
                size = 0
            scale = progress.configure(size)
            progress.setLabelText("Downloading compressed archive...")
            ok = self._download_one(
                remote_archive, local_archive, size, progress, 0, size, scale
            )
            if not ok:
                self.status_message.emit(
                    "[Canceled] Compressed download canceled; remote archive removed.\n"
                )
                return False
            count = self._extract_tar_safe(local_archive, dest_root)
            self.status_message.emit(
                f"Compressed download complete: {count} item(s) extracted to "
                f"{dest_root}\n"
            )
            return True
        except Exception as exc:
            self.status_message.emit(
                f"[Error] Could not extract compressed download: {exc}\n"
            )
            return False
        finally:
            try:
                self.sftp_client.remove(remote_archive)
            except Exception:
                self.status_message.emit(
                    f"[Warning] Could not remove remote temp archive: "
                    f"{remote_archive}\n"
                )
            shutil.rmtree(local_root, ignore_errors=True)

    def _extract_tar_safe(self, archive_path: Path, dest_root: Path) -> int:
        """Extract a tar.gz without allowing traversal, symlinks or devices."""
        dest = dest_root.resolve()
        dest.mkdir(parents=True, exist_ok=True)
        count = 0
        with tarfile.open(archive_path, "r:gz") as archive:
            for member in archive.getmembers():
                name = member.name.replace("\\", "/")
                path = PurePosixPath(name)
                if not name or name in (".", "./"):
                    continue
                if path.is_absolute() or ".." in path.parts:
                    raise ValueError(f"Unsafe path in archive: {name!r}")
                if member.issym() or member.islnk():
                    self.status_message.emit(
                        f"[Warning] Skipped link in archive: {name}\n"
                    )
                    continue
                target = (dest.joinpath(*path.parts)).resolve()
                if dest not in target.parents and target != dest:
                    raise ValueError(f"Unsafe path in archive: {name!r}")
                if member.isdir():
                    target.mkdir(parents=True, exist_ok=True)
                elif member.isfile():
                    source = archive.extractfile(member)
                    if source is None:
                        continue
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with source, open(target, "wb") as output:
                        shutil.copyfileobj(source, output)
                    count += 1
        return count

    def _enumerate_remote_dir(self, remote_dir, local_dir: Path, plan):
        """Walk a remote dir, appending to `plan` so we know total size upfront."""
        plan.append((remote_dir, local_dir, 0, True))
        try:
            entries = self.sftp_client.listdir_attr(remote_dir)
        except Exception as e:
            self.status_message.emit(
                f"[Error] Could not list {remote_dir}: {e}\n"
            )
            return
        for entry in entries:
            rp = str(PurePosixPath(remote_dir) / entry.filename)
            lp = local_dir / entry.filename
            if stat.S_ISDIR(entry.st_mode):
                self._enumerate_remote_dir(rp, lp, plan)
            else:
                plan.append((rp, lp, entry.st_size, False))

    def _download_one(
        self, remote_path, local_path, expected_size,
        progress, offset, total, scale,
    ) -> bool:
        """
        Download a single file. Files > LARGE_FILE_THRESHOLD use chunked
        read/write. If the user cancels, a 0-byte placeholder is written.
        """
        local_path.parent.mkdir(parents=True, exist_ok=True)
        use_chunked = expected_size > LARGE_FILE_THRESHOLD
        try:
            if not use_chunked:
                return self._download_small(
                    remote_path, local_path, expected_size,
                    progress, offset, total, scale,
                )
            return self._download_chunked(
                remote_path, local_path, expected_size,
                progress, offset, total, scale,
            )
        except Exception as e:
            self.status_message.emit(
                f"[Error] Failed to download {PurePosixPath(remote_path).name}: {e}\n"
            )
            self._write_placeholder(local_path)
            return False

    def _download_small(
        self, remote_path, local_path, size, progress, offset, total, scale,
    ) -> bool:
        """Fast path using paramiko's `get` (still has a progress callback)."""
        def callback(transferred, _total):
            progress.setValue(int((offset + transferred) / scale))
            QCoreApplication.processEvents()
            return not progress.wasCanceled()

        self.sftp_client.get(remote_path, local_path.as_posix(), callback=callback)

        if progress.wasCanceled():
            self._write_placeholder(local_path)
            self.status_message.emit(
                f"[Canceled] Download canceled: {PurePosixPath(remote_path).name} "
                f"(0-byte placeholder created)\n"
            )
            return False
        self.status_message.emit(f"Downloaded: {PurePosixPath(remote_path).name}\n")
        return True

    def _download_chunked(
        self, remote_path, local_path, size, progress, offset, total, scale,
    ) -> bool:
        """
        Chunked download: reads CHUNK_SIZE bytes at a time, writes to disk, and
        refreshes the GUI at most every PROGRESS_UPDATE_INTERVAL seconds.
        Keeps memory flat and the UI responsive for multi-GB files.
        """
        last_update = 0.0
        transferred = 0
        cancelled = False

        with self.sftp_client.open(remote_path, "rb") as rf, \
             open(local_path, "wb") as lf:
            try:
                rf.seek(0)
            except Exception:
                pass
            while True:
                if progress.wasCanceled():
                    cancelled = True
                    break
                data = rf.read(CHUNK_SIZE)
                if not data:
                    break
                lf.write(data)
                transferred += len(data)

                now = time.time()
                if now - last_update >= PROGRESS_UPDATE_INTERVAL:
                    progress.setValue(int((offset + transferred) / scale))
                    QCoreApplication.processEvents()
                    last_update = now

        progress.setValue(int((offset + transferred) / scale))

        if cancelled:
            self._write_placeholder(local_path)
            self.status_message.emit(
                f"[Canceled] Download canceled at "
                f"{self._format_size(transferred)} / {self._format_size(size)}: "
                f"{PurePosixPath(remote_path).name} (0-byte placeholder created)\n"
            )
            return False
        self.status_message.emit(
            f"Downloaded: {PurePosixPath(remote_path).name} "
            f"({self._format_size(transferred)})\n"
        )
        return True

    @staticmethod
    def _write_placeholder(local_path: Path):
        """Truncate/create a 0-byte file at `local_path`."""
        try:
            local_path.parent.mkdir(parents=True, exist_ok=True)
            with open(local_path, "wb"):
                pass
        except Exception:
            pass

    # -------- upload --------
    def upload_file(self):
        if not self.sftp_client:
            QMessageBox.warning(self, "Warning", "Connect to the cluster first.")
            return
        if self.queue_check.isChecked():
            self.enqueue_upload_files()
            return
        local_files, _ = QFileDialog.getOpenFileNames(
            self, "Select files to upload", "", UPLOAD_FILTER
        )
        if not local_files:
            return

        total_bytes = 0
        for path in local_files:
            try:
                total_bytes += Path(path).stat().st_size
            except OSError:
                pass
        progress, scale = _make_progress(
            self, "Starting upload...", total_bytes, "Batch Upload"
        )
        uploaded_any = self._upload_files_worker(
            local_files, str(self.current_path), progress, scale
        )
        if uploaded_any:
            # Guarantee 100% even if integer division left it short
            progress.setValue(progress.maximum())
            self.refresh()

    def _upload_files_worker(self, local_files, remote_dir, progress, scale) -> bool:
        uploaded_any = False
        accumulated = 0
        for i, local_file in enumerate(local_files):
            if progress.wasCanceled():
                self.status_message.emit(
                    "[Canceled] Batch upload stopped by user.\n"
                )
                break
            filename = Path(local_file).name
            progress.setLabelText(
                f"Uploading file {i+1} of {len(local_files)}: {filename}"
            )
            if self._upload_single_file(
                local_file, progress, accumulated, scale, remote_dir
            ):
                uploaded_any = True
            try:
                accumulated += Path(local_file).stat().st_size
            except OSError:
                pass
            progress.setValue(int(accumulated / scale))
        return uploaded_any

    def _upload_single_file(
        self, local_file, progress, accumulated, scale, remote_dir=None
    ) -> bool:
        try:
            filename = Path(local_file).name
            base = PurePosixPath(remote_dir) if remote_dir else self.current_path
            remote_path = (base / filename).as_posix()
            file_size = Path(local_file).stat().st_size
            self.status_message.emit(
                f"Uploading {filename} ({self._format_size(file_size)})...\n"
            )

            def callback(transferred, _total):
                if progress:
                    progress.setValue(int((accumulated + transferred) / scale))
                    QCoreApplication.processEvents()
                return not (progress and progress.wasCanceled())

            self.sftp_client.put(
                Path(local_file).as_posix(), remote_path, callback=callback
            )
            if progress and progress.wasCanceled():
                self.status_message.emit(f"[Canceled] Upload canceled at: {filename}\n")
                try:
                    self.sftp_client.remove(remote_path)
                except Exception:
                    pass
                return False
            self.status_message.emit(f"Uploaded: {filename}\n")
            return True
        except Exception as e:
            self.status_message.emit(
                f"[Error] Error uploading {Path(local_file).name}: {e}\n"
            )
            return False

    def upload_folder(self):
        if not self.sftp_client:
            QMessageBox.warning(self, "Warning", "Connect to the cluster first.")
            return
        if self.queue_check.isChecked():
            self.enqueue_upload_folder()
            return
        local_dir = QFileDialog.getExistingDirectory(self, "Select Folder to Upload")
        if not local_dir:
            return

        local_dir_path = Path(local_dir)
        folder_name = local_dir_path.name
        all_files = []
        total_bytes = 0
        for root, _dirs, files in os.walk(local_dir):
            for file in files:
                p = Path(root) / file
                all_files.append(p)
                try:
                    total_bytes += p.stat().st_size
                except OSError:
                    pass

        progress, scale = _make_progress(
            self,
            f"Uploading folder {folder_name}...",
            total_bytes,
            "Folder Upload",
        )
        uploaded_any = self._upload_folder_worker(
            str(local_dir_path),
            [str(p) for p in all_files],
            str(self.current_path),
            progress,
            scale,
        )
        if uploaded_any:
            # Guarantee 100% even if integer division left it short
            progress.setValue(progress.maximum())
            self.refresh()
            self.status_message.emit(f"Folder upload complete: {folder_name}\n")

    def _upload_folder_worker(
        self, local_dir, files, remote_dir, progress, scale
    ) -> bool:
        local_dir_path = Path(local_dir)
        folder_name = local_dir_path.name
        base_remote = PurePosixPath(remote_dir) / folder_name
        try:
            self.sftp_client.mkdir(base_remote.as_posix())
            self.status_message.emit(
                f"Created remote folder: {base_remote.name}\n"
            )
        except IOError:
            pass

        accumulated = 0
        uploaded_any = False
        for i, file_path in enumerate(files):
            if progress.wasCanceled():
                self.status_message.emit(
                    "[Canceled] Folder upload stopped by user.\n"
                )
                break
            local_file = Path(file_path)
            try:
                rel = local_file.relative_to(local_dir_path)
                size = local_file.stat().st_size
            except OSError:
                continue
            remote_file = base_remote / PurePosixPath(rel.as_posix())
            self._ensure_remote_dir(remote_file.parent.as_posix())
            progress.setLabelText(
                f"Uploading file {i+1} of {len(files)}: {rel.name}"
            )
            try:
                def callback(transferred, _total):
                    progress.setValue(
                        int((accumulated + transferred) / scale)
                    )
                    QCoreApplication.processEvents()
                    return not progress.wasCanceled()

                self.sftp_client.put(
                    local_file.as_posix(),
                    remote_file.as_posix(),
                    callback=callback,
                )
                uploaded_any = True
            except Exception as e:
                self.status_message.emit(
                    f"[Error] Failed to upload {rel.name}: {e}\n"
                )
            accumulated += size
            progress.setValue(int(accumulated / scale))
        return uploaded_any or not files

    def _ensure_remote_dir(self, remote_dir: str):
        if remote_dir in ("/", "", "."):
            return
        try:
            self.sftp_client.stat(remote_dir)
        except IOError:
            parent = PurePosixPath(remote_dir).parent.as_posix()
            self._ensure_remote_dir(parent)
            try:
                self.sftp_client.mkdir(remote_dir)
            except Exception:
                pass

    # -------- delete --------
    def delete_selected(self):
        if not self.sftp_client:
            QMessageBox.warning(self, "Warning", "Connect to the cluster first.")
            return
        items = self.tree.selectedItems()
        if not items:
            return
        listing = "\n".join([f"  • {i.text(0)}" for i in items])
        reply = QMessageBox.question(
            self, "Confirm Delete",
            f"Delete the following items?\n\n{listing}",
            QMessageBox.Yes | QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return
        for item in items:
            filename = item.data(0, Qt.UserRole)
            remote_path = str(self.current_path / filename)
            try:
                if item.text(2) == "Directory":
                    self._delete_recursive(remote_path)
                    self.status_message.emit(f"Deleted directory: {filename}\n")
                else:
                    self.sftp_client.remove(remote_path)
                    self.status_message.emit(f"Deleted file: {filename}\n")
            except Exception as e:
                self.status_message.emit(
                    f"[Error] Failed to delete {filename}: {e}\n"
                )
        self.refresh()

    def _delete_recursive(self, path: str):
        for entry in self.sftp_client.listdir_attr(path):
            p = str(PurePosixPath(path) / entry.filename)
            if stat.S_ISDIR(entry.st_mode):
                self._delete_recursive(p)
            else:
                self.sftp_client.remove(p)
        self.sftp_client.rmdir(path)

    def create_new_folder(self):
        if not self.sftp_client:
            QMessageBox.warning(self, "Warning", "Connect to the cluster first.")
            return
        name, ok = QInputDialog.getText(self, "New Folder", "Enter folder name:")
        if not ok or not name:
            return
        try:
            self.sftp_client.mkdir(str(self.current_path / name))
            self.status_message.emit(f"Created folder: {name}\n")
            self.refresh()
        except Exception as e:
            self.error_dialog.emit(f"Failed to create folder: {e}")

    # -------- context menu --------
    def _download_compressed_selected(self):
        self.compress_check.setChecked(True)
        self.download_selected()

    def _show_context_menu(self, position):
        if not self.tree.selectedItems():
            return
        menu = QMenu()
        menu.addAction(
            QIcon(QApplication.style().standardIcon(QStyle.SP_ArrowDown)),
            "Download",
            self.download_selected,
        )
        menu.addAction(
            QIcon(QApplication.style().standardIcon(QStyle.SP_ArrowDown)),
            "Download compressed (tar.gz)",
            self._download_compressed_selected,
        )
        menu.addAction(
            QIcon(QApplication.style().standardIcon(QStyle.SP_FileIcon)),
            "Edit in Text Editor",
            self._edit_selected,
        )
        menu.addSeparator()
        menu.addAction(
            QIcon(QApplication.style().standardIcon(QStyle.SP_TrashIcon)),
            "Delete",
            self.delete_selected,
        )
        menu.exec(self.tree.viewport().mapToGlobal(position))