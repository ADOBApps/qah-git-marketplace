"""
Author: Acxel Orozco
Date: 2026-10-21
Last modification: 2026-10-24
Description: Credential manager for SSH user passwords with per-user Fernet keys

This module provides secure credential storage with:
- Per-(host, port, user) Fernet keys stored in a dedicated directory
- Metadata index (JSON) separate from secrets
- Password rotation support
- Collision-safe key filenames (handles special chars in host/user)
- Export / import of credential bundles (zip)
- Backward-compatible migration from legacy {host}_{user}.key files
- Restrictive file permissions (0700 dir, 0600 keys)

This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

QAH is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

import json
import logging
import os
import re
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Optional, List, Dict

from cryptography.fernet import Fernet, InvalidToken


class CredentialManager:
    """
    Manages Fernet keys + metadata for SSH credentials.

    Storage layout:
        <base_dir>/credentials/
            index.json                              # metadata (no secrets)
            <host>__<port>__<user>.key              # Fernet key (0600)
            ...

    The encrypted password token itself lives in the caller's history file
    (e.g. shh_info_history.json), not here. This class only owns the keys.
    """

    # File / dir permission constants (POSIX only; ignored on Windows)
    _DIR_MODE = 0o700
    _FILE_MODE = 0o600

    def __init__(self, base_dir: Path):
        """
        Initialize the credential manager.

        Args:
            base_dir: Parent directory. The manager creates a ``credentials``
                      subdirectory inside it and stores all keys there.
        """
        self.base_dir = Path(base_dir)
        self.creds_dir = self.base_dir / "credentials"
        self.index_file = self.creds_dir / "index.json"

        self._ensure_dir(self.creds_dir)
        self._index: Dict[str, dict] = self._load_index()

    # ------------------------------------------------------------------ #
    # Low-level helpers
    # ------------------------------------------------------------------ #

    @staticmethod
    def _ensure_dir(path: Path) -> None:
        """Create directory with restrictive permissions."""
        path.mkdir(parents=True, exist_ok=True)
        if os.name == "posix":
            try:
                os.chmod(path, CredentialManager._DIR_MODE)
            except OSError as e:
                logging.warning(f"Could not chmod {path}: {e}")

    @staticmethod
    def _set_file_mode(path: Path, mode: int) -> None:
        """Best-effort chmod on POSIX systems."""
        if os.name == "posix":
            try:
                os.chmod(path, mode)
            except OSError as e:
                logging.warning(f"Could not chmod {path}: {e}")

    @staticmethod
    def _slug(host: str, port: int, user: str) -> str:
        """
        Build a filesystem-safe, collision-resistant slug.

        Raw form: ``host__port__user``. Any character outside
        ``[A-Za-z0-9_.-]`` is replaced with ``_``.
        """
        raw = f"{host}__{int(port)}__{user}"
        return re.sub(r"[^A-Za-z0-9_.-]", "_", raw)

    def _key_path(self, host: str, port: int, user: str) -> Path:
        return self.creds_dir / f"{self._slug(host, port, user)}.key"

    # ------------------------------------------------------------------ #
    # Index management
    # ------------------------------------------------------------------ #

    def _load_index(self) -> Dict[str, dict]:
        if not self.index_file.exists():
            return {}
        try:
            data = json.loads(self.index_file.read_text("utf-8"))
            if not isinstance(data, dict):
                logging.error("Credential index is not a dict; starting fresh")
                return {}
            return data
        except Exception as e:
            logging.error(f"Failed to load credential index: {e}")
            return {}

    def _save_index(self) -> None:
        try:
            self.index_file.write_text(
                json.dumps(self._index, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            self._set_file_mode(self.index_file, self._FILE_MODE)
        except Exception as e:
            logging.error(f"Failed to save credential index: {e}")

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #

    def has_credentials(self, host: str, port: int, user: str) -> bool:
        """Return True if a key file exists for this identity."""
        return self._key_path(host, port, user).exists()

    def store(self, host: str, port: int, user: str, password: str) -> str:
        """
        Encrypt ``password`` and persist the key.

        If credentials already exist for this (host, port, user) tuple, the
        key is rotated (new Fernet key generated, old key overwritten) and
        the token is regenerated. Returns the encrypted token, which the
        caller should save in its own history file.

        Args:
            host: SSH hostname or IP.
            port: SSH port.
            user: Login username.
            password: Plaintext password.

        Returns:
            The Fernet-encrypted password token (str).
        """
        port = int(port)
        key = Fernet.generate_key()
        key_path = self._key_path(host, port, user)

        try:
            key_path.write_bytes(key)
            self._set_file_mode(key_path, self._FILE_MODE)
        except Exception as e:
            logging.error(f"Failed to write key file {key_path}: {e}")
            raise

        token = Fernet(key).encrypt(password.encode("utf-8")).decode("utf-8")

        slug = self._slug(host, port, user)
        prev = self._index.get(slug, {})
        now = datetime.now().isoformat()
        self._index[slug] = {
            "host": host,
            "port": port,
            "user": user,
            "key_file": key_path.name,
            "created": prev.get("created", now),
            "rotated": now,
        }
        self._save_index()

        logging.info(f"Stored credentials for {user}@{host}:{port}")
        return token

    def retrieve(
        self, host: str, port: int, user: str, token: str
    ) -> Optional[str]:
        """
        Decrypt ``token`` using the stored key.

        Returns:
            The plaintext password, or None if the key is missing or the
            token cannot be decrypted (e.g. rotated elsewhere).
        """
        port = int(port)
        key_path = self._key_path(host, port, user)

        if not key_path.exists():
            logging.warning(
                f"Missing key file for {user}@{host}:{port} ({key_path.name})"
            )
            return None

        try:
            key = key_path.read_bytes()
            return Fernet(key).decrypt(token.encode("utf-8")).decode("utf-8")
        except InvalidToken:
            logging.error(
                f"Invalid token for {user}@{host}:{port} "
                "(password was re-encrypted with a different key?)"
            )
            return None
        except Exception as e:
            logging.error(f"Decrypt failed for {user}@{host}:{port}: {e}")
            return None

    def rotate(self, host: str, port: int, user: str, new_password: str) -> str:
        """Rotate the key + re-encrypt with a new password. Returns new token."""
        return self.store(host, port, user, new_password)

    def delete(self, host: str, port: int, user: str) -> bool:
        """
        Delete the key file and index entry for this identity.

        Returns True if anything was actually removed.
        """
        port = int(port)
        slug = self._slug(host, port, user)
        key_path = self._key_path(host, port, user)

        removed = False
        if key_path.exists():
            try:
                key_path.unlink()
                removed = True
            except OSError as e:
                logging.error(f"Failed to delete key {key_path}: {e}")

        if slug in self._index:
            del self._index[slug]
            self._save_index()
            removed = True

        if removed:
            logging.info(f"Deleted credentials for {user}@{host}:{port}")
        return removed

    def list_credentials(self) -> List[dict]:
        """Return all known credential metadata (no secrets)."""
        return list(self._index.values())

    def get_credential(self, host: str, port: int, user: str) -> Optional[dict]:
        """Return the metadata entry for a single identity, or None."""
        return self._index.get(self._slug(host, port, user))

    # ------------------------------------------------------------------ #
    # Import / export
    # ------------------------------------------------------------------ #

    def export(self, bundle_path: Path) -> None:
        """
        Export the whole credentials directory (keys + index) as a zip.

        WARNING: The bundle contains the Fernet keys. Treat it like a
        password vault — anyone with the bundle can decrypt every stored
        password.
        """
        bundle_path = Path(bundle_path)
        bundle_path.parent.mkdir(parents=True, exist_ok=True)

        with zipfile.ZipFile(bundle_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in sorted(self.creds_dir.iterdir()):
                if f.is_file():
                    zf.write(f, arcname=f.name)

        self._set_file_mode(bundle_path, self._FILE_MODE)
        logging.info(f"Exported credentials bundle -> {bundle_path}")

    def import_bundle(self, bundle_path: Path, overwrite: bool = False) -> int:
        """
        Import credentials from a zip bundle created by :meth:`export`.

        Args:
            bundle_path: Path to the zip.
            overwrite: If True, existing keys with the same name are
                       replaced. If False, existing keys are preserved.

        Returns:
            Number of entries imported (or merged).
        """
        bundle_path = Path(bundle_path)
        if not bundle_path.exists():
            raise FileNotFoundError(f"Bundle not found: {bundle_path}")

        imported = 0
        with zipfile.ZipFile(bundle_path, "r") as zf:
            for name in zf.namelist():
                # Guard against path traversal
                if "/" in name or "\\" in name or name.startswith(".."):
                    logging.warning(f"Skipping suspicious archive entry: {name}")
                    continue

                target = self.creds_dir / name
                if target.exists() and not overwrite:
                    logging.info(f"Skipping existing file: {name}")
                    continue

                with zf.open(name) as src, open(target, "wb") as dst:
                    dst.write(src.read())
                self._set_file_mode(target, self._FILE_MODE)
                imported += 1

        # Reload index from disk (bundle may have contained an updated one)
        self._index = self._load_index()

        logging.info(f"Imported {imported} file(s) from {bundle_path}")
        return imported

    # ------------------------------------------------------------------ #
    # Legacy migration
    # ------------------------------------------------------------------ #

    def migrate_legacy_keys(self, history_entries: List[dict]) -> int:
        """
        Move legacy ``{host}_{user}.key`` files (stored in the parent of
        ``credentials/``) into the new location, assuming port=22 for any
        entry that predates port support.

        Args:
            history_entries: The list of history dicts (each with at least
                             ``host`` and ``user``; ``port`` optional).

        Returns:
            Number of keys successfully migrated.
        """
        migrated = 0
        for entry in history_entries:
            host = entry.get("host")
            user = entry.get("user")
            if not host or not user:
                continue
            port = int(entry.get("port", 22))

            legacy = self.base_dir / f"{host}_{user}.key"
            target = self._key_path(host, port, user)

            if legacy.exists() and not target.exists():
                try:
                    legacy.rename(target)
                    self._set_file_mode(target, self._FILE_MODE)
                    migrated += 1
                    logging.info(
                        f"Migrated legacy key {legacy.name} -> {target.name}"
                    )
                except OSError as e:
                    logging.error(f"Failed to migrate {legacy}: {e}")

            # Ensure index entry exists even if key already in place
            slug = self._slug(host, port, user)
            if target.exists() and slug not in self._index:
                now = datetime.now().isoformat()
                self._index[slug] = {
                    "host": host,
                    "port": port,
                    "user": user,
                    "key_file": target.name,
                    "created": now,
                    "rotated": now,
                }

        if migrated or self._index:
            self._save_index()

        return migrated