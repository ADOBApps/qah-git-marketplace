"""Remote file browser: tree, navigation, upload/download/edit/delete."""

import os
import re
import shlex
import shutil
import stat
import tarfile
import tempfile
import time
from pathlib import Path, PurePosixPath
from datetime import datetime

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTreeWidget, QTreeWidgetItem, QFileDialog, QMessageBox,
    QHeaderView, QAbstractItemView, QProgressDialog, QMenu,
    QApplication, QStyle, QInputDialog, QCheckBox,
)
from PySide6.QtCore import Qt, Signal, QCoreApplication
from PySide6.QtGui import QFont, QIcon

from .workers import SFTPWorker, SSHWorker, SortableItem


# Tune these if you need different behavior
CHUNK_SIZE = 1024 * 1024                    # 1 MB per read/write
PROGRESS_UPDATE_INTERVAL = 0.10             # seconds between GUI updates
LARGE_FILE_THRESHOLD = 100 * 1024 * 1024    # >100 MB uses chunked mode

# Qt's QProgressDialog is int32-backed; anything larger overflows.
_MAX_INT = 2_147_483_647


def _make_progress(parent, label: str, total_bytes: int, title: str):
    """
    Build a QProgressDialog that survives totals larger than INT32_MAX.

    Returns (dialog, scale) where `scale` = number of real bytes per progress
    unit. The dialog's maximum equals `max(int(total_bytes / scale), 1)`, so
    setting `int(real_bytes / scale)` reaches 100% exactly when all bytes are
    transferred. Callers should still push `progress.maximum()` at the end of
    a batch to guarantee the bar fills even if rounding left it at N-1.
    """
    total = max(int(total_bytes), 1)
    if total <= _MAX_INT:
        scale = 1
    else:
        scale = (total // _MAX_INT) + 1

    progress_max = max(int(total // scale), 1)
    progress = QProgressDialog(label, "Cancel", 0, progress_max, parent)
    progress.setWindowTitle(title)
    progress.setWindowModality(Qt.WindowModal)
    progress.setAutoClose(True)
    progress.setValue(0)
    return progress, scale


class FileBrowser(QWidget):
    file_open_in_editor = Signal(str)   # remote_path
    directory_changed = Signal(str)     # new path
    status_message = Signal(str)        # append to terminal log
    error_dialog = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.sftp_client = None
        self.ssh_client = None
        self.current_path = PurePosixPath("/home")
        self._workers = []
        self._tar_worker = None
        self._tar_progress = None
        self._init_ui()

    # -------- worker tracking --------
    def _track(self, worker):
        self._workers.append(worker)
        worker.finished.connect(lambda: self._untrack(worker))
        worker.error.connect(lambda _msg: self._untrack(worker))
        return worker

    def _untrack(self, worker):
        if worker in self._workers:
            self._workers.remove(worker)

    def cancel_pending(self):
        for w in list(self._workers):
            try:
                if isinstance(w, SFTPWorker):
                    w.cancel()
                w.quit()
                w.wait(2000)
            except Exception:
                pass
        self._workers.clear()

    # -------- UI --------
    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Remote File Browser"))

        nav = QHBoxLayout()
        self.back_btn = QPushButton("Back")
        self.back_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_ArrowBack))
        self.back_btn.clicked.connect(self.go_back)
        self.back_btn.setEnabled(False)

        self.up_btn = QPushButton("Up")
        self.up_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_ArrowUp))
        self.up_btn.clicked.connect(self.go_back)
        self.up_btn.setEnabled(False)

        self.home_btn = QPushButton("Home")
        self.home_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_DirHomeIcon))
        self.home_btn.clicked.connect(self.go_home)
        self.home_btn.setEnabled(False)

        self.refresh_btn = QPushButton("Refresh")
        self.refresh_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_BrowserReload))
        self.refresh_btn.clicked.connect(self.refresh)
        self.refresh_btn.setEnabled(False)

        nav.addWidget(self.back_btn)
        nav.addWidget(self.up_btn)
        nav.addWidget(self.home_btn)
        nav.addWidget(self.refresh_btn)
        nav.addStretch()
        layout.addLayout(nav)

        self.path_label = QLabel(str(self.current_path))
        self.path_label.setFont(QFont("Courier New", 10))
        self.path_label.setStyleSheet("background-color: #f0f0f0; padding: 3px;")
        layout.addWidget(self.path_label)

        self.tree = QTreeWidget()
        self.tree.setSortingEnabled(True)
        self.tree.setSortingEnabled(False)
        self.tree.setHeaderLabels(["Name", "Size", "Type", "Modified"])
        self.tree.header().setSectionResizeMode(QHeaderView.Interactive)
        self.tree.header().setSectionsClickable(True)
        self.tree.header().setSortIndicatorShown(True)
        self.tree.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.tree.itemDoubleClicked.connect(self._on_item_double_clicked)
        self.tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._show_context_menu)
        layout.addWidget(self.tree)

        btns = QHBoxLayout()
        self.new_folder_btn = QPushButton("New Folder")
        self.new_folder_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_FileDialogNewFolder)
        )
        self.new_folder_btn.clicked.connect(self.create_new_folder)
        self.new_folder_btn.setEnabled(False)

        self.upload_folder_btn = QPushButton("Upload Folder")
        self.upload_folder_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_DirIcon)
        )
        self.upload_folder_btn.clicked.connect(self.upload_folder)
        self.upload_folder_btn.setEnabled(False)

        self.upload_file_btn = QPushButton("Upload File")
        self.upload_file_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_ArrowUp)
        )
        self.upload_file_btn.clicked.connect(self.upload_file)
        self.upload_file_btn.setEnabled(False)

        self.download_btn = QPushButton("Download")
        self.download_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_ArrowDown)
        )
        self.download_btn.clicked.connect(self.download_selected)
        self.download_btn.setEnabled(False)

        self.compress_check = QCheckBox("Compress on server (tar.gz)")
        self.compress_check.setChecked(True)
        self.compress_check.setToolTip(
            "Create one tar.gz archive on the cluster, download it, and extract "
            "it locally. Recommended for folders and text/data files; turn it "
            "off for files that are already compressed."
        )
        self.compress_check.setEnabled(False)

        self.edit_btn = QPushButton("Edit in Text Editor")
        self.edit_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_FileIcon)
        )
        self.edit_btn.clicked.connect(self._edit_selected)
        self.edit_btn.setEnabled(False)

        self.delete_btn = QPushButton("Delete")
        self.delete_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_TrashIcon)
        )
        self.delete_btn.clicked.connect(self.delete_selected)
        self.delete_btn.setEnabled(False)

        for b in (self.new_folder_btn, self.upload_folder_btn,
                  self.upload_file_btn, self.download_btn,
                  self.edit_btn, self.delete_btn):
            btns.addWidget(b)
        btns.addWidget(self.compress_check)
        btns.addStretch()
        layout.addLayout(btns)

    # -------- connection API --------
    def set_connected(self, sftp_client, initial_path=None, ssh_client=None):
        self.sftp_client = sftp_client
        self.ssh_client = ssh_client
        if initial_path:
            self.current_path = PurePosixPath(initial_path)
        enabled = sftp_client is not None
        for b in (self.back_btn, self.up_btn, self.home_btn, self.refresh_btn,
                  self.new_folder_btn, self.upload_folder_btn, self.upload_file_btn,
                  self.download_btn, self.edit_btn, self.delete_btn):
            b.setEnabled(enabled)
        self.compress_check.setEnabled(enabled and ssh_client is not None)
        if enabled:
            self.refresh()
        else:
            self.tree.clear()
            self.path_label.setText("Disconnected")

    # -------- listing --------
    def refresh(self):
        if not self.sftp_client:
            return
        for w in list(self._workers):
            if isinstance(w, SFTPWorker) and w.operation == "listdir":
                w.cancel()
        self.tree.clear()
        self.status_message.emit(f"Refreshing file list in: {self.current_path}\n")
        worker = self._track(
            SFTPWorker(self.sftp_client, "listdir", str(self.current_path))
        )
        worker.file_list_ready.connect(self._populate)
        worker.error.connect(self._on_sftp_error)
        worker.start()

    def _populate(self, files):
        self.tree.setSortingEnabled(False)
        self.tree.clear()
        files_sorted = sorted(
            files, key=lambda f: (not stat.S_ISDIR(f.st_mode), f.filename.lower())
        )
        for f in files_sorted:
            is_dir = stat.S_ISDIR(f.st_mode)
            size_str = self._format_size(f.st_size) if not is_dir else ""
            file_type = "Directory" if is_dir else "File"
            modified = (
                datetime.fromtimestamp(f.st_mtime).strftime("%Y-%m-%d %H:%M")
                if f.st_mtime else ""
            )
            item = SortableItem([f.filename, size_str, file_type, modified])
            item.setData(0, Qt.UserRole + 1, f.filename.lower())
            item.setData(1, Qt.UserRole + 1, 0 if is_dir else int(f.st_size))
            item.setData(2, Qt.UserRole + 1, 0 if is_dir else 1)
            item.setData(3, Qt.UserRole + 1, int(f.st_mtime) if f.st_mtime else 0)
            item.setIcon(
                0,
                QApplication.style().standardIcon(
                    QStyle.SP_DirIcon if is_dir else QStyle.SP_FileIcon
                ),
            )
            item.setData(0, Qt.UserRole, f.filename)
            self.tree.addTopLevelItem(item)
        self.tree.setSortingEnabled(True)
        self.path_label.setText(str(self.current_path))

    @staticmethod
    def _format_size(size_bytes):
        for unit in ["B", "KB", "MB", "GB", "TB"]:
            if size_bytes < 1024.0:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.1f} PB"

    def _on_sftp_error(self, msg):
        self.status_message.emit(f"[Error] SFTP Error: {msg}\n")
        self.error_dialog.emit(msg)

    # -------- navigation --------
    def _on_item_double_clicked(self, item, _column):
        filename = item.data(0, Qt.UserRole)
        if item.text(2) == "Directory":
            self._chdir(str(self.current_path / filename))
        else:
            self.status_message.emit(f"File: {filename}\n")

    def _chdir(self, target: str):
        worker = self._track(SFTPWorker(self.sftp_client, "chdir", target))
        worker.finished.connect(self._on_chdir_ok)
        worker.error.connect(self._on_chdir_error)
        worker.start()

    def _on_chdir_ok(self, new_path):
        self.current_path = PurePosixPath(new_path)
        self.directory_changed.emit(new_path)
        self.refresh()
        self.status_message.emit(f"Directory changed to: {new_path}\n")

    def _on_chdir_error(self, msg):
        self.error_dialog.emit(f"Could not change directory:\n{msg}")
        self.status_message.emit(f"[Error] cd error: {msg}\n")

    def go_back(self):
        parent = self.current_path.parent
        if parent and parent != self.current_path:
            self._chdir(str(parent))

    def go_home(self):
        self._chdir("~")

    def change_dir(self, target: str):
        if not target:
            target = "~"
        if target.startswith("~"):
            self._chdir(target)
        elif not PurePosixPath(target).is_absolute():
            self._chdir(str(self.current_path / target))
        else:
            self._chdir(target)

    # -------- file operations --------
    def _edit_selected(self):
        items = self.tree.selectedItems()
        if not items:
            QMessageBox.warning(self, "Warning", "Select a file to edit.")
            return
        item = items[0]
        if item.text(2) == "Directory":
            QMessageBox.warning(self, "Warning", "Cannot edit directories.")
            return
        filename = item.data(0, Qt.UserRole)
        self.file_open_in_editor.emit(str(self.current_path / filename))

    # ==================================================================
    # DOWNLOAD — recursive folders + chunked files + INT32-safe progress
    # ==================================================================
    def download_selected(self):
        if not self.sftp_client:
            QMessageBox.warning(self, "Warning", "Connect to the cluster first.")
            return
        items = self.tree.selectedItems()
        if not items:
            QMessageBox.warning(self, "Warning", "Select files or folders to download.")
            return
        local_dir = QFileDialog.getExistingDirectory(self, "Select download destination")
        if not local_dir:
            return
        dest_root = Path(local_dir)

        if self.compress_check.isChecked():
            if self.ssh_client is None:
                self.status_message.emit(
                    "[Warning] Compressed download needs the SSH command channel; "
                    "using normal download.\n"
                )
            else:
                self._download_compressed(items, dest_root)
                return

        # First pass: enumerate everything so the progress bar has a total
        plan = []   # (remote_path, local_path, size, is_dir)
        for item in items:
            filename = item.data(0, Qt.UserRole)
            remote_path = str(self.current_path / filename)
            if item.text(2) == "Directory":
                self._enumerate_remote_dir(remote_path, dest_root / filename, plan)
            else:
                try:
                    size = self.sftp_client.stat(remote_path).st_size
                except Exception:
                    size = 0
                plan.append((remote_path, dest_root / filename, size, False))

        if not plan:
            self.status_message.emit("[Info] Nothing to download.\n")
            return

        total_bytes = sum(p[2] for p in plan if not p[3])
        file_count = sum(1 for p in plan if not p[3])
        self.status_message.emit(
            f"Downloading {file_count} file(s), total {self._format_size(total_bytes)}\n"
        )

        progress, scale = _make_progress(
            self, "Preparing download...", total_bytes, "Batch Download"
        )

        accumulated = 0
        downloaded_any = False
        for remote_path, local_path, size, is_dir in plan:
            if progress.wasCanceled():
                self.status_message.emit("[Canceled] Batch download stopped by user.\n")
                break
            if is_dir:
                local_path.mkdir(parents=True, exist_ok=True)
                continue

            progress.setLabelText(
                f"Downloading {PurePosixPath(remote_path).name} "
                f"({self._format_size(size)})..."
            )
            ok = self._download_one(
                remote_path, local_path, size,
                progress, accumulated, total_bytes, scale,
            )
            if ok:
                downloaded_any = True
            accumulated += size
            progress.setValue(int(accumulated / scale))

        if downloaded_any:
            # Guarantee 100% even if integer division left it short
            progress.setValue(progress.maximum())
            self.status_message.emit("Download complete.\n")

    # -------- compressed download (tar.gz on cluster) --------
    def _download_compressed(self, items, dest_root: Path):
        """Create one tar.gz on the cluster, download it and extract locally."""
        if not self.sftp_client or not self.ssh_client:
            QMessageBox.warning(self, "Warning", "Connect to the cluster first.")
            return
        if self._tar_worker is not None and self._tar_worker.isRunning():
            QMessageBox.information(
                self, "Busy", "A compressed download is already being prepared."
            )
            return
        names = []
        for item in items:
            name = str(item.data(0, Qt.UserRole) or "")
            if not name or "\n" in name or "\r" in name:
                QMessageBox.warning(self, "Warning", f"Unsupported remote name: {name!r}")
                return
            names.append(name)
        if not names:
            QMessageBox.warning(self, "Warning", "Select files or folders to download.")
            return

        quoted_names = " ".join(shlex.quote(name) for name in names)
        cwd = shlex.quote(str(self.current_path))
        command = (
            'tmp=$(mktemp "${TMPDIR:-/tmp}/qah_ssh_dl_XXXXXX.tar.gz") || exit 1; '
            f'tar -czf "$tmp" -C {cwd} -- {quoted_names} '
            '|| { rm -f "$tmp"; exit 2; }; '
            'printf "\\n__QAH_ARCHIVE__%s\\n" "$tmp"'
        )

        self._tar_output = ""
        self._tar_stderr = ""
        self._tar_dest = dest_root
        self._tar_worker = None

        progress = QProgressDialog(
            "Compressing selected files on the cluster...", "", 0, 0, self
        )
        progress.setWindowTitle("Compressed Download")
        progress.setWindowModality(Qt.WindowModal)
        progress.setCancelButton(None)
        progress.setMinimumDuration(0)
        progress.show()
        QCoreApplication.processEvents()
        self._tar_progress = progress

        worker = self._track(SSHWorker(self.ssh_client, command))
        worker.output.connect(self._on_tar_output)
        worker.error.connect(self._on_tar_error)
        worker.finished.connect(self._on_tar_finished)
        self._tar_worker = worker
        worker.start()

    def _on_tar_output(self, text: str):
        self._tar_output += text

    def _on_tar_error(self, text: str):
        self._tar_stderr += text

    def _on_tar_finished(self):
        progress = getattr(self, "_tar_progress", None)
        if progress is not None:
            progress.close()
        self._tar_progress = None
        output = getattr(self, "_tar_output", "")
        stderr = getattr(self, "_tar_stderr", "")
        marker = "__QAH_ARCHIVE__"
        if marker not in output:
            detail = stderr.strip() or output.strip() or "unknown error"
            self.status_message.emit(
                f"[Error] Compressed download failed on the cluster: {detail}\n"
            )
            QMessageBox.critical(
                self,
                "Compressed download failed",
                "The cluster could not create the tar.gz archive.\n\n"
                f"{detail[-2000:]}\n\n"
                "Check that 'tar' and 'gzip' are available on the cluster, "
                "or disable 'Compress on server' and use a normal download.",
            )
            return

        remote_archive = output.rsplit(marker, 1)[1].strip().splitlines()[0].strip()
        if not remote_archive:
            self.status_message.emit("[Error] Compressed download returned no archive path.\n")
            return

        dest_root = getattr(self, "_tar_dest", Path.home())
        local_root = Path(tempfile.mkdtemp(prefix="qah_ssh_download_"))
        local_archive = local_root / "download.tar.gz"
        try:
            try:
                size = self.sftp_client.stat(remote_archive).st_size
            except Exception:
                size = 0
            self.status_message.emit(
                f"[Info] Cluster archive ready: {remote_archive} "
                f"({self._format_size(size)})\n"
            )
            progress2, scale = _make_progress(
                self,
                "Downloading compressed archive...",
                size,
                "Compressed Download",
            )
            ok = self._download_one(
                remote_archive, local_archive, size, progress2, 0, size, scale
            )
            progress2.setValue(progress2.maximum())
            progress2.close()
            if not ok:
                self.status_message.emit(
                    "[Canceled] Compressed download canceled; remote archive removed.\n"
                )
                return
            try:
                count = self._extract_tar_safe(local_archive, dest_root)
            except Exception as exc:
                self.status_message.emit(
                    f"[Error] Could not extract {remote_archive}: {exc}\n"
                )
                QMessageBox.critical(
                    self,
                    "Extraction failed",
                    f"The archive downloaded but could not be extracted:\n\n{exc}",
                )
                return
            self.status_message.emit(
                f"Compressed download complete: {count} item(s) extracted to "
                f"{dest_root}\n"
            )
        finally:
            try:
                self.sftp_client.remove(remote_archive)
            except Exception:
                self.status_message.emit(
                    f"[Warning] Could not remove remote temp archive: {remote_archive}\n"
                )
            shutil.rmtree(local_root, ignore_errors=True)
            self._tar_worker = None

    def _extract_tar_safe(self, archive_path: Path, dest_root: Path) -> int:
        """Extract a tar.gz without allowing traversal, symlinks or devices."""
        dest = dest_root.resolve()
        dest.mkdir(parents=True, exist_ok=True)
        count = 0
        with tarfile.open(archive_path, "r:gz") as archive:
            for member in archive.getmembers():
                name = member.name.replace("\\", "/")
                path = PurePosixPath(name)
                if not name or name in (".", "./"):
                    continue
                if path.is_absolute() or ".." in path.parts:
                    raise ValueError(f"Unsafe path in archive: {name!r}")
                if member.issym() or member.islnk():
                    self.status_message.emit(
                        f"[Warning] Skipped link in archive: {name}\n"
                    )
                    continue
                target = (dest.joinpath(*path.parts)).resolve()
                if dest not in target.parents and target != dest:
                    raise ValueError(f"Unsafe path in archive: {name!r}")
                if member.isdir():
                    target.mkdir(parents=True, exist_ok=True)
                elif member.isfile():
                    source = archive.extractfile(member)
                    if source is None:
                        continue
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with source, open(target, "wb") as output:
                        shutil.copyfileobj(source, output)
                    count += 1
        return count

    def _enumerate_remote_dir(self, remote_dir, local_dir: Path, plan):
        """Walk a remote dir, appending to `plan` so we know total size upfront."""
        plan.append((remote_dir, local_dir, 0, True))
        try:
            entries = self.sftp_client.listdir_attr(remote_dir)
        except Exception as e:
            self.status_message.emit(
                f"[Error] Could not list {remote_dir}: {e}\n"
            )
            return
        for entry in entries:
            rp = str(PurePosixPath(remote_dir) / entry.filename)
            lp = local_dir / entry.filename
            if stat.S_ISDIR(entry.st_mode):
                self._enumerate_remote_dir(rp, lp, plan)
            else:
                plan.append((rp, lp, entry.st_size, False))

    def _download_one(
        self, remote_path, local_path, expected_size,
        progress, offset, total, scale,
    ) -> bool:
        """
        Download a single file. Files > LARGE_FILE_THRESHOLD use chunked
        read/write. If the user cancels, a 0-byte placeholder is written.
        """
        local_path.parent.mkdir(parents=True, exist_ok=True)
        use_chunked = expected_size > LARGE_FILE_THRESHOLD
        try:
            if not use_chunked:
                return self._download_small(
                    remote_path, local_path, expected_size,
                    progress, offset, total, scale,
                )
            return self._download_chunked(
                remote_path, local_path, expected_size,
                progress, offset, total, scale,
            )
        except Exception as e:
            self.status_message.emit(
                f"[Error] Failed to download {PurePosixPath(remote_path).name}: {e}\n"
            )
            self._write_placeholder(local_path)
            return False

    def _download_small(
        self, remote_path, local_path, size, progress, offset, total, scale,
    ) -> bool:
        """Fast path using paramiko's `get` (still has a progress callback)."""
        def callback(transferred, _total):
            progress.setValue(int((offset + transferred) / scale))
            QCoreApplication.processEvents()
            return not progress.wasCanceled()

        self.sftp_client.get(remote_path, local_path.as_posix(), callback=callback)

        if progress.wasCanceled():
            self._write_placeholder(local_path)
            self.status_message.emit(
                f"[Canceled] Download canceled: {PurePosixPath(remote_path).name} "
                f"(0-byte placeholder created)\n"
            )
            return False
        self.status_message.emit(f"Downloaded: {PurePosixPath(remote_path).name}\n")
        return True

    def _download_chunked(
        self, remote_path, local_path, size, progress, offset, total, scale,
    ) -> bool:
        """
        Chunked download: reads CHUNK_SIZE bytes at a time, writes to disk, and
        refreshes the GUI at most every PROGRESS_UPDATE_INTERVAL seconds.
        Keeps memory flat and the UI responsive for multi-GB files.
        """
        last_update = 0.0
        transferred = 0
        cancelled = False

        with self.sftp_client.open(remote_path, "rb") as rf, \
             open(local_path, "wb") as lf:
            try:
                rf.seek(0)
            except Exception:
                pass
            while True:
                if progress.wasCanceled():
                    cancelled = True
                    break
                data = rf.read(CHUNK_SIZE)
                if not data:
                    break
                lf.write(data)
                transferred += len(data)

                now = time.time()
                if now - last_update >= PROGRESS_UPDATE_INTERVAL:
                    progress.setValue(int((offset + transferred) / scale))
                    QCoreApplication.processEvents()
                    last_update = now

        progress.setValue(int((offset + transferred) / scale))

        if cancelled:
            self._write_placeholder(local_path)
            self.status_message.emit(
                f"[Canceled] Download canceled at "
                f"{self._format_size(transferred)} / {self._format_size(size)}: "
                f"{PurePosixPath(remote_path).name} (0-byte placeholder created)\n"
            )
            return False
        self.status_message.emit(
            f"Downloaded: {PurePosixPath(remote_path).name} "
            f"({self._format_size(transferred)})\n"
        )
        return True

    @staticmethod
    def _write_placeholder(local_path: Path):
        """Truncate/create a 0-byte file at `local_path`."""
        try:
            local_path.parent.mkdir(parents=True, exist_ok=True)
            with open(local_path, "wb"):
                pass
        except Exception:
            pass

    # -------- upload --------
    def upload_file(self):
        if not self.sftp_client:
            QMessageBox.warning(self, "Warning", "Connect to the cluster first.")
            return
        local_files, _ = QFileDialog.getOpenFileNames(
            self, "Select files to upload", "",
            "Any files (*);;"
            "All Files (*.*);;"
            "Quantum Files (*.inp *.orca *.in *.pw);;"
            "VASP Files (INCAR* POSCAR* POTCAR* KPOINTS* CONTCAR* DOSCAR* "
            "EIGENVAL* IBZKPT* OSZICAR* PCDAT*);;"
            "Text Files (*.txt *.py *.sh);;"
            "Data Files (*.dat *.csv *.json)"
        )
        if not local_files:
            return

        total_bytes = sum(Path(f).stat().st_size for f in local_files)
        progress, scale = _make_progress(
            self, "Starting upload...", total_bytes, "Batch Upload"
        )

        uploaded_any = False
        accumulated = 0
        for i, local_file in enumerate(local_files):
            if progress.wasCanceled():
                self.status_message.emit("[Canceled] Batch upload stopped by user.\n")
                break
            filename = Path(local_file).name
            progress.setLabelText(
                f"Uploading file {i+1} of {len(local_files)}:\n{filename}"
            )
            if self._upload_single_file(local_file, progress, accumulated, scale):
                uploaded_any = True
            accumulated += Path(local_file).stat().st_size
            progress.setValue(int(accumulated / scale))

        if uploaded_any:
            # Guarantee 100% even if integer division left it short
            progress.setValue(progress.maximum())
            self.refresh()

    def _upload_single_file(self, local_file, progress, accumulated, scale) -> bool:
        try:
            filename = Path(local_file).name
            remote_path = (PurePosixPath(self.current_path) / filename).as_posix()
            file_size = Path(local_file).stat().st_size
            self.status_message.emit(
                f"Uploading {filename} ({self._format_size(file_size)})...\n"
            )

            def callback(transferred, _total):
                if progress:
                    progress.setValue(int((accumulated + transferred) / scale))
                    QCoreApplication.processEvents()
                return not (progress and progress.wasCanceled())

            self.sftp_client.put(
                Path(local_file).as_posix(), remote_path, callback=callback
            )
            if progress and progress.wasCanceled():
                self.status_message.emit(f"[Canceled] Upload canceled at: {filename}\n")
                try:
                    self.sftp_client.remove(remote_path)
                except Exception:
                    pass
                return False
            self.status_message.emit(f"Uploaded: {filename}\n")
            return True
        except Exception as e:
            self.status_message.emit(
                f"[Error] Error uploading {Path(local_file).name}: {e}\n"
            )
            return False

    def upload_folder(self):
        if not self.sftp_client:
            QMessageBox.warning(self, "Warning", "Connect to the cluster first.")
            return
        local_dir = QFileDialog.getExistingDirectory(self, "Select Folder to Upload")
        if not local_dir:
            return

        local_dir_path = Path(local_dir)
        folder_name = local_dir_path.name
        base_remote = PurePosixPath(self.current_path) / folder_name

        all_files = []
        total_bytes = 0
        for root, _dirs, files in os.walk(local_dir):
            for file in files:
                p = Path(root) / file
                all_files.append(p)
                total_bytes += p.stat().st_size

        progress, scale = _make_progress(
            self,
            f"Uploading folder {folder_name}...",
            total_bytes,
            "Folder Upload",
        )

        accumulated = 0
        try:
            self.sftp_client.mkdir(base_remote.as_posix())
            self.status_message.emit(f"Created remote folder: {base_remote.name}\n")
        except IOError:
            pass

        uploaded_any = False
        for i, local_file in enumerate(all_files):
            if progress.wasCanceled():
                self.status_message.emit("[Canceled] Folder upload stopped by user.\n")
                break
            rel = local_file.relative_to(local_dir_path)
            remote_file = base_remote / PurePosixPath(rel.as_posix())
            self._ensure_remote_dir(remote_file.parent.as_posix())
            progress.setLabelText(
                f"Uploading file {i+1} of {len(all_files)}:\n{rel.name}"
            )
            try:
                def callback(transferred, _total):
                    if progress:
                        progress.setValue(int((accumulated + transferred) / scale))
                        QCoreApplication.processEvents()
                    return not (progress and progress.wasCanceled())

                self.sftp_client.put(
                    local_file.as_posix(), remote_file.as_posix(), callback=callback
                )
                uploaded_any = True
            except Exception as e:
                self.status_message.emit(
                    f"[Error] Failed to upload {rel.name}: {e}\n"
                )
            accumulated += local_file.stat().st_size
            progress.setValue(int(accumulated / scale))

        if uploaded_any:
            # Guarantee 100% even if integer division left it short
            progress.setValue(progress.maximum())
            self.refresh()
            self.status_message.emit(f"Folder upload complete: {folder_name}\n")

    def _ensure_remote_dir(self, remote_dir: str):
        if remote_dir in ("/", "", "."):
            return
        try:
            self.sftp_client.stat(remote_dir)
        except IOError:
            parent = PurePosixPath(remote_dir).parent.as_posix()
            self._ensure_remote_dir(parent)
            try:
                self.sftp_client.mkdir(remote_dir)
            except Exception:
                pass

    # -------- delete --------
    def delete_selected(self):
        if not self.sftp_client:
            QMessageBox.warning(self, "Warning", "Connect to the cluster first.")
            return
        items = self.tree.selectedItems()
        if not items:
            return
        listing = "\n".join([f"  • {i.text(0)}" for i in items])
        reply = QMessageBox.question(
            self, "Confirm Delete",
            f"Delete the following items?\n\n{listing}",
            QMessageBox.Yes | QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return
        for item in items:
            filename = item.data(0, Qt.UserRole)
            remote_path = str(self.current_path / filename)
            try:
                if item.text(2) == "Directory":
                    self._delete_recursive(remote_path)
                    self.status_message.emit(f"Deleted directory: {filename}\n")
                else:
                    self.sftp_client.remove(remote_path)
                    self.status_message.emit(f"Deleted file: {filename}\n")
            except Exception as e:
                self.status_message.emit(
                    f"[Error] Failed to delete {filename}: {e}\n"
                )
        self.refresh()

    def _delete_recursive(self, path: str):
        for entry in self.sftp_client.listdir_attr(path):
            p = str(PurePosixPath(path) / entry.filename)
            if stat.S_ISDIR(entry.st_mode):
                self._delete_recursive(p)
            else:
                self.sftp_client.remove(p)
        self.sftp_client.rmdir(path)

    def create_new_folder(self):
        if not self.sftp_client:
            QMessageBox.warning(self, "Warning", "Connect to the cluster first.")
            return
        name, ok = QInputDialog.getText(self, "New Folder", "Enter folder name:")
        if not ok or not name:
            return
        try:
            self.sftp_client.mkdir(str(self.current_path / name))
            self.status_message.emit(f"Created folder: {name}\n")
            self.refresh()
        except Exception as e:
            self.error_dialog.emit(f"Failed to create folder: {e}")

    # -------- context menu --------
    def _download_compressed_selected(self):
        self.compress_check.setChecked(True)
        self.download_selected()

    def _show_context_menu(self, position):
        if not self.tree.selectedItems():
            return
        menu = QMenu()
        menu.addAction(
            QIcon(QApplication.style().standardIcon(QStyle.SP_ArrowDown)),
            "Download",
            self.download_selected,
        )
        menu.addAction(
            QIcon(QApplication.style().standardIcon(QStyle.SP_ArrowDown)),
            "Download compressed (tar.gz)",
            self._download_compressed_selected,
        )
        menu.addAction(
            QIcon(QApplication.style().standardIcon(QStyle.SP_FileIcon)),
            "Edit in Text Editor",
            self._edit_selected,
        )
        menu.addSeparator()
        menu.addAction(
            QIcon(QApplication.style().standardIcon(QStyle.SP_TrashIcon)),
            "Delete",
            self.delete_selected,
        )
        menu.exec(self.tree.viewport().mapToGlobal(position))