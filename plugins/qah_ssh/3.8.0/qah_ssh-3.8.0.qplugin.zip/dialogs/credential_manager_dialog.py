"""Credential Manager dialog (keys, rotation, export/import)."""

from pathlib import Path

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QTableWidget, QTableWidgetItem, QFileDialog,
    QMessageBox, QInputDialog, QHeaderView, QAbstractItemView,
    QApplication, QStyle,
)
from PySide6.QtCore import Qt

def show_credential_manager_dialog(parent, user_history, on_use=None):
    """Open the credential manager. `on_use(host, port, user, password)`
    is called when the user clicks 'Use in Form'."""
    dialog = QDialog(parent)
    dialog.setWindowTitle("Credential Manager")
    dialog.resize(900, 500)
    layout = QVBoxLayout(dialog)

    # --- search bar ---
    search_row = QHBoxLayout()
    search_row.addWidget(QLabel("Filter:"))
    search_input = QLineEdit()
    search_input.setPlaceholderText("host, port, or user…")
    search_row.addWidget(search_input)
    layout.addLayout(search_row)

    # --- table ---
    table = QTableWidget(0, 6)
    table.setHorizontalHeaderLabels(
        ["Host", "Port", "User", "Key file", "Created", "Last rotated"]
    )
    table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
    table.setSelectionBehavior(QAbstractItemView.SelectRows)
    table.setSelectionMode(QAbstractItemView.SingleSelection)
    table.setEditTriggers(QAbstractItemView.NoEditTriggers)
    table.setSortingEnabled(True)
    layout.addWidget(table)

    # --- buttons ---
    bar = QHBoxLayout()
    use_btn = QPushButton("Use in Form")
    use_btn.setIcon(
        QApplication.style().standardIcon(QStyle.SP_DialogApplyButton)
    )
    rotate_btn = QPushButton("Rotate Password…")
    rotate_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_BrowserReload))
    delete_btn = QPushButton("Delete")
    delete_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_TrashIcon))
    export_btn = QPushButton("Export Bundle…")
    export_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_DialogSaveButton))
    import_btn = QPushButton("Import Bundle…")
    import_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_DialogOpenButton))
    close_btn = QPushButton("Close")

    for b in (use_btn, rotate_btn, delete_btn, export_btn, import_btn):
        bar.addWidget(b)
    bar.addStretch()
    bar.addWidget(close_btn)
    layout.addLayout(bar)

    status_label = QLabel("")
    status_label.setStyleSheet("color: #555; padding: 3px;")
    layout.addWidget(status_label)

    def refresh():
        table.setSortingEnabled(False)
        table.setRowCount(0)
        search = search_input.text().strip().lower()
        for e in user_history.creds.list_credentials():
            row_text = " ".join(
                str(e.get(k, "")) for k in ("host", "port", "user")
            ).lower()
            if search and search not in row_text:
                continue
            row = table.rowCount()
            table.insertRow(row)
            for col, key in enumerate(
                ["host", "port", "user", "key_file", "created", "rotated"]
            ):
                item = QTableWidgetItem(str(e.get(key, "")))
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                table.setItem(row, col, item)
        table.setSortingEnabled(True)
        status_label.setText(f"{table.rowCount()} credential(s)")

    def selected_entry():
        rows = table.selectionModel().selectedRows()
        if not rows:
            return None
        r = rows[0].row()
        return {
            "host": table.item(r, 0).text(),
            "port": int(table.item(r, 1).text() or 22),
            "user": table.item(r, 2).text(),
        }

    def on_use_clicked():
        sel = selected_entry()
        if not sel:
            status_label.setText("Select a row first.")
            return
        ssh_info = user_history.get_decrypted_shh_info(
            user_history.get_shh_info(sel["host"], sel["port"], sel["user"])
        )
        if on_use:
            on_use(
                ssh_info.get("host", ""),
                ssh_info.get("port", 22),
                ssh_info.get("user", ""),
                ssh_info.get("password", ""),
            )
        dialog.accept()

    def on_rotate():
        sel = selected_entry()
        if not sel:
            status_label.setText("Select a row first.")
            return
        new_pwd, ok = QInputDialog.getText(
            dialog, "Rotate Password",
            f"New password for {sel['user']}@{sel['host']}:{sel['port']}:",
            QLineEdit.Password,
        )
        if ok and new_pwd:
            try:
                user_history.add_shh_info(
                    sel["host"], sel["port"], sel["user"], new_pwd
                )
                status_label.setText(
                    f"Rotated: {sel['user']}@{sel['host']}:{sel['port']}"
                )
                refresh()
            except Exception as e:
                QMessageBox.critical(dialog, "Rotate failed", str(e))

    def on_delete():
        sel = selected_entry()
        if not sel:
            status_label.setText("Select a row first.")
            return
        if QMessageBox.question(
            dialog, "Confirm Delete",
            f"Delete saved credentials for "
            f"{sel['user']}@{sel['host']}:{sel['port']}?\n\n"
            "This removes the history entry AND its encryption key. "
            "The password cannot be recovered.",
            QMessageBox.Yes | QMessageBox.No,
        ) == QMessageBox.Yes:
            try:
                user_history.delete_entry(
                    sel["host"], sel["port"], sel["user"]
                )
                status_label.setText(
                    f"Deleted: {sel['user']}@{sel['host']}:{sel['port']}"
                )
                refresh()
            except Exception as e:
                QMessageBox.critical(dialog, "Delete failed", str(e))

    def on_export():
        path, _ = QFileDialog.getSaveFileName(
            dialog, "Export credentials bundle",
            "qah_credentials.zip", "Zip archives (*.zip)",
        )
        if not path:
            return
        try:
            user_history.creds.export(Path(path))
            status_label.setText(f"Exported → {path}")
            QMessageBox.information(
                dialog, "Exported",
                f"Bundle saved to:\n{path}\n\n"
                "Treat this file like a password vault — it contains "
                "the encryption keys.",
            )
        except Exception as e:
            QMessageBox.critical(dialog, "Export failed", str(e))

    def on_import():
        path, _ = QFileDialog.getOpenFileName(
            dialog, "Import credentials bundle", "", "Zip archives (*.zip)"
        )
        if not path:
            return
        try:
            n = user_history.creds.import_bundle(Path(path), overwrite=False)
            user_history.load_history()
            refresh()
            status_label.setText(f"Imported {n} file(s)")
            QMessageBox.information(
                dialog, "Imported", f"Imported {n} file(s) from:\n{path}"
            )
        except Exception as e:
            QMessageBox.critical(dialog, "Import failed", str(e))

    search_input.textChanged.connect(refresh)
    use_btn.clicked.connect(on_use_clicked)
    rotate_btn.clicked.connect(on_rotate)
    delete_btn.clicked.connect(on_delete)
    export_btn.clicked.connect(on_export)
    import_btn.clicked.connect(on_import)
    close_btn.clicked.connect(dialog.accept)

    refresh()
    dialog.exec()