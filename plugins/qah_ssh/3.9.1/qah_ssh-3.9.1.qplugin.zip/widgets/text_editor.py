import tempfile
from pathlib import Path, PurePosixPath
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QTextEdit, QMessageBox,
    QApplication, QStyle, QToolBar, QStatusBar
)
from PySide6.QtGui import QFont, QAction, QIcon, QKeySequence
from PySide6.QtCore import Signal

class SimpleTextEditor(QWidget):
    """Simplified text editor for the SSH plugin"""
    
    # Signals for communication with parent
    upload_requested = Signal(str, str)  # (local_temp_path, remote_path)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.current_file = None
        self.temp_path = None
        self.remote_path = None
        self.main_window = None  # Reference to the main SSH window
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # Toolbar
        toolbar = QToolBar()
        
        self.file_label = QLabel("No file open")
        self.file_label.setStyleSheet("""
            QLabel {
                padding: 4px;
                font-weight: bold;
                color: #2196F3;
            }
        """)
        toolbar.addWidget(self.file_label)
        
        toolbar.addSeparator()
        
        # Save actions
        self.save_action = QAction(QIcon(), "Save", self)
        self.save_action.setIcon(QApplication.style().standardIcon(QStyle.SP_DialogSaveButton))
        self.save_action.setShortcut(QKeySequence("Ctrl+S"))
        self.save_action.triggered.connect(self.save_file)
        self.save_action.setEnabled(False)
        toolbar.addAction(self.save_action)
        
        self.save_back_action = QAction(QIcon(), "Save && Upload", self)
        self.save_back_action.setIcon(QApplication.style().standardIcon(QStyle.SP_ArrowUp))
        self.save_back_action.setShortcut(QKeySequence("Ctrl+Shift+S"))
        self.save_back_action.triggered.connect(self.save_and_upload)
        self.save_back_action.setEnabled(False)
        toolbar.addAction(self.save_back_action)
        
        toolbar.addSeparator()
        
        # Edit actions
        undo_action = QAction(QIcon(), "Undo", self)
        undo_action.setIcon(QApplication.style().standardIcon(QStyle.SP_ArrowBack))
        undo_action.setShortcut(QKeySequence("Ctrl+Z"))
        undo_action.triggered.connect(self.undo)
        toolbar.addAction(undo_action)
        
        redo_action = QAction(QIcon(), "Redo", self)
        redo_action.setIcon(QApplication.style().standardIcon(QStyle.SP_ArrowForward))
        redo_action.setShortcut(QKeySequence("Ctrl+Y"))
        redo_action.triggered.connect(self.redo)
        toolbar.addAction(redo_action)
        
        layout.addWidget(toolbar)
        
        # Text editor
        self.text_edit = QTextEdit()
        self.text_edit.setFont(QFont("Consolas", 11))
        self.text_edit.textChanged.connect(self.on_text_changed)
        self.text_edit.cursorPositionChanged.connect(self._update_position_label)
        layout.addWidget(self.text_edit)
        
        # Status bar
        self.status_bar = QStatusBar()
        layout.addWidget(self.status_bar)
    
    def set_main_window(self, main_window):
        """Set reference to the main SSH window"""
        self.main_window = main_window
    
    def load_file(self, content: str, filename: str, remote_path: str = None):
        """Load content into editor"""
        self.text_edit.setPlainText(content)
        self.current_file = filename
        self.remote_path = remote_path
        
        if remote_path:
            display_path = PurePosixPath(remote_path).parent
            self.file_label.setText(f"Editing: {filename} (from: {display_path})")
        else:
            self.file_label.setText(f"Editing: {filename}")
        
        self.save_action.setEnabled(False)
        self.save_back_action.setEnabled(False)
        self.status_bar.showMessage(f"Loaded {len(content)} characters")
    
    def load_temp_file(self, temp_path: Path, remote_path: str = None):
        """Load temporary file"""
        try:
            # Try different encodings
            for encoding in ['utf-8', 'latin-1', 'cp1252']:
                try:
                    content = temp_path.read_text(encoding=encoding)
                    break
                except UnicodeDecodeError:
                    continue
            else:
                # If all encodings fail, use binary mode with replacement
                content = temp_path.read_bytes().decode('utf-8', errors='replace')
            
            self.temp_path = temp_path
            self.remote_path = remote_path
            self.load_file(content, temp_path.name, remote_path)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load file: {e}")
    
    def save_file(self):
        """Save to temporary file"""
        if not self.temp_path:
            temp_dir = Path.home() / "QAH" / "plugin_files" / "QAH_SSH" / "temp"
            temp_dir.mkdir(parents=True, exist_ok=True)
            self.temp_path = Path(tempfile.mktemp(suffix=".txt", dir=str(temp_dir)))
        
        try:
            content = self.text_edit.toPlainText()
            self.temp_path.write_text(content, encoding='utf-8')
            self.save_action.setEnabled(False)
            self.status_bar.showMessage(f"Saved to: {self.temp_path.name}")
            return True
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save: {e}")
            return False
    
    def save_and_upload(self):
        """Save and upload to server"""
        # First save the file locally
        if not self.save_file():
            return
        
        # Check if we have a remote path to upload to
        if not self.remote_path:
            QMessageBox.warning(self, "Warning", 
                              "No remote path associated with this file.\n"
                              "Cannot upload to server.")
            return
        
        # Check if we have a connection to the server via main window
        if not self.main_window or not self.main_window.sftp_client:
            QMessageBox.warning(self, "Warning", 
                              "Not connected to server.\n"
                              "Please connect to the cluster first.")
            return
        
        # Confirm upload with user
        reply = QMessageBox.question(
            self, "Confirm Upload",
            f"Upload '{self.current_file}' to server?\n"
            f"Destination: {self.remote_path}\n\n"
            "This will overwrite the original file on the server.",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            # Emit signal for upload (or call main window method directly)
            if hasattr(self.main_window, 'upload_edited_file'):
                self.main_window.upload_edited_file(self.temp_path, self.remote_path)
            else:
                # Alternative: emit signal
                self.upload_requested.emit(str(self.temp_path), self.remote_path)
    
    def get_content(self) -> str:
        """Get current content"""
        return self.text_edit.toPlainText()
    
    def undo(self):
        self.text_edit.undo()
    
    def redo(self):
        self.text_edit.redo()
    
    def on_text_changed(self):
        self.save_action.setEnabled(True)
        self.save_back_action.setEnabled(True)
        self._update_position_label()

    def _update_position_label(self):
        cursor = self.text_edit.textCursor()
        line = cursor.blockNumber() + 1
        col = cursor.columnNumber() + 1
        total_lines = self.text_edit.document().blockCount()
        total_chars = len(self.text_edit.toPlainText())
        self.status_bar.showMessage(
            f"Ln {line}, Col {col}   |   {total_lines} lines, {total_chars} chars"
        )