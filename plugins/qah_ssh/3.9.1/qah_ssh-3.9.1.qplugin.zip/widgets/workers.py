"""QThread workers used by the SSH plugin (SSH command, SFTP ops, sortable tree items)."""

from pathlib import PurePosixPath

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import QTreeWidgetItem


class SSHWorker(QThread):
    output = Signal(str)
    error = Signal(str)
    finished = Signal()

    def __init__(self, client, command):
        super().__init__()
        self.client = client
        self.command = command

    def run(self):
        try:
            _stdin, stdout, stderr = self.client.exec_command(self.command)
            out = stdout.read().decode("utf-8", errors="replace")
            err = stderr.read().decode("utf-8", errors="replace")
            try:
                self.output.emit(out)
                if err.strip():
                    self.error.emit(err)
            except RuntimeError:
                pass
        except Exception as e:
            try:
                self.error.emit(f"SSH Error: {e}")
            except RuntimeError:
                pass
        finally:
            try:
                self.finished.emit()
            except RuntimeError:
                pass


class SFTPWorker(QThread):
    finished = Signal(str)
    error = Signal(str)
    file_list_ready = Signal(list)
    file_content_ready = Signal(str, str, str)

    def __init__(self, sftp_client, operation, path=None, remote_path=None):
        super().__init__()
        self.sftp_client = sftp_client
        self.operation = operation
        self.path = path
        self.remote_path = remote_path
        self._cancelled = False

    def cancel(self):
        self._cancelled = True

    def run(self):
        try:
            if self._cancelled:
                return
            if self.operation == "chdir":
                self.sftp_client.chdir(self.path)
                self._safe_emit(self.finished, self.path)
            elif self.operation == "listdir":
                files = self.sftp_client.listdir_attr(self.path)
                self._safe_emit(self.file_list_ready, files)
            elif self.operation == "readfile":
                if self.remote_path:
                    with self.sftp_client.open(self.remote_path, "rb") as f:
                        data = f.read()
                    try:
                        content = data.decode("utf-8")
                    except UnicodeDecodeError:
                        try:
                            content = data.decode("latin-1")
                        except UnicodeDecodeError:
                            content = data.decode("utf-8", errors="replace")
                    filename = PurePosixPath(self.remote_path).name
                    self._safe_emit(
                        self.file_content_ready, filename, content, self.remote_path
                    )
        except Exception as e:
            self._safe_emit(self.error, str(e))

    @staticmethod
    def _safe_emit(signal, *args):
        try:
            signal.emit(*args)
        except RuntimeError:
            pass


class SortableItem(QTreeWidgetItem):
    """Sort by typed Qt.UserRole+1 values instead of display text."""

    def __lt__(self, other):
        col = self.treeWidget().sortColumn() if self.treeWidget() else 0
        a = self.data(col, Qt.UserRole + 1)
        b = other.data(col, Qt.UserRole + 1) if other else None
        if a is None or b is None:
            return super().__lt__(other)
        try:
            return a < b
        except TypeError:
            return str(a) < str(b)