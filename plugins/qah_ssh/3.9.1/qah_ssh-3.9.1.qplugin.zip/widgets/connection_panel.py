"""SSH connection form + status bar. Emits connect_requested / disconnect_requested."""

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QGridLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QGroupBox,
    QApplication, QStyle, QToolButton,
)
from PySide6.QtCore import Signal

from ..controllers.recent_users import SSHInfoInputEventFilter


class ConnectionPanel(QWidget):
    connect_requested = Signal(str, int, str, str)   # host, port, user, password
    disconnect_requested = Signal()
    user_history_requested = Signal()
    credential_manager_requested = Signal()

    def __init__(self, user_history, parent=None):
        super().__init__(parent)
        self.user_history = user_history
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(5)

        group = QGroupBox("SSH Connection")
        g = QGridLayout()

        g.addWidget(QLabel("Host:"), 0, 0)
        self.host_input = QLineEdit()
        self.host_input.setPlaceholderText("cluster.example.com")
        g.addWidget(self.host_input, 0, 1)

        g.addWidget(QLabel("Username:"), 1, 0)
        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("your_username")
        g.addWidget(self.username_input, 1, 1)

        g.addWidget(QLabel("Password:"), 2, 0)
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        g.addWidget(self.password_input, 2, 1)

        g.addWidget(QLabel("Port:"), 3, 0)
        self.port_input = QLineEdit("22")
        g.addWidget(self.port_input, 3, 1)

        self.host_event_filter = SSHInfoInputEventFilter(
            self.host_input,
            self.port_input,
            self.username_input,
            self.password_input,
            self.user_history,
        )
        self.host_input.installEventFilter(self.host_event_filter)

        self.connect_btn = QPushButton("Connect")
        self.connect_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_DialogOkButton)
        )
        self.connect_btn.setStyleSheet("background-color: #4CAF50; color: white;")
        self.connect_btn.clicked.connect(self._on_connect)

        self.disconnect_btn = QPushButton("Disconnect")
        self.disconnect_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_DialogCancelButton)
        )
        self.disconnect_btn.setEnabled(False)
        self.disconnect_btn.setStyleSheet("background-color: #f44336; color: white;")
        self.disconnect_btn.clicked.connect(self.disconnect_requested)

        self.history_user_btn = QToolButton()
        self.history_user_btn.setToolTip("User History")
        self.history_user_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_FileDialogDetailedView)
        )
        self.history_user_btn.clicked.connect(self.user_history_requested)

        self.cred_manager_btn = QToolButton()
        self.cred_manager_btn.setToolTip("Credential Manager")
        self.cred_manager_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_DriveHDIcon)
        )
        self.cred_manager_btn.clicked.connect(self.credential_manager_requested)

        btn_row = QHBoxLayout()
        btn_row.addWidget(self.connect_btn)
        btn_row.addWidget(self.disconnect_btn)
        btn_row.addWidget(self.history_user_btn)
        btn_row.addWidget(self.cred_manager_btn)
        g.addLayout(btn_row, 4, 0, 1, 2)

        group.setLayout(g)
        layout.addWidget(group)

        self.status_bar = QLabel("Ready to connect")
        self.status_bar.setStyleSheet("""
            QLabel {
                background-color: #333;
                color: #fff;
                padding: 5px;
                border-radius: 3px;
                font-weight: bold;
            }
        """)
        layout.addWidget(self.status_bar)

    def _on_connect(self):
        host = self.host_input.text().strip()
        user = self.username_input.text().strip()
        password = self.password_input.text()
        try:
            port = int(self.port_input.text() or "22")
        except ValueError:
            port = 22
        self.connect_requested.emit(host, port, user, password)

    # -- external API --
    def set_status(self, text: str):
        self.status_bar.setText(text)

    def set_connected(self, connected: bool):
        for w in (self.host_input, self.username_input,
                  self.password_input, self.port_input):
            w.setEnabled(not connected)
        self.connect_btn.setEnabled(not connected)
        self.disconnect_btn.setEnabled(connected)
        self.history_user_btn.setEnabled(not connected)
        self.cred_manager_btn.setEnabled(not connected)

    def fill_form(self, host: str, port: int, user: str, password: str):
        self.host_input.setText(host)
        self.port_input.setText(str(port))
        self.username_input.setText(user)
        self.password_input.setText(password)

    def current_inputs(self):
        return (
            self.host_input.text().strip(),
            int(self.port_input.text() or "22"),
            self.username_input.text().strip(),
            self.password_input.text(),
        )