"""Temp-files tab: list, refresh, open, delete, upload."""

from pathlib import Path

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QListWidget, QListWidgetItem, QMessageBox, QApplication, QStyle,
)
from PySide6.QtCore import Qt, Signal


class TempFilesPanel(QWidget):
    open_in_editor = Signal(str, str)      # temp_path, remote_path
    upload_requested = Signal(str, str)    # temp_path, remote_path
    temp_changed = Signal()

    def __init__(self, temp_manager, parent=None):
        super().__init__(parent)
        self.temp_manager = temp_manager
        self.sftp_client = None
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Temporary Files (downloaded for editing)"))

        toolbar = QHBoxLayout()
        self.refresh_btn = QPushButton("Refresh")
        self.refresh_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_BrowserReload)
        )
        self.refresh_btn.clicked.connect(self.refresh)
        self.refresh_btn.setEnabled(False)

        self.open_btn = QPushButton("Open in Editor")
        self.open_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_FileIcon))
        self.open_btn.clicked.connect(self._open_selected)
        self.open_btn.setEnabled(False)

        self.delete_btn = QPushButton("Delete")
        self.delete_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_TrashIcon)
        )
        self.delete_btn.clicked.connect(self._delete_selected)
        self.delete_btn.setEnabled(False)

        self.upload_btn = QPushButton("Upload to Server")
        self.upload_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_ArrowUp)
        )
        self.upload_btn.clicked.connect(self._upload_selected)
        self.upload_btn.setEnabled(False)

        for b in (self.refresh_btn, self.open_btn, self.delete_btn, self.upload_btn):
            toolbar.addWidget(b)
        toolbar.addStretch()
        layout.addLayout(toolbar)

        self.list = QListWidget()
        self.list.itemSelectionChanged.connect(self._on_selection)
        self.list.itemDoubleClicked.connect(lambda _item: self._open_selected())
        layout.addWidget(self.list)

        self.info = QLabel("")
        self.info.setStyleSheet(
            "padding: 5px; background-color: #f0f0f0; border-radius: 3px;"
        )
        layout.addWidget(self.info)

    def set_connected(self, sftp_client):
        self.sftp_client = sftp_client
        for b in (self.refresh_btn, self.open_btn, self.delete_btn, self.upload_btn):
            b.setEnabled(sftp_client is not None)
        if sftp_client:
            self.refresh()

    def refresh(self):
        self.list.clear()
        entries = self.temp_manager.get_temp_files()
        for info in entries:
            item = QListWidgetItem(f"{info['filename']} - {info['remote_path']}")
            item.setData(Qt.UserRole, info)
            self.list.addItem(item)
        self.info.setText(
            "No temporary files" if not entries
            else f"{len(entries)} temporary file(s)"
        )

    def _on_selection(self):
        selected = bool(self.list.selectedItems())
        self.open_btn.setEnabled(selected and self.sftp_client is not None)
        self.delete_btn.setEnabled(selected and self.sftp_client is not None)
        self.upload_btn.setEnabled(selected and self.sftp_client is not None)
        if selected:
            info = self.list.selectedItems()[0].data(Qt.UserRole)
            self.info.setText(
                f"File: {info['filename']}\n"
                f"Remote: {info['remote_path']}\n"
                f"Created: {info['created'].strftime('%Y-%m-%d %H:%M:%S')}"
            )

    def _find_temp_path(self, remote_path: str):
        for path_str, data in self.temp_manager.temp_files.items():
            if data["remote_path"] == remote_path:
                return Path(path_str)
        return None

    def _open_selected(self):
        items = self.list.selectedItems()
        if not items:
            return
        info = items[0].data(Qt.UserRole)
        temp_path = self._find_temp_path(info["remote_path"])
        if temp_path and temp_path.exists():
            self.open_in_editor.emit(str(temp_path), info["remote_path"])
        else:
            QMessageBox.warning(
                self, "Warning",
                "Temporary file not found. It may have been deleted."
            )
            self.refresh()

    def _delete_selected(self):
        items = self.list.selectedItems()
        if not items:
            return
        info = items[0].data(Qt.UserRole)
        reply = QMessageBox.question(
            self, "Confirm Delete",
            f"Delete temporary file '{info['filename']}'?\n"
            "This will not affect the original file on the server.",
            QMessageBox.Yes | QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return
        for path_str in list(self.temp_manager.temp_files.keys()):
            data = self.temp_manager.temp_files[path_str]
            if data["remote_path"] == info["remote_path"]:
                p = Path(path_str)
                if p.exists():
                    p.unlink()
                del self.temp_manager.temp_files[path_str]
                break
        self.refresh()

    def _upload_selected(self):
        if not self.sftp_client:
            QMessageBox.warning(self, "Warning", "Connect to the cluster first.")
            return
        items = self.list.selectedItems()
        if not items:
            return
        info = items[0].data(Qt.UserRole)
        temp_path = self._find_temp_path(info["remote_path"])
        if not temp_path or not temp_path.exists():
            QMessageBox.warning(self, "Warning", "Temporary file not found.")
            return
        reply = QMessageBox.question(
            self, "Confirm Upload",
            f"Upload '{info['filename']}' back to server?\n"
            f"Destination: {info['remote_path']}\n\n"
            "This will overwrite the original file on the server.",
            QMessageBox.Yes | QMessageBox.No,
        )
        if reply == QMessageBox.Yes:
            self.upload_requested.emit(str(temp_path), info["remote_path"])