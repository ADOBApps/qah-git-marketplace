"""
Author: Acxel Orozco
Date: 2026-05-04
Last modification: 2026-10-24
Description: User history manager for SSH terminal with JSON storage + credential keys

This module provides:
- SSHInfoHistory: last-users history (host, port, user, encrypted password token)
- CredentialManager: per-(host, port, user) Fernet key storage + rotation + import/export
- SSHInfoInputEventFilter: up/down arrow navigation across saved users

This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

QAH is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

import json
import logging
import os
import re
import zipfile
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Dict

from cryptography.fernet import Fernet, InvalidToken
from PySide6.QtCore import Qt, QObject


# ====================================================================== #
#  CredentialManager — owns the Fernet keys                              #
# ====================================================================== #

class CredentialManager:
    """
    Manages Fernet keys + metadata for SSH credentials.

    Storage layout:
        <base_dir>/credentials/
            index.json                              # metadata (no secrets)
            <host>__<port>__<user>.key              # Fernet key (0600)
    """

    _DIR_MODE = 0o700
    _FILE_MODE = 0o600

    def __init__(self, base_dir: Path):
        self.base_dir = Path(base_dir)
        self.creds_dir = self.base_dir / "credentials"
        self.index_file = self.creds_dir / "index.json"

        self._ensure_dir(self.creds_dir)
        self._index: Dict[str, dict] = self._load_index()

    # ------------------------------------------------------------------ #
    # Low-level helpers
    # ------------------------------------------------------------------ #

    @staticmethod
    def _ensure_dir(path: Path) -> None:
        path.mkdir(parents=True, exist_ok=True)
        if os.name == "posix":
            try:
                os.chmod(path, CredentialManager._DIR_MODE)
            except OSError as e:
                logging.warning(f"Could not chmod {path}: {e}")

    @staticmethod
    def _set_file_mode(path: Path, mode: int) -> None:
        if os.name == "posix":
            try:
                os.chmod(path, mode)
            except OSError as e:
                logging.warning(f"Could not chmod {path}: {e}")

    @staticmethod
    def _slug(host: str, port: int, user: str) -> str:
        raw = f"{host}__{int(port)}__{user}"
        return re.sub(r"[^A-Za-z0-9_.-]", "_", raw)

    def _key_path(self, host: str, port: int, user: str) -> Path:
        return self.creds_dir / f"{self._slug(host, port, user)}.key"

    # ------------------------------------------------------------------ #
    # Index management
    # ------------------------------------------------------------------ #

    def _load_index(self) -> Dict[str, dict]:
        if not self.index_file.exists():
            return {}
        try:
            data = json.loads(self.index_file.read_text("utf-8"))
            return data if isinstance(data, dict) else {}
        except Exception as e:
            logging.error(f"Failed to load credential index: {e}")
            return {}

    def _save_index(self) -> None:
        try:
            self.index_file.write_text(
                json.dumps(self._index, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            self._set_file_mode(self.index_file, self._FILE_MODE)
        except Exception as e:
            logging.error(f"Failed to save credential index: {e}")

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #

    def has_credentials(self, host: str, port: int, user: str) -> bool:
        return self._key_path(host, port, user).exists()

    def store(self, host: str, port: int, user: str, password: str) -> str:
        """Encrypt password, (re)writing the key. Rotates if exists."""
        port = int(port)
        key = Fernet.generate_key()
        key_path = self._key_path(host, port, user)

        key_path.write_bytes(key)
        self._set_file_mode(key_path, self._FILE_MODE)

        token = Fernet(key).encrypt(password.encode("utf-8")).decode("utf-8")

        slug = self._slug(host, port, user)
        prev = self._index.get(slug, {})
        now = datetime.now().isoformat()
        self._index[slug] = {
            "host": host,
            "port": port,
            "user": user,
            "key_file": key_path.name,
            "token": token,
            "created": prev.get("created", now),
            "rotated": now,
        }
        self._save_index()
        logging.info(f"Stored credentials for {user}@{host}:{port}")
        return token

    def retrieve(
        self, host: str, port: int, user: str, token: str
    ) -> Optional[str]:
        port = int(port)
        key_path = self._key_path(host, port, user)
        if not key_path.exists():
            logging.warning(
                f"Missing key file for {user}@{host}:{port} ({key_path.name})"
            )
            return None
        try:
            key = key_path.read_bytes()
            return Fernet(key).decrypt(token.encode("utf-8")).decode("utf-8")
        except InvalidToken:
            logging.error(
                f"Invalid token for {user}@{host}:{port} "
                "(password was re-encrypted with a different key?)"
            )
            return None
        except Exception as e:
            logging.error(f"Decrypt failed for {user}@{host}:{port}: {e}")
            return None

    def rotate(self, host: str, port: int, user: str, new_password: str) -> str:
        return self.store(host, port, user, new_password)

    def delete(self, host: str, port: int, user: str) -> bool:
        port = int(port)
        slug = self._slug(host, port, user)
        key_path = self._key_path(host, port, user)

        removed = False
        if key_path.exists():
            try:
                key_path.unlink()
                removed = True
            except OSError as e:
                logging.error(f"Failed to delete key {key_path}: {e}")

        if slug in self._index:
            del self._index[slug]
            self._save_index()
            removed = True

        if removed:
            logging.info(f"Deleted credentials for {user}@{host}:{port}")
        return removed

    def list_credentials(self) -> List[dict]:
        return list(self._index.values())

    def get_credential(self, host: str, port: int, user: str) -> Optional[dict]:
        return self._index.get(self._slug(host, port, user))

    def retrieve_for_identity(self, host: str, port: int, user: str) -> str:
        """Decrypt the password from the index itself (history-independent)."""
        entry = self.get_credential(host, port, user)
        if not entry:
            return ""
        token = str(entry.get("token", "") or "")
        if not token:
            return ""
        return self.retrieve(host, port, user, token) or ""

    def set_token(self, host: str, port: int, user: str, token: str) -> None:
        if not token:
            return
        slug = self._slug(host, port, user)
        entry = self._index.get(slug)
        if entry is not None and not entry.get("token"):
            entry["token"] = token
            self._save_index()

    def backfill_tokens(self, history_entries: List[dict]) -> int:
        """Copy tokens from legacy history entries into the credential index."""
        count = 0
        for entry in history_entries:
            host = entry.get("host")
            user = entry.get("user")
            token = entry.get("password")
            if not host or not user or not token:
                continue
            slug = self._slug(host, int(entry.get("port", 22)), user)
            item = self._index.get(slug)
            if item is not None and not item.get("token"):
                item["token"] = token
                count += 1
        if count:
            self._save_index()
        return count

    # ------------------------------------------------------------------ #
    # Import / export
    # ------------------------------------------------------------------ #

    def export(self, bundle_path: Path) -> None:
        bundle_path = Path(bundle_path)
        bundle_path.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(bundle_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in sorted(self.creds_dir.iterdir()):
                if f.is_file():
                    zf.write(f, arcname=f.name)
        self._set_file_mode(bundle_path, self._FILE_MODE)
        logging.info(f"Exported credentials bundle -> {bundle_path}")

    def import_bundle(self, bundle_path: Path, overwrite: bool = False) -> int:
        bundle_path = Path(bundle_path)
        if not bundle_path.exists():
            raise FileNotFoundError(f"Bundle not found: {bundle_path}")

        imported = 0
        with zipfile.ZipFile(bundle_path, "r") as zf:
            for name in zf.namelist():
                if "/" in name or "\\" in name or name.startswith(".."):
                    logging.warning(f"Skipping suspicious archive entry: {name}")
                    continue
                target = self.creds_dir / name
                if target.exists() and not overwrite:
                    logging.info(f"Skipping existing file: {name}")
                    continue
                with zf.open(name) as src, open(target, "wb") as dst:
                    dst.write(src.read())
                self._set_file_mode(target, self._FILE_MODE)
                imported += 1

        self._index = self._load_index()
        logging.info(f"Imported {imported} file(s) from {bundle_path}")
        return imported

    # ------------------------------------------------------------------ #
    # Legacy migration
    # ------------------------------------------------------------------ #

    def migrate_legacy_keys(self, history_entries: List[dict]) -> int:
        """Move legacy {host}_{user}.key files into the new layout."""
        migrated = 0
        for entry in history_entries:
            host = entry.get("host")
            user = entry.get("user")
            if not host or not user:
                continue
            port = int(entry.get("port", 22))

            legacy = self.base_dir / f"{host}_{user}.key"
            target = self._key_path(host, port, user)

            if legacy.exists() and not target.exists():
                try:
                    legacy.rename(target)
                    self._set_file_mode(target, self._FILE_MODE)
                    migrated += 1
                except OSError as e:
                    logging.error(f"Failed to migrate {legacy}: {e}")

            slug = self._slug(host, port, user)
            if target.exists() and slug not in self._index:
                now = datetime.now().isoformat()
                self._index[slug] = {
                    "host": host,
                    "port": port,
                    "user": user,
                    "key_file": target.name,
                    "created": now,
                    "rotated": now,
                }

        if migrated or self._index:
            self._save_index()
        return migrated


# ====================================================================== #
#  SSHInfoHistory — user history + credential access                     #
# ====================================================================== #

class SSHInfoHistory:
    """Manages SSH user history (host, port, user, encrypted password token)."""

    def __init__(self, temp_dir: Path, max_history: int = 100):
        self.temp_dir = Path(temp_dir)
        self.max_history = max_history
        self.history_file = self.temp_dir / "shh_info_history.json"

        self.creds = CredentialManager(self.temp_dir)

        self.shh_info: List[dict] = []
        self.current_index: int = -1
        self.current_input: str = ""

        # Load, migrate, save if changed
        self.load_history()
        if self._migrate_legacy_entries():
            self.save_history()
        self.creds.migrate_legacy_keys(self.shh_info)
        self.creds.backfill_tokens(self.shh_info)

    # ------------------------------------------------------------------ #
    # Persistence
    # ------------------------------------------------------------------ #

    def load_history(self):
        """Load user history from JSON file."""
        self.shh_info = []
        try:
            if self.history_file.exists():
                with open(self.history_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.shh_info = data.get("shh_info", [])
                    if len(self.shh_info) > self.max_history:
                        self.shh_info = self.shh_info[-self.max_history:]
                    logging.info(
                        f"Loaded {len(self.shh_info)} ssh_info entries from history"
                    )
        except Exception as e:
            logging.error(f"Failed to load ssh_info history: {e}")
            self.shh_info = []

    def save_history(self):
        """Save user history to JSON file."""
        try:
            self.temp_dir.mkdir(parents=True, exist_ok=True)
            with open(self.history_file, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "shh_info": self.shh_info,
                        "last_updated": datetime.now().isoformat(),
                        "max_history": self.max_history,
                    },
                    f,
                    indent=2,
                    ensure_ascii=False,
                )
            logging.info(f"Saved {len(self.shh_info)} ssh_info entries to history")
        except Exception as e:
            logging.error(f"Failed to save ssh_info history: {e}")

    def _migrate_legacy_entries(self) -> bool:
        """Ensure every entry has a 'port' field. Returns True if changed."""
        changed = False
        for entry in self.shh_info:
            if "port" not in entry:
                entry["port"] = 22
                changed = True
        return changed

    # ------------------------------------------------------------------ #
    # Lookups
    # ------------------------------------------------------------------ #

    def get_shh_info(self, host: str, port: int, user: str) -> Optional[dict]:
        for d in self.shh_info:
            if (
                d.get("host") == host
                and int(d.get("port", 22)) == int(port)
                and d.get("user") == user
            ):
                return d
        return None

    def get_shh_info_by_host(
        self, host: str, port: Optional[int] = None
    ) -> Optional[dict]:
        for d in self.shh_info:
            if d.get("host") == host and (
                port is None or int(d.get("port", 22)) == int(port)
            ):
                return d
        return None

    def get_decrypted_shh_info(self, shh_info: Optional[dict]) -> dict:
        """Return {host, port, user, password} with password decrypted (or '')."""
        if not shh_info:
            return {"host": "", "port": 22, "user": "", "password": ""}

        host = shh_info["host"]
        port = int(shh_info.get("port", 22))
        user = shh_info["user"]

        pwd = self.creds.retrieve(host, port, user, shh_info.get("password", ""))
        if pwd is None:
            logging.warning(
                f"Could not decrypt password for {user}@{host}:{port} — "
                "user must re-enter it"
            )
            pwd = ""
        return {"host": host, "port": port, "user": user, "password": pwd}

    def get_decrypted_credential(self, host: str, port: int, user: str) -> dict:
        """Look up a credential directly, even without a history entry.

        Newer credential index entries store the encrypted token alongside the
        key. This makes the Credential Manager work when the history JSON was
        deleted or belongs to another installation.
        """
        entry = self.get_shh_info(host, port, user)
        if entry is not None:
            info = self.get_decrypted_shh_info(entry)
            if info.get("password"):
                return info
        password = self.creds.retrieve_for_identity(host, port, user)
        return {"host": host, "port": int(port), "user": user, "password": password}

    # ------------------------------------------------------------------ #
    # Add / delete
    # ------------------------------------------------------------------ #

    def add_shh_info(self, host: str, port: int, user: str, password: str):
        """Add or update a user entry (rotates the key if it already exists)."""
        if not host or not host.strip():
            return
        port = int(port)

        token = self.creds.store(host, port, user, password)
        existing = self.get_shh_info(host, port, user)

        if existing is not None:
            existing["password"] = token
            self.save_history()
            self.reset_navigation()
            return

        self.shh_info.append(
            {"host": host, "port": port, "user": user, "password": token}
        )
        if len(self.shh_info) > self.max_history:
            self.shh_info = self.shh_info[-self.max_history:]
        self.save_history()
        self.reset_navigation()

    def delete_entry(self, host: str, port: int, user: str):
        """Remove a single saved user (and its key)."""
        port = int(port)
        self.shh_info = [
            d
            for d in self.shh_info
            if not (
                d.get("host") == host
                and int(d.get("port", 22)) == port
                and d.get("user") == user
            )
        ]
        self.creds.delete(host, port, user)
        self.save_history()
        self.reset_navigation()

    def clear_history(self):
        """Clear all history entries and their keys."""
        for entry in list(self.shh_info):
            self.creds.delete(
                entry["host"], int(entry.get("port", 22)), entry["user"]
            )
        self.shh_info = []
        self.reset_navigation()
        self.save_history()
        logging.info("ssh_info history cleared")

    # ------------------------------------------------------------------ #
    # Navigation (up/down arrows)
    # ------------------------------------------------------------------ #

    def get_previous_shh_info(self, current_input: str = "") -> Optional[dict]:
        if not self.shh_info:
            return None
        if self.current_index == -1:
            self.current_input = current_input
            self.current_index = len(self.shh_info) - 1
        elif self.current_index > 0:
            self.current_index -= 1
        else:
            return self.get_decrypted_shh_info(self.shh_info[0])

        return self.get_decrypted_shh_info(self.shh_info[self.current_index])

    def get_next_shh_info(self) -> Optional[dict]:
        if not self.shh_info or self.current_index == -1:
            return None
        if self.current_index < len(self.shh_info) - 1:
            self.current_index += 1
            return self.get_decrypted_shh_info(self.shh_info[self.current_index])

        original = self.current_input
        self.reset_navigation()
        # Return the saved "original input" host so the form can restore it.
        return (
            {"host": original, "port": 22, "user": "", "password": ""}
            if original
            else None
        )

    def reset_navigation(self):
        self.current_index = -1
        self.current_input = ""

    # ------------------------------------------------------------------ #
    # Misc
    # ------------------------------------------------------------------ #

    def get_all_shh_info(self) -> List[dict]:
        return self.shh_info.copy()

    def search_shh_info(self, search_term: str) -> List[str]:
        """Return host list (for the legacy user-history dialog)."""
        results = []
        term = (search_term or "").lower()
        for d in self.shh_info:
            if not term:
                results.append(d.get("host", ""))
                continue
            haystack = " ".join(
                str(d.get(k, "")) for k in ("host", "port", "user")
            ).lower()
            if term in haystack:
                results.append(d.get("host", ""))
        return results

    def get_stats(self) -> dict:
        return {
            "total_shh_info": len(self.shh_info),
            "max_history": self.max_history,
            "file_path": str(self.history_file),
            "file_exists": self.history_file.exists(),
            "credentials": len(self.creds.list_credentials()),
        }


# ====================================================================== #
#  Event filter for up/down arrow navigation                             #
# ====================================================================== #

class SSHInfoInputEventFilter(QObject):
    """Up/Down arrow navigation across saved SSH users (host, port, user, pwd)."""

    def __init__(
        self,
        ssh_hots_input,
        ssh_port_input,
        ssh_username_input,
        ssh_password_input,
        shh_info_history,
    ):
        super().__init__()
        self.ssh_hots_input = ssh_hots_input
        self.ssh_port_input = ssh_port_input
        self.ssh_username_input = ssh_username_input
        self.ssh_password_input = ssh_password_input
        self.shh_info_history = shh_info_history

    def _apply(self, info: Optional[dict]):
        if not info:
            return
        self.ssh_hots_input.setText(info.get("host", ""))
        self.ssh_port_input.setText(str(info.get("port", 22)))
        self.ssh_username_input.setText(info.get("user", ""))
        self.ssh_password_input.setText(info.get("password", ""))

    def eventFilter(self, obj, event):
        if event.type() == event.Type.KeyPress:
            if event.key() == Qt.Key_Up:
                self._apply(
                    self.shh_info_history.get_previous_shh_info(
                        self.ssh_hots_input.text()
                    )
                )
                return True
            elif event.key() == Qt.Key_Down:
                self._apply(self.shh_info_history.get_next_shh_info())
                return True
        return False