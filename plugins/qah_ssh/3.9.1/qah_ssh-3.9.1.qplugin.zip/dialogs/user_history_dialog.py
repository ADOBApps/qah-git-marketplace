"""User history dialog (simple host list)."""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QListWidget, QDialogButtonBox, QMessageBox,
)


def show_user_history_dialog(parent, user_history, on_pick_user=None):
    dialog = QDialog(parent)
    dialog.setWindowTitle("Users History")
    layout = QVBoxLayout(dialog)

    search_row = QHBoxLayout()
    search_row.addWidget(QLabel("Search:"))
    search_input = QLineEdit()
    search_input.setPlaceholderText("Filter users...")
    search_row.addWidget(search_input)
    layout.addLayout(search_row)

    user_list = QListWidget()
    layout.addWidget(user_list)

    buttons = QDialogButtonBox()
    clear_btn = QPushButton("Clear History")
    close_btn = QPushButton("Close")
    buttons.addButton(clear_btn, QDialogButtonBox.ActionRole)
    buttons.addButton(close_btn, QDialogButtonBox.AcceptRole)
    layout.addWidget(buttons)

    def refresh_list():
        user_list.clear()
        for host in reversed(user_history.search_shh_info(search_input.text())):
            user_list.addItem(host)

    def on_clear():
        if QMessageBox.question(
            dialog, "Confirm Clear", "Clear all user history?",
            QMessageBox.Yes | QMessageBox.No,
        ) == QMessageBox.Yes:
            user_history.clear_history()
            refresh_list()

    def on_item(item):
        host = item.text()
        ssh_info = user_history.get_decrypted_shh_info(
            user_history.get_shh_info_by_host(host)
        )
        if on_pick_user:
            on_pick_user(ssh_info)
        dialog.accept()

    search_input.textChanged.connect(refresh_list)
    clear_btn.clicked.connect(on_clear)
    close_btn.clicked.connect(dialog.accept)
    user_list.itemDoubleClicked.connect(on_item)

    refresh_list()
    dialog.exec()