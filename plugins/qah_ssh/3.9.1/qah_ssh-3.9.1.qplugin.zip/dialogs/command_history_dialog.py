"""Command history manager dialog."""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QListWidget, QDialogButtonBox, QMessageBox,
)


def show_command_history_dialog(parent, command_history, on_pick_command=None):
    dialog = QDialog(parent)
    dialog.setWindowTitle("Command History")
    layout = QVBoxLayout(dialog)

    search_row = QHBoxLayout()
    search_row.addWidget(QLabel("Search:"))
    search_input = QLineEdit()
    search_input.setPlaceholderText("Filter commands...")
    search_row.addWidget(search_input)
    layout.addLayout(search_row)

    command_list = QListWidget()
    layout.addWidget(command_list)

    buttons = QDialogButtonBox()
    clear_btn = QPushButton("Clear History")
    close_btn = QPushButton("Close")
    buttons.addButton(clear_btn, QDialogButtonBox.ActionRole)
    buttons.addButton(close_btn, QDialogButtonBox.AcceptRole)
    layout.addWidget(buttons)

    def refresh_list():
        command_list.clear()
        for cmd in reversed(command_history.search_commands(search_input.text())):
            command_list.addItem(cmd)

    def on_clear():
        if QMessageBox.question(
            dialog, "Confirm Clear", "Clear all command history?",
            QMessageBox.Yes | QMessageBox.No,
        ) == QMessageBox.Yes:
            command_history.clear_history()
            refresh_list()

    def on_item(item):
        if on_pick_command:
            on_pick_command(item.text())
        dialog.accept()

    search_input.textChanged.connect(refresh_list)
    clear_btn.clicked.connect(on_clear)
    close_btn.clicked.connect(dialog.accept)
    command_list.itemDoubleClicked.connect(on_item)

    refresh_list()
    dialog.exec()