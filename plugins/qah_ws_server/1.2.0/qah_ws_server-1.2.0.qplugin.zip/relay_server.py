# qah_ws_server/relay_server.py
"""Standalone QAH WS rendezvous relay.

Run this on a small VPS or any machine with a public TCP port:

    python relay_server.py --host 0.0.0.0 --port 45901

The relay pairs a QAH WS Server room with QAH WS Clients and then copies raw
bytes. It does not terminate TLS and cannot read commands or output; the QAH
TLS certificate and the application AES-GCM layer remain end-to-end.

Protocol (one JSON line before the byte pipe):

    server -> relay: {"role":"server","room":"...","token":"...","slots":1}
    relay  -> server: {"ok":true}
    client -> relay: {"role":"client","room":"...","token":"..."}
    relay  -> client: {"ok":true}

After the client receives {"ok":true}, both sides start TLS immediately.
"""

from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import re
import select
import socket
import threading
import time
from typing import Dict, List, Optional, Tuple


ROOM_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
MAX_HANDSHAKE = 65536
MAX_WAITING_PER_ROOM = 8
BUFFER_SIZE = 65536


def _now() -> float:
    return time.time()


def _stamp() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _token_hash(token: str) -> bytes:
    return hashlib.sha256(token.encode("utf-8")).digest()


def _recv_line(conn: socket.socket, max_bytes: int = MAX_HANDSHAKE) -> bytes:
    data = bytearray()
    while True:
        chunk = conn.recv(1)
        if not chunk:
            raise ConnectionError("connection closed during handshake")
        data.extend(chunk)
        if chunk == b"\n":
            return bytes(data)
        if len(data) > max_bytes:
            raise ValueError("handshake line too long")


def _send_line(conn: socket.socket, payload: dict) -> None:
    body = json.dumps(payload, separators=(",", ":")).encode("utf-8") + b"\n"
    conn.sendall(body)


def _send_error(conn: socket.socket, message: str) -> None:
    try:
        _send_line(conn, {"ok": False, "error": message})
    except OSError:
        pass


def _socket_alive(conn: socket.socket) -> bool:
    try:
        readable, _, _ = select.select([conn], [], [], 0)
        if not readable:
            return True
        data = conn.recv(1, socket.MSG_PEEK)
        return bool(data)
    except (OSError, ValueError):
        return False


class _Room:
    def __init__(self, token_hash: bytes):
        self.token_hash = token_hash
        self.waiting: List[Tuple[socket.socket, tuple]] = []
        self.created = _now()
        self.last_seen = _now()


class RelayServer:
    """TCP rendezvous relay with one or more server slots per room."""

    def __init__(
        self,
        host: str = "0.0.0.0",
        port: int = 45901,
        *,
        max_rooms: int = 512,
        room_ttl: int = 3600,
        verbose: bool = True,
    ):
        self.host = host
        self.port = int(port)
        self.max_rooms = max(1, int(max_rooms))
        self.room_ttl = max(60, int(room_ttl))
        self.verbose = verbose
        self._rooms: Dict[str, _Room] = {}
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._server: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None
        self._cleaner: Optional[threading.Thread] = None

    # -- lifecycle ------------------------------------------------------
    def start(self) -> int:
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((self.host, self.port))
        server.listen(64)
        server.settimeout(0.5)
        self._server = server
        self.port = int(server.getsockname()[1])
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._accept_loop, daemon=True
        )
        self._thread.start()
        self._cleaner = threading.Thread(
            target=self._cleanup_loop, daemon=True
        )
        self._cleaner.start()
        self._log(f"Relay listening on {self.host}:{self.port}")
        return self.port

    def stop(self) -> None:
        self._stop.set()
        if self._server is not None:
            try:
                self._server.close()
            except OSError:
                pass
            self._server = None
        with self._lock:
            waiting = [
                conn
                for room in self._rooms.values()
                for conn, _addr in room.waiting
            ]
            self._rooms.clear()
        for conn in waiting:
            try:
                conn.close()
            except OSError:
                pass
        if self._thread is not None:
            self._thread.join(timeout=2)
            self._thread = None
        if self._cleaner is not None:
            self._cleaner.join(timeout=2)
            self._cleaner = None
        self._log("Relay stopped.")

    def serve_forever(self) -> None:
        try:
            while not self._stop.is_set():
                self._stop.wait(0.5)
        except KeyboardInterrupt:
            self.stop()

    # -- logging --------------------------------------------------------
    def _log(self, text: str) -> None:
        if self.verbose:
            print(f"[{_stamp()}] {text}", flush=True)

    # -- accept / handshake ---------------------------------------------
    def _accept_loop(self) -> None:
        server = self._server
        if server is None:
            return
        while not self._stop.is_set():
            try:
                conn, address = server.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            threading.Thread(
                target=self._handle, args=(conn, address), daemon=True
            ).start()

    def _handle(self, conn: socket.socket, address: tuple) -> None:
        handed_off = False
        try:
            conn.settimeout(30)
            raw = _recv_line(conn)
            message = json.loads(raw.decode("utf-8"))
            if not isinstance(message, dict):
                raise ValueError("handshake is not an object")
            role = str(message.get("role", ""))
            room_id = str(message.get("room", ""))
            token = str(message.get("token", ""))
            if not ROOM_RE.fullmatch(room_id):
                _send_error(conn, "invalid room id")
                return
            if not token:
                _send_error(conn, "missing room token")
                return
            if role == "server":
                handed_off = self._register(conn, room_id, token, address)
            elif role == "client":
                handed_off = self._join(conn, room_id, token, address)
            else:
                _send_error(conn, "role must be server or client")
        except Exception as exc:
            self._log(f"Handshake from {address[0]} failed: {exc}")
            if not handed_off:
                _send_error(conn, "relay handshake failed")
        finally:
            if not handed_off:
                try:
                    conn.close()
                except OSError:
                    pass

    def _register(
        self, conn: socket.socket, room_id: str, token: str, address: tuple
    ) -> bool:
        token_digest = _token_hash(token)
        with self._lock:
            room = self._rooms.get(room_id)
            if room is None:
                if len(self._rooms) >= self.max_rooms:
                    _send_error(conn, "relay is full")
                    return False
                room = _Room(token_digest)
                self._rooms[room_id] = room
            if not hmac.compare_digest(room.token_hash, token_digest):
                _send_error(conn, "invalid room token")
                return False
            if len(room.waiting) >= MAX_WAITING_PER_ROOM:
                _send_error(conn, "too many waiting server slots")
                return False
            room.waiting.append((conn, address))
            room.last_seen = _now()
        conn.settimeout(None)
        _send_line(conn, {"ok": True, "room": room_id})
        self._log(
            f"Server slot registered for room {room_id} from {address[0]} "
            f"({len(room.waiting)} waiting)"
        )
        return True

    def _join(
        self, conn: socket.socket, room_id: str, token: str, address: tuple
    ) -> bool:
        token_digest = _token_hash(token)
        with self._lock:
            room = self._rooms.get(room_id)
            if room is None:
                _send_error(conn, "room not found or server offline")
                return False
            if not hmac.compare_digest(room.token_hash, token_digest):
                _send_error(conn, "invalid room token")
                return False
            server_socket = None
            server_address = None
            while room.waiting:
                candidate, candidate_address = room.waiting.pop(0)
                if _socket_alive(candidate):
                    server_socket = candidate
                    server_address = candidate_address
                    break
                try:
                    candidate.close()
                except OSError:
                    pass
            if server_socket is None:
                _send_error(conn, "no server slot available")
                return False
            room.last_seen = _now()
            if not room.waiting:
                self._rooms.pop(room_id, None)
        try:
            conn.settimeout(None)
            _send_line(conn, {"ok": True, "room": room_id})
        except OSError:
            try:
                server_socket.close()
            except OSError:
                pass
            return False
        self._log(
            f"Paired room {room_id}: client {address[0]} <-> "
            f"server {server_address[0] if server_address else '?'}"
        )
        self._start_pipe(server_socket, conn)
        return True

    # -- byte pipe ------------------------------------------------------
    def _start_pipe(self, left: socket.socket, right: socket.socket) -> None:
        closed = threading.Event()

        def close_both() -> None:
            if closed.is_set():
                return
            closed.set()
            for sock in (left, right):
                try:
                    sock.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
                try:
                    sock.close()
                except OSError:
                    pass

        def pump(src: socket.socket, dst: socket.socket) -> None:
            try:
                while not self._stop.is_set():
                    data = src.recv(BUFFER_SIZE)
                    if not data:
                        self._log("Relay pipe: EOF; closing both sides")
                        break
                    dst.sendall(data)
            except OSError as exc:
                if not closed.is_set():
                    self._log(f"Relay pipe stopped: {exc}")
            finally:
                close_both()

        threading.Thread(
            target=pump, args=(left, right), daemon=True
        ).start()
        threading.Thread(
            target=pump, args=(right, left), daemon=True
        ).start()

    # -- cleanup --------------------------------------------------------
    def _cleanup_loop(self) -> None:
        while not self._stop.wait(30):
            now = _now()
            with self._lock:
                for room_id, room in list(self._rooms.items()):
                    room.waiting = [
                        (conn, addr)
                        for conn, addr in room.waiting
                        if _socket_alive(conn)
                    ]
                    if not room.waiting and now - room.last_seen > self.room_ttl:
                        self._rooms.pop(room_id, None)
                        self._log(f"Expired empty room {room_id}")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="QAH WS rendezvous relay (raw TCP, TLS stays end-to-end)"
    )
    parser.add_argument("--host", default="0.0.0.0", help="bind address")
    parser.add_argument("--port", type=int, default=45901, help="bind port")
    parser.add_argument(
        "--max-rooms", type=int, default=512, help="maximum waiting rooms"
    )
    parser.add_argument(
        "--room-ttl",
        type=int,
        default=3600,
        help="seconds before an empty room is removed",
    )
    parser.add_argument("--quiet", action="store_true", help="less logging")
    args = parser.parse_args()

    relay = RelayServer(
        args.host,
        args.port,
        max_rooms=args.max_rooms,
        room_ttl=args.room_ttl,
        verbose=not args.quiet,
    )
    relay.start()
    print(
        "QAH WS relay is running. Point QAH WS Server -> Relay at:\n"
        f"  {args.host}:{relay.port}\n"
        "Keep TCP port open in the firewall. Press Ctrl+C to stop.",
        flush=True,
    )
    try:
        relay.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        relay.stop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
