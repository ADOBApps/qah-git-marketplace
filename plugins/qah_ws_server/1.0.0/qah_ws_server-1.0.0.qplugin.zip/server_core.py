# qah_ws_server/server_core.py
"""Author: Acxel Orozco
QAH WS Server - encrypted remote command console (server side).

The server only starts when the operator clicks Start. Paired clients send
encrypted commands over WSS; output is streamed back. Auto-approve is either
timed (armed by the operator) or permanent (requires the server password on
every client session). Destructive commands always require confirmation.
"""

from __future__ import annotations

import base64
import json
import os
import platform
import re
import subprocess
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

try:
    from . import ws_common
except ImportError:  # standalone plugin loading
    try:
        import ws_common  # type: ignore
    except ImportError:
        import importlib.util
        import sys

        _path = Path(__file__).with_name("ws_common.py")
        _spec = importlib.util.spec_from_file_location("qah_ws_common", _path)
        if _spec is None or _spec.loader is None:
            raise ImportError(f"Could not load {_path}")
        _module = importlib.util.module_from_spec(_spec)
        sys.modules[_spec.name] = _module
        _spec.loader.exec_module(_module)
        ws_common = _module

ws = ws_common


def qah_home() -> Path:
    override = os.environ.get("QAH_HOME")
    return Path(override).expanduser() if override else Path.home() / "QAH"


def default_root() -> Path:
    override = os.environ.get("QAH_WS_SERVER_HOME")
    return Path(override).expanduser() if override else qah_home() / "qah_ws_server"


@dataclass
class ServerSettings:
    server_id: str = ""
    server_name: str = ""
    bind_host: str = "0.0.0.0"
    port: int = ws.DEFAULT_PORT
    public_host: str = ""
    auto_mode: str = "off"  # off | timed | permanent
    timed_until: int = 0
    password_salt: str = ""
    password_hash: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "server_id": self.server_id,
            "server_name": self.server_name,
            "bind_host": self.bind_host,
            "port": int(self.port),
            "public_host": self.public_host,
            "auto_mode": self.auto_mode,
            "timed_until": int(self.timed_until),
            "password_salt": self.password_salt,
            "password_hash": self.password_hash,
        }

    @classmethod
    def from_dict(cls, data: Optional[Dict[str, Any]]) -> "ServerSettings":
        data = dict(data or {})
        return cls(
            server_id=str(data.get("server_id", "")),
            server_name=str(data.get("server_name", "")),
            bind_host=str(data.get("bind_host", "0.0.0.0")) or "0.0.0.0",
            port=int(data.get("port", ws.DEFAULT_PORT) or ws.DEFAULT_PORT),
            public_host=str(data.get("public_host", "")).strip(),
            auto_mode=str(data.get("auto_mode", "off")),
            timed_until=int(data.get("timed_until", 0) or 0),
            password_salt=str(data.get("password_salt", "")),
            password_hash=str(data.get("password_hash", "")),
        )


@dataclass
class ConnectionState:
    connection: ws.WSConnection
    address: tuple
    client_id: str = ""
    client_name: str = ""
    session_key: bytes = b""
    unlocked: bool = False
    processes: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    seen_ids: set = field(default_factory=set)


class CommandServer:
    """WSS command server with pairing, policies, streaming and audit."""

    def __init__(
        self,
        root: Optional[os.PathLike | str] = None,
        *,
        settings: Optional[ServerSettings] = None,
    ):
        self.root = Path(root).expanduser() if root else default_root()
        self.root.mkdir(parents=True, exist_ok=True)
        self.settings_path = self.root / "settings.json"
        self.clients_path = self.root / "clients.json"
        self.pending_path = self.root / "pending.json"
        self.audit_path = self.root / "audit.jsonl"
        self.cert_path = self.root / "cert.pem"
        self.key_path = self.root / "key.pem"

        self.settings = settings or ServerSettings.from_dict(
            ws.read_json(self.settings_path, {})
        )
        if not self.settings.server_id:
            self.settings.server_id = ws.new_id()
        if not self.settings.server_name:
            self.settings.server_name = platform.node() or "QAH WS Server"
        if self.settings.auto_mode == "timed" and self.settings.timed_until <= ws.now():
            self.settings.auto_mode = "off"
            self.settings.timed_until = 0
        self.save_settings()

        self.clients: Dict[str, Dict[str, Any]] = ws.read_json(self.clients_path, {})
        self.pending: List[Dict[str, Any]] = ws.read_json(self.pending_path, [])
        self.fingerprint = ws.ensure_certificate(self.cert_path, self.key_path)
        self._lock = threading.RLock()
        self._server: Optional[ws.WebSocketServer] = None
        self._states: List[ConnectionState] = []
        self._stop = threading.Event()

        self.on_log: Optional[Callable[[str], None]] = None
        self.on_clients: Optional[Callable[[List[Dict[str, Any]]], None]] = None
        self.on_approval: Optional[Callable[[Dict[str, Any]], bool]] = None
        self.on_output: Optional[Callable[[str], None]] = None
        self._prune_pending()

    # -- callbacks / settings -------------------------------------------
    def _log(self, text: str) -> None:
        if self.on_log:
            try:
                self.on_log(text)
            except Exception:
                pass

    def _emit_clients(self) -> None:
        if self.on_clients:
            try:
                self.on_clients(self.client_list())
            except Exception:
                pass

    def _emit_output(self, text: str) -> None:
        if self.on_output:
            try:
                self.on_output(text)
            except Exception:
                pass

    def save_settings(self) -> None:
        ws.write_private(self.settings_path, json.dumps(self.settings.to_dict(), indent=2))

    def _save_clients(self) -> None:
        ws.write_private(self.clients_path, json.dumps(self.clients, indent=2))

    def _save_pending(self) -> None:
        ws.write_private(self.pending_path, json.dumps(self.pending, indent=2))

    def _prune_pending(self) -> None:
        now = ws.now()
        self.pending = [item for item in self.pending if int(item.get("expires", 0)) > now][-20:]
        self._save_pending()

    # -- policy ---------------------------------------------------------
    def auto_status(self) -> Dict[str, Any]:
        mode = self.settings.auto_mode
        if mode == "timed":
            remaining = max(0, self.settings.timed_until - ws.now())
            if remaining <= 0:
                self.settings.auto_mode = "off"
                self.settings.timed_until = 0
                self.save_settings()
                return {"mode": "off", "remaining": 0, "password_set": bool(self.settings.password_hash)}
            return {"mode": "timed", "remaining": remaining, "password_set": bool(self.settings.password_hash)}
        return {
            "mode": mode,
            "remaining": 0,
            "password_set": bool(self.settings.password_hash),
        }

    def arm_timed(self, minutes: int = 30) -> None:
        self.settings.auto_mode = "timed"
        self.settings.timed_until = ws.now() + max(1, int(minutes)) * 60
        self.save_settings()
        self._log(f"Auto-approve armed for {minutes} minute(s).")

    def disarm(self) -> None:
        self.settings.auto_mode = "off"
        self.settings.timed_until = 0
        self.save_settings()
        self._log("Auto-approve disarmed.")

    def set_password(self, new_password: str, current_password: str = "") -> None:
        if len(new_password) < 8:
            raise ws.WSError("The server password must be at least 8 characters.")
        if self.settings.password_hash and not ws.verify_password(
            current_password,
            self.settings.password_salt,
            self.settings.password_hash,
        ):
            raise ws.WSError("The current server password is incorrect.")
        salt, digest = ws.hash_password(new_password)
        self.settings.password_salt = salt
        self.settings.password_hash = digest
        with self._lock:
            for state in self._states:
                state.unlocked = False
        self.save_settings()
        self._log("Server password updated; active sessions must unlock again.")

    def enable_permanent(self, password: str) -> None:
        if not self.settings.password_hash:
            raise ws.WSError("Set a server password before enabling permanent auto-approve.")
        if not ws.verify_password(
            password, self.settings.password_salt, self.settings.password_hash
        ):
            raise ws.WSError("Incorrect server password.")
        self.settings.auto_mode = "permanent"
        self.settings.timed_until = 0
        with self._lock:
            for state in self._states:
                state.unlocked = False
        self.save_settings()
        self._log("Permanent auto-approve enabled (password required per client session).")

    def disable_permanent(self, password: str) -> None:
        if not ws.verify_password(
            password, self.settings.password_salt, self.settings.password_hash
        ):
            raise ws.WSError("Incorrect server password.")
        if self.settings.auto_mode == "permanent":
            self.settings.auto_mode = "off"
            self.save_settings()
        with self._lock:
            for state in self._states:
                state.unlocked = False
        self._log("Permanent auto-approve disabled.")

    def _password_ok(self, password: str) -> bool:
        return bool(self.settings.password_hash) and ws.verify_password(
            password, self.settings.password_salt, self.settings.password_hash
        )

    # -- lifecycle ------------------------------------------------------
    def start(self) -> int:
        if self._server is not None:
            return self.settings.port
        server = ws.WebSocketServer(
            self.settings.bind_host,
            self.settings.port,
            self.cert_path,
            self.key_path,
            self._handle_connection,
            on_log=self._log,
        )
        self._stop.clear()
        port = server.start()
        self._server = server
        if port != self.settings.port:
            self.settings.port = port
            self.save_settings()
        self._log(f"Server started on {self.settings.bind_host}:{port}.")
        return port

    def stop(self) -> None:
        self._stop.set()
        with self._lock:
            states = list(self._states)
        for state in states:
            for entry in list(state.processes.values()):
                try:
                    entry["cancel"].set()
                    _kill_process(entry.get("proc"))
                except Exception:
                    pass
            try:
                state.connection.close()
            except Exception:
                pass
        if self._server is not None:
            self._server.stop()
            self._server = None
        self._log("Server stopped.")

    @property
    def running(self) -> bool:
        return self._server is not None

    # -- invites / clients ----------------------------------------------
    def create_invite(self, public_host: str = "", minutes: int = 60) -> Dict[str, Any]:
        secret = os.urandom(32)
        host = (public_host or self.settings.public_host or _local_ip()).strip()
        host = host.replace("wss://", "").replace("https://", "").rstrip("/")
        if ":" in host and not host.startswith("["):
            url = f"wss://{host}"
        else:
            url = f"wss://{host}:{self.settings.port}"
        invite = {
            "app": ws.APP_TAG,
            "v": ws.PROTOCOL_VERSION,
            "kind": "invite",
            "server_id": self.settings.server_id,
            "name": self.settings.server_name,
            "url": url,
            "fingerprint": self.fingerprint,
            "secret": ws._b64(secret),
            "expires": ws.now() + max(1, int(minutes)) * 60,
        }
        with self._lock:
            self.pending.append(
                {
                    "secret": ws._b64(secret),
                    "expires": invite["expires"],
                    "created": ws.now(),
                }
            )
            self._prune_pending()
        code = ws.encode_invite(invite)
        self._log(f"Pairing invite created for {url}.")
        return {"code": code, "invite": invite, "expires": invite["expires"]}

    def client_list(self) -> List[Dict[str, Any]]:
        with self._lock:
            states = {state.client_id: state for state in self._states if state.client_id}
            result = []
            for client_id, record in self.clients.items():
                state = states.get(client_id)
                result.append(
                    {
                        "id": client_id,
                        "name": record.get("name", client_id),
                        "paired_at": record.get("paired_at", 0),
                        "last_seen": record.get("last_seen", 0),
                        "connected": state is not None,
                        "unlocked": bool(state.unlocked) if state else False,
                    }
                )
            result.sort(key=lambda item: str(item["name"]).lower())
            return result

    def remove_client(self, client_id: str) -> None:
        with self._lock:
            self.clients.pop(client_id, None)
            self._save_clients()
            states = [state for state in self._states if state.client_id == client_id]
        for state in states:
            for entry in list(state.processes.values()):
                try:
                    entry["cancel"].set()
                    _kill_process(entry.get("proc"))
                except Exception:
                    pass
            try:
                state.connection.close()
            except Exception:
                pass
        self._emit_clients()
        self._log(f"Removed client {client_id[:8]}.")

    # -- WebSocket handling ---------------------------------------------
    def _handle_connection(self, conn: ws.WSConnection, address: tuple) -> None:
        state = ConnectionState(connection=conn, address=address)
        try:
            first = conn.recv_json()
            if first is None:
                return
            if first.get("kind") == "pair":
                if not self._pair(state, first):
                    return
            elif first.get("kind") == "hello":
                if not self._hello(state, first):
                    return
            else:
                conn.send_json({"kind": "error", "error": "Expected pair or hello."})
                return
            with self._lock:
                self._states.append(state)
            self._emit_clients()
            self._log(f"Client connected: {state.client_name} ({state.client_id[:8]}) from {address[0]}")
            while not self._stop.is_set():
                message = conn.recv_json()
                if message is None:
                    break
                self._dispatch(state, message)
        except Exception as exc:
            self._log(f"Client {address[0]} disconnected: {exc}")
        finally:
            with self._lock:
                if state in self._states:
                    self._states.remove(state)
            for entry in list(state.processes.values()):
                try:
                    entry["cancel"].set()
                    _kill_process(entry.get("proc"))
                except Exception:
                    pass
            try:
                conn.close()
            except Exception:
                pass
            self._emit_clients()

    def _pair(self, state: ConnectionState, message: Dict[str, Any]) -> bool:
        client_id = str(message.get("client_id", ""))
        name = str(message.get("name", "")).strip() or client_id[:8]
        nonce_text = str(message.get("nonce", ""))
        proof = str(message.get("proof", ""))
        if not re.fullmatch(r"[A-Za-z0-9_-]{8,64}", client_id):
            state.connection.send_json({"kind": "error", "error": "Invalid client id."})
            return False
        try:
            client_nonce = ws._unb64(nonce_text)
        except Exception:
            state.connection.send_json({"kind": "error", "error": "Invalid nonce."})
            return False
        with self._lock:
            pending = list(self.pending)
        for item in pending:
            try:
                secret = ws._unb64(item["secret"])
            except Exception:
                continue
            if not ws.check_proof(
                secret, f"pair|{client_id}|{nonce_text}", proof
            ):
                continue
            if int(item.get("expires", 0)) < ws.now():
                continue
            server_nonce = os.urandom(16)
            base_key = ws.derive_key(
                secret, client_nonce, server_nonce, b"qah-ws-pair/v1"
            )
            session_key = ws.derive_key(
                base_key, client_nonce, server_nonce, b"qah-ws-session/v1"
            )
            with self._lock:
                self.pending = [entry for entry in self.pending if entry is not item]
                self._save_pending()
                self.clients[client_id] = {
                    "id": client_id,
                    "name": name,
                    "key": ws._b64(base_key),
                    "paired_at": ws.now(),
                    "last_seen": ws.now(),
                }
                self._save_clients()
            state.client_id = client_id
            state.client_name = name
            state.session_key = session_key
            state.connection.send_json(
                {
                    "kind": "pair_ok",
                    "server_id": self.settings.server_id,
                    "server_nonce": ws._b64(server_nonce),
                    "unlock_required": self.settings.auto_mode == "permanent",
                }
            )
            self._log(f"Paired new client {name} ({client_id[:8]}).")
            return True
        state.connection.send_json({"kind": "error", "error": "Invalid or expired invite."})
        return False

    def _hello(self, state: ConnectionState, message: Dict[str, Any]) -> bool:
        client_id = str(message.get("client_id", ""))
        nonce_text = str(message.get("nonce", ""))
        proof = str(message.get("proof", ""))
        record = self.clients.get(client_id)
        if not record:
            state.connection.send_json({"kind": "error", "error": "Unknown client."})
            return False
        try:
            client_nonce = ws._unb64(nonce_text)
            base_key = ws._unb64(record["key"])
        except Exception:
            state.connection.send_json({"kind": "error", "error": "Invalid hello."})
            return False
        if not ws.check_proof(base_key, f"hello|{client_id}|{nonce_text}", proof):
            state.connection.send_json({"kind": "error", "error": "Authentication failed."})
            return False
        server_nonce = os.urandom(16)
        session_key = ws.derive_key(
            base_key, client_nonce, server_nonce, b"qah-ws-session/v1"
        )
        state.client_id = client_id
        state.client_name = str(record.get("name", client_id))
        state.session_key = session_key
        record["last_seen"] = ws.now()
        with self._lock:
            self._save_clients()
        state.connection.send_json(
            {
                "kind": "hello_ok",
                "server_id": self.settings.server_id,
                "server_nonce": ws._b64(server_nonce),
                "unlock_required": self.settings.auto_mode == "permanent",
            }
        )
        return True

    def _send_secure(
        self, state: ConnectionState, kind: str, payload: Dict[str, Any]
    ) -> None:
        message_id = ws.new_id()
        timestamp = ws.now()
        aad = {
            "v": ws.PROTOCOL_VERSION,
            "kind": kind,
            "id": message_id,
            "ts": timestamp,
            "from": self.settings.server_id,
            "to": state.client_id,
        }
        nonce, ciphertext = ws.seal(state.session_key, payload, aad)
        state.connection.send_json(
            {
                **aad,
                "nonce": nonce,
                "ciphertext": ciphertext,
            }
        )

    def _dispatch(self, state: ConnectionState, message: Dict[str, Any]) -> None:
        kind = str(message.get("kind", ""))
        if kind == "ping":
            state.connection.send_json({"kind": "pong", "ts": ws.now()})
            return
        if kind not in ("exec", "cancel", "unlock"):
            state.connection.send_json({"kind": "error", "error": "Unknown message."})
            return
        if not state.session_key:
            state.connection.send_json({"kind": "error", "error": "Not authenticated."})
            return
        message_id = str(message.get("id", ""))
        if kind in ("exec", "cancel") and message_id:
            if message_id in state.seen_ids:
                self._send_secure(state, "error", {"id": message_id, "error": "Duplicate message id."})
                return
            state.seen_ids.add(message_id)
            if len(state.seen_ids) > 5000:
                state.seen_ids.clear()
        try:
            payload = ws.unseal(state.session_key, message)
        except Exception as exc:
            self._send_secure(state, "error", {"error": str(exc)})
            return
        if kind == "unlock":
            self._handle_unlock(state, payload)
        elif kind == "cancel":
            self._handle_cancel(state, payload)
        elif kind == "exec":
            self._handle_exec(state, message.get("id"), payload)

    def _handle_unlock(self, state: ConnectionState, payload: Dict[str, Any]) -> None:
        password = str(payload.get("password", ""))
        if self._password_ok(password):
            state.unlocked = True
            self._send_secure(state, "unlock_ok", {"ok": True})
            self._emit_clients()
            self._log(f"Client {state.client_name} unlocked permanent auto-approve.")
        else:
            self._send_secure(state, "error", {"error": "Incorrect server password."})
            self._log(f"Client {state.client_name} failed the server password.")

    def _handle_cancel(self, state: ConnectionState, payload: Dict[str, Any]) -> None:
        exec_id = str(payload.get("id", ""))
        entry = state.processes.get(exec_id)
        if entry:
            entry["cancel"].set()
            _kill_process(entry.get("proc"))

    def _handle_exec(
        self, state: ConnectionState, message_id: Any, payload: Dict[str, Any]
    ) -> None:
        exec_id = str(message_id or ws.new_id())
        command = str(payload.get("command", "")).strip()
        cwd = str(payload.get("cwd", "")).strip() or str(Path.home())
        timeout = max(1, min(int(payload.get("timeout", 120) or 120), 600))
        if not command:
            self._send_secure(state, "error", {"id": exec_id, "error": "Empty command."})
            return
        if len(command) > ws.MAX_COMMAND_CHARS:
            self._send_secure(state, "error", {"id": exec_id, "error": "Command is too long."})
            return
        cwd_path = Path(cwd).expanduser()
        if not cwd_path.is_dir():
            self._send_secure(state, "error", {"id": exec_id, "error": f"Working directory not found: {cwd}"})
            return
        dangerous = ws.is_dangerous_command(command)
        auto = False
        mode = self.settings.auto_mode
        if mode == "timed" and ws.now() < self.settings.timed_until:
            auto = True
        elif mode == "permanent" and state.unlocked:
            auto = True
        if dangerous:
            auto = False
        approved = auto
        if not auto:
            approved = self._request_approval(state, exec_id, command, str(cwd_path), dangerous)
        if not approved:
            self._send_secure(state, "error", {"id": exec_id, "error": "Command denied by the server operator."})
            self._audit(state, exec_id, command, str(cwd_path), False, auto, dangerous, None, 0, 0, False)
            return
        self._send_secure(state, "exec_start", {"id": exec_id, "command": command})
        thread = threading.Thread(
            target=self._run_command,
            args=(state, exec_id, command, str(cwd_path), timeout, auto, dangerous),
            daemon=True,
        )
        thread.start()

    def _request_approval(
        self,
        state: ConnectionState,
        exec_id: str,
        command: str,
        cwd: str,
        dangerous: bool,
    ) -> bool:
        request = {
            "id": exec_id,
            "client_id": state.client_id,
            "client_name": state.client_name,
            "command": command,
            "cwd": cwd,
            "dangerous": dangerous,
            "reason": "destructive command" if dangerous else "auto-approve is off/locked",
        }
        self._log(f"Approval requested from {state.client_name}: {command}")
        if self.on_approval is None:
            return False
        try:
            return bool(self.on_approval(request))
        except Exception as exc:
            self._log(f"Approval callback failed: {exc}")
            return False

    def _run_command(
        self,
        state: ConnectionState,
        exec_id: str,
        command: str,
        cwd: str,
        timeout: int,
        auto: bool,
        dangerous: bool,
    ) -> None:
        started = time.time()
        total = 0
        truncated = False
        sequence = 0
        kwargs: Dict[str, Any] = {}
        if os.name == "nt":
            kwargs["creationflags"] = (
                getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
                | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200)
            )
        try:
            proc = subprocess.Popen(
                command,
                shell=True,
                cwd=cwd,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                **kwargs,
            )
        except Exception as exc:
            self._send_secure(state, "error", {"id": exec_id, "error": str(exc)})
            self._audit(state, exec_id, command, cwd, True, auto, dangerous, None, 0, 0, False)
            return
        cancel = threading.Event()
        state.processes[exec_id] = {"proc": proc, "cancel": cancel}
        lock = threading.Lock()

        def send_chunk(kind: str, data: bytes) -> None:
            nonlocal total, truncated, sequence
            if not data:
                return
            with lock:
                if truncated:
                    return
                if total + len(data) > ws.MAX_OUTPUT_BYTES:
                    data = data[: max(0, ws.MAX_OUTPUT_BYTES - total)]
                    truncated = True
                if not data:
                    return
                total += len(data)
                sequence += 1
                try:
                    self._send_secure(
                        state,
                        kind,
                        {
                            "id": exec_id,
                            "seq": sequence,
                            "data": base64.b64encode(data).decode("ascii"),
                        },
                    )
                except Exception:
                    truncated = True

        def pump(pipe, kind: str) -> None:
            try:
                while True:
                    chunk = pipe.read(4096)
                    if not chunk:
                        break
                    send_chunk(kind, chunk)
            except Exception:
                pass
            finally:
                try:
                    pipe.close()
                except Exception:
                    pass

        out_thread = threading.Thread(target=pump, args=(proc.stdout, "stdout"), daemon=True)
        err_thread = threading.Thread(target=pump, args=(proc.stderr, "stderr"), daemon=True)
        out_thread.start()
        err_thread.start()
        code: Optional[int] = None
        try:
            while True:
                try:
                    code = proc.wait(timeout=0.5)
                    break
                except subprocess.TimeoutExpired:
                    if cancel.is_set():
                        _kill_process(proc)
                        code = -2
                        break
                    if time.time() - started > timeout:
                        _kill_process(proc)
                        code = -1
                        break
        finally:
            out_thread.join(timeout=5)
            err_thread.join(timeout=5)
            state.processes.pop(exec_id, None)
        if code == -1:
            self._send_secure(state, "error", {"id": exec_id, "error": f"Timed out after {timeout}s."})
        elif code == -2:
            self._send_secure(state, "error", {"id": exec_id, "error": "Cancelled."})
        duration = time.time() - started
        self._send_secure(
            state,
            "exit",
            {
                "id": exec_id,
                "code": code,
                "duration": round(duration, 3),
                "bytes": total,
                "truncated": truncated,
            },
        )
        self._audit(
            state, exec_id, command, cwd, True, auto, dangerous, code, duration, total, truncated
        )
        self._emit_output(
            f"[{state.client_name}] {command}\n"
            f"exit={code} bytes={total} duration={duration:.2f}s"
        )

    def _audit(
        self,
        state: ConnectionState,
        exec_id: str,
        command: str,
        cwd: str,
        allowed: bool,
        auto: bool,
        dangerous: bool,
        code: Optional[int],
        duration: float,
        total: int,
        truncated: bool,
    ) -> None:
        record = {
            "ts": ws.now(),
            "client_id": state.client_id,
            "client_name": state.client_name,
            "exec_id": exec_id,
            "command": command,
            "cwd": cwd,
            "allowed": allowed,
            "auto": auto,
            "dangerous": dangerous,
            "exit": code,
            "duration": round(float(duration), 3),
            "bytes": total,
            "truncated": truncated,
        }
        try:
            with open(self.audit_path, "a", encoding="utf-8") as handle:
                handle.write(json.dumps(record, ensure_ascii=False) + "\n")
            if os.name != "nt":
                try:
                    self.audit_path.chmod(0o600)
                except OSError:
                    pass
        except OSError:
            pass


def _local_ip() -> str:
    sock = __import__("socket").socket(__import__("socket").AF_INET, __import__("socket").SOCK_DGRAM)
    try:
        sock.connect(("8.8.8.8", 80))
        return sock.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        sock.close()


def _kill_process(proc) -> None:
    if proc is None:
        return
    try:
        if os.name == "nt":
            subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000),
                timeout=10,
            )
        else:
            proc.kill()
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass
