#!/usr/bin/env python3
"""Headless QAH WS Server for Linux/Windows and AI-to-AI coordination.

This runs the same encrypted command server as the QAH WS Server plugin, but
without Qt. It prints a one-time pairing invite and can arm timed auto-approve
for the benchmark window.

Examples:
  python qah_ws_server_cli.py --bind 0.0.0.0 --auto-minutes 60 \
      --invite-file invite.txt
  python qah_ws_server_cli.py --bind 127.0.0.1 --port 45910 --run-seconds 120

Security: this is remote command execution. Use LAN/Tailscale, share the invite
only over a trusted channel, and stop the server after the benchmark.
"""

from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from server_core import CommandServer, default_root  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="Headless QAH WS Server")
    parser.add_argument("--root", default="", help="Server settings directory")
    parser.add_argument("--bind", default="0.0.0.0", help="Bind address")
    parser.add_argument("--port", type=int, default=45900, help="TCP port")
    parser.add_argument("--public-host", default="",
                        help="Host/address written into the invite")
    parser.add_argument("--transport", choices=("direct", "relay"), default="direct",
                        help="direct WSS or outbound relay mode")
    parser.add_argument("--relay-host", default="", help="Relay host")
    parser.add_argument("--relay-port", type=int, default=45901, help="Relay port")
    parser.add_argument("--relay-room", default="", help="Relay room id")
    parser.add_argument("--relay-token", default="", help="Relay room token")
    parser.add_argument("--server-name", default="", help="Display name")
    parser.add_argument("--auto-minutes", type=int, default=60,
                        help="Timed auto-approve window (0 = off)")
    parser.add_argument("--invite-minutes", type=int, default=60,
                        help="Invite lifetime in minutes")
    parser.add_argument("--invite-file", default="invite.txt",
                        help="Write the invite here (chmod 600)")
    parser.add_argument("--approve-all", action="store_true",
                        help="Approve every command, including dangerous ones")
    parser.add_argument("--run-seconds", type=float, default=0,
                        help="Stop after N seconds (0 = run until Ctrl+C)")
    args = parser.parse_args()

    root = Path(args.root).expanduser() if args.root else default_root()
    server = CommandServer(root=root)
    server.settings.bind_host = args.bind
    server.settings.port = int(args.port)
    server.settings.transport = args.transport
    server.settings.public_host = args.public_host
    if args.transport == "relay":
        if not (args.relay_host and args.relay_room and args.relay_token):
            print("Relay mode needs --relay-host, --relay-room and --relay-token.",
                  file=sys.stderr)
            return 2
        server.settings.relay_host = args.relay_host
        server.settings.relay_port = int(args.relay_port)
        server.settings.relay_room = args.relay_room
        server.settings.relay_token = args.relay_token
    if args.server_name:
        server.settings.server_name = args.server_name
    server.save_settings()

    server.on_log = lambda text: print(f"[server] {text}", flush=True)
    if args.approve_all:
        print("[server] WARNING: approve-all is enabled", flush=True)
        server.on_approval = lambda request: True
    else:
        server.on_approval = lambda request: False

    port = server.start()
    if args.auto_minutes > 0:
        server.arm_timed(args.auto_minutes)
    invite = server.create_invite(public_host=args.public_host,
                                  minutes=args.invite_minutes)
    invite_path = Path(args.invite_file).expanduser()
    invite_path.parent.mkdir(parents=True, exist_ok=True)
    invite_path.write_text(invite["code"] + "\n", encoding="utf-8")
    try:
        os.chmod(invite_path, 0o600)
    except Exception:
        pass

    print(f"[server] listening on {args.bind}:{port}", flush=True)
    print(f"[server] invite file: {invite_path}", flush=True)
    print(f"[server] invite: {invite['code']}", flush=True)
    print("[server] timed auto-approve: "
          f"{args.auto_minutes} min; invite: {args.invite_minutes} min", flush=True)

    started = time.time()
    try:
        while True:
            if args.run_seconds and time.time() - started >= args.run_seconds:
                break
            time.sleep(1.0)
    except KeyboardInterrupt:
        pass
    finally:
        server.stop()
        print("[server] stopped", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
