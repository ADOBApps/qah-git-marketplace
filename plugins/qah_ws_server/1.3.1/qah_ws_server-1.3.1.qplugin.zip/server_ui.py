# qah_ws_server/server_ui.py
"""PySide6 UI for QAH WS Server."""

from __future__ import annotations

import importlib
import importlib.util
import json
import sys
import threading
import traceback
from datetime import datetime
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QObject, QThread, QTimer, Qt, Signal
from PySide6.QtGui import QFont, QFontDatabase
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QInputDialog,
    QPlainTextEdit,
    QPushButton,
    QSpinBox,
    QTabWidget,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)


def _load_sibling(name: str):
    try:
        return importlib.import_module(f"{__name__}.{name}")
    except ImportError:
        path = Path(__file__).with_name(f"{name}.py")
        spec = importlib.util.spec_from_file_location(f"_qah_ws_server_{name}", path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        return module


core = _load_sibling("server_core")
ws = core.ws
docs = _load_sibling("documentation")


class _Bridge(QObject):
    log = Signal(str)
    clients = Signal(object)
    approval = Signal(object)
    output = Signal(str)


class _Approval:
    def __init__(self, request):
        self.request = request
        self.event = threading.Event()
        self.result = False


class ServerWidget(QWidget):
    def __init__(self, plugin):
        super().__init__()
        self.plugin = plugin
        self.server = plugin.server
        self.bridge = _Bridge(self)
        self.bridge.log.connect(self._log)
        self.bridge.clients.connect(self._refresh_clients)
        self.bridge.approval.connect(self._show_approval)
        self.bridge.output.connect(self._on_output)

        self.server.on_log = lambda text: self.bridge.log.emit(text)
        self.server.on_clients = lambda clients: self.bridge.clients.emit(clients)
        self.server.on_approval = self._approval
        self.server.on_output = lambda text: self.bridge.output.emit(text)

        self._build_ui()
        self._refresh_status()
        self._refresh_clients()
        self._refresh_audit()

        self._policy_timer = QTimer(self)
        self._policy_timer.timeout.connect(self._refresh_policy)
        self._policy_timer.start(1000)

    # -- UI -------------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        header = QHBoxLayout()
        title = QLabel("<b>QAH WS Server</b>")
        title.setFont(QFont("Arial", 14))
        header.addWidget(title)
        self.status_label = QLabel("")
        self.status_label.setStyleSheet("color: #6c757d;")
        header.addWidget(self.status_label, 1)
        self.fingerprint_label = QLabel("")
        self.fingerprint_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.fingerprint_label.setStyleSheet("color: #6c757d;")
        header.addWidget(self.fingerprint_label)
        layout.addLayout(header)

        top = QHBoxLayout()
        self.start_button = QPushButton("Start server")
        self.start_button.clicked.connect(self._start)
        top.addWidget(self.start_button)
        self.stop_button = QPushButton("Stop server")
        self.stop_button.clicked.connect(self._stop)
        top.addWidget(self.stop_button)
        self.invite_button = QPushButton("Create pairing invite")
        self.invite_button.clicked.connect(self._create_invite)
        top.addWidget(self.invite_button)
        top.addStretch(1)
        self.mode_badge = QLabel("")
        self.mode_badge.setStyleSheet("font-weight: bold;")
        top.addWidget(self.mode_badge)
        layout.addLayout(top)

        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, 1)
        self._build_server_tab()
        self._build_policy_tab()
        self._build_clients_tab()
        self._build_audit_tab()
        self._build_relay_tab()
        self._build_settings_tab()
        self._build_docs_tab()

        self.activity = QPlainTextEdit()
        self.activity.setReadOnly(True)
        self.activity.setMaximumHeight(120)
        self.activity.setFont(_mono_font())
        layout.addWidget(self.activity)
        self._log("Server is stopped. Nothing is listening until you click Start.")

    def _build_server_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.addWidget(
            QLabel(
                "Create an invite, send it to the client through a trusted "
                "channel, then leave the server running while the client works."
            )
        )
        self.invite_text = QPlainTextEdit()
        self.invite_text.setReadOnly(True)
        self.invite_text.setFont(_mono_font())
        self.invite_text.setPlaceholderText("Pairing invite appears here.")
        layout.addWidget(self.invite_text, 1)
        row = QHBoxLayout()
        copy = QPushButton("Copy invite")
        copy.clicked.connect(self._copy_invite)
        row.addWidget(copy)
        save = QPushButton("Save invite...")
        save.clicked.connect(self._save_invite)
        row.addWidget(save)
        row.addStretch(1)
        layout.addLayout(row)
        self.tabs.addTab(tab, "Server")

    def _build_policy_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        intro = QLabel(
            "Default is <b>off</b>: every command needs approval in a dialog. "
            "Timed mode arms auto-approve for the chosen duration (1–1440 "
            "minutes). Permanent mode requires the server password on every "
            "client session. Destructive commands always require confirmation, "
            "even when armed."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)
        self.policy_label = QLabel("")
        self.policy_label.setWordWrap(True)
        layout.addWidget(self.policy_label)

        row = QHBoxLayout()
        row.addWidget(QLabel("Duration:"))
        self.auto_minutes_spin = QSpinBox()
        self.auto_minutes_spin.setRange(1, 1440)
        self.auto_minutes_spin.setValue(30)
        self.auto_minutes_spin.setSuffix(" min")
        self.auto_minutes_spin.setToolTip(
            "Timed auto-approve window, from 1 minute to 24 hours."
        )
        row.addWidget(self.auto_minutes_spin)
        arm = QPushButton("Arm auto-approve")
        arm.clicked.connect(self._arm_timed)
        row.addWidget(arm)
        disarm = QPushButton("Disarm now")
        disarm.clicked.connect(self._disarm)
        row.addWidget(disarm)
        row.addStretch(1)
        layout.addLayout(row)

        box = QGroupBox("Permanent auto-approve (password protected)")
        form = QFormLayout(box)
        self.current_password = QLineEdit()
        self.current_password.setEchoMode(QLineEdit.Password)
        self.current_password.setPlaceholderText("current password, if one exists")
        self.new_password = QLineEdit()
        self.new_password.setEchoMode(QLineEdit.Password)
        self.new_password.setPlaceholderText("new password (min 8 characters)")
        self.confirm_password = QLineEdit()
        self.confirm_password.setEchoMode(QLineEdit.Password)
        form.addRow("Current:", self.current_password)
        form.addRow("New:", self.new_password)
        form.addRow("Confirm:", self.confirm_password)
        password_row = QHBoxLayout()
        setpw = QPushButton("Set / change password")
        setpw.clicked.connect(self._set_password)
        password_row.addWidget(setpw)
        enable = QPushButton("Enable permanent")
        enable.clicked.connect(self._enable_permanent)
        password_row.addWidget(enable)
        disable = QPushButton("Disable permanent")
        disable.clicked.connect(self._disable_permanent)
        password_row.addWidget(disable)
        password_row.addStretch(1)
        form.addRow("", password_row)
        layout.addWidget(box)
        layout.addStretch(1)
        self.tabs.addTab(tab, "Policy")

    def _build_clients_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.addWidget(
            QLabel("Paired clients. Remove a client to revoke its key immediately.")
        )
        self.client_list = QListWidget()
        self.client_list.setAlternatingRowColors(True)
        layout.addWidget(self.client_list, 1)
        row = QHBoxLayout()
        refresh = QPushButton("Refresh")
        refresh.clicked.connect(self._refresh_clients)
        row.addWidget(refresh)
        remove = QPushButton("Remove selected client")
        remove.clicked.connect(self._remove_client)
        row.addWidget(remove)
        row.addStretch(1)
        layout.addLayout(row)
        self.tabs.addTab(tab, "Clients")

    def _build_audit_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.addWidget(
            QLabel(
                "Every requested command is appended to audit.jsonl with the "
                "client, decision, exit code and output size."
            )
        )
        self.audit_view = QPlainTextEdit()
        self.audit_view.setReadOnly(True)
        self.audit_view.setFont(_mono_font())
        layout.addWidget(self.audit_view, 1)
        row = QHBoxLayout()
        refresh = QPushButton("Refresh")
        refresh.clicked.connect(self._refresh_audit)
        row.addWidget(refresh)
        row.addStretch(1)
        layout.addLayout(row)
        self.tabs.addTab(tab, "Audit")

    def _build_relay_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        intro = QLabel(
            "Relay mode makes the server connect <b>outbound</b> to a relay, so "
            "no inbound port is needed. The relay only copies TLS bytes; "
            "certificate pinning, pairing and application encryption stay "
            "end-to-end. Direct mode keeps listening on the bind address below."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        form = QFormLayout()
        self.transport_combo = QComboBox()
        self.transport_combo.addItem("Direct (listen on this computer)", "direct")
        self.transport_combo.addItem("Relay (outbound to a relay)", "relay")
        self.relay_host_edit = QLineEdit()
        self.relay_host_edit.setPlaceholderText("relay.example.com")
        self.relay_port_spin = QSpinBox()
        self.relay_port_spin.setRange(1, 65535)
        self.relay_port_spin.setValue(45901)
        self.relay_room_edit = QLineEdit()
        self.relay_room_edit.setPlaceholderText("generated automatically")
        self.relay_token_edit = QLineEdit()
        self.relay_token_edit.setEchoMode(QLineEdit.Password)
        self.relay_token_edit.setPlaceholderText("generated automatically")
        self.relay_slots_spin = QSpinBox()
        self.relay_slots_spin.setRange(1, 8)
        self.relay_slots_spin.setValue(1)
        form.addRow("Transport:", self.transport_combo)
        form.addRow("Relay host:", self.relay_host_edit)
        form.addRow("Relay port:", self.relay_port_spin)
        form.addRow("Room:", self.relay_room_edit)
        form.addRow("Room token:", self.relay_token_edit)
        form.addRow("Waiting slots:", self.relay_slots_spin)
        layout.addLayout(form)

        row = QHBoxLayout()
        save = QPushButton("Save relay settings")
        save.clicked.connect(self._save_relay_settings)
        row.addWidget(save)
        generate = QPushButton("Generate new room & token")
        generate.clicked.connect(self._generate_relay_identity)
        row.addWidget(generate)
        row.addStretch(1)
        layout.addLayout(row)

        self.relay_status_label = QLabel("")
        self.relay_status_label.setWordWrap(True)
        self.relay_status_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(self.relay_status_label)

        note = QLabel(
            "Run the bundled <code>relay_server.py</code> on a host with a "
            "public TCP port, then enter its address here. Changing the "
            "transport, room or token requires stopping and starting the "
            "server. Invites created before the change stop working."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color: #6b7280;")
        layout.addWidget(note)
        layout.addStretch(1)
        self.tabs.addTab(tab, "Relay")

    def _build_settings_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        form = QFormLayout()
        self.name_edit = QLineEdit()
        self.bind_edit = QLineEdit()
        self.bind_edit.setPlaceholderText("0.0.0.0 for internet, 127.0.0.1 for local")
        self.port_spin = QSpinBox()
        self.port_spin.setRange(1024, 65535)
        self.public_edit = QLineEdit()
        self.public_edit.setPlaceholderText("public hostname or host:port for invites")
        form.addRow("Server name:", self.name_edit)
        form.addRow("Bind address:", self.bind_edit)
        form.addRow("Port:", self.port_spin)
        form.addRow("Public host:", self.public_edit)
        layout.addLayout(form)
        row = QHBoxLayout()
        save = QPushButton("Save settings")
        save.clicked.connect(self._save_settings)
        row.addWidget(save)
        row.addStretch(1)
        layout.addLayout(row)
        self.cert_label = QLabel("")
        self.cert_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.cert_label.setWordWrap(True)
        layout.addWidget(self.cert_label)
        layout.addStretch(1)
        self._load_settings()
        self.tabs.addTab(tab, "Settings")

    def _build_docs_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        browser = QTextBrowser()
        browser.setOpenExternalLinks(True)
        browser.setHtml(docs.docs_html())
        layout.addWidget(browser, 1)
        self.tabs.addTab(tab, "Documentation")

    # -- helpers --------------------------------------------------------
    def _load_settings(self):
        s = self.server.settings
        self.name_edit.setText(s.server_name)
        self.bind_edit.setText(s.bind_host)
        self.port_spin.setValue(int(s.port))
        self.public_edit.setText(s.public_host)
        index = self.transport_combo.findData(s.transport)
        self.transport_combo.setCurrentIndex(index if index >= 0 else 0)
        self.relay_host_edit.setText(s.relay_host)
        self.relay_port_spin.setValue(int(s.relay_port))
        self.relay_room_edit.setText(s.relay_room)
        self.relay_token_edit.setText(s.relay_token)
        self.relay_slots_spin.setValue(int(s.relay_slots))
        self.cert_label.setText(
            f"Certificate fingerprint:\n{self.server.fingerprint}\n"
            f"Data folder: {self.server.root}"
        )

    def _refresh_status(self):
        running = self.server.running
        self.start_button.setEnabled(not running)
        self.stop_button.setEnabled(running)
        self.invite_button.setEnabled(running)
        state = "running" if running else "stopped"
        s = self.server.settings
        if s.transport == "relay":
            relay = self.server.relay_status()
            address = relay.get("relay") or "relay not configured"
            self.status_label.setText(
                f"{state} · relay {address} · room {s.relay_room or '-'}"
            )
            if running:
                self.relay_status_label.setText(
                    f"Relay room <b>{s.relay_room}</b> via <b>{address}</b> · "
                    f"{relay.get('registered', 0)} slot(s) registered"
                    + (
                        f"<br><span style='color:#b91c1c;'>"
                        f"{relay.get('last_error', '')}</span>"
                        if relay.get("last_error")
                        else ""
                    )
                )
            else:
                self.relay_status_label.setText(
                    f"Relay configured: <b>{address}</b>, room "
                    f"<b>{s.relay_room or '-'}</b>. Start the server to connect."
                )
        else:
            self.status_label.setText(
                f"{state} · {s.bind_host}:{s.port}"
            )
            if hasattr(self, "relay_status_label"):
                self.relay_status_label.setText(
                    "Direct mode: the server listens on the bind address above."
                )
        self.fingerprint_label.setText(f"fp {self.server.fingerprint[:16]}")
        self._refresh_policy()

    def _refresh_policy(self):
        status = self.server.auto_status()
        mode = status["mode"]
        if mode == "timed":
            remaining = status["remaining"]
            text = f"timed arm: {remaining // 60}:{remaining % 60:02d} remaining"
            color = "#b45309"
        elif mode == "permanent":
            text = "permanent auto-approve (password per client session)"
            color = "#b91c1c"
        else:
            text = "off: every command requires approval"
            color = "#1e7b45"
        self.mode_badge.setText(text)
        self.mode_badge.setStyleSheet(f"color: {color}; font-weight: bold;")
        self.policy_label.setText(
            f"Current mode: <b>{text}</b><br>"
            f"Server password set: {'yes' if status['password_set'] else 'no'}"
        )

    def _start(self):
        try:
            self.server.start()
            self._refresh_status()
        except Exception as exc:
            QMessageBox.critical(self, "Start failed", str(exc))

    def _stop(self):
        self.server.stop()
        self._refresh_status()

    def _create_invite(self):
        try:
            invite = self.server.create_invite(self.public_edit.text().strip())
        except Exception as exc:
            QMessageBox.critical(self, "Invite failed", str(exc))
            return
        self.invite_text.setPlainText(invite["code"])
        self._log(f"Invite created for {invite['invite']['url']}")

    def _copy_invite(self):
        text = self.invite_text.toPlainText().strip()
        if text:
            QApplication.clipboard().setText(text)
            self._log("Invite copied.")

    def _save_invite(self):
        text = self.invite_text.toPlainText().strip()
        if not text:
            return
        from PySide6.QtWidgets import QFileDialog

        path, _ = QFileDialog.getSaveFileName(
            self, "Save pairing invite", str(Path.home() / "qah-ws-invite.txt"),
            "Text files (*.txt);;All files (*)",
        )
        if path:
            Path(path).write_text(text + "\n", encoding="utf-8")
            self._log(f"Invite saved to {path}")

    # -- policy actions -------------------------------------------------
    def _arm_timed(self):
        self.server.arm_timed(int(self.auto_minutes_spin.value()))
        self._refresh_policy()

    def _disarm(self):
        self.server.disarm()
        self._refresh_policy()

    def _set_password(self):
        new = self.new_password.text()
        confirm = self.confirm_password.text()
        if new != confirm:
            QMessageBox.warning(self, "Password", "The new passwords do not match.")
            return
        try:
            self.server.set_password(new, self.current_password.text())
        except Exception as exc:
            QMessageBox.critical(self, "Password", str(exc))
            return
        self.current_password.clear()
        self.new_password.clear()
        self.confirm_password.clear()
        self._refresh_policy()
        QMessageBox.information(self, "Password", "Server password updated.")

    def _enable_permanent(self):
        password = self.new_password.text() or self.current_password.text()
        if not password:
            QMessageBox.warning(self, "Password", "Enter the server password.")
            return
        try:
            self.server.enable_permanent(password)
        except Exception as exc:
            QMessageBox.critical(self, "Permanent mode", str(exc))
            return
        self._refresh_policy()
        QMessageBox.warning(
            self,
            "Permanent auto-approve",
            "Permanent mode is enabled. Each client session must unlock with the "
            "server password. Destructive commands still require confirmation.",
        )

    def _disable_permanent(self):
        password, ok = QInputDialog.getText(
            self, "Disable permanent mode", "Server password:", QLineEdit.Password
        )
        if not ok:
            return
        try:
            self.server.disable_permanent(password)
        except Exception as exc:
            QMessageBox.critical(self, "Permanent mode", str(exc))
            return
        self._refresh_policy()

    # -- clients / approval --------------------------------------------
    def _refresh_clients(self, clients=None):
        if clients is None:
            clients = self.server.client_list()
        self.client_list.clear()
        for client in clients:
            state = "connected" if client.get("connected") else "offline"
            if client.get("unlocked"):
                state += " · unlocked"
            item = QListWidgetItem(f"{client['name']}  [{client['id'][:8]}]  {state}")
            item.setData(Qt.UserRole, client["id"])
            self.client_list.addItem(item)

    def _remove_client(self):
        item = self.client_list.currentItem()
        if item is None:
            return
        client_id = item.data(Qt.UserRole)
        answer = QMessageBox.question(
            self,
            "Remove client",
            f"Revoke client {client_id[:8]}? Its key will stop working immediately.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer == QMessageBox.Yes:
            self.server.remove_client(client_id)

    def _approval(self, request):
        approval = _Approval(request)
        self.bridge.approval.emit(approval)
        approval.event.wait(120)
        return approval.result

    def _show_approval(self, approval: _Approval):
        request = approval.request
        box = QMessageBox(self)
        box.setWindowTitle("Remote command approval")
        box.setIcon(QMessageBox.Warning)
        box.setText(
            f"Client <b>{request.get('client_name')}</b> requests a command."
        )
        box.setInformativeText(
            f"<pre>{request.get('command')}</pre>"
            f"<p><b>Working directory:</b> {request.get('cwd')}<br>"
            f"<b>Reason:</b> {request.get('reason')}</p>"
        )
        allow = box.addButton("Allow once", QMessageBox.AcceptRole)
        deny = box.addButton("Deny", QMessageBox.RejectRole)
        box.setDefaultButton(deny)
        box.exec()
        approval.result = box.clickedButton() is allow
        approval.event.set()
        self._log(
            f"{'Allowed' if approval.result else 'Denied'} command from "
            f"{request.get('client_name')}: {request.get('command')}"
        )

    # -- audit / logs ---------------------------------------------------
    def _refresh_audit(self):
        try:
            lines = self.server.audit_path.read_text(encoding="utf-8").splitlines()
        except OSError:
            lines = []
        self.audit_view.setPlainText("\n".join(lines[-500:]))

    def _on_output(self, text):
        self._log(text)

    def _log(self, text):
        stamp = datetime.now().strftime("%H:%M:%S")
        for index, line in enumerate(str(text).splitlines() or [""]):
            prefix = f"[{stamp}] " if index == 0 else "           "
            self.activity.appendPlainText(prefix + line)
        bar = self.activity.verticalScrollBar()
        bar.setValue(bar.maximum())

    # -- settings -------------------------------------------------------
    def _save_settings(self):
        s = self.server.settings
        s.server_name = self.name_edit.text().strip() or s.server_name
        s.bind_host = self.bind_edit.text().strip() or "0.0.0.0"
        s.port = int(self.port_spin.value())
        s.public_host = self.public_edit.text().strip()
        self.server.save_settings()
        self._log("Settings saved. Restart the server to apply bind/port changes.")
        self._refresh_status()

    def _save_relay_settings(self):
        s = self.server.settings
        s.transport = str(self.transport_combo.currentData() or "direct")
        s.relay_host = self.relay_host_edit.text().strip()
        s.relay_port = int(self.relay_port_spin.value())
        s.relay_room = self.relay_room_edit.text().strip()
        s.relay_token = self.relay_token_edit.text().strip()
        s.relay_slots = int(self.relay_slots_spin.value())
        if s.transport == "relay":
            self.server.ensure_relay_identity()
        self.server.save_settings()
        self._load_settings()
        self._log(
            "Relay settings saved. Stop and start the server to apply them."
        )
        self._refresh_status()

    def _generate_relay_identity(self):
        if self.server.running:
            QMessageBox.warning(
                self,
                "Server running",
                "Stop the server before generating a new relay room and token.",
            )
            return
        values = self.server.new_relay_identity()
        self.relay_room_edit.setText(values["room"])
        self.relay_token_edit.setText(values["token"])
        self._log(
            "Generated a new relay room and token. Save the settings and "
            "restart the server; old invites are now invalid."
        )
        self._refresh_status()

    def cleanup(self):
        self._policy_timer.stop()
        self.server.stop()


def _mono_font() -> QFont:
    try:
        font = QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont)
    except Exception:
        font = QFontDatabase.systemFont(QFontDatabase.FixedFont)
    font.setPointSize(10)
    return font
