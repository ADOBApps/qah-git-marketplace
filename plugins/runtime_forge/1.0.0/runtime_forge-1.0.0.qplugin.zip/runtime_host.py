"""JSON-RPC runtime host for Runtime Forge.

This script is run with an isolated Python interpreter and a per-plugin
site-packages directory. It never imports QAH and only writes JSON responses to
stdout; plugin prints are captured.
"""

from __future__ import annotations

import contextlib
import importlib
import io
import json
import sys
import traceback


def _jsonable(value):
    try:
        json.dumps(value)
        return value
    except Exception:
        return repr(value)


def _response(request_id, ok, result=None, error=None):
    payload = {"id": request_id, "ok": bool(ok)}
    if ok:
        payload["result"] = result
    else:
        payload["error"] = error
    print(json.dumps(payload, ensure_ascii=False, default=str), flush=True)


def main():
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--site-packages", action="append", default=[])
    args = parser.parse_args()
    for path in reversed(args.site_packages):
        if path:
            sys.path.insert(0, path)

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        request_id = None
        try:
            request = json.loads(line)
            request_id = request.get("id")
            method = request.get("method")
            params = request.get("params") or {}
            out = io.StringIO()
            err = io.StringIO()
            with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                if method == "ping":
                    result = {
                        "python": sys.version,
                        "executable": sys.executable,
                        "site_packages": args.site_packages,
                    }
                elif method == "import":
                    module = importlib.import_module(str(params.get("module") or ""))
                    result = {
                        "module": module.__name__,
                        "file": getattr(module, "__file__", ""),
                        "version": getattr(module, "__version__", ""),
                    }
                elif method == "call":
                    module = importlib.import_module(str(params.get("module") or ""))
                    function = getattr(module, str(params.get("function") or ""))
                    result = function(*params.get("args", []), **params.get("kwargs", {}))
                    result = _jsonable(result)
                elif method == "exec":
                    namespace = {"__name__": "__runtime_host__"}
                    exec(str(params.get("code") or ""), namespace)
                    result = {
                        key: repr(value)
                        for key, value in namespace.items()
                        if not key.startswith("__") and not callable(value)
                    }
                else:
                    raise ValueError(f"Unknown method: {method}")
            result_payload = result
            captured = out.getvalue()
            if captured:
                if isinstance(result_payload, dict):
                    result_payload = dict(result_payload)
                    result_payload.setdefault("stdout", captured)
                else:
                    result_payload = {"value": result_payload, "stdout": captured}
            stderr_text = err.getvalue()
            if stderr_text and isinstance(result_payload, dict):
                result_payload.setdefault("stderr", stderr_text)
            _response(request_id, True, result_payload)
        except BaseException as exc:
            _response(
                request_id,
                False,
                error=f"{type(exc).__name__}: {exc}",
            )


if __name__ == "__main__":
    main()
