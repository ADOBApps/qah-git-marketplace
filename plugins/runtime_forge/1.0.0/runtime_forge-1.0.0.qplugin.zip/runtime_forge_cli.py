"""Runtime Forge CLI (headless)."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from forge_core import (
    activate_build,
    call,
    doctor,
    execute,
    import_module,
    install_lock,
    list_builds,
    list_runtimes,
    load_lock,
    lock_from_wheels,
    ping,
    remove_runtime,
    rollback,
)


def _print(value):
    print(json.dumps(value, indent=2, default=str))


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Runtime Forge CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("list", help="list runtimes")

    lock = sub.add_parser("lock", help="build a lock from wheel files")
    lock.add_argument("--plugin", required=True)
    lock.add_argument("--wheels", nargs="+", required=True)
    lock.add_argument("--out")

    install = sub.add_parser("install", help="install a runtime from a lock")
    install.add_argument("lock")
    install.add_argument("--wheel-dir", default=".")

    doctor_p = sub.add_parser("doctor", help="check a runtime")
    doctor_p.add_argument("plugin")

    remove = sub.add_parser("remove", help="remove a runtime")
    remove.add_argument("plugin")

    ping_p = sub.add_parser("ping", help="ping the runtime host")
    ping_p.add_argument("plugin")

    imp = sub.add_parser("import", help="import a module in the runtime")
    imp.add_argument("plugin")
    imp.add_argument("module")

    call_p = sub.add_parser("call", help="call a function in the runtime")
    call_p.add_argument("plugin")
    call_p.add_argument("module")
    call_p.add_argument("function")
    call_p.add_argument("--args", default="[]")
    call_p.add_argument("--kwargs", default="{}")

    run = sub.add_parser("exec", help="execute code in the runtime host")
    run.add_argument("plugin")
    run.add_argument("code")

    list_b = sub.add_parser("builds", help="list builds")
    list_b.add_argument("plugin")

    activate = sub.add_parser("activate", help="activate a build")
    activate.add_argument("plugin")
    activate.add_argument("build")

    roll = sub.add_parser("rollback", help="roll back to the previous build")
    roll.add_argument("plugin")

    args = parser.parse_args(argv)
    try:
        if args.command == "list":
            _print(list_runtimes())
        elif args.command == "lock":
            result = lock_from_wheels(
                args.plugin, [Path(path).expanduser() for path in args.wheels]
            )
            if args.out:
                Path(args.out).write_text(json.dumps(result, indent=2), encoding="utf-8")
                print(f"Lock written to {args.out}")
            else:
                _print(result)
        elif args.command == "install":
            lock_data = load_lock(Path(args.lock).expanduser())
            wheel_dir = Path(args.wheel_dir).expanduser()
            sources = {path.name: path for path in wheel_dir.glob("*.whl")}
            _print(install_lock(lock_data["plugin_id"], lock_data, wheel_sources=sources))
        elif args.command == "doctor":
            _print(doctor(args.plugin))
        elif args.command == "remove":
            remove_runtime(args.plugin)
            print(f"Removed {args.plugin}")
        elif args.command == "ping":
            _print(ping(args.plugin))
        elif args.command == "import":
            _print(import_module(args.plugin, args.module))
        elif args.command == "call":
            _print(call(args.plugin, args.module, args.function, json.loads(args.args), json.loads(args.kwargs)))
        elif args.command == "exec":
            _print(execute(args.plugin, args.code))
        elif args.command == "builds":
            _print(list_builds(args.plugin))
        elif args.command == "activate":
            _print(activate_build(args.plugin, args.build))
        elif args.command == "rollback":
            _print(rollback(args.plugin))
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
