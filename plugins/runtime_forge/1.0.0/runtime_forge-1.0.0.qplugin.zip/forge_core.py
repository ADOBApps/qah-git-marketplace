"""Runtime Forge core: isolated, hash-locked runtimes for QAH plugins.

The MVP installs pre-built wheels into a per-plugin ``site-packages`` directory,
stores a lock file with SHA256 hashes, and runs code through a JSON-RPC host in
a separate Python interpreter. It never runs pip, setup.py or cargo on the user
machine.
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import sysconfig
import time
import zipfile
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

ID_RE = re.compile(r"^[a-z][a-z0-9_]{1,63}$")
HOST_NAME = "runtime_host.py"


def qah_home() -> Path:
    override = os.environ.get("QAH_HOME")
    return Path(override).expanduser() if override else Path.home() / "QAH"


def runtimes_dir() -> Path:
    root = qah_home() / "runtimes"
    root.mkdir(parents=True, exist_ok=True)
    return root


def wheel_cache_dir() -> Path:
    root = qah_home() / "runtime_cache" / "wheels"
    root.mkdir(parents=True, exist_ok=True)
    return root


def runtime_root(plugin_id: str) -> Path:
    if not ID_RE.fullmatch(str(plugin_id)):
        raise ValueError(f"Invalid plugin id: {plugin_id!r}")
    root = runtimes_dir() / plugin_id
    root.mkdir(parents=True, exist_ok=True)
    return root


def _read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2), encoding="utf-8")


def sha256_file(path: Path) -> str:
    hasher = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


# ---------------------------------------------------------------------------
# Interpreter resolution
# ---------------------------------------------------------------------------

def _probe(command: List[str]) -> Optional[Dict[str, Any]]:
    try:
        completed = subprocess.run(
            command + ["-I", "-c", "import sys;print(sys.version.split()[0]);print(sys.executable)"],
            capture_output=True,
            text=True,
            timeout=6,
        )
    except Exception:
        return None
    if completed.returncode != 0:
        return None
    lines = [line.strip() for line in completed.stdout.splitlines() if line.strip()]
    if len(lines) < 2 or not re.match(r"^\d+\.\d+", lines[0]):
        return None
    return {"command": command, "version": lines[0], "executable": lines[-1]}


def find_python() -> Optional[Dict[str, Any]]:
    candidates: List[List[str]] = []
    if sys.executable and Path(sys.executable).exists():
        candidates.append([sys.executable])
    for name in ("python3", "python"):
        found = shutil.which(name)
        if found:
            candidates.append([found])
    if os.name == "nt":
        py = shutil.which("py")
        if py:
            candidates.append([py, "-3"])
    seen = set()
    for command in candidates:
        key = tuple(command)
        if key in seen:
            continue
        seen.add(key)
        probe = _probe(command)
        if probe:
            return probe
    return None


def python_version_of(command: Sequence[str]) -> str:
    probe = _probe(list(command))
    return probe["version"] if probe else ""


# ---------------------------------------------------------------------------
# Wheel tags
# ---------------------------------------------------------------------------

def parse_wheel_filename(filename: str) -> Dict[str, str]:
    base = Path(filename).name
    if not base.lower().endswith(".whl"):
        raise ValueError(f"Not a wheel: {filename}")
    parts = base[:-4].split("-")
    if len(parts) not in (5, 6):
        raise ValueError(f"Invalid wheel filename: {filename}")
    if len(parts) == 5:
        dist, version, py_tag, abi_tag, platform_tag = parts
        build = ""
    else:
        dist, version, build, py_tag, abi_tag, platform_tag = parts
    return {
        "distribution": dist,
        "version": version,
        "build": build,
        "python_tag": py_tag,
        "abi_tag": abi_tag,
        "platform_tag": platform_tag,
    }


def _platform_tokens() -> Tuple[str, str]:
    system = platform.system().lower()
    machine = platform.machine().lower()
    if machine in ("amd64", "x86_64"):
        arch = "x86_64"
    elif machine in ("arm64", "aarch64"):
        arch = "aarch64"
    elif machine in ("i386", "i686", "x86"):
        arch = "i686"
    else:
        arch = machine
    return system, arch


def wheel_compatible(filename: str, python_version: str) -> Tuple[bool, str]:
    try:
        tags = parse_wheel_filename(filename)
    except Exception as exc:
        return False, str(exc)
    py_parts = tags["python_tag"].split(".")
    abi_parts = tags["abi_tag"].split(".")
    platform_parts = tags["platform_tag"].split(".")
    major, minor = (python_version.split(".") + ["0"])[:2]
    cp = f"cp{major}{minor}"

    py_ok = any(
        part in ("py3", f"py{major}", cp)
        or (part.startswith("cp") and part[: len(cp)] == cp)
        or part in ("py2.py3",)
        for part in py_parts
    )
    abi_ok = any(
        part in ("none", "abi3", cp, cp + "m") or part.startswith("cp")
        for part in abi_parts
    )
    system, arch = _platform_tokens()
    platform_ok = False
    for part in platform_parts:
        if part == "any":
            platform_ok = True
            break
        if system == "windows":
            if part.startswith("win") and (arch in part or part in ("win32",) and arch == "i686"):
                platform_ok = True
        elif system == "linux":
            if ("linux" in part or "manylinux" in part or "musllinux" in part) and (arch in part or "any" in part):
                platform_ok = True
        elif system == "darwin":
            if "macosx" in part and (arch in part or "universal2" in part or "universal" in part):
                platform_ok = True
        if platform_ok:
            break
    if not py_ok:
        return False, f"Python tag {tags['python_tag']} does not match Python {python_version}"
    if not abi_ok:
        return False, f"ABI tag {tags['abi_tag']} is not compatible"
    if not platform_ok:
        return False, f"Platform tag {tags['platform_tag']} does not match {system}/{arch}"
    return True, ""


# ---------------------------------------------------------------------------
# Lock files
# ---------------------------------------------------------------------------

def lock_from_wheels(
    plugin_id: str,
    wheel_paths: Sequence[Path],
    *,
    interpreter: Optional[Sequence[str]] = None,
    runtime: str = "python",
) -> Dict[str, Any]:
    if not ID_RE.fullmatch(plugin_id):
        raise ValueError(f"Invalid plugin id: {plugin_id!r}")
    command = list(interpreter or (find_python() or {}).get("command") or [])
    version = python_version_of(command) if command else platform.python_version()
    wheels = []
    errors = []
    for path in wheel_paths:
        path = Path(path)
        if not path.is_file():
            errors.append(f"Missing wheel: {path}")
            continue
        try:
            tags = parse_wheel_filename(path.name)
            compatible, reason = wheel_compatible(path.name, version) if version else (True, "")
            if not compatible:
                errors.append(f"{path.name}: {reason}")
                continue
            wheels.append({
                "filename": path.name,
                "sha256": sha256_file(path),
                "size": path.stat().st_size,
                **tags,
                "compatible": compatible,
            })
        except Exception as exc:
            errors.append(f"{path.name}: {exc}")
    if errors:
        raise ValueError("; ".join(errors))
    if not wheels:
        raise ValueError("No wheels selected.")
    return {
        "format": "qah-runtime-lock",
        "version": 1,
        "plugin_id": plugin_id,
        "runtime": runtime,
        "python": version,
        "interpreter": command[-1] if command and command[0] == command[-1] else " ".join(command),
        "wheels": wheels,
        "created": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }


def load_lock(path: Path) -> Dict[str, Any]:
    value = _read_json(Path(path), {})
    if not isinstance(value, dict) or value.get("format") != "qah-runtime-lock":
        raise ValueError("Not a Runtime Forge lock file.")
    return value


# ---------------------------------------------------------------------------
# Download / extraction
# ---------------------------------------------------------------------------

def download_wheel(url: str, destination: Path, expected_sha256: str = "") -> Path:
    from urllib.request import urlopen
    from urllib.parse import urlparse

    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    parsed = urlparse(url)
    if parsed.scheme == "file":
        source = Path(parsed.path)
        shutil.copyfile(source, destination)
    elif parsed.scheme in ("http", "https"):
        with urlopen(url, timeout=60) as response, open(destination, "wb") as output:
            shutil.copyfileobj(response, output)
    else:
        raise ValueError(f"Unsupported wheel URL: {url}")
    if expected_sha256 and sha256_file(destination).lower() != expected_sha256.lower():
        try:
            destination.unlink()
        except OSError:
            pass
        raise ValueError(f"SHA256 mismatch for {destination.name}")
    return destination


def _safe_extract_wheel(wheel: Path, site_packages: Path, bin_dir: Path) -> int:
    count = 0
    dist = parse_wheel_filename(wheel.name)["distribution"]
    with zipfile.ZipFile(wheel) as archive:
        for info in archive.infolist():
            name = info.filename.replace("\\", "/")
            if not name or name.endswith("/"):
                continue
            parts = Path(name).parts
            if name.startswith("/") or ".." in parts:
                raise ValueError(f"Unsafe path in wheel: {name}")
            target_base = site_packages
            for prefix in (f"{dist}.data/purelib/", f"{dist}.data/platlib/"):
                if name.startswith(prefix):
                    name = name[len(prefix):]
                    break
            else:
                if name.startswith(f"{dist}.data/scripts/"):
                    target_base = bin_dir
                    name = name[len(f"{dist}.data/scripts/"):]
                elif name.startswith(f"{dist}.data/"):
                    continue
            if not name:
                continue
            target = target_base.joinpath(*Path(name).parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info) as source, open(target, "wb") as output:
                shutil.copyfileobj(source, output)
            count += 1
    return count


# ---------------------------------------------------------------------------
# Install / lifecycle
# ---------------------------------------------------------------------------

def install_lock(
    plugin_id: str,
    lock: Dict[str, Any],
    *,
    wheel_sources: Optional[Dict[str, Path]] = None,
    cache_dir: Optional[Path] = None,
    progress=None,
) -> Dict[str, Any]:
    if lock.get("plugin_id") not in ("", plugin_id):
        raise ValueError("Lock file belongs to a different plugin id.")
    root = runtime_root(plugin_id)
    cache = Path(cache_dir) if cache_dir else wheel_cache_dir()
    cache.mkdir(parents=True, exist_ok=True)
    sources = {name: Path(path) for name, path in (wheel_sources or {}).items()}
    build = time.strftime("%Y%m%d-%H%M%S")
    staging = root / "versions" / f".{build}.tmp"
    final = root / "versions" / build
    site_packages = staging / "site-packages"
    bin_dir = staging / "bin"
    site_packages.mkdir(parents=True, exist_ok=True)
    bin_dir.mkdir(parents=True, exist_ok=True)
    installed = []
    try:
        for index, wheel in enumerate(lock.get("wheels") or [], 1):
            filename = str(wheel.get("filename") or "")
            if not filename:
                raise ValueError("Lock entry has no filename.")
            source = sources.get(filename)
            if source is None:
                source = cache / filename
            if not source.is_file():
                url = str(wheel.get("url") or "")
                if not url:
                    raise ValueError(f"Wheel not found and no URL: {filename}")
                if progress:
                    progress(f"Downloading {filename}...")
                source = download_wheel(url, cache / filename, str(wheel.get("sha256") or ""))
            expected = str(wheel.get("sha256") or "")
            if expected and sha256_file(source).lower() != expected.lower():
                raise ValueError(f"SHA256 mismatch: {filename}")
            compatible, reason = wheel_compatible(
                filename, str(lock.get("python") or platform.python_version())
            )
            if not compatible:
                raise ValueError(f"{filename}: {reason}")
            if progress:
                progress(f"Installing {index}/{len(lock.get('wheels') or [])}: {filename}")
            _safe_extract_wheel(source, site_packages, bin_dir)
            installed.append(filename)
        _write_json(staging / "lock.json", lock)
        _write_json(staging / "build.json", {
            "build": build,
            "created": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "wheels": installed,
        })
        if final.exists():
            shutil.rmtree(final, ignore_errors=True)
        staging.rename(final)
        previous = current_build(plugin_id)
        current = {
            "plugin_id": plugin_id,
            "build": build,
            "previous": previous or "",
            "site_packages": str(final / "site-packages"),
            "bin": str(final / "bin"),
            "python": str(lock.get("python") or ""),
            "interpreter": str(lock.get("interpreter") or ""),
            "wheels": installed,
            "updated": time.strftime("%Y-%m-%dT%H:%M:%S"),
        }
        _write_json(root / "current.json", current)
        _sentinel_watch(plugin_id, final)
        return current
    except Exception:
        shutil.rmtree(staging, ignore_errors=True)
        raise


def current_build(plugin_id: str) -> Optional[Dict[str, Any]]:
    root = runtime_root(plugin_id)
    current = _read_json(root / "current.json", {})
    return current if isinstance(current, dict) and current.get("build") else None


def activate_build(plugin_id: str, build: str) -> Dict[str, Any]:
    root = runtime_root(plugin_id)
    build_dir = root / "versions" / build
    lock = _read_json(build_dir / "lock.json", {})
    if not lock:
        raise ValueError(f"Build not found: {build}")
    current = {
        "plugin_id": plugin_id,
        "build": build,
        "previous": (current_build(plugin_id) or {}).get("build", ""),
        "site_packages": str(build_dir / "site-packages"),
        "bin": str(build_dir / "bin"),
        "python": str(lock.get("python") or ""),
        "interpreter": str(lock.get("interpreter") or ""),
        "wheels": [item.get("filename") for item in lock.get("wheels") or []],
        "updated": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    _write_json(root / "current.json", current)
    return current


def rollback(plugin_id: str) -> Dict[str, Any]:
    current = current_build(plugin_id)
    if not current:
        raise ValueError("No active runtime.")
    previous = str(current.get("previous") or "")
    if not previous:
        raise ValueError("No previous runtime to roll back to.")
    return activate_build(plugin_id, previous)


def list_builds(plugin_id: str) -> List[str]:
    root = runtime_root(plugin_id)
    versions = root / "versions"
    if not versions.is_dir():
        return []
    return sorted(
        [path.name for path in versions.iterdir() if path.is_dir() and not path.name.startswith(".")],
        reverse=True,
    )


def list_runtimes() -> List[Dict[str, Any]]:
    result = []
    root = runtimes_dir()
    for child in sorted(root.iterdir()):
        if not child.is_dir() or not ID_RE.fullmatch(child.name):
            continue
        current = current_build(child.name)
        result.append({
            "plugin_id": child.name,
            "path": str(child),
            "current": current or {},
            "builds": list_builds(child.name),
        })
    return result


def remove_runtime(plugin_id: str) -> None:
    root = runtime_root(plugin_id)
    shutil.rmtree(root, ignore_errors=True)


def doctor(plugin_id: str) -> Dict[str, Any]:
    current = current_build(plugin_id)
    if not current:
        return {"ok": False, "detail": "No active runtime."}
    site_packages = Path(current.get("site_packages", ""))
    problems = []
    if not site_packages.is_dir():
        problems.append("site-packages is missing")
    lock = _read_json(Path(site_packages).parent / "lock.json", {})
    wheels = lock.get("wheels") or []
    if not wheels:
        problems.append("lock has no wheels")
    interpreter = current.get("interpreter") or ""
    probe = None
    if interpreter:
        command = [interpreter] if Path(interpreter).exists() else interpreter.split()
        probe = _probe(command)
    if not probe:
        found = find_python()
        probe = found
        if not found:
            problems.append("no Python interpreter found")
    return {
        "ok": not problems,
        "plugin_id": plugin_id,
        "current": current,
        "wheels": len(wheels),
        "interpreter": (probe or {}).get("version", ""),
        "problems": problems,
    }


def _sentinel_watch(plugin_id: str, build_dir: Path) -> None:
    try:
        from plugin_sentinel import sentinel_api  # type: ignore

        sentinel_api.watch_path(build_dir, "runtime", f"{plugin_id} runtime {build_dir.name}")
        for suffix in ("*.dll", "*.so", "*.dylib", "*.pyd"):
            for library in (build_dir / "site-packages").rglob(suffix):
                try:
                    sentinel_api.watch_library(library)
                except Exception:
                    pass
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Runtime host
# ---------------------------------------------------------------------------

def host_path() -> Path:
    return Path(__file__).with_name(HOST_NAME)


def _interpreter_command(current: Dict[str, Any]) -> List[str]:
    text = str(current.get("interpreter") or "").strip()
    if text:
        if " " in text and not Path(text).exists():
            return text.split()
        if Path(text).exists():
            return [text]
    found = find_python()
    if not found:
        raise RuntimeError("No Python interpreter available for the runtime host.")
    return list(found["command"])


def run_host(plugin_id: str, request: Dict[str, Any], timeout: int = 30) -> Dict[str, Any]:
    current = current_build(plugin_id)
    if not current:
        raise ValueError("No active runtime.")
    site_packages = str(current.get("site_packages") or "")
    command = _interpreter_command(current) + [
        "-I", "-u", str(host_path()), "--site-packages", site_packages,
    ]
    payload = json.dumps(request, ensure_ascii=False) + "\n"
    try:
        completed = subprocess.run(
            command,
            input=payload,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=str(Path(site_packages).parent.parent),
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0,
        )
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": f"Runtime host timed out after {timeout}s"}
    for line in reversed(completed.stdout.splitlines()):
        line = line.strip()
        if line.startswith("{"):
            try:
                return json.loads(line)
            except Exception:
                continue
    return {
        "ok": False,
        "error": "Runtime host produced no JSON response.",
        "stdout": completed.stdout[-8000:],
        "stderr": completed.stderr[-8000:],
    }


def ping(plugin_id: str) -> Dict[str, Any]:
    return run_host(plugin_id, {"id": 1, "method": "ping"})


def import_module(plugin_id: str, module: str) -> Dict[str, Any]:
    return run_host(plugin_id, {"id": 1, "method": "import", "params": {"module": module}})


def call(plugin_id: str, module: str, function: str, args=None, kwargs=None) -> Dict[str, Any]:
    return run_host(plugin_id, {
        "id": 1,
        "method": "call",
        "params": {"module": module, "function": function, "args": args or [], "kwargs": kwargs or {}},
    })


def execute(plugin_id: str, code: str) -> Dict[str, Any]:
    return run_host(plugin_id, {"id": 1, "method": "exec", "params": {"code": code}})
