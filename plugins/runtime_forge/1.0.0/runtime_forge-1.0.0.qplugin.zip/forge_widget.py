"""PySide6 UI for Runtime Forge."""

from __future__ import annotations

import json
import time
import traceback
from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt, QThread, Signal, QUrl
from PySide6.QtGui import QDesktopServices, QFont
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QListWidget,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSplitter,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from . import forge_core as forge
from .forge_docs import DOCS_HTML


class ForgeTask(QThread):
    done = Signal(object)
    failed = Signal(str)
    log = Signal(str)

    def __init__(self, function, parent=None):
        super().__init__(parent)
        self._function = function

    def run(self):
        try:
            self.done.emit(self._function(self.log.emit))
        except Exception:
            self.failed.emit(traceback.format_exc())


class RuntimeForgeWidget(QWidget):
    def __init__(self, plugin=None, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.wheels: list[Path] = []
        self.lock: Optional[dict] = None
        self.task: Optional[ForgeTask] = None
        self._build_ui()
        self._detect_interpreter()
        self.refresh_runtimes()

    # -- UI --------------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        header = QHBoxLayout()
        title = QLabel("<b>Runtime Forge</b>")
        title.setFont(QFont("Segoe UI", 15, QFont.Weight.Bold))
        header.addWidget(title)
        subtitle = QLabel("Isolated per-plugin Python runtimes · hash-locked wheels · JSON-RPC host")
        subtitle.setStyleSheet("color:#6b7280;")
        header.addWidget(subtitle, 1)
        self.status = QLabel("Ready")
        self.status.setStyleSheet("color:#6b7280;")
        header.addWidget(self.status)
        layout.addLayout(header)

        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, 1)
        self._build_runtimes_tab()
        self._build_builder_tab()
        self._build_host_tab()
        self._build_docs_tab()

    def _build_runtimes_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        row = QHBoxLayout()
        refresh = QPushButton("Refresh")
        refresh.clicked.connect(self.refresh_runtimes)
        row.addWidget(refresh)
        new = QPushButton("New runtime…")
        new.clicked.connect(lambda: self.tabs.setCurrentIndex(1))
        row.addWidget(new)
        doctor = QPushButton("Doctor selected")
        doctor.clicked.connect(self.doctor_selected)
        row.addWidget(doctor)
        rollback = QPushButton("Rollback selected")
        rollback.clicked.connect(self.rollback_selected)
        row.addWidget(rollback)
        remove = QPushButton("Remove selected")
        remove.clicked.connect(self.remove_selected)
        row.addWidget(remove)
        open_folder = QPushButton("Open folder")
        open_folder.clicked.connect(self.open_selected_folder)
        row.addWidget(open_folder)
        row.addStretch(1)
        layout.addLayout(row)

        self.runtime_table = QTableWidget(0, 6)
        self.runtime_table.setHorizontalHeaderLabels(["Plugin", "Python", "Build", "Wheels", "Updated", "Path"])
        self.runtime_table.verticalHeader().setVisible(False)
        self.runtime_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.runtime_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.runtime_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.runtime_table.horizontalHeader().setStretchLastSection(True)
        self.runtime_table.itemSelectionChanged.connect(self._update_runtime_buttons)
        layout.addWidget(self.runtime_table, 1)
        self.runtime_detail = QPlainTextEdit()
        self.runtime_detail.setReadOnly(True)
        self.runtime_detail.setFont(QFont("Consolas", 9))
        self.runtime_detail.setPlaceholderText("Select a runtime to see its current build and lock details.")
        layout.addWidget(self.runtime_detail)
        self.tabs.addTab(tab, "Runtimes")

    def _build_builder_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        form_box = QGroupBox("Runtime profile")
        form = QFormLayout(form_box)
        self.plugin_id_edit = QLineEdit()
        self.plugin_id_edit.setPlaceholderText("e.g. pydft_plugin")
        form.addRow("Plugin id:", self.plugin_id_edit)
        interpreter_row = QHBoxLayout()
        self.interpreter_edit = QLineEdit()
        self.interpreter_edit.setPlaceholderText("python.exe, python3, or py -3")
        interpreter_row.addWidget(self.interpreter_edit, 1)
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse_interpreter)
        interpreter_row.addWidget(browse)
        form.addRow("Python interpreter:", interpreter_row)
        self.interpreter_label = QLabel("")
        self.interpreter_label.setStyleSheet("color:#6b7280;")
        form.addRow("", self.interpreter_label)
        layout.addWidget(form_box)

        wheels_box = QGroupBox("Wheels")
        wheels_layout = QVBoxLayout(wheels_box)
        self.wheel_list = QListWidget()
        self.wheel_list.setAlternatingRowColors(True)
        wheels_layout.addWidget(self.wheel_list, 1)
        row = QHBoxLayout()
        add = QPushButton("Add wheel files…")
        add.clicked.connect(self.add_wheels)
        row.addWidget(add)
        add_dir = QPushButton("Add wheelhouse folder…")
        add_dir.clicked.connect(self.add_wheelhouse)
        row.addWidget(add_dir)
        remove = QPushButton("Remove")
        remove.clicked.connect(self.remove_wheels)
        row.addWidget(remove)
        clear = QPushButton("Clear")
        clear.clicked.connect(self.clear_wheels)
        row.addWidget(clear)
        row.addStretch(1)
        wheels_layout.addLayout(row)
        layout.addWidget(wheels_box, 1)

        self.lock_preview = QPlainTextEdit()
        self.lock_preview.setReadOnly(True)
        self.lock_preview.setFont(QFont("Consolas", 9))
        self.lock_preview.setPlaceholderText("Lock preview appears here.")
        layout.addWidget(self.lock_preview)
        row = QHBoxLayout()
        build = QPushButton("Build lock")
        build.clicked.connect(self.build_lock)
        row.addWidget(build)
        save = QPushButton("Save lock…")
        save.clicked.connect(self.save_lock)
        row.addWidget(save)
        install = QPushButton("Install runtime")
        install.clicked.connect(self.install_runtime)
        row.addWidget(install)
        row.addStretch(1)
        layout.addLayout(row)
        self.builder_log = QPlainTextEdit()
        self.builder_log.setReadOnly(True)
        self.builder_log.setMaximumHeight(130)
        self.builder_log.setFont(QFont("Consolas", 9))
        layout.addWidget(self.builder_log)
        self.tabs.addTab(tab, "Builder")

    def _build_host_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        row = QHBoxLayout()
        row.addWidget(QLabel("Runtime:"))
        self.host_runtime = QComboBox()
        row.addWidget(self.host_runtime, 1)
        row.addWidget(QLabel("Method:"))
        self.host_method = QComboBox()
        self.host_method.addItems(["Ping", "Import module", "Call function", "Execute code"])
        row.addWidget(self.host_method)
        run = QPushButton("Run")
        run.clicked.connect(self.run_host)
        row.addWidget(run)
        layout.addLayout(row)

        form = QFormLayout()
        self.host_module = QLineEdit()
        self.host_module.setPlaceholderText("pydft")
        form.addRow("Module:", self.host_module)
        self.host_function = QLineEdit()
        self.host_function.setPlaceholderText("function_name")
        form.addRow("Function:", self.host_function)
        self.host_args = QLineEdit()
        self.host_args.setPlaceholderText("[1, 2]")
        form.addRow("Args JSON:", self.host_args)
        self.host_kwargs = QLineEdit()
        self.host_kwargs.setPlaceholderText('{"key": "value"}')
        form.addRow("Kwargs JSON:", self.host_kwargs)
        layout.addLayout(form)
        layout.addWidget(QLabel("Code:"))
        self.host_code = QPlainTextEdit()
        self.host_code.setFont(QFont("Consolas", 9))
        self.host_code.setPlaceholderText("result = 1 + 1")
        layout.addWidget(self.host_code, 1)
        self.host_output = QPlainTextEdit()
        self.host_output.setReadOnly(True)
        self.host_output.setFont(QFont("Consolas", 9))
        layout.addWidget(self.host_output, 1)
        self.tabs.addTab(tab, "Host")

    def _build_docs_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        browser = QTextBrowser()
        browser.setOpenExternalLinks(False)
        browser.setHtml(DOCS_HTML)
        layout.addWidget(browser, 1)
        self.tabs.addTab(tab, "Documentation")

    # -- helpers ---------------------------------------------------------
    def _log(self, text):
        self.builder_log.appendPlainText(str(text))
        bar = self.builder_log.verticalScrollBar()
        bar.setValue(bar.maximum())

    def _detect_interpreter(self):
        found = forge.find_python()
        if found:
            command = found["command"]
            text = command[0] if len(command) == 1 else " ".join(command)
            self.interpreter_edit.setText(text)
            self.interpreter_label.setText(f"Detected Python {found['version']}")
        else:
            self.interpreter_label.setText("No Python interpreter found. Select one manually.")
            self.interpreter_label.setStyleSheet("color:#b91c1c;")

    def _browse_interpreter(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Python interpreter", str(Path.home()),
            "Executables (*.exe python python3 python3.*);;All files (*)",
        )
        if path:
            self.interpreter_edit.setText(path)

    def _interpreter_command(self):
        text = self.interpreter_edit.text().strip()
        if not text:
            return []
        return [text] if Path(text).exists() else text.split()

    def _selected_runtime(self):
        rows = self.runtime_table.selectionModel().selectedRows()
        if not rows:
            return None
        item = self.runtime_table.item(rows[0].row(), 0)
        return item.data(Qt.ItemDataRole.UserRole) if item else None

    def _update_runtime_buttons(self):
        self._show_runtime_detail()

    def refresh_runtimes(self):
        runtimes = forge.list_runtimes()
        self.runtime_table.setRowCount(0)
        self.host_runtime.clear()
        for item in runtimes:
            current = item.get("current") or {}
            row = self.runtime_table.rowCount()
            self.runtime_table.insertRow(row)
            values = [
                item.get("plugin_id", ""),
                current.get("python", ""),
                current.get("build", ""),
                str(len(current.get("wheels") or [])),
                current.get("updated", ""),
                item.get("path", ""),
            ]
            for col, value in enumerate(values):
                cell = QTableWidgetItem(str(value))
                cell.setData(Qt.ItemDataRole.UserRole, item.get("plugin_id"))
                self.runtime_table.setItem(row, col, cell)
            self.host_runtime.addItem(item.get("plugin_id", ""), item.get("plugin_id"))
        self.status.setText(f"{len(runtimes)} runtime(s)")

    def _show_runtime_detail(self):
        plugin_id = self._selected_runtime()
        if not plugin_id:
            return
        current = forge.current_build(plugin_id) or {}
        self.runtime_detail.setPlainText(json.dumps({
            "plugin_id": plugin_id,
            "current": current,
            "builds": forge.list_builds(plugin_id),
        }, indent=2))

    def doctor_selected(self):
        plugin_id = self._selected_runtime()
        if not plugin_id:
            QMessageBox.information(self, "Runtime Forge", "Select a runtime first.")
            return
        self._run_task(f"Doctor {plugin_id}...", lambda log: forge.doctor(plugin_id), self._show_doctor)

    def _show_doctor(self, result):
        self.runtime_detail.setPlainText(json.dumps(result, indent=2))
        self.status.setText("Doctor: " + ("OK" if result.get("ok") else "problems found"))

    def rollback_selected(self):
        plugin_id = self._selected_runtime()
        if not plugin_id:
            return
        try:
            current = forge.rollback(plugin_id)
            self.status.setText(f"Rolled back to {current.get('build')}")
            self.refresh_runtimes()
        except Exception as exc:
            QMessageBox.critical(self, "Runtime Forge", str(exc))

    def remove_selected(self):
        plugin_id = self._selected_runtime()
        if not plugin_id:
            return
        if QMessageBox.question(
            self, "Remove runtime",
            f"Delete the isolated runtime for {plugin_id}?",
            QMessageBox.Yes | QMessageBox.No,
        ) == QMessageBox.Yes:
            try:
                forge.remove_runtime(plugin_id)
                self.refresh_runtimes()
            except Exception as exc:
                QMessageBox.critical(self, "Runtime Forge", str(exc))

    def open_selected_folder(self):
        plugin_id = self._selected_runtime()
        if not plugin_id:
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(forge.runtime_root(plugin_id))))

    # -- builder ---------------------------------------------------------
    def add_wheels(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Add wheels", str(Path.home()), "Wheels (*.whl);;All files (*)"
        )
        self._add_wheel_paths([Path(path) for path in paths])

    def add_wheelhouse(self):
        directory = QFileDialog.getExistingDirectory(self, "Select wheelhouse folder")
        if not directory:
            return
        self._add_wheel_paths(sorted(Path(directory).glob("*.whl")))

    def _add_wheel_paths(self, paths):
        existing = {str(path.resolve()) for path in self.wheels}
        for path in paths:
            if path.suffix.lower() == ".whl" and str(path.resolve()) not in existing:
                self.wheels.append(path)
                existing.add(str(path.resolve()))
                self.wheel_list.addItem(path.name)
        self.lock = None

    def remove_wheels(self):
        for item in self.wheel_list.selectedItems():
            row = self.wheel_list.row(item)
            self.wheel_list.takeItem(row)
            if 0 <= row < len(self.wheels):
                self.wheels.pop(row)
        self.lock = None

    def clear_wheels(self):
        self.wheels.clear()
        self.wheel_list.clear()
        self.lock = None
        self.lock_preview.clear()

    def build_lock(self):
        plugin_id = self.plugin_id_edit.text().strip()
        if not forge.ID_RE.fullmatch(plugin_id):
            QMessageBox.warning(self, "Runtime Forge", "Enter a valid plugin id (lowercase, underscores).")
            return
        if not self.wheels:
            QMessageBox.warning(self, "Runtime Forge", "Add at least one wheel.")
            return
        try:
            self.lock = forge.lock_from_wheels(
                plugin_id, self.wheels,
                interpreter=self._interpreter_command() or None,
            )
        except Exception as exc:
            QMessageBox.critical(self, "Runtime Forge", str(exc))
            return
        self.lock_preview.setPlainText(json.dumps(self.lock, indent=2))
        self.status.setText(f"Lock built: {len(self.lock['wheels'])} wheel(s)")

    def save_lock(self):
        if not self.lock:
            self.build_lock()
        if not self.lock:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save runtime lock", str(Path.home() / f"{self.lock['plugin_id']}.lock.json"),
            "Runtime lock (*.json);;All files (*)",
        )
        if not path:
            return
        Path(path).write_text(json.dumps(self.lock, indent=2), encoding="utf-8")
        self.status.setText(f"Lock saved to {path}")

    def install_runtime(self):
        if not self.lock:
            self.build_lock()
        if not self.lock:
            return
        plugin_id = self.lock["plugin_id"]
        sources = {path.name: path for path in self.wheels}
        self._log(f"Installing runtime for {plugin_id}...")
        self._run_task(
            f"Installing {plugin_id}...",
            lambda log: forge.install_lock(plugin_id, self.lock, wheel_sources=sources, progress=log),
            self._installed,
        )

    def _installed(self, current):
        self._log(f"Installed build {current.get('build')} with {len(current.get('wheels') or [])} wheel(s).")
        self.refresh_runtimes()
        self.tabs.setCurrentIndex(0)
        self.status.setText(f"Runtime {current.get('plugin_id')} ready")

    # -- host ------------------------------------------------------------
    def run_host(self):
        plugin_id = self.host_runtime.currentData()
        if not plugin_id:
            QMessageBox.information(self, "Runtime Forge", "Install/select a runtime first.")
            return
        method = self.host_method.currentText()
        try:
            if method == "Ping":
                function = lambda log: forge.ping(plugin_id)
            elif method == "Import module":
                module = self.host_module.text().strip()
                function = lambda log: forge.import_module(plugin_id, module)
            elif method == "Call function":
                module = self.host_module.text().strip()
                function_name = self.host_function.text().strip()
                args = json.loads(self.host_args.text() or "[]")
                kwargs = json.loads(self.host_kwargs.text() or "{}")
                function = lambda log: forge.call(plugin_id, module, function_name, args, kwargs)
            else:
                code = self.host_code.toPlainText()
                function = lambda log: forge.execute(plugin_id, code)
        except Exception as exc:
            QMessageBox.critical(self, "Runtime Forge", f"Invalid request: {exc}")
            return
        self._run_task("Running runtime host...", function, self._show_host_result)

    def _show_host_result(self, result):
        self.host_output.setPlainText(json.dumps(result, indent=2, default=str))
        self.status.setText("Host request finished")

    # -- task ------------------------------------------------------------
    def _run_task(self, label, function, on_done):
        if self.task is not None and self.task.isRunning():
            QMessageBox.information(self, "Runtime Forge", "Another operation is running.")
            return
        task = ForgeTask(function, self)
        task.log.connect(self._log)
        task.done.connect(on_done)
        task.failed.connect(self._on_task_failed)
        task.finished.connect(lambda t=task: self._on_task_finished(t))
        self.task = task
        self.status.setText(label)
        task.start()

    def _on_task_failed(self, text):
        self._log(text)
        self.status.setText("Operation failed")
        QMessageBox.critical(self, "Runtime Forge", "See the log for the traceback.")

    def _on_task_finished(self, task):
        if self.task is task:
            self.task = None
        task.deleteLater()

    def cleanup(self):
        task = self.task
        if task is not None:
            try:
                task.finished.disconnect()
            except Exception:
                pass
            if task.isRunning():
                task.wait(5000)
            if task.isRunning():
                task.setParent(None)
                task.finished.connect(task.deleteLater)
            else:
                task.deleteLater()
        self.task = None
