"""Documentation HTML for Runtime Forge."""

from __future__ import annotations

DOCS_HTML = """
<html><head><style>
body{font-family:'Segoe UI',Arial,sans-serif;font-size:10pt;color:#1f2937}
h1{font-size:17pt;color:#0f172a}h2{font-size:12.5pt;color:#1d4ed8;margin-top:16px}
h3{font-size:11pt;color:#111827;margin-top:12px}
code{background:#f3f4f6;padding:1px 3px}pre{background:#f3f4f6;padding:8px;border:1px solid #e5e7eb}
.warn{color:#b91c1c;font-weight:bold}.muted{color:#6b7280}
</style></head><body>
<h1>Runtime Forge Documentation</h1>
<p class="muted">Isolated per-plugin runtimes, hash-locked wheels, JSON-RPC host.</p>

<h2>1. What this MVP does</h2>
<ul>
<li>Installs pre-built wheels into a per-plugin <code>site-packages</code>.</li>
<li>Stores a lock file with SHA256 hashes and platform tags.</li>
<li>Runs plugin code through a separate JSON-RPC host.</li>
<li>Keeps previous builds for rollback.</li>
<li>Does <b>not</b> run pip, setup.py, sdists, cargo or arbitrary build scripts.</li>
</ul>
<p class="warn">A Python environment is not a security boundary. Use Plugin Sentinel's
sandbox and native inspection for untrusted artifacts.</p>

<h2>2. Runtime layout</h2>
<pre>%USERPROFILE%\\QAH\\runtimes\\&lt;plugin_id&gt;\\
  current.json
  versions\\&lt;build&gt;\\site-packages\\
  versions\\&lt;build&gt;\\bin\\
  versions\\&lt;build&gt;\\lock.json
  versions\\&lt;build&gt;\\build.json</pre>

<h2>3. Lock file</h2>
<pre>{
  "format": "qah-runtime-lock",
  "version": 1,
  "plugin_id": "pydft_plugin",
  "runtime": "python",
  "python": "3.12.5",
  "interpreter": "C:\\\\Python312\\\\python.exe",
  "wheels": [
    {
      "filename": "pydft-0.1.0-py3-none-any.whl",
      "sha256": "...",
      "size": 12345,
      "python_tag": "py3",
      "abi_tag": "none",
      "platform_tag": "any"
    }
  ]
}</pre>
<p>Builds reject wheels whose Python, ABI or platform tags do not match the
selected interpreter/platform. <code>pydft</code> is normally pure Python; if it
needs numpy/scipy, add their platform wheels to the same lock.</p>

<h2>4. Python interpreter</h2>
<p>Runtime Forge probes <code>python3</code>, <code>python</code> and (on Windows)
<code>py -3</code>. QAH's Briefcase Windows bundle often has no
<code>python.exe</code>, so select a portable/system Python interpreter in the
Builder. The runtime is isolated by its own <code>site-packages</code>; the
interpreter itself is shared.</p>

<h2>5. Host protocol</h2>
<p>The runtime host is started with:</p>
<pre>python -I -u runtime_host.py --site-packages &lt;runtime site-packages&gt;</pre>
<p>Requests are one JSON object per line:</p>
<pre>{"id": 1, "method": "ping"}
{"id": 1, "method": "import", "params": {"module": "pydft"}}
{"id": 1, "method": "call", "params": {"module": "pydft", "function": "add", "args": [1, 2]}}
{"id": 1, "method": "exec", "params": {"code": "result = 6 * 7"}}</pre>
<p>Responses are JSON. Plugin prints are captured and returned in
<code>stdout</code>; they never corrupt the protocol.</p>

<h2>6. Rust and native artifacts</h2>
<p>Rust has no runtime to install. Ship a compiled wheel (maturin) or a prebuilt
binary for each platform. Runtime Forge installs wheels; native binaries should
be placed in the runtime <code>bin</code> or shipped in a wheel. Validate them
with Plugin Sentinel's native scanner; never require cargo on the user machine.</p>

<h2>7. Sentinel integration</h2>
<p>After installation, Runtime Forge registers the build directory with
<code>plugin_sentinel.sentinel_api.watch_path</code> and watches native files in
<code>site-packages</code> when Sentinel is installed. Run the host under
Sentinel's sandbox for behavioural testing.</p>

<h2>8. Limitations</h2>
<ul>
<li>MVP has no dependency resolver; the lock must list all wheels.</li>
<li>Wheels only; no sdists/setup.py builds.</li>
<li>The interpreter is shared; only <code>site-packages</code> is isolated.</li>
<li>No automatic Python download yet; choose a portable interpreter on Windows.</li>
<li>Functions return JSON-serializable values or <code>repr()</code>.</li>
</ul>

<h2>9. CLI</h2>
<pre>python runtime_forge_cli.py list
python runtime_forge_cli.py lock --plugin pydft_plugin --wheels *.whl --out pydft.lock.json
python runtime_forge_cli.py install pydft.lock.json --wheel-dir .
python runtime_forge_cli.py doctor pydft_plugin
python runtime_forge_cli.py ping pydft_plugin
python runtime_forge_cli.py import pydft_plugin pydft
python runtime_forge_cli.py call pydft_plugin pydft add --args "[1,2]"</pre>

</body></html>
"""
