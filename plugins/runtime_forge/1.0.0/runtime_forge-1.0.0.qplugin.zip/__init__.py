"""Runtime Forge - isolated per-plugin runtimes for QAH.

GPLv3 or later.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QObject
from PySide6.QtGui import QAction, QIcon
from PySide6.QtWidgets import QWidget

try:
    from plugins.libs.plugin_manager import PluginInfo
except Exception:
    PluginInfo = object  # type: ignore


class RuntimeForge(QObject):
    def __init__(self, plugin_info: PluginInfo):
        super().__init__()
        self.plugin_info = plugin_info
        self.ui_widget: Optional[QWidget] = None
        self.icon: Optional[QIcon] = None
        icon_path = Path(__file__).parent / "icon.svg"
        if icon_path.is_file():
            self.icon = QIcon(str(icon_path))

    def initialize(self) -> bool:
        logging.info("Initializing %s v%s", self.plugin_info.name, self.plugin_info.version)
        return True

    def get_widget(self) -> Optional[QWidget]:
        if self.ui_widget is None:
            try:
                from .forge_widget import RuntimeForgeWidget

                self.ui_widget = RuntimeForgeWidget(self)
            except Exception as exc:
                logging.error("Could not build Runtime Forge: %s", exc)
                logging.debug("Traceback", exc_info=True)
                return None
        return self.ui_widget

    def get_menu_actions(self):
        action = QAction("Runtime Forge", self)
        if self.icon is not None:
            action.setIcon(self.icon)
        action.setToolTip("Isolated per-plugin runtimes with hash-locked wheels")
        return [action]

    def cleanup(self):
        if self.ui_widget is not None:
            try:
                if hasattr(self.ui_widget, "cleanup"):
                    self.ui_widget.cleanup()
            finally:
                self.ui_widget.deleteLater()
                self.ui_widget = None


Plugin = RuntimeForge
