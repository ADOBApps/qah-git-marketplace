"""Injected dependency discovery for Plugin Sentinel.

Wheel Plugin Manager can inject pre-built wheels for QAH's frozen Python under
``<QAH home>/plugins/vendor/<target>``. Those packages are not QAH plugins, so
they do not appear in the normal plugin inventory. This module exposes them as
read-only dependency sets for the Sentinel Dependencies tab.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List

MANIFEST_NAME = "qah_dependencies.json"


def qah_home() -> Path:
    override = os.environ.get("QAH_HOME")
    return Path(override).expanduser() if override else Path.home() / "QAH"


def vendor_dir(create: bool = False) -> Path:
    override = os.environ.get("QAH_VENDOR_DIR")
    root = Path(override).expanduser() if override else qah_home() / "plugins" / "vendor"
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def discover_dependency_sets() -> List[Dict[str, Any]]:
    root = vendor_dir(create=False)
    result: List[Dict[str, Any]] = []
    if not root.is_dir():
        return result
    for child in sorted(root.iterdir()):
        if not child.is_dir() or child.name.startswith("."):
            continue
        manifest = child / MANIFEST_NAME
        if not manifest.is_file():
            continue
        try:
            data = json.loads(manifest.read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(data, dict):
            continue
        data["path"] = str(child)
        data["target"] = str(data.get("target") or child.name)
        data.setdefault("packages", [])
        data.setdefault("wheels", [])
        result.append(data)
    return result


def dependency_rows() -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []
    for item in discover_dependency_sets():
        packages = item.get("packages") or []
        if not packages:
            rows.append({
                "target": str(item.get("target", "")),
                "package": "(empty set)",
                "version": "",
                "python": str(item.get("python", "")),
                "platform": str(item.get("platform", "")),
                "path": str(item.get("path", "")),
            })
            continue
        for package in packages:
            rows.append({
                "target": str(item.get("target", "")),
                "package": str(package.get("name", "")),
                "version": str(package.get("version", "")),
                "python": str(item.get("python", "")),
                "platform": str(item.get("platform", "")),
                "path": str(item.get("path", "")),
            })
    return rows


def summary_text() -> str:
    sets = discover_dependency_sets()
    packages = sum(len(item.get("packages") or []) for item in sets)
    return (
        f"{len(sets)} dependency set(s) · {packages} package(s) · "
        f"{vendor_dir(create=False)}"
    )
