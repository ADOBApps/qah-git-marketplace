"""Sentinel addon discovery, integrity pinning and sandboxed execution.

An addon is a source package with ``addon.json`` and a Python entry point. It
is never imported into Sentinel's process: it runs in a separate, isolated
Python process with audit hooks, a scrubbed environment, a timeout and a
memory limit.

Integrity model
---------------
Each addon folder is reduced to a deterministic SHA256 digest. The first
trusted digest is stored in ``addon_pins.json``. A later mismatch means the
addon was modified and it is refused until the user explicitly re-pins it.
Marketplace installs write ``.qah_install.json`` and are pinned automatically
after installation.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from . import sandbox_runner

ADDON_FORMAT = "qah-sentinel-addon"
ADDON_API_VERSION = 1
ADDON_EXTENSIONS = (".qah", ".qah.zip")
ID_RE = re.compile(r"^[a-z][a-z0-9_]{2,63}$")
VERSION_RE = re.compile(r"^[0-9A-Za-z][0-9A-Za-z._+-]{0,63}$")

KNOWN_CAPABILITIES = {
    "read-files",
    "write-files",
    "network",
    "report",
    "findings",
    "policy",
    "watchdog",
}

MAX_ADDON_BYTES = 100 * 1024 * 1024
MAX_RESULT_BYTES = 4 * 1024 * 1024
RESULT_FILE_NAME = "result.json"


# -- locations ---------------------------------------------------------------


def _state_dir() -> Path:
    from .sentinel_core import state_dir

    return state_dir()


def addons_dir(create: bool = True) -> Path:
    override = os.environ.get("QAH_SENTINEL_ADDONS_DIR")
    root = Path(override).expanduser() if override else _state_dir() / "addons"
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def addon_data_dir(addon_id: str, create: bool = True) -> Path:
    path = _state_dir() / "addon_data" / addon_id
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def pins_path() -> Path:
    return _state_dir() / "addon_pins.json"


def settings_path() -> Path:
    return _state_dir() / "addon_settings.json"


def _read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def load_pins() -> Dict[str, Dict[str, Any]]:
    data = _read_json(pins_path(), {})
    pins = data.get("addons") if isinstance(data, dict) else None
    return pins if isinstance(pins, dict) else {}


def save_pins(pins: Dict[str, Dict[str, Any]]) -> None:
    _write_json(pins_path(), {"format": 1, "addons": pins})


def load_settings() -> Dict[str, Dict[str, Any]]:
    data = _read_json(settings_path(), {})
    addons = data.get("addons") if isinstance(data, dict) else None
    return addons if isinstance(addons, dict) else {}


def save_settings(addons: Dict[str, Dict[str, Any]]) -> None:
    _write_json(settings_path(), {"format": 1, "addons": addons})


# -- integrity ---------------------------------------------------------------


def _iter_files(folder: Path):
    for path in sorted(folder.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(folder)
        if "__pycache__" in rel.parts or rel.name.endswith((".pyc", ".pyo")):
            continue
        yield path, rel.as_posix()


def addon_digest(folder: Path) -> str:
    hasher = hashlib.sha256()
    for path, rel in _iter_files(Path(folder)):
        hasher.update(rel.encode("utf-8"))
        hasher.update(b"\0")
        try:
            hasher.update(path.read_bytes())
        except OSError:
            hasher.update(b"<unreadable>")
        hasher.update(b"\0")
    return hasher.hexdigest()


def _file_hashes(folder: Path) -> Dict[str, str]:
    result: Dict[str, str] = {}
    for path, rel in _iter_files(Path(folder)):
        try:
            result[rel] = hashlib.sha256(path.read_bytes()).hexdigest()
        except OSError:
            result[rel] = ""
    return result


# -- manifest ----------------------------------------------------------------


def read_manifest(folder: Path) -> Dict[str, Any]:
    folder = Path(folder)
    path = folder / "addon.json"
    if not path.is_file():
        raise ValueError("addon.json is missing")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise ValueError(f"addon.json is not valid JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise ValueError("addon.json is not an object")
    return data


def validate_manifest(manifest: Dict[str, Any], folder: Path) -> List[str]:
    errors: List[str] = []
    addon_id = str(manifest.get("id") or "").strip()
    if not ID_RE.fullmatch(addon_id):
        errors.append("id must be lowercase letters, digits and underscores")
    if str(manifest.get("format") or "") != ADDON_FORMAT:
        errors.append(f"format must be {ADDON_FORMAT!r}")
    for field in ("name", "author", "description"):
        if not str(manifest.get(field) or "").strip():
            errors.append(f"{field} is required")
    version = str(manifest.get("version") or "").strip()
    if not VERSION_RE.fullmatch(version):
        errors.append("version is invalid")
    try:
        api_version = int(manifest.get("api_version", 0))
    except Exception:
        api_version = -1
    if api_version != ADDON_API_VERSION:
        errors.append(
            f"api_version {api_version!r} is not supported "
            f"(Sentinel addon API is {ADDON_API_VERSION})"
        )
    main = str(manifest.get("main") or "main.py")
    if not (Path(folder) / main).is_file():
        errors.append(f"main file {main!r} is missing")
    entry = str(manifest.get("entry") or "run")
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", entry):
        errors.append("entry must be a Python function name")
    capabilities = manifest.get("capabilities")
    if capabilities is None:
        capabilities = []
    if not isinstance(capabilities, list):
        errors.append("capabilities must be a list")
    else:
        unknown = sorted(set(str(item) for item in capabilities) - KNOWN_CAPABILITIES)
        if unknown:
            errors.append("unknown capabilities: " + ", ".join(unknown))
    try:
        timeout = int(manifest.get("timeout", 30))
        if not 1 <= timeout <= 300:
            errors.append("timeout must be between 1 and 300 seconds")
    except Exception:
        errors.append("timeout must be an integer")
    return errors


# -- discovery ---------------------------------------------------------------


def _installed_marker(folder: Path) -> Dict[str, Any]:
    data = _read_json(Path(folder) / ".qah_install.json", {})
    return data if isinstance(data, dict) else {}


def describe_addon(folder: Path, pins: Dict[str, Dict[str, Any]], settings: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    folder = Path(folder)
    info: Dict[str, Any] = {
        "id": folder.name,
        "name": folder.name,
        "version": "",
        "api_version": 0,
        "capabilities": [],
        "path": str(folder),
        "status": "invalid",
        "errors": [],
        "digest": "",
        "pinned_digest": "",
        "enabled": True,
        "entry": "run",
        "timeout": 30,
        "description": "",
        "author": "",
        "source": "local",
    }
    try:
        manifest = read_manifest(folder)
    except Exception as exc:
        info["errors"] = [str(exc)]
        return info
    addon_id = str(manifest.get("id") or folder.name)
    info.update({
        "id": addon_id,
        "name": str(manifest.get("name") or addon_id),
        "version": str(manifest.get("version") or ""),
        "api_version": int(manifest.get("api_version", 0) or 0),
        "capabilities": [str(item) for item in (manifest.get("capabilities") or [])],
        "description": str(manifest.get("description") or ""),
        "author": str(manifest.get("author") or ""),
        "entry": str(manifest.get("entry") or "run"),
        "timeout": int(manifest.get("timeout", 30) or 30),
    })
    marker = _installed_marker(folder)
    if marker:
        info["source"] = str(marker.get("source") or "marketplace")
        info["install_sha256"] = str(marker.get("archive_sha256") or "")
        info["installed_at"] = str(marker.get("installed_at") or "")
    errors = validate_manifest(manifest, folder)
    if errors:
        info["errors"] = errors
        info["status"] = "invalid"
        return info
    try:
        digest = addon_digest(folder)
    except Exception as exc:
        info["errors"] = [f"cannot hash addon: {exc}"]
        info["status"] = "invalid"
        return info
    info["digest"] = digest
    pin = pins.get(addon_id) or {}
    pinned_digest = str(pin.get("digest") or "")
    marker_sha = str(marker.get("archive_sha256") or "") if marker else ""
    pin_sha = str(pin.get("archive_sha256") or "")
    # A marketplace install is trusted at install time. Pin it on first
    # discovery, and re-pin when the marketplace install record changes (an
    # update/reinstall), because that record is written only after the catalog
    # SHA256 was verified. A plain file edit with the same install record is
    # still detected as "modified".
    trusted_reinstall = bool(marker_sha and marker_sha != pin_sha)
    if marker and (not pinned_digest or trusted_reinstall):
        pin = {
            "digest": digest,
            "version": info["version"],
            "source": str(marker.get("source") or "marketplace"),
            "archive_sha256": marker_sha,
            "pinned_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        }
        pins[addon_id] = pin
        save_pins(pins)
        pinned_digest = digest
    info["pinned_digest"] = pinned_digest
    enabled = bool((settings.get(addon_id) or {}).get("enabled", True))
    info["enabled"] = enabled
    if not pinned_digest:
        info["status"] = "unpinned"
        info["errors"] = ["Not pinned yet. Verify the addon and pin its hash before running."]
    elif pinned_digest != digest:
        info["status"] = "modified"
        info["errors"] = [
            "The addon files changed after they were pinned. Re-pin only if the "
            "change is expected."
        ]
    elif not enabled:
        info["status"] = "disabled"
    else:
        info["status"] = "ok"
    return info


def discover_addons() -> List[Dict[str, Any]]:
    root = addons_dir(False)
    pins = load_pins()
    settings = load_settings()
    result: List[Dict[str, Any]] = []
    if not root.is_dir():
        return result
    changed = False
    before = json.dumps(pins, sort_keys=True)
    for child in sorted(root.iterdir()):
        if not child.is_dir() or child.name.startswith("."):
            continue
        if not (child / "addon.json").is_file():
            continue
        result.append(describe_addon(child, pins, settings))
    if json.dumps(pins, sort_keys=True) != before:
        changed = True
    if changed:
        save_pins(pins)
    result.sort(key=lambda item: str(item.get("name", "")).lower())
    return result


def get_addon(addon_id: str) -> Optional[Dict[str, Any]]:
    for addon in discover_addons():
        if addon["id"] == addon_id:
            return addon
    return None


# -- trust and settings ------------------------------------------------------


def pin_addon(addon_id: str) -> Dict[str, Any]:
    addon = get_addon(addon_id)
    if addon is None:
        raise ValueError(f"Addon {addon_id!r} is not installed.")
    if addon["status"] == "invalid":
        raise ValueError("; ".join(addon.get("errors") or ["invalid addon"]))
    pins = load_pins()
    pins[addon_id] = {
        "digest": addon["digest"],
        "version": addon.get("version", ""),
        "source": addon.get("source", "local"),
        "archive_sha256": addon.get("install_sha256", ""),
        "pinned_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    save_pins(pins)
    return get_addon(addon_id) or addon


def unpin_addon(addon_id: str) -> None:
    pins = load_pins()
    pins.pop(addon_id, None)
    save_pins(pins)


def set_enabled(addon_id: str, enabled: bool) -> None:
    settings = load_settings()
    entry = dict(settings.get(addon_id) or {})
    entry["enabled"] = bool(enabled)
    settings[addon_id] = entry
    save_settings(settings)


def remove_addon(addon_id: str) -> str:
    addon = get_addon(addon_id)
    if addon is None:
        raise ValueError(f"Addon {addon_id!r} is not installed.")
    target = Path(addon["path"]).resolve()
    root = addons_dir(False).resolve()
    if target.parent != root:
        raise ValueError(f"Refusing to remove an addon outside {root}.")
    shutil.rmtree(target)
    unpin_addon(addon_id)
    settings = load_settings()
    settings.pop(addon_id, None)
    save_settings(settings)
    return f"Removed {target}"


# -- install -----------------------------------------------------------------


def install_addon_archive(path: Path, *, source: str = "local") -> Dict[str, Any]:
    path = Path(path).expanduser().resolve()
    if not path.is_file():
        raise ValueError(f"Addon package not found: {path}")
    if path.stat().st_size > MAX_ADDON_BYTES:
        raise ValueError("Addon package is larger than 100 MB.")
    workspace = Path(tempfile.mkdtemp(prefix="sentinel-addon-install-"))
    try:
        package = sandbox_runner._extract_archive(path, workspace)
        manifest = read_manifest(package)
        errors = validate_manifest(manifest, package)
        if errors:
            raise ValueError("; ".join(errors))
        addon_id = str(manifest["id"])
        root = addons_dir()
        target = root / addon_id
        backup: Optional[Path] = None
        if target.exists():
            backup = target.with_name(f".{addon_id}.backup-{int(time.time())}")
            os.replace(target, backup)
        try:
            shutil.copytree(package, target)
            if source == "marketplace":
                marker = {
                    "source": source,
                    "archive_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                    "installed_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                    "version": str(manifest.get("version") or ""),
                }
                (target / ".qah_install.json").write_text(
                    json.dumps(marker, indent=2), encoding="utf-8"
                )
        except Exception:
            if target.exists():
                shutil.rmtree(target, ignore_errors=True)
            if backup and backup.exists():
                os.replace(backup, target)
            raise
        if backup and backup.exists():
            shutil.rmtree(backup, ignore_errors=True)
        unpin_addon(addon_id)
        return get_addon(addon_id) or {"id": addon_id}
    finally:
        shutil.rmtree(workspace, ignore_errors=True)


# -- execution ---------------------------------------------------------------


def _scrubbed_env(workdir: Path) -> Dict[str, str]:
    env = os.environ.copy()
    for key in list(env):
        if key.upper().startswith(
            ("QAH_", "GITHUB_", "GH_", "AWS_", "AZURE_", "OPENAI_", "ANTHROPIC_")
        ):
            env.pop(key, None)
    env.update({
        "HOME": str(workdir),
        "USERPROFILE": str(workdir),
        "TEMP": str(workdir),
        "TMP": str(workdir),
        "PYTHONNOUSERSITE": "1",
        "PYTHONDONTWRITEBYTECODE": "1",
        "QT_QPA_PLATFORM": "offscreen",
    })
    return env


def run_addon(
    addon_id: str,
    *,
    targets: Optional[List[os.PathLike | str]] = None,
    config: Optional[Dict[str, Any]] = None,
    timeout: Optional[int] = None,
    allow_modified: bool = False,
) -> Dict[str, Any]:
    addon = get_addon(addon_id)
    if addon is None:
        raise ValueError(f"Addon {addon_id!r} is not installed.")
    if addon["status"] == "invalid":
        raise ValueError("; ".join(addon.get("errors") or ["invalid addon"]))
    if addon["status"] == "modified" and not allow_modified:
        raise ValueError(
            "Addon files changed after pinning. Re-pin it in the Addons tab if "
            "the change is expected."
        )
    if addon["status"] == "unpinned":
        raise ValueError("Pin the addon hash before running it.")
    if not addon["enabled"] and not allow_modified:
        raise ValueError("The addon is disabled.")
    return _execute_addon(addon, targets=targets, config=config, timeout=timeout)


def run_addon_folder(
    folder: os.PathLike | str,
    *,
    targets: Optional[List[os.PathLike | str]] = None,
    config: Optional[Dict[str, Any]] = None,
    timeout: Optional[int] = None,
) -> Dict[str, Any]:
    """Run an unprepared addon folder, for Addon Studio testing.

    The folder is validated but not installed or pinned. It is still executed in
    the same isolated addon host with the same capability limits.
    """
    folder = Path(folder).expanduser().resolve()
    manifest = read_manifest(folder)
    errors = validate_manifest(manifest, folder)
    if errors:
        raise ValueError("; ".join(errors))
    addon = {
        "id": str(manifest.get("id") or folder.name),
        "name": str(manifest.get("name") or folder.name),
        "version": str(manifest.get("version") or ""),
        "capabilities": [str(item) for item in (manifest.get("capabilities") or [])],
        "path": str(folder),
        "entry": str(manifest.get("entry") or "run"),
        "timeout": int(manifest.get("timeout", 30) or 30),
    }
    return _execute_addon(addon, targets=targets, config=config, timeout=timeout)


def _execute_addon(
    addon: Dict[str, Any],
    *,
    targets: Optional[List[os.PathLike | str]] = None,
    config: Optional[Dict[str, Any]] = None,
    timeout: Optional[int] = None,
) -> Dict[str, Any]:
    addon_id = str(addon["id"])
    folder = Path(addon["path"])
    capabilities = set(addon.get("capabilities") or [])
    target_paths: List[Path] = []
    for item in targets or []:
        candidate = Path(item).expanduser()
        if not candidate.exists():
            raise ValueError(f"Addon target does not exist: {candidate}")
        target_paths.append(candidate.resolve())
    if target_paths and "read-files" not in capabilities:
        raise ValueError(
            "This addon does not declare the 'read-files' capability, so it "
            "cannot receive targets."
        )
    workdir = Path(tempfile.mkdtemp(prefix="sentinel-addon-run-"))
    data_dir = addon_data_dir(addon_id)
    try:
        context = {
            "addon_id": addon_id,
            "addon_name": addon.get("name", addon_id),
            "addon_version": addon.get("version", ""),
            "api_version": ADDON_API_VERSION,
            "capabilities": sorted(capabilities),
            "addon_dir": str(folder),
            "data_dir": str(data_dir),
            "workdir": str(workdir),
            "targets": [str(path) for path in target_paths],
            "config": config or {},
        }
        context_path = workdir / "context.json"
        context_path.write_text(json.dumps(context, indent=2), encoding="utf-8")
        result_path = workdir / RESULT_FILE_NAME
        allowed_read = [folder, data_dir, workdir] + target_paths
        allowed_read += _python_read_roots()
        command = [
            sys.executable,
            "-I",
            "-B",
            "-u",
            str(Path(__file__).with_name("addon_host.py")),
            "--addon",
            str(folder),
            "--context",
            str(context_path),
            "--result",
            str(result_path),
            "--allow-network",
            "1" if "network" in capabilities else "0",
            "--allow-write",
            "1" if "write-files" in capabilities else "0",
        ]
        for path in allowed_read:
            command += ["--allowed-read", str(path)]
        command += ["--data-dir", str(data_dir), "--workdir", str(workdir)]

        run_timeout = int(timeout or addon.get("timeout") or 30)
        run_timeout = max(1, min(run_timeout, 300))
        kwargs: Dict[str, Any] = {}
        if os.name == "nt":
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        else:
            kwargs["start_new_session"] = True
        started = time.time()
        proc = subprocess.Popen(
            command,
            cwd=str(workdir),
            env=_scrubbed_env(workdir),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            **kwargs,
        )
        job = sandbox_runner._assign_windows_job(proc, 512, run_timeout)
        timed_out = False
        try:
            stdout, stderr = proc.communicate(timeout=run_timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            sandbox_runner._kill_tree(proc)
            try:
                stdout, stderr = proc.communicate(timeout=5)
            except Exception:
                stdout, stderr = "", ""
        finally:
            if job is not None:
                try:
                    import ctypes

                    ctypes.WinDLL("kernel32").CloseHandle(job)
                except Exception:
                    pass
        duration = round(time.time() - started, 3)
        payload: Dict[str, Any] = {}
        if result_path.is_file() and result_path.stat().st_size <= MAX_RESULT_BYTES:
            payload = _read_json(result_path, {})
        if timed_out:
            status = "timeout"
        elif payload:
            status = str(payload.get("status") or "error")
        else:
            status = "error"
        return {
            "status": status,
            "addon": addon_id,
            "duration": duration,
            "timed_out": timed_out,
            "timeout": run_timeout,
            "returncode": proc.returncode,
            "capabilities": sorted(capabilities),
            "targets": [str(path) for path in target_paths],
            "findings": payload.get("findings") or [],
            "report": payload.get("report") or "",
            "summary": payload.get("summary") or "",
            "data": payload.get("data") or {},
            "violations": payload.get("violations") or [],
            "detail": payload.get("detail") or "",
            "stdout": stdout[-20000:],
            "stderr": stderr[-20000:],
        }
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def _python_read_roots() -> List[Path]:
    roots: List[Path] = []
    for value in (sys.prefix, sys.base_prefix):
        if value:
            roots.append(Path(value))
    for value in sys.path:
        if not value:
            continue
        path = Path(value)
        if path.is_dir():
            roots.append(path)
    return roots
