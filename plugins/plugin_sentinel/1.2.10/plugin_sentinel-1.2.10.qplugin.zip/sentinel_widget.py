"""PySide6 dashboard for Plugin Sentinel."""

from __future__ import annotations

import json
import re
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional

from PySide6.QtCore import Qt, QThread, Signal, QUrl
from PySide6.QtGui import QAction, QColor, QDesktopServices, QFont
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QCheckBox,
    QComboBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QSplitter,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QTextBrowser,
    QToolBar,
    QToolButton,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
    QMenu,
)

from . import sentinel_core as core
from .runtime_monitor import RuntimeTab
from .watchdog_monitor import WatchdogTab
from . import sandbox_runner
from . import sentinel_addons
from . import sentinel_dependencies

SEVERITY_COLORS = {
    "critical": QColor("#fecaca"),
    "high": QColor("#ffedd5"),
    "medium": QColor("#fef3c7"),
    "low": QColor("#e0e7ff"),
    "info": QColor("#e0f2fe"),
}
VERDICT_COLORS = {"PASS": "#15803d", "WARN": "#b45309", "BLOCK": "#b91c1c"}
GRADE_COLORS = {"A": "#15803d", "B": "#0f766e", "C": "#b45309", "D": "#c2410c", "E": "#b91c1c", "F": "#7f1d1d"}


class ScanWorker(QThread):
    one_done = Signal(dict)
    progress = Signal(int, int, str)
    all_done = Signal()

    def __init__(self, targets, checks, policy, baseline, parent=None):
        super().__init__(parent)
        self.targets = list(targets)
        self.checks = list(checks)
        self.policy = dict(policy or {})
        self.baseline = dict(baseline or {})
        self._stop = False

    def stop(self):
        self._stop = True

    def run(self):
        total = len(self.targets)
        for index, target in enumerate(self.targets, 1):
            if self._stop:
                break
            self.progress.emit(index, total, target.label)
            try:
                result = core.scan_target(target, self.checks, self.policy, self.baseline)
            except Exception as exc:
                result = {
                    "target": str(target.path),
                    "path": str(target.path),
                    "label": target.label,
                    "source": target.source,
                    "id": target.plugin_id,
                    "version": target.version,
                    "ok": False,
                    "counts": {"critical": 1},
                    "risk_score": 100,
                    "grade": "F",
                    "policy_verdict": "BLOCK",
                    "baseline": "new",
                    "sentinel": {"capabilities": [], "findings": [
                        {"severity": "critical", "check": "worker", "code": "audit.failed", "message": str(exc)}
                    ]},
                    "checks": {},
                    "text": f"Audit failed: {exc}",
                }
            self.one_done.emit(result)
        self.all_done.emit()


class AddonRunWorker(QThread):
    done = Signal(dict)

    def __init__(self, addon_id, targets, timeout=None, parent=None):
        super().__init__(parent)
        self.addon_id = addon_id
        self.targets = list(targets or [])
        self.timeout = timeout

    def run(self):
        try:
            result = sentinel_addons.run_addon(
                self.addon_id,
                targets=self.targets,
                timeout=self.timeout,
            )
        except Exception as exc:
            result = {
                "status": "error",
                "addon": self.addon_id,
                "detail": str(exc),
                "findings": [],
                "violations": [],
                "duration": 0,
                "stdout": "",
                "stderr": "",
            }
        self.done.emit(result)


class SandboxWorker(QThread):
    done = Signal(dict)

    def __init__(self, target, timeout, memory_mb, allow_network, parent=None):
        super().__init__(parent)
        self.target = Path(target)
        self.timeout = int(timeout)
        self.memory_mb = int(memory_mb)
        self.allow_network = bool(allow_network)
        self._qah_app = None
        try:
            from plugins.libs import plugin_manager  # type: ignore

            path = Path(plugin_manager.__file__).resolve()
            for parent in path.parents:
                if (parent / "app_packages").is_dir() and (parent / "app").is_dir():
                    self._qah_app = parent
                    break
        except Exception:
            pass

    def run(self):
        try:
            result = sandbox_runner.run_sandbox(
                self.target,
                timeout=self.timeout,
                memory_mb=self.memory_mb,
                allow_network=self.allow_network,
                qah_app=self._qah_app,
            )
        except Exception as exc:
            result = {
                "status": "error",
                "target": str(self.target),
                "detail": str(exc),
                "violations": [],
                "stdout": "",
                "stderr": "",
            }
        self.done.emit(result)


class SentinelWidget(QWidget):
    COLUMNS = ("Plugin", "Version", "Source", "Risk", "Grade", "Verdict", "Crit", "High", "Med", "Low", "Baseline", "Capabilities")

    def __init__(self, plugin=None, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.targets: List[core.Target] = []
        self.results: Dict[str, dict] = {}
        self.baseline = core.load_baseline()
        self.policy = core.load_policy()
        self.worker: Optional[ScanWorker] = None
        self.sandbox_worker: Optional[SandboxWorker] = None
        self.addon_worker: Optional[AddonRunWorker] = None
        self.sandbox_result: Optional[dict] = None
        self._busy = False
        self._build_ui()
        self._load_policy_ui()
        self.refresh_targets()

    # -- UI --------------------------------------------------------------
    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        header = QHBoxLayout()
        title = QLabel("<b>Plugin Sentinel</b>")
        title.setFont(QFont("Segoe UI", 15, QFont.Weight.Bold))
        title.setToolTip(
            "Risk scoring, capability mapping, native inspection, trusted "
            "baselines, policy gates, runtime monitoring and Sentinel addons."
        )
        header.addWidget(title)
        header.addStretch(1)
        self.status = QLabel("Ready")
        self.status.setStyleSheet("color:#6b7280;")
        header.addWidget(self.status)
        layout.addLayout(header)

        self.toolbar = QToolBar()
        self.toolbar.setIconSize(self.toolbar.iconSize())
        layout.addWidget(self.toolbar)
        style = self.style()

        self.action_refresh = QAction(style.standardIcon(style.StandardPixmap.SP_BrowserReload), "Refresh", self)
        self.action_scan_all = QAction(style.standardIcon(style.StandardPixmap.SP_MediaPlay), "Scan all", self)
        self.action_scan_selected = QAction(style.standardIcon(style.StandardPixmap.SP_FileDialogDetailedView), "Scan selected", self)
        self.action_scan_file = QAction(style.standardIcon(style.StandardPixmap.SP_DirOpenIcon), "Scan file…", self)
        self.action_stop = QAction(style.standardIcon(style.StandardPixmap.SP_MediaStop), "Stop", self)
        self.action_trust = QAction(style.standardIcon(style.StandardPixmap.SP_DialogApplyButton), "Trust", self)
        self.action_forget = QAction(style.standardIcon(style.StandardPixmap.SP_TrashIcon), "Forget", self)
        self.action_export = QAction(style.standardIcon(style.StandardPixmap.SP_DialogSaveButton), "Export…", self)
        self.action_stop.setEnabled(False)
        self.action_trust.setEnabled(False)
        self.action_forget.setEnabled(False)
        self.action_export.setEnabled(False)

        for action in (self.action_refresh, self.action_scan_all, self.action_scan_selected,
                       self.action_scan_file):
            self.toolbar.addAction(action)
        self.toolbar.addSeparator()
        self.toolbar.addAction(self.action_stop)
        self.toolbar.addSeparator()
        self.toolbar.addAction(self.action_trust)
        self.toolbar.addAction(self.action_forget)
        self.toolbar.addSeparator()
        self.toolbar.addAction(self.action_export)

        self.checks_button = QToolButton()
        self.checks_button.setText("Checks ▾")
        self.checks_button.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.checks_menu = QMenu(self.checks_button)
        self.check_actions: Dict[str, QAction] = {}
        for name in core.BASE_ALL_CHECKS:
            action = QAction(name, self)
            action.setCheckable(True)
            action.setChecked(name in core.BASE_DEFAULT_CHECKS)
            action.setToolTip(self._check_description(name))
            self.checks_menu.addAction(action)
            self.check_actions[name] = action
        self.checks_button.setMenu(self.checks_menu)
        self.toolbar.addSeparator()
        self.toolbar.addWidget(self.checks_button)

        self.progress = QProgressBar()
        self.progress.setMaximumWidth(180)
        self.progress.setVisible(False)
        self.toolbar.addSeparator()
        self.toolbar.addWidget(self.progress)

        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, 1)
        self._build_inventory_tab()
        self._build_findings_tab()
        self._build_native_tab()
        self._build_capabilities_tab()
        self.runtime_tab = RuntimeTab()
        self._add_scroll_tab(self.tabs, self.runtime_tab, "Runtime")
        self.watchdog_tabs = QTabWidget()
        self.tabs.addTab(self.watchdog_tabs, "Watchdog")
        self.watchdog_tab = WatchdogTab()
        self._add_scroll_tab(self.watchdog_tabs, self.watchdog_tab, "Watchdog")
        self._build_watchdog_builder_tab()
        self._build_sandbox_tab()
        self._build_baseline_tab()
        self._build_policy_tab()
        self._build_report_tab()
        self.addons_tabs = QTabWidget()
        self.tabs.addTab(self.addons_tabs, "Addons")
        self._build_addons_tab()
        self._build_health_tab()
        self._build_dependencies_tab()
        self._build_docs_tab()

        self.action_refresh.triggered.connect(self.refresh_targets)
        self.action_scan_all.triggered.connect(self.scan_all)
        self.action_scan_selected.triggered.connect(self.scan_selected)
        self.action_scan_file.triggered.connect(self.scan_file)
        self.action_stop.triggered.connect(self.stop)
        self.action_trust.triggered.connect(self.trust_selected)
        self.action_forget.triggered.connect(self.forget_selected)
        self.action_export.triggered.connect(self.export_report)

        layout.activate()
        content.setMinimumHeight(max(120, int(layout.sizeHint().height())))
        content.setMinimumWidth(0)
        self.content_scroll = QScrollArea()
        self.content_scroll.setWidgetResizable(True)
        self.content_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.content_scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAsNeeded
        )
        self.content_scroll.setVerticalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAsNeeded
        )
        self.content_scroll.setWidget(content)
        outer.addWidget(self.content_scroll)

    def _add_scroll_tab(self, tabs, page, title):
        """Add a tab page inside a scroll area with a natural minimum height."""
        if page.layout() is not None:
            page.layout().activate()
        page.ensurePolished()
        hint = page.sizeHint()
        page.setMinimumHeight(max(80, int(hint.height())))
        page.setMinimumWidth(0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setWidget(page)
        tabs.addTab(scroll, title)
        return scroll

    def _check_description(self, name: str) -> str:
        return {
            "manifest": "manifest.json schema, ids, declared files",
            "archive": "archive shape: traversal, symlinks, size, compression ratio",
            "static": "AST scan for dangerous imports, calls and obfuscation",
            "deps": "dependency names, URLs/VCS, QAH-stack duplication",
            "sandbox": "runs the plugin in a subprocess with limits and no network",
        }.get(name, name)

    def _build_inventory_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        filters = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Filter by name, id, version or capability…")
        self.search.textChanged.connect(self._apply_filters)
        filters.addWidget(self.search, 2)
        self.source_filter = QComboBox()
        self.source_filter.addItems(["All sources", "user", "system", "wheel", "file"])
        self.source_filter.currentTextChanged.connect(self._apply_filters)
        filters.addWidget(self.source_filter)
        self.verdict_filter = QComboBox()
        self.verdict_filter.addItems(["All verdicts", "PASS", "WARN", "BLOCK"])
        self.verdict_filter.currentTextChanged.connect(self._apply_filters)
        filters.addWidget(self.verdict_filter)
        layout.addLayout(filters)

        splitter = QSplitter(Qt.Orientation.Vertical)
        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(list(self.COLUMNS))
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setWordWrap(False)
        self.table.setTextElideMode(Qt.TextElideMode.ElideRight)
        self.table.setHorizontalScrollMode(
            QAbstractItemView.ScrollMode.ScrollPerPixel
        )
        self.table.setVerticalScrollMode(
            QAbstractItemView.ScrollMode.ScrollPerPixel
        )
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        header.setStretchLastSection(False)
        for column, width in enumerate(
            (220, 80, 80, 60, 60, 85, 55, 55, 55, 55, 85, 240)
        ):
            self.table.setColumnWidth(column, width)
        self.table.itemSelectionChanged.connect(self._show_inventory_detail)
        splitter.addWidget(self.table)

        self.detail = QPlainTextEdit()
        self.detail.setReadOnly(True)
        self.detail.setFont(QFont("Consolas", 9))
        self.detail.setPlaceholderText(
            "Select a plugin to see the full audit. Use Scan all, Scan selected or Scan file.\n\n"
            "Risk combines severity weights; policy gates can block critical/high findings, "
            "untrusted hashes and unexpected capabilities."
        )
        splitter.addWidget(self.detail)
        splitter.setSizes([340, 240])
        layout.addWidget(splitter, 1)
        self._add_scroll_tab(self.tabs, tab, "Inventory")

    def _build_findings_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        filters = QHBoxLayout()
        self.finding_search = QLineEdit()
        self.finding_search.setPlaceholderText("Filter findings…")
        self.finding_search.textChanged.connect(self._apply_finding_filters)
        filters.addWidget(self.finding_search, 2)
        self.severity_filter = QComboBox()
        self.severity_filter.addItems(["All severities", "critical", "high", "medium", "low", "info"])
        self.severity_filter.currentTextChanged.connect(self._apply_finding_filters)
        filters.addWidget(self.severity_filter)
        layout.addLayout(filters)

        splitter = QSplitter(Qt.Orientation.Vertical)
        self.findings_tree = QTreeWidget()
        self.findings_tree.setHeaderLabels(["Plugin", "Severity", "Check", "Code", "Message", "Path"])
        self.findings_tree.setRootIsDecorated(False)
        self.findings_tree.setAlternatingRowColors(True)
        self.findings_tree.header().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.findings_tree.header().setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        self.findings_tree.itemSelectionChanged.connect(self._show_finding_detail)
        splitter.addWidget(self.findings_tree)
        self.finding_detail = QPlainTextEdit()
        self.finding_detail.setReadOnly(True)
        self.finding_detail.setFont(QFont("Consolas", 9))
        splitter.addWidget(self.finding_detail)
        splitter.setSizes([320, 200])
        layout.addWidget(splitter, 1)
        self._add_scroll_tab(self.tabs, tab, "Findings")

    def _build_native_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        intro = QLabel(
            "Native libraries found in plugins: PE, ELF and Mach-O headers, "
            "architecture, entropy, imports, hardening flags and SHA256. "
            "No native code is executed."
        )
        intro.setWordWrap(True)
        intro.setStyleSheet("color:#6b7280;")
        layout.addWidget(intro)
        splitter = QSplitter(Qt.Orientation.Vertical)
        self.native_table = QTableWidget(0, 10)
        self.native_table.setHorizontalHeaderLabels(
            ["Plugin", "File", "Format", "Arch", "Bits", "Size", "Entropy", "Signed", "Findings", "SHA256"]
        )
        self.native_table.verticalHeader().setVisible(False)
        self.native_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.native_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.native_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.native_table.horizontalHeader().setStretchLastSection(True)
        self.native_table.itemSelectionChanged.connect(self._show_native_detail)
        splitter.addWidget(self.native_table)
        self.native_detail = QPlainTextEdit()
        self.native_detail.setReadOnly(True)
        self.native_detail.setFont(QFont("Consolas", 9))
        self.native_detail.setPlaceholderText("Select a library to see imports, flags and sections.")
        splitter.addWidget(self.native_detail)
        splitter.setSizes([300, 220])
        layout.addWidget(splitter, 1)
        self._add_scroll_tab(self.tabs, tab, "Native")

    def _build_sandbox_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        intro = QLabel(
            "Run plugin code in a separate process with Python audit hooks, a "
            "temporary workspace, blocked writes/network/subprocess/native "
            "loading, and a hard timeout. This is a containment harness, not a "
            "hypervisor: treat it as a strong audit tool, not a security boundary "
            "against kernel-level code."
        )
        intro.setWordWrap(True)
        intro.setStyleSheet("color:#6b7280;")
        layout.addWidget(intro)

        form_box = QGroupBox("Sandbox run")
        form = QFormLayout(form_box)
        row = QHBoxLayout()
        self.sandbox_target = QComboBox()
        self.sandbox_target.setMinimumWidth(420)
        row.addWidget(self.sandbox_target, 1)
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse_sandbox_target)
        row.addWidget(browse)
        form.addRow("Target:", row)
        self.sandbox_timeout = QSpinBox()
        self.sandbox_timeout.setRange(1, 300)
        self.sandbox_timeout.setValue(20)
        self.sandbox_timeout.setSuffix(" s")
        form.addRow("Timeout:", self.sandbox_timeout)
        self.sandbox_memory = QSpinBox()
        self.sandbox_memory.setRange(32, 4096)
        self.sandbox_memory.setValue(512)
        self.sandbox_memory.setSuffix(" MB")
        form.addRow("Memory limit:", self.sandbox_memory)
        self.sandbox_network = QCheckBox("Allow network access (not recommended)")
        form.addRow("", self.sandbox_network)
        layout.addWidget(form_box)

        row = QHBoxLayout()
        self.sandbox_run_btn = QPushButton("Run sandbox")
        self.sandbox_run_btn.clicked.connect(self.run_sandbox)
        row.addWidget(self.sandbox_run_btn)
        self.sandbox_status = QLabel("Idle.")
        self.sandbox_status.setStyleSheet("color:#6b7280;")
        row.addWidget(self.sandbox_status, 1)
        layout.addLayout(row)
        self.sandbox_output = QPlainTextEdit()
        self.sandbox_output.setReadOnly(True)
        self.sandbox_output.setFont(QFont("Consolas", 9))
        self.sandbox_output.setPlaceholderText(
            "Sandbox result: status, violations, stdout/stderr and resource information."
        )
        layout.addWidget(self.sandbox_output, 1)
        self._add_scroll_tab(self.tabs, tab, "Sandbox")

    def _build_capabilities_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        intro = QLabel(
            "Capabilities are derived from Python imports, calls and source patterns. "
            "They are informational unless the policy disallows one."
        )
        intro.setWordWrap(True)
        intro.setStyleSheet("color:#6b7280;")
        layout.addWidget(intro)
        self.cap_table = QTableWidget(0, 1 + len(core.CAPABILITIES))
        self.cap_table.setHorizontalHeaderLabels(
            ["Plugin"] + [label for _name, label in core.CAPABILITIES]
        )
        self.cap_table.verticalHeader().setVisible(False)
        self.cap_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.cap_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.cap_table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.cap_table, 1)
        self._add_scroll_tab(self.tabs, tab, "Capabilities")

    def _build_baseline_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        intro = QLabel(
            "Trust a plugin to pin its current SHA256. A changed digest is flagged as drift; "
            "<b>new</b> means it has never been trusted."
        )
        intro.setWordWrap(True)
        intro.setStyleSheet("color:#6b7280;")
        layout.addWidget(intro)
        self.baseline_table = QTableWidget(0, 6)
        self.baseline_table.setHorizontalHeaderLabels(
            ["Key", "Plugin", "Version", "SHA256", "Trusted at", "Current status"]
        )
        self.baseline_table.verticalHeader().setVisible(False)
        self.baseline_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.baseline_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.baseline_table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.baseline_table, 1)
        row = QHBoxLayout()
        trust = QPushButton("Trust selected inventory plugin")
        trust.clicked.connect(self.trust_selected)
        row.addWidget(trust)
        forget = QPushButton("Forget selected baseline")
        forget.clicked.connect(self.forget_selected_baseline)
        row.addWidget(forget)
        reload_btn = QPushButton("Reload baseline")
        reload_btn.clicked.connect(self.reload_baseline)
        row.addWidget(reload_btn)
        save_btn = QPushButton("Save baseline")
        save_btn.clicked.connect(self.save_baseline)
        row.addWidget(save_btn)
        row.addStretch(1)
        layout.addLayout(row)
        self._add_scroll_tab(self.tabs, tab, "Baseline")

    def _build_policy_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        intro = QLabel(
            "Policy turns Sentinel into a gate. BLOCK means at least one rule failed; "
            "WARN means medium/low risk; PASS means no blocking findings. "
            "System plugins are report-only and are never disabled or unloaded."
        )
        intro.setWordWrap(True)
        intro.setStyleSheet("color:#6b7280;")
        layout.addWidget(intro)

        form_box = QGroupBox("Gate")
        form = QFormLayout(form_box)
        self.fail_combo = QComboBox()
        self.fail_combo.addItems(["never", "low", "medium", "high", "critical"])
        form.addRow("Block at severity:", self.fail_combo)
        self.risk_spin = QSpinBox()
        self.risk_spin.setRange(0, 100)
        form.addRow("Maximum risk score:", self.risk_spin)
        self.trusted_check = QCheckBox("Require a trusted baseline hash")
        form.addRow("", self.trusted_check)
        layout.addWidget(form_box)

        cap_box = QGroupBox("Allowed capabilities")
        cap_layout = QVBoxLayout(cap_box)
        self.cap_checks: Dict[str, QCheckBox] = {}
        for name, label in core.CAPABILITIES:
            check = QCheckBox(label)
            cap_layout.addWidget(check)
            self.cap_checks[name] = check
        layout.addWidget(cap_box)

        row = QHBoxLayout()
        save = QPushButton("Save policy")
        save.clicked.connect(self.save_policy_ui)
        row.addWidget(save)
        evaluate = QPushButton("Evaluate current results")
        evaluate.clicked.connect(self.evaluate_results)
        row.addWidget(evaluate)
        row.addStretch(1)
        layout.addLayout(row)
        self.policy_status = QLabel("No policy evaluation yet.")
        self.policy_status.setWordWrap(True)
        layout.addWidget(self.policy_status)
        layout.addStretch(1)
        self._add_scroll_tab(self.tabs, tab, "Policy")

    def _build_report_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        row = QHBoxLayout()
        refresh = QPushButton("Refresh preview")
        refresh.clicked.connect(self._refresh_report_preview)
        row.addWidget(refresh)
        for label, fmt in (("JSON…", "json"), ("Markdown…", "md"), ("HTML…", "html"), ("CSV…", "csv")):
            btn = QPushButton(label)
            btn.clicked.connect(lambda _checked=False, f=fmt: self.export_report(f))
            row.addWidget(btn)
        row.addStretch(1)
        layout.addLayout(row)
        self.report_view = QTextBrowser()
        self.report_view.setOpenExternalLinks(False)
        layout.addWidget(self.report_view, 1)
        self._add_scroll_tab(self.tabs, tab, "Report")

    def _build_health_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        intro = QLabel(
            "Reads the report written by the headless <b>Plugin Health Guard</b> plugin. "
            "Use it to see manifest, duplicate-id, backup and bytecode issues without "
            "opening a second window."
        )
        intro.setWordWrap(True)
        intro.setStyleSheet("color:#6b7280;")
        layout.addWidget(intro)
        row = QHBoxLayout()
        refresh = QPushButton("Refresh report")
        refresh.clicked.connect(self._refresh_health)
        row.addWidget(refresh)
        run = QPushButton("Run Health Guard check")
        run.clicked.connect(self._run_health_guard)
        row.addWidget(run)
        open_json = QPushButton("Open JSON")
        open_json.clicked.connect(self._open_health_json)
        row.addWidget(open_json)
        row.addStretch(1)
        layout.addLayout(row)
        self.health_summary = QLabel("No health report loaded.")
        self.health_summary.setWordWrap(True)
        layout.addWidget(self.health_summary)
        self.health_table = QTableWidget(0, 5)
        self.health_table.setHorizontalHeaderLabels(["Severity", "Code", "Plugin", "Message", "Path"])
        self.health_table.verticalHeader().setVisible(False)
        self.health_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.health_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.health_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.health_table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.health_table, 1)
        self.health_status = QLabel("")
        self.health_status.setStyleSheet("color:#6b7280;")
        layout.addWidget(self.health_status)
        self._add_scroll_tab(self.addons_tabs, tab, "Health")
        self._refresh_health()

    def _health_report_path(self) -> Path:
        return Path.home() / "QAH" / "plugin_health_guard" / "health.json"

    def _refresh_health(self):
        path = self._health_report_path()
        self.health_table.setRowCount(0)
        if not path.is_file():
            self.health_summary.setText(
                f"No report at {path}. Install Plugin Health Guard and run a check."
            )
            self.health_status.setText("Health Guard report missing.")
            return
        try:
            report = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            self.health_summary.setText(f"Could not read {path}: {exc}")
            return
        counts = report.get("counts") or {}
        self.health_summary.setText(
            f"Generated {report.get('generated_at', '?')} · "
            f"{counts.get('plugins', 0)} plugin(s) · "
            f"{counts.get('issues', 0)} issue(s) · "
            f"critical {counts.get('critical', 0)}, high {counts.get('high', 0)}, "
            f"medium {counts.get('medium', 0)}, low {counts.get('low', 0)}"
        )
        for issue in report.get("issues") or []:
            row = self.health_table.rowCount()
            self.health_table.insertRow(row)
            values = [
                str(issue.get("severity", "")),
                str(issue.get("code", "")),
                str(issue.get("plugin_id") or issue.get("source") or ""),
                str(issue.get("message", "")),
                str(issue.get("path", "")),
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(value)
                if col == 0 and value in SEVERITY_COLORS:
                    item.setBackground(SEVERITY_COLORS[value])
                self.health_table.setItem(row, col, item)
        self.health_status.setText(f"{path}")

    def _run_health_guard(self):
        manager = None
        for widget in QApplication.topLevelWidgets():
            manager = getattr(widget, "plugin_manager", None)
            if manager is not None and hasattr(manager, "plugins"):
                break
        if manager is None:
            QMessageBox.information(self, "Plugin Sentinel", "QAH plugin manager was not found.")
            return
        plugin = manager.get_plugin("plugin_health_guard") if hasattr(manager, "get_plugin") else None
        if plugin is None:
            try:
                manager.load_plugin("plugin_health_guard")
                plugin = manager.get_plugin("plugin_health_guard")
            except Exception:
                plugin = None
        if plugin is None or not hasattr(plugin, "run_check"):
            QMessageBox.information(
                self, "Plugin Sentinel",
                "Plugin Health Guard is not installed or not loaded. Install it from "
                "the Git Plugin Marketplace, then try again.",
            )
            return
        try:
            plugin.run_check()
            self._refresh_health()
            self.health_status.setText("Health Guard check completed.")
        except Exception as exc:
            QMessageBox.critical(self, "Plugin Sentinel", f"Health Guard failed:\n{exc}")

    def _open_health_json(self):
        path = self._health_report_path()
        if path.is_file():
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
        else:
            QMessageBox.information(self, "Plugin Sentinel", f"No report at:\n{path}")

    def _build_watchdog_builder_tab(self):
        from . import watchdog_builder

        tab = QWidget()
        layout = QVBoxLayout(tab)
        intro = QLabel(
            "Generate a small <b>installable, headless watchdog plugin</b> for a "
            "plugin folder, native library, log or execution output. The generated "
            "plugin pins a SHA256, checks on a timer, writes a JSON report and adds "
            "two menu actions. It uses only PySide6 and the standard library."
        )
        intro.setWordWrap(True)
        intro.setStyleSheet("color:#6b7280;")
        layout.addWidget(intro)

        form_box = QGroupBox("Watchdog target")
        form = QFormLayout(form_box)
        target_row = QHBoxLayout()
        self.watch_target = QLineEdit()
        self.watch_target.setPlaceholderText("Plugin folder, DLL/SO/dylib, log or output file")
        target_row.addWidget(self.watch_target, 1)
        file_btn = QPushButton("File…")
        file_btn.clicked.connect(self._browse_watch_file)
        target_row.addWidget(file_btn)
        folder_btn = QPushButton("Folder…")
        folder_btn.clicked.connect(self._browse_watch_folder)
        target_row.addWidget(folder_btn)
        form.addRow("Target:", target_row)
        self.watch_label = QLineEdit()
        form.addRow("Label:", self.watch_label)
        self.watch_interval = QSpinBox()
        self.watch_interval.setRange(2, 3600)
        self.watch_interval.setValue(30)
        self.watch_interval.setSuffix(" s")
        form.addRow("Check every:", self.watch_interval)
        layout.addWidget(form_box)

        meta_box = QGroupBox("Generated plugin")
        meta_form = QFormLayout(meta_box)
        self.watch_id = QLineEdit("watchdog_target")
        self.watch_name = QLineEdit("Watchdog: target")
        self.watch_version = QLineEdit("1.0.0")
        meta_form.addRow("Plugin id:", self.watch_id)
        meta_form.addRow("Name:", self.watch_name)
        meta_form.addRow("Version:", self.watch_version)
        output_row = QHBoxLayout()
        self.watch_output = QLineEdit()
        self.watch_output.setPlaceholderText("Output .qplugin.zip")
        output_row.addWidget(self.watch_output, 1)
        out_btn = QPushButton("Save as…")
        out_btn.clicked.connect(self._browse_watch_output)
        output_row.addWidget(out_btn)
        meta_form.addRow("Output:", output_row)
        layout.addWidget(meta_box)

        row = QHBoxLayout()
        generate = QPushButton("Generate installable watchdog plugin")
        generate.clicked.connect(self._generate_watchdog)
        row.addWidget(generate)
        row.addStretch(1)
        layout.addLayout(row)
        self.watch_log = QPlainTextEdit()
        self.watch_log.setReadOnly(True)
        self.watch_log.setFont(QFont("Consolas", 9))
        layout.addWidget(self.watch_log, 1)
        self._add_scroll_tab(self.watchdog_tabs, tab, "Builder")

    def _set_watch_target(self, path: Path):
        path = Path(path)
        self.watch_target.setText(str(path))
        stem = re.sub(r"[^a-z0-9_]+", "_", path.stem.lower()).strip("_") or "target"
        self.watch_id.setText(f"watchdog_{stem}"[:64])
        self.watch_name.setText(f"Watchdog: {path.name}")
        self.watch_label.setText(path.name)
        if not self.watch_output.text().strip():
            self.watch_output.setText(
                str(Path.home() / "QAH" / "plugin_files" / f"watchdog_{stem}-1.0.0.qplugin.zip")
            )

    def _browse_watch_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select watchdog target", str(Path.home()), "All files (*)")
        if path:
            self._set_watch_target(Path(path))

    def _browse_watch_folder(self):
        path = QFileDialog.getExistingDirectory(self, "Select watchdog target folder")
        if path:
            self._set_watch_target(Path(path))

    def _browse_watch_output(self):
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Save generated watchdog",
            str(self.watch_output.text() or (Path.home() / "watchdog.qplugin.zip")),
            "QAH plugin (*.qplugin.zip *.zip);;All files (*)",
        )
        if path:
            self.watch_output.setText(path)

    def _generate_watchdog(self):
        from . import watchdog_builder

        if not self.watch_target.text().strip():
            QMessageBox.warning(self, "Watchdog Builder", "Select a target first.")
            return
        if not self.watch_output.text().strip():
            QMessageBox.warning(self, "Watchdog Builder", "Choose an output ZIP.")
            return
        try:
            output = watchdog_builder.build_watchdog_plugin(
                Path(self.watch_target.text().strip()),
                plugin_id=self.watch_id.text().strip(),
                name=self.watch_name.text().strip() or "Watchdog",
                version=self.watch_version.text().strip() or "1.0.0",
                label=self.watch_label.text().strip() or "target",
                interval=int(self.watch_interval.value()),
                output_zip=Path(self.watch_output.text().strip()),
            )
        except Exception as exc:
            QMessageBox.critical(self, "Watchdog Builder", str(exc))
            return
        self.watch_log.appendPlainText(f"Generated: {output}")
        self.watch_log.appendPlainText("Install it as a normal QAH plugin, then run its menu action.")
        self.status.setText(f"Watchdog plugin generated: {output}")

    def _build_addons_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        intro = QLabel(
            "Sentinel addons extend audits <b>without becoming QAH plugins</b>. "
            "Each addon is a source package (<code>.qah</code>) with "
            "<code>addon.json</code> and a Python entry point. Addons never load "
            "into Sentinel's process: they run in an isolated child process with "
            "audit hooks, a timeout, a memory limit, read-only targets by default "
            "and only the capabilities they declare."
        )
        intro.setWordWrap(True)
        intro.setStyleSheet("color:#6b7280;")
        layout.addWidget(intro)

        row = QHBoxLayout()
        refresh = QPushButton("Refresh")
        refresh.clicked.connect(self.load_addons)
        row.addWidget(refresh)
        pin = QPushButton("Trust && pin hash")
        pin.clicked.connect(self._addon_pin)
        row.addWidget(pin)
        toggle = QPushButton("Enable / disable")
        toggle.clicked.connect(self._addon_toggle)
        row.addWidget(toggle)
        run = QPushButton("Run selected")
        run.clicked.connect(self._addon_run)
        row.addWidget(run)
        import_btn = QPushButton("Import .qah…")
        import_btn.clicked.connect(self._addon_import)
        row.addWidget(import_btn)
        data_btn = QPushButton("Open data folder")
        data_btn.clicked.connect(self._addon_open_data)
        row.addWidget(data_btn)
        remove = QPushButton("Remove")
        remove.clicked.connect(self._addon_remove)
        row.addWidget(remove)
        row.addStretch(1)
        layout.addLayout(row)

        self.addon_table = QTableWidget(0, 6)
        self.addon_table.setHorizontalHeaderLabels(
            ["Addon", "Version", "API", "Status", "Source", "Capabilities"]
        )
        self.addon_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.addon_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.addon_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.addon_table.verticalHeader().setVisible(False)
        self.addon_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.addon_table.horizontalHeader().setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        self.addon_table.itemSelectionChanged.connect(self._addon_selection_changed)
        self.addon_table.itemDoubleClicked.connect(lambda _item: self._addon_run())
        layout.addWidget(self.addon_table, 1)

        targets_box = QGroupBox("Run targets (optional, one path per line)")
        targets_layout = QVBoxLayout(targets_box)
        self.addon_targets = QPlainTextEdit()
        self.addon_targets.setFixedHeight(64)
        self.addon_targets.setPlaceholderText(
            "Files or folders the addon may read. Requires the read-files capability."
        )
        targets_layout.addWidget(self.addon_targets)
        target_row = QHBoxLayout()
        add_file = QPushButton("Add file…")
        add_file.clicked.connect(self._addon_add_file_target)
        target_row.addWidget(add_file)
        add_folder = QPushButton("Add folder…")
        add_folder.clicked.connect(self._addon_add_folder_target)
        target_row.addWidget(add_folder)
        clear = QPushButton("Clear targets")
        clear.clicked.connect(self.addon_targets.clear)
        target_row.addWidget(clear)
        target_row.addStretch(1)
        targets_layout.addLayout(target_row)
        layout.addWidget(targets_box)

        output_box = QGroupBox("Addon output")
        output_layout = QVBoxLayout(output_box)
        self.addon_output = QPlainTextEdit()
        self.addon_output.setReadOnly(True)
        self.addon_output.setFont(QFont("Consolas", 9))
        self.addon_output.setPlaceholderText(
            "Select an addon, pin its hash, add targets if needed, then Run."
        )
        output_layout.addWidget(self.addon_output)
        layout.addWidget(output_box, 1)

        self.addon_status = QLabel("Addons are disabled until their hash is pinned.")
        self.addon_status.setStyleSheet("color:#6b7280;")
        layout.addWidget(self.addon_status)
        self._add_scroll_tab(self.addons_tabs, tab, "Addons")
        self.load_addons()

    def load_addons(self):
        table = getattr(self, "addon_table", None)
        if table is None:
            return
        selected = self._selected_addon_id()
        try:
            addons = sentinel_addons.discover_addons()
        except Exception as exc:
            self.addon_status.setText(f"Could not read addons: {exc}")
            return
        table.blockSignals(True)
        table.setRowCount(len(addons))
        for row, addon in enumerate(addons):
            name_item = QTableWidgetItem(addon.get("name") or addon["id"])
            name_item.setData(Qt.UserRole, addon["id"])
            name_item.setToolTip(
                (addon.get("description") or "")
                + ("\n\n" + "\n".join(addon.get("errors") or []) if addon.get("errors") else "")
            )
            table.setItem(row, 0, name_item)
            table.setItem(row, 1, QTableWidgetItem(str(addon.get("version") or "")))
            table.setItem(row, 2, QTableWidgetItem(str(addon.get("api_version") or "")))
            status_item = QTableWidgetItem(str(addon.get("status") or ""))
            status_item.setForeground(QColor({
                "ok": "#15803d",
                "unpinned": "#b45309",
                "modified": "#b91c1c",
                "invalid": "#b91c1c",
                "disabled": "#6b7280",
            }.get(str(addon.get("status")), "#374151")))
            table.setItem(row, 3, status_item)
            table.setItem(row, 4, QTableWidgetItem(str(addon.get("source") or "")))
            table.setItem(
                row,
                5,
                QTableWidgetItem(", ".join(addon.get("capabilities") or []) or "—"),
            )
        table.blockSignals(False)
        if selected:
            for row in range(table.rowCount()):
                item = table.item(row, 0)
                if item and item.data(Qt.UserRole) == selected:
                    table.selectRow(row)
                    break
        ok = sum(1 for addon in addons if addon.get("status") == "ok")
        self.addon_status.setText(
            f"{len(addons)} addon(s) installed · {ok} ready · "
            f"{sentinel_addons.addons_dir(False)}"
        )

    def _selected_addon_id(self) -> Optional[str]:
        table = getattr(self, "addon_table", None)
        if table is None:
            return None
        row = table.currentRow()
        if row < 0:
            return None
        item = table.item(row, 0)
        return str(item.data(Qt.UserRole)) if item else None

    def _selected_addon(self) -> Optional[dict]:
        addon_id = self._selected_addon_id()
        if not addon_id:
            return None
        for addon in sentinel_addons.discover_addons():
            if addon["id"] == addon_id:
                return addon
        return None

    def _addon_selection_changed(self):
        addon = self._selected_addon()
        if addon is None:
            return
        lines = [
            f"Addon   : {addon['id']}",
            f"Name    : {addon.get('name', '')}",
            f"Version : {addon.get('version', '')}",
            f"API     : {addon.get('api_version', '')}",
            f"Status  : {addon.get('status', '')}",
            f"Source  : {addon.get('source', '')}",
            f"Entry   : {addon.get('entry', 'run')}",
            f"Timeout : {addon.get('timeout', 30)} s",
            f"Path    : {addon.get('path', '')}",
            f"Digest  : {addon.get('digest', '')}",
            f"Pinned  : {addon.get('pinned_digest', '') or '(not pinned)'}",
            f"Caps    : {', '.join(addon.get('capabilities') or []) or 'none'}",
        ]
        if addon.get("errors"):
            lines.append("")
            lines.extend(f"! {item}" for item in addon["errors"])
        self.addon_output.setPlainText("\n".join(lines))

    def _addon_pin(self):
        addon = self._selected_addon()
        if addon is None:
            QMessageBox.information(self, "Sentinel addons", "Select an addon first.")
            return
        if addon.get("status") == "invalid":
            QMessageBox.warning(
                self,
                "Invalid addon",
                "\n".join(addon.get("errors") or ["The addon is invalid."]),
            )
            return
        answer = QMessageBox.question(
            self,
            "Trust addon hash",
            f"Pin {addon.get('name')} v{addon.get('version')}?\n\n"
            f"SHA256: {addon.get('digest', '')}\n\n"
            "Any later change to the addon files will mark it as modified and "
            "block it until you explicitly re-pin it.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes,
        )
        if answer != QMessageBox.Yes:
            return
        try:
            sentinel_addons.pin_addon(addon["id"])
        except Exception as exc:
            QMessageBox.critical(self, "Pin addon", str(exc))
            return
        self.load_addons()
        self.addon_status.setText(f"Pinned {addon['id']} at {addon.get('digest', '')[:16]}…")

    def _addon_toggle(self):
        addon = self._selected_addon()
        if addon is None:
            QMessageBox.information(self, "Sentinel addons", "Select an addon first.")
            return
        if addon.get("status") == "modified":
            QMessageBox.warning(
                self,
                "Modified addon",
                "This addon changed after it was pinned. Re-pin it only if the "
                "change is expected before enabling it.",
            )
            return
        enabled = bool(addon.get("enabled", True))
        sentinel_addons.set_enabled(addon["id"], not enabled)
        self.load_addons()
        self.addon_status.setText(
            f"{addon['id']} {'disabled' if enabled else 'enabled'}."
        )

    def _addon_add_file_target(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select addon target file", str(Path.home()), "All files (*)"
        )
        if path:
            self._append_addon_target(path)

    def _addon_add_folder_target(self):
        path = QFileDialog.getExistingDirectory(self, "Select addon target folder")
        if path:
            self._append_addon_target(path)

    def _append_addon_target(self, path: str):
        current = self.addon_targets.toPlainText().strip()
        self.addon_targets.setPlainText(
            (current + "\n" if current else "") + path
        )

    def _addon_targets(self) -> List[str]:
        return [
            line.strip()
            for line in self.addon_targets.toPlainText().splitlines()
            if line.strip()
        ]

    def _addon_run(self):
        addon = self._selected_addon()
        if addon is None:
            QMessageBox.information(self, "Sentinel addons", "Select an addon first.")
            return
        if addon.get("status") != "ok":
            QMessageBox.warning(
                self,
                "Addon not ready",
                "\n".join(addon.get("errors") or [
                    f"Addon status is {addon.get('status')!r}. Pin and enable it first."
                ]),
            )
            return
        if self.addon_worker is not None and self.addon_worker.isRunning():
            return
        targets = self._addon_targets()
        caps = ", ".join(addon.get("capabilities") or []) or "none"
        answer = QMessageBox.question(
            self,
            "Run Sentinel addon",
            f"Run {addon.get('name')} v{addon.get('version')}?\n\n"
            f"Capabilities: {caps}\n"
            f"Targets: {len(targets)}\n"
            f"Timeout: {addon.get('timeout', 30)} s\n\n"
            "It runs in an isolated process. Native loading, subprocesses and "
            "undeclared network access are blocked.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return
        self.addon_output.setPlainText(f"Running {addon['id']}…")
        self.addon_status.setText(f"Running {addon['id']} in the addon sandbox…")
        worker = AddonRunWorker(addon["id"], targets, addon.get("timeout"), self)
        worker.done.connect(self._on_addon_done)
        worker.finished.connect(worker.deleteLater)
        self.addon_worker = worker
        worker.start()

    def _on_addon_done(self, result: dict):
        self.addon_worker = None
        lines = [
            f"Addon    : {result.get('addon', '')}",
            f"Status   : {result.get('status', '')}",
            f"Duration : {result.get('duration', 0)} s",
            f"Timeout  : {result.get('timed_out', False)}",
            f"Targets  : {', '.join(result.get('targets') or []) or 'none'}",
            f"Detail   : {result.get('detail', '')}",
            "",
        ]
        if result.get("summary"):
            lines += ["Summary", "-------", str(result["summary"]), ""]
        if result.get("report"):
            lines += ["Report", "------", str(result["report"]), ""]
        findings = result.get("findings") or []
        lines.append(f"Findings: {len(findings)}")
        for finding in findings[:100]:
            if isinstance(finding, dict):
                severity = finding.get("severity") or finding.get("level") or "info"
                title = finding.get("title") or finding.get("message") or finding
                lines.append(f"  [{severity}] {title}")
        if result.get("data"):
            lines += ["", "Data", "----", json.dumps(result["data"], indent=2)[:20000]]
        violations = result.get("violations") or []
        if violations:
            lines += ["", f"Sandbox violations: {len(violations)}"]
            lines.extend(
                f"  {item.get('event', '')}: {item.get('detail', '')}"
                for item in violations[:30]
            )
        if result.get("stderr"):
            lines += ["", "stderr", "------", str(result["stderr"])[-4000:]]
        self.addon_output.setPlainText("\n".join(lines))
        self.addon_status.setText(
            f"Addon {result.get('addon', '')} finished with status "
            f"{result.get('status', '')}."
        )
        if result.get("status") in ("error", "blocked", "timeout"):
            QMessageBox.warning(
                self,
                "Addon result",
                f"The addon finished with status {result.get('status')}.\n\n"
                + str(result.get("detail") or "See the Addon output pane."),
            )

    def _addon_import(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Import Sentinel addon",
            str(Path.home()),
            "Sentinel addon (*.qah *.qah.zip *.zip);;All files (*)",
        )
        if not path:
            return
        try:
            addon = sentinel_addons.install_addon_archive(Path(path), source="local")
        except Exception as exc:
            QMessageBox.critical(self, "Import addon", str(exc))
            return
        self.load_addons()
        self.addon_status.setText(
            f"Imported {addon.get('id')} {addon.get('version')}; pin its hash before running."
        )
        answer = QMessageBox.question(
            self,
            "Addon imported",
            f"Imported {addon.get('name')} v{addon.get('version')}.\n\n"
            f"Capabilities: {', '.join(addon.get('capabilities') or []) or 'none'}\n\n"
            "Newly imported addons stay disabled until their hash is pinned. "
            "Pin it now?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer == QMessageBox.Yes:
            try:
                sentinel_addons.pin_addon(addon["id"])
            except Exception as exc:
                QMessageBox.critical(self, "Pin addon", str(exc))
            self.load_addons()

    def _addon_open_data(self):
        addon = self._selected_addon()
        if addon is None:
            QMessageBox.information(self, "Sentinel addons", "Select an addon first.")
            return
        path = sentinel_addons.addon_data_dir(addon["id"])
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    def _addon_remove(self):
        addon = self._selected_addon()
        if addon is None:
            QMessageBox.information(self, "Sentinel addons", "Select an addon first.")
            return
        answer = QMessageBox.question(
            self,
            "Remove addon",
            f"Remove {addon.get('name')} from Sentinel?\n\n"
            "Its pin and settings are removed too. Data in its data folder is "
            "kept.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return
        try:
            message = sentinel_addons.remove_addon(addon["id"])
        except Exception as exc:
            QMessageBox.critical(self, "Remove addon", str(exc))
            return
        self.load_addons()
        self.addon_status.setText(message)

    def _build_dependencies_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        intro = QLabel(
            "Read-only view of pre-built wheels injected for QAH's frozen Python "
            "by Wheel Plugin Manager. These are <b>packages</b>, not QAH plugins, "
            "so they do not appear in Inventory or Plugin Executions. They are "
            "loaded from <code>plugins/vendor/&lt;target&gt;</code>."
        )
        intro.setWordWrap(True)
        intro.setStyleSheet("color:#6b7280;")
        layout.addWidget(intro)

        row = QHBoxLayout()
        refresh = QPushButton("Refresh")
        refresh.clicked.connect(self.load_dependencies)
        row.addWidget(refresh)
        open_folder = QPushButton("Open set folder")
        open_folder.clicked.connect(self._open_dependency_folder)
        row.addWidget(open_folder)
        copy_path = QPushButton("Copy path")
        copy_path.clicked.connect(self._copy_dependency_path)
        row.addWidget(copy_path)
        remove_package = QPushButton("Remove package")
        remove_package.clicked.connect(self._remove_dependency_package)
        row.addWidget(remove_package)
        remove_set = QPushButton("Remove set")
        remove_set.clicked.connect(self._remove_dependency_set)
        row.addWidget(remove_set)
        row.addStretch(1)
        layout.addLayout(row)

        self.dependency_table = QTableWidget(0, 6)
        self.dependency_table.setHorizontalHeaderLabels(
            ["Target", "Package", "Version", "Python", "Platform", "Path"]
        )
        self.dependency_table.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows
        )
        self.dependency_table.setSelectionMode(
            QAbstractItemView.SelectionMode.SingleSelection
        )
        self.dependency_table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers
        )
        self.dependency_table.verticalHeader().setVisible(False)
        self.dependency_table.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.ResizeMode.ResizeToContents
        )
        self.dependency_table.horizontalHeader().setSectionResizeMode(
            5, QHeaderView.ResizeMode.Stretch
        )
        layout.addWidget(self.dependency_table, 1)

        self.dependency_status = QLabel("")
        self.dependency_status.setStyleSheet("color:#6b7280;")
        layout.addWidget(self.dependency_status)
        self._add_scroll_tab(self.tabs, tab, "Dependencies")
        self.load_dependencies()

    def load_dependencies(self):
        table = getattr(self, "dependency_table", None)
        if table is None:
            return
        try:
            rows = sentinel_dependencies.dependency_rows()
            summary = sentinel_dependencies.summary_text()
        except Exception as exc:
            self.dependency_status.setText(f"Could not read vendor dependencies: {exc}")
            return
        table.setRowCount(len(rows))
        for index, row in enumerate(rows):
            values = [
                row.get("target", ""),
                row.get("package", ""),
                row.get("version", ""),
                row.get("python", ""),
                row.get("platform", ""),
                row.get("path", ""),
            ]
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                if column == 0:
                    item.setData(
                        Qt.UserRole,
                        {
                            "target": row.get("target", ""),
                            "package": row.get("package", ""),
                            "path": row.get("path", ""),
                        },
                    )
                    item.setToolTip(row.get("path", ""))
                table.setItem(index, column, item)
        self.dependency_status.setText(summary)

    def _selected_dependency_info(self) -> Dict[str, str]:
        table = getattr(self, "dependency_table", None)
        if table is None:
            return {}
        row = table.currentRow()
        if row < 0:
            return {}
        item = table.item(row, 0)
        if item is None:
            return {}
        data = item.data(Qt.UserRole)
        return data if isinstance(data, dict) else {"path": str(data or "")}

    def _selected_dependency_path(self) -> str:
        return str(self._selected_dependency_info().get("path") or "")

    def _open_dependency_folder(self):
        path = self._selected_dependency_path()
        if not path:
            QMessageBox.information(
                self, "Dependencies", "Select an injected dependency row first."
            )
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    def _copy_dependency_path(self):
        path = self._selected_dependency_path()
        if not path:
            QMessageBox.information(
                self, "Dependencies", "Select an injected dependency row first."
            )
            return
        QApplication.clipboard().setText(path)
        self.status.setText("Dependency path copied")

    def _remove_dependency_package(self):
        info = self._selected_dependency_info()
        target = str(info.get("target") or "")
        package = str(info.get("package") or "")
        if not target or not package or package == "(empty set)":
            QMessageBox.information(
                self, "Dependencies", "Select a package row first."
            )
            return
        answer = QMessageBox.question(
            self,
            "Remove injected package",
            f"Remove {package} from target {target}?\n\n"
            "Files are deleted from the vendor folder. Modules already imported "
            "in this QAH session stay in memory until restart.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return
        try:
            message = sentinel_dependencies.remove_package(target, package)
        except Exception as exc:
            QMessageBox.critical(self, "Remove package", str(exc))
            return
        self.load_dependencies()
        self.status.setText(message)

    def _remove_dependency_set(self):
        info = self._selected_dependency_info()
        target = str(info.get("target") or "")
        if not target:
            QMessageBox.information(
                self, "Dependencies", "Select a dependency row first."
            )
            return
        answer = QMessageBox.question(
            self,
            "Remove dependency set",
            f"Remove the whole dependency set {target}?\n\n"
            "This deletes every injected package in that set. Modules already "
            "imported in this QAH session stay in memory until restart.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return
        try:
            message = sentinel_dependencies.remove_set(target)
        except Exception as exc:
            QMessageBox.critical(self, "Remove set", str(exc))
            return
        self.load_dependencies()
        self.status.setText(message)

    def _build_docs_tab(self):
        from .sentinel_docs import DOCS_HTML

        tab = QWidget()
        layout = QVBoxLayout(tab)
        browser = QTextBrowser()
        browser.setOpenExternalLinks(False)
        browser.setHtml(DOCS_HTML)
        layout.addWidget(browser, 1)
        self._add_scroll_tab(self.tabs, tab, "Documentation")

    # -- targets / inventory --------------------------------------------
    def refresh_targets(self):
        if self.worker is not None and self.worker.isRunning():
            return
        self.targets = core.find_targets()
        self.results.clear()
        self.table.setRowCount(0)
        self.findings_tree.clear()
        self.cap_table.setRowCount(0)
        for target in self.targets:
            self._append_target_row(target)
        self._refresh_baseline_table()
        self._refresh_capabilities()
        self._refresh_native()
        self._refresh_findings()
        self._refresh_sandbox_targets()
        self._refresh_report_preview()
        self.status.setText(f"{len(self.targets)} plugin(s) found")
        self.action_export.setEnabled(False)

    def _append_target_row(self, target: core.Target):
        row = self.table.rowCount()
        self.table.insertRow(row)
        name = QTableWidgetItem(target.name or target.label)
        name.setData(Qt.ItemDataRole.UserRole, target)
        name.setToolTip(str(target.path))
        self.table.setItem(row, 0, name)
        self.table.setItem(row, 1, QTableWidgetItem(target.version))
        self.table.setItem(row, 2, QTableWidgetItem(target.source))
        for col in range(3, len(self.COLUMNS)):
            self.table.setItem(row, col, QTableWidgetItem("—"))
        self.table.setItem(row, 10, QTableWidgetItem(core.baseline_status(target, self.baseline)))

    def _row_for_path(self, path: str) -> int:
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 0)
            target = item.data(Qt.ItemDataRole.UserRole) if item else None
            if target and str(target.path) == path:
                return row
        return -1

    def _target_for_row(self, row: int) -> Optional[core.Target]:
        item = self.table.item(row, 0)
        return item.data(Qt.ItemDataRole.UserRole) if item else None

    def _selected_targets(self) -> List[core.Target]:
        rows = sorted({index.row() for index in self.table.selectionModel().selectedRows()})
        return [target for row in rows if (target := self._target_for_row(row)) is not None]

    def scan_all(self):
        if self.targets:
            self._start_scan(list(self.targets))

    def scan_selected(self):
        targets = self._selected_targets()
        if not targets:
            QMessageBox.information(self, "Plugin Sentinel", "Select one or more plugins first.")
            return
        self._start_scan(targets)

    def scan_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Scan a plugin file", str(Path.home()),
            "Plugins (*.qplugin.zip *.zip *.whl);;All files (*)",
        )
        if not path:
            return
        target = core.make_target(Path(path), "file")
        existing = {str(item.path) for item in self.targets}
        if str(target.path) not in existing:
            self.targets.append(target)
            self._append_target_row(target)
        self._start_scan([target])

    # -- worker ----------------------------------------------------------
    def _selected_checks(self) -> List[str]:
        return [name for name, action in self.check_actions.items() if action.isChecked()]

    def _start_scan(self, targets):
        if self.worker is not None and self.worker.isRunning():
            QMessageBox.information(self, "Plugin Sentinel", "A scan is already running.")
            return
        checks = self._selected_checks()
        if not checks:
            QMessageBox.warning(self, "Plugin Sentinel", "Select at least one check.")
            return
        worker = ScanWorker(targets, checks, self.policy, self.baseline, parent=self)
        worker.one_done.connect(self._on_one_done)
        worker.progress.connect(self._on_progress)
        worker.all_done.connect(self._on_all_done)
        worker.finished.connect(lambda w=worker: self._on_worker_finished(w))
        self.worker = worker
        self._busy = True
        self.progress.setVisible(True)
        self.progress.setRange(0, len(targets))
        self.progress.setValue(0)
        self.action_stop.setEnabled(True)
        self.action_scan_all.setEnabled(False)
        self.action_scan_selected.setEnabled(False)
        self.action_scan_file.setEnabled(False)
        self.status.setText(f"Scanning {len(targets)} plugin(s)…")
        worker.start()

    def _on_worker_finished(self, worker):
        if self.worker is worker:
            self.worker = None
        worker.deleteLater()
        self._busy = False
        self.progress.setVisible(False)
        self.action_stop.setEnabled(False)
        self.action_scan_all.setEnabled(True)
        self.action_scan_selected.setEnabled(True)
        self.action_scan_file.setEnabled(True)

    def stop(self):
        if self.worker is not None:
            self.worker.stop()
            self.status.setText("Stopping…")

    def _on_progress(self, index, total, label):
        self.progress.setMaximum(total)
        self.progress.setValue(index - 1)
        self.status.setText(f"Scanning {label} ({index}/{total})…")

    def _on_one_done(self, result):
        self.results[result.get("path", "")] = result
        self._update_inventory_row(result)
        self._refresh_findings()
        self._refresh_capabilities()
        self._refresh_native()
        self._refresh_report_preview()
        self.action_export.setEnabled(True)
        self.action_trust.setEnabled(True)

    def _on_all_done(self):
        core.annotate_duplicates(list(self.results.values()), self.policy)
        for result in self.results.values():
            self._update_inventory_row(result)
        self._refresh_findings()
        self._refresh_capabilities()
        self._refresh_native()
        self._refresh_baseline_table()
        self._refresh_report_preview()
        passed = sum(1 for item in self.results.values() if item.get("policy_verdict") == "PASS")
        total = len(self.results)
        self.status.setText(f"Scan finished: {passed}/{total} PASS")

    # -- inventory updates ----------------------------------------------
    def _update_inventory_row(self, result):
        row = self._row_for_path(result.get("path", ""))
        if row < 0:
            return
        values = {
            1: str(result.get("version", "")),
            2: str(result.get("source", "")),
            3: str(result.get("risk_score", 0)),
            4: str(result.get("grade", "A")),
            5: str(result.get("policy_verdict", "PASS")),
            6: str((result.get("counts") or {}).get("critical", 0)),
            7: str((result.get("counts") or {}).get("high", 0)),
            8: str((result.get("counts") or {}).get("medium", 0)),
            9: str((result.get("counts") or {}).get("low", 0)),
            10: str(result.get("baseline", "new")),
            11: ", ".join((result.get("sentinel") or {}).get("capabilities") or []),
        }
        for col, text in values.items():
            item = self.table.item(row, col)
            if item is None:
                item = QTableWidgetItem()
                self.table.setItem(row, col, item)
            item.setText(text)
        grade = str(result.get("grade", "A"))
        risk_item = self.table.item(row, 3)
        risk_item.setForeground(QColor(GRADE_COLORS.get(grade, "#374151")))
        verdict_item = self.table.item(row, 5)
        verdict_item.setForeground(QColor(VERDICT_COLORS.get(values[5], "#374151")))
        for sev, col in (("critical", 6), ("high", 7), ("medium", 8), ("low", 9)):
            item = self.table.item(row, col)
            if int(values[col]) > 0:
                item.setBackground(SEVERITY_COLORS[sev])
        self._apply_filters()

    def _apply_filters(self):
        text = self.search.text().strip().lower()
        source = self.source_filter.currentText()
        verdict = self.verdict_filter.currentText()
        for row in range(self.table.rowCount()):
            target = self._target_for_row(row)
            result = self.results.get(str(target.path)) if target else None
            haystack = " ".join([
                target.name if target else "",
                target.label if target else "",
                target.plugin_id if target else "",
                " ".join((result or {}).get("sentinel", {}).get("capabilities") or []),
            ]).lower()
            show = True
            if text and text not in haystack:
                show = False
            if source != "All sources" and target and target.source != source:
                show = False
            if verdict != "All verdicts" and result and result.get("policy_verdict") != verdict:
                show = False
            if verdict != "All verdicts" and result is None:
                show = False
            self.table.setRowHidden(row, not show)

    def _show_inventory_detail(self):
        targets = self._selected_targets()
        if not targets:
            return
        result = self.results.get(str(targets[0].path))
        if result:
            self.detail.setPlainText(result.get("text", ""))
        else:
            self.detail.setPlainText(
                f"{targets[0].label} has not been scanned yet.\n"
                "Use Scan all, Scan selected or Scan file."
            )

    # -- findings --------------------------------------------------------
    def _refresh_findings(self):
        self.findings_tree.clear()
        for finding in core.flatten_findings(list(self.results.values())):
            item = QTreeWidgetItem([
                str(finding.get("plugin") or ""),
                str(finding.get("severity") or ""),
                str(finding.get("check") or ""),
                str(finding.get("code") or ""),
                str(finding.get("message") or ""),
                str(finding.get("path") or ""),
            ])
            item.setData(0, Qt.ItemDataRole.UserRole, finding)
            sev = finding.get("severity")
            if sev in SEVERITY_COLORS:
                item.setBackground(1, SEVERITY_COLORS[sev])
            self.findings_tree.addTopLevelItem(item)
        self._apply_finding_filters()

    def _apply_finding_filters(self):
        text = self.finding_search.text().strip().lower()
        severity = self.severity_filter.currentText()
        for index in range(self.findings_tree.topLevelItemCount()):
            item = self.findings_tree.topLevelItem(index)
            haystack = " ".join(item.text(col) for col in range(6)).lower()
            show = (not text or text in haystack)
            if severity != "All severities" and item.text(1) != severity:
                show = False
            item.setHidden(not show)

    def _show_finding_detail(self):
        items = self.findings_tree.selectedItems()
        if not items:
            return
        finding = items[0].data(0, Qt.ItemDataRole.UserRole) or {}
        lines = [
            f"{finding.get('code')}  [{finding.get('severity')}]",
            finding.get("message", ""),
            "",
            f"check: {finding.get('check')}",
            f"path: {finding.get('path') or '-'}",
        ]
        if finding.get("line"):
            lines.append(f"line: {finding['line']}")
        if finding.get("detail"):
            lines += ["", finding["detail"]]
        self.finding_detail.setPlainText("\n".join(lines))

    # -- native libraries ------------------------------------------------
    def _refresh_native(self):
        self.native_table.setRowCount(0)
        for result in self.results.values():
            for library in result.get("native") or []:
                row = self.native_table.rowCount()
                self.native_table.insertRow(row)
                findings = library.get("findings") or []
                sev = ""
                for candidate in ("critical", "high", "medium", "low", "info"):
                    if any(item.get("severity") == candidate for item in findings):
                        sev = candidate
                        break
                values = [
                    str(result.get("label") or result.get("id") or ""),
                    str(library.get("name") or ""),
                    str(library.get("format") or ""),
                    str(library.get("arch") or ""),
                    str(library.get("bits") or ""),
                    str(library.get("size") or ""),
                    str(library.get("entropy") or ""),
                    str(library.get("signed") or ""),
                    f"{len(findings)} {sev}".strip(),
                    str(library.get("sha256") or ""),
                ]
                for col, value in enumerate(values):
                    item = QTableWidgetItem(value)
                    item.setData(Qt.ItemDataRole.UserRole, library)
                    if col == 8 and sev in SEVERITY_COLORS:
                        item.setBackground(SEVERITY_COLORS[sev])
                    self.native_table.setItem(row, col, item)

    def _show_native_detail(self):
        rows = self.native_table.selectionModel().selectedRows()
        if not rows:
            return
        item = self.native_table.item(rows[0].row(), 0)
        library = item.data(Qt.ItemDataRole.UserRole) if item else None
        if not library:
            return
        lines = [
            f"{library.get('name')}",
            f"format: {library.get('format')}  arch: {library.get('arch')}  bits: {library.get('bits')}",
            f"size: {library.get('size')}  entropy: {library.get('entropy')}  signed: {library.get('signed')}",
            f"sha256: {library.get('sha256')}",
            "",
            "flags:",
        ]
        lines += [f"  - {flag}" for flag in library.get("flags") or []] or ["  none"]
        lines += ["", "imports:"]
        lines += [f"  - {name}" for name in (library.get("imports") or [])[:200]] or ["  none"]
        lines += ["", "findings:"]
        lines += [f"  - [{f.get('severity')}] {f.get('code')}: {f.get('message')}" for f in library.get("findings") or []] or ["  none"]
        self.native_detail.setPlainText("\n".join(lines))

    # -- sandbox ---------------------------------------------------------
    def _refresh_sandbox_targets(self):
        current = self.sandbox_target.currentData()
        self.sandbox_target.clear()
        for target in self.targets:
            label = f"{target.name or target.label}  ({target.source})"
            self.sandbox_target.addItem(label, str(target.path))
        if current:
            index = self.sandbox_target.findData(current)
            if index >= 0:
                self.sandbox_target.setCurrentIndex(index)

    def _browse_sandbox_target(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Sandbox a plugin archive", str(Path.home()),
            "Plugins (*.qplugin.zip *.zip *.whl);;All files (*)",
        )
        if not path:
            return
        target = core.make_target(Path(path), "file")
        if not any(str(item.path) == str(target.path) for item in self.targets):
            self.targets.append(target)
            self._append_target_row(target)
        label = f"{target.name or target.label}  (file)"
        self.sandbox_target.addItem(label, str(target.path))
        self.sandbox_target.setCurrentIndex(self.sandbox_target.count() - 1)

    def run_sandbox(self):
        if self.sandbox_worker is not None and self.sandbox_worker.isRunning():
            QMessageBox.information(self, "Plugin Sentinel", "A sandbox run is already active.")
            return
        path = self.sandbox_target.currentData()
        if not path:
            QMessageBox.information(self, "Plugin Sentinel", "Select a target first.")
            return
        self.sandbox_output.setPlainText("Running sandbox…")
        self.sandbox_status.setText("Running…")
        self.sandbox_status.setStyleSheet("color:#b45309;")
        self.sandbox_run_btn.setEnabled(False)
        worker = SandboxWorker(
            path,
            self.sandbox_timeout.value(),
            self.sandbox_memory.value(),
            self.sandbox_network.isChecked(),
            parent=self,
        )
        worker.done.connect(self._on_sandbox_done)
        worker.finished.connect(lambda w=worker: self._on_sandbox_worker_finished(w))
        self.sandbox_worker = worker
        worker.start()

    def _on_sandbox_done(self, result):
        self.sandbox_result = result
        lines = [
            f"status: {result.get('status')}",
            f"target: {result.get('target')}",
            f"duration: {result.get('duration')} s",
            f"return code: {result.get('returncode')}",
            f"timeout: {result.get('timeout')} s",
            f"memory limit: {result.get('memory_limit_mb')} MB (enforced: {result.get('memory_limit_enforced')})",
            f"network allowed: {result.get('network_allowed')}",
            "",
            "violations:",
        ]
        violations = result.get("violations") or []
        lines += [f"  - [{item.get('event')}] {item.get('detail')}" for item in violations] or ["  none"]
        if result.get("detail"):
            lines += ["", "detail:", result["detail"]]
        if result.get("stdout"):
            lines += ["", "stdout:", result["stdout"]]
        if result.get("stderr"):
            lines += ["", "stderr:", result["stderr"]]
        self.sandbox_output.setPlainText("\n".join(lines))
        status = result.get("status", "error")
        color = {"ok": "#15803d", "blocked": "#b91c1c", "timeout": "#b45309"}.get(status, "#b91c1c")
        self.sandbox_status.setText(f"Sandbox: {status}")
        self.sandbox_status.setStyleSheet(f"color:{color};font-weight:bold;")

    def _on_sandbox_worker_finished(self, worker):
        if self.sandbox_worker is worker:
            self.sandbox_worker = None
        worker.deleteLater()
        self.sandbox_run_btn.setEnabled(True)

    # -- capabilities ----------------------------------------------------
    def _refresh_capabilities(self):
        self.cap_table.setRowCount(0)
        for result in self.results.values():
            row = self.cap_table.rowCount()
            self.cap_table.insertRow(row)
            self.cap_table.setItem(row, 0, QTableWidgetItem(result.get("label") or result.get("id") or ""))
            caps = set((result.get("sentinel") or {}).get("capabilities") or [])
            for col, (name, _label) in enumerate(core.CAPABILITIES, start=1):
                item = QTableWidgetItem("●" if name in caps else "")
                item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                if name in caps:
                    item.setForeground(QColor("#1d4ed8"))
                self.cap_table.setItem(row, col, item)

    # -- baseline --------------------------------------------------------
    def _refresh_baseline_table(self):
        entries = (self.baseline.get("plugins") or {})
        self.baseline_table.setRowCount(0)
        for key, entry in sorted(entries.items()):
            row = self.baseline_table.rowCount()
            self.baseline_table.insertRow(row)
            digest = str(entry.get("digest", ""))
            status = "trusted"
            for target in self.targets:
                if core.baseline_key(target) == key:
                    status = core.baseline_status(target, self.baseline)
                    break
            values = [key, entry.get("name", ""), entry.get("version", ""), digest[:16] + ("…" if len(digest) > 16 else ""), entry.get("trusted_at", ""), status]
            for col, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setToolTip(digest if col == 3 else str(value))
                self.baseline_table.setItem(row, col, item)
        self.action_forget.setEnabled(bool(entries))

    def trust_selected(self):
        targets = self._selected_targets()
        if not targets:
            QMessageBox.information(self, "Plugin Sentinel", "Select an inventory plugin first.")
            return
        for target in targets:
            core.trust_target(target, self.baseline)
        core.save_baseline(self.baseline)
        self._refresh_baseline_table()
        self.status.setText(f"Trusted {len(targets)} plugin(s)")
        for result in self.results.values():
            result["baseline"] = core.baseline_status(
                next((t for t in self.targets if str(t.path) == result.get("path")), targets[0]),
                self.baseline,
            )
            self._update_inventory_row(result)

    def forget_selected(self):
        targets = self._selected_targets()
        if targets:
            for target in targets:
                core.forget_target(target, self.baseline)
            core.save_baseline(self.baseline)
            self._refresh_baseline_table()
            for result in self.results.values():
                target = next((item for item in self.targets if str(item.path) == result.get("path")), None)
                if target is not None:
                    result["baseline"] = core.baseline_status(target, self.baseline)
                    self._update_inventory_row(result)
            self.status.setText(f"Removed {len(targets)} baseline pin(s)")
            return
        self.forget_selected_baseline()

    def forget_selected_baseline(self):
        row = self.baseline_table.currentRow()
        if row < 0:
            QMessageBox.information(self, "Plugin Sentinel", "Select a baseline entry first.")
            return
        key_item = self.baseline_table.item(row, 0)
        if key_item is None:
            return
        (self.baseline.get("plugins") or {}).pop(key_item.text(), None)
        core.save_baseline(self.baseline)
        self._refresh_baseline_table()

    def reload_baseline(self):
        self.baseline = core.load_baseline()
        self._refresh_baseline_table()
        self.refresh_targets()

    def save_baseline(self):
        core.save_baseline(self.baseline)
        self.status.setText(f"Baseline saved to {core.baseline_path()}")

    # -- policy ----------------------------------------------------------
    def _load_policy_ui(self):
        self.fail_combo.setCurrentText(str(self.policy.get("fail_on", "high")))
        self.risk_spin.setValue(int(self.policy.get("max_risk", 60)))
        self.trusted_check.setChecked(bool(self.policy.get("require_trusted")))
        allowed = set(self.policy.get("allowed_capabilities") or [name for name, _ in core.CAPABILITIES])
        for name, check in self.cap_checks.items():
            check.setChecked(name in allowed)

    def _policy_from_ui(self) -> dict:
        return {
            "fail_on": self.fail_combo.currentText(),
            "max_risk": int(self.risk_spin.value()),
            "require_trusted": bool(self.trusted_check.isChecked()),
            "allowed_capabilities": [name for name, check in self.cap_checks.items() if check.isChecked()],
        }

    def save_policy_ui(self):
        self.policy = self._policy_from_ui()
        core.save_policy(self.policy)
        self.policy_status.setText(f"Policy saved to {core.policy_path()}")
        self.evaluate_results()

    def evaluate_results(self):
        for result in self.results.values():
            result["policy"] = core.evaluate_policy(result, self.policy, result.get("baseline", "new"))
            result["policy_verdict"] = result["policy"]["verdict"]
            self._update_inventory_row(result)
        blocks = [item for item in self.results.values() if item.get("policy_verdict") == "BLOCK"]
        warns = [item for item in self.results.values() if item.get("policy_verdict") == "WARN"]
        self.policy_status.setText(
            f"Evaluated {len(self.results)} plugin(s): "
            f"{len(blocks)} BLOCK, {len(warns)} WARN, "
            f"{len(self.results) - len(blocks) - len(warns)} PASS"
        )
        self._refresh_findings()
        self._refresh_report_preview()

    # -- report ----------------------------------------------------------
    def _refresh_report_preview(self):
        if not self.results:
            self.report_view.setHtml("<p style='color:#6b7280'>Run a scan to generate a report.</p>")
            return
        self.report_view.setHtml(core.report_to_html(list(self.results.values()), self.policy))

    def export_report(self, fmt: Optional[str] = None):
        if not self.results:
            QMessageBox.information(self, "Plugin Sentinel", "Run a scan first.")
            return
        if fmt is None:
            fmt = "json"
        suffix = {"json": "json", "md": "md", "html": "html", "csv": "csv"}.get(fmt, "json")
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Sentinel report",
            str(Path.home() / f"plugin-sentinel-{time.strftime('%Y%m%d-%H%M')}.{suffix}"),
            f"{suffix.upper()} (*.{suffix});;All files (*)",
        )
        if not path:
            return
        try:
            if fmt == "json":
                text = core.report_to_json(list(self.results.values()), self.policy, self.baseline)
            elif fmt == "md":
                text = core.report_to_markdown(list(self.results.values()))
            elif fmt == "html":
                text = core.report_to_html(list(self.results.values()), self.policy)
            else:
                text = core.report_to_csv(list(self.results.values()))
            Path(path).write_text(text, encoding="utf-8")
        except Exception as exc:
            QMessageBox.critical(self, "Plugin Sentinel", f"Could not write report:\n{exc}")
            return
        self.status.setText(f"Report written to {path}")

    # -- lifecycle -------------------------------------------------------
    def cleanup(self):
        worker = self.worker
        if worker is not None:
            try:
                worker.finished.disconnect()
            except Exception:
                pass
            if worker.isRunning():
                worker.stop()
                worker.wait(5000)
            if worker.isRunning():
                worker.setParent(None)
                worker.finished.connect(worker.deleteLater)
            else:
                worker.deleteLater()
        self.worker = None
        sandbox = self.sandbox_worker
        if sandbox is not None:
            sandbox.wait(3000)
            if sandbox.isRunning():
                sandbox.setParent(None)
                sandbox.finished.connect(sandbox.deleteLater)
            else:
                sandbox.deleteLater()
        self.sandbox_worker = None
        addon_worker = self.addon_worker
        if addon_worker is not None:
            addon_worker.wait(3000)
            if addon_worker.isRunning():
                addon_worker.setParent(None)
                addon_worker.finished.connect(addon_worker.deleteLater)
            else:
                addon_worker.deleteLater()
        self.addon_worker = None
        try:
            self.runtime_tab.cleanup()
        except Exception:
            pass
        try:
            self.watchdog_tab.cleanup()
        except Exception:
            pass
