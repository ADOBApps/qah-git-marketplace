# Watchdog Builder: template and examples

## How it works

The Watchdog Builder lives in **Plugin Sentinel → Watchdog → Builder**. It calls
`watchdog_builder.build_watchdog_plugin(...)`.

The current builder generates a **hash watchdog**:

1. User chooses a target file or folder, plugin id, name, version, label and
   interval.
2. `build_watchdog_plugin` resolves the target and validates the id.
3. It writes a `.qplugin.zip` containing:
   - `manifest.json` (category `development`, no dependencies),
   - `__init__.py` generated from `_code_template(...)`,
   - `icon.svg`,
   - `README.md`.
4. The generated plugin, on first check, stores a SHA256 baseline in
   `%USERPROFILE%\QAH\<plugin_id>\baseline.json`.
5. On later checks it recomputes the digest and writes
   `%USERPROFILE%\QAH\<plugin_id>\report.json` with status
   `pinned`, `ok`, `changed`, `missing` or `error`.
6. Menu actions: **Check watchdog now** and **Open watchdog report**.

The generated code uses only PySide6 and the standard library. It does **not**
need Sentinel at runtime. It also does **not** kill, unload, throttle or modify
the target.

## Code template

The template is the `_code_template` string in
`plugin_sentinel/watchdog_builder.py`. Its essential parts are:

```python
PLUGIN_ID = "watchdog_example"
TARGET = Path(r"C:\path\to\target")
LABEL = "target"
INTERVAL_MS = 60 * 1000
STATE_DIR = Path.home() / "QAH" / PLUGIN_ID
BASELINE = STATE_DIR / "baseline.json"
REPORT = STATE_DIR / "report.json"


def _digest(path: Path) -> str:
    hasher = hashlib.sha256()
    if path.is_dir():
        for entry in sorted(path.rglob("*")):
            if entry.is_file() and "__pycache__" not in entry.parts:
                hasher.update(str(entry.relative_to(path)).encode())
                hasher.update(entry.read_bytes())
    else:
        hasher.update(path.read_bytes())
    return hasher.hexdigest()


class Watchdog(QObject):
    def __init__(self, plugin_info):
        super().__init__()
        self.timer = QTimer(self)
        self.timer.setInterval(INTERVAL_MS)
        self.timer.timeout.connect(self.check)
        QTimer.singleShot(1500, self.check)
        QTimer.singleShot(1800, self.timer.start)

    def check(self):
        if not TARGET.exists():
            self._write_report("missing", "")
            return
        current = _digest(TARGET)
        previous = read_baseline()
        if not previous:
            write_baseline(current)
            self._write_report("pinned", current)
        else:
            self._write_report("ok" if current == previous else "changed", current, previous)
```

## Generate from Python

```python
from pathlib import Path
from plugin_sentinel import watchdog_builder

watchdog_builder.build_watchdog_plugin(
    Path(r"C:\Users\HP\QAH\plugins\python_plugins\my_plugin"),
    plugin_id="watchdog_my_plugin",
    name="Watchdog: my plugin",
    version="1.0.0",
    label="my plugin folder",
    interval=60,
    output_zip=Path(r"C:\Users\HP\QAH\plugin_files\watchdog_my_plugin-1.0.0.qplugin.zip"),
)
```

Install the ZIP as a normal QAH plugin.

## Examples

### 1. Hash watchdog

Use the Builder with a plugin folder, DLL/SO/dylib, log or output file. This is
the existing path and catches content drift.

### 2. Static resource audit addon

`sentinel_resource_audit` is a report-only Sentinel addon. It scans plugin
folders for heavy imports and declared dependencies (`pydft`, `pyqint`, `numba`,
`scipy`, `matplotlib`, `torch`, `tensorflow`, `jax`, `cupy`, `pyscf`, `rdkit`)
and returns findings/report.

It has no process-control capability. Addons cannot call Sentinel internals,
spawn processes, unload plugins or kill anything.

### 3. Runtime Resource Watchdog plugin

`resource_watchdog` is a native Tools plugin, not a generated hash watchdog. It:

- reports QAH PID, CPU %, RSS, thread count and child processes;
- lists heavy modules currently loaded in QAH;
- warns when CPU or RSS crosses a threshold;
- writes `%USERPROFILE%\QAH\resource_watchdog\report.json`;
- never kills, unloads, suspends or throttles.

QAH plugins share one process, so CPU is attributed to QAH as a whole. The
watchdog can show that `pyqint`/`pydft` are loaded and that QAH is busy, but not
which plugin caused it.

## Why not let an addon kill?

Sentinel addons are isolated child processes with capability limits. Giving an
addon process-control authority would defeat that containment model. Runtime
enforcement belongs in Sentinel's Runtime/Plugin Executions UI or a native
plugin, and even there the safe default should be **warn**, not kill.
