"""Live runtime monitor (htop-style) for Plugin Sentinel."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QCheckBox,
    QComboBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

try:
    from . import sentinel_dependencies

    sentinel_dependencies.activate()
except Exception:
    pass

try:
    import psutil  # type: ignore
except Exception:
    psutil = None

try:
    from .sentinel_core import state_dir
except Exception:
    def state_dir() -> Path:
        root = Path.home() / "QAH" / "plugin_sentinel"
        root.mkdir(parents=True, exist_ok=True)
        return root


class RuntimeTab(QWidget):
    COLUMNS = ("PID", "Process", "CPU %", "Memory MB", "Threads", "Status", "User")

    def __init__(self, parent=None):
        super().__init__(parent)
        self._timer = QTimer(self)
        self._timer.setInterval(2000)
        self._timer.timeout.connect(self.refresh)
        self._last_net = None
        self._settings_path = state_dir() / "runtime_settings.json"
        self._build_ui()
        self._load_settings()
        # Do not refresh or start the timer until the tab is actually shown.
        self._timer.stop()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(6)

        top = QHBoxLayout()
        self.cpu_label = QLabel("CPU —")
        self.cpu_bar = QProgressBar()
        self.cpu_bar.setRange(0, 100)
        self.cpu_bar.setMaximumWidth(180)
        self.mem_label = QLabel("Memory —")
        self.mem_bar = QProgressBar()
        self.mem_bar.setRange(0, 100)
        self.mem_bar.setMaximumWidth(180)
        self.disk_label = QLabel("Disk —")
        self.net_label = QLabel("Net —")
        for widget in (self.cpu_label, self.cpu_bar, self.mem_label, self.mem_bar, self.disk_label, self.net_label):
            top.addWidget(widget)
        top.addStretch(1)
        self.source_label = QLabel("")
        self.source_label.setStyleSheet("color:#6b7280;")
        top.addWidget(self.source_label)
        self.interval_combo = QComboBox()
        for label, value in (
            ("0.5 s", 500),
            ("1 s", 1000),
            ("2 s", 2000),
            ("5 s", 5000),
            ("10 s", 10000),
        ):
            self.interval_combo.addItem(label, value)
        self.interval_combo.setToolTip("Runtime refresh interval while this tab is visible")
        self.interval_combo.currentIndexChanged.connect(self._interval_changed)
        top.addWidget(self.interval_combo)
        self.pause_check = QCheckBox("Pause")
        self.pause_check.setToolTip("Stop runtime sampling without closing the tab")
        self.pause_check.toggled.connect(self._pause_changed)
        top.addWidget(self.pause_check)
        self.sort_combo = QComboBox()
        self.sort_combo.addItems(["Sort: CPU", "Sort: memory", "Sort: PID"])
        self.sort_combo.currentTextChanged.connect(lambda _text: self.refresh())
        top.addWidget(self.sort_combo)
        self.qah_only = QCheckBox("QAH process tree")
        self.qah_only.setToolTip("Show only QAH and its child processes")
        self.qah_only.toggled.connect(lambda _checked: self.refresh())
        top.addWidget(self.qah_only)
        refresh = QPushButton("Refresh")
        refresh.clicked.connect(lambda _checked=False: self.refresh())
        top.addWidget(refresh)
        layout.addLayout(top)

        self.view_tabs = QTabWidget()
        process_tab = QWidget()
        process_layout = QVBoxLayout(process_tab)
        process_layout.setContentsMargins(0, 0, 0, 0)
        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(list(self.COLUMNS))
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setStretchLastSection(True)
        process_layout.addWidget(self.table, 1)
        self.view_tabs.addTab(process_tab, "Processes")

        execution_tab = QWidget()
        execution_layout = QVBoxLayout(execution_tab)
        execution_layout.setContentsMargins(0, 0, 0, 0)
        note = QLabel(
            "QAH plugins run inside the QAH process, not as separate processes. "
            "Stopping a user plugin asks QAH's PluginManager to unload it. "
            "System and wheel plugins are protected."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color:#6b7280;")
        execution_layout.addWidget(note)
        exec_row = QHBoxLayout()
        refresh_plugins = QPushButton("Refresh plugin list")
        refresh_plugins.clicked.connect(lambda _checked=False: self._refresh_executions())
        exec_row.addWidget(refresh_plugins)
        self.stop_plugin_btn = QPushButton("Stop selected user plugin")
        self.stop_plugin_btn.clicked.connect(self._stop_selected_plugin)
        exec_row.addWidget(self.stop_plugin_btn)
        exec_row.addStretch(1)
        execution_layout.addLayout(exec_row)
        self.plugin_table = QTableWidget(0, 5)
        self.plugin_table.setHorizontalHeaderLabels(
            ["Plugin", "Version", "Source", "Loaded", "QAH PID"]
        )
        self.plugin_table.verticalHeader().setVisible(False)
        self.plugin_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.plugin_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.plugin_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.plugin_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.plugin_table.horizontalHeader().setStretchLastSection(True)
        execution_layout.addWidget(self.plugin_table, 1)
        self.execution_status = QLabel("Plugin execution view")
        self.execution_status.setStyleSheet("color:#6b7280;")
        execution_layout.addWidget(self.execution_status)
        self.view_tabs.addTab(execution_tab, "Plugin Executions")
        self.execution_view = execution_tab
        self.view_tabs.currentChanged.connect(self._view_changed)
        layout.addWidget(self.view_tabs, 1)

        self.status = QLabel("Live view · updates while this tab is visible")
        self.status.setStyleSheet("color:#6b7280;")
        layout.addWidget(self.status)

    def _load_settings(self):
        interval = int(self._timer.interval())
        paused = False
        try:
            data = json.loads(self._settings_path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                interval = int(data.get("interval_ms", interval))
                paused = bool(data.get("paused", False))
        except Exception:
            pass
        index = self.interval_combo.findData(interval)
        if index < 0:
            index = self.interval_combo.findData(2000)
        if index < 0:
            index = 0
        self.interval_combo.blockSignals(True)
        self.interval_combo.setCurrentIndex(index)
        self.interval_combo.blockSignals(False)
        self._timer.setInterval(int(self.interval_combo.itemData(index) or 2000))
        self.pause_check.blockSignals(True)
        self.pause_check.setChecked(paused)
        self.pause_check.blockSignals(False)
        self._update_source_label()
        self._update_status()

    def _save_settings(self):
        data = {
            "interval_ms": int(self._timer.interval()),
            "paused": bool(self.pause_check.isChecked()),
        }
        try:
            self._settings_path.parent.mkdir(parents=True, exist_ok=True)
            self._settings_path.write_text(
                json.dumps(data, indent=2), encoding="utf-8"
            )
        except OSError:
            pass

    def _update_source_label(self):
        if psutil is not None:
            text = f"source: psutil {getattr(psutil, '__version__', '')}".strip()
        elif os.name == "nt":
            text = "source: tasklist (psutil not installed)"
        else:
            text = "source: ps (psutil not installed)"
        if self.pause_check.isChecked():
            text += " · paused"
        self.source_label.setText(text)

    def _update_status(self, count=None):
        if self.pause_check.isChecked():
            self.status.setText("Paused · no runtime sampling")
            return
        seconds = self._timer.interval() / 1000
        parts = ["Live view"]
        if count is not None:
            parts.append(f"{count} process(es)")
        parts.append(f"updates every {seconds:g} s while visible")
        parts.append(f"QAH PID {os.getpid()}")
        self.status.setText(" · ".join(parts))

    def _interval_changed(self, _index: int):
        value = int(self.interval_combo.currentData() or 2000)
        self._timer.setInterval(value)
        self._save_settings()
        if self.isVisible() and not self.pause_check.isChecked():
            self._timer.start()
            self.refresh()
        self._update_status()

    def _pause_changed(self, checked: bool):
        if checked:
            self._timer.stop()
        elif self.isVisible():
            self._timer.start()
            self.refresh()
        self._save_settings()
        self._update_source_label()
        self._update_status()

    def _system_metrics(self):
        if psutil is not None:
            cpu = psutil.cpu_percent(interval=None)
            memory = psutil.virtual_memory()
            disk = shutil.disk_usage(str(Path.home()))
            net = psutil.net_io_counters()
            return cpu, memory.percent, f"{disk.used / (1024**3):.1f}/{disk.total / (1024**3):.1f} GB", net
        cpu = 0.0
        memory_percent = 0.0
        try:
            import ctypes

            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.c_ulong),
                    ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong),
                    ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
                ]

            status = MEMORYSTATUSEX()
            status.dwLength = ctypes.sizeof(status)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status))
            memory_percent = float(status.dwMemoryLoad)
        except Exception:
            pass
        disk = shutil.disk_usage(str(Path.home()))
        return cpu, memory_percent, f"{disk.used / (1024**3):.1f}/{disk.total / (1024**3):.1f} GB", None

    def _qah_tree(self):
        if psutil is None:
            return None
        try:
            root = psutil.Process(os.getpid())
            return {root.pid} | {child.pid for child in root.children(recursive=True)}
        except Exception:
            return {os.getpid()}

    def _process_rows(self):
        rows = []
        qah_tree = self._qah_tree()
        if psutil is not None:
            for pid in psutil.pids():
                try:
                    process = psutil.Process(pid)
                    with process.oneshot():
                        cpu = process.cpu_percent(interval=None)
                        memory = process.memory_info().rss / (1024**2)
                        threads = process.num_threads()
                        name = process.name()
                        status = process.status()
                        try:
                            user = process.username()
                        except Exception:
                            user = ""
                    rows.append((pid, name, cpu, memory, threads, status, user))
                except Exception:
                    continue
        else:
            rows = self._fallback_process_rows()
        if qah_tree and self.qah_only.isChecked() is False:
            pass
        elif qah_tree and self.qah_only.isChecked():
            rows = [row for row in rows if row[0] in qah_tree]
        sort_key = self.sort_combo.currentText()
        if sort_key == "Sort: memory":
            rows.sort(key=lambda row: row[3], reverse=True)
        elif sort_key == "Sort: PID":
            rows.sort(key=lambda row: row[0])
        else:
            rows.sort(key=lambda row: row[2], reverse=True)
        return rows[:80], qah_tree or set()

    def _fallback_process_rows(self):
        rows = []
        try:
            if os.name == "nt":
                output = subprocess.check_output(
                    ["tasklist", "/FO", "CSV", "/NH"],
                    text=True,
                    errors="replace",
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
                import csv
                import io

                for row in csv.reader(io.StringIO(output)):
                    if len(row) < 5:
                        continue
                    try:
                        pid = int(row[1])
                    except ValueError:
                        continue
                    memory_text = row[4].replace(" K", "").replace(",", "").strip()
                    memory_mb = 0.0
                    try:
                        memory_mb = float(memory_text) / 1024
                    except ValueError:
                        pass
                    rows.append((pid, row[0], 0.0, memory_mb, 0, row[2], ""))
            else:
                output = subprocess.check_output(
                    ["ps", "-eo", "pid=,comm=,%cpu=,%mem=,rss=,stat=,user="],
                    text=True,
                    errors="replace",
                )
                for line in output.splitlines():
                    parts = line.split(None, 6)
                    if len(parts) < 7:
                        continue
                    try:
                        rows.append((int(parts[0]), parts[1], float(parts[2]), float(parts[4]) / 1024, 0, parts[5], parts[6]))
                    except ValueError:
                        continue
        except Exception:
            pass
        return rows

    def _plugin_manager(self):
        candidates = []
        for widget in QApplication.topLevelWidgets():
            manager = getattr(widget, "plugin_manager", None)
            if manager is not None and hasattr(manager, "plugins"):
                score = len(getattr(manager, "plugins", {}) or {}) + 10 * len(getattr(manager, "loaded_plugins", {}) or {})
                candidates.append((score, manager))
        if not candidates:
            for widget in QApplication.allWidgets():
                manager = getattr(widget, "plugin_manager", None)
                if manager is not None and hasattr(manager, "plugins"):
                    score = len(getattr(manager, "plugins", {}) or {}) + 10 * len(getattr(manager, "loaded_plugins", {}) or {})
                    candidates.append((score, manager))
        if not candidates:
            return None
        return max(candidates, key=lambda item: item[0])[1]

    def _selected_plugin_id(self) -> str:
        try:
            rows = self.plugin_table.selectionModel().selectedRows()
        except Exception:
            return ""
        if not rows:
            return ""
        item = self.plugin_table.item(rows[0].row(), 0)
        return str(item.data(Qt.ItemDataRole.UserRole) or "") if item else ""

    def _refresh_executions(self):
        manager = self._plugin_manager()
        selected_id = self._selected_plugin_id()
        scroll = self.plugin_table.verticalScrollBar().value()
        self.plugin_table.blockSignals(True)
        self.plugin_table.setRowCount(0)
        if manager is None:
            self.plugin_table.blockSignals(False)
            self.execution_status.setText(
                "QAH plugin manager was not found. Open a QAH plugin tab first, "
                "then click Refresh plugin list."
            )
            return
        loaded = set(getattr(manager, "loaded_plugins", {}) or {})
        plugins = list((getattr(manager, "plugins", {}) or {}).values())
        if not plugins:
            self.plugin_table.blockSignals(False)
            self.execution_status.setText(
                "QAH plugin manager found, but its registry is empty. "
                "Use Plugins → Scan for new or removed plugins, then refresh."
            )
            return
        selected_row = -1
        for info in sorted(plugins, key=lambda item: str(getattr(item, "name", "")).lower()):
            plugin_id = str(getattr(info, "id", "") or "")
            source = str(getattr(info, "source", "") or ("user" if getattr(info, "is_user_plugin", False) else "system"))
            row = self.plugin_table.rowCount()
            self.plugin_table.insertRow(row)
            values = [
                str(getattr(info, "name", plugin_id)),
                str(getattr(info, "version", "")),
                source,
                "yes" if plugin_id in loaded else "no",
                str(os.getpid()),
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(value)
                item.setData(Qt.ItemDataRole.UserRole, plugin_id)
                self.plugin_table.setItem(row, col, item)
            if source != "user":
                self.plugin_table.item(row, 2).setBackground(QColor("#e5e7eb"))
            if plugin_id == selected_id:
                selected_row = row
        if selected_row >= 0:
            self.plugin_table.selectRow(selected_row)
        self.plugin_table.verticalScrollBar().setValue(scroll)
        self.plugin_table.blockSignals(False)
        self.execution_status.setText(
            f"{len(plugins)} plugin(s) · {len(loaded)} loaded · QAH PID {os.getpid()}"
        )

    def _view_changed(self, _index: int):
        if self.view_tabs.currentWidget() is self.execution_view:
            self._refresh_executions()

    def _stop_selected_plugin(self):
        manager = self._plugin_manager()
        if manager is None:
            QMessageBox.information(self, "Plugin Sentinel", "QAH plugin manager was not found.")
            return
        plugin_id = self._selected_plugin_id()
        if not plugin_id:
            QMessageBox.information(self, "Plugin Sentinel", "Select a plugin execution first.")
            return
        if plugin_id == "plugin_sentinel":
            QMessageBox.information(self, "Plugin Sentinel", "Sentinel cannot unload itself from this view.")
            return
        info = (getattr(manager, "plugins", {}) or {}).get(plugin_id)
        source = str(getattr(info, "source", "") or ("user" if getattr(info, "is_user_plugin", False) else "system")) if info else "system"
        if source != "user":
            QMessageBox.information(
                self,
                "Protected plugin",
                "System and wheel plugins are protected. Use the QAH installer or the wheel manager.",
            )
            return
        if plugin_id not in (getattr(manager, "loaded_plugins", {}) or {}):
            QMessageBox.information(self, "Plugin Sentinel", "This plugin is not loaded.")
            return
        if QMessageBox.question(
            self,
            "Stop user plugin",
            f"Ask QAH to unload {getattr(info, 'name', plugin_id)}?\n\n"
            "This calls the plugin's cleanup and closes its UI. Background threads "
            "that ignore cleanup may keep running.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        ) != QMessageBox.Yes:
            return
        try:
            manager.unload_plugin(plugin_id)
            self.execution_status.setText(f"Unloaded user plugin: {plugin_id}")
        except Exception as exc:
            QMessageBox.critical(self, "Plugin Sentinel", f"Could not unload plugin:\n{exc}")
        self._refresh_executions()

    def refresh(self):
        if not self.isVisible():
            return
        cpu, memory, disk, net = self._system_metrics()
        self.cpu_label.setText(f"CPU {cpu:.1f}%")
        self.cpu_bar.setValue(int(cpu))
        self.mem_label.setText(f"Memory {memory:.1f}%")
        self.mem_bar.setValue(int(memory))
        self.disk_label.setText(f"Disk {disk}")
        if net is not None:
            if self._last_net is None:
                self.net_label.setText("Net —")
            else:
                sent = (net.bytes_sent - self._last_net.bytes_sent) / 1024
                recv = (net.bytes_recv - self._last_net.bytes_recv) / 1024
                self.net_label.setText(f"Net ↓{recv:.0f} KB/s ↑{sent:.0f} KB/s")
            self._last_net = net
        rows, qah_tree = self._process_rows()
        self.table.setRowCount(0)
        for row in rows:
            index = self.table.rowCount()
            self.table.insertRow(index)
            values = [str(row[0]), row[1], f"{row[2]:.1f}", f"{row[3]:.1f}", str(row[4]), row[5], row[6]]
            for col, value in enumerate(values):
                item = QTableWidgetItem(value)
                if row[0] == os.getpid():
                    item.setBackground(QColor("#dbeafe"))
                    item.setToolTip("Plugin Sentinel / QAH process")
                self.table.setItem(index, col, item)
        self._update_status(len(rows))
        if self.view_tabs.currentWidget() is self.execution_view:
            self._refresh_executions()

    def showEvent(self, event):
        super().showEvent(event)
        self._update_source_label()
        if self.pause_check.isChecked():
            self._update_status()
            return
        self._timer.start()
        self.refresh()

    def hideEvent(self, event):
        self._timer.stop()
        super().hideEvent(event)

    def cleanup(self):
        self._save_settings()
        self._timer.stop()
