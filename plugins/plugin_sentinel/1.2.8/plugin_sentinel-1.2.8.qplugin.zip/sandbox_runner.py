"""Process sandbox for Plugin Sentinel.

This is a containment harness, not a hypervisor. It runs plugin code in a
separate Python process with:

* a fresh temporary working directory and scrubbed environment,
* Python audit hooks that block network, subprocess, ctypes and writes outside
  the sandbox,
* POSIX rlimits or a Windows Job Object for memory/CPU containment,
* a hard timeout and process-tree kill.

It is designed to catch accidental or unsophisticated malicious behaviour in
Python code. Native code is blocked by the audit hook, but no in-process
sandbox can be a guarantee against every kernel-level escape.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path
from typing import Any, Dict, Optional

from .sentinel_python import find_python

RESULT_MARKER = "__SENTINEL_SANDBOX_RESULT__"


_HARNESS = r'''# Plugin Sentinel sandbox harness
import argparse
import importlib
import importlib.machinery
import json
import os
import sys
import time
import traceback

RESULT_MARKER = "__SENTINEL_SANDBOX_RESULT__"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--package", required=True)
    parser.add_argument("--workdir", required=True)
    parser.add_argument("--allow-network", default="0")
    parser.add_argument("--memory-mb", type=int, default=512)
    parser.add_argument("--deny-read", action="append", default=[])
    parser.add_argument("--qah-app", default="")
    args = parser.parse_args()
    allow_network = args.allow_network == "1"
    workdir = os.path.realpath(args.workdir)
    package = os.path.realpath(args.package)
    deny_read = [os.path.realpath(path) for path in args.deny_read if path]
    violations = []
    started = time.time()

    def under_workdir(path):
        try:
            real = os.path.realpath(path)
            return real == workdir or real.startswith(workdir + os.sep)
        except Exception:
            return False

    def hook(event, values):
        if event.startswith("socket.") and not allow_network:
            violations.append({"event": event, "detail": "network blocked"})
            raise PermissionError("sandbox: network is blocked")
        if event in ("subprocess.Popen", "os.system", "os.exec", "os.spawn",
                     "os.posix_spawn", "os.posix_spawnp", "os.fork", "os.forkpty"):
            violations.append({"event": event, "detail": "process creation blocked"})
            raise PermissionError("sandbox: process creation is blocked")
        if event in ("ctypes.dlopen", "ctypes.dlsym"):
            violations.append({"event": event, "detail": "native loading blocked"})
            raise PermissionError("sandbox: native library loading is blocked")
        if event.startswith("winreg."):
            violations.append({"event": event, "detail": "registry access blocked"})
            raise PermissionError("sandbox: registry access is blocked")
        if event == "open":
            path = values[0] if values else None
            mode = values[1] if len(values) > 1 else None
            if isinstance(path, (str, bytes, os.PathLike)) and isinstance(mode, str):
                real = os.path.realpath(os.fspath(path))
                writing = any(ch in mode for ch in "wax+")
                if writing and not under_workdir(real):
                    violations.append({"event": event, "detail": "write outside sandbox: " + real})
                    raise PermissionError("sandbox: writes outside the work directory are blocked")
                if not writing and deny_read and any(
                    real == root or real.startswith(root + os.sep) for root in deny_read
                ):
                    violations.append({"event": event, "detail": "sensitive read blocked: " + real})
                    raise PermissionError("sandbox: sensitive credential paths are read-protected")
        if event in ("os.remove", "os.rename", "os.rmdir", "shutil.rmtree", "os.unlink"):
            for value in values:
                if isinstance(value, (str, bytes, os.PathLike)) and not under_workdir(os.fspath(value)):
                    violations.append({"event": event, "detail": "filesystem mutation outside sandbox: " + os.fspath(value)})
                    raise PermissionError("sandbox: filesystem mutation outside the work directory is blocked")

    sys.addaudithook(hook)
    if os.name != "nt":
        try:
            import resource
            memory = max(32, args.memory_mb) * 1024 * 1024
            resource.setrlimit(resource.RLIMIT_AS, (memory, memory))
            resource.setrlimit(resource.RLIMIT_CPU, (25, 25))
            resource.setrlimit(resource.RLIMIT_FSIZE, (64 * 1024 * 1024, 64 * 1024 * 1024))
            resource.setrlimit(resource.RLIMIT_NOFILE, (256, 256))
            try:
                resource.setrlimit(resource.RLIMIT_NPROC, (32, 32))
            except Exception:
                pass
        except Exception:
            pass

    os.chdir(workdir)
    if args.qah_app:
        sys.path.insert(0, args.qah_app)
    parent = os.path.dirname(package)
    name = os.path.basename(package)
    sys.path.insert(0, parent)
    status = "ok"
    detail = ""
    try:
        if os.path.isdir(package) and os.path.isfile(os.path.join(package, "__init__.py")):
            importlib.import_module(name)
        else:
            main_file = os.path.join(package, "plugin.py")
            if not os.path.isfile(main_file):
                raise RuntimeError("No package __init__.py or plugin.py found")
            importlib.machinery.SourceFileLoader("__sandbox_plugin__", main_file).load_module()
    except BaseException as exc:
        if violations:
            status = "blocked"
        else:
            status = "error"
        detail = f"{type(exc).__name__}: {exc}"
    if violations and status == "ok":
        status = "blocked"
    duration = round(time.time() - started, 3)
    print(RESULT_MARKER + json.dumps({
        "status": status,
        "detail": detail,
        "violations": violations[:100],
        "duration": duration,
        "package": package,
        "allow_network": allow_network,
    }), flush=True)


if __name__ == "__main__":
    main()
'''


def _extract_archive(path: Path, destination: Path) -> Path:
    with zipfile.ZipFile(path) as archive:
        for info in archive.infolist():
            name = info.filename.replace("\\", "/")
            parts = Path(name).parts
            if name.startswith("/") or ".." in parts:
                raise RuntimeError(f"Unsafe path in archive: {name}")
            target = destination.joinpath(*parts)
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info) as source, open(target, "wb") as output:
                shutil.copyfileobj(source, output)
    for candidate in sorted(destination.rglob("manifest.json")):
        return candidate.parent
    for candidate in sorted(destination.rglob("__init__.py")):
        return candidate.parent
    return destination


def _resolve_package(target: Path, workspace: Path) -> Path:
    if target.is_dir():
        if (target / "manifest.json").is_file() or (target / "__init__.py").is_file():
            return target
        for candidate in sorted(target.rglob("manifest.json")):
            return candidate.parent
        return target
    return _extract_archive(target, workspace / "extracted")


def _assign_windows_job(proc: subprocess.Popen, memory_mb: int, timeout: int):
    if os.name != "nt":
        return None
    try:
        import ctypes
        from ctypes import wintypes

        class IO_COUNTERS(ctypes.Structure):
            _fields_ = [
                ("ReadOperationCount", ctypes.c_ulonglong),
                ("WriteOperationCount", ctypes.c_ulonglong),
                ("OtherOperationCount", ctypes.c_ulonglong),
                ("ReadTransferCount", ctypes.c_ulonglong),
                ("WriteTransferCount", ctypes.c_ulonglong),
                ("OtherTransferCount", ctypes.c_ulonglong),
            ]

        class JOBOBJECT_BASIC_LIMIT_INFORMATION(ctypes.Structure):
            _fields_ = [
                ("PerProcessUserTimeLimit", ctypes.c_longlong),
                ("PerJobUserTimeLimit", ctypes.c_longlong),
                ("LimitFlags", wintypes.DWORD),
                ("MinimumWorkingSetSize", ctypes.c_size_t),
                ("MaximumWorkingSetSize", ctypes.c_size_t),
                ("ActiveProcessLimit", wintypes.DWORD),
                ("Affinity", ctypes.c_size_t),
                ("PriorityClass", wintypes.DWORD),
                ("SchedulingClass", wintypes.DWORD),
            ]

        class JOBOBJECT_EXTENDED_LIMIT_INFORMATION(ctypes.Structure):
            _fields_ = [
                ("BasicLimitInformation", JOBOBJECT_BASIC_LIMIT_INFORMATION),
                ("IoInfo", IO_COUNTERS),
                ("ProcessMemoryLimit", ctypes.c_size_t),
                ("JobMemoryLimit", ctypes.c_size_t),
                ("PeakProcessMemoryUsed", ctypes.c_size_t),
                ("PeakJobMemoryUsed", ctypes.c_size_t),
            ]

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.CreateJobObjectW.restype = wintypes.HANDLE
        job = kernel32.CreateJobObjectW(None, None)
        if not job:
            return None
        info = JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
        # KILL_ON_JOB_CLOSE | PROCESS_MEMORY | PROCESS_TIME
        info.BasicLimitInformation.LimitFlags = 0x2000 | 0x100 | 0x2
        info.BasicLimitInformation.PerProcessUserTimeLimit = max(1, int(timeout)) * 10_000_000
        info.ProcessMemoryLimit = int(memory_mb) * 1024 * 1024
        if not kernel32.SetInformationJobObject(
            job, 9, ctypes.byref(info), ctypes.sizeof(info)
        ):
            kernel32.CloseHandle(job)
            return None
        if not kernel32.AssignProcessToJobObject(job, int(proc._handle)):
            kernel32.CloseHandle(job)
            return None
        return job
    except Exception:
        return None


def _kill_tree(proc: subprocess.Popen) -> None:
    try:
        if os.name == "nt":
            subprocess.run(
                ["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                capture_output=True,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        else:
            import signal
            os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def run_sandbox(
    target: Path,
    *,
    timeout: int = 20,
    memory_mb: int = 512,
    allow_network: bool = False,
    qah_app: Optional[Path] = None,
) -> Dict[str, Any]:
    target = Path(target)
    workspace = Path(tempfile.mkdtemp(prefix="sentinel-sandbox-"))
    try:
        package = _resolve_package(target, workspace)
        workdir = workspace / "work"
        workdir.mkdir(parents=True, exist_ok=True)
        harness = workspace / "sentinel_sandbox_harness.py"
        harness.write_text(_HARNESS, encoding="utf-8")
        home = Path.home()
        deny_read = [
            home / ".ssh",
            home / ".aws",
            home / ".gnupg",
            home / ".kube",
            home / ".docker",
            home / ".config" / "gcloud",
            home / "QAH" / "plugin_files" / "QAH_SSH" / "credentials",
            home / "QAH" / "qah_ws_server" / "clients.json",
            home / "QAH" / "qah_ws_client" / "client.json",
        ]
        env = os.environ.copy()
        for key in list(env):
            if key.upper().startswith(("QAH_", "GITHUB_", "GH_", "AWS_", "AZURE_", "OPENAI_", "ANTHROPIC_")):
                env.pop(key, None)
        env.update({
            "HOME": str(workdir),
            "USERPROFILE": str(workdir),
            "TEMP": str(workdir),
            "TMP": str(workdir),
            "PYTHONNOUSERSITE": "1",
            "PYTHONDONTWRITEBYTECODE": "1",
            "QT_QPA_PLATFORM": "offscreen",
        })
        interpreter = find_python()
        if interpreter is None:
            return {
                "status": "error",
                "target": str(target),
                "package": str(package),
                "duration": 0.0,
                "returncode": None,
                "timed_out": False,
                "timeout": timeout,
                "memory_limit_mb": memory_mb,
                "network_allowed": allow_network,
                "violations": [],
                "detail": (
                    "No Python interpreter found. Sentinel sandbox runs in a real "
                    "Python process; QAH's frozen launcher cannot execute the "
                    "sandbox harness. Install Python 3.8+ or set "
                    "QAH_SENTINEL_PYTHON to an interpreter path."
                ),
                "stdout": "",
                "stderr": "",
                "memory_limit_enforced": False,
            }
        command = [
            *interpreter["command"],
            "-I",
            "-B",
            "-u",
            str(harness),
            "--package",
            str(package),
            "--workdir",
            str(workdir),
            "--allow-network",
            "1" if allow_network else "0",
            "--memory-mb",
            str(max(32, int(memory_mb))),
        ]
        for path in deny_read:
            command += ["--deny-read", str(path)]
        if qah_app:
            command += ["--qah-app", str(qah_app)]
        kwargs = {}
        if os.name == "nt":
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        else:
            kwargs["start_new_session"] = True
        started = time.time()
        proc = subprocess.Popen(
            command,
            cwd=str(workdir),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            **kwargs,
        )
        job = _assign_windows_job(proc, memory_mb, timeout)
        timed_out = False
        try:
            stdout, stderr = proc.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            _kill_tree(proc)
            try:
                stdout, stderr = proc.communicate(timeout=5)
            except Exception:
                stdout, stderr = "", ""
        finally:
            if job is not None:
                try:
                    import ctypes
                    ctypes.WinDLL("kernel32").CloseHandle(job)
                except Exception:
                    pass
        duration = round(time.time() - started, 3)
        result = None
        for line in stdout.splitlines():
            if line.startswith(RESULT_MARKER):
                try:
                    result = json.loads(line[len(RESULT_MARKER):])
                except Exception:
                    result = None
        if timed_out:
            status = "timeout"
        elif result:
            status = result.get("status", "error")
        else:
            status = "error"
        return {
            "status": status,
            "target": str(target),
            "package": str(package),
            "duration": duration,
            "returncode": proc.returncode,
            "timed_out": timed_out,
            "timeout": timeout,
            "memory_limit_mb": memory_mb,
            "network_allowed": allow_network,
            "violations": (result or {}).get("violations", []),
            "detail": (result or {}).get("detail", ""),
            "stdout": stdout[-20000:],
            "stderr": stderr[-20000:],
            "memory_limit_enforced": job is not None or os.name != "nt",
        }
    finally:
        shutil.rmtree(workspace, ignore_errors=True)
