"""Locate a real Python interpreter for isolated Sentinel child processes.

QAH ships as a frozen launcher. Inside QAH, ``sys.executable`` points at the
QAH executable, so launching ``sys.executable addon_host.py`` starts another
QAH instance instead of a Python script. This module probes real interpreters
and returns one that can execute Sentinel's standalone child harnesses.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

_PROBE = (
    "import json,sys;"
    "print(json.dumps({'version':sys.version.split()[0],"
    "'executable':sys.executable,'prefix':sys.prefix,"
    "'base_prefix':sys.base_prefix,"
    "'path':[p for p in sys.path if p]}))"
)

_CACHE: Optional[Dict[str, Any]] = None
_CACHE_AT = 0.0
_CACHE_TTL = 60.0


def _creationflags() -> int:
    if os.name == "nt":
        return int(getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return 0


def _probe(command: List[str]) -> Optional[Dict[str, Any]]:
    try:
        completed = subprocess.run(
            command + ["-I", "-c", _PROBE],
            capture_output=True,
            text=True,
            timeout=8,
            creationflags=_creationflags(),
        )
    except Exception:
        return None
    if completed.returncode != 0:
        return None
    lines = [line.strip() for line in completed.stdout.splitlines() if line.strip()]
    if not lines:
        return None
    try:
        info = json.loads(lines[-1])
    except Exception:
        return None
    version = str(info.get("version") or "")
    if not re.match(r"^\d+\.\d+", version):
        return None
    try:
        major, minor = (int(part) for part in version.split(".")[:2])
    except Exception:
        return None
    if (major, minor) < (3, 7):
        return None
    paths = [str(item) for item in (info.get("path") or []) if str(item)]
    executable = str(info.get("executable") or "")
    if not executable:
        return None
    return {
        "command": list(command),
        "version": version,
        "executable": executable,
        "prefix": str(info.get("prefix") or ""),
        "base_prefix": str(info.get("base_prefix") or ""),
        "paths": paths,
    }


def _looks_like_python(path: Path) -> bool:
    name = path.name.lower()
    return name.startswith("python") or name in ("py.exe", "py")


def _candidates() -> List[List[str]]:
    candidates: List[List[str]] = []
    override = (
        os.environ.get("QAH_SENTINEL_PYTHON")
        or os.environ.get("QAH_PYTHON")
        or ""
    ).strip()
    if override:
        candidates.append([override])
    for name in ("python3", "python"):
        found = shutil.which(name)
        if found:
            candidates.append([found])
    if os.name == "nt":
        py = shutil.which("py")
        if py:
            candidates.append([py, "-3"])
    if sys.executable and Path(sys.executable).exists():
        # In a frozen QAH this is the QAH launcher, not Python. Never probe it.
        if not getattr(sys, "frozen", False) and _looks_like_python(Path(sys.executable)):
            candidates.append([sys.executable])
    return candidates


def find_python(refresh: bool = False) -> Optional[Dict[str, Any]]:
    """Return a usable Python interpreter, or ``None``.

    The result is cached briefly so repeated addon or sandbox runs do not probe
    the system every time. Set ``refresh=True`` to force a new search.
    """
    global _CACHE, _CACHE_AT
    now = time.monotonic()
    if not refresh and _CACHE_AT and now - _CACHE_AT < _CACHE_TTL:
        return _CACHE
    _CACHE_AT = now
    _CACHE = None
    seen = set()
    for command in _candidates():
        key = tuple(command)
        if key in seen:
            continue
        seen.add(key)
        probe = _probe(command)
        if probe:
            _CACHE = probe
            return probe
    return None


def interpreter_summary(info: Optional[Dict[str, Any]] = None) -> str:
    info = info if info is not None else find_python()
    if not info:
        return "no Python interpreter found"
    return f"Python {info['version']} ({info['executable']})"
