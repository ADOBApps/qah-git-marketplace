"""Plugin Sentinel core engine.

Qt-free audit engine used by both the Sentinel UI and its CLI. It builds on
QAH's bundled ``plugins.libs.plugin_audit`` checks and adds:

* risk scoring and letter grades,
* capability mapping from Python AST and text,
* manifest/archive hardening and secret detection,
* duplicate-id detection,
* trusted-hash baselines and drift detection,
* policy evaluation, and
* JSON/Markdown/HTML/CSV reports.

This file is part of QAH. GPLv3 or later.
"""

from __future__ import annotations

import ast
import csv
import hashlib
import html
import io
import json
import os
import re
import stat
import sys
import time
import zipfile
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

try:
    from . import native_scan
except Exception:
    import native_scan  # type: ignore

# ---------------------------------------------------------------------------
# QAH audit library loader
# ---------------------------------------------------------------------------

BASE_ALL_CHECKS: Tuple[str, ...] = ("manifest", "archive", "static", "deps", "sandbox")
BASE_DEFAULT_CHECKS: Tuple[str, ...] = ("manifest", "archive", "static", "deps")


def _load_audit_library():
    try:
        from plugins.libs import plugin_paths  # type: ignore
        from plugins.libs.plugin_audit import (  # type: ignore
            ALL_CHECKS,
            DEFAULT_CHECKS,
            audit,
            describe,
            resolve_package,
        )

        return {
            "audit": audit,
            "describe": describe,
            "resolve_package": resolve_package,
            "plugin_paths": plugin_paths,
            "all_checks": tuple(ALL_CHECKS),
            "default_checks": tuple(DEFAULT_CHECKS),
        }
    except Exception:
        pass

    candidates = []
    env_app = os.environ.get("QAH_APP_DIR")
    if env_app:
        candidates.append(Path(env_app).expanduser())
    local = os.environ.get("LOCALAPPDATA")
    if local:
        candidates.append(
            Path(local)
            / "Programs"
            / "Acxel David Orozco Baldomero"
            / "Quantum Analysis Helper"
            / "app"
        )
    # Linux/macOS locations used by Briefcase-style installs.
    candidates.extend([
        Path.home() / ".local" / "share" / "Quantum Analysis Helper" / "app",
        Path.home() / "Applications" / "Quantum Analysis Helper.app" / "Contents" / "Resources" / "app",
        Path("/opt/QuantumAnalysisHelper/app"),
    ])
    candidates.append(Path(__file__).resolve().parents[2])
    for app in candidates:
        if not (app / "plugins" / "libs" / "plugin_audit").is_dir():
            continue
        sys.path.insert(0, str(app))
        try:
            from plugins.libs import plugin_paths  # type: ignore
            from plugins.libs.plugin_audit import (  # type: ignore
                ALL_CHECKS,
                DEFAULT_CHECKS,
                audit,
                describe,
                resolve_package,
            )

            return {
                "audit": audit,
                "describe": describe,
                "resolve_package": resolve_package,
                "plugin_paths": plugin_paths,
                "all_checks": tuple(ALL_CHECKS),
                "default_checks": tuple(DEFAULT_CHECKS),
            }
        except Exception:
            continue
    return None


AUDIT_LIB = _load_audit_library()

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

SEVERITIES = ("critical", "high", "medium", "low", "info")
_RANK = {name: index for index, name in enumerate(SEVERITIES)}
WEIGHTS = {"critical": 40, "high": 20, "medium": 4, "low": 1, "info": 0}
SKIP_DIRS = {"__pycache__", ".git", ".venv", "venv", "build", "dist", "target", "node_modules"}

CAPABILITIES: Tuple[Tuple[str, str], ...] = (
    ("network", "Network"),
    ("subprocess", "Subprocess"),
    ("filesystem", "Filesystem"),
    ("native", "Native code"),
    ("credentials", "Credentials"),
    ("persistence", "Persistence"),
    ("dynamic", "Dynamic code"),
    ("gui", "GUI"),
    ("database", "Database"),
)

CAPABILITY_NAMES = dict(CAPABILITIES)

_MODULE_CAPABILITIES = {
    "socket": "network",
    "ssl": "network",
    "http": "network",
    "urllib": "network",
    "requests": "network",
    "httpx": "network",
    "aiohttp": "network",
    "websockets": "network",
    "ftplib": "network",
    "smtplib": "network",
    "telnetlib": "network",
    "subprocess": "subprocess",
    "pty": "subprocess",
    "paramiko": "credentials",
    "cryptography": "credentials",
    "keyring": "credentials",
    "getpass": "credentials",
    "netrc": "credentials",
    "ctypes": "native",
    "cffi": "native",
    "win32api": "native",
    "win32con": "native",
    "win32process": "native",
    "winreg": "persistence",
    "atexit": "persistence",
    "sqlite3": "database",
    "psycopg2": "database",
    "pymysql": "database",
    "PySide6": "gui",
    "PyQt5": "gui",
    "PyQt6": "gui",
    "tkinter": "gui",
    "importlib": "dynamic",
    "marshal": "dynamic",
    "pickle": "dynamic",
}

_CALL_CAPABILITIES = {
    "eval": "dynamic",
    "exec": "dynamic",
    "compile": "dynamic",
    "__import__": "dynamic",
    "open": "filesystem",
    "os.system": "subprocess",
    "os.popen": "subprocess",
    "os.spawnl": "subprocess",
    "os.spawnv": "subprocess",
    "subprocess.run": "subprocess",
    "subprocess.call": "subprocess",
    "subprocess.Popen": "subprocess",
    "subprocess.check_output": "subprocess",
    "socket.socket": "network",
    "requests.get": "network",
    "requests.post": "network",
    "urllib.request.urlopen": "network",
    "ctypes.CDLL": "native",
    "ctypes.WinDLL": "native",
    "winreg.OpenKey": "persistence",
    "atexit.register": "persistence",
}

_SECRET_PATTERNS = (
    ("secret.private_key", "critical", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----")),
    ("secret.aws_key", "high", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("secret.github_token", "high", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{30,}\b")),
    ("secret.generic", "high", re.compile(r"(?i)\b(?:api[_-]?key|secret|token|password)\b\s*[:=]\s*['\"]([A-Za-z0-9_./+=:@-]{8,})['\"]")),
)

_VERSION_RE = re.compile(r"^\d+\.\d+(?:\.\d+)?(?:[-+][0-9A-Za-z.-]+)?$")
_ID_RE = re.compile(r"^[a-z][a-z0-9_]{2,63}$")


# ---------------------------------------------------------------------------
# State paths and serialisation
# ---------------------------------------------------------------------------

def state_dir() -> Path:
    override = os.environ.get("QAH_PLUGIN_SENTINEL_HOME")
    root = Path(override).expanduser() if override else Path.home() / "QAH" / "plugin_sentinel"
    root.mkdir(parents=True, exist_ok=True)
    return root


def baseline_path() -> Path:
    return state_dir() / "baseline.json"


def policy_path() -> Path:
    return state_dir() / "policy.json"


def load_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2), encoding="utf-8")


def default_policy() -> Dict[str, Any]:
    return {
        "fail_on": "high",
        "max_risk": 70,
        "require_trusted": False,
        "allowed_capabilities": [name for name, _label in CAPABILITIES],
    }


def load_policy(path: Optional[Path] = None) -> Dict[str, Any]:
    value = load_json(path or policy_path(), {})
    policy = default_policy()
    if isinstance(value, dict):
        policy.update(value)
    return policy


def save_policy(policy: Dict[str, Any], path: Optional[Path] = None) -> None:
    save_json(path or policy_path(), policy)


def load_baseline(path: Optional[Path] = None) -> Dict[str, Any]:
    value = load_json(path or baseline_path(), {})
    if not isinstance(value, dict):
        value = {}
    value.setdefault("format", "qah-plugin-sentinel-baseline")
    value.setdefault("version", 1)
    value.setdefault("plugins", {})
    return value


def save_baseline(baseline: Dict[str, Any], path: Optional[Path] = None) -> None:
    baseline["updated"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    save_json(path or baseline_path(), baseline)


# ---------------------------------------------------------------------------
# Target model
# ---------------------------------------------------------------------------

@dataclass
class Target:
    path: Path
    source: str
    label: str
    plugin_id: str = ""
    name: str = ""
    version: str = ""
    manifest: Dict[str, Any] = field(default_factory=dict)
    digest: str = ""
    size_bytes: int = 0
    kind: str = "directory"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "path": str(self.path),
            "source": self.source,
            "label": self.label,
            "id": self.plugin_id,
            "name": self.name or self.label,
            "version": self.version,
            "digest": self.digest,
            "size_bytes": self.size_bytes,
            "kind": self.kind,
        }


def _system_plugins_dir() -> Path:
    lib = AUDIT_LIB
    if lib and lib.get("plugin_paths") is not None:
        try:
            from plugins.libs import plugin_manager  # type: ignore

            return Path(plugin_manager.__file__).resolve().parents[1] / "python_plugins"
        except Exception:
            pass
    return Path(__file__).resolve().parents[1]


def _plugin_dirs() -> Tuple[Path, Path, Path]:
    lib = AUDIT_LIB
    if lib and lib.get("plugin_paths") is not None:
        paths = lib["plugin_paths"]
        try:
            return (
                Path(paths.classic_plugins_dir()),
                _system_plugins_dir(),
                Path(paths.wheels_dir()),
            )
        except Exception:
            pass
    root = Path.home() / "QAH" / "plugins"
    return root / "python_plugins", _system_plugins_dir(), root / "wheels"


def _tree_digest(root: Path) -> str:
    hasher = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root)
        if SKIP_DIRS.intersection(rel.parts):
            continue
        hasher.update(str(rel).encode("utf-8"))
        try:
            hasher.update(path.read_bytes())
        except OSError:
            continue
    return hasher.hexdigest()


def _file_digest(path: Path) -> str:
    hasher = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def digest_path(path: Path) -> str:
    """SHA256 for a file or deterministic tree digest for a plugin directory."""
    path = Path(path)
    if path.is_dir():
        return _tree_digest(path)
    return _file_digest(path)


def _zip_manifest(path: Path) -> Dict[str, Any]:
    try:
        with zipfile.ZipFile(path) as archive:
            names = [name for name in archive.namelist() if name.endswith("manifest.json")]
            if not names:
                return {}
            names.sort(key=lambda name: (name.count("/"), len(name)))
            return json.loads(archive.read(names[0]).decode("utf-8"))
    except Exception:
        return {}


def read_manifest(path: Path) -> Dict[str, Any]:
    path = Path(path)
    if path.is_dir():
        direct = path / "manifest.json"
        if direct.is_file():
            try:
                return json.loads(direct.read_text(encoding="utf-8"))
            except Exception:
                return {}
        for candidate in sorted(path.rglob("manifest.json")):
            if SKIP_DIRS.intersection(candidate.relative_to(path).parts):
                continue
            try:
                return json.loads(candidate.read_text(encoding="utf-8"))
            except Exception:
                continue
        return {}
    if path.suffix.lower() in (".zip", ".whl", ".qplugin"):
        return _zip_manifest(path)
    return {}


def make_target(path: Path, source: str = "file") -> Target:
    path = Path(path)
    manifest = read_manifest(path)
    if path.is_dir():
        digest = _tree_digest(path)
        size = sum(
            entry.stat().st_size
            for entry in path.rglob("*")
            if entry.is_file() and not SKIP_DIRS.intersection(entry.relative_to(path).parts)
        )
        kind = "directory"
    else:
        try:
            digest = _file_digest(path)
            size = path.stat().st_size
        except OSError:
            digest, size = "", 0
        kind = "wheel" if path.suffix.lower() == ".whl" else "archive"
    return Target(
        path=path,
        source=source,
        label=path.name,
        plugin_id=str(manifest.get("id") or ""),
        name=str(manifest.get("name") or path.name),
        version=str(manifest.get("version") or ""),
        manifest=manifest,
        digest=digest,
        size_bytes=size,
        kind=kind,
    )


def _iter_plugin_dirs(root: Path, max_depth: int = 8) -> Iterable[Path]:
    """Find plugin roots, including nested categories under the user root.

    A directory with manifest.json is a plugin root and its subtree is pruned,
    so internal packages are never reported as separate plugins. Top-level
    legacy folders with __init__.py but no manifest are kept when they do not
    contain a discovered plugin.
    """
    root = Path(root)
    if not root.is_dir():
        return
    found: List[Path] = []
    try:
        for current_root, dirs, files in os.walk(root):
            current = Path(current_root)
            try:
                relative = current.relative_to(root)
            except ValueError:
                continue
            depth = len(relative.parts)
            if depth > max_depth:
                dirs[:] = []
                continue
            dirs[:] = [
                name for name in dirs
                if not name.startswith((".", "_"))
                and name not in SKIP_DIRS
            ]
            if current != root and "manifest.json" in files:
                found.append(current)
                dirs[:] = []
    except OSError:
        return
    seen = {str(path.resolve()) for path in found}
    for path in found:
        yield path
    # Preserve the old behavior for top-level legacy plugins without a manifest.
    try:
        children = sorted(root.iterdir())
    except OSError:
        return
    for child in children:
        if not child.is_dir() or child.name.startswith((".", "_")) or child.name == "__pycache__":
            continue
        try:
            resolved = str(child.resolve())
        except OSError:
            continue
        if resolved in seen:
            continue
        if not (child / "__init__.py").is_file():
            continue
        if any(str(path.resolve()).startswith(resolved + os.sep) for path in found):
            continue
        yield child


def find_targets(
    user_dir: Optional[Path] = None,
    system_dir: Optional[Path] = None,
    wheels_dir: Optional[Path] = None,
) -> List[Target]:
    default_user, default_system, default_wheels = _plugin_dirs()
    targets: List[Target] = []
    seen = set()

    def add(path: Path, source: str):
        try:
            key = str(path.resolve())
        except OSError:
            key = str(path)
        if key in seen:
            return
        seen.add(key)
        targets.append(make_target(path, source))

    for directory, source in (
        (user_dir or default_user, "user"),
        (system_dir or default_system, "system"),
    ):
        for plugin_dir in _iter_plugin_dirs(Path(directory)):
            add(plugin_dir, source)

    wheel_root = Path(wheels_dir or default_wheels)
    try:
        wheel_children = sorted(wheel_root.iterdir())
    except OSError:
        wheel_children = []
    for child in wheel_children:
        if child.is_dir() and not child.name.startswith(("_", ".")):
            add(child, "wheel")
        elif child.suffix.lower() == ".whl":
            add(child, "wheel")
    return targets


def duplicate_ids(targets: Sequence[Target]) -> Dict[str, List[Target]]:
    groups: Dict[str, List[Target]] = {}
    for target in targets:
        if target.plugin_id:
            groups.setdefault(target.plugin_id, []).append(target)
    return {key: value for key, value in groups.items() if len(value) > 1}


def baseline_key(target: Target) -> str:
    return f"{target.source}:{target.plugin_id or target.label}"


def baseline_status(target: Target, baseline: Dict[str, Any]) -> str:
    entry = (baseline.get("plugins") or {}).get(baseline_key(target))
    if not entry:
        return "new"
    if entry.get("digest") != target.digest:
        return "changed"
    return "trusted"


def trust_target(target: Target, baseline: Dict[str, Any]) -> None:
    baseline.setdefault("plugins", {})[baseline_key(target)] = {
        "id": target.plugin_id,
        "name": target.name,
        "version": target.version,
        "digest": target.digest,
        "path": str(target.path),
        "trusted_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }


def forget_target(target: Target, baseline: Dict[str, Any]) -> None:
    (baseline.get("plugins") or {}).pop(baseline_key(target), None)


# ---------------------------------------------------------------------------
# Capability and secret analysis
# ---------------------------------------------------------------------------

def _iter_python_files(target: Target) -> Iterable[Tuple[str, str]]:
    path = Path(target.path)
    if path.is_dir():
        for file in sorted(path.rglob("*.py")):
            rel = file.relative_to(path)
            if SKIP_DIRS.intersection(rel.parts):
                continue
            try:
                if file.stat().st_size > 2 * 1024 * 1024:
                    continue
                yield str(rel), file.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
        return
    if path.suffix.lower() not in (".zip", ".whl", ".qplugin"):
        return
    try:
        with zipfile.ZipFile(path) as archive:
            for name in archive.namelist():
                if not name.endswith(".py"):
                    continue
                info = archive.getinfo(name)
                if info.file_size > 2 * 1024 * 1024:
                    continue
                try:
                    yield name, archive.read(name).decode("utf-8", errors="replace")
                except Exception:
                    continue
    except Exception:
        return


def _iter_text_files(target: Target) -> Iterable[Tuple[str, str]]:
    path = Path(target.path)
    suffixes = {".py", ".json", ".txt", ".md", ".cfg", ".ini", ".yaml", ".yml", ".env", ".sh", ".bat", ".ps1"}
    if path.is_dir():
        for file in sorted(path.rglob("*")):
            if not file.is_file() or file.suffix.lower() not in suffixes:
                continue
            rel = file.relative_to(path)
            if SKIP_DIRS.intersection(rel.parts):
                continue
            try:
                if file.stat().st_size > 2 * 1024 * 1024:
                    continue
                yield str(rel), file.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
        return
    if path.suffix.lower() not in (".zip", ".whl", ".qplugin"):
        return
    try:
        with zipfile.ZipFile(path) as archive:
            for name in archive.namelist():
                if Path(name).suffix.lower() not in suffixes:
                    continue
                info = archive.getinfo(name)
                if info.file_size > 2 * 1024 * 1024:
                    continue
                try:
                    yield name, archive.read(name).decode("utf-8", errors="replace")
                except Exception:
                    continue
    except Exception:
        return


def _call_name(node: ast.Call) -> str:
    func = node.func
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        parts = []
        current = func
        while isinstance(current, ast.Attribute):
            parts.append(current.attr)
            current = current.value
        if isinstance(current, ast.Name):
            parts.append(current.id)
        return ".".join(reversed(parts))
    return ""


def analyze_capabilities(target: Target) -> Dict[str, Any]:
    caps = set()
    hits: List[Dict[str, Any]] = []
    dynamic_hits: List[str] = []
    obfuscation = False
    shell_true = False
    parse_errors: List[str] = []

    for filename, source in _iter_python_files(target):
        if "base64" in source and re.search(r"\b(?:exec|eval)\s*\(", source):
            obfuscation = True
        try:
            tree = ast.parse(source, filename=filename)
        except SyntaxError as exc:
            parse_errors.append(f"{filename}:{exc.lineno}: {exc.msg}")
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    root = alias.name.split(".")[0]
                    cap = _MODULE_CAPABILITIES.get(root)
                    if cap:
                        caps.add(cap)
            elif isinstance(node, ast.ImportFrom) and node.module:
                root = node.module.split(".")[0]
                cap = _MODULE_CAPABILITIES.get(root)
                if cap:
                    caps.add(cap)
            elif isinstance(node, ast.Call):
                name = _call_name(node)
                cap = _CALL_CAPABILITIES.get(name)
                if cap:
                    caps.add(cap)
                if name in ("eval", "exec", "compile", "__import__"):
                    dynamic_hits.append(f"{filename}:{node.lineno}: {name}()")
                if name.startswith("subprocess.") or name in ("os.system", "os.popen"):
                    caps.add("subprocess")
                    for keyword in node.keywords:
                        if keyword.arg == "shell" and isinstance(keyword.value, ast.Constant) and keyword.value.value is True:
                            shell_true = True
                if name.startswith("winreg.") or name == "atexit.register":
                    caps.add("persistence")

    secrets: List[Dict[str, Any]] = []
    for filename, source in _iter_text_files(target):
        for code, severity, pattern in _SECRET_PATTERNS:
            for match in pattern.finditer(source):
                line = source.count("\n", 0, match.start()) + 1
                snippet = match.group(0)
                if len(snippet) > 24:
                    snippet = snippet[:12] + "…" + snippet[-6:]
                secrets.append(
                    {
                        "severity": severity,
                        "code": code,
                        "message": f"Possible secret in {filename}",
                        "path": filename,
                        "line": line,
                        "detail": f"matched: {snippet}",
                    }
                )
    return {
        "capabilities": sorted(caps),
        "dynamic_hits": dynamic_hits[:20],
        "obfuscation": obfuscation,
        "shell_true": shell_true,
        "secrets": secrets[:40],
        "parse_errors": parse_errors[:20],
    }


# ---------------------------------------------------------------------------
# Findings / risk / policy
# ---------------------------------------------------------------------------

def _finding(severity: str, code: str, message: str, **kwargs) -> Dict[str, Any]:
    value = {
        "check": "sentinel",
        "severity": severity,
        "code": code,
        "message": message,
    }
    value.update({key: val for key, val in kwargs.items() if val not in (None, "", 0)})
    return value


def manifest_findings(target: Target) -> List[Dict[str, Any]]:
    manifest = target.manifest or {}
    findings: List[Dict[str, Any]] = []
    if not manifest:
        findings.append(_finding("high", "manifest.missing", "No manifest.json was found"))
        return findings
    plugin_id = str(manifest.get("id") or "")
    name = str(manifest.get("name") or "")
    version = str(manifest.get("version") or "")
    author = str(manifest.get("author") or "")
    description = str(manifest.get("description") or "")
    main = str(manifest.get("main") or "")
    if not plugin_id or not _ID_RE.fullmatch(plugin_id):
        findings.append(_finding("medium", "manifest.id", f"Invalid or missing plugin id: {plugin_id!r}"))
    if not name:
        findings.append(_finding("low", "manifest.name", "Missing display name"))
    if not version or not _VERSION_RE.fullmatch(version):
        findings.append(_finding("low", "manifest.version", f"Version is not semver-like: {version!r}"))
    if not author:
        findings.append(_finding("low", "manifest.author", "Missing author"))
    if not description:
        findings.append(_finding("low", "manifest.description", "Missing description"))
    if not main:
        findings.append(_finding("medium", "manifest.main", "Missing main entry point"))
    elif target.path.is_dir() and not (target.path / main).is_file():
        findings.append(_finding("high", "manifest.main_missing", f"Main file declared but not found: {main}"))
    icon = str(manifest.get("icon") or "")
    if icon:
        if target.path.is_dir() and not (target.path / icon).is_file():
            findings.append(_finding("low", "manifest.icon_missing", f"Icon declared but not found: {icon}"))
    deps = manifest.get("dependencies") or []
    if isinstance(deps, list):
        for dep in deps:
            text = str(dep)
            if re.match(r"^(?:git\+|https?://|ssh://|file:|\.{0,2}/)", text):
                findings.append(_finding("high", "manifest.unsafe_dependency", f"Dependency uses a URL/VCS/local path: {text}"))
    if "license" not in manifest:
        findings.append(_finding("info", "manifest.license", "No license metadata in manifest"))
    return findings


def archive_findings(target: Target) -> List[Dict[str, Any]]:
    path = Path(target.path)
    findings: List[Dict[str, Any]] = []
    if path.is_dir():
        names = []
        for file in path.rglob("*"):
            if file.is_file():
                rel = file.relative_to(path)
                if SKIP_DIRS.intersection(rel.parts):
                    continue
                names.append(rel.as_posix())
    elif path.suffix.lower() in (".zip", ".whl", ".qplugin"):
        try:
            with zipfile.ZipFile(path) as archive:
                names = archive.namelist()
        except Exception as exc:
            return [_finding("high", "archive.unreadable", f"Archive could not be read: {exc}")]
    else:
        return []
    for name in names:
        lower = name.lower()
        if lower.endswith((".stable", ".old")):
            findings.append(_finding("medium", "archive.backup", f"Backup file shipped: {name}", path=name))
        if "__pycache__" in lower or lower.endswith((".pyc", ".pyo")):
            findings.append(_finding("info", "archive.bytecode", f"Compiled bytecode shipped: {name}", path=name))
        if lower.endswith((".env", ".pem", ".key", ".p12", ".pfx")):
            findings.append(_finding("high", "archive.secret_file", f"Sensitive file shipped: {name}", path=name))
        if lower.endswith((".exe", ".dll", ".so", ".dylib")) and "icon" not in lower:
            findings.append(_finding("medium", "archive.native", f"Native binary shipped: {name}", path=name))
    return findings


def advanced_findings(target: Target, analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
    findings: List[Dict[str, Any]] = []
    caps = set(analysis.get("capabilities") or [])
    if analysis.get("obfuscation"):
        findings.append(_finding("high", "capability.obfuscation", "Base64 plus eval/exec pattern can hide code"))
    if analysis.get("shell_true"):
        findings.append(_finding("medium", "capability.shell_true", "Subprocess call uses shell=True"))
    if "persistence" in caps:
        findings.append(_finding("high", "capability.persistence", "Plugin can create persistence or startup entries"))
    if "native" in caps:
        findings.append(_finding("medium", "capability.native", "Plugin can load native code"))
    if "network" in caps and "credentials" in caps:
        findings.append(_finding("high", "capability.exfil", "Plugin combines network access with credential APIs"))
    if "subprocess" in caps and "network" in caps:
        findings.append(_finding("medium", "capability.remote_exec", "Plugin combines subprocess execution with network access"))
    for hit in analysis.get("dynamic_hits") or []:
        findings.append(_finding("medium", "capability.dynamic", f"Dynamic execution: {hit}", path=hit))
    for secret in analysis.get("secrets") or []:
        findings.append(_finding(secret["severity"], secret["code"], secret["message"], path=secret.get("path"), line=secret.get("line"), detail=secret.get("detail")))
    for error in analysis.get("parse_errors") or []:
        findings.append(_finding("low", "static.parse_error", f"Could not parse Python file: {error}"))
    return findings


def _counts(findings: Sequence[Dict[str, Any]]) -> Dict[str, int]:
    counts = {name: 0 for name in SEVERITIES}
    for finding in findings:
        severity = finding.get("severity", "info")
        counts[severity] = counts.get(severity, 0) + 1
    return counts


def _worst(findings: Sequence[Dict[str, Any]]) -> str:
    for finding in findings:
        severity = finding.get("severity")
        if severity:
            return severity
    return "ok"


def risk_score(counts: Dict[str, int]) -> int:
    return min(100, sum(WEIGHTS.get(severity, 0) * counts.get(severity, 0) for severity in SEVERITIES))


def risk_grade(score: int) -> str:
    if score >= 85:
        return "F"
    if score >= 70:
        return "E"
    if score >= 50:
        return "D"
    if score >= 25:
        return "C"
    if score >= 10:
        return "B"
    return "A"


def evaluate_policy(report: Dict[str, Any], policy: Dict[str, Any], baseline: str) -> Dict[str, Any]:
    violations: List[str] = []
    fail_on = str(policy.get("fail_on") or "high")
    fail_rank = -1 if fail_on == "never" else _RANK.get(fail_on, _RANK["high"])
    counts = report.get("counts") or {}
    for severity in SEVERITIES:
        if counts.get(severity) and _RANK[severity] <= fail_rank:
            violations.append(f"{counts[severity]} {severity} finding(s)")
    max_risk = int(policy.get("max_risk", 100))
    if int(report.get("risk_score", 0)) > max_risk:
        violations.append(f"risk {report['risk_score']} > {max_risk}")
    if policy.get("require_trusted") and baseline != "trusted":
        violations.append(f"baseline status is {baseline}")
    allowed = set(policy.get("allowed_capabilities") or [name for name, _ in CAPABILITIES])
    caps = set((report.get("sentinel") or {}).get("capabilities") or [])
    denied = sorted(caps - allowed)
    if denied:
        violations.append("capability not allowed: " + ", ".join(denied))
    if violations:
        verdict = "BLOCK"
    elif counts.get("medium") or counts.get("low") or int(report.get("risk_score", 0)) >= 25:
        verdict = "WARN"
    else:
        verdict = "PASS"
    return {"verdict": verdict, "violations": violations}


# ---------------------------------------------------------------------------
# Audit entry point
# ---------------------------------------------------------------------------

def _fallback_report(target: Target, checks: Sequence[str]) -> Dict[str, Any]:
    findings: List[Dict[str, Any]] = []
    if "manifest" in checks:
        findings.extend(manifest_findings(target))
    if "archive" in checks:
        findings.extend(archive_findings(target))
    counts = _counts(findings)
    return {
        "format": "qah-plugin-audit",
        "version": 1,
        "target": str(target.path),
        "kind": target.kind,
        "digest": target.digest,
        "size_bytes": target.size_bytes,
        "duration": 0.0,
        "counts": counts,
        "ok": not any(f.get("severity") != "info" for f in findings),
        "metadata": {},
        "checks": {
            "sentinel": {
                "ran": True,
                "skipped_reason": "",
                "duration": 0.0,
                "worst": _worst(findings),
                "findings": findings,
            }
        },
    }


def _flatten_checks(report: Dict[str, Any]) -> List[Dict[str, Any]]:
    findings: List[Dict[str, Any]] = []
    for name, check in (report.get("checks") or {}).items():
        if not isinstance(check, dict):
            continue
        for finding in check.get("findings") or []:
            item = dict(finding)
            item.setdefault("check", name)
            findings.append(item)
    return findings


def _sort_findings(findings: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return sorted(findings, key=lambda item: (_RANK.get(item.get("severity", "info"), 99), item.get("check", ""), item.get("path", "")))


def _append_text(base_text: str, report: Dict[str, Any]) -> str:
    sentinel = report.get("sentinel") or {}
    lines = [base_text.rstrip(), "", "=" * 68, "PLUGIN SENTINEL", "=" * 68]
    lines.append(f"risk: {report.get('risk_score', 0)}/100  grade: {report.get('grade', 'A')}")
    lines.append(f"baseline: {report.get('baseline', 'new')}")
    lines.append(f"policy: {report.get('policy_verdict', 'PASS')}")
    caps = sentinel.get("capabilities") or []
    lines.append("capabilities: " + (", ".join(caps) if caps else "none detected"))
    advanced = sentinel.get("findings") or []
    if advanced:
        lines.append("")
        lines.append(f"Sentinel findings ({len(advanced)}):")
        for finding in advanced:
            where = finding.get("path") or ""
            if finding.get("line"):
                where += f":{finding['line']}"
            suffix = f"  ({where})" if where else ""
            lines.append(f"  - [{finding.get('severity')}] {finding.get('code')}: {finding.get('message')}{suffix}")
    return "\n".join(lines)


def scan_target(
    target: Target,
    checks: Sequence[str],
    policy: Dict[str, Any],
    baseline: Dict[str, Any],
) -> Dict[str, Any]:
    selected = [name for name in checks if name]
    if "sentinel" not in selected:
        selected.append("sentinel")
    base_checks = [name for name in selected if name != "sentinel"]
    if AUDIT_LIB is not None and base_checks:
        try:
            base = AUDIT_LIB["audit"](target.path, base_checks).to_dict()
        except Exception as exc:
            base = _fallback_report(target, base_checks)
            base.setdefault("metadata", {})["audit_error"] = str(exc)
    else:
        base = _fallback_report(target, base_checks)
    # Compose the text from the structured report (one audit execution only).
    base_text = _report_text_from_dict(base)

    analysis = analyze_capabilities(target)
    native_libraries = native_scan.scan_native(target)
    sentinel_findings = (
        manifest_findings(target)
        + archive_findings(target)
        + advanced_findings(target, analysis)
        + native_scan.native_findings(native_libraries)
    )
    base_checks_dict = dict(base.get("checks") or {})
    base_checks_dict["sentinel"] = {
        "ran": True,
        "skipped_reason": "",
        "duration": 0.0,
        "worst": _worst(sentinel_findings),
        "findings": sentinel_findings,
    }
    base["checks"] = base_checks_dict
    findings = _sort_findings(_flatten_checks(base))
    counts = _counts(findings)
    base["counts"] = counts
    base["ok"] = not any(item.get("severity") != "info" for item in findings)
    base["id"] = target.plugin_id
    base["name"] = target.name
    base["version"] = target.version
    base["source"] = target.source
    base["label"] = target.label
    base["path"] = str(target.path)
    base["digest"] = target.digest or base.get("digest", "")
    base["kind"] = target.kind
    base["size_bytes"] = target.size_bytes or base.get("size_bytes", 0)
    base["native"] = native_libraries
    base["sentinel"] = {
        "capabilities": analysis.get("capabilities") or [],
        "dynamic_hits": analysis.get("dynamic_hits") or [],
        "secret_hits": len(analysis.get("secrets") or []),
        "parse_errors": analysis.get("parse_errors") or [],
        "findings": sentinel_findings,
        "checks_run": list(selected),
    }
    base["risk_score"] = risk_score(counts)
    base["grade"] = risk_grade(base["risk_score"])
    base["baseline"] = baseline_status(target, baseline)
    base["duplicate"] = target.plugin_id in duplicate_ids([target])  # replaced by caller for full set
    base["policy"] = evaluate_policy(base, policy, base["baseline"])
    base["policy_verdict"] = base["policy"]["verdict"]
    base["text"] = _append_text(base_text, base)
    return base


def _report_text_from_dict(report: Dict[str, Any]) -> str:
    lines = [f"Audit: {report.get('target', '')}  ({report.get('kind', '')})"]
    if report.get("digest"):
        lines.append(f"sha256: {report['digest']}")
    lines.append("=" * 68)
    for name, check in (report.get("checks") or {}).items():
        if not isinstance(check, dict):
            continue
        findings = check.get("findings") or []
        lines.append(f"[{check.get('worst') or 'ok':<8}] {name} ({len(findings)} finding(s))")
        for finding in findings:
            where = finding.get("path") or ""
            if finding.get("line"):
                where += f":{finding['line']}"
            suffix = f"  ({where})" if where else ""
            lines.append(f"    - [{finding.get('severity')}] {finding.get('code')}: {finding.get('message')}{suffix}")
    counts = report.get("counts") or {}
    summary = ", ".join(f"{name} {counts[name]}" for name in SEVERITIES if counts.get(name))
    lines.append("=" * 68)
    lines.append(("RESULT: PASSED" if report.get("ok") else f"RESULT: ISSUES ({summary})"))
    return "\n".join(lines)


def annotate_duplicates(results: Sequence[Dict[str, Any]], policy: Optional[Dict[str, Any]] = None) -> None:
    groups: Dict[str, List[Dict[str, Any]]] = {}
    for result in results:
        plugin_id = result.get("id")
        if plugin_id:
            groups.setdefault(plugin_id, []).append(result)
    for plugin_id, group in groups.items():
        if len(group) < 2:
            continue
        sources = ", ".join(sorted({str(item.get("source")) for item in group}))
        for result in group:
            result["duplicate"] = True
            sentinel = result.setdefault("sentinel", {})
            findings = sentinel.setdefault("findings", [])
            findings.append(_finding("high", "duplicate.id", f"Plugin id {plugin_id!r} is installed more than once ({sources})"))
            result["checks"].setdefault("sentinel", {"ran": True, "findings": []})["findings"] = findings
            all_findings = _sort_findings(_flatten_checks(result))
            result["counts"] = _counts(all_findings)
            result["ok"] = not any(item.get("severity") != "info" for item in all_findings)
            result["risk_score"] = risk_score(result["counts"])
            result["grade"] = risk_grade(result["risk_score"])
            result["policy"] = evaluate_policy(result, policy or default_policy(), result.get("baseline", "new"))
            result["policy_verdict"] = result["policy"]["verdict"]
            text = result.get("text", "")
            if "duplicate.id" not in text:
                result["text"] = text + (
                    f"\n  - [high] duplicate.id: plugin id {plugin_id!r} "
                    f"is installed more than once ({sources})"
                )


# ---------------------------------------------------------------------------
# Reports
# ---------------------------------------------------------------------------

def flatten_findings(results: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows = []
    for result in results:
        for finding in result.get("checks", {}).get("sentinel", {}).get("findings", []):
            row = dict(finding)
            row["plugin"] = result.get("label") or result.get("id")
            row["plugin_id"] = result.get("id")
            row["source"] = result.get("source")
            rows.append(row)
        for name, check in (result.get("checks") or {}).items():
            if name == "sentinel" or not isinstance(check, dict):
                continue
            for finding in check.get("findings") or []:
                row = dict(finding)
                row["check"] = name
                row["plugin"] = result.get("label") or result.get("id")
                row["plugin_id"] = result.get("id")
                row["source"] = result.get("source")
                rows.append(row)
    return _sort_findings(rows)


def report_to_json(results: Sequence[Dict[str, Any]], policy: Dict[str, Any], baseline: Dict[str, Any]) -> str:
    payload = {
        "format": "qah-plugin-sentinel-report",
        "version": 1,
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "policy": policy,
        "baseline_updated": baseline.get("updated"),
        "reports": list(results),
    }
    return json.dumps(payload, indent=2, default=str)


def report_to_markdown(results: Sequence[Dict[str, Any]]) -> str:
    lines = [
        "# Plugin Sentinel report",
        "",
        f"Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}",
        "",
        "| Plugin | Version | Source | Risk | Grade | Verdict | Critical | High | Medium | Low |",
        "|---|---|---|---:|---|---|---:|---:|---:|---:|",
    ]
    for result in sorted(results, key=lambda item: item.get("risk_score", 0), reverse=True):
        counts = result.get("counts") or {}
        lines.append(
            "| {name} | {version} | {source} | {risk} | {grade} | {verdict} | {c} | {h} | {m} | {l} |".format(
                name=str(result.get("label") or result.get("id") or "").replace("|", "\\|"),
                version=result.get("version", ""),
                source=result.get("source", ""),
                risk=result.get("risk_score", 0),
                grade=result.get("grade", "A"),
                verdict=result.get("policy_verdict", "PASS"),
                c=counts.get("critical", 0),
                h=counts.get("high", 0),
                m=counts.get("medium", 0),
                l=counts.get("low", 0),
            )
        )
    lines.append("")
    for result in results:
        lines.append(f"## {result.get('label') or result.get('id')}")
        lines.append("")
        lines.append(f"- Path: `{result.get('path')}`")
        lines.append(f"- SHA256: `{result.get('digest', '')}`")
        lines.append(f"- Risk: {result.get('risk_score', 0)}/100 (grade {result.get('grade', 'A')})")
        lines.append(f"- Policy: {result.get('policy_verdict', 'PASS')}")
        caps = (result.get("sentinel") or {}).get("capabilities") or []
        lines.append(f"- Capabilities: {', '.join(caps) if caps else 'none detected'}")
        lines.append("")
        for finding in flatten_findings([result]):
            lines.append(f"- [{finding.get('severity')}] `{finding.get('code')}` {finding.get('message')}")
        lines.append("")
    return "\n".join(lines)


def report_to_csv(results: Sequence[Dict[str, Any]]) -> str:
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(["plugin", "id", "version", "source", "risk", "grade", "verdict", "critical", "high", "medium", "low", "info", "capabilities", "digest", "path"])
    for result in results:
        counts = result.get("counts") or {}
        writer.writerow([
            result.get("label", ""),
            result.get("id", ""),
            result.get("version", ""),
            result.get("source", ""),
            result.get("risk_score", 0),
            result.get("grade", "A"),
            result.get("policy_verdict", "PASS"),
            counts.get("critical", 0),
            counts.get("high", 0),
            counts.get("medium", 0),
            counts.get("low", 0),
            counts.get("info", 0),
            ";".join((result.get("sentinel") or {}).get("capabilities") or []),
            result.get("digest", ""),
            result.get("path", ""),
        ])
    return buffer.getvalue()


def report_to_html(results: Sequence[Dict[str, Any]], policy: Optional[Dict[str, Any]] = None) -> str:
    rows = []
    for result in sorted(results, key=lambda item: item.get("risk_score", 0), reverse=True):
        counts = result.get("counts") or {}
        verdict = result.get("policy_verdict", "PASS")
        color = {"BLOCK": "#b91c1c", "WARN": "#b45309", "PASS": "#15803d"}.get(verdict, "#374151")
        rows.append(
            "<tr>"
            f"<td>{html.escape(str(result.get('label') or result.get('id') or ''))}</td>"
            f"<td>{html.escape(str(result.get('version', '')))}</td>"
            f"<td>{html.escape(str(result.get('source', '')))}</td>"
            f"<td style='text-align:right'>{result.get('risk_score', 0)}</td>"
            f"<td>{result.get('grade', 'A')}</td>"
            f"<td style='color:{color};font-weight:bold'>{verdict}</td>"
            f"<td style='text-align:right'>{counts.get('critical', 0)}</td>"
            f"<td style='text-align:right'>{counts.get('high', 0)}</td>"
            f"<td style='text-align:right'>{counts.get('medium', 0)}</td>"
            f"<td>{html.escape(', '.join((result.get('sentinel') or {}).get('capabilities') or []))}</td>"
            "</tr>"
        )
    findings_rows = []
    for finding in flatten_findings(results):
        findings_rows.append(
            "<tr>"
            f"<td>{html.escape(str(finding.get('plugin') or ''))}</td>"
            f"<td>{html.escape(str(finding.get('severity', '')))}</td>"
            f"<td>{html.escape(str(finding.get('code', '')))}</td>"
            f"<td>{html.escape(str(finding.get('message', '')))}</td>"
            f"<td>{html.escape(str(finding.get('path', '')))}</td>"
            "</tr>"
        )
    return f"""<!doctype html>
<html><head><meta charset="utf-8"><title>Plugin Sentinel report</title>
<style>
body{{font-family:Segoe UI,Arial,sans-serif;color:#1f2937;margin:28px}}
h1{{color:#0f172a}} h2{{color:#1d4ed8;margin-top:28px}}
table{{border-collapse:collapse;width:100%;margin-top:8px}}
th,td{{border:1px solid #d1d5db;padding:6px 8px;text-align:left;vertical-align:top}}
th{{background:#f3f4f6}} code{{background:#f3f4f6;padding:1px 3px}}
.muted{{color:#6b7280}}
</style></head><body>
<h1>Plugin Sentinel report</h1>
<p class="muted">Generated {time.strftime('%Y-%m-%d %H:%M:%S')}</p>
<h2>Inventory</h2>
<table><thead><tr><th>Plugin</th><th>Version</th><th>Source</th><th>Risk</th><th>Grade</th><th>Verdict</th><th>Critical</th><th>High</th><th>Medium</th><th>Capabilities</th></tr></thead>
<tbody>{''.join(rows)}</tbody></table>
<h2>Sentinel findings</h2>
<table><thead><tr><th>Plugin</th><th>Severity</th><th>Code</th><th>Message</th><th>Path</th></tr></thead>
<tbody>{''.join(findings_rows)}</tbody></table>
</body></html>"""
