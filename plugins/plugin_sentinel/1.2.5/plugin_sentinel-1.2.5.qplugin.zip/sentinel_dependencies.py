"""Injected dependency discovery for Plugin Sentinel.

Wheel Plugin Manager can inject pre-built wheels for QAH's frozen Python under
``<QAH home>/plugins/vendor/<target>``. Those packages are not QAH plugins, so
they do not appear in the normal plugin inventory. This module exposes them as
read-only dependency sets for the Sentinel Dependencies tab.
"""

from __future__ import annotations

import csv
import importlib
import json
import os
import re
import shutil
import sys
import time
from pathlib import Path, PurePosixPath
from typing import Any, Dict, List

MANIFEST_NAME = "qah_dependencies.json"


def qah_home() -> Path:
    override = os.environ.get("QAH_HOME")
    return Path(override).expanduser() if override else Path.home() / "QAH"


def vendor_dir(create: bool = False) -> Path:
    override = os.environ.get("QAH_VENDOR_DIR")
    root = Path(override).expanduser() if override else qah_home() / "plugins" / "vendor"
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def activate(targets=("plugin_sentinel", "global")) -> List[str]:
    """Insert Sentinel-private and global vendor paths into sys.path."""
    root = vendor_dir(create=False)
    added: List[str] = []
    for target in targets:
        path = root / target
        if path.is_dir() and str(path) not in sys.path:
            sys.path.insert(0, str(path))
            added.append(str(path))
    if added:
        importlib.invalidate_caches()
    return added


def discover_dependency_sets() -> List[Dict[str, Any]]:
    root = vendor_dir(create=False)
    result: List[Dict[str, Any]] = []
    if not root.is_dir():
        return result
    for child in sorted(root.iterdir()):
        if not child.is_dir() or child.name.startswith("."):
            continue
        manifest = child / MANIFEST_NAME
        if not manifest.is_file():
            continue
        try:
            data = json.loads(manifest.read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(data, dict):
            continue
        data["path"] = str(child)
        data["target"] = str(data.get("target") or child.name)
        data.setdefault("packages", [])
        data.setdefault("wheels", [])
        result.append(data)
    return result


def dependency_rows() -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []
    for item in discover_dependency_sets():
        packages = item.get("packages") or []
        if not packages:
            rows.append({
                "target": str(item.get("target", "")),
                "package": "(empty set)",
                "version": "",
                "python": str(item.get("python", "")),
                "platform": str(item.get("platform", "")),
                "path": str(item.get("path", "")),
            })
            continue
        for package in packages:
            rows.append({
                "target": str(item.get("target", "")),
                "package": str(package.get("name", "")),
                "version": str(package.get("version", "")),
                "python": str(item.get("python", "")),
                "platform": str(item.get("platform", "")),
                "path": str(item.get("path", "")),
            })
    return rows


def summary_text() -> str:
    sets = discover_dependency_sets()
    packages = sum(len(item.get("packages") or []) for item in sets)
    return (
        f"{len(sets)} dependency set(s) · {packages} package(s) · "
        f"{vendor_dir(create=False)}"
    )


def _canonical(name: str) -> str:
    return re.sub(r"[-_.]+", "-", str(name or "").strip()).lower()


def _safe_target(target: str) -> Path:
    root = vendor_dir(create=False).resolve()
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", str(target or "global")).strip("._")
    if not name or name in (".", ".."):
        name = "global"
    path = (root / name).resolve()
    if path.parent != root:
        raise ValueError(f"Refusing to touch a path outside {root}: {path}")
    return path


def _remove_package_files(folder: Path, package: str) -> bool:
    canonical = _canonical(package)
    root = folder.resolve()
    removed = False
    for dist_info in list(folder.glob("*.dist-info")):
        meta = dist_info / "METADATA"
        if not meta.is_file():
            continue
        try:
            name = ""
            for line in meta.read_text(encoding="utf-8", errors="replace").splitlines():
                if line.lower().startswith("name:"):
                    name = line.split(":", 1)[1].strip()
                    break
        except OSError:
            continue
        if _canonical(name) != canonical:
            continue
        record = dist_info / "RECORD"
        if record.is_file():
            try:
                with open(record, "r", encoding="utf-8", errors="replace", newline="") as handle:
                    for row in csv.reader(handle):
                        if not row:
                            continue
                        relative = row[0].replace("\\", "/")
                        if not relative or relative.startswith("/"):
                            continue
                        if ".." in PurePosixPath(relative).parts:
                            continue
                        candidate = (folder / relative).resolve()
                        try:
                            if candidate.is_file() and root in candidate.parents:
                                candidate.unlink()
                        except OSError:
                            pass
            except OSError:
                pass
        shutil.rmtree(dist_info, ignore_errors=True)
        removed = True
    if removed:
        for directory in sorted(
            (item for item in folder.rglob("*") if item.is_dir()),
            key=lambda item: len(item.parts),
            reverse=True,
        ):
            try:
                directory.rmdir()
            except OSError:
                pass
    return removed


def _rewrite_manifest(folder: Path, package: str = "") -> None:
    manifest = folder / MANIFEST_NAME
    if not manifest.is_file():
        return
    try:
        data = json.loads(manifest.read_text(encoding="utf-8"))
    except Exception:
        return
    if package:
        canonical = _canonical(package)
        data["packages"] = [
            item for item in (data.get("packages") or [])
            if _canonical(item.get("name", "")) != canonical
        ]
        data["wheels"] = [
            item for item in (data.get("wheels") or [])
            if _canonical(item.get("name", "")) != canonical
        ]
        data["updated"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    manifest.write_text(json.dumps(data, indent=2), encoding="utf-8")


def remove_package(target: str, package: str) -> str:
    folder = _safe_target(target)
    if not folder.is_dir():
        raise ValueError(f"Dependency set not found: {folder}")
    if not _remove_package_files(folder, package):
        raise ValueError(f"Package {package!r} is not installed in {folder}.")
    _rewrite_manifest(folder, package)
    return f"Removed {package} from {folder}"


def remove_set(target: str) -> str:
    folder = _safe_target(target)
    if not folder.is_dir():
        raise ValueError(f"Dependency set not found: {folder}")
    shutil.rmtree(folder)
    return f"Removed dependency set {folder}"
