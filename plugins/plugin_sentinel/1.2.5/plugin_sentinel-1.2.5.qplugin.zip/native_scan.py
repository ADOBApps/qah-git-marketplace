"""Native library inspection for Plugin Sentinel.

Parses PE, ELF and Mach-O headers without importing the plugin or executing any
native code. It reports architecture, sections, entropy, imports, hardening
flags and suspicious APIs.
"""

from __future__ import annotations

import hashlib
import math
import struct
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, Dict, Iterable, List, Sequence, Tuple

NATIVE_SUFFIXES = (".dll", ".so", ".dylib", ".pyd")

SUSPICIOUS_IMPORTS = {
    "virtualalloc",
    "virtualprotect",
    "writeprocessmemory",
    "createremotethread",
    "createthread",
    "setwindowshookexa",
    "setwindowshookexw",
    "internetopen",
    "internetopenurl",
    "urldownloadtofile",
    "winexec",
    "shellexecutea",
    "shellexecutew",
    "createservicea",
    "createservicew",
    "regsetvaluea",
    "regsetvaluew",
    "ntcreatethreadex",
    "rtlcreateuserthread",
    "loadlibrarya",
    "loadlibraryw",
    "getprocaddress",
    "setwindowshookex",
}


def _u16(data: bytes, offset: int) -> int:
    return struct.unpack_from("<H", data, offset)[0]


def _u32(data: bytes, offset: int) -> int:
    return struct.unpack_from("<I", data, offset)[0]


def _u64(data: bytes, offset: int) -> int:
    return struct.unpack_from("<Q", data, offset)[0]


def _entropy(data: bytes) -> float:
    sample = data[: 1024 * 1024]
    if not sample:
        return 0.0
    counts = [0] * 256
    for byte in sample:
        counts[byte] += 1
    size = len(sample)
    result = 0.0
    for count in counts:
        if count:
            probability = count / size
            result -= probability * math.log2(probability)
    return round(result, 3)


def _safe_name(data: bytes, offset: int, limit: int = 256) -> str:
    if offset < 0 or offset >= len(data):
        return ""
    end = data.find(b"\x00", offset, min(len(data), offset + limit))
    if end < 0:
        end = min(len(data), offset + limit)
    return data[offset:end].decode("utf-8", errors="replace")


def _rva_to_offset(rva: int, sections: List[Dict[str, Any]]) -> int:
    for section in sections:
        start = int(section.get("virtual_address", 0))
        size = max(int(section.get("virtual_size", 0)), int(section.get("raw_size", 0)))
        if start <= rva < start + size:
            return int(section.get("raw_ptr", 0)) + (rva - start)
    return 0


def parse_pe(data: bytes) -> Dict[str, Any]:
    if len(data) < 0x40 or data[:2] != b"MZ":
        return {}
    try:
        pe_offset = _u32(data, 0x3C)
        if data[pe_offset:pe_offset + 4] != b"PE\x00\x00":
            return {}
        coff = pe_offset + 4
        machine = _u16(data, coff)
        section_count = _u16(data, coff + 2)
        timestamp = _u32(data, coff + 4)
        optional_size = _u16(data, coff + 16)
        characteristics = _u16(data, coff + 18)
        optional = coff + 20
        magic = _u16(data, optional)
        is_64 = magic == 0x20B
        if magic not in (0x10B, 0x20B):
            return {}
        subsystem = _u16(data, optional + 68)
        dll_characteristics = _u16(data, optional + 70)
        data_dir = optional + (112 if is_64 else 96)
        dir_count = _u32(data, optional + (108 if is_64 else 92))
        dir_count = min(dir_count, 16)

        def directory(index: int) -> Tuple[int, int]:
            offset = data_dir + index * 8
            if offset + 8 > len(data):
                return 0, 0
            return _u32(data, offset), _u32(data, offset + 4)

        sections = []
        section_offset = optional + optional_size
        for index in range(section_count):
            base = section_offset + index * 40
            if base + 40 > len(data):
                break
            name = data[base:base + 8].split(b"\x00", 1)[0].decode("ascii", errors="replace")
            virtual_size = _u32(data, base + 8)
            virtual_address = _u32(data, base + 12)
            raw_size = _u32(data, base + 16)
            raw_ptr = _u32(data, base + 20)
            section_characteristics = _u32(data, base + 36)
            sections.append({
                "name": name,
                "virtual_size": virtual_size,
                "virtual_address": virtual_address,
                "raw_size": raw_size,
                "raw_ptr": raw_ptr,
                "characteristics": section_characteristics,
                "executable": bool(section_characteristics & 0x20000000),
                "writable": bool(section_characteristics & 0x80000000),
            })

        imports = []
        import_rva, import_size = directory(1)
        if import_rva and import_size:
            offset = _rva_to_offset(import_rva, sections)
            for index in range(256):
                descriptor = offset + index * 20
                if descriptor + 20 > len(data):
                    break
                original_thunk = _u32(data, descriptor)
                name_rva = _u32(data, descriptor + 12)
                first_thunk = _u32(data, descriptor + 16)
                if not any((original_thunk, name_rva, first_thunk)):
                    break
                dll_name = _safe_name(data, _rva_to_offset(name_rva, sections))
                thunk_rva = original_thunk or first_thunk
                thunk_offset = _rva_to_offset(thunk_rva, sections)
                if thunk_offset:
                    step = 8 if is_64 else 4
                    for thunk_index in range(512):
                        location = thunk_offset + thunk_index * step
                        if location + step > len(data):
                            break
                        value = _u64(data, location) if is_64 else _u32(data, location)
                        if not value:
                            break
                        high = 1 << (63 if is_64 else 31)
                        if value & high:
                            imports.append(f"{dll_name}!#{value & 0xFFFF}")
                        else:
                            hint_name = _rva_to_offset(value, sections)
                            if hint_name:
                                imports.append(f"{dll_name}!{_safe_name(data, hint_name + 2)}")
        debug_size = directory(6)[1]
        tls_size = directory(9)[1]
        security_size = directory(4)[1]
        flags = []
        if any(section["executable"] and section["writable"] for section in sections):
            flags.append("writable+executable section")
        if dll_characteristics & 0x40:
            flags.append("ASLR compatible")
        if dll_characteristics & 0x100:
            flags.append("NX compatible")
        if dll_characteristics & 0x400:
            flags.append("Control Flow Guard")
        if tls_size:
            flags.append("TLS callbacks")
        if debug_size:
            flags.append("debug directory")
        return {
            "format": "PE",
            "arch": {
                0x14C: "x86", 0x8664: "x64", 0xAA64: "ARM64", 0x1C0: "ARM"
            }.get(machine, f"0x{machine:x}"),
            "bits": 64 if is_64 else 32,
            "subsystem": {
                1: "native", 2: "GUI", 3: "console", 9: "Windows CE", 10: "EFI"
            }.get(subsystem, str(subsystem)),
            "timestamp": timestamp,
            "characteristics": characteristics,
            "sections": sections,
            "imports": sorted(set(imports))[:500],
            "signed": bool(security_size),
            "flags": flags,
            "has_tls": bool(tls_size),
            "has_debug": bool(debug_size),
        }
    except Exception:
        return {}


def parse_elf(data: bytes) -> Dict[str, Any]:
    if len(data) < 0x40 or data[:4] != b"\x7fELF":
        return {}
    try:
        bits = data[4]
        endian = "<" if data[5] == 1 else ">"
        is_64 = bits == 2
        e_type = struct.unpack_from(endian + "H", data, 16)[0]
        machine = struct.unpack_from(endian + "H", data, 18)[0]
        entry = struct.unpack_from(endian + ("Q" if is_64 else "I"), data, 24)[0]
        phoff = struct.unpack_from(endian + ("Q" if is_64 else "I"), data, 32)[0]
        shoff = struct.unpack_from(endian + ("Q" if is_64 else "I"), data, 40)[0]
        phentsize = struct.unpack_from(endian + "H", data, 54)[0]
        phnum = struct.unpack_from(endian + "H", data, 56)[0]
        shentsize = struct.unpack_from(endian + "H", data, 58)[0]
        shnum = struct.unpack_from(endian + "H", data, 60)[0]
        loads = []
        interp = ""
        exec_stack = False
        dynamic = None
        for index in range(phnum):
            base = phoff + index * phentsize
            if is_64:
                p_type, p_flags, p_offset, p_vaddr, p_paddr, p_filesz, p_memsz, p_align = struct.unpack_from(
                    endian + "IIQQQQQQ", data, base
                )
            else:
                p_type, p_offset, p_vaddr, p_paddr, p_filesz, p_memsz, p_flags, p_align = struct.unpack_from(
                    endian + "IIIIIIII", data, base
                )
            if p_type == 1:
                loads.append((p_vaddr, p_offset, p_filesz))
            elif p_type == 2:
                dynamic = (p_offset, p_filesz)
            elif p_type == 3:
                interp = _safe_name(data, p_offset, p_filesz or 256)
            elif p_type == 0x6474E551:  # GNU_STACK
                exec_stack = bool(p_flags & 1)
        needed = []
        rpath = []
        if dynamic:
            strtab = 0
            strsz = 0
            entries = []
            step = 16 if is_64 else 8
            offset, size = dynamic
            for index in range(min(size // step, 4096)):
                base = offset + index * step
                tag, value = struct.unpack_from(endian + ("QQ" if is_64 else "II"), data, base)
                entries.append((tag, value))
                if tag == 0:
                    break
                if tag == 5:
                    strtab = value
                elif tag == 10:
                    strsz = value
            strtab_offset = 0
            for vaddr, file_offset, filesz in loads:
                if vaddr <= strtab < vaddr + filesz:
                    strtab_offset = file_offset + (strtab - vaddr)
                    break
            for tag, value in entries:
                if tag in (1, 15, 29) and strtab_offset:
                    text = _safe_name(data, strtab_offset + value, strsz or 512)
                    if tag == 1:
                        needed.append(text)
                    else:
                        rpath.append(text)
        flags = []
        if exec_stack:
            flags.append("executable stack")
        if rpath:
            flags.append("RPATH/RUNPATH")
        if e_type == 2:
            flags.append("non-PIE executable")
        if not interp:
            flags.append("static/no interpreter")
        return {
            "format": "ELF",
            "arch": {
                3: "x86", 62: "x64", 40: "ARM", 183: "ARM64", 8: "MIPS", 20: "PowerPC", 21: "PowerPC64", 243: "RISC-V"
            }.get(machine, f"0x{machine:x}"),
            "bits": 64 if is_64 else 32,
            "subsystem": {1: "relocatable", 2: "executable", 3: "shared object", 4: "core"}.get(e_type, str(e_type)),
            "entry": entry,
            "sections": [],
            "imports": sorted(set(needed))[:500],
            "signed": "n/a",
            "flags": flags,
            "rpath": rpath,
            "interp": interp,
            "has_tls": False,
            "has_debug": bool(shoff and shnum),
        }
    except Exception:
        return {}


def parse_macho(data: bytes) -> Dict[str, Any]:
    if len(data) < 28:
        return {}
    try:
        magic = struct.unpack_from(">I", data, 0)[0]
        if magic not in (0xFEEDFACE, 0xFEEDFACF, 0xCAFEBABE, 0xBEBAFECA):
            return {}
        if magic == 0xCAFEBABE:
            return {"format": "Mach-O", "arch": "fat/universal", "bits": 0, "sections": [], "imports": [], "signed": "n/a", "flags": ["fat binary"]}
        is_64 = magic == 0xFEEDFACF
        cputype = struct.unpack_from(">I", data, 4)[0]
        filetype = struct.unpack_from(">I", data, 12)[0]
        ncmds = struct.unpack_from(">I", data, 16)[0]
        offset = 32 if is_64 else 28
        imports = []
        rpaths = []
        signed = False
        for _ in range(min(ncmds, 4096)):
            if offset + 8 > len(data):
                break
            cmd, cmdsize = struct.unpack_from(">II", data, offset)
            if cmdsize < 8:
                break
            if cmd in (0xC, 0xD, 0x18):
                name_offset = struct.unpack_from(">I", data, offset + 8)[0]
                name = _safe_name(data, offset + name_offset, cmdsize)
                if name:
                    imports.append(name)
            elif cmd == 0x8000001C:
                path_offset = struct.unpack_from(">I", data, offset + 8)[0]
                path = _safe_name(data, offset + path_offset, cmdsize)
                if path:
                    rpaths.append(path)
            elif cmd == 0x1D:
                signed = True
            offset += cmdsize
        flags = []
        if rpaths:
            flags.append("RPATH")
        if not signed:
            flags.append("no code signature")
        return {
            "format": "Mach-O",
            "arch": {7: "x86", 0x01000007: "x64", 12: "ARM", 0x0100000C: "ARM64"}.get(cputype, f"0x{cputype:x}"),
            "bits": 64 if is_64 else 32,
            "subsystem": {2: "executable", 6: "dylib", 8: "bundle"}.get(filetype, str(filetype)),
            "sections": [],
            "imports": sorted(set(imports))[:500],
            "signed": signed,
            "flags": flags,
            "rpath": rpaths,
            "has_tls": False,
            "has_debug": False,
        }
    except Exception:
        return {}


def parse_native(data: bytes) -> Dict[str, Any]:
    for parser in (parse_pe, parse_elf, parse_macho):
        result = parser(data)
        if result:
            return result
    return {}


def iter_native_files(target: Any) -> Iterable[Tuple[str, bytes]]:
    path = Path(target.path)
    if path.is_dir():
        for file in sorted(path.rglob("*")):
            if file.is_file() and file.suffix.lower() in NATIVE_SUFFIXES:
                rel = file.relative_to(path)
                try:
                    if file.stat().st_size > 128 * 1024 * 1024:
                        continue
                    yield str(rel), file.read_bytes()
                except OSError:
                    continue
        return
    if path.suffix.lower() in NATIVE_SUFFIXES:
        try:
            yield path.name, path.read_bytes()
        except OSError:
            return
        return
    if path.suffix.lower() not in (".zip", ".whl", ".qplugin"):
        return
    try:
        with zipfile.ZipFile(path) as archive:
            for name in archive.namelist():
                if PurePosixPath(name).suffix.lower() not in NATIVE_SUFFIXES:
                    continue
                info = archive.getinfo(name)
                if info.file_size > 128 * 1024 * 1024:
                    continue
                try:
                    yield name, archive.read(name)
                except Exception:
                    continue
    except Exception:
        return


def scan_native(target: Any) -> List[Dict[str, Any]]:
    libraries = []
    for name, data in iter_native_files(target):
        parsed = parse_native(data)
        safe = name.replace("\\", "/").split("/")[-1]
        findings = []
        if not parsed:
            findings.append({"severity": "low", "code": "native.unknown_format", "message": f"Unrecognized native format: {name}", "path": name})
            parsed = {"format": "unknown", "arch": "unknown", "bits": 0, "sections": [], "imports": [], "signed": "n/a", "flags": [], "has_tls": False, "has_debug": False}
        imports = [item.lower() for item in (parsed.get("imports") or [])]
        suspicious = sorted({item.split("!")[-1] for item in (parsed.get("imports") or []) if item.split("!")[-1].lower() in SUSPICIOUS_IMPORTS})
        if suspicious:
            findings.append({"severity": "high", "code": "native.suspicious_import", "message": "Suspicious imports: " + ", ".join(suspicious[:12]), "path": name})
        if any(section.get("executable") and section.get("writable") for section in parsed.get("sections") or []):
            findings.append({"severity": "high", "code": "native.wx_section", "message": "A section is both writable and executable", "path": name})
        if parsed.get("has_tls"):
            findings.append({"severity": "medium", "code": "native.tls_callback", "message": "TLS callbacks present", "path": name})
        if parsed.get("format") == "PE" and parsed.get("signed") is False:
            findings.append({"severity": "medium", "code": "native.unsigned", "message": "PE file has no Authenticode signature", "path": name})
        if "executable stack" in (parsed.get("flags") or []):
            findings.append({"severity": "high", "code": "native.exec_stack", "message": "Executable stack flag set", "path": name})
        if parsed.get("rpath"):
            findings.append({"severity": "medium", "code": "native.rpath", "message": "RPATH/RUNPATH is set: " + ", ".join(parsed["rpath"][:4]), "path": name})
        entropy = _entropy(data)
        if entropy >= 7.2:
            findings.append({"severity": "medium", "code": "native.high_entropy", "message": f"High entropy ({entropy}); possible packing/encryption", "path": name})
        if parsed.get("has_debug"):
            findings.append({"severity": "info", "code": "native.debug", "message": "Debug metadata present", "path": name})
        libraries.append({
            "name": name,
            "file": safe,
            "format": parsed.get("format", "unknown"),
            "arch": parsed.get("arch", "unknown"),
            "bits": parsed.get("bits", 0),
            "subsystem": parsed.get("subsystem", ""),
            "size": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
            "entropy": entropy,
            "signed": parsed.get("signed", "n/a"),
            "imports": parsed.get("imports") or [],
            "flags": parsed.get("flags") or [],
            "sections": parsed.get("sections") or [],
            "findings": findings,
        })
    return libraries


def native_findings(libraries: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    findings = []
    for library in libraries:
        findings.extend(library.get("findings") or [])
    return findings
