"""Isolated child process that executes one Sentinel addon.

This file is intentionally standalone: it only imports the Python standard
library, applies audit hooks before the addon is loaded, and writes a JSON
result. It is launched by ``sentinel_addons.run_addon`` and must not be
imported into Sentinel's process.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
import sys
import time
import traceback

MAX_FINDINGS = 500
MAX_TEXT = 200_000


def _real(path) -> str:
    try:
        return os.path.realpath(os.fspath(path))
    except Exception:
        return ""


def _under(path: str, roots) -> bool:
    for root in roots:
        if path == root or path.startswith(root + os.sep):
            return True
    return False


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--addon", required=True)
    parser.add_argument("--context", required=True)
    parser.add_argument("--result", required=True)
    parser.add_argument("--data-dir", required=True)
    parser.add_argument("--workdir", required=True)
    parser.add_argument("--allow-network", default="0")
    parser.add_argument("--allow-write", default="0")
    parser.add_argument("--allowed-read", action="append", default=[])
    args = parser.parse_args()

    allow_network = args.allow_network == "1"
    allow_write = args.allow_write == "1"
    addon_dir = _real(args.addon)
    data_dir = _real(args.data_dir)
    workdir = _real(args.workdir)
    result_path = _real(args.result)
    read_roots = {_real(item) for item in args.allowed_read if item}
    read_roots.update({addon_dir, data_dir, workdir, result_path})
    write_roots = {workdir, result_path}
    if allow_write:
        write_roots.add(data_dir)

    violations = []

    def violation(event: str, detail: str):
        violations.append({"event": event, "detail": detail[:500]})
        raise PermissionError(f"sentinel addon sandbox: {detail}")

    def hook(event, values):
        if event.startswith("socket.") and not allow_network:
            violation(event, "network access is not declared")
        if event in (
            "subprocess.Popen",
            "os.system",
            "os.exec",
            "os.spawn",
            "os.posix_spawn",
            "os.posix_spawnp",
            "os.fork",
            "os.forkpty",
            "pty.spawn",
        ):
            violation(event, "process creation is not allowed in addons")
        if event in ("ctypes.dlopen", "ctypes.dlsym", "ctypes.dlsym/handle"):
            violation(event, "native library loading is not allowed in addons")
        if event.startswith("winreg."):
            violation(event, "registry access is blocked")
        if event == "open":
            path = values[0] if values else None
            mode = values[1] if len(values) > 1 else None
            if isinstance(path, (str, bytes, os.PathLike)) and isinstance(mode, str):
                real = _real(path)
                writing = any(ch in mode for ch in "wax+")
                if writing and not _under(real, write_roots):
                    violation(event, "write outside the addon data directory: " + real)
                if not writing and not _under(real, read_roots):
                    violation(event, "read outside the addon and target paths: " + real)
        if event in ("os.listdir", "os.scandir"):
            target = values[0] if values else None
            if isinstance(target, (str, bytes, os.PathLike)):
                real = _real(target)
                if not _under(real, read_roots):
                    violation(event, "directory listing outside the addon and target paths: " + real)
        if event in (
            "os.remove",
            "os.rename",
            "os.rmdir",
            "os.mkdir",
            "os.unlink",
            "shutil.rmtree",
        ):
            for value in values:
                if isinstance(value, (str, bytes, os.PathLike)):
                    real = _real(value)
                    if not _under(real, write_roots):
                        violation(event, "filesystem mutation outside the addon data directory: " + real)
        if event in ("shutil.copyfile", "shutil.move", "shutil.copytree"):
            destination = values[-1] if values else None
            if isinstance(destination, (str, bytes, os.PathLike)):
                real = _real(destination)
                if not _under(real, write_roots):
                    violation(event, "filesystem mutation outside the addon data directory: " + real)
        if event == "os.chdir":
            target = values[0] if values else None
            if isinstance(target, (str, bytes, os.PathLike)):
                real = _real(target)
                if not _under(real, {workdir}):
                    violation(event, "changing directory outside the sandbox")

    with open(args.context, "r", encoding="utf-8") as handle:
        context = json.load(handle)

    sys.dont_write_bytecode = True
    sys.addaudithook(hook)
    if os.name != "nt":
        try:
            import resource

            memory = 512 * 1024 * 1024
            resource.setrlimit(resource.RLIMIT_AS, (memory, memory))
            resource.setrlimit(resource.RLIMIT_CPU, (300, 300))
            resource.setrlimit(resource.RLIMIT_FSIZE, (64 * 1024 * 1024, 64 * 1024 * 1024))
            resource.setrlimit(resource.RLIMIT_NOFILE, (256, 256))
            try:
                resource.setrlimit(resource.RLIMIT_NPROC, (32, 32))
            except Exception:
                pass
        except Exception:
            pass

    os.chdir(workdir)
    started = time.time()
    status = "ok"
    detail = ""
    payload = {}
    try:
        manifest_path = os.path.join(addon_dir, "addon.json")
        with open(manifest_path, "r", encoding="utf-8") as handle:
            manifest = json.load(handle)
        main_name = str(manifest.get("main") or "main.py")
        entry_name = str(manifest.get("entry") or "run")
        main_path = os.path.join(addon_dir, main_name)
        spec = importlib.util.spec_from_file_location("sentinel_addon_main", main_path)
        if spec is None or spec.loader is None:
            raise RuntimeError(f"Cannot load addon main file: {main_name}")
        module = importlib.util.module_from_spec(spec)
        sys.modules["sentinel_addon_main"] = module
        spec.loader.exec_module(module)
        entry = getattr(module, entry_name, None)
        if not callable(entry):
            raise RuntimeError(f"Addon entry {entry_name!r} is not callable")
        returned = entry(context)
        if returned is None:
            payload = {}
        elif isinstance(returned, dict):
            payload = returned
        else:
            payload = {"data": returned}
        try:
            json.dumps(payload)
        except TypeError as exc:
            raise RuntimeError(f"Addon returned data that is not JSON serializable: {exc}")
        status = str(payload.get("status") or "ok")
        if status not in (
            "ok",
            "info",
            "warning",
            "high",
            "critical",
            "error",
            "blocked",
        ):
            status = "ok"
        detail = str(payload.get("detail") or "")
    except BaseException as exc:
        status = "blocked" if violations else "error"
        detail = f"{type(exc).__name__}: {exc}"
        payload = {"traceback": traceback.format_exc()[-8000:]}
    if violations and status == "ok":
        status = "blocked"

    findings = payload.get("findings")
    if not isinstance(findings, list):
        findings = []
    result = {
        "status": status,
        "detail": detail[:4000],
        "summary": str(payload.get("summary") or "")[:MAX_TEXT],
        "report": str(payload.get("report") or "")[:MAX_TEXT],
        "findings": findings[:MAX_FINDINGS],
        "data": payload.get("data") if isinstance(payload.get("data"), dict) else {},
        "violations": violations[:100],
        "duration": round(time.time() - started, 3),
        "traceback": str(payload.get("traceback") or ""),
    }
    try:
        written = json.dumps(result)
    except Exception as exc:
        written = json.dumps({
            "status": "error",
            "detail": f"Could not serialize addon result: {exc}",
            "violations": violations[:100],
        })
    if len(written.encode("utf-8")) > 4 * 1024 * 1024:
        result["findings"] = findings[:50]
        result["report"] = result["report"][:10000]
        written = json.dumps(result)
    try:
        with open(result_path, "w", encoding="utf-8") as handle:
            handle.write(written)
    except Exception:
        pass
    print("__SENTINEL_ADDON_RESULT__" + json.dumps({
        "status": result["status"],
        "violations": len(violations),
    }), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
