"""Hash watchdog for Plugin Sentinel.

Watches a plugin directory or a native library and alerts when its content
changes. This is a drift detector, not an OS filesystem filter.
"""

from __future__ import annotations

import hashlib
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QAbstractItemView,
    QFileDialog,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from . import sentinel_core as core


def watches_path() -> Path:
    return core.state_dir() / "watches.json"


def load_watches() -> Dict:
    value = core.load_json(watches_path(), {})
    if not isinstance(value, dict):
        value = {}
    value.setdefault("format", "qah-plugin-sentinel-watches")
    value.setdefault("version", 1)
    value.setdefault("interval", 5)
    value.setdefault("watches", [])
    return value


def save_watches(data: Dict) -> None:
    core.save_json(watches_path(), data)


class WatchdogWorker(QThread):
    updated = Signal(dict)
    failure = Signal(str)

    def __init__(self, watches: List[dict], interval: int = 5, once: bool = False, parent=None):
        super().__init__(parent)
        self.watches = [dict(item) for item in watches]
        self.interval = max(1, int(interval))
        self.once = once
        self._stop = threading.Event()

    def stop(self):
        self._stop.set()

    def run(self):
        try:
            while not self._stop.is_set():
                for watch in self.watches:
                    if self._stop.is_set():
                        break
                    path = Path(watch.get("path", ""))
                    key = str(watch.get("key") or path)
                    if not path.exists():
                        self.updated.emit({
                            "key": key,
                            "status": "missing",
                            "current": "",
                            "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                        })
                        continue
                    try:
                        current = core.digest_path(path)
                    except Exception as exc:
                        self.updated.emit({
                            "key": key,
                            "status": "error",
                            "current": "",
                            "error": str(exc),
                            "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                        })
                        continue
                    status = "ok" if current == watch.get("digest") else "changed"
                    self.updated.emit({
                        "key": key,
                        "status": status,
                        "current": current,
                        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                    })
                if self.once:
                    break
                if self._stop.wait(self.interval):
                    break
        except Exception as exc:
            self.failure.emit(str(exc))


class WatchdogTab(QWidget):
    COLUMNS = ("Target", "Type", "Path", "Status", "Last check", "Pinned digest", "Current digest")

    def __init__(self, parent=None):
        super().__init__(parent)
        self.data = load_watches()
        self.worker: Optional[WatchdogWorker] = None
        self._build_ui()
        self._refresh_table()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(6)
        intro = QLabel(
            "Watch a plugin folder or a native library. The watchdog recomputes "
            "its SHA256 and reports <b>changed</b> when the content drifts."
        )
        intro.setWordWrap(True)
        intro.setStyleSheet("color:#6b7280;")
        layout.addWidget(intro)

        row = QHBoxLayout()
        add_plugin = QPushButton("Watch plugin folder…")
        add_plugin.clicked.connect(self.add_plugin)
        row.addWidget(add_plugin)
        add_library = QPushButton("Watch library…")
        add_library.clicked.connect(self.add_library)
        row.addWidget(add_library)
        remove = QPushButton("Remove")
        remove.clicked.connect(self.remove_selected)
        row.addWidget(remove)
        pin = QPushButton("Pin current")
        pin.clicked.connect(self.pin_current)
        row.addWidget(pin)
        row.addSpacing(12)
        row.addWidget(QLabel("Check every"))
        self.interval_spin = QSpinBox()
        self.interval_spin.setRange(2, 3600)
        self.interval_spin.setSuffix(" s")
        self.interval_spin.setValue(int(self.data.get("interval", 5)))
        row.addWidget(self.interval_spin)
        self.start_btn = QPushButton("Start watchdog")
        self.start_btn.clicked.connect(self.toggle_watchdog)
        row.addWidget(self.start_btn)
        check = QPushButton("Check now")
        check.clicked.connect(self.check_now)
        row.addWidget(check)
        row.addStretch(1)
        layout.addLayout(row)

        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(list(self.COLUMNS))
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.table, 1)
        self.status = QLabel("Watchdog stopped.")
        self.status.setStyleSheet("color:#6b7280;")
        layout.addWidget(self.status)

    def _refresh_table(self):
        self.table.setRowCount(0)
        for watch in self.data.get("watches", []):
            row = self.table.rowCount()
            self.table.insertRow(row)
            values = [
                watch.get("label") or Path(str(watch.get("path", ""))).name,
                watch.get("type", ""),
                watch.get("path", ""),
                watch.get("status", "unknown"),
                watch.get("last_check", ""),
                str(watch.get("digest", ""))[:16] + ("…" if len(str(watch.get("digest", ""))) > 16 else ""),
                str(watch.get("current", ""))[:16] + ("…" if len(str(watch.get("current", ""))) > 16 else ""),
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setData(Qt.ItemDataRole.UserRole, watch.get("key"))
                if col == 3:
                    status = watch.get("status", "")
                    if status == "changed":
                        item.setBackground(QColor("#fecaca"))
                    elif status == "ok":
                        item.setBackground(QColor("#dcfce7"))
                    elif status in ("missing", "error"):
                        item.setBackground(QColor("#fef3c7"))
                self.table.setItem(row, col, item)

    def _add_watch(self, path: Path, kind: str):
        path = path.resolve()
        if not path.exists():
            QMessageBox.warning(self, "Plugin Sentinel", f"Path does not exist:\n{path}")
            return
        key = f"{kind}:{path}"
        watches = self.data.setdefault("watches", [])
        existing = next((item for item in watches if item.get("key") == key), None)
        try:
            digest = core.digest_path(path)
        except Exception as exc:
            QMessageBox.critical(self, "Plugin Sentinel", f"Could not hash target:\n{exc}")
            return
        if existing is None:
            existing = {
                "key": key,
                "label": path.name,
                "type": kind,
                "path": str(path),
            }
            watches.append(existing)
        existing.update({
            "digest": digest,
            "current": digest,
            "status": "ok",
            "last_check": time.strftime("%Y-%m-%d %H:%M:%S"),
        })
        save_watches(self.data)
        self._refresh_table()
        self.status.setText(f"Watching {path}")

    def add_plugin(self):
        path = QFileDialog.getExistingDirectory(self, "Select plugin folder to watch")
        if path:
            self._add_watch(Path(path), "plugin")

    def add_library(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select native library to watch", str(Path.home()),
            "Native libraries (*.dll *.so *.dylib *.pyd);;All files (*)",
        )
        if path:
            self._add_watch(Path(path), "library")

    def remove_selected(self):
        row = self.table.currentRow()
        if row < 0:
            return
        key_item = self.table.item(row, 0)
        key = key_item.data(Qt.ItemDataRole.UserRole) if key_item else None
        self.data["watches"] = [item for item in self.data.get("watches", []) if item.get("key") != key]
        save_watches(self.data)
        self._refresh_table()

    def pin_current(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.information(self, "Plugin Sentinel", "Select a watch first.")
            return
        key_item = self.table.item(row, 0)
        key = key_item.data(Qt.ItemDataRole.UserRole) if key_item else None
        watch = next((item for item in self.data.get("watches", []) if item.get("key") == key), None)
        if watch is None:
            return
        try:
            digest = core.digest_path(Path(watch["path"]))
        except Exception as exc:
            QMessageBox.critical(self, "Plugin Sentinel", f"Could not hash target:\n{exc}")
            return
        watch.update({"digest": digest, "current": digest, "status": "ok", "last_check": time.strftime("%Y-%m-%d %H:%M:%S")})
        save_watches(self.data)
        self._refresh_table()

    def toggle_watchdog(self):
        if self.worker is not None and self.worker.isRunning():
            self.stop_watchdog()
        else:
            self.start_watchdog()

    def start_watchdog(self):
        if self.worker is not None and self.worker.isRunning():
            return
        watches = [item for item in self.data.get("watches", []) if item.get("path")]
        if not watches:
            QMessageBox.information(self, "Plugin Sentinel", "Add a plugin or library to watch first.")
            return
        self.data["interval"] = int(self.interval_spin.value())
        save_watches(self.data)
        worker = WatchdogWorker(watches, self.data["interval"], parent=self)
        worker.updated.connect(self._on_update)
        worker.failure.connect(lambda text: self.status.setText(f"Watchdog error: {text}"))
        worker.finished.connect(lambda w=worker: self._on_worker_finished(w))
        self.worker = worker
        self.start_btn.setText("Stop watchdog")
        self.status.setText(f"Watchdog running · {len(watches)} target(s)")
        worker.start()

    def stop_watchdog(self):
        worker = self.worker
        if worker is not None:
            worker.stop()
            worker.wait(3000)
            if worker.isRunning():
                worker.setParent(None)
                worker.finished.connect(worker.deleteLater)
            else:
                worker.deleteLater()
            self.worker = None
        self.start_btn.setText("Start watchdog")
        self.status.setText("Watchdog stopped.")

    def check_now(self):
        if self.worker is not None and self.worker.isRunning():
            QMessageBox.information(self, "Plugin Sentinel", "The watchdog is already running.")
            return
        watches = [item for item in self.data.get("watches", []) if item.get("path")]
        if not watches:
            QMessageBox.information(self, "Plugin Sentinel", "Add a plugin or library to watch first.")
            return
        worker = WatchdogWorker(watches, 1, once=True, parent=self)
        worker.updated.connect(self._on_update)
        worker.failure.connect(lambda text: self.status.setText(f"Watchdog error: {text}"))
        worker.finished.connect(lambda w=worker: self._on_worker_finished(w))
        self.worker = worker
        self.status.setText("Checking watched targets…")
        worker.start()

    def _on_update(self, update: dict):
        key = update.get("key")
        watch = next((item for item in self.data.get("watches", []) if item.get("key") == key), None)
        if watch is None:
            return
        watch["status"] = update.get("status", "unknown")
        watch["current"] = update.get("current", watch.get("current", ""))
        watch["last_check"] = update.get("time", time.strftime("%Y-%m-%d %H:%M:%S"))
        self._refresh_table()
        if update.get("status") == "changed":
            self.status.setText(f"CHANGED: {watch.get('label')} — pin current to accept")
            self.status.setStyleSheet("color:#b91c1c;font-weight:bold;")
        elif update.get("status") == "ok":
            self.status.setText(f"OK: {watch.get('label')}")
            self.status.setStyleSheet("color:#15803d;")
        elif update.get("status") in ("missing", "error"):
            self.status.setText(f"{update.get('status').upper()}: {watch.get('label')} {update.get('error','')}")
            self.status.setStyleSheet("color:#b45309;")

    def _on_worker_finished(self, worker):
        if self.worker is worker:
            self.worker = None
        worker.deleteLater()
        self.start_btn.setText("Start watchdog")

    def cleanup(self):
        self.stop_watchdog()
