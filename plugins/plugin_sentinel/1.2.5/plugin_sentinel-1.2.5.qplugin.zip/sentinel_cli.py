"""Headless Plugin Sentinel CLI.

Examples:
    python sentinel_cli.py --all
    python sentinel_cli.py C:\\path\\plugin.qplugin.zip --format json
    python sentinel_cli.py --all --checks manifest archive static deps --fail-on high
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from sentinel_core import (
    BASE_ALL_CHECKS,
    BASE_DEFAULT_CHECKS,
    annotate_duplicates,
    default_policy,
    find_targets,
    load_baseline,
    load_policy,
    make_target,
    report_to_csv,
    report_to_html,
    report_to_json,
    report_to_markdown,
    scan_target,
    save_baseline,
    save_policy,
    trust_target,
)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="Plugin Sentinel: risk scoring and policy audit for QAH plugins."
    )
    parser.add_argument("paths", nargs="*", help="plugin folders, .qplugin.zip or .whl files")
    parser.add_argument("--all", action="store_true", help="scan installed user/system/wheel plugins")
    parser.add_argument("--checks", nargs="+", default=list(BASE_DEFAULT_CHECKS), choices=list(BASE_ALL_CHECKS))
    parser.add_argument("--format", choices=["text", "json", "md", "html", "csv"], default="text")
    parser.add_argument("--output", help="write the report to this file")
    parser.add_argument("--baseline", help="baseline JSON path")
    parser.add_argument("--policy", help="policy JSON path")
    parser.add_argument("--fail-on", choices=["never", "low", "medium", "high", "critical"], help="override policy fail_on")
    parser.add_argument("--max-risk", type=int, help="override policy max_risk")
    parser.add_argument("--require-trusted", action="store_true", help="override policy require_trusted")
    parser.add_argument("--trust", action="store_true", help="trust every scanned plugin in the baseline")
    parser.add_argument("--save-policy", help="write the effective policy to this path and exit after saving")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args(argv)

    baseline_path = Path(args.baseline).expanduser() if args.baseline else None
    policy_path = Path(args.policy).expanduser() if args.policy else None
    baseline = load_baseline(baseline_path)
    policy = load_policy(policy_path)
    if args.fail_on:
        policy["fail_on"] = args.fail_on
    if args.max_risk is not None:
        policy["max_risk"] = int(args.max_risk)
    if args.require_trusted:
        policy["require_trusted"] = True

    if args.save_policy:
        save_policy(policy, Path(args.save_policy).expanduser())
        print(f"Policy written to {args.save_policy}")
        return 0

    targets = []
    if args.all or not args.paths:
        targets.extend(find_targets())
    for raw in args.paths:
        targets.append(make_target(Path(raw).expanduser(), "file"))
    if not targets:
        print("No plugins found to scan.", file=sys.stderr)
        return 2

    results = []
    for target in targets:
        if not args.quiet:
            print(f"Scanning {target.label} ({target.source})...", file=sys.stderr)
        results.append(scan_target(target, args.checks, policy, baseline))

    annotate_duplicates(results, policy)
    if args.trust:
        for target in targets:
            trust_target(target, baseline)
        save_baseline(baseline, baseline_path)

    if args.format == "json":
        text = report_to_json(results, policy, baseline)
    elif args.format == "md":
        text = report_to_markdown(results)
    elif args.format == "html":
        text = report_to_html(results, policy)
    elif args.format == "csv":
        text = report_to_csv(results)
    else:
        text = "\n\n".join(result.get("text", "") for result in results)
        text += "\n\n" + "-" * 68 + "\n"
        for result in results:
            counts = result.get("counts") or {}
            text += (
                f"{result.get('label'):<34} risk={result.get('risk_score', 0):>3} "
                f"grade={result.get('grade', 'A')} {result.get('policy_verdict', 'PASS'):<5} "
                f"C{counts.get('critical', 0)} H{counts.get('high', 0)} "
                f"M{counts.get('medium', 0)} L{counts.get('low', 0)}\n"
            )

    if args.output:
        Path(args.output).expanduser().write_text(text, encoding="utf-8")
        if not args.quiet:
            print(f"Report written to {args.output}", file=sys.stderr)
    else:
        print(text)

    blocked = any(result.get("policy_verdict") == "BLOCK" for result in results)
    return 1 if blocked else 0


if __name__ == "__main__":
    raise SystemExit(main())
