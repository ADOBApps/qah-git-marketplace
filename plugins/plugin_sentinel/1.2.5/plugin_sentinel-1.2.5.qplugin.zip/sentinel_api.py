"""Public watchdog API for Plugin Sentinel.

Other QAH plugins can import this module while Plugin Sentinel is installed to
register file, plugin, native-library or execution-output watches. Watches are
persisted in sentinel's ``watches.json`` and are visible in the Watchdog tab.

Example::

    from plugin_sentinel import sentinel_api
    sentinel_api.watch_plugin("my_plugin")
    sentinel_api.watch_library(r"C:\\path\\native.dll")
    sentinel_api.watch_execution("simulation output", r"C:\\path\\out.log")

Callbacks are in-process subscriptions. If both plugins are loaded, call
``poll()`` from a QTimer/thread to check watches and dispatch events. Cross-
process consumers can read ``watches.json`` and ``events.jsonl`` directly.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from . import sentinel_core as core

_CALLBACKS: List[Callable[[Dict[str, Any]], None]] = []


def watches_file() -> Path:
    return core.state_dir() / "watches.json"


def events_file() -> Path:
    return core.state_dir() / "events.jsonl"


def _load() -> Dict[str, Any]:
    value = core.load_json(watches_file(), {})
    if not isinstance(value, dict):
        value = {}
    value.setdefault("format", "qah-plugin-sentinel-watches")
    value.setdefault("version", 1)
    value.setdefault("interval", 5)
    value.setdefault("watches", [])
    return value


def _save(data: Dict[str, Any]) -> None:
    core.save_json(watches_file(), data)


def _key(kind: str, path: Path) -> str:
    return f"{kind}:{path.resolve()}"


def _upsert(kind: str, path: Path, label: Optional[str] = None) -> Dict[str, Any]:
    path = Path(path).expanduser()
    try:
        path = path.resolve()
    except OSError:
        pass
    data = _load()
    key = _key(kind, path)
    digest = ""
    status = "waiting"
    if path.exists():
        try:
            digest = core.digest_path(path)
            status = "ok"
        except Exception:
            status = "error"
    watch = next((item for item in data["watches"] if item.get("key") == key), None)
    if watch is None:
        watch = {"key": key, "type": kind, "path": str(path)}
        data["watches"].append(watch)
    watch.update({
        "label": label or path.name,
        "digest": digest,
        "current": digest,
        "status": status,
        "last_check": time.strftime("%Y-%m-%d %H:%M:%S"),
    })
    _save(data)
    return dict(watch)


def watch_path(path: Path, kind: str = "plugin", label: Optional[str] = None) -> Dict[str, Any]:
    return _upsert(kind, Path(path), label)


def watch_plugin(plugin_id_or_path) -> Dict[str, Any]:
    text = str(plugin_id_or_path)
    candidate = Path(text).expanduser()
    if candidate.exists():
        return _upsert("plugin", candidate, candidate.name)
    for target in core.find_targets():
        if target.plugin_id == text or target.label == text:
            return _upsert("plugin", target.path, target.name or target.label)
    raise ValueError(f"Plugin not found: {text}")


def watch_library(path: Path) -> Dict[str, Any]:
    return _upsert("library", Path(path), Path(path).name)


def watch_execution(label: str, path: Path) -> Dict[str, Any]:
    """Watch an output/executable path produced by another plugin's execution."""
    return _upsert("execution", Path(path), label or Path(path).name)


def list_watches() -> List[Dict[str, Any]]:
    return list(_load().get("watches", []))


def remove_watch(key_or_path: str) -> bool:
    text = str(key_or_path)
    data = _load()
    before = len(data["watches"])
    data["watches"] = [
        item for item in data["watches"]
        if item.get("key") != text and item.get("path") != text
    ]
    _save(data)
    return len(data["watches"]) != before


def subscribe(callback: Callable[[Dict[str, Any]], None]) -> None:
    if callback not in _CALLBACKS:
        _CALLBACKS.append(callback)


def unsubscribe(callback: Callable[[Dict[str, Any]], None]) -> None:
    if callback in _CALLBACKS:
        _CALLBACKS.remove(callback)


def _emit(update: Dict[str, Any]) -> None:
    for callback in list(_CALLBACKS):
        try:
            callback(dict(update))
        except Exception:
            pass


def check_watch(key_or_path: str) -> Dict[str, Any]:
    text = str(key_or_path)
    data = _load()
    watch = next(
        (item for item in data["watches"]
         if item.get("key") == text or item.get("path") == text),
        None,
    )
    if watch is None:
        raise ValueError(f"No watch for {key_or_path}")
    path = Path(watch.get("path", ""))
    if not path.exists():
        update = {
            "key": watch["key"], "status": "missing", "current": "",
            "time": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
    else:
        try:
            current = core.digest_path(path)
            status = "ok" if current == watch.get("digest") else "changed"
            update = {
                "key": watch["key"], "status": status, "current": current,
                "time": time.strftime("%Y-%m-%d %H:%M:%S"),
            }
        except Exception as exc:
            update = {
                "key": watch["key"], "status": "error", "current": "",
                "error": str(exc), "time": time.strftime("%Y-%m-%d %H:%M:%S"),
            }
    watch.update({
        "status": update["status"],
        "current": update.get("current", ""),
        "last_check": update["time"],
    })
    _save(data)
    if update["status"] in ("changed", "missing", "error"):
        try:
            events_file().parent.mkdir(parents=True, exist_ok=True)
            with open(events_file(), "a", encoding="utf-8") as handle:
                handle.write(json.dumps(update, ensure_ascii=False) + "\n")
        except Exception:
            pass
        _emit(update)
    return update


def poll() -> List[Dict[str, Any]]:
    updates = []
    for watch in list_watches():
        try:
            updates.append(check_watch(watch["key"]))
        except Exception:
            continue
    return updates
