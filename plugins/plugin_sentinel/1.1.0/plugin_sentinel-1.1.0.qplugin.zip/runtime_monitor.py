"""Live runtime monitor (htop-style) for Plugin Sentinel."""

from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QProgressBar,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

try:
    import psutil  # type: ignore
except Exception:
    psutil = None


class RuntimeTab(QWidget):
    COLUMNS = ("PID", "Process", "CPU %", "Memory MB", "Threads", "Status", "User")

    def __init__(self, parent=None):
        super().__init__(parent)
        self._timer = QTimer(self)
        self._timer.setInterval(1000)
        self._timer.timeout.connect(self.refresh)
        self._last_net = None
        self._build_ui()
        self.refresh()
        self._timer.start()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(6)

        top = QHBoxLayout()
        self.cpu_label = QLabel("CPU —")
        self.cpu_bar = QProgressBar()
        self.cpu_bar.setRange(0, 100)
        self.cpu_bar.setMaximumWidth(180)
        self.mem_label = QLabel("Memory —")
        self.mem_bar = QProgressBar()
        self.mem_bar.setRange(0, 100)
        self.mem_bar.setMaximumWidth(180)
        self.disk_label = QLabel("Disk —")
        self.net_label = QLabel("Net —")
        for widget in (self.cpu_label, self.cpu_bar, self.mem_label, self.mem_bar, self.disk_label, self.net_label):
            top.addWidget(widget)
        top.addStretch(1)
        self.sort_combo = QComboBox()
        self.sort_combo.addItems(["Sort: CPU", "Sort: memory", "Sort: PID"])
        self.sort_combo.currentTextChanged.connect(lambda _text: self.refresh())
        top.addWidget(self.sort_combo)
        self.qah_only = QCheckBox("QAH process tree")
        self.qah_only.setToolTip("Show only QAH and its child processes")
        self.qah_only.toggled.connect(lambda _checked: self.refresh())
        top.addWidget(self.qah_only)
        refresh = QPushButton("Refresh")
        refresh.clicked.connect(lambda _checked=False: self.refresh())
        top.addWidget(refresh)
        layout.addLayout(top)

        if psutil is None:
            note = QLabel(
                "psutil is not available. Showing a reduced process table; install "
                "psutil for live per-process CPU and memory."
            )
            note.setWordWrap(True)
            note.setStyleSheet("color:#b45309;")
            layout.addWidget(note)

        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(list(self.COLUMNS))
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.table, 1)
        self.status = QLabel("Live view · updates every second")
        self.status.setStyleSheet("color:#6b7280;")
        layout.addWidget(self.status)

    def _system_metrics(self):
        if psutil is not None:
            cpu = psutil.cpu_percent(interval=None)
            memory = psutil.virtual_memory()
            disk = shutil.disk_usage(str(Path.home()))
            net = psutil.net_io_counters()
            return cpu, memory.percent, f"{disk.used / (1024**3):.1f}/{disk.total / (1024**3):.1f} GB", net
        cpu = 0.0
        memory_percent = 0.0
        try:
            import ctypes

            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.c_ulong),
                    ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong),
                    ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
                ]

            status = MEMORYSTATUSEX()
            status.dwLength = ctypes.sizeof(status)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status))
            memory_percent = float(status.dwMemoryLoad)
        except Exception:
            pass
        disk = shutil.disk_usage(str(Path.home()))
        return cpu, memory_percent, f"{disk.used / (1024**3):.1f}/{disk.total / (1024**3):.1f} GB", None

    def _qah_tree(self):
        if psutil is None:
            return None
        try:
            root = psutil.Process(os.getpid())
            return {root.pid} | {child.pid for child in root.children(recursive=True)}
        except Exception:
            return {os.getpid()}

    def _process_rows(self):
        rows = []
        qah_tree = self._qah_tree()
        if psutil is not None:
            for pid in psutil.pids():
                try:
                    process = psutil.Process(pid)
                    with process.oneshot():
                        cpu = process.cpu_percent(interval=None)
                        memory = process.memory_info().rss / (1024**2)
                        threads = process.num_threads()
                        name = process.name()
                        status = process.status()
                        try:
                            user = process.username()
                        except Exception:
                            user = ""
                    rows.append((pid, name, cpu, memory, threads, status, user))
                except Exception:
                    continue
        else:
            rows = self._fallback_process_rows()
        if qah_tree and self.qah_only.isChecked() is False:
            pass
        elif qah_tree and self.qah_only.isChecked():
            rows = [row for row in rows if row[0] in qah_tree]
        sort_key = self.sort_combo.currentText()
        if sort_key == "Sort: memory":
            rows.sort(key=lambda row: row[3], reverse=True)
        elif sort_key == "Sort: PID":
            rows.sort(key=lambda row: row[0])
        else:
            rows.sort(key=lambda row: row[2], reverse=True)
        return rows[:80], qah_tree or set()

    def _fallback_process_rows(self):
        rows = []
        try:
            if os.name == "nt":
                output = subprocess.check_output(
                    ["tasklist", "/FO", "CSV", "/NH"],
                    text=True,
                    errors="replace",
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
                import csv
                import io

                for row in csv.reader(io.StringIO(output)):
                    if len(row) < 5:
                        continue
                    try:
                        pid = int(row[1])
                    except ValueError:
                        continue
                    memory_text = row[4].replace(" K", "").replace(",", "").strip()
                    memory_mb = 0.0
                    try:
                        memory_mb = float(memory_text) / 1024
                    except ValueError:
                        pass
                    rows.append((pid, row[0], 0.0, memory_mb, 0, row[2], ""))
            else:
                output = subprocess.check_output(
                    ["ps", "-eo", "pid=,comm=,%cpu=,%mem=,rss=,stat=,user="],
                    text=True,
                    errors="replace",
                )
                for line in output.splitlines():
                    parts = line.split(None, 6)
                    if len(parts) < 7:
                        continue
                    try:
                        rows.append((int(parts[0]), parts[1], float(parts[2]), float(parts[4]) / 1024, 0, parts[5], parts[6]))
                    except ValueError:
                        continue
        except Exception:
            pass
        return rows

    def refresh(self):
        cpu, memory, disk, net = self._system_metrics()
        self.cpu_label.setText(f"CPU {cpu:.1f}%")
        self.cpu_bar.setValue(int(cpu))
        self.mem_label.setText(f"Memory {memory:.1f}%")
        self.mem_bar.setValue(int(memory))
        self.disk_label.setText(f"Disk {disk}")
        if net is not None:
            if self._last_net is None:
                self.net_label.setText("Net —")
            else:
                sent = (net.bytes_sent - self._last_net.bytes_sent) / 1024
                recv = (net.bytes_recv - self._last_net.bytes_recv) / 1024
                self.net_label.setText(f"Net ↓{recv:.0f} KB/s ↑{sent:.0f} KB/s")
            self._last_net = net
        rows, qah_tree = self._process_rows()
        self.table.setRowCount(0)
        for row in rows:
            index = self.table.rowCount()
            self.table.insertRow(index)
            values = [str(row[0]), row[1], f"{row[2]:.1f}", f"{row[3]:.1f}", str(row[4]), row[5], row[6]]
            for col, value in enumerate(values):
                item = QTableWidgetItem(value)
                if row[0] == os.getpid():
                    item.setBackground(QColor("#dbeafe"))
                    item.setToolTip("Plugin Sentinel / QAH process")
                self.table.setItem(index, col, item)
        self.status.setText(f"Live view · {len(rows)} process(es) · QAH PID {os.getpid()}")

    def cleanup(self):
        self._timer.stop()
