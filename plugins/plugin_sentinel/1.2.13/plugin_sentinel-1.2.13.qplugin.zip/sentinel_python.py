"""Locate a real Python interpreter for isolated Sentinel child processes.

QAH ships as a frozen launcher. Inside QAH, ``sys.executable`` points at the
QAH executable, so launching ``sys.executable addon_host.py`` starts another
QAH instance instead of a Python script. This module probes real interpreters
and returns one that can execute Sentinel's standalone child harnesses.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

_PROBE = (
    "import json,sys;"
    "print(json.dumps({'version':sys.version.split()[0],"
    "'executable':sys.executable,'prefix':sys.prefix,"
    "'base_prefix':sys.base_prefix,"
    "'path':[p for p in sys.path if p]}))"
)

_CACHE: Optional[Dict[str, Any]] = None
_CACHE_AT = 0.0
_CACHE_TTL = 60.0
_QAH_CACHE: Dict[str, Optional[Dict[str, Any]]] = {}

# Persisted GUI setting for the sandbox/addon interpreter. The environment
# variables remain supported and act as an override for portable deployments.
SETTING_FILE = "python.json"


def settings_path() -> Path:
    override = os.environ.get("QAH_PLUGIN_SENTINEL_HOME")
    root = (
        Path(override).expanduser()
        if override
        else Path.home() / "QAH" / "plugin_sentinel"
    )
    return root / SETTING_FILE


def load_python_setting() -> str:
    """Return the interpreter path configured in the Sentinel GUI, if any."""
    try:
        data = json.loads(settings_path().read_text(encoding="utf-8"))
    except Exception:
        return ""
    if not isinstance(data, dict):
        return ""
    return str(data.get("sandbox_python") or "").strip()


def save_python_setting(path: "os.PathLike[str] | str | None") -> None:
    """Persist the GUI interpreter choice and invalidate probe caches."""
    value = str(path or "").strip()
    target = settings_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "format": 1,
        "sandbox_python": value,
        "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    target.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    reset_cache()


def reset_cache() -> None:
    global _CACHE, _CACHE_AT
    _CACHE = None
    _CACHE_AT = 0.0
    _QAH_CACHE.clear()
    _QAH_ERROR.clear()


def _creationflags() -> int:
    if os.name == "nt":
        return int(getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return 0


def _probe(command: List[str]) -> Optional[Dict[str, Any]]:
    try:
        completed = subprocess.run(
            command + ["-I", "-c", _PROBE],
            capture_output=True,
            text=True,
            timeout=8,
            creationflags=_creationflags(),
        )
    except Exception:
        return None
    if completed.returncode != 0:
        return None
    lines = [line.strip() for line in completed.stdout.splitlines() if line.strip()]
    if not lines:
        return None
    try:
        info = json.loads(lines[-1])
    except Exception:
        return None
    version = str(info.get("version") or "")
    if not re.match(r"^\d+\.\d+", version):
        return None
    try:
        major, minor = (int(part) for part in version.split(".")[:2])
    except Exception:
        return None
    if (major, minor) < (3, 7):
        return None
    paths = [str(item) for item in (info.get("path") or []) if str(item)]
    executable = str(info.get("executable") or "")
    if not executable:
        return None
    return {
        "command": list(command),
        "version": version,
        "executable": executable,
        "prefix": str(info.get("prefix") or ""),
        "base_prefix": str(info.get("base_prefix") or ""),
        "paths": paths,
    }


def _looks_like_python(path: Path) -> bool:
    name = path.name.lower()
    return name.startswith("python") or name in ("py.exe", "py")


def _candidates() -> List[List[str]]:
    candidates: List[List[str]] = []
    configured = load_python_setting()
    if configured:
        candidates.append([configured])
    override = (
        os.environ.get("QAH_SENTINEL_PYTHON")
        or os.environ.get("QAH_PYTHON")
        or ""
    ).strip()
    if override and [override] not in candidates:
        candidates.append([override])
    for name in ("python3", "python"):
        found = shutil.which(name)
        if found:
            candidates.append([found])
    if os.name == "nt":
        py = shutil.which("py")
        if py:
            candidates.append([py, "-3"])
    if sys.executable and Path(sys.executable).exists():
        # In a frozen QAH this is the QAH launcher, not Python. Never probe it.
        if not getattr(sys, "frozen", False) and _looks_like_python(Path(sys.executable)):
            candidates.append([sys.executable])
    return candidates


def find_python(refresh: bool = False) -> Optional[Dict[str, Any]]:
    """Return a usable Python interpreter, or ``None``.

    The result is cached briefly so repeated addon or sandbox runs do not probe
    the system every time. Set ``refresh=True`` to force a new search.
    """
    global _CACHE, _CACHE_AT
    now = time.monotonic()
    if not refresh and _CACHE_AT and now - _CACHE_AT < _CACHE_TTL:
        return _CACHE
    _CACHE_AT = now
    _CACHE = None
    seen = set()
    for command in _candidates():
        key = tuple(command)
        if key in seen:
            continue
        seen.add(key)
        probe = _probe(command)
        if probe:
            _CACHE = probe
            return probe
    return None


def interpreter_summary(info: Optional[Dict[str, Any]] = None) -> str:
    info = info if info is not None else find_python()
    if not info:
        return "no Python interpreter found"
    return f"Python {info['version']} ({info['executable']})"


_QAH_ERROR: Dict[str, str] = {}


def _qah_probe_code(app: Path, packages: Path) -> str:
    # ``os.add_dll_directory`` exists only on Windows; calling it
    # unconditionally made the probe fail on Linux and macOS, which reported
    # "No python interpreter compatible with QAH's PySide6 was found" even
    # for a perfectly valid interpreter.
    return (
        "import os,sys;"
        f"app={str(app)!r};pkg={str(packages)!r};"
        "sys.path.insert(0,pkg);sys.path.insert(0,app);"
        "add=getattr(os,'add_dll_directory',None);"
        "add and add(app);add and add(pkg);"
        "sys.addaudithook(lambda e,v: (_ for _ in ()).throw(PermissionError(e))"
        " if e in ('ctypes.dlopen','ctypes.dlsym') else None);"
        "import PySide6;from PySide6 import QtCore;"
        "print(PySide6.__version__,QtCore.__version__)"
    )


def _probe_qah(command: List[str], app: Path, packages: Path) -> tuple[bool, str]:
    code = _qah_probe_code(app, packages)
    try:
        completed = subprocess.run(
            command + ["-I", "-c", code],
            capture_output=True,
            text=True,
            timeout=12,
            creationflags=_creationflags(),
        )
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"
    if completed.returncode == 0:
        return True, (completed.stdout or "").strip()
    lines = [
        line.strip()
        for line in ((completed.stderr or "") + "\n" + (completed.stdout or "")).splitlines()
        if line.strip()
    ]
    detail = lines[-1] if lines else f"exit code {completed.returncode}"
    return False, detail[:300]


def describe_interpreter(
    path: "os.PathLike[str] | str",
    qah_app: Optional[os.PathLike | str] = None,
) -> Dict[str, Any]:
    """Probe one interpreter for the GUI and report version/PySide6 status."""
    value = str(path or "").strip()
    result: Dict[str, Any] = {
        "path": value,
        "ok": False,
        "version": "",
        "executable": "",
        "pyside6": "",
        "detail": "",
    }
    if not value:
        result["detail"] = "No interpreter path set."
        return result
    base = _probe([value])
    if not base:
        result["detail"] = "Not an executable Python 3.7+."
        return result
    result["version"] = base["version"]
    result["executable"] = base["executable"]
    if not qah_app:
        result["ok"] = True
        return result
    app = Path(qah_app).expanduser().resolve()
    packages = app / "app_packages"
    if not packages.is_dir():
        result["ok"] = True
        result["detail"] = "QAH app_packages not found; PySide6 was not checked."
        return result
    ok, detail = _probe_qah([value], app, packages)
    result["ok"] = ok
    if ok:
        result["pyside6"] = detail
    else:
        result["detail"] = detail
    return result


def qah_python_error(qah_app: Optional[os.PathLike | str] = None) -> str:
    if not qah_app:
        return ""
    key = str(Path(qah_app).expanduser().resolve())
    return _QAH_ERROR.get(key, "")


def find_qah_python(
    qah_app: Optional[os.PathLike | str] = None,
    refresh: bool = False,
) -> Optional[Dict[str, Any]]:
    """Find an interpreter that can load QAH's bundled PySide6.

    A random Python on PATH (for example Anaconda) may be ABI-incompatible with
    QAH's PySide6 build. The sandbox needs the QAH bundle, so probe candidates
    by importing PySide6 from ``<qah_app>/app_packages`` before selecting one.
    The GUI setting is tried first, then ``QAH_SENTINEL_PYTHON``/``QAH_PYTHON``,
    then ``python3``/``python`` and the Windows ``py -3`` launcher.
    """
    if not qah_app:
        return find_python(refresh=refresh)
    app = Path(qah_app).expanduser().resolve()
    packages = app / "app_packages"
    if not packages.is_dir():
        return find_python(refresh=refresh)
    key = str(app)
    if not refresh and key in _QAH_CACHE:
        return _QAH_CACHE[key]
    errors: List[str] = []
    seen = set()
    for command in _candidates():
        marker = tuple(command)
        if marker in seen:
            continue
        seen.add(marker)
        base = _probe(command)
        if not base:
            continue
        ok, detail = _probe_qah(command, app, packages)
        if ok:
            _QAH_CACHE[key] = base
            _QAH_ERROR.pop(key, None)
            return base
        errors.append(f"{Path(command[0]).name}: {detail}")
    _QAH_CACHE[key] = None
    _QAH_ERROR[key] = "; ".join(errors[-4:])
    return None

