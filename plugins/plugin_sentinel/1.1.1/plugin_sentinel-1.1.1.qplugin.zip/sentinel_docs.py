"""Offline documentation HTML for Plugin Sentinel."""

from __future__ import annotations

DOCS_HTML = """
<html><head><style>
body{font-family:'Segoe UI',Arial,sans-serif;font-size:10pt;color:#1f2937}
h1{font-size:17pt;color:#0f172a}h2{font-size:12.5pt;color:#1d4ed8;margin-top:16px}
h3{font-size:11pt;color:#111827;margin-top:12px}
code{background:#f3f4f6;padding:1px 3px}pre{background:#f3f4f6;padding:8px;border:1px solid #e5e7eb}
.warn{color:#b91c1c;font-weight:bold}.muted{color:#6b7280}
</style></head><body>
<h1>Plugin Sentinel Documentation</h1>
<p class="muted">Advanced audit, native inspection, watchdog API, runtime monitor and process sandbox.</p>

<h2>1. What Sentinel protects</h2>
<ul>
<li>User, system and wheel plugin inventories, including nested user-plugin folders.</li>
<li>Manifest, archive, static and dependency checks from QAH's plugin audit library.</li>
<li>Native DLL/SO/dylib headers, imports, hardening flags, entropy and signatures.</li>
<li>Trusted SHA256 baselines and drift detection.</li>
<li>Policy gates with capability allowlists and risk thresholds.</li>
</ul>
<p class="warn">Sentinel is report-and-gate only. It never unloads, disables, deletes or blocks a plugin.
System plugins are owned by the QAH installer and are protected from marketplace shadowing.</p>

<h2>2. External watchdog API</h2>
<p>Other QAH plugins can register watches while Plugin Sentinel is installed:</p>
<pre>from plugin_sentinel import sentinel_api

# Watch a plugin, native library or execution output path
sentinel_api.watch_plugin("my_plugin")
sentinel_api.watch_library(r"C:\\path\\native.dll")
sentinel_api.watch_execution("simulation output", r"C:\\path\\out.log")

# List, remove and check
sentinel_api.list_watches()
sentinel_api.check_watch("plugin:C:/.../my_plugin")
sentinel_api.remove_watch("plugin:C:/.../my_plugin")</pre>

<h3>Change callbacks</h3>
<pre>def on_change(event):
    print("watchdog:", event)

sentinel_api.subscribe(on_change)

# Call periodically from your plugin's QTimer/thread
sentinel_api.poll()</pre>
<p>Callbacks are in-process and only fire while both plugins are loaded. The
watch definitions are shared with the Watchdog tab through
<code>%USERPROFILE%\\QAH\\plugin_sentinel\\watches.json</code>. Cross-process
consumers can read <code>events.jsonl</code> in the same folder.</p>

<h3>Execution watches</h3>
<p><code>watch_execution(label, path)</code> is a path watchdog for an output,
log, script or executable produced by another plugin's execution. It detects
content changes; it is not a process supervisor and does not intercept or kill
processes.</p>

<h2>3. Watchdog tab</h2>
<p>Watch plugin folders and native libraries, choose an interval, run a check
now, or pin the current hash to accept a change. Statuses: <b>ok</b>,
<b>changed</b>, <b>missing</b>, <b>error</b>.</p>

<h2>4. Native inspection</h2>
<p>Sentinel parses PE, ELF and Mach-O headers without loading the library. It
reports architecture, imports, entropy, signed/unsigned state, ASLR/NX/CFG,
TLS callbacks, writable+executable sections, executable stack and RPATH.</p>

<h2>5. Runtime tab</h2>
<p>htop-style CPU/memory/disk/network gauges and a process table. <code>psutil</code>
is used when available; otherwise Sentinel falls back to <code>ps</code> or
<code>tasklist</code>, so it does not require psutil.</p>

<h2>6. Sandbox</h2>
<p>The sandbox runs plugin code in a separate process with Python audit hooks,
a temporary workspace, blocked network/subprocess/ctypes and write restrictions,
POSIX rlimits or a Windows Job Object, and a hard timeout.</p>
<p class="warn">This is a containment harness, not a hypervisor or an OS security
boundary. Native escapes and kernel-level behaviour cannot be fully contained by
an in-process Python sandbox. Use a VM/container when you need a hard boundary.</p>

<h2>7. Health Guard integration</h2>
<p>The headless <b>Plugin Health Guard</b> writes:</p>
<pre>%USERPROFILE%\\QAH\\plugin_health_guard\\health.json</pre>
<p>Sentinel's <b>Health</b> tab reads that report, shows manifest/duplicate/backup
issues and can trigger a new Health Guard check when the plugin is loaded.
Other plugins can read it directly:</p>
<pre>from plugin_health_guard import health_api
summary = health_api.summary()</pre>

<h2>8. Runtime executions</h2>
<p>The <b>Runtime → Plugin Executions</b> subtab lists QAH plugins, their source
(user/system/wheel), loaded state and QAH PID. It can ask QAH's PluginManager to
unload a selected <b>user</b> plugin. System and wheel plugins are protected.
This is an unload, not a hard process kill; background threads that ignore cleanup
may keep running.</p>

<h2>9. System plugin protection</h2>
<p>Sentinel and the Git Marketplace protect system and wheel plugins:</p>
<ul>
<li>Sentinel only reports findings; it has no uninstall/disable action.</li>
<li>The marketplace disables update/version-install for non-user plugins.</li>
<li>“Update all” skips system and wheel plugins.</li>
<li>System plugins remain owned by the QAH installer.</li>
</ul>

<h2>10. Linux and macOS</h2>
<ul>
<li>User plugin discovery uses QAH's platform paths when available.</li>
<li>Native inspection supports ELF and Mach-O.</li>
<li>Runtime falls back to <code>ps</code>.</li>
<li>Sandbox uses POSIX rlimits and <code>killpg</code>.</li>
<li>Reports and watch paths use <code>Path.home()</code>; no Windows-only path is required.</li>
</ul>

<h2>11. CLI</h2>
<pre>python sentinel_cli.py --all --format text
python sentinel_cli.py C:\\path\\plugin.qplugin.zip --fail-on high --max-risk 50
python sentinel_cli.py --all --format json --output sentinel-report.json</pre>
<p>Exit code 1 means at least one BLOCK verdict; 0 means no blocks; 2 means no
targets/CLI error.</p>

</body></html>
"""
