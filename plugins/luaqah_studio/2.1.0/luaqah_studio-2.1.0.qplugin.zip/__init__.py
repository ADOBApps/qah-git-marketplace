# luaqah_studio/__init__.py
"""
LuaQAH Studio - Professional Visual Programming Studio for Lua
A QAH plugin for building Lua programs from connected visual blocks.

This file is part of Quantum Analysis Helper.
Quantum Analysis Helper is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Quantum Analysis Helper is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

from __future__ import annotations

import importlib
import importlib.util
import logging
import sys
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QObject
from PySide6.QtGui import QAction, QIcon
from PySide6.QtWidgets import QWidget

try:
    from plugins.libs.plugin_manager import PluginInfo
except Exception:  # other QAH builds may use a different module layout
    PluginInfo = object  # type: ignore

__version__ = "2.1.0"
_PLUGIN_ID = "luaqah_studio"


def _load_sibling(name: str):
    """Import a helper module in both package and classic-plugin loading modes."""
    try:
        return importlib.import_module(f"{__name__}.{name}")
    except ImportError:
        path = Path(__file__).parent / f"{name}.py"
        spec = importlib.util.spec_from_file_location(f"{__name__}_{name}", path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        return module


class LuaQAHStudio(QObject):
    """Main plugin class for LuaQAH Studio."""

    def __init__(self, plugin_info: PluginInfo):
        super().__init__()
        self.plugin_info = plugin_info
        self.ui_widget: Optional[QWidget] = None
        self.icon: Optional[QIcon] = None

        plugin_dir = Path(__file__).parent
        for name in ("icon.svg", "icon.png"):
            icon_path = plugin_dir / name
            if icon_path.is_file():
                self.icon = QIcon(str(icon_path))
                break

    def initialize(self) -> bool:
        try:
            logging.info(
                "Initializing %s version: %s",
                self.plugin_info.name,
                self.plugin_info.version,
            )
            return True
        except Exception as exc:
            logging.error("Failed to initialize LuaQAH Studio: %s", exc)
            return False

    def get_widget(self) -> Optional[QWidget]:
        if self.ui_widget is None:
            try:
                ui = _load_sibling("plugin_ui")
                self.ui_widget = ui.LuaQAHStudioWidget(self)
            except Exception as exc:
                logging.error("Failed to initialize widget: %s", exc)
                logging.debug("Traceback", exc_info=True)
                return None
        return self.ui_widget

    def get_menu_action(self):
        action = QAction(self.plugin_info.name, None)
        if self.icon is not None:
            action.setIcon(self.icon)
        action.setToolTip("Open the visual Lua block editor")
        return action

    def get_menu_actions(self):
        return [self.get_menu_action()]

    def open_editor(self):
        return self.get_widget()

    def cleanup(self):
        if self.ui_widget is not None:
            try:
                if hasattr(self.ui_widget, "cleanup"):
                    self.ui_widget.cleanup()
            finally:
                self.ui_widget.deleteLater()
                self.ui_widget = None


Plugin = LuaQAHStudio

# Backwards-compatible alias for older imports.
DragDropLuaBlocks = LuaQAHStudio
