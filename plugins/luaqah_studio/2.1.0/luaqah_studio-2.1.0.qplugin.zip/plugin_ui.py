"""
LuaQAH Studio - Main UI Widget
Updated with Lua/LuaJIT selection and file save improvements
"""

import json
import time
import re
import tempfile
from datetime import datetime
from pathlib import Path
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox,
    QPushButton, QLabel, QLineEdit, QFileDialog,
    QComboBox, QTextEdit, QSplitter, QProgressBar,
    QTabWidget, QMessageBox, QListWidget, QListWidgetItem,
    QToolBox, QDialog, QFormLayout, QSpinBox, QCheckBox,
    QDialogButtonBox, QStyle, QApplication, QMenu, QFrame
)
from PySide6.QtGui import (
    QFont, QIcon, QTextCursor, QAction, QShortcut, QKeySequence, QPalette, QColor
)
from PySide6.QtCore import Qt, Signal, Slot, QTimer

from .block_components import (
    BlockScene, BlockProgrammingView, BlockLibraryWidget,
    CodePreviewWidget
)

from .enhanced_terminal import EnhancedLuaTerminal


class EngineSettingsDialog(QDialog):
    """Dialog for Lua engine settings"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Lua Engine Settings")
        self.setModal(True)
        self.settings = {}
        
        self._setup_ui()
    
    def _setup_ui(self):
        """Setup dialog UI"""
        layout = QVBoxLayout(self)
        
        form_layout = QFormLayout()
        
        # Only Lua option
        self.engine_combo = QComboBox()
        self.engine_combo.addItems(["Lua"])
        self.engine_combo.setCurrentText("Lua")
        self.engine_combo.setEnabled(False)
        form_layout.addRow("Execution Engine:", self.engine_combo)
        
        # Memory limit
        self.memory_spin = QSpinBox()
        self.memory_spin.setRange(1, 1024)
        self.memory_spin.setValue(256)
        self.memory_spin.setSuffix(" MB")
        form_layout.addRow("Memory Limit:", self.memory_spin)
        
        # Debug mode
        self.debug_checkbox = QCheckBox("Enable debug mode")
        self.debug_checkbox.setChecked(False)
        form_layout.addRow("", self.debug_checkbox)
        
        layout.addLayout(form_layout)
        
        # Buttons
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
    
    def get_settings(self):
        """Get settings from dialog"""
        return {
            'engine': 'lua',
            'memory_limit': self.memory_spin.value(),
            'enable_jit': False,
            'debug_mode': self.debug_checkbox.isChecked()
        }


class LuaQAHStudioWidget(QWidget):
    """Main widget for drag-and-drop Lua block programming"""
    
    def __init__(self, plugin_instance=None):
        super().__init__()
        self.plugin = plugin_instance
        self.current_file = None
        self.blocks = []
        self.connections = []
        self.engine_settings = {
            'engine': 'lua',
            'memory_limit': 256,
            'enable_jit': False,
            'debug_mode': False
        }
        self.is_dirty = False
        self._undo_stack = []
        self._redo_stack = []
        self._restoring = False
        self._last_dir = Path.home()
        self.setAcceptDrops(True)

        self._setup_ui()
        self._connect_signals()
        self._install_shortcuts()
        self._set_dirty(False)

        if plugin_instance and getattr(plugin_instance, 'icon', None):
            self.setWindowIcon(plugin_instance.icon)
    
    def _setup_ui(self):
        """Setup the user interface."""
        palette = QApplication.palette()
        text_color = palette.color(QPalette.Text).name()
        muted_color = palette.color(QPalette.PlaceholderText).name()
        accent_color = palette.color(QPalette.Highlight).name()

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(12, 12, 12, 12)
        main_layout.setSpacing(8)

        # Title bar with engine indicator.
        title_layout = QHBoxLayout()
        title_block = QVBoxLayout()
        title_block.setSpacing(0)
        title_label = QLabel("LuaQAH Studio")
        title_font = QFont("Arial", 17, QFont.Weight.Bold)
        title_label.setFont(title_font)
        title_label.setStyleSheet(f"color: {text_color};")
        title_block.addWidget(title_label)
        subtitle = QLabel("Visual programming for Lua  ·  drag, connect, generate, run")
        subtitle.setStyleSheet(f"color: {muted_color}; font-size: 11px;")
        title_block.addWidget(subtitle)
        title_layout.addLayout(title_block)

        # Engine indicator.
        self.engine_label = QLabel("Engine: Lua")
        self.engine_label.setStyleSheet(
            f"color: {accent_color}; font-weight: bold; padding-left: 12px;"
        )
        title_layout.addWidget(self.engine_label)
        title_layout.addStretch()

        # Dirty/status indicator.
        self.status_indicator = QLabel("●")
        self.status_indicator.setStyleSheet(f"color: {accent_color}; font-size: 22px;")
        self.status_indicator.setToolTip("Canvas state")
        title_layout.addWidget(self.status_indicator)
        main_layout.addLayout(title_layout)
        
        # Control toolbar.
        toolbar_layout = QHBoxLayout()
        toolbar_layout.setSpacing(4)

        def toolbar_separator():
            line = QFrame()
            line.setFrameShape(QFrame.VLine)
            line.setFrameShadow(QFrame.Sunken)
            toolbar_layout.addWidget(line)

        # File operations.
        self.new_btn = QPushButton("New")
        self.new_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_FileIcon))
        self.new_btn.setToolTip("New project (Ctrl+N)")
        self.open_btn = QPushButton("Open")
        self.open_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_DirOpenIcon))
        self.open_btn.setToolTip("Open project (Ctrl+O)")
        self.save_btn = QPushButton("Save")
        self.save_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_DialogSaveButton))
        self.save_btn.setToolTip("Save project (Ctrl+S)")
        self.save_as_btn = QPushButton("Save As")
        self.save_as_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_DriveHDIcon))
        self.save_as_btn.setToolTip("Save project as... (Ctrl+Shift+S)")

        # Undo/redo.
        self.undo_btn = QPushButton("Undo")
        self.undo_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_ArrowBack))
        self.undo_btn.setToolTip("Undo (Ctrl+Z)")
        self.redo_btn = QPushButton("Redo")
        self.redo_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_ArrowForward))
        self.redo_btn.setToolTip("Redo (Ctrl+Y)")

        # Code operations.
        self.generate_btn = QPushButton("Generate Code")
        self.generate_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_TitleBarMaxButton))
        self.generate_btn.setToolTip("Generate Lua from the canvas (Ctrl+G)")
        self.export_lua_btn = QPushButton("Export .lua")
        self.export_lua_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_CommandLink))
        self.export_lua_btn.setToolTip("Export the generated Lua file")

        # Engine settings.
        self.engine_btn = QPushButton("Engine")
        self.engine_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_ComputerIcon))
        self.engine_btn.setToolTip("Lua engine settings")

        # Run buttons.
        self.run_btn = QPushButton("Run")
        self.run_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_MediaPlay))
        self.run_btn.setToolTip("Generate and run the program (F5)")
        self.run_btn.clicked.connect(self._run_lua_code)

        self.run_settings_btn = QPushButton("Run Options")
        self.run_settings_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_FileDialogContentsView)
        )
        self.run_settings_btn.setToolTip("Run/debug options")
        self.run_settings_btn.clicked.connect(self._show_run_options)

        for button in (
            self.new_btn, self.open_btn, self.save_btn, self.save_as_btn,
        ):
            toolbar_layout.addWidget(button)
        toolbar_separator()
        toolbar_layout.addWidget(self.undo_btn)
        toolbar_layout.addWidget(self.redo_btn)
        toolbar_separator()
        toolbar_layout.addWidget(self.generate_btn)
        toolbar_layout.addWidget(self.export_lua_btn)
        toolbar_separator()
        toolbar_layout.addStretch(1)
        toolbar_layout.addWidget(self.engine_btn)
        toolbar_layout.addWidget(self.run_btn)
        toolbar_layout.addWidget(self.run_settings_btn)

        main_layout.addLayout(toolbar_layout)
        
        # ========== MAIN CONTENT SPLITTER ==========
        main_splitter = QSplitter(Qt.Horizontal)
        
        # ========== LEFT PANEL: Block Library ==========
        self.library_widget = BlockLibraryWidget()
        main_splitter.addWidget(self.library_widget)
        
        # ========== CENTER PANEL: Block Canvas ==========
        center_widget = QWidget()
        center_layout = QVBoxLayout(center_widget)
        center_layout.setContentsMargins(0, 0, 0, 0)
        
        # Canvas toolbar
        canvas_toolbar = QHBoxLayout()
        self.zoom_in_btn = QPushButton("Zoom In")
        self.zoom_in_btn.setToolTip("Zoom in (Ctrl++)")
        self.zoom_out_btn = QPushButton("Zoom Out")
        self.zoom_out_btn.setToolTip("Zoom out (Ctrl+-)")
        self.fit_view_btn = QPushButton("Fit View")
        self.fit_view_btn.setToolTip("Fit all blocks (Ctrl+0)")
        self.auto_arrange_btn = QPushButton("Auto Arrange")
        self.auto_arrange_btn.setToolTip("Arrange blocks in columns by type")
        self.delete_btn = QPushButton("Delete Selected")
        self.delete_btn.setIcon(QApplication.style().standardIcon(QStyle.SP_TrashIcon))
        self.delete_btn.setToolTip("Delete selected blocks (Del)")

        canvas_toolbar.addWidget(self.zoom_in_btn)
        canvas_toolbar.addWidget(self.zoom_out_btn)
        canvas_toolbar.addWidget(self.fit_view_btn)
        canvas_toolbar.addWidget(self.auto_arrange_btn)
        canvas_toolbar.addStretch()
        canvas_toolbar.addWidget(self.delete_btn)

        center_layout.addLayout(canvas_toolbar)
        
        # Block scene and view
        self.block_scene = BlockScene()
        self.block_view = BlockProgrammingView(self.block_scene)
        center_layout.addWidget(self.block_view)
        
        main_splitter.addWidget(center_widget)
        
        # ========== RIGHT PANEL: Terminal + Code Preview + Project Tree ==========
        self.right_tabs = QTabWidget()
        
        # Tab 1: Interactive Terminal
        terminal_tab = QWidget()
        terminal_layout = QVBoxLayout(terminal_tab)
        terminal_layout.setContentsMargins(0, 0, 0, 0)
        
        self.terminal = EnhancedLuaTerminal(parent=self, engine_type="lua")
        self.terminal.command_executed.connect(self.execute_terminal_command)
        terminal_layout.addWidget(self.terminal)
        
        self.right_tabs.addTab(terminal_tab, "Terminal")
        
        # Tab 2: Code Preview
        self.code_preview = CodePreviewWidget()
        self.right_tabs.addTab(self.code_preview, "Lua Code")
        
        # Tab 3: Project Tree
        project_tab = QWidget()
        project_layout = QVBoxLayout(project_tab)
        project_layout.setContentsMargins(4, 4, 4, 4)

        self.project_tree = QListWidget()
        self.project_tree.setAlternatingRowColors(True)
        self.project_tree.setToolTip("Double-click a block to focus it on the canvas")
        self.project_tree.itemDoubleClicked.connect(self._focus_block_from_tree)
        project_layout.addWidget(self.project_tree, 1)

        self.file_info_label = QLabel("No project loaded")
        self.file_info_label.setStyleSheet(
            f"color: {QApplication.palette().color(QPalette.PlaceholderText).name()}; "
            "font-size: 11px;"
        )
        project_layout.addWidget(self.file_info_label)

        self.right_tabs.addTab(project_tab, "Project")
        
        main_splitter.addWidget(self.right_tabs)
        
        # Set splitter sizes
        main_splitter.setSizes([290, 680, 430])
        main_layout.addWidget(main_splitter)
        
        # ========== BOTTOM PANEL: Build Output ==========
        output_group = QGroupBox("Build Output")
        output_layout = QVBoxLayout()
        
        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setMaximumHeight(120)
        output_font = QFont("Consolas", 9)
        output_font.setStyleHint(QFont.Monospace)
        self.output_text.setFont(output_font)
        output_layout.addWidget(self.output_text)
        
        output_group.setLayout(output_layout)
        main_layout.addWidget(output_group)
        
        # ========== PROGRESS BAR ==========
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        main_layout.addWidget(self.progress_bar)
        
        # ========== STATUS BAR ==========
        self.status_label = QLabel("Ready — add blocks, connect sockets, then Generate Code")
        self.status_label.setStyleSheet(
            f"color: {QApplication.palette().color(QPalette.PlaceholderText).name()}; "
            "font-style: italic;"
        )
        main_layout.addWidget(self.status_label)
    
    def create_tools_panel(self):
        """Create tools panel with enhanced terminal and output"""
        panel = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(5, 5, 5, 5)
        
        # Output console
        output_group = QGroupBox("Build Output")
        output_layout = QVBoxLayout()
        
        self.output_text_alt = QTextEdit()
        self.output_text_alt.setReadOnly(True)
        self.output_text_alt.setMaximumHeight(150)
        self.output_text_alt.setFont(QFont("Courier New", 9))
        output_layout.addWidget(self.output_text_alt)
        
        output_group.setLayout(output_layout)
        layout.addWidget(output_group)
        
        # Terminal
        console_group = QGroupBox("Interactive Terminal")
        console_layout = QVBoxLayout()
        
        self.terminal_alt = EnhancedLuaTerminal(parent=self, engine_type="lua")
        self.terminal_alt.command_executed.connect(self.execute_terminal_command)
        console_layout.addWidget(self.terminal_alt)
        
        console_group.setLayout(console_layout)
        layout.addWidget(console_group)
        
        panel.setLayout(layout)
        return panel
    
    def execute_terminal_command(self, command: str):
        """Execute command from enhanced terminal with return value capture"""
        start_time = time.time()
        
        # Use standard Lua
        bridge = None
        
        try:
            from plugins.libs.lua.lua_bridge import get_lua_bridge
            bridge = get_lua_bridge()
        except ImportError as e:
            print(f"Lua bridge import error: {e}")
            self.terminal.append_error("No Lua engine available!")
            return
        
        try:
            lua_state = bridge.init()
            if not lua_state:
                self.terminal.append_error("Failed to initialize Lua state")
                return
            
            try:
                escaped_command = command.replace('\\', '\\\\').replace('`', '\\`')
                
                wrapper = f"""
                local _old_print = print
                local _output_lines = {{}}
                print = function(...)
                    local args = {{...}}
                    local line = table.concat(args, "\\t")
                    table.insert(_output_lines, line)
                    _old_print(...)
                end
                
                local _return_value = nil
                local ok, err = pcall(function()
                    local chunk = load([==[{escaped_command}]==])
                    if chunk then
                        local results = {{chunk()}}
                        if #results > 0 then
                            _return_value = results
                        end
                    end
                end)
                
                print = _old_print
                
                if not ok then
                    return false, tostring(err)
                else
                    _G["_term_output"] = _output_lines
                    _G["_term_return"] = _return_value
                    return true
                end
                """
                
                success = bridge.execute_script(lua_state, wrapper)
                
                if success:
                    bridge.execute_script(lua_state, """
                    for i, line in ipairs(_G["_term_output"] or {{}}) do
                        _G["_tline_"..i] = line
                    end
                    """)
                    
                    for i in range(1, 1000):
                        try:
                            line = bridge.get_global_string(lua_state, f"_tline_{i}")
                            if line:
                                self.terminal.append_output(line)
                            else:
                                break
                        except:
                            break
                    
                    try:
                        bridge.execute_script(lua_state, """
                        local rv = _G["_term_return"]
                        if type(rv) == 'table' then
                            local result = {}
                            for i, v in ipairs(rv) do
                                if type(v) == 'table' then
                                    result[i] = 'table'
                                elseif type(v) == 'string' then
                                    result[i] = '"' .. v .. '"'
                                else
                                    result[i] = tostring(v)
                                end
                            end
                            _term_return_str = table.concat(result, ', ')
                        else
                            _term_return_str = tostring(rv)
                        end
                        """)
                        return_val = bridge.get_global_string(lua_state, "_term_return_str")
                        if return_val and return_val != "nil" and return_val != "":
                            self.terminal.append_return_value(return_val)
                    except:
                        pass
                    
                else:
                    error = bridge.get_last_error(lua_state)
                    line_match = re.search(r':(\d+):', error)
                    line_num = int(line_match.group(1)) if line_match else None
                    self.terminal.append_error(error, line_num)
                
                elapsed = time.time() - start_time
                self.terminal.append_timing(elapsed)
                
            finally:
                bridge.close(lua_state)
                
        except Exception as e:
            self.terminal.append_error(f"Execution error: {str(e)}")
    
    def _connect_signals(self):
        """Connect signals and slots."""
        self.new_btn.clicked.connect(self._new_project)
        self.open_btn.clicked.connect(self._open_project)
        self.save_btn.clicked.connect(self._save_project)
        self.save_as_btn.clicked.connect(self._save_as_project)
        self.undo_btn.clicked.connect(self._undo)
        self.redo_btn.clicked.connect(self._redo)

        self.generate_btn.clicked.connect(self._generate_lua_code)
        self.export_lua_btn.clicked.connect(self._export_lua_file)
        self.engine_btn.clicked.connect(self._open_engine_settings)

        self.library_widget.block_selected.connect(self._add_block_from_library)
        self.zoom_in_btn.clicked.connect(self._zoom_in)
        self.zoom_out_btn.clicked.connect(self._zoom_out)
        self.fit_view_btn.clicked.connect(self._fit_view)
        self.auto_arrange_btn.clicked.connect(self._auto_arrange)
        self.delete_btn.clicked.connect(self._delete_selected)

        self.block_scene.block_added.connect(self._on_block_added)
        self.block_scene.block_removed.connect(self._on_block_removed)
        self.block_scene.about_to_change.connect(self._on_about_to_change)
        self.block_scene.connection_created.connect(self._on_connection_created)

    def _install_shortcuts(self):
        """Install keyboard shortcuts."""
        shortcuts = [
            ("Ctrl+N", self._new_project),
            ("Ctrl+O", self._open_project),
            ("Ctrl+S", self._save_project),
            ("Ctrl+Shift+S", self._save_as_project),
            ("Ctrl+G", self._generate_lua_code),
            ("F5", self._run_lua_code),
            ("Ctrl+Z", self._undo),
            ("Ctrl+Y", self._redo),
            ("Ctrl+Shift+Z", self._redo),
            ("Ctrl++", self._zoom_in),
            ("Ctrl+=", self._zoom_in),
            ("Ctrl+-", self._zoom_out),
            ("Ctrl+0", self._fit_view),
            ("Ctrl+F", lambda: self.library_widget.search.setFocus()),
        ]
        for sequence, slot in shortcuts:
            shortcut = QShortcut(QKeySequence(sequence), self)
            shortcut.activated.connect(slot)
            setattr(self, f"_shortcut_{sequence.replace('+', '_').replace('=', 'eq')}", shortcut)
    
    def _open_engine_settings(self):
        """Open engine settings dialog"""
        dialog = EngineSettingsDialog(self)
        if dialog.exec():
            self.engine_settings = dialog.get_settings()
            engine_name = self.engine_settings['engine'].upper()
            self.engine_label.setText(f"Engine: {engine_name}")
            self._set_status(f"Engine set to {engine_name}")
    
    def _new_project(self):
        """Create a new project."""
        if self.blocks and self.is_dirty:
            reply = QMessageBox.question(
                self,
                "New Project",
                "Create a new project? Unsaved changes will be lost.",
                QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel,
                QMessageBox.Save,
            )
            if reply == QMessageBox.Cancel:
                return
            if reply == QMessageBox.Save:
                self._save_project()
                if self.is_dirty:
                    return

        self.block_scene.clear()
        self.blocks.clear()
        self.connections.clear()
        self.current_file = None
        self._undo_stack.clear()
        self._redo_stack.clear()

        if hasattr(self, 'project_tree'):
            self.project_tree.clear()
        if hasattr(self, 'code_preview'):
            self.code_preview.clear()
        if hasattr(self, 'file_info_label'):
            self.file_info_label.setText("New project")

        self._set_dirty(False)
        self._set_status("New project created")
        self.status_indicator.setStyleSheet("color: #2ecc71; font-size: 22px;")

    def _open_project(self):
        """Open a .blockproj project."""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Open Block Project",
            str(self._last_dir),
            "Block Projects (*.blockproj);;All Files (*)",
        )
        if not file_path:
            return
        self._load_project_path(file_path)

    def _load_project_path(self, file_path: str):
        """Load a project from a path (also used by drag-and-drop)."""
        try:
            with open(file_path, 'r', encoding='utf-8') as handle:
                data = json.load(handle)

            self.block_scene.deserialize(data)
            self.blocks = self.block_scene.blocks()
            self.connections.clear()

            if 'engine_settings' in data:
                self.engine_settings.update(data['engine_settings'])
                engine_name = self.engine_settings.get('engine', 'lua').upper()
                self.engine_label.setText(f"Engine: {engine_name}")

            self.current_file = Path(file_path)
            self._last_dir = self.current_file.parent
            self._undo_stack.clear()
            self._redo_stack.clear()
            self._update_undo_buttons()
            self._update_project_tree()
            self.file_info_label.setText(f"Loaded: {self.current_file.name}")
            self._set_dirty(False)
            self._set_status(f"Project loaded: {self.current_file.name}")
            self.status_indicator.setStyleSheet("color: #2ecc71; font-size: 22px;")
            QTimer.singleShot(100, self._fit_view)
            self._generate_lua_code(preview_only=True)
        except Exception as exc:
            QMessageBox.critical(self, "Error", f"Failed to load project: {exc}")

    def _save_project(self):
        """Save the project to its current file."""
        if not self.current_file:
            self._save_as_project()
        else:
            self._save_to_file(self.current_file)

    def _save_as_project(self):
        """Save the project under a new name."""
        suggested = str(self._last_dir / (
            (self.current_file.stem if self.current_file else "untitled") + ".blockproj"
        ))
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Block Project",
            suggested,
            "Block Projects (*.blockproj);;All Files (*)",
        )
        if not file_path:
            return
        if not file_path.lower().endswith(".blockproj"):
            file_path += ".blockproj"
        self.current_file = Path(file_path)
        self._last_dir = self.current_file.parent
        self._save_to_file(self.current_file)

    def _save_to_file(self, file_path: Path):
        """Serialise the scene to a project file."""
        try:
            data = self.block_scene.serialize()
            now = datetime.now().isoformat(timespec="seconds")
            data.update({
                'version': '2.0',
                'plugin_version': '2.1.0',
                'engine_settings': self.engine_settings,
                'metadata': {
                    'name': file_path.stem,
                    'modified': now,
                    'blocks_count': len(self.blocks),
                    'connections_count': len(data.get('connections', [])),
                    'engine': self.engine_settings.get('engine', 'lua'),
                },
            })
            with open(file_path, 'w', encoding='utf-8') as handle:
                json.dump(data, handle, indent=2)

            self.file_info_label.setText(f"Saved: {file_path.name}")
            self._set_dirty(False)
            self._set_status(f"Project saved: {file_path.name}")
        except Exception as exc:
            QMessageBox.critical(self, "Error", f"Failed to save project: {exc}")
    
    def _export_lua_file(self):
        """Export generated Lua code to a .lua file."""
        if not self.code_preview.toPlainText().strip():
            self._generate_lua_code(preview_only=True)
        code = self.code_preview.toPlainText()
        if not code.strip():
            QMessageBox.warning(self, "No Code", "Generate Lua code first.")
            return

        suggested = str(self._last_dir / (
            (self.current_file.stem if self.current_file else "program") + ".lua"
        ))
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Export Lua File", suggested,
            "Lua Files (*.lua);;All Files (*)"
        )
        if not file_path:
            return
        if not file_path.lower().endswith(".lua"):
            file_path += ".lua"

        try:
            with open(file_path, 'w', encoding='utf-8') as handle:
                handle.write(code)
            self._last_dir = Path(file_path).parent
            self._set_status(f"Lua code exported to: {Path(file_path).name}")
            QMessageBox.information(self, "Exported", f"Lua code exported to:\n{file_path}")
        except Exception as exc:
            QMessageBox.critical(self, "Error", f"Failed to export Lua code: {exc}")
    
    def _add_block_from_library(self, block_data: dict):
        """Add a block from the library to the canvas."""
        block = self.block_scene.add_block(dict(block_data))
        if block:
            self.blocks = self.block_scene.blocks()
            self._update_project_tree()
            self._set_dirty(True)
            self._set_status(f"Added block: {block.title}")
            self.block_view.ensureVisible(block, 80, 80)

    def _on_block_added(self, block):
        self.blocks = self.block_scene.blocks()
        self._update_project_tree()
        if not self._restoring:
            self._set_dirty(True)

    def _on_block_removed(self, block):
        self.blocks = self.block_scene.blocks()
        self._update_project_tree()
        if not self._restoring:
            self._set_dirty(True)

    def _on_connection_created(self, source, target):
        self._set_dirty(True)
        self._set_status(f"Connected {source.name} → {target.name}")

    def _update_project_tree(self):
        """Refresh the project overview list."""
        if not hasattr(self, 'project_tree'):
            return
        self.project_tree.clear()
        type_order = {
            'event': 0,
            'variable': 1,
            'function': 2,
            'control': 3,
            'operator': 4,
            'action': 5,
        }
        blocks = sorted(
            self.block_scene.blocks(),
            key=lambda b: (type_order.get(b.block_type, 9), b.y(), b.x()),
        )
        icons = {
            'event': '🚀',
            'variable': '📦',
            'function': '⚙',
            'control': '🔀',
            'operator': '∑',
            'action': '▶',
        }
        for block in blocks:
            item = QListWidgetItem(
                f"{icons.get(block.block_type, '▢')} {block.title}   #{block.block_id}"
            )
            item.setData(Qt.UserRole, block)
            item.setToolTip(f"Type: {block.block_type}\nPosition: {block.x():.0f}, {block.y():.0f}")
            self.project_tree.addItem(item)

    def _focus_block_from_tree(self, item):
        block = item.data(Qt.UserRole)
        if block is None:
            return
        self.block_scene.clearSelection()
        block.setSelected(True)
        self.block_view.centerOn(block)
        self.block_view.setFocus()

    def _zoom_in(self):
        self.block_view.scale(1.15, 1.15)
        self.block_view.current_zoom *= 1.15

    def _zoom_out(self):
        self.block_view.scale(1 / 1.15, 1 / 1.15)
        self.block_view.current_zoom /= 1.15

    def _fit_view(self):
        rect = self.block_scene.itemsBoundingRect()
        if rect.isNull() or not self.block_scene.blocks():
            self.block_view.reset_zoom()
            return
        self.block_view.fitInView(rect.adjusted(-60, -60, 60, 60), Qt.KeepAspectRatio)
        self.block_view.current_zoom = self.block_view.transform().m11()

    def _delete_selected(self):
        removed = self.block_scene.delete_selected_blocks()
        if removed:
            self.blocks = self.block_scene.blocks()
            self._update_project_tree()
            self._set_dirty(True)
            self._set_status(f"Deleted {removed} block(s)")
    
    def _auto_arrange(self):
        """Arrange blocks in columns by type and fit the view."""
        blocks = self.block_scene.blocks()
        if not blocks:
            return
        self._push_undo()
        columns = {
            'event': 0,
            'variable': 1,
            'function': 2,
            'control': 3,
            'operator': 4,
            'action': 5,
        }
        counters = {}
        for block in sorted(blocks, key=lambda b: (columns.get(b.block_type, 9), b.title)):
            column = columns.get(block.block_type, 6)
            row = counters.get(column, 0)
            counters[column] = row + 1
            block.setPos(80 + column * 300, 100 + row * 130)
        self._set_dirty(True)
        self._set_status("Blocks arranged by type")
        QTimer.singleShot(50, self._fit_view)

    # ------------------------------------------------------------------ undo
    def _snapshot(self) -> str:
        return json.dumps(self.block_scene.serialize(), sort_keys=True)

    def _on_about_to_change(self):
        if self._restoring:
            return
        self._push_undo()

    def _push_undo(self):
        snapshot = self._snapshot()
        if self._undo_stack and self._undo_stack[-1] == snapshot:
            return
        self._undo_stack.append(snapshot)
        self._undo_stack = self._undo_stack[-50:]
        self._redo_stack.clear()
        self._update_undo_buttons()

    def _undo(self):
        if not self._undo_stack:
            return
        current = self._snapshot()
        snapshot = self._undo_stack.pop()
        self._redo_stack.append(current)
        self._restore_snapshot(snapshot)
        self._update_undo_buttons()
        self._set_status("Undo")

    def _redo(self):
        if not self._redo_stack:
            return
        current = self._snapshot()
        snapshot = self._redo_stack.pop()
        self._undo_stack.append(current)
        self._restore_snapshot(snapshot)
        self._update_undo_buttons()
        self._set_status("Redo")

    def _restore_snapshot(self, snapshot: str):
        self._restoring = True
        try:
            self.block_scene.deserialize(json.loads(snapshot))
            self.blocks = self.block_scene.blocks()
            self.connections.clear()
            self._update_project_tree()
            self._set_dirty(True)
        finally:
            self._restoring = False

    def _update_undo_buttons(self):
        if hasattr(self, 'undo_btn'):
            self.undo_btn.setEnabled(bool(self._undo_stack))
        if hasattr(self, 'redo_btn'):
            self.redo_btn.setEnabled(bool(self._redo_stack))

    # ---------------------------------------------------------------- status
    def _set_dirty(self, dirty: bool):
        self.is_dirty = bool(dirty)
        name = self.current_file.name if self.current_file else "Untitled"
        marker = " *" if self.is_dirty else ""
        if self.plugin is not None and getattr(self.plugin, 'plugin_info', None):
            self.setWindowTitle(f"{name}{marker} — LuaQAH Studio")
        self.status_indicator.setStyleSheet(
            "color: #e67e22; font-size: 22px;" if self.is_dirty
            else "color: #2ecc71; font-size: 22px;"
        )

    def _set_status(self, message: str):
        self.status_label.setText(message)
        QTimer.singleShot(6000, lambda: self.status_label.setText("Ready"))


    def _generate_lua_code(self, preview_only=False):
        """Generate Lua code from the canvas blocks."""
        try:
            self.blocks = self.block_scene.blocks()
            event_blocks = [b for b in self.blocks if b.block_type == 'event']
            if not event_blocks and not preview_only:
                QMessageBox.warning(
                    self,
                    "No Entry Points",
                    "Add an 'On Start' or similar event block to generate runnable code.",
                )
                return

            lua_code = self._generate_complete_code()
            self.code_preview.update_code(lua_code)
            self.right_tabs.setCurrentIndex(1)
            self._set_status("Lua code generated")

            if not preview_only:
                temp_dir = Path.home() / "QAH" / "temp_lua"
                temp_dir.mkdir(parents=True, exist_ok=True)
                temp_file = temp_dir / f"generated_{self._get_project_name()}.lua"
                temp_file.write_text(lua_code, encoding='utf-8')
                self._set_status(f"Lua code generated → {temp_file}")
        except Exception as exc:
            QMessageBox.critical(self, "Error", f"Failed to generate Lua code: {exc}")
    
    def _generate_complete_code(self):
        """Generate one clean Lua file from every block on the canvas."""
        project_name = self._get_project_name()
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        engine = self.engine_settings.get('engine', 'lua').upper()
        blocks = sorted(self.block_scene.blocks(), key=lambda b: (b.y(), b.x()))

        def is_value_source(block):
            return any(
                socket.direction == 'output'
                and socket.socket_type != 'execution'
                and socket.data_type != 'execution'
                and socket.connected_to is not None
                for socket in block.sockets.values()
            )

        events = [b for b in blocks if b.block_type == 'event']
        variables = [b for b in blocks if b.block_type == 'variable']
        functions = [b for b in blocks if b.block_type == 'function']
        controls = [b for b in blocks if b.block_type == 'control']
        operators = [b for b in blocks if b.block_type == 'operator']
        actions = [b for b in blocks if b.block_type == 'action']
        others = [
            b for b in blocks
            if b.block_type not in ('event', 'variable', 'function', 'control', 'operator', 'action')
        ]

        lines = [
            '-- Generated by LuaQAH Studio 2.1',
            f'-- Project: {project_name}',
            f'-- Engine: {engine}',
            f'-- Generated: {timestamp}',
            f'-- Blocks: {len(blocks)}  Connections: {len(self.block_scene.serialize().get("connections", []))}',
            f'-- Memory limit: {self.engine_settings.get("memory_limit", 0)} MB',
            '',
            'local BLOCK_COUNT = ' + str(len(blocks)),
            'print("=== " .. ' + json.dumps(project_name) + ' .. " ===")',
            'print("Blocks: " .. BLOCK_COUNT)',
            'print("Generated: " .. ' + json.dumps(timestamp) + ')',
            '',
        ]

        def append_block(block, indent):
            try:
                code = block.generate_lua_code(indent)
            except Exception as exc:
                code = f'{"    " * indent}-- Could not generate {block.title}: {exc}'
            if code and code.strip():
                lines.append(code.rstrip())

        # Value-producing blocks connected to another block are rendered inline.
        def section(title, group, indent, skip_value_sources=True):
            usable = [
                b for b in group
                if not (skip_value_sources and is_value_source(b))
            ]
            if not usable:
                return
            lines.append('')
            lines.append(('    ' * indent) + '-- ' + title)
            for block in usable:
                append_block(block, indent)

        # Variable declarations / table setup.
        section('VARIABLES', variables, 0, skip_value_sources=True)

        lines.append('')
        lines.append('local function main()')
        section('EVENT HANDLERS', events, 1)
        section('FUNCTIONS', functions, 1)
        section('CONTROL FLOW', controls, 1)
        section('MATH / OPERATORS', operators, 1)
        section('ACTIONS', actions, 1)
        section('OTHER BLOCKS', others, 1)
        lines.append('end')
        lines.append('')

        lines.extend([
            '-- Error handling wrapper',
            'local success, err = pcall(main)',
            'if not success then',
            '    print("")',
            '    print("=== ERROR ===")',
            '    print("Error during execution:", err)',
            '    local msg = tostring(err)',
            '    if string.find(msg, "attempt to perform arithmetic") then',
            '        print("Hint: check numeric inputs and math operations")',
            '    elseif string.find(msg, "attempt to call") then',
            '        print("Hint: check that functions and blocks are connected correctly")',
            '    elseif string.find(msg, "not enough memory") then',
            '        print("Hint: increase the engine memory limit")',
            '    elseif string.find(msg, "syntax error") then',
            '        print("Hint: check parentheses, brackets and quotes")',
            '    end',
            '    if debug and debug.traceback then',
            '        print(debug.traceback(err, 2))',
            '    end',
            'else',
            '    print("")',
            '    print("=== SUCCESS ===")',
            '    print("Execution completed successfully")',
            'end',
            '',
            'print("")',
            'print("=== End of Program ===")',
            'if success then return 0 else return 1 end',
            '',
        ])

        return '\n'.join(lines)

    def _get_project_name(self):
        if self.current_file:
            return self.current_file.stem
        return "UntitledProject"
    
    def _run_lua_code(self, engine_type=None):
        """Generate (if needed) and run the Lua program."""
        if not self.code_preview.toPlainText().strip():
            self._generate_lua_code(preview_only=True)
        code = self.code_preview.toPlainText()
        if not code.strip():
            QMessageBox.warning(self, "No Code", "Add blocks and generate Lua code first.")
            return

        try:
            self.progress_bar.setVisible(True)
            self.progress_bar.setRange(0, 0)
            self._set_status("Executing with Lua...")
            self.output_text.append("--- Running generated program ---")
            QTimer.singleShot(100, lambda: self._execute_with_lua(code))
        except Exception as exc:
            QMessageBox.critical(self, "Error", f"Failed to initialize Lua engine: {exc}")
            self.progress_bar.setVisible(False)
    
    def _execute_with_lua(self, code):
        """Execute code with the standard Lua bridge."""
        lua_state = None
        bridge = None
        try:
            from plugins.libs.lua.lua_bridge import get_lua_bridge
            bridge = get_lua_bridge()
            lua_state = bridge.init()
            if not lua_state:
                raise RuntimeError("Failed to initialize Lua state")

            if self.engine_settings.get('memory_limit', 0) > 0:
                memory_code = (
                    f"local limit = {self.engine_settings['memory_limit']} * 1024 * 1024\n"
                    'print(string.format("Memory limit: %.1f MB", limit / (1024*1024)))\n'
                )
                try:
                    bridge.execute_script(lua_state, memory_code)
                except Exception:
                    pass

            success = bridge.execute_script(lua_state, code)
            if success:
                self._set_status("Lua execution completed successfully")
                self.output_text.append("Lua execution completed successfully.")
            else:
                error_msg = self._get_lua_error(bridge, lua_state)
                self._set_status("Lua execution failed")
                self.output_text.append(f"Lua error: {error_msg}")
                QMessageBox.critical(self, "Lua Error", f"Execution failed:\n{error_msg}")
        except ImportError as exc:
            print(f"Lua bridge not available: {exc}")
            self._run_in_demo_mode(code, "Lua")
        except Exception as exc:
            self._set_status(f"Execution error: {exc}")
            QMessageBox.critical(self, "Error", f"Failed to execute Lua code:\n{exc}")
        finally:
            if bridge is not None and lua_state is not None:
                try:
                    bridge.close(lua_state)
                except Exception:
                    try:
                        bridge.cleanup(lua_state)
                    except Exception:
                        pass
            self.progress_bar.setVisible(False)
    
    def _get_lua_error(self, bridge, lua_state):
        """Get error message from Lua stack"""
        try:
            if hasattr(bridge.lib, 'lua_tolstring'):
                err_ptr = bridge.lib.lua_tolstring(lua_state, -1, None)
                if err_ptr:
                    import ctypes
                    return ctypes.string_at(err_ptr).decode('utf-8', errors='ignore')
        except:
            pass
        return "Unknown error"
    
    def _run_in_demo_mode(self, code, engine_name):
        """Run in demo mode when Lua engine is not available"""
        demo_dialog = QDialog(self)
        demo_dialog.setWindowTitle(f"{engine_name} Demo Mode")
        demo_dialog.setModal(True)
        demo_dialog.resize(600, 400)
        
        layout = QVBoxLayout(demo_dialog)
        
        info_label = QLabel(f"{engine_name} bridge not available. Running in demo mode.")
        info_label.setStyleSheet("color: #e67e22; font-weight: bold;")
        layout.addWidget(info_label)
        
        code_text = QTextEdit()
        code_text.setPlainText(code)
        code_text.setReadOnly(True)
        code_text.setFont(QFont("Consolas", 10))
        layout.addWidget(code_text)
        
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(demo_dialog.accept)
        layout.addWidget(close_btn)
        
        demo_dialog.exec()
        self._set_status("Code displayed in demo mode")
    
    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            for url in event.mimeData().urls():
                if url.isLocalFile() and url.toLocalFile().lower().endswith(('.blockproj', '.lua')):
                    event.acceptProposedAction()
                    return
        event.ignore()

    def dropEvent(self, event):
        for url in event.mimeData().urls():
            if not url.isLocalFile():
                continue
            path = url.toLocalFile()
            if path.lower().endswith('.blockproj'):
                self._load_project_path(path)
                event.acceptProposedAction()
                return
            if path.lower().endswith('.lua'):
                text = Path(path).read_text(encoding='utf-8', errors='replace')
                self.code_preview.update_code(text)
                self.right_tabs.setCurrentIndex(1)
                self._set_status(f"Loaded Lua file: {Path(path).name}")
                event.acceptProposedAction()
                return
        event.ignore()

    def closeEvent(self, event):
        if self.is_dirty:
            reply = QMessageBox.question(
                self,
                "Unsaved Project",
                "Save changes before closing?",
                QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel,
                QMessageBox.Save,
            )
            if reply == QMessageBox.Cancel:
                event.ignore()
                return
            if reply == QMessageBox.Save:
                self._save_project()
                if self.is_dirty:
                    event.ignore()
                    return
        event.accept()

    def cleanup(self):
        """Called by the plugin wrapper before the widget is deleted."""
        self.block_scene.clear()

    def _show_run_options(self):
        """Show run options menu"""
        menu = QMenu(self)
        
        run_lua_action = menu.addAction("Run with Lua")
        run_lua_action.triggered.connect(lambda: self._run_lua_code('lua'))
        
        menu.addSeparator()
        
        run_debug_action = menu.addAction("Run with Debug Mode")
        run_debug_action.triggered.connect(lambda: self._run_lua_code('debug'))
        
        menu.exec(self.run_settings_btn.mapToGlobal(self.run_settings_btn.rect().bottomLeft()))


# Backwards-compatible alias for older imports.
DragDropLuaBlocksWidget = LuaQAHStudioWidget
