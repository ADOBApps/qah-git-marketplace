"""
Block Components - Core classes for block programming
This file is part of Quantum Analysis Helper.
Quantum Analysis Helper is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Quantum Analysis Helper is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

import json
import uuid
import math
from typing import Dict, List, Any, Optional, Tuple
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
    QListWidget, QListWidgetItem, QTextEdit, QGraphicsView,
    QGraphicsScene, QGraphicsItem, QGraphicsTextItem,
    QGraphicsLineItem, QGraphicsDropShadowEffect, QToolBox,
    QGroupBox, QComboBox, QInputDialog, QMessageBox, QMenu,
    QGraphicsObject, QStyleOptionGraphicsItem, QDialog,
    QFormLayout, QLineEdit, QDialogButtonBox, QApplication,
    QLabel, QScrollArea, QFrame, QTreeWidget, QTreeWidgetItem
)
from PySide6.QtGui import (
    QFont, QColor, QBrush, QPen, QLinearGradient, QPainter,
    QDrag, QPixmap, QIcon, QCursor, QAction, QTextCursor,
    QTextCharFormat, QPainterPath, QPolygonF, QPalette,
    QSyntaxHighlighter, QTextDocument
)
from PySide6.QtCore import (
    Qt, Signal, Slot, QPoint, QPointF, QRectF, QSize,
    QMimeData, QByteArray, QDataStream, QIODevice,
    QObject
)
import re


class Connection(QGraphicsLineItem):
    """Curved connection between two sockets."""

    def __init__(self, start_socket, end_socket, parent=None):
        super().__init__(parent)
        self.start_socket = start_socket
        self.end_socket = end_socket
        self._color = QApplication.palette().color(QPalette.Highlight)
        if not self._color.isValid():
            self._color = QColor("#4f8cff")

        pen = QPen(self._color, 2.5)
        pen.setCosmetic(True)
        self.setPen(pen)
        self.setZValue(-1)
        self.setFlag(QGraphicsItem.ItemIsSelectable, True)
        self.setAcceptHoverEvents(True)
        self.update_line()

    def update_line(self):
        """Update the line geometry between socket centres."""
        if self.start_socket and self.end_socket:
            start_pos = self.start_socket.scenePos()
            end_pos = self.end_socket.scenePos()
            start_pos += QPointF(
                self.start_socket.SOCKET_SIZE / 2,
                self.start_socket.SOCKET_SIZE / 2,
            )
            end_pos += QPointF(
                self.end_socket.SOCKET_SIZE / 2,
                self.end_socket.SOCKET_SIZE / 2,
            )
            self.setLine(start_pos.x(), start_pos.y(), end_pos.x(), end_pos.y())

    def paint(self, painter, option, widget=None):
        """Paint a smooth Bezier connection with an arrow head."""
        line = self.line()
        if line.length() <= 0:
            return

        painter.setRenderHint(QPainter.Antialiasing, True)
        start = line.p1()
        end = line.p2()
        bend = max(40.0, abs(end.x() - start.x()) * 0.45)
        c1 = QPointF(start.x() + bend, start.y())
        c2 = QPointF(end.x() - bend, end.y())

        path = QPainterPath(start)
        path.cubicTo(c1, c2, end)

        color = QColor("#ffd166") if self.isSelected() else self._color
        pen = QPen(color, 3.2 if self.isSelected() else 2.5)
        pen.setCosmetic(True)
        painter.setPen(pen)
        painter.setBrush(Qt.NoBrush)
        painter.drawPath(path)

        angle = math.atan2(end.y() - c2.y(), end.x() - c2.x())
        arrow_size = 11
        arrow = QPolygonF(
            [
                QPointF(0, 0),
                QPointF(-arrow_size, arrow_size / 2),
                QPointF(-arrow_size, -arrow_size / 2),
            ]
        )
        painter.save()
        painter.translate(end)
        painter.rotate(math.degrees(angle))
        painter.setBrush(QBrush(color))
        painter.setPen(QPen(Qt.NoPen))
        painter.drawPolygon(arrow)
        painter.restore()


class Socket(QGraphicsObject):
    """Socket for connecting blocks"""
    
    SOCKET_SIZE = 12
    socket_clicked = Signal(object)  # Signal emitted when socket is clicked
    
    def __init__(self, block, name: str, socket_type: str, direction: str, 
                 data_type: str):
        super().__init__(block)
        self.block = block
        self.name = name
        self.socket_type = socket_type
        self.direction = direction  # "input" or "output"
        self.data_type = data_type
        
        # Connection tracking
        self.connections = []  # List of Connection objects
        self.connected_to = None  # Other socket this is connected to
        
        # Visual properties
        self._rect = QRectF(0, 0, self.SOCKET_SIZE, self.SOCKET_SIZE)
        self.setAcceptHoverEvents(True)
        
        # Label
        self.label = QGraphicsTextItem(name, self)
        self.label.setDefaultTextColor(Qt.white)
        small_font = QFont("Arial", 7)
        self.label.setFont(small_font)
        
        # Position label based on direction
        if self.direction == "input":
            self.label.setPos(self.SOCKET_SIZE + 3, -5)
        else:
            self.label.setPos(-self.label.boundingRect().width() - 3, -5)
    
    def boundingRect(self):
        """Required override for QGraphicsItem"""
        return self._rect
    
    def paint(self, painter, option, widget=None):
        """Paint the socket."""
        painter.setRenderHint(QPainter.Antialiasing, True)
        color = self._get_socket_color()

        painter.setBrush(QBrush(color))
        painter.setPen(QPen(QColor(0, 0, 0, 120), 1))
        painter.drawEllipse(self._rect)

        if self.isUnderMouse():
            painter.setPen(QPen(QColor("#ffd166"), 2))
            painter.setBrush(Qt.NoBrush)
            painter.drawEllipse(self._rect.adjusted(-2, -2, 2, 2))

    def mousePressEvent(self, event):
        """Handle mouse press on socket."""
        self.socket_clicked.emit(self)
        event.accept()

    def _get_socket_color(self) -> QColor:
        """Get color based on data type."""
        colors = {
            'any': QColor(200, 200, 200),
            'number': QColor(66, 165, 245),
            'string': QColor(76, 175, 80),
            'boolean': QColor(255, 152, 0),
            'table': QColor(156, 39, 176),
            'function': QColor(244, 67, 54),
            'execution': QColor(255, 255, 255),
        }
        return colors.get(self.data_type, colors.get(self.socket_type, QColor(200, 200, 200)))

    def can_connect_to(self, other_socket) -> bool:
        """Check whether two sockets can be connected."""
        if self == other_socket:
            return False
        if self.block == other_socket.block:
            return False
        if self.direction == other_socket.direction:
            return False
        if self.data_type != "any" and other_socket.data_type != "any":
            if self.data_type != other_socket.data_type:
                return False
        return True

    def connect_to(self, other_socket) -> bool:
        """Connect this socket, keeping one connection per socket."""
        if self.connected_to is other_socket and self.connections:
            return True
        if not self.can_connect_to(other_socket):
            return False

        # One edge per socket keeps generated code unambiguous.
        self.disconnect()
        other_socket.disconnect()

        connection = Connection(self, other_socket)
        if self.scene():
            self.scene().addItem(connection)

        self.connections.append(connection)
        other_socket.connections.append(connection)
        self.connected_to = other_socket
        other_socket.connected_to = self
        return True

    def disconnect(self, connection=None):
        """Remove one or all connections from this socket."""
        targets = [connection] if connection is not None else list(self.connections)
        for conn in targets:
            if conn is None:
                continue
            for sock in (conn.start_socket, conn.end_socket):
                if sock is None:
                    continue
                if conn in sock.connections:
                    sock.connections.remove(conn)
                other = conn.end_socket if sock is conn.start_socket else conn.start_socket
                if other is not None and sock.connected_to is other:
                    sock.connected_to = None
            if conn.scene() is not None:
                conn.scene().removeItem(conn)

        if connection is None:
            self.connections.clear()
            self.connected_to = None


class LuaBlock(QGraphicsObject):
    """Base class for Lua programming blocks"""
    
    # Signals must be defined at class level
    block_moved = Signal(object, QPointF)
    block_selected = Signal(object)
    block_deleted = Signal(object)
    block_duplicated = Signal(object, object)  # original, duplicate
    
    TYPE_COLORS = {
        'event': QColor(0, 150, 136),      # Teal
        'action': QColor(156, 39, 176),    # Purple
        'control': QColor(255, 87, 34),    # Deep Orange
        'variable': QColor(3, 169, 244),   # Light Blue
        'function': QColor(76, 175, 80),   # Green
        'operator': QColor(255, 193, 7),   # Amber
        'value': QColor(121, 85, 72),      # Brown
    }
    
    def __init__(self, block_type: str, title: str, parent=None, *, add_default_sockets: bool = True):
        super().__init__(parent)
        self.block_type = block_type
        self.block_id = str(uuid.uuid4())[:8]
        self.title = title
        self.description = ""
        self.sockets = {}  # name -> Socket object
        self.lua_code = ""
        self.data = {}
        self._hovered = False

        # Setup visuals
        self._setup_appearance()
        self._setup_ui()

        if add_default_sockets:
            self._add_default_sockets()

        # Enable flags
        self.setFlag(QGraphicsItem.ItemIsMovable, True)
        self.setFlag(QGraphicsItem.ItemIsSelectable, True)
        self.setAcceptHoverEvents(True)
    
    def _setup_appearance(self):
        """Setup block appearance"""
        # Colors
        base_color = self.TYPE_COLORS.get(self.block_type, QColor(100, 100, 100))
        self.base_color = base_color
        self.highlight_color = base_color.lighter(130)
        self.shadow_color = base_color.darker(150)
        
        # Size based on block type
        if self.block_type == 'event':
            self.width = 200
            self.height = 60
        elif self.block_type == 'control':
            self.width = 220
            self.height = 80
        else:
            self.width = 180
            self.height = 70
        
        # Bounding rectangle
        self._rect = QRectF(0, 0, self.width, self.height)
        
        # Shadow effect
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(8)
        shadow.setColor(QColor(0, 0, 0, 80))
        shadow.setOffset(2, 2)
        self.setGraphicsEffect(shadow)
    
    def boundingRect(self):
        """Required override for QGraphicsItem"""
        return self._rect
    
    def paint(self, painter, option, widget=None):
        """Custom paint method for the block."""
        painter.setRenderHint(QPainter.Antialiasing, True)
        gradient = QLinearGradient(0, 0, 0, self.height)
        gradient.setColorAt(0, self.base_color.lighter(112) if self._hovered else self.base_color)
        gradient.setColorAt(1, self.base_color.darker(125))

        painter.setBrush(QBrush(gradient))
        painter.setPen(QPen(self.shadow_color, 1.5))
        painter.drawRoundedRect(self._rect, 8, 8)

        # Top highlight strip.
        painter.setPen(QPen(QColor(255, 255, 255, 45), 1))
        painter.drawLine(8, 2, self.width - 8, 2)

        if self.isSelected():
            painter.setPen(QPen(QColor("#ffd166"), 2.5))
            painter.setBrush(Qt.NoBrush)
            painter.drawRoundedRect(self._rect.adjusted(-1, -1, 1, 1), 9, 9)

    def hoverEnterEvent(self, event):
        self._hovered = True
        self.update()
        super().hoverEnterEvent(event)

    def hoverLeaveEvent(self, event):
        self._hovered = False
        self.update()
        super().hoverLeaveEvent(event)
    
    def _setup_ui(self):
        """Setup block UI elements"""
        # Title area
        self.title_item = QGraphicsTextItem(self.title, self)
        self.title_item.setDefaultTextColor(Qt.white)
        font = QFont("Arial", 9, QFont.Bold)
        self.title_item.setFont(font)
        self.title_item.setPos(10, 10)
        
        # ID label (small)
        self.id_item = QGraphicsTextItem(f"#{self.block_id}", self)
        self.id_item.setDefaultTextColor(Qt.white)
        small_font = QFont("Arial", 6)
        self.id_item.setFont(small_font)
        self.id_item.setPos(self.width - 35, 5)
        
        # Add default sockets based on block type
        self._add_default_sockets()
    
    PLACEHOLDER_TYPES = {
        "condition": "boolean",
        "a": "number",
        "b": "number",
        "x": "number",
        "y": "number",
        "start": "number",
        "end": "number",
        "index": "number",
        "n_qubits": "number",
        "qubit": "number",
        "control": "number",
        "target": "number",
        "message": "string",
        "prompt": "string",
        "filename": "string",
        "content": "string",
        "str": "string",
        "pattern": "string",
        "gate": "string",
        "table": "table",
        "state": "table",
        "variable": "any",
        "key": "any",
        "value": "any",
        "name": "any",
    }

    def _add_default_sockets(self):
        """Add the structural sockets for this block type."""
        if self.block_type == "event":
            self.add_socket("trigger", "execution", "output", "any")
        elif self.block_type == "action":
            self.add_socket("exec_in", "execution", "input", "any")
            self.add_socket("exec_out", "execution", "output", "any")
        elif self.block_type == "control":
            title = self.title.lower()
            if "if" in title:
                self.add_socket("condition", "value", "input", "boolean")
                self.add_socket("then_out", "execution", "output", "any")
                self.add_socket("else_out", "execution", "output", "any")
            elif "while" in title or "repeat" in title:
                self.add_socket("condition", "value", "input", "boolean")
                self.add_socket("loop_out", "execution", "output", "any")
        elif self.block_type == "variable":
            title = self.title.lower()
            if "set" in title:
                self.add_socket("value", "value", "input", "any")
                self.add_socket("exec_out", "execution", "output", "any")
            elif "get" in title:
                self.add_socket("result", "value", "output", "any")
            elif "increment" in title or "decrement" in title:
                self.add_socket("exec_out", "execution", "output", "any")
        elif self.block_type in ("function", "operator"):
            self.add_socket("result", "value", "output", "any")

        self.ensure_sockets_for_template()

    def clear_sockets(self):
        """Remove all socket graphics and connection pointers."""
        for socket in list(self.sockets.values()):
            socket.disconnect()
            if socket.scene() is not None:
                socket.scene().removeItem(socket)
            else:
                socket.setParentItem(None)
                socket.deleteLater()
        self.sockets.clear()

    def ensure_sockets_for_template(self):
        """Create input sockets for every ``{placeholder}`` in the template."""
        code = self.lua_code or self._get_default_code_template()
        for placeholder in re.findall(r"\{([A-Za-z_]\w*)\}", code):
            if placeholder == "var_name" or placeholder in self.sockets:
                continue
            data_type = self.PLACEHOLDER_TYPES.get(placeholder, "any")
            self.add_socket(placeholder, "value", "input", data_type)

        if self.block_type in ("operator", "function") and "result" not in self.sockets:
            self.add_socket("result", "value", "output", "any")
        if self.block_type == "action":
            if "exec_in" not in self.sockets:
                self.add_socket("exec_in", "execution", "input", "any")
            if "exec_out" not in self.sockets:
                self.add_socket("exec_out", "execution", "output", "any")
    
    def add_socket(self, name: str, socket_type: str, direction: str, data_type: str) -> Socket:
        """Add a socket to the block"""
        socket = Socket(self, name, socket_type, direction, data_type)
        self.sockets[name] = socket
        
        # Position socket based on direction
        self._position_sockets()
        
        # Connect socket signals
        socket.socket_clicked.connect(self._on_socket_clicked)
        
        return socket
    
    def _position_sockets(self):
        """Position all sockets on the block"""
        input_sockets = [s for s in self.sockets.values() if s.direction == "input"]
        output_sockets = [s for s in self.sockets.values() if s.direction == "output"]
        
        # Position input sockets on left side
        input_y = 30
        input_spacing = 25
        for socket in input_sockets:
            socket.setPos(0, input_y)
            socket.label.setPos(socket.SOCKET_SIZE + 3, input_y - 5)
            input_y += input_spacing
        
        # Position output sockets on right side
        output_y = 30
        output_spacing = 25
        for socket in output_sockets:
            socket.setPos(self.width - socket.SOCKET_SIZE, output_y)
            socket.label.setPos(-socket.label.boundingRect().width() - 3, output_y - 5)
            output_y += output_spacing
    
    def _on_socket_clicked(self, socket):
        """Handle socket click - will be connected to scene's connection logic"""
        # This signal will be connected to the scene's connection handler
        pass
    
    def mousePressEvent(self, event):
        """Handle mouse press"""
        super().mousePressEvent(event)
        self.block_selected.emit(self)
        event.accept()
    
    def mouseMoveEvent(self, event):
        """Handle mouse move (dragging)"""
        super().mouseMoveEvent(event)
        self.block_moved.emit(self, self.pos())
        event.accept()
        
        # Update all connections when block moves
        for socket in self.sockets.values():
            for connection in socket.connections:
                connection.update_line()
    
    def mouseDoubleClickEvent(self, event):
        """Handle double click to edit"""
        self._open_edit_dialog()
        event.accept()
    
    def contextMenuEvent(self, event):
        """Show context menu"""
        menu = QMenu()
        
        edit_action = menu.addAction("Edit Block")
        delete_action = menu.addAction("Delete Block")
        menu.addSeparator()
        duplicate_action = menu.addAction("Duplicate Block")
        
        action = menu.exec(event.screenPos())
        
        if action == edit_action:
            self._open_edit_dialog()
        elif action == delete_action:
            self.block_deleted.emit(self)
        elif action == duplicate_action:
            self._duplicate_block()
    
    def _open_edit_dialog(self):
        """Open block edit dialog with variable name input for variable blocks"""
        
        if self.block_type == 'variable':
            # Special dialog for variable blocks
            dialog = QDialog()
            dialog.setWindowTitle(f"Edit {self.title}")
            layout = QVBoxLayout(dialog)
            
            form_layout = QFormLayout()
            
            # Variable name input
            var_name_input = QLineEdit()
            var_name_input.setPlaceholderText("Enter variable name (e.g., counter, result, data)")
            if 'var_name' in self.data:
                var_name_input.setText(self.data['var_name'])
            form_layout.addRow("Variable Name:", var_name_input)
            
            # Default value input (for Set Variable only)
            value_input = None
            if 'set' in self.title.lower():
                value_input = QLineEdit()
                value_input.setPlaceholderText("Enter value (e.g., 0, 'hello', {})")
                if 'value' in self.data:
                    value_input.setText(self.data['value'])
                form_layout.addRow("Default Value:", value_input)
            
            # Buttons
            button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
            button_box.accepted.connect(dialog.accept)
            button_box.rejected.connect(dialog.reject)
            
            layout.addLayout(form_layout)
            layout.addWidget(button_box)
            
            if dialog.exec():
                var_name = var_name_input.text().strip()
                if var_name:
                    self.data['var_name'] = var_name
                    
                    # Save value for Set Variable blocks
                    if value_input is not None:
                        value = value_input.text().strip()
                        if value:
                            self.data['value'] = value
                            self.lua_code = f"{var_name} = {value}"
                        else:
                            self.data['value'] = 'nil'
                            self.lua_code = f"{var_name} = nil"
                    elif 'get' in self.title.lower():
                        self.lua_code = var_name
                    elif 'increment' in self.title.lower():
                        self.lua_code = f"{var_name} = {var_name} + 1"
                    elif 'decrement' in self.title.lower():
                        self.lua_code = f"{var_name} = {var_name} - 1"
                    
                    # Update title to show variable name
                    self.title_item.setPlainText(f"{self.title}: {var_name}")
                    
        else:
            # Original edit dialog for other blocks
            title, ok = QInputDialog.getText(
                None, "Edit Block", "Enter new title:", 
                text=self.title
            )
            
            if ok and title.strip():
                self.title = title.strip()
                self.title_item.setPlainText(self.title)
    
    def _duplicate_block(self):
        """Duplicate this block, its data and its socket layout."""
        scene = self.scene()
        if not scene:
            return

        try:
            scene.about_to_change.emit()
            duplicate = LuaBlock(
                self.block_type, f"{self.title} (Copy)", add_default_sockets=False
            )
            duplicate.lua_code = self.lua_code
            duplicate.description = self.description
            duplicate.data = self.data.copy() if self.data else {}
            duplicate.setPos(self.x() + 34, self.y() + 34)

            for name, socket in self.sockets.items():
                duplicate.add_socket(
                    name, socket.socket_type, socket.direction, socket.data_type
                )
            duplicate.ensure_sockets_for_template()
            duplicate._sync_title_item()

            scene.addItem(duplicate)
            duplicate.block_deleted.connect(scene._on_block_deleted)
            duplicate.block_moved.connect(scene._on_block_moved)
            for socket in duplicate.sockets.values():
                socket.socket_clicked.connect(scene._on_socket_clicked)
            if hasattr(scene, "block_added"):
                scene.block_added.emit(duplicate)
            self.block_duplicated.emit(self, duplicate)
        except Exception as exc:
            print(f"Error duplicating block: {exc}")
            QMessageBox.warning(None, "Duplication Error", f"Failed to duplicate block: {exc}")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert block to a JSON-serialisable dictionary."""
        return {
            'type': self.block_type,
            'id': self.block_id,
            'title': self.title,
            'description': self.description,
            'position': {'x': self.x(), 'y': self.y()},
            'z': self.zValue(),
            'sockets': {name: {
                'type': socket.socket_type,
                'direction': socket.direction,
                'data_type': socket.data_type
            } for name, socket in self.sockets.items()},
            'lua_code': self.lua_code,
            'data': self.data
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]):
        """Create a block from saved data without duplicating default sockets."""
        block = cls(
            data.get('type', 'function'),
            data.get('title', 'Block'),
            add_default_sockets=False,
        )
        block.block_id = data.get('id', block.block_id)
        block.description = data.get('description', '')
        block.lua_code = data.get('lua_code', '')
        block.data = data.get('data', {}) or {}

        if 'position' in data:
            block.setPos(data['position'].get('x', 0), data['position'].get('y', 0))
        if 'z' in data:
            block.setZValue(data.get('z', 0))

        for name, socket_data in data.get('sockets', {}).items():
            block.add_socket(
                name,
                socket_data.get('type', 'value'),
                socket_data.get('direction', 'input'),
                socket_data.get('data_type', 'any'),
            )
        block.ensure_sockets_for_template()
        block._sync_title_item()
        return block

    def _sync_title_item(self):
        """Show a variable name in the block title when it has one."""
        title = self.title
        var_name = self.data.get('var_name') if isinstance(self.data, dict) else None
        if var_name:
            title = f"{self.title}: {var_name}"
        if hasattr(self, 'title_item') and self.title_item is not None:
            self.title_item.setPlainText(title)
    
    def get_connected_code(self, socket_name: str) -> str:
        """Get code from connected block via specified socket"""
        socket = self.sockets.get(socket_name)
        if socket and socket.connected_to:
            return socket.connected_to.block.generate_lua_code()
        return ""
    
    # In the LuaBlock class, enhance the generate_lua_code method:

    def generate_lua_code(self, indent: int = 0) -> str:
        """Generate Lua code for this block with resolved connections."""
        indent_str = '    ' * indent
        title_lower = self.title.lower()

        # Variable blocks use their data fields rather than a generic template.
        if self.block_type == 'variable':
            if 'create table' in title_lower:
                name = self.data.get('name') or 'my_table'
                return f"{indent_str}local {name} = {{}}\n"
            var_name = self.data.get('var_name') or 'my_var'
            if 'set' in title_lower:
                socket = self.sockets.get('value')
                if socket is not None and socket.connected_to is not None:
                    value = socket.connected_to.block.generate_lua_code(0).strip() or 'nil'
                else:
                    value = str(self.data.get('value', 'nil') or 'nil')
                return f"{indent_str}{var_name} = {value}\n"
            if 'get' in title_lower:
                return f"{indent_str}{var_name}\n"
            if 'increment' in title_lower:
                return f"{indent_str}{var_name} = {var_name} + 1\n"
            if 'decrement' in title_lower:
                return f"{indent_str}{var_name} = {var_name} - 1\n"

        code = self.lua_code or self._get_default_code_template()
        if not code:
            return f"{indent_str}-- {self.title}\n"

        # Make sure every placeholder has a socket, including old projects.
        for placeholder in re.findall(r"\{([A-Za-z_]\w*)\}", code):
            if placeholder != 'var_name' and placeholder not in self.sockets:
                self.add_socket(
                    placeholder,
                    "value",
                    "input",
                    self.PLACEHOLDER_TYPES.get(placeholder, "any"),
                )

        for placeholder in dict.fromkeys(re.findall(r"\{([A-Za-z_]\w*)\}", code)):
            if placeholder == 'var_name':
                replacement = self.data.get('var_name') or 'my_var'
            else:
                replacement = self._placeholder_value(placeholder)
            code = code.replace("{" + placeholder + "}", replacement)

        # Never emit a literal {placeholder} into Lua code.
        code = re.sub(r"\{[A-Za-z_]\w*\}", "nil", code)

        lines = code.split('\n')
        formatted_lines = []
        current_indent = indent
        for raw_line in lines:
            line = raw_line.strip()
            if not line:
                formatted_lines.append('')
                continue
            if line.startswith(('end', 'else', 'elseif', 'until')):
                current_indent = max(indent, current_indent - 1)
            formatted_lines.append(('    ' * current_indent) + line)
            if line.endswith(('then', 'do')) or line.startswith(('function', 'repeat')):
                current_indent += 1
            elif line.startswith('else') or line.startswith('elseif'):
                current_indent += 1

        return '\n'.join(formatted_lines)

    def _placeholder_value(self, placeholder: str) -> str:
        """Return connected code, saved data, or a safe Lua default."""
        socket = self.sockets.get(placeholder)
        if socket is not None and socket.connected_to is not None:
            connected = socket.connected_to.block.generate_lua_code(0).strip()
            if connected:
                return connected

        if placeholder in self.data and self.data.get(placeholder) not in (None, ""):
            value = self.data[placeholder]
            if isinstance(value, str):
                if placeholder in ("var_name", "variable", "name", "key", "table"):
                    return value
                return json.dumps(value)
            return str(value)

        return self._get_default_value(
            socket.data_type if socket is not None else self.PLACEHOLDER_TYPES.get(placeholder, "any"),
            placeholder,
        )

    def _get_default_code_template(self) -> str:
        """Get default code template based on block type and title"""
        title_lower = self.title.lower()
        
        if self.block_type == 'control':
            if 'for each' in title_lower:
                return "for {key}, {value} in pairs({table}) do\n    -- body\nend"
            if 'if' in title_lower or 'then' in title_lower:
                return "if {condition} then\n    -- then block\nend"
            elif 'for' in title_lower and 'loop' in title_lower:
                return "for {variable} = {start}, {end} do\n    -- loop body\nend"
            elif 'while' in title_lower:
                return "while {condition} do\n    -- loop body\nend"
            elif 'repeat' in title_lower:
                return "repeat\n    -- loop body\nuntil {condition}"
        
        elif self.block_type == 'operator':
            if 'add' in title_lower or '+' in self.title:
                return "{a} + {b}"
            elif 'subtract' in title_lower or '-' in self.title:
                return "{a} - {b}"
            elif 'multiply' in title_lower or '×' in self.title or '*' in self.title:
                return "{a} * {b}"
            elif 'divide' in title_lower or '÷' in self.title or '/' in self.title:
                return "{a} / {b}"
            elif 'equal' in title_lower:
                return "{a} == {b}"
            elif 'not equal' in title_lower:
                return "{a} ~= {b}"
            elif 'greater' in title_lower:
                return "{a} > {b}"
            elif 'less' in title_lower:
                return "{a} < {b}"
        
        elif self.block_type == 'variable':
            if 'set' in title_lower:
                return "{var_name} = {value}"
            elif 'get' in title_lower:
                return "{var_name}"
            elif 'increment' in title_lower:
                return "{var_name} = {var_name} + 1"
            elif 'decrement' in title_lower:
                return "{var_name} = {var_name} - 1"
        
        elif self.block_type == 'function':
            if 'quantum' in title_lower:
                return "quantum_state({n_qubits})"
            elif 'gate' in title_lower:
                return "apply_gate({state}, {gate}, {qubit})"
            elif 'measure' in title_lower:
                return "measure({state})"
            elif 'print' in title_lower:
                return 'print({message})'
            elif 'input' in title_lower:
                return 'io.read()'
        
        # Default template for unknown blocks
        return f"-- TODO: Implement {self.title} functionality"
    
    def _get_default_value(self, data_type: str, placeholder: Optional[str] = None) -> str:
        """Get a safe default value for a data type/placeholder."""
        special = {
            'name': 'my_table',
            'variable': 'i',
            'key': 'k',
            'state': 'state',
            'table': '{}',
            'message': '""',
            'prompt': '""',
            'filename': '"file.txt"',
            'content': '""',
            'str': '""',
            'pattern': '""',
            'gate': '"H"',
            'n_qubits': '2',
            'qubit': '0',
            'control': '0',
            'target': '1',
            'end': '10',
            'start': '0',
        }
        if placeholder in special:
            return special[placeholder]
        defaults = {
            'number': '0',
            'string': '""',
            'boolean': 'false',
            'table': '{}',
            'function': 'function() end',
            'any': 'nil'
        }
        return defaults.get(data_type, 'nil')
    
    def generate_complete_code(self) -> str:
        """Generate complete code block with this as entry point"""
        code = f"-- Block: {self.title} (ID: {self.block_id})\n"
        
        # Check what type of code this block needs
        if self.block_type == 'event':
            code += self.generate_lua_code(0)
        elif self.block_type == 'function':
            # Generate function definition
            func_name = self.data.get('function_name', f"block_{self.block_id}")
            params = self.data.get('parameters', '')
            code += f"function {func_name}({params})\n"
            code += self.generate_lua_code(1)
            code += "end\n\n"
            # If it's a main function, add call
            if self.data.get('is_main', False):
                code += f"{func_name}()\n"
        else:
            code += self.generate_lua_code(0)
        
        return code


class BlockScene(QGraphicsScene):
    """Graphics scene for block programming."""

    block_added = Signal(object)
    block_removed = Signal(object)
    connection_created = Signal(object, object)
    connection_removed = Signal(object, object)
    about_to_change = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setSceneRect(-2000, -2000, 4000, 4000)
        self.connecting_socket = None
        self.temp_connection = None

    def blocks(self):
        """Return all LuaBlock items in the scene."""
        return [item for item in self.items() if isinstance(item, LuaBlock)]

    def add_block(self, block_data: Dict[str, Any]) -> Optional[LuaBlock]:
        """Add a block from the library or from a saved project."""
        try:
            self.about_to_change.emit()
            if 'sockets' in block_data or 'id' in block_data:
                block = LuaBlock.from_dict(block_data)
            else:
                block = LuaBlock(block_data['type'], block_data['title'])
                block.description = block_data.get('description', '')
                block.lua_code = block_data.get('lua_code', '')
                block.data = dict(block_data.get('data', {}) or {})
                block.ensure_sockets_for_template()

            if 'position' in block_data:
                block.setPos(
                    block_data['position'].get('x', 100),
                    block_data['position'].get('y', 100),
                )
            else:
                count = len(self.blocks())
                block.setPos(80 + (count % 3) * 270, 80 + (count // 3) * 150)

            self.addItem(block)
            block.block_deleted.connect(self._on_block_deleted)
            block.block_moved.connect(self._on_block_moved)
            for socket in block.sockets.values():
                socket.socket_clicked.connect(self._on_socket_clicked)

            self.block_added.emit(block)
            return block
        except Exception as exc:
            print(f"Error adding block: {exc}")
            return None

    def serialize(self) -> Dict[str, Any]:
        """Serialise blocks and their connections to a JSON-safe dict."""
        blocks = sorted(self.blocks(), key=lambda b: (b.y(), b.x(), b.block_id))
        connections = []
        seen = set()
        for block in blocks:
            for socket in block.sockets.values():
                for conn in socket.connections:
                    start = conn.start_socket
                    end = conn.end_socket
                    if start is None or end is None:
                        continue
                    out_socket = start if start.direction == 'output' else end
                    in_socket = end if out_socket is start else start
                    if out_socket.direction != 'output' or in_socket.direction != 'input':
                        continue
                    key = (
                        out_socket.block.block_id,
                        out_socket.name,
                        in_socket.block.block_id,
                        in_socket.name,
                    )
                    if key in seen:
                        continue
                    seen.add(key)
                    connections.append({
                        'from_block': out_socket.block.block_id,
                        'from_socket': out_socket.name,
                        'to_block': in_socket.block.block_id,
                        'to_socket': in_socket.name,
                    })
        return {
            'version': '2.0',
            'blocks': [block.to_dict() for block in blocks],
            'connections': connections,
        }

    def deserialize(self, data: Dict[str, Any]) -> None:
        """Replace the scene with a saved project."""
        self.clear()
        self.connecting_socket = None
        self.temp_connection = None

        by_id = {}
        for block_data in data.get('blocks', []):
            try:
                block = LuaBlock.from_dict(block_data)
            except Exception as exc:
                print(f"Skipping invalid block: {exc}")
                continue
            self.addItem(block)
            block.block_deleted.connect(self._on_block_deleted)
            block.block_moved.connect(self._on_block_moved)
            for socket in block.sockets.values():
                socket.socket_clicked.connect(self._on_socket_clicked)
            by_id[block.block_id] = block

        for link in data.get('connections', []):
            source = by_id.get(link.get('from_block'))
            target = by_id.get(link.get('to_block'))
            if source is None or target is None:
                continue
            out_socket = source.sockets.get(link.get('from_socket'))
            in_socket = target.sockets.get(link.get('to_socket'))
            if out_socket is not None and in_socket is not None:
                out_socket.connect_to(in_socket)

    def delete_selected_blocks(self) -> int:
        """Delete all selected blocks, returning the number removed."""
        removed = 0
        for item in list(self.selectedItems()):
            if isinstance(item, LuaBlock):
                self._on_block_deleted(item)
                removed += 1
        return removed

    def _on_block_deleted(self, block):
        """Handle block deletion and remove its edges."""
        self.about_to_change.emit()
        for socket in list(block.sockets.values()):
            socket.disconnect()
        for conn in [i for i in self.items() if isinstance(i, Connection)]:
            if conn.start_socket is None or conn.end_socket is None:
                self.removeItem(conn)
        self.removeItem(block)
        self.block_removed.emit(block)

    def _on_block_moved(self, block, pos):
        for socket in block.sockets.values():
            for connection in list(socket.connections):
                connection.update_line()

    def _on_socket_clicked(self, socket):
        """Start or finish a connection when a socket is clicked."""
        if not self.connecting_socket:
            self.connecting_socket = socket
            return

        source = self.connecting_socket
        self.connecting_socket = None
        if self.temp_connection is not None:
            self.removeItem(self.temp_connection)
            self.temp_connection = None

        if source.can_connect_to(socket):
            self.about_to_change.emit()
            if source.connect_to(socket):
                self.connection_created.emit(source, socket)

    def mouseMoveEvent(self, event):
        """Draw the temporary connection preview."""
        if self.connecting_socket:
            if self.temp_connection is None:
                self.temp_connection = Connection(self.connecting_socket, None)
                self.addItem(self.temp_connection)
            scene_pos = event.scenePos()
            start_pos = self.connecting_socket.scenePos()
            start_pos += QPointF(
                self.connecting_socket.SOCKET_SIZE / 2,
                self.connecting_socket.SOCKET_SIZE / 2,
            )
            self.temp_connection.setLine(
                start_pos.x(), start_pos.y(), scene_pos.x(), scene_pos.y()
            )
        super().mouseMoveEvent(event)

    def mousePressEvent(self, event):
        """Cancel an in-progress connection with the right mouse button."""
        if event.button() == Qt.RightButton and self.connecting_socket:
            self.connecting_socket = None
            if self.temp_connection is not None:
                self.removeItem(self.temp_connection)
                self.temp_connection = None
            event.accept()
        else:
            super().mousePressEvent(event)


class BlockProgrammingView(QGraphicsView):
    """Custom view for block programming."""

    def __init__(self, scene: BlockScene, parent=None):
        super().__init__(scene, parent)
        self.setRenderHints(QPainter.Antialiasing | QPainter.TextAntialiasing)
        self.setDragMode(QGraphicsView.RubberBandDrag)
        self.setInteractive(True)
        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.AnchorViewCenter)
        self.setViewportUpdateMode(QGraphicsView.BoundingRectViewportUpdate)
        self.current_zoom = 1.0
        self._apply_theme()

    def _apply_theme(self):
        palette = QApplication.palette()
        self._grid_color = palette.color(QPalette.Mid)
        self._grid_color.setAlpha(45)
        self._major_grid_color = palette.color(QPalette.Mid)
        self._major_grid_color.setAlpha(75)
        self.setBackgroundBrush(QBrush(palette.color(QPalette.Base)))

    def drawBackground(self, painter, rect):
        painter.fillRect(rect, self.backgroundBrush())
        step = 24
        left = int(rect.left()) - (int(rect.left()) % step)
        top = int(rect.top()) - (int(rect.top()) % step)

        minor = QPen(self._grid_color, 1)
        major = QPen(self._major_grid_color, 1)
        painter.setRenderHint(QPainter.Antialiasing, False)

        x = left
        while x < rect.right():
            painter.setPen(major if int(x) % (step * 5) == 0 else minor)
            painter.drawLine(QPointF(x, rect.top()), QPointF(x, rect.bottom()))
            x += step
        y = top
        while y < rect.bottom():
            painter.setPen(major if int(y) % (step * 5) == 0 else minor)
            painter.drawLine(QPointF(rect.left(), y), QPointF(rect.right(), y))
            y += step

    def wheelEvent(self, event):
        """Ctrl+wheel zooms around the cursor."""
        if event.modifiers() & Qt.ControlModifier:
            zoom_in = event.angleDelta().y() > 0
            factor = 1.15 if zoom_in else 1 / 1.15
            new_zoom = self.current_zoom * factor
            if 0.2 <= new_zoom <= 3.0:
                self.scale(factor, factor)
                self.current_zoom = new_zoom
                event.accept()
                return
        super().wheelEvent(event)

    def reset_zoom(self):
        self.resetTransform()
        self.current_zoom = 1.0

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key_Delete, Qt.Key_Backspace):
            scene = self.scene()
            if isinstance(scene, BlockScene):
                scene.delete_selected_blocks()
                event.accept()
                return
        if event.key() == Qt.Key_0 and event.modifiers() & Qt.ControlModifier:
            self.reset_zoom()
            event.accept()
            return
        super().keyPressEvent(event)


class BlockLibraryWidget(QWidget):
    """Searchable block library."""
    
    block_selected = Signal(dict)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.blocks = self._load_block_templates()
        self._items = []
        self._setup_ui()
    
    def _load_block_templates(self) -> Dict[str, List[Dict[str, Any]]]:
        """Load block templates with complete code for all categories"""
        blocks = {
            'Events': [
                {'type': 'event', 'title': 'On Start', 'icon': '🚀',
                'description': 'Executes when program starts', 
                'lua_code': 'print("Program started")'},
                {'type': 'event', 'title': 'On Timer', 'icon': '⏱️',
                'description': 'Executes on timer interval',
                'lua_code': 'print("Timer event triggered")'},
                {'type': 'event', 'title': 'On Click', 'icon': '🖱️',
                'description': 'Executes on mouse click',
                'lua_code': 'print("Mouse clicked!")'},
            ],
            'Control': [
                {'type': 'control', 'title': 'If-Then', 'icon': '🔀',
                'description': 'Conditional execution',
                'lua_code': 'if {condition} then\n    -- then block\nend'},
                {'type': 'control', 'title': 'If-Else', 'icon': '⚖️',
                'description': 'Conditional with else branch',
                'lua_code': 'if {condition} then\n    -- then block\nelse\n    -- else block\nend'},
                {'type': 'control', 'title': 'For Loop', 'icon': '🔄',
                'description': 'For loop with counter',
                'lua_code': 'for {variable} = {start}, {end} do\n    -- loop body\nend'},
                {'type': 'control', 'title': 'While Loop', 'icon': '∞',
                'description': 'While condition is true',
                'lua_code': 'while {condition} do\n    -- loop body\nend'},
                {'type': 'control', 'title': 'Repeat-Until', 'icon': '↩️',
                'description': 'Repeat until condition',
                'lua_code': 'repeat\n    -- loop body\nuntil {condition}'},
            ],
            'Variables': [
                {'type': 'variable', 'title': 'Set Variable', 'icon': '📝',
                'description': 'Set variable value - Double-click to set variable name',
                'lua_code': '{var_name} = {value}'},
                {'type': 'variable', 'title': 'Get Variable', 'icon': '📖',
                'description': 'Get variable value - Double-click to set variable name',
                'lua_code': '{var_name}'},
                {'type': 'variable', 'title': 'Increment', 'icon': '➕',
                'description': 'Increase variable by 1 - Double-click to set variable name',
                'lua_code': '{var_name} = {var_name} + 1'},
                {'type': 'variable', 'title': 'Decrement', 'icon': '➖',
                'description': 'Decrease variable by 1 - Double-click to set variable name',
                'lua_code': '{var_name} = {var_name} - 1'},
            ],
            'Math': [
                {'type': 'operator', 'title': 'Add', 'icon': '+',
                'description': 'Addition operator',
                'lua_code': '{a} + {b}'},
                {'type': 'operator', 'title': 'Subtract', 'icon': '-',
                'description': 'Subtraction operator',
                'lua_code': '{a} - {b}'},
                {'type': 'operator', 'title': 'Multiply', 'icon': '×',
                'description': 'Multiplication operator',
                'lua_code': '{a} * {b}'},
                {'type': 'operator', 'title': 'Divide', 'icon': '÷',
                'description': 'Division operator',
                'lua_code': '{a} / {b}'},
                {'type': 'operator', 'title': 'Modulo', 'icon': '%',
                'description': 'Modulo operator',
                'lua_code': '{a} % {b}'},
                {'type': 'operator', 'title': 'Power', 'icon': '^',
                'description': 'Exponentiation',
                'lua_code': '{a} ^ {b}'},
                {'type': 'operator', 'title': 'Equal', 'icon': '=',
                'description': 'Equality comparison',
                'lua_code': '{a} == {b}'},
                {'type': 'operator', 'title': 'Not Equal', 'icon': '≠',
                'description': 'Inequality comparison',
                'lua_code': '{a} ~= {b}'},
            ],
            'Quantum': [
                {'type': 'function', 'title': 'Quantum State', 'icon': '⚛️',
                'description': 'Create quantum state',
                'lua_code': 'quantum_state({n_qubits})'},
                {'type': 'function', 'title': 'Apply Gate', 'icon': '🔷',
                'description': 'Apply quantum gate',
                'lua_code': 'apply_gate({state}, "{gate}", {qubit})'},
                {'type': 'function', 'title': 'Measure', 'icon': '📏',
                'description': 'Measure quantum state',
                'lua_code': 'measure({state})'},
                {'type': 'function', 'title': 'Hadamard Gate', 'icon': 'H',
                'description': 'Apply Hadamard gate',
                'lua_code': 'apply_gate({state}, "H", {qubit})'},
                {'type': 'function', 'title': 'CNOT Gate', 'icon': '⊕',
                'description': 'Apply CNOT gate',
                'lua_code': 'apply_gate({state}, "CNOT", {control}, {target})'},
                {'type': 'function', 'title': 'Quantum Circuit', 'icon': '🔗',
                'description': 'Create quantum circuit',
                'lua_code': '-- Quantum circuit initialization\nlocal circuit = {}\nprint("Quantum circuit created")'},
            ],
            'Input/Output': [
                {'type': 'function', 'title': 'Print', 'icon': '🖨️',
                'description': 'Print to console',
                'lua_code': 'print({message})'},
                {'type': 'function', 'title': 'Read Input', 'icon': '📥',
                'description': 'Read user input',
                'lua_code': 'local input = io.read()'},
                {'type': 'function', 'title': 'Read File', 'icon': '📄',
                'description': 'Read from file',
                'lua_code': 'local file = io.open("{filename}", "r")\nlocal content = file:read("*a")\nfile:close()'},
                {'type': 'function', 'title': 'Write File', 'icon': '📝',
                'description': 'Write to file',
                'lua_code': 'local file = io.open("{filename}", "w")\nfile:write("{content}")\nfile:close()'},
            ],
            'File I/O': [
                {'type': 'function', 'title': 'Read File', 'icon': '📄',
                'description': 'Read entire file content',
                'lua_code': 'local content = read_file({filename})'},
                {'type': 'action', 'title': 'Write File', 'icon': '💾',
                'description': 'Write content to file',
                'lua_code': 'write_file({filename}, {content})'},
                {'type': 'action', 'title': 'Append to File', 'icon': '➕',
                'description': 'Append content to file',
                'lua_code': 'local file = io.open({filename}, "a")\nfile:write({content})\nfile:close()'},
            ],
            'String Operations': [
                {'type': 'operator', 'title': 'String Length', 'icon': '📏',
                'description': 'Get string length',
                'lua_code': '#{str}'},
                {'type': 'operator', 'title': 'String Upper', 'icon': '🔠',
                'description': 'Convert to uppercase',
                'lua_code': 'string.upper({str})'},
                {'type': 'operator', 'title': 'String Lower', 'icon': '🔡',
                'description': 'Convert to lowercase',
                'lua_code': 'string.lower({str})'},
                {'type': 'function', 'title': 'String Substring', 'icon': '✂️',
                'description': 'Extract substring',
                'lua_code': 'string.sub({str}, {start}, {end})'},
                {'type': 'function', 'title': 'String Find', 'icon': '🔍',
                'description': 'Find pattern in string',
                'lua_code': 'string.find({str}, {pattern})'},
                {'type': 'operator', 'title': 'String Concat', 'icon': '➕',
                'description': 'Concatenate strings',
                'lua_code': '{a} .. {b}'},
            ],
            'Table Operations': [
                {'type': 'variable', 'title': 'Create Table', 'icon': '📋',
                'description': 'Create new table',
                'lua_code': 'local {name} = {}'},
                {'type': 'action', 'title': 'Table Insert', 'icon': '📥',
                'description': 'Insert value into table',
                'lua_code': 'table.insert({table}, {value})'},
                {'type': 'action', 'title': 'Table Remove', 'icon': '📤',
                'description': 'Remove value from table',
                'lua_code': 'table.remove({table}, {index})'},
                {'type': 'control', 'title': 'For Each', 'icon': '🔄',
                'description': 'Iterate over table',
                'lua_code': 'for {key}, {value} in pairs({table}) do\n    -- body\nend'},
                {'type': 'function', 'title': 'Table Length', 'icon': '📏',
                'description': 'Get table length',
                'lua_code': '#{table}'},
            ],
            'User Input': [
                {'type': 'function', 'title': 'Print', 'icon': '🖨️',
                'description': 'Print to console',
                'lua_code': 'print({message})'},
                {'type': 'function', 'title': 'Input', 'icon': '⌨️',
                'description': 'Get user input',
                'lua_code': 'local input = io.read()'},
                {'type': 'function', 'title': 'Input with Prompt', 'icon': '💬',
                'description': 'Prompt and get input',
                'lua_code': 'io.write({prompt})\nlocal input = io.read()'},
            ],
            'Advanced Math': [
                {'type': 'function', 'title': 'Random Number', 'icon': '🎲',
                'description': 'Generate random number',
                'lua_code': 'math.random({min}, {max})'},
                {'type': 'function', 'title': 'Square Root', 'icon': '√',
                'description': 'Calculate square root',
                'lua_code': 'math.sqrt({x})'},
                {'type': 'function', 'title': 'Power', 'icon': '^',
                'description': 'Raise to power',
                'lua_code': 'math.pow({x}, {y})'},
                {'type': 'function', 'title': 'Absolute Value', 'icon': '|x|',
                'description': 'Get absolute value',
                'lua_code': 'math.abs({x})'},
                {'type': 'function', 'title': 'Round', 'icon': '○',
                'description': 'Round number',
                'lua_code': 'math.floor({x} + 0.5)'},
            ],
        }
        return blocks
    
    def _setup_ui(self):
        """Build the search field and a category tree of blocks."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)

        self.search = QLineEdit()
        self.search.setPlaceholderText("Search blocks...")
        self.search.setClearButtonEnabled(True)
        self.search.setToolTip("Filter by block name, description or category (Ctrl+F)")
        self.search.textChanged.connect(self._apply_filter)
        layout.addWidget(self.search)

        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setIndentation(12)
        self.tree.setAlternatingRowColors(True)
        self.tree.setMinimumWidth(260)
        self.tree.setRootIsDecorated(True)
        self.tree.itemClicked.connect(self._on_tree_item_clicked)

        type_colors = {
            'event': QColor('#009688'),
            'action': QColor('#9c27b0'),
            'control': QColor('#ff5722'),
            'variable': QColor('#03a9f4'),
            'function': QColor('#4caf50'),
            'operator': QColor('#ffc107'),
            'value': QColor('#795548'),
        }
        bold = QFont()
        bold.setBold(True)

        for category, block_list in self.blocks.items():
            category_item = QTreeWidgetItem([f"{category}  ({len(block_list)})"])
            category_item.setFlags(Qt.ItemIsEnabled)
            category_item.setFont(0, bold)
            self.tree.addTopLevelItem(category_item)

            for block_data in block_list:
                item = QTreeWidgetItem(
                    [f"{block_data.get('icon', '▢')}  {block_data['title']}"]
                )
                item.setData(0, Qt.UserRole, block_data)
                item.setToolTip(
                    0,
                    f"{block_data.get('title')}\n{block_data.get('description', '')}\n\n"
                    "Click to add it to the canvas.",
                )
                color = type_colors.get(block_data.get('type'))
                if color is not None:
                    item.setForeground(0, QBrush(color))
                category_item.addChild(item)
                self._items.append((item, block_data, category))

            category_item.setExpanded(True)

        layout.addWidget(self.tree, 1)

    def _on_tree_item_clicked(self, item, column):
        data = item.data(0, Qt.UserRole)
        if isinstance(data, dict):
            self.block_selected.emit(data)

    def _apply_filter(self, text: str):
        """Show only matching blocks; hide categories with no matches."""
        query = text.strip().lower()
        for index in range(self.tree.topLevelItemCount()):
            category_item = self.tree.topLevelItem(index)
            visible_children = 0
            for child_index in range(category_item.childCount()):
                child = category_item.child(child_index)
                data = child.data(0, Qt.UserRole) or {}
                haystack = " ".join(
                    [
                        data.get('title', ''),
                        data.get('description', ''),
                        category_item.text(0),
                    ]
                ).lower()
                visible = not query or query in haystack
                child.setHidden(not visible)
                if visible:
                    visible_children += 1
            category_item.setHidden(visible_children == 0)
            if query and visible_children:
                category_item.setExpanded(True)

    def _on_block_clicked(self, button):
        """Handle block selection (kept for compatibility)."""
        self.block_selected.emit(button.block_data)


class LuaHighlighter(QSyntaxHighlighter):
    """Small, theme-aware Lua syntax highlighter for the code preview."""

    def __init__(self, document):
        super().__init__(document)
        palette = QApplication.palette()
        dark = palette.color(QPalette.Window).lightness() < 128

        keyword = QColor("#c792ea") if dark else QColor("#6a1b9a")
        string = QColor("#a5d6a7") if dark else QColor("#2e7d32")
        comment = QColor("#8a8f98") if dark else QColor("#6b7280")
        number = QColor("#ffb74d") if dark else QColor("#c2410c")
        builtin = QColor("#82aaff") if dark else QColor("#1565c0")

        def fmt(color, bold=False):
            f = QTextCharFormat()
            f.setForeground(color)
            if bold:
                f.setFontWeight(QFont.Bold)
            return f

        self._rules = [
            (re.compile(r"--[^\n]*"), fmt(comment)),
            (re.compile(r'"[^"\\]*(\\.[^"\\]*)*"'), fmt(string)),
            (re.compile(r"'[^'\\]*(\\.[^'\\]*)*'"), fmt(string)),
            (
                re.compile(
                    r"\b(and|break|do|else|elseif|end|false|for|function|goto|if|in|"
                    r"local|nil|not|or|repeat|return|then|true|until|while)\b"
                ),
                fmt(keyword, True),
            ),
            (
                re.compile(
                    r"\b(print|pairs|ipairs|table|string|math|io|os|require|pcall|"
                    r"type|tostring|tonumber|error|assert)\b"
                ),
                fmt(builtin),
            ),
            (re.compile(r"\b\d+(\.\d+)?\b"), fmt(number)),
        ]

    def highlightBlock(self, text):
        for pattern, text_format in self._rules:
            for match in pattern.finditer(text):
                self.setFormat(match.start(), match.end() - match.start(), text_format)


class CodePreviewWidget(QTextEdit):
    """Read-only Lua code preview with syntax highlighting."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setReadOnly(True)
        self.setLineWrapMode(QTextEdit.NoWrap)
        font = QFont("Consolas", 10)
        font.setStyleHint(QFont.Monospace)
        font.setFixedPitch(True)
        self.setFont(font)
        self.highlighter = LuaHighlighter(self.document())

    def update_code(self, code: str):
        """Replace the displayed code and scroll to the top."""
        self.setPlainText(code)
        cursor = self.textCursor()
        cursor.movePosition(QTextCursor.Start)
        self.setTextCursor(cursor)