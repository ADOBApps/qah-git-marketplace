"""PyDFT Workbench widget.

Detects pydft from an injected Wheel Plugin Manager vendor path and runs a
small restricted Kohn-Sham DFT calculation (CO, STO-3G, svwn5).
"""

from __future__ import annotations

import importlib
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, Optional

from PySide6.QtCore import QThread, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QComboBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

MOLECULES = ("CO", "H2O", "H2", "N2")
FUNCTIONALS = ("svwn5", "svwn3", "pbe")
TOLERANCES = (("1e-3 (fast)", 1e-3), ("1e-4 (balanced)", 1e-4), ("1e-5 (tight)", 1e-5))


def qah_home() -> Path:
    override = os.environ.get("QAH_HOME")
    return Path(override).expanduser() if override else Path.home() / "QAH"


def activate_vendor(targets=("pydft_workbench", "global")) -> list:
    root = qah_home() / "plugins" / "vendor"
    added = []
    for target in targets:
        path = root / target
        if path.is_dir() and str(path) not in sys.path:
            sys.path.insert(0, str(path))
            added.append(str(path))
    if added:
        importlib.invalidate_caches()
    return added


def probe_dependencies(force: bool = False) -> Dict[str, Any]:
    activate_vendor()
    result: Dict[str, Any] = {
        "ok": False,
        "python": sys.version.split()[0],
        "error": "",
        "versions": {},
    }
    try:
        import pydft
        import pyqint
        result["versions"]["pydft"] = getattr(pydft, "__version__", "")
        result["versions"]["pyqint"] = getattr(pyqint, "__version__", "")
        try:
            import pylebedev
            result["versions"]["pylebedev"] = getattr(pylebedev, "__version__", "")
        except Exception:
            result["versions"]["pylebedev"] = "missing"
        result["ok"] = True
        result["pydft_file"] = getattr(pydft, "__file__", "")
    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
    return result


def run_demo(molecule: str, functional: str, tolerance: float) -> Dict[str, Any]:
    activate_vendor()
    from pyqint import MoleculeBuilder
    from pydft import DFT

    started = time.time()
    mol = MoleculeBuilder.from_name(molecule)
    dft = DFT(mol, basis="sto3g", functional=functional)
    result = dft.scf(tolerance)
    orbe = result.get("orbe")
    if orbe is None:
        orbe = []
    nelec = int(result.get("nelec") or 0)
    nocc = max(0, nelec // 2)
    homo = float(orbe[nocc - 1]) if len(orbe) >= nocc else None
    lumo = float(orbe[nocc]) if len(orbe) > nocc else None
    gap = (lumo - homo) if homo is not None and lumo is not None else None
    return {
        "molecule": molecule,
        "functional": functional,
        "tolerance": tolerance,
        "energy": float(result.get("energy") or 0.0),
        "homo": homo,
        "lumo": lumo,
        "gap": gap,
        "nelec": nelec,
        "iterations": len(result.get("energies") or []),
        "seconds": time.time() - started,
    }


class DemoWorker(QThread):
    done = Signal(dict)
    failed = Signal(str)

    def __init__(self, molecule, functional, tolerance, parent=None):
        super().__init__(parent)
        self.molecule = molecule
        self.functional = functional
        self.tolerance = tolerance

    def run(self):
        try:
            self.done.emit(run_demo(self.molecule, self.functional, self.tolerance))
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class PyDFTWidget(QWidget):
    def __init__(self, plugin=None, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.worker: Optional[DemoWorker] = None
        self.dependency: Dict[str, Any] = {}
        self._build_ui()
        self._detect(show_message=False)

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        header = QHBoxLayout()
        title = QLabel("<b>PyDFT Workbench</b>")
        title.setFont(QFont("Segoe UI", 15, QFont.Weight.Bold))
        header.addWidget(title)
        subtitle = QLabel("Localized-orbital DFT demo · educational")
        subtitle.setStyleSheet("color:#6b7280;")
        header.addWidget(subtitle, 1)
        self.dependency_badge = QLabel("Checking pydft…")
        self.dependency_badge.setStyleSheet("color:#b45309;")
        header.addWidget(self.dependency_badge)
        layout.addLayout(header)

        info = QGroupBox("Dependency probe")
        info_layout = QVBoxLayout(info)
        self.dependency_text = QLabel("")
        self.dependency_text.setWordWrap(True)
        self.dependency_text.setTextInteractionFlags(
            self.dependency_text.textInteractionFlags()
        )
        info_layout.addWidget(self.dependency_text)
        row = QHBoxLayout()
        detect = QPushButton("Detect dependencies")
        detect.clicked.connect(lambda _checked=False: self._detect(show_message=True))
        row.addWidget(detect)
        row.addStretch(1)
        info_layout.addLayout(row)
        layout.addWidget(info)

        form_box = QGroupBox("Calculation")
        form = QFormLayout(form_box)
        self.molecule_combo = QComboBox()
        self.molecule_combo.addItems(MOLECULES)
        form.addRow("Molecule:", self.molecule_combo)
        self.functional_combo = QComboBox()
        self.functional_combo.addItems(FUNCTIONALS)
        form.addRow("Functional:", self.functional_combo)
        self.tolerance_combo = QComboBox()
        for label, value in TOLERANCES:
            self.tolerance_combo.addItem(label, value)
        form.addRow("SCF tolerance:", self.tolerance_combo)
        layout.addWidget(form_box)

        actions = QHBoxLayout()
        self.run_button = QPushButton("Run DFT demo")
        self.run_button.clicked.connect(lambda _checked=False: self._run())
        actions.addWidget(self.run_button)
        actions.addStretch(1)
        layout.addLayout(actions)

        self.output = QPlainTextEdit()
        self.output.setReadOnly(True)
        self.output.setFont(QFont("Consolas", 9))
        self.output.setPlaceholderText(
            "pydft results: energy, HOMO/LUMO, gap, SCF iterations."
        )
        layout.addWidget(self.output, 1)

        self.status = QLabel("Ready")
        self.status.setStyleSheet("color:#6b7280;")
        layout.addWidget(self.status)

    def _detect(self, show_message: bool = False):
        self.dependency = probe_dependencies(force=True)
        versions = self.dependency.get("versions") or {}
        if self.dependency.get("ok"):
            self.dependency_badge.setText(f"pydft {versions.get('pydft', '')}")
            self.dependency_badge.setStyleSheet("color:#15803d;")
            self.dependency_text.setText(
                "pydft {} · pyqint {} · pylebedev {} · Python {}".format(
                    versions.get("pydft", "?"),
                    versions.get("pyqint", "?"),
                    versions.get("pylebedev", "?"),
                    self.dependency.get("python", "?"),
                )
            )
            self.run_button.setEnabled(True)
            self.status.setText("pydft detected; ready to run.")
        else:
            self.dependency_badge.setText("pydft not injected")
            self.dependency_badge.setStyleSheet("color:#b45309;")
            self.dependency_text.setText(
                "pydft is not available yet.\n\n"
                "Inject it from Wheel Plugin Manager:\n"
                "  Package: pydft\n"
                "  Target : global\n\n"
                "Then press Detect dependencies. No QAH restart is required "
                "for this plugin."
            )
            self.run_button.setEnabled(False)
            self.status.setText(self.dependency.get("error", "pydft missing"))
            if show_message:
                QMessageBox.information(
                    self,
                    "PyDFT Workbench dependencies",
                    "pydft is not available yet.\n\n"
                    "Install it with Wheel Plugin Manager (Package: pydft, "
                    "Target: global), then press Detect dependencies.",
                )

    def _run(self):
        if self.worker is not None and self.worker.isRunning():
            return
        if not (self.dependency.get("versions") or {}).get("pydft"):
            self._detect(show_message=True)
            return
        molecule = self.molecule_combo.currentText()
        functional = self.functional_combo.currentText()
        tolerance = float(self.tolerance_combo.currentData() or 1e-3)
        self.run_button.setEnabled(False)
        self.status.setText(f"Running {molecule}/{functional}…")
        self.output.setPlainText(
            f"Running pydft\n"
            f"  molecule  : {molecule}\n"
            f"  basis     : sto3g\n"
            f"  functional: {functional}\n"
            f"  tolerance : {tolerance:g}\n"
        )
        worker = DemoWorker(molecule, functional, tolerance, self)
        worker.done.connect(self._on_done)
        worker.failed.connect(self._on_failed)
        worker.finished.connect(worker.deleteLater)
        self.worker = worker
        worker.start()

    def _on_done(self, result: Dict[str, Any]):
        self.worker = None
        self.run_button.setEnabled(True)
        homo = result.get("homo")
        lumo = result.get("lumo")
        gap = result.get("gap")
        lines = [
            "pydft result",
            "============",
            f"Molecule   : {result['molecule']}",
            f"Basis      : sto3g",
            f"Functional : {result['functional']}",
            f"Tolerance  : {result['tolerance']:g}",
            f"Energy     : {result['energy']:.8f} Ha",
            f"Electrons  : {result['nelec']}",
            f"SCF iters  : {result['iterations']}",
            f"Time       : {result['seconds']:.2f} s",
        ]
        if homo is not None:
            lines.append(f"HOMO       : {homo:.6f} Ha")
        if lumo is not None:
            lines.append(f"LUMO       : {lumo:.6f} Ha")
        if gap is not None:
            lines.append(f"Gap        : {gap:.6f} Ha")
        self.output.setPlainText("\n".join(lines))
        self.status.setText("Calculation complete.")
        self._detect(show_message=False)

    def _on_failed(self, message: str):
        self.worker = None
        self.run_button.setEnabled(True)
        self.output.setPlainText(f"pydft calculation failed:\n\n{message}")
        self.status.setText("Calculation failed.")
        QMessageBox.critical(self, "PyDFT Workbench", message)

    def cleanup(self):
        if self.worker is not None:
            self.worker.wait(3000)
            if self.worker.isRunning():
                self.worker.setParent(None)
                self.worker.finished.connect(self.worker.deleteLater)
            else:
                self.worker.deleteLater()
        self.worker = None
