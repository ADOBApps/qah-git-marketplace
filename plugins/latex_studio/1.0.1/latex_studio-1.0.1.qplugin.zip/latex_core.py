"""Core services for LaTeX Studio.

Project model, LaTeX build runner and Git-relay operations.
GPL-3.0-or-later.
"""

from __future__ import annotations

import base64
import json
import os
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

HOME = Path.home()
ROOT = HOME / "QAH" / "latex_studio"
PROJECTS = ROOT / "projects"
SETTINGS_PATH = ROOT / "settings.json"
META_NAME = ".latexstudio.json"

DEFAULT_ENGINE = "latexmk-pdf"
ENGINES = [
    ("latexmk-pdf", "latexmk - PDF"),
    ("latexmk-xelatex", "latexmk - XeLaTeX"),
    ("latexmk-lualatex", "latexmk - LuaLaTeX"),
    ("pdflatex", "pdflatex (direct)"),
    ("xelatex", "xelatex (direct)"),
    ("lualatex", "lualatex (direct)"),
]
AUX_SUFFIXES = {
    ".aux", ".log", ".out", ".toc", ".lof", ".lot", ".fls", ".fdb_latexmk",
    ".synctex.gz", ".bbl", ".blg", ".nav", ".snm", ".vrb", ".xdv",
}
IGNORE_DIRS = {".git", "__pycache__", "build", "out", ".venv", "venv", "node_modules"}

DEFAULT_SETTINGS = {
    "projects_root": str(PROJECTS),
    "default_engine": DEFAULT_ENGINE,
    "git": {
        "token": "",
        "branch": "main",
        "poll_seconds": 60,
        "auto_pull": False,
        "name": "",
        "email": "",
    },
    "editor": {"font_size": 11, "wrap": False},
}


def ensure_dirs() -> None:
    PROJECTS.mkdir(parents=True, exist_ok=True)


def _merge(base: Dict[str, Any], incoming: Any) -> Dict[str, Any]:
    result = dict(base)
    if isinstance(incoming, dict):
        for key, value in incoming.items():
            if isinstance(value, dict) and isinstance(result.get(key), dict):
                result[key] = _merge(result[key], value)
            else:
                result[key] = value
    return result


def load_settings() -> Dict[str, Any]:
    ensure_dirs()
    try:
        data = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
    except Exception:
        data = {}
    return _merge(DEFAULT_SETTINGS, data)


def save_settings(settings: Dict[str, Any]) -> None:
    ensure_dirs()
    SETTINGS_PATH.write_text(json.dumps(settings, indent=2), encoding="utf-8")
    try:
        if os.name != "nt":
            os.chmod(SETTINGS_PATH, 0o600)
    except OSError:
        pass


def projects_root() -> Path:
    settings = load_settings()
    root = Path(settings.get("projects_root") or PROJECTS).expanduser()
    root.mkdir(parents=True, exist_ok=True)
    return root


def _safe_name(name: str) -> str:
    clean = "".join(ch if ch.isalnum() or ch in "-_." else "_" for ch in name.strip())
    clean = clean.strip("._")
    return clean or "paper"


def _write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _article_tex(title: str, template: str) -> str:
    if template == "report":
        document = "report"
    elif template == "beamer":
        document = "beamer"
    else:
        document = "article"
    if template == "beamer":
        body = r"""\begin{frame}{Introduction}
Write your first slide here.
\end{frame}

\begin{frame}{Results}
Add results here.
\end{frame}
"""
    else:
        body = r"""\input{sections/introduction}

\section{Methods}
Describe the methods.

\section{Results}
Present the results.

\section{Conclusions}
State the conclusions.

\bibliographystyle{plain}
\bibliography{references}
"""
    return rf"""\documentclass[11pt]{{{document}}}
\usepackage[utf8]{{inputenc}}
\usepackage[T1]{{fontenc}}
\usepackage{{lmodern}}
\usepackage{{amsmath,amssymb}}
\usepackage{{graphicx}}
\usepackage{{booktabs}}
\usepackage{{hyperref}}
\title{{{title}}}
\author{{Author}}
\date{{\today}}

\begin{{document}}
\maketitle

{body}
\end{{document}}
"""


def create_project(name: str, template: str = "article") -> Path:
    ensure_dirs()
    root = projects_root()
    base = _safe_name(name)
    destination = root / base
    counter = 2
    while destination.exists():
        destination = root / f"{base}-{counter}"
        counter += 1
    destination.mkdir(parents=True)
    (destination / "sections").mkdir()
    (destination / "figures").mkdir()
    _write(destination / "main.tex", _article_tex(name.strip() or base, template))
    _write(
        destination / "sections" / "introduction.tex",
        "\\section{Introduction}\nStart writing here. Cite an example \\cite{example}.\n",
    )
    _write(
        destination / "references.bib",
        "@article{example,\n"
        "  author = {Doe, Jane},\n"
        "  title = {An Example Reference},\n"
        "  journal = {Journal of Examples},\n"
        "  year = {2026}\n"
        "}\n",
    )
    _write(
        destination / "README.md",
        f"# {name.strip() or base}\n\n"
        "LaTeX Studio project. Main file: `main.tex`.\n\n"
        "Build with latexmk or pdflatex, then commit and push to your Git relay.\n",
    )
    _write(
        destination / ".gitignore",
        "*.aux\n*.log\n*.out\n*.toc\n*.lof\n*.lot\n*.fls\n*.fdb_latexmk\n"
        "*.synctex.gz\n*.bbl\n*.blg\n*.pdf\nbuild/\n",
    )
    write_meta(
        destination,
        {"format": 1, "name": name.strip() or base, "main": "main.tex",
         "engine": DEFAULT_ENGINE, "template": template,
         "created": time.strftime("%Y-%m-%dT%H:%M:%S")},
    )
    if shutil.which("git"):
        init_repo(destination)
    return destination


def write_meta(project: Path, meta: Dict[str, Any]) -> None:
    project = Path(project)
    (project / META_NAME).write_text(json.dumps(meta, indent=2), encoding="utf-8")


def read_meta(project: Path) -> Dict[str, Any]:
    try:
        data = json.loads((Path(project) / META_NAME).read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    main = detect_main(Path(project))
    return {"format": 1, "name": Path(project).name, "main": main.name if main else "main.tex",
            "engine": DEFAULT_ENGINE}


def ensure_meta(project: Path) -> Dict[str, Any]:
    project = Path(project)
    if not (project / META_NAME).is_file():
        write_meta(project, read_meta(project))
    return read_meta(project)


def list_projects() -> List[Dict[str, Any]]:
    root = projects_root()
    result: List[Dict[str, Any]] = []
    for folder in sorted(root.iterdir()):
        if not folder.is_dir() or folder.name.startswith("."):
            continue
        meta = read_meta(folder)
        result.append({
            "path": str(folder),
            "name": meta.get("name") or folder.name,
            "main": meta.get("main") or "",
            "engine": meta.get("engine") or DEFAULT_ENGINE,
        })
    return result


def detect_main(project: Path) -> Optional[Path]:
    project = Path(project)
    candidate = ""
    try:
        data = json.loads((project / META_NAME).read_text(encoding="utf-8"))
        if isinstance(data, dict):
            candidate = str(data.get("main") or "")
    except Exception:
        candidate = ""
    if candidate:
        path = project / candidate
        if path.is_file():
            return path
    for name in ("main.tex", "paper.tex", "article.tex"):
        path = project / name
        if path.is_file():
            return path
    tex = sorted(path for path in project.glob("*.tex") if path.is_file())
    return tex[0] if tex else None


def tex_files(project: Path) -> List[Path]:
    project = Path(project)
    result = []
    for path in sorted(project.rglob("*.tex")):
        if any(part in IGNORE_DIRS for part in path.relative_to(project).parts):
            continue
        result.append(path)
    return result


def project_files(project: Path) -> List[Path]:
    project = Path(project)
    result = []
    for path in sorted(project.rglob("*")):
        rel = path.relative_to(project)
        if any(part in IGNORE_DIRS for part in rel.parts):
            continue
        if path.is_file() and path.suffix.lower() not in AUX_SUFFIXES:
            result.append(path)
    return result


def pdf_for(project: Path, main: Optional[Path] = None) -> Optional[Path]:
    project = Path(project)
    main = main or detect_main(project)
    if main is None:
        return None
    pdf = main.with_suffix(".pdf")
    return pdf if pdf.is_file() else None


# -- build -------------------------------------------------------------------


def _popup_kwargs() -> Dict[str, Any]:
    if os.name == "nt":
        return {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0)}
    return {}


def _run_build_command(
    command: List[str],
    cwd: Path,
    timeout: int,
    log: List[str],
    process_callback: Optional[Callable[[subprocess.Popen], None]] = None,
) -> int:
    log.append("$ " + " ".join(command))
    try:
        proc = subprocess.Popen(
            command,
            cwd=str(cwd),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            **_popup_kwargs(),
        )
    except OSError as exc:
        log.append(f"Could not start build: {exc}")
        return 127
    if process_callback is not None:
        process_callback(proc)
    try:
        output, _ = proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        log.append(f"Build timed out after {timeout}s")
        try:
            proc.kill()
        except Exception:
            pass
        output, _ = proc.communicate()
    if output:
        log.append(output.rstrip())
    return int(proc.returncode or 0)


def build_project(
    project: Path,
    main: Optional[Path] = None,
    engine: str = DEFAULT_ENGINE,
    timeout: int = 180,
    process_callback: Optional[Callable[[subprocess.Popen], None]] = None,
) -> Dict[str, Any]:
    project = Path(project)
    main = Path(main) if main else detect_main(project)
    if main is None or not main.is_file():
        return {"ok": False, "log": "No main .tex file found.", "pdf": None,
                "returncode": -1, "command": ""}
    if main.parent != project:
        # Keep the build output next to the selected main file.
        build_root = main.parent
    else:
        build_root = project

    log: List[str] = []
    started = time.time()
    command: List[str] = []
    latexmk = shutil.which("latexmk")
    if latexmk and engine.startswith("latexmk"):
        flag = "-pdf"
        if engine.endswith("xelatex"):
            flag = "-xelatex"
        elif engine.endswith("lualatex"):
            flag = "-lualatex"
        command = [
            latexmk, flag, "-interaction=nonstopmode", "-file-line-error",
            "-synctex=1", main.name,
        ]
        rc = _run_build_command(command, build_root, timeout, log, process_callback)
    elif not latexmk and engine.startswith("latexmk"):
        log.append("latexmk was not found on PATH; falling back to a direct engine.")
        engine = "pdflatex"
        command = []
        rc = 127
    else:
        rc = 0

    if not command:
        exe_name = engine if engine in ("pdflatex", "xelatex", "lualatex") else "pdflatex"
        exe = shutil.which(exe_name)
        if not exe:
            return {"ok": False, "log": "\n".join(log + [f"{exe_name} was not found on PATH."]),
                    "pdf": None, "returncode": 127, "command": exe_name}
        command = [exe, "-interaction=nonstopmode", "-file-line-error", main.name]
        rc = _run_build_command(command, build_root, timeout, log, process_callback)
        bibtex = shutil.which("bibtex")
        if rc == 0 and bibtex and (build_root / "references.bib").is_file():
            rc = _run_build_command([bibtex, main.stem], build_root, timeout, log, process_callback)
        if rc == 0:
            rc = _run_build_command(command, build_root, timeout, log, process_callback)
        if rc == 0:
            rc = _run_build_command(command, build_root, timeout, log, process_callback)

    pdf = build_root / (main.stem + ".pdf")
    ok = rc == 0 and pdf.is_file()
    if ok:
        log.append(f"Build OK: {pdf}")
    else:
        log.append(f"Build failed with exit code {rc}.")
    return {
        "ok": ok,
        "log": "\n".join(log),
        "pdf": str(pdf) if pdf.is_file() else None,
        "returncode": rc,
        "command": " ".join(command),
        "duration": round(time.time() - started, 2),
    }


# -- git relay ---------------------------------------------------------------


def git_available() -> bool:
    return shutil.which("git") is not None


def _auth_args(token: str) -> List[str]:
    token = (token or "").strip()
    if not token:
        return []
    raw = base64.b64encode(f"x-access-token:{token}".encode("utf-8")).decode("ascii")
    return ["-c", f"http.extraHeader=Authorization: Basic {raw}"]


def run_git(
    project: Optional[Path],
    args: List[str],
    *,
    token: str = "",
    timeout: int = 120,
    cwd: Optional[Path] = None,
) -> Dict[str, Any]:
    if not git_available():
        return {"ok": False, "code": 127, "stdout": "", "stderr": "Git was not found on PATH."}
    command = ["git"] + _auth_args(token)
    if project is not None:
        command += ["-C", str(project)]
    command += list(args)
    env = os.environ.copy()
    env["GIT_TERMINAL_PROMPT"] = "0"
    env.setdefault("GIT_EDITOR", "true")
    env.setdefault("GIT_SEQUENCE_EDITOR", "true")
    started = time.time()
    try:
        completed = subprocess.run(
            command,
            cwd=str(cwd) if cwd else None,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            env=env,
            **_popup_kwargs(),
        )
    except subprocess.TimeoutExpired:
        return {"ok": False, "code": 124, "stdout": "", "stderr": f"Git timed out after {timeout}s.",
                "duration": round(time.time() - started, 2), "command": " ".join(command)}
    return {
        "ok": completed.returncode == 0,
        "code": completed.returncode,
        "stdout": completed.stdout.strip(),
        "stderr": completed.stderr.strip(),
        "duration": round(time.time() - started, 2),
        "command": " ".join(command),
    }


def is_repo(project: Path) -> bool:
    return (Path(project) / ".git").exists()


def init_repo(project: Path) -> Dict[str, Any]:
    project = Path(project)
    if is_repo(project):
        return {"ok": True, "stdout": "Repository already initialized.", "stderr": "", "code": 0}
    result = run_git(project, ["init", "-b", "main"])
    if not result["ok"]:
        result = run_git(project, ["init"])
        if result["ok"]:
            run_git(project, ["symbolic-ref", "HEAD", "refs/heads/main"])
    return result


def set_remote(project: Path, url: str) -> Dict[str, Any]:
    url = (url or "").strip()
    if not url:
        return {"ok": False, "stderr": "Remote URL is empty.", "stdout": "", "code": 1}
    existing = run_git(project, ["remote", "get-url", "origin"])
    if existing["ok"]:
        return run_git(project, ["remote", "set-url", "origin", url])
    return run_git(project, ["remote", "add", "origin", url])


def set_identity(project: Path, name: str, email: str) -> None:
    if name.strip():
        run_git(project, ["config", "user.name", name.strip()])
    if email.strip():
        run_git(project, ["config", "user.email", email.strip()])


def status(project: Path) -> Dict[str, Any]:
    project = Path(project)
    if not is_repo(project):
        return {"repo": False, "branch": "", "dirty": False, "ahead": 0, "behind": 0,
                "remote": "", "last": "", "conflicts": []}
    res = run_git(project, ["status", "--porcelain=v1", "-b"])
    if not res["ok"]:
        return {"repo": True, "error": res["stderr"] or res["stdout"], "conflicts": []}
    branch = ""
    ahead = behind = 0
    dirty = False
    for line in res["stdout"].splitlines():
        if line.startswith("## "):
            header = line[3:]
            branch = header.split("...")[0].strip()
            if "[" in header and "]" in header:
                states = header.split("[", 1)[1].split("]", 1)[0]
                for part in states.split(","):
                    part = part.strip()
                    if part.startswith("ahead "):
                        ahead = int(part.split()[1])
                    elif part.startswith("behind "):
                        behind = int(part.split()[1])
        elif line.strip():
            dirty = True
    remote = run_git(project, ["remote", "get-url", "origin"])
    last = run_git(project, ["log", "-1", "--format=%h  %s  (%cr)"])
    conflicts = run_git(project, ["diff", "--name-only", "--diff-filter=U"])
    return {
        "repo": True,
        "branch": branch or "main",
        "dirty": dirty,
        "ahead": ahead,
        "behind": behind,
        "remote": remote["stdout"] if remote["ok"] else "",
        "last": last["stdout"] if last["ok"] else "",
        "conflicts": [line for line in conflicts["stdout"].splitlines() if line.strip()],
    }


def commit(project: Path, message: str, name: str = "", email: str = "") -> Dict[str, Any]:
    add = run_git(project, ["add", "-A"])
    if not add["ok"]:
        return add
    pending = run_git(project, ["status", "--porcelain"])
    if not pending["stdout"].strip():
        return {"ok": True, "code": 0, "stdout": "Nothing to commit.", "stderr": ""}
    args = ["commit", "-m", message.strip() or "Update paper"]
    if name.strip():
        args = ["-c", f"user.name={name.strip()}"] + args
    if email.strip():
        args = ["-c", f"user.email={email.strip()}"] + args
    return run_git(project, args)


def pull(project: Path, branch: str = "main", token: str = "", rebase: bool = True) -> Dict[str, Any]:
    args = ["pull"]
    if rebase:
        args.append("--rebase")
    if branch:
        args += ["origin", branch]
    result = run_git(project, args, token=token)
    if not result["ok"]:
        conflicts = run_git(project, ["diff", "--name-only", "--diff-filter=U"])
        result["conflicts"] = [line for line in conflicts["stdout"].splitlines() if line.strip()]
    else:
        result["conflicts"] = []
    return result


def push(project: Path, branch: str = "main", token: str = "") -> Dict[str, Any]:
    return run_git(project, ["push", "-u", "origin", branch], token=token)


def sync(project: Path, branch: str = "main", token: str = "") -> Dict[str, Any]:
    pulled = pull(project, branch, token)
    if not pulled["ok"]:
        return pulled
    return push(project, branch, token)


def continue_rebase(project: Path) -> Dict[str, Any]:
    add = run_git(project, ["add", "-A"])
    if not add["ok"]:
        return add
    return run_git(project, ["-c", "core.editor=true", "rebase", "--continue"])


def abort_operation(project: Path) -> Dict[str, Any]:
    result = run_git(project, ["rebase", "--abort"])
    if result["ok"]:
        return result
    return run_git(project, ["merge", "--abort"])


def clone(url: str, destination: Path, branch: str = "", token: str = "") -> Dict[str, Any]:
    destination = Path(destination)
    if destination.exists():
        return {"ok": False, "code": 1, "stdout": "", "stderr": f"Destination already exists: {destination}"}
    destination.parent.mkdir(parents=True, exist_ok=True)
    args = ["clone"]
    if branch.strip():
        args += ["--branch", branch.strip()]
    args += [url.strip(), str(destination)]
    result = run_git(None, args, token=token, cwd=destination.parent)
    if result["ok"]:
        ensure_meta(destination)
    return result


def log(project: Path, count: int = 8) -> str:
    result = run_git(project, ["log", f"-{max(1, count)}", "--oneline", "--decorate"])
    return result["stdout"] if result["ok"] else result["stderr"]
