"""Google Drive relay for LaTeX Studio.

Optional backend using the Google Drive v3 API with the ``drive.file`` scope.
It synchronizes source files as snapshots and never performs Git operations.

GPL-3.0-or-later.
"""

from __future__ import annotations

import hashlib
import io
import json
import mimetypes
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from . import latex_core as core

try:
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from googleapiclient.discovery import build
    from googleapiclient.http import MediaFileUpload, MediaIoBaseDownload

    GOOGLE_OK = True
except Exception:  # optional dependencies are injected with WPM
    Request = Credentials = InstalledAppFlow = build = None  # type: ignore
    MediaFileUpload = MediaIoBaseDownload = None  # type: ignore
    GOOGLE_OK = False

SCOPES = ["https://www.googleapis.com/auth/drive.file"]
FOLDER_MIME = "application/vnd.google-apps.folder"
DRIVE_STATE_DIR = core.ROOT / "drive_state"
TOKEN_PATH = core.ROOT / "drive_token.json"
SYNC_EXCLUDE = {".pdf", ".aux", ".log", ".out", ".toc", ".fls", ".fdb_latexmk",
                ".synctex.gz", ".bbl", ".blg", ".pyc"}
WPM_HINT = (
    "Google Drive support needs optional wheels injected into the private target:\n\n"
    'py -3 "C:\\Users\\HP\\QAH\\plugins\\python_plugins\\wheel_plugin_manager\\qah_wheel_cli.py" '
    'inject google-api-python-client google-auth google-auth-oauthlib --target latex_studio\n\n'
    "Then restart QAH. The Git relay remains available without these packages."
)


class DriveError(RuntimeError):
    pass


def _require_google() -> None:
    if not GOOGLE_OK:
        raise DriveError(WPM_HINT)


def config(settings: Dict[str, Any]) -> Dict[str, Any]:
    drive = settings.setdefault("drive", {})
    return {
        "client_id": str(drive.get("client_id") or ""),
        "client_secret": str(drive.get("client_secret") or ""),
        "folder_id": str(drive.get("folder_id") or ""),
        "auto_sync": bool(drive.get("auto_sync")),
        "poll_seconds": int(drive.get("poll_seconds") or 120),
        "share_email": str(drive.get("share_email") or ""),
        "account": str(drive.get("account") or ""),
    }


def save_config(settings: Dict[str, Any], values: Dict[str, Any]) -> None:
    drive = settings.setdefault("drive", {})
    for key in ("client_id", "client_secret", "folder_id", "share_email", "account"):
        drive[key] = str(values.get(key) or "").strip()
    drive["auto_sync"] = bool(values.get("auto_sync"))
    drive["poll_seconds"] = int(values.get("poll_seconds") or 120)
    core.save_settings(settings)


def token_present() -> bool:
    return TOKEN_PATH.is_file()


def _save_token(creds) -> None:
    TOKEN_PATH.parent.mkdir(parents=True, exist_ok=True)
    TOKEN_PATH.write_text(creds.to_json(), encoding="utf-8")
    try:
        if os.name != "nt":
            os.chmod(TOKEN_PATH, 0o600)
    except OSError:
        pass


def credentials(settings: Dict[str, Any], *, interactive: bool = False):
    _require_google()
    cfg = config(settings)
    creds = None
    if TOKEN_PATH.is_file():
        try:
            creds = Credentials.from_authorized_user_file(str(TOKEN_PATH), SCOPES)
        except Exception:
            creds = None
    if creds is not None and creds.valid:
        return creds
    if creds is not None and creds.expired and creds.refresh_token:
        try:
            creds.refresh(Request())
            _save_token(creds)
            return creds
        except Exception:
            creds = None
    if not interactive:
        raise DriveError("Google Drive is not authorized. Press Authorize first.")
    if not cfg["client_id"] or not cfg["client_secret"]:
        raise DriveError("Enter the OAuth Desktop client ID and client secret first.")
    client_config = {
        "installed": {
            "client_id": cfg["client_id"],
            "client_secret": cfg["client_secret"],
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "redirect_uris": ["http://localhost"],
        }
    }
    flow = InstalledAppFlow.from_client_config(client_config, SCOPES)
    creds = flow.run_local_server(
        port=0,
        open_browser=True,
        access_type="offline",
        prompt="consent",
        authorization_prompt_message="Authorize LaTeX Studio to access its Google Drive files.",
        success_message="LaTeX Studio is authorized. You can close this browser tab.",
    )
    _save_token(creds)
    return creds


def service(settings: Dict[str, Any], *, interactive: bool = False):
    _require_google()
    return build("drive", "v3", credentials=credentials(settings, interactive=interactive),
                 cache_discovery=False)


def _state_path(project: Path) -> Path:
    digest = hashlib.sha1(str(Path(project).resolve()).encode("utf-8")).hexdigest()[:12]
    DRIVE_STATE_DIR.mkdir(parents=True, exist_ok=True)
    return DRIVE_STATE_DIR / f"{digest}.json"


def load_state(project: Path) -> Dict[str, Any]:
    try:
        data = json.loads(_state_path(project).read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {"format": 1, "root_id": "", "project_id": "", "files": {},
            "last_sync": "", "account": ""}


def save_state(project: Path, state: Dict[str, Any]) -> None:
    _state_path(project).write_text(json.dumps(state, indent=2), encoding="utf-8")


def _md5(path: Path) -> str:
    hasher = hashlib.md5()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def local_files(project: Path) -> Dict[str, Dict[str, Any]]:
    project = Path(project)
    result: Dict[str, Dict[str, Any]] = {}
    for path in core.project_files(project):
        rel = path.relative_to(project)
        if any(part in core.IGNORE_DIRS for part in rel.parts):
            continue
        if path.suffix.lower() in SYNC_EXCLUDE or any(
            path.name.endswith(suffix) for suffix in SYNC_EXCLUDE
        ):
            continue
        try:
            stat = path.stat()
            result[rel.as_posix()] = {
                "path": path,
                "size": stat.st_size,
                "md5": _md5(path),
                "mtime": int(stat.st_mtime),
            }
        except OSError:
            continue
    return result


def _list_children(service_obj, parent_id: str) -> List[Dict[str, Any]]:
    result: List[Dict[str, Any]] = []
    token = None
    while True:
        response = service_obj.files().list(
            q=f"'{parent_id}' in parents and trashed = false",
            spaces="drive",
            pageSize=1000,
            pageToken=token,
            fields="nextPageToken, files(id,name,mimeType,modifiedTime,md5Checksum,size,parents)",
        ).execute()
        result.extend(response.get("files", []))
        token = response.get("nextPageToken")
        if not token:
            break
    return result


def _find_child(service_obj, parent_id: str, name: str, mime: str = "") -> Optional[Dict[str, Any]]:
    for item in _list_children(service_obj, parent_id):
        if item.get("name") != name:
            continue
        if mime and item.get("mimeType") != mime:
            continue
        return item
    return None


def _create_folder(service_obj, parent_id: str, name: str) -> Dict[str, Any]:
    body = {"name": name, "mimeType": FOLDER_MIME, "parents": [parent_id]}
    return service_obj.files().create(
        body=body, fields="id,name,mimeType,modifiedTime"
    ).execute()


def _ensure_folder(service_obj, parent_id: str, name: str) -> str:
    found = _find_child(service_obj, parent_id, name, FOLDER_MIME)
    if found:
        return str(found["id"])
    return str(_create_folder(service_obj, parent_id, name)["id"])


def _root_id(service_obj, settings: Dict[str, Any], project: Path,
             state: Dict[str, Any], progress=None) -> str:
    cfg = config(settings)
    if cfg["folder_id"]:
        if state.get("root_id") and state.get("root_id") != cfg["folder_id"]:
            state["project_id"] = ""
        state["root_id"] = cfg["folder_id"]
        return cfg["folder_id"]
    if state.get("root_id"):
        return str(state["root_id"])
    found = _find_child(service_obj, "root", "LaTeX Studio", FOLDER_MIME)
    if found:
        root_id = str(found["id"])
    else:
        root_id = str(_create_folder(service_obj, "root", "LaTeX Studio")["id"])
    state["root_id"] = root_id
    return root_id


def _project_id(service_obj, settings: Dict[str, Any], project: Path,
                state: Dict[str, Any]) -> str:
    root_id = _root_id(service_obj, settings, project, state)
    name = core.read_meta(project).get("name") or project.name
    name = core._safe_name(str(name))
    if state.get("project_id"):
        return str(state["project_id"])
    folder_id = _ensure_folder(service_obj, root_id, name)
    state["project_id"] = folder_id
    return folder_id


def ensure_folder(project: Path, settings: Dict[str, Any], *, service_obj=None) -> Dict[str, Any]:
    _require_google()
    project = Path(project)
    service_obj = service_obj or service(settings, interactive=False)
    state = load_state(project)
    project_id = _project_id(service_obj, settings, project, state)
    save_state(project, state)
    return {"ok": True, "project_id": project_id, "root_id": state.get("root_id", ""),
            "url": f"https://drive.google.com/drive/folders/{project_id}"}


def _remote_tree(service_obj, folder_id: str, prefix: str = "") -> Dict[str, Dict[str, Any]]:
    result: Dict[str, Dict[str, Any]] = {}
    for item in _list_children(service_obj, folder_id):
        name = str(item.get("name") or "")
        rel = f"{prefix}{name}"
        if item.get("mimeType") == FOLDER_MIME:
            result.update(_remote_tree(service_obj, str(item["id"]), rel + "/"))
        else:
            item["rel"] = rel
            result[rel] = item
    return result


def _ensure_remote_parent(service_obj, project_id: str, rel: str) -> str:
    parent = project_id
    parts = rel.split("/")[:-1]
    for part in parts:
        parent = _ensure_folder(service_obj, parent, part)
    return parent


def _upload(service_obj, project_id: str, rel: str, local: Dict[str, Any],
            existing: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    path = Path(local["path"])
    mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    media = MediaFileUpload(str(path), mimetype=mime, resumable=local["size"] > 5 * 1024 * 1024)
    fields = "id,name,mimeType,modifiedTime,md5Checksum,size,parents"
    if existing:
        item = service_obj.files().update(
            fileId=str(existing["id"]), media_body=media, fields=fields
        ).execute()
    else:
        parent = _ensure_remote_parent(service_obj, project_id, rel)
        body = {"name": rel.split("/")[-1], "parents": [parent]}
        item = service_obj.files().create(
            body=body, media_body=media, fields=fields
        ).execute()
    return item


def _download(service_obj, file_id: str, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    request = service_obj.files().get_media(fileId=file_id)
    with open(target, "wb") as handle:
        downloader = MediaIoBaseDownload(handle, request)
        done = False
        while not done:
            _status, done = downloader.next_chunk()


def _conflict_path(path: Path) -> Path:
    stamp = time.strftime("%Y%m%d-%H%M%S")
    return path.with_name(f"{path.stem}.conflict-{stamp}{path.suffix}")


def push(project: Path, settings: Dict[str, Any], *, service_obj=None) -> Dict[str, Any]:
    _require_google()
    project = Path(project)
    service_obj = service_obj or service(settings, interactive=False)
    state = load_state(project)
    project_id = _project_id(service_obj, settings, project, state)
    remote = _remote_tree(service_obj, project_id)
    local = local_files(project)
    pushed = 0
    conflicts: List[str] = []
    skipped = 0
    for rel, item in sorted(local.items()):
        existing = remote.get(rel)
        base = state["files"].get(rel)
        local_changed = base is None or base.get("md5") != item["md5"]
        remote_changed = bool(existing) and (base is None or existing.get("md5Checksum") != base.get("md5"))
        if not local_changed:
            continue
        if remote_changed and base is not None:
            conflicts.append(rel)
            continue
        try:
            uploaded = _upload(service_obj, project_id, rel, item, existing)
        except Exception as exc:
            skipped += 1
            conflicts.append(f"{rel}: upload failed: {exc}")
            continue
        state["files"][rel] = {
            "id": str(uploaded.get("id") or ""),
            "md5": item["md5"],
            "modified": str(uploaded.get("modifiedTime") or ""),
            "size": item["size"],
        }
        pushed += 1
    state["root_id"] = state.get("root_id", "")
    state["project_id"] = project_id
    state["last_sync"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    save_state(project, state)
    return {"ok": not conflicts, "pushed": pushed, "skipped": skipped,
            "conflicts": conflicts, "project_id": project_id,
            "root_id": state.get("root_id", "")}


def pull(project: Path, settings: Dict[str, Any], *, service_obj=None) -> Dict[str, Any]:
    _require_google()
    project = Path(project)
    service_obj = service_obj or service(settings, interactive=False)
    state = load_state(project)
    project_id = _project_id(service_obj, settings, project, state)
    remote = _remote_tree(service_obj, project_id)
    downloaded = 0
    conflicts: List[str] = []
    for rel, item in sorted(remote.items()):
        if rel.endswith("/"):
            continue
        target = project / rel
        base = state["files"].get(rel)
        local_md5 = _md5(target) if target.is_file() else ""
        remote_md5 = str(item.get("md5Checksum") or "")
        remote_changed = base is None or remote_md5 != base.get("md5")
        if not remote_changed:
            continue
        local_changed = bool(local_md5) and (
            base is None or local_md5 != base.get("md5")
        )
        if local_changed and local_md5 != remote_md5:
            conflict = _conflict_path(target)
            try:
                _download(service_obj, str(item["id"]), conflict)
                conflicts.append(rel)
            except Exception as exc:
                conflicts.append(f"{rel}: {exc}")
            continue
        try:
            _download(service_obj, str(item["id"]), target)
            downloaded += 1
            state["files"][rel] = {
                "id": str(item["id"]),
                "md5": remote_md5,
                "modified": str(item.get("modifiedTime") or ""),
                "size": int(item.get("size") or 0),
            }
        except Exception as exc:
            conflicts.append(f"{rel}: download failed: {exc}")
    state["root_id"] = state.get("root_id", "")
    state["project_id"] = project_id
    state["last_sync"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    save_state(project, state)
    return {"ok": not conflicts, "downloaded": downloaded,
            "conflicts": conflicts, "project_id": project_id,
            "root_id": state.get("root_id", "")}


def sync(project: Path, settings: Dict[str, Any], *, service_obj=None) -> Dict[str, Any]:
    pulled = pull(project, settings, service_obj=service_obj)
    pushed = push(project, settings, service_obj=service_obj)
    return {
        "ok": pulled.get("ok") and pushed.get("ok"),
        "downloaded": pulled.get("downloaded", 0),
        "pushed": pushed.get("pushed", 0),
        "conflicts": list(pulled.get("conflicts", [])) + list(pushed.get("conflicts", [])),
    }


def status(project: Path) -> Dict[str, Any]:
    state = load_state(project)
    return {
        "authorized": token_present(),
        "last_sync": state.get("last_sync", ""),
        "project_id": state.get("project_id", ""),
        "root_id": state.get("root_id", ""),
        "files": len(state.get("files", {})),
    }


def share(project: Path, settings: Dict[str, Any], email: str, *, service_obj=None) -> Dict[str, Any]:
    _require_google()
    email = (email or "").strip()
    if not email:
        raise DriveError("Enter an email to share with.")
    service_obj = service_obj or service(settings, interactive=False)
    state = load_state(project)
    project_id = _project_id(service_obj, settings, Path(project), state)
    body = {
        "type": "user",
        "role": "writer",
        "emailAddress": email,
        "sendNotificationEmail": True,
    }
    result = service_obj.permissions().create(
        fileId=project_id, body=body, fields="id,role,type,emailAddress"
    ).execute()
    return {"ok": True, "permission": result, "project_id": project_id}


def folder_url(project: Path) -> str:
    folder_id = load_state(project).get("project_id", "")
    return f"https://drive.google.com/drive/folders/{folder_id}" if folder_id else ""
