"""LaTeX Studio widget.

A QAH-native LaTeX project editor with latexmk builds and a Git relay.
GPL-3.0-or-later.
"""

from __future__ import annotations

import os
import shutil
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from PySide6.QtCore import QThread, QTimer, Qt, QUrl, Signal
from PySide6.QtGui import QDesktopServices, QFont, QImage, QPixmap, QTextDocument
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QGroupBox,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QSplitter,
    QTabWidget,
    QTextBrowser,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from . import latex_core as core
from . import latex_drive as drive
from .latex_editor import LatexEditor


class TaskWorker(QThread):
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, function: Callable[[], Any], parent=None):
        super().__init__(parent)
        self.function = function

    def run(self) -> None:
        try:
            self.done.emit(self.function())
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class FindReplaceDialog(QDialog):
    def __init__(self, editor: LatexEditor, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Find / replace")
        self.editor = editor
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.find_edit = QLineEdit()
        self.replace_edit = QLineEdit()
        form.addRow("Find:", self.find_edit)
        form.addRow("Replace:", self.replace_edit)
        self.case = QCheckBox("Match case")
        form.addRow("", self.case)
        layout.addLayout(form)
        row = QHBoxLayout()
        find_next = QPushButton("Find next")
        find_next.clicked.connect(self._find_next)
        replace = QPushButton("Replace")
        replace.clicked.connect(self._replace)
        replace_all = QPushButton("Replace all")
        replace_all.clicked.connect(self._replace_all)
        row.addWidget(find_next)
        row.addWidget(replace)
        row.addWidget(replace_all)
        row.addStretch(1)
        layout.addLayout(row)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _flags(self):
        flags = QTextDocument.FindFlag(0)
        if self.case.isChecked():
            flags |= QTextDocument.FindFlag.FindCaseSensitively
        return flags

    def _find_next(self):
        if not self.find_edit.text():
            return
        cursor = self.editor.textCursor()
        if not self.editor.find(self.find_edit.text(), self._flags()):
            cursor.movePosition(cursor.MoveOperation.Start)
            self.editor.setTextCursor(cursor)
            self.editor.find(self.find_edit.text(), self._flags())

    def _replace(self):
        cursor = self.editor.textCursor()
        if cursor.hasSelection() and cursor.selectedText() == self.find_edit.text():
            cursor.insertText(self.replace_edit.text())
        self._find_next()

    def _replace_all(self):
        needle = self.find_edit.text()
        if not needle:
            return
        cursor = self.editor.textCursor()
        cursor.movePosition(cursor.MoveOperation.Start)
        self.editor.setTextCursor(cursor)
        count = 0
        while self.editor.find(needle, self._flags()):
            self.editor.textCursor().insertText(self.replace_edit.text())
            count += 1
        QMessageBox.information(self, "LaTeX Studio", f"Replaced {count} occurrence(s).")


class LatexStudioWidget(QWidget):
    def __init__(self, plugin=None, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.settings = core.load_settings()
        self.project: Optional[Path] = None
        self.documents: Dict[str, LatexEditor] = {}
        self.worker: Optional[TaskWorker] = None
        self.build_process = None
        self._loading_projects = False
        self._task_widgets: List[QWidget] = []
        self.git_timer = QTimer(self)
        self.git_timer.timeout.connect(self._auto_pull)
        self.drive_timer = QTimer(self)
        self.drive_timer.timeout.connect(self._auto_drive_sync)
        self._build_ui()
        self._load_projects()
        self._configure_git_timer()
        self._configure_drive_timer()

    # -- construction -----------------------------------------------------
    def _build_ui(self) -> None:
        outer_layout = QVBoxLayout(self)
        outer_layout.setContentsMargins(0, 0, 0, 0)
        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(8, 8, 8, 8)
        header = QHBoxLayout()
        title = QLabel("<b>LaTeX Studio</b>")
        title.setFont(QFont("Segoe UI", 15, QFont.Weight.Bold))
        header.addWidget(title)
        subtitle = QLabel("LaTeX projects · latexmk builds · Git relay collaboration")
        subtitle.setStyleSheet("color:#6b7280;")
        header.addWidget(subtitle, 1)
        self.status = QLabel("Ready.")
        self.status.setStyleSheet("color:#6b7280;")
        self.status.setWordWrap(True)
        header.addWidget(self.status)
        layout.addLayout(header)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.addWidget(self._scroll_page(self._build_project_panel(), 520))
        splitter.addWidget(self._build_workspace())
        splitter.setSizes([320, 980])
        layout.addWidget(splitter, 1)

        content.setMinimumSize(900, 620)
        outer = QScrollArea()
        outer.setWidgetResizable(True)
        outer.setFrameShape(QFrame.Shape.NoFrame)
        outer.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        outer.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        outer.setWidget(content)
        outer_layout.addWidget(outer, 1)

    def _scroll_page(self, page: QWidget, min_height: int = 420) -> QScrollArea:
        if page.layout() is not None:
            page.layout().activate()
        page.setMinimumWidth(0)
        hint = page.sizeHint()
        page.setMinimumHeight(max(min_height, min(950, int(hint.height()))))
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setWidget(page)
        return scroll

    def _text_pane(self, widget: QPlainTextEdit) -> QPlainTextEdit:
        widget.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        widget.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        return widget

    def _build_project_panel(self) -> QWidget:
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(0, 0, 0, 0)

        box = QGroupBox("Project")
        box_layout = QVBoxLayout(box)
        self.project_combo = QComboBox()
        self.project_combo.currentIndexChanged.connect(self._project_changed)
        box_layout.addWidget(self.project_combo)
        row = QHBoxLayout()
        new = QPushButton("New…")
        new.clicked.connect(self._new_project)
        open_btn = QPushButton("Open…")
        open_btn.clicked.connect(self._open_project_dialog)
        clone = QPushButton("Clone…")
        clone.clicked.connect(self._clone_project)
        row.addWidget(new)
        row.addWidget(open_btn)
        row.addWidget(clone)
        box_layout.addLayout(row)
        layout.addWidget(box)

        self.file_tree = QTreeWidget()
        self.file_tree.setHeaderHidden(True)
        self.file_tree.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.file_tree.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.file_tree.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.file_tree.itemDoubleClicked.connect(self._tree_activated)
        layout.addWidget(self.file_tree, 1)

        row = QHBoxLayout()
        new_file = QPushButton("+ File")
        new_file.clicked.connect(self._new_file)
        new_folder = QPushButton("+ Folder")
        new_folder.clicked.connect(self._new_folder)
        row.addWidget(new_file)
        row.addWidget(new_folder)
        layout.addLayout(row)
        row = QHBoxLayout()
        rename = QPushButton("Rename")
        rename.clicked.connect(self._rename_item)
        delete = QPushButton("Delete")
        delete.clicked.connect(self._delete_item)
        refresh = QPushButton("Refresh")
        refresh.clicked.connect(self._refresh_tree)
        row.addWidget(rename)
        row.addWidget(delete)
        row.addWidget(refresh)
        layout.addLayout(row)
        return panel

    def _build_workspace(self) -> QWidget:
        self.tabs = QTabWidget()
        self.tabs.addTab(self._scroll_page(self._build_editor_tab(), 420), "Editor")
        self.tabs.addTab(self._scroll_page(self._build_build_tab(), 600), "Build")
        self.tabs.addTab(self._scroll_page(self._build_git_tab(), 820), "Git relay")
        self.tabs.addTab(self._scroll_page(self._build_drive_tab(), 820), "Google Drive")
        self.tabs.addTab(self._scroll_page(self._build_help_tab(), 420), "Help")
        return self.tabs

    def _build_editor_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        row = QHBoxLayout()
        save = QPushButton("Save")
        save.clicked.connect(self._save_current)
        save_all = QPushButton("Save all")
        save_all.clicked.connect(self._save_all)
        find = QPushButton("Find / replace")
        find.clicked.connect(self._find_replace)
        close = QPushButton("Close tab")
        close.clicked.connect(self._close_current)
        row.addWidget(save)
        row.addWidget(save_all)
        row.addWidget(find)
        row.addWidget(close)
        row.addStretch(1)
        layout.addLayout(row)
        self.doc_tabs = QTabWidget()
        self.doc_tabs.setTabsClosable(True)
        self.doc_tabs.tabCloseRequested.connect(self._close_doc)
        layout.addWidget(self.doc_tabs, 1)
        self._task_widgets += [save, save_all, find]
        return page

    def _build_build_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        box = QGroupBox("Build")
        form = QFormLayout(box)
        form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.main_combo = QComboBox()
        form.addRow("Main file:", self.main_combo)
        self.engine_combo = QComboBox()
        for engine_id, label in core.ENGINES:
            self.engine_combo.addItem(label, engine_id)
        form.addRow("Engine:", self.engine_combo)
        self.timeout_spin = QSpinBox()
        self.timeout_spin.setRange(10, 900)
        self.timeout_spin.setValue(180)
        self.timeout_spin.setSuffix(" s")
        form.addRow("Timeout:", self.timeout_spin)
        row = QHBoxLayout()
        self.build_btn = QPushButton("Build")
        self.build_btn.clicked.connect(self._start_build)
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self._cancel_build)
        self.cancel_btn.setEnabled(False)
        open_pdf = QPushButton("Open PDF")
        open_pdf.clicked.connect(self._open_pdf)
        open_folder = QPushButton("Open folder")
        open_folder.clicked.connect(self._open_project_folder)
        row.addWidget(self.build_btn)
        row.addWidget(self.cancel_btn)
        row.addWidget(open_pdf)
        row.addWidget(open_folder)
        row.addStretch(1)
        form.addRow("", row)
        layout.addWidget(box)
        self.build_status = QLabel("No build yet.")
        self.build_status.setStyleSheet("color:#6b7280;")
        layout.addWidget(self.build_status)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        self.build_log = self._text_pane(QPlainTextEdit())
        self.build_log.setReadOnly(True)
        self.build_log.setFont(QFont("Consolas", 9))
        splitter.addWidget(self.build_log)
        self.preview_scroll = QScrollArea()
        self.preview_scroll.setWidgetResizable(True)
        self.preview_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.preview_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.preview_label = QLabel("Build the project to preview the first PDF page.")
        self.preview_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview_label.setWordWrap(True)
        self.preview_scroll.setWidget(self.preview_label)
        splitter.addWidget(self.preview_scroll)
        splitter.setSizes([540, 540])
        layout.addWidget(splitter, 1)
        self._task_widgets += [self.build_btn, self.main_combo, self.engine_combo, self.timeout_spin]
        return page

    def _build_git_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        info = QLabel(
            "The Git relay is a shared Git remote (GitHub, GitLab or any SSH/HTTPS "
            "remote). Commit and push your changes; collaborators pull them. "
            "A token is optional when Git credentials or SSH keys are configured."
        )
        info.setWordWrap(True)
        info.setStyleSheet("color:#6b7280;")
        layout.addWidget(info)

        box = QGroupBox("Relay configuration")
        form = QFormLayout(box)
        form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.git_remote = QLineEdit()
        self.git_remote.setPlaceholderText("https://github.com/user/paper.git or git@github.com:user/paper.git")
        form.addRow("Remote URL:", self.git_remote)
        self.git_branch = QLineEdit("main")
        form.addRow("Branch:", self.git_branch)
        self.git_token = QLineEdit()
        self.git_token.setEchoMode(QLineEdit.EchoMode.Password)
        self.git_token.setPlaceholderText("optional token (not written to the repository)")
        form.addRow("Token:", self.git_token)
        self.git_name = QLineEdit()
        self.git_name.setPlaceholderText("optional local Git user name")
        form.addRow("Git user:", self.git_name)
        self.git_email = QLineEdit()
        self.git_email.setPlaceholderText("optional local Git email")
        form.addRow("Git email:", self.git_email)
        self.git_poll = QSpinBox()
        self.git_poll.setRange(10, 3600)
        self.git_poll.setSuffix(" s")
        form.addRow("Auto-pull poll:", self.git_poll)
        self.git_auto = QCheckBox("Auto-pull remote changes")
        form.addRow("", self.git_auto)
        row = QHBoxLayout()
        save = QPushButton("Save config")
        save.clicked.connect(self._save_git_config)
        init = QPushButton("Initialize repo")
        init.clicked.connect(self._git_init)
        status = QPushButton("Status")
        status.clicked.connect(self._refresh_git_status)
        row.addWidget(save)
        row.addWidget(init)
        row.addWidget(status)
        row.addStretch(1)
        form.addRow("", row)
        layout.addWidget(box)

        commit_box = QGroupBox("Collaborate")
        commit_layout = QVBoxLayout(commit_box)
        row = QHBoxLayout()
        self.commit_message = QLineEdit("Update paper")
        row.addWidget(QLabel("Commit:"))
        row.addWidget(self.commit_message, 1)
        self.commit_btn = QPushButton("Commit")
        self.commit_btn.clicked.connect(self._git_commit)
        row.addWidget(self.commit_btn)
        commit_layout.addLayout(row)
        row = QHBoxLayout()
        for label, handler in (
            ("Pull", self._git_pull),
            ("Push", self._git_push),
            ("Sync", self._git_sync),
            ("Continue", self._git_continue),
            ("Abort", self._git_abort),
        ):
            button = QPushButton(label)
            button.clicked.connect(handler)
            row.addWidget(button)
        row.addStretch(1)
        commit_layout.addLayout(row)
        layout.addWidget(commit_box)

        self.git_status = self._text_pane(QPlainTextEdit())
        self.git_status.setReadOnly(True)
        self.git_status.setFont(QFont("Consolas", 9))
        self.git_status.setMaximumHeight(110)
        layout.addWidget(self.git_status)
        self.git_log = self._text_pane(QPlainTextEdit())
        self.git_log.setReadOnly(True)
        self.git_log.setFont(QFont("Consolas", 9))
        layout.addWidget(self.git_log, 1)
        self._task_widgets += [self.git_remote, self.git_branch, self.git_token,
                               self.git_name, self.git_email, self.git_poll,
                               self.git_auto, self.commit_message, self.commit_btn]
        return page

    def _build_drive_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        info = QLabel(
            "Optional Google Drive relay using the <code>drive.file</code> scope. "
            "The plugin creates a <b>LaTeX Studio</b> folder in Drive and syncs the "
            "project as source snapshots. Google Drive is file-level sync, not Git: "
            "conflicts are saved as conflict copies and must be resolved manually."
        )
        info.setWordWrap(True)
        info.setStyleSheet("color:#6b7280;")
        layout.addWidget(info)
        if not drive.GOOGLE_OK:
            warn = QLabel(
                "Google libraries are not installed. Inject them with Wheel Plugin Manager "
                "into the private <code>latex_studio</code> target, then restart QAH."
            )
            warn.setWordWrap(True)
            warn.setStyleSheet("color:#b45309;")
            layout.addWidget(warn)

        box = QGroupBox("Google Drive configuration")
        form = QFormLayout(box)
        form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.drive_client_id = QLineEdit()
        self.drive_client_id.setPlaceholderText("OAuth Desktop client ID")
        form.addRow("Client ID:", self.drive_client_id)
        self.drive_client_secret = QLineEdit()
        self.drive_client_secret.setEchoMode(QLineEdit.EchoMode.Password)
        self.drive_client_secret.setPlaceholderText("OAuth Desktop client secret")
        form.addRow("Client secret:", self.drive_client_secret)
        self.drive_folder_id = QLineEdit()
        self.drive_folder_id.setPlaceholderText("optional root folder ID; blank creates LaTeX Studio")
        form.addRow("Root folder ID:", self.drive_folder_id)
        self.drive_share_email = QLineEdit()
        self.drive_share_email.setPlaceholderText("collaborator email for sharing")
        form.addRow("Share with:", self.drive_share_email)
        self.drive_poll = QSpinBox()
        self.drive_poll.setRange(30, 3600)
        self.drive_poll.setSuffix(" s")
        form.addRow("Auto-sync poll:", self.drive_poll)
        self.drive_auto = QCheckBox("Auto-sync Google Drive")
        form.addRow("", self.drive_auto)
        row = QHBoxLayout()
        save = QPushButton("Save config")
        save.clicked.connect(self._save_drive_config)
        auth = QPushButton("Authorize")
        auth.clicked.connect(self._drive_authorize)
        folder = QPushButton("Create / find folder")
        folder.clicked.connect(self._drive_folder)
        status = QPushButton("Status")
        status.clicked.connect(self._refresh_drive_status)
        open_folder = QPushButton("Open folder")
        open_folder.clicked.connect(self._drive_open_folder)
        for button in (save, auth, folder, status, open_folder):
            row.addWidget(button)
        row.addStretch(1)
        form.addRow("", row)
        layout.addWidget(box)

        actions = QGroupBox("Snapshot sync")
        actions_layout = QVBoxLayout(actions)
        row = QHBoxLayout()
        push = QPushButton("Push")
        push.clicked.connect(self._drive_push)
        pull = QPushButton("Pull")
        pull.clicked.connect(self._drive_pull)
        sync = QPushButton("Sync")
        sync.clicked.connect(self._drive_sync)
        share = QPushButton("Share folder")
        share.clicked.connect(self._drive_share)
        for button in (push, pull, sync, share):
            row.addWidget(button)
        row.addStretch(1)
        actions_layout.addLayout(row)
        layout.addWidget(actions)

        self.drive_status = self._text_pane(QPlainTextEdit())
        self.drive_status.setReadOnly(True)
        self.drive_status.setFont(QFont("Consolas", 9))
        self.drive_status.setMaximumHeight(110)
        layout.addWidget(self.drive_status)
        self.drive_log = self._text_pane(QPlainTextEdit())
        self.drive_log.setReadOnly(True)
        self.drive_log.setFont(QFont("Consolas", 9))
        layout.addWidget(self.drive_log, 1)
        self._task_widgets += [save, auth, folder, status, open_folder,
                               self.drive_client_id, self.drive_client_secret,
                               self.drive_folder_id, self.drive_share_email,
                               self.drive_poll, self.drive_auto, push, pull, sync, share]
        return page

    def _build_help_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        viewer = QTextBrowser()
        viewer.setOpenExternalLinks(True)
        viewer.setHtml(
            "<h2>LaTeX Studio</h2>"
            "<p>A LaTeX paper workspace with syntax-highlighted editing, local PDF "
            "builds and a Git relay for collaboration.</p>"
            "<h3>Quick start</h3>"
            "<ol>"
            "<li><b>New…</b> creates a project with <code>main.tex</code>, "
            "<code>sections/</code>, <code>figures/</code> and <code>references.bib</code>.</li>"
            "<li>Edit files in the tree; double-click to open.</li>"
            "<li>In <b>Build</b>, choose the main file and engine, then press <b>Build</b>.</li>"
            "<li>Open the PDF, or use the optional first-page preview.</li>"
            "</ol>"
            "<h3>Git relay collaboration</h3>"
            "<ol>"
            "<li>Create an empty private repository on GitHub/GitLab.</li>"
            "<li>Paste its URL in <b>Git relay</b> and press <b>Save config</b>.</li>"
            "<li>Press <b>Initialize repo</b> for a new project, or <b>Clone…</b> for an existing paper.</li>"
            "<li>Commit your changes, then <b>Push</b>. Collaborators press <b>Pull</b> or enable auto-pull.</li>"
            "</ol>"
            "<p>Git is asynchronous: use small commits and pull before starting a writing session. "
            "If a pull conflicts, resolve the conflict markers in the editor, save, then press "
            "<b>Continue</b>, or <b>Abort</b> to return to the previous state.</p>"
            "<h3>Google Drive relay (optional)</h3>"
            "<p>The Google Drive tab uses the <code>drive.file</code> scope. Install the "
            "optional Google libraries with Wheel Plugin Manager:</p>"
            "<pre>py -3 ...\\wheel_plugin_manager\\qah_wheel_cli.py inject "
            "google-api-python-client google-auth google-auth-oauthlib --target latex_studio</pre>"
            "<p>Create a Google Cloud OAuth <b>Desktop app</b> client, paste its ID/secret, "
            "press <b>Authorize</b>, then <b>Create / find folder</b>. The plugin creates a "
            "<code>LaTeX Studio</code> folder and syncs source snapshots.</p>"
            "<p>Google Drive sync is file-level, not Git. If both sides change the same file, "
            "the plugin writes a <code>.conflict-...</code> copy instead of overwriting. "
            "The Git relay remains the primary history/diff backend.</p>"
            "<h3>Notes</h3>"
            "<ul>"
            "<li>Build requires <code>latexmk</code> (recommended) or <code>pdflatex</code>/"
            "<code>xelatex</code>/<code>lualatex</code> plus <code>bibtex</code>.</li>"
            "<li>PDF preview uses PyMuPDF when available; otherwise use <b>Open PDF</b>.</li>"
            "<li>Tokens are stored in your local QAH settings, not in the Git repository.</li>"
            "</ul>"
        )
        layout.addWidget(viewer)
        return page

    # -- projects ---------------------------------------------------------
    def _load_projects(self) -> None:
        self._loading_projects = True
        self.project_combo.clear()
        projects = core.list_projects()
        for item in projects:
            self.project_combo.addItem(item["name"], item["path"])
        self._loading_projects = False
        if not projects:
            self.status.setText("No projects yet. Create one with New… or clone a Git repository.")
            return
        last = str(self.settings.get("last_project") or "")
        index = self.project_combo.findData(last)
        if index < 0:
            index = 0
        self.project_combo.setCurrentIndex(index)
        self._open_project(Path(self.project_combo.currentData()))

    def _project_changed(self, _index: int) -> None:
        if self._loading_projects:
            return
        data = self.project_combo.currentData()
        if data:
            self._open_project(Path(data))

    def _open_project(self, project: Path) -> None:
        project = Path(project)
        if not project.is_dir():
            return
        self._save_all()
        for index in reversed(range(self.doc_tabs.count())):
            self.doc_tabs.removeTab(index)
        self.documents.clear()
        self.project = project
        self.settings["last_project"] = str(project)
        core.save_settings(self.settings)
        meta = core.ensure_meta(project)
        self._refresh_tree()
        self._refresh_main_files(meta)
        self.engine_combo.setCurrentIndex(
            max(0, self.engine_combo.findData(meta.get("engine") or self.settings.get("default_engine")))
        )
        main = core.detect_main(project)
        if main is not None:
            self.open_file(main)
        self._load_git_fields()
        self._refresh_git_status()
        self._load_drive_fields()
        self._refresh_drive_status()
        self.status.setText(f"Project: {project}")

    def _refresh_tree(self) -> None:
        self.file_tree.clear()
        if self.project is None:
            return

        def add_items(parent_item, folder: Path):
            try:
                children = sorted(folder.iterdir(), key=lambda p: (p.is_file(), p.name.lower()))
            except OSError:
                return
            for child in children:
                if child.name in core.IGNORE_DIRS:
                    continue
                if child.is_file() and child.suffix.lower() in core.AUX_SUFFIXES:
                    continue
                item = QTreeWidgetItem([child.name])
                item.setData(0, Qt.ItemDataRole.UserRole, str(child))
                if child.is_dir():
                    item.setIcon(0, self.style().standardIcon(self.style().StandardPixmap.SP_DirIcon))
                    parent_item.addChild(item)
                    add_items(item, child)
                else:
                    item.setIcon(0, self.style().standardIcon(self.style().StandardPixmap.SP_FileIcon))
                    parent_item.addChild(item)

        add_items(self.file_tree.invisibleRootItem(), self.project)
        self.file_tree.expandToDepth(1)

    def _refresh_main_files(self, meta: Optional[Dict[str, Any]] = None) -> None:
        current = self.main_combo.currentData()
        self.main_combo.clear()
        if self.project is None:
            return
        for path in core.tex_files(self.project):
            rel = path.relative_to(self.project).as_posix()
            self.main_combo.addItem(rel, str(path))
        meta = meta or core.read_meta(self.project)
        target = meta.get("main") or current
        index = self.main_combo.findData(str(self.project / target)) if target else -1
        if index < 0:
            index = self.main_combo.findText(str(target)) if target else 0
        if index >= 0:
            self.main_combo.setCurrentIndex(index)

    def _selected_path(self) -> Optional[Path]:
        item = self.file_tree.currentItem()
        if item is None:
            return None
        value = item.data(0, Qt.ItemDataRole.UserRole)
        return Path(value) if value else None

    def _target_folder(self) -> Path:
        selected = self._selected_path()
        if selected is not None and selected.is_dir():
            return selected
        if selected is not None:
            return selected.parent
        return self.project or core.projects_root()

    def _new_project(self) -> None:
        name, ok = QInputDialog.getText(self, "New LaTeX project", "Project name:")
        if not ok or not name.strip():
            return
        template, ok = QInputDialog.getItem(
            self, "Template", "Document template:",
            ["article", "report", "beamer"], 0, False,
        )
        if not ok:
            return
        try:
            project = core.create_project(name.strip(), template)
        except Exception as exc:
            QMessageBox.warning(self, "LaTeX Studio", str(exc))
            return
        self._load_projects()
        index = self.project_combo.findData(str(project))
        if index >= 0:
            self.project_combo.setCurrentIndex(index)

    def _open_project_dialog(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Open LaTeX project", str(core.projects_root()))
        if folder:
            project = Path(folder)
            core.ensure_meta(project)
            self._load_projects()
            index = self.project_combo.findData(str(project))
            if index < 0:
                self.project_combo.addItem(project.name, str(project))
                index = self.project_combo.count() - 1
            self.project_combo.setCurrentIndex(index)

    def _clone_project(self) -> None:
        url, ok = QInputDialog.getText(self, "Clone Git relay", "Repository URL:")
        if not ok or not url.strip():
            return
        branch = self.git_branch.text().strip() or "main"
        name = Path(url.rstrip("/").split("/")[-1]).stem or "paper"
        destination = core.projects_root() / core._safe_name(name)
        if destination.exists():
            QMessageBox.warning(self, "LaTeX Studio", f"Destination already exists:\n{destination}")
            return
        token = self.git_token.text().strip()
        self._run_task(
            lambda: core.clone(url.strip(), destination, branch, token),
            "Cloning repository…",
            on_done=lambda result: self._clone_done(result, destination),
        )

    def _clone_done(self, result: Dict[str, Any], destination: Path) -> None:
        self._append_log(self.git_log, result.get("stdout", "") or result.get("stderr", ""))
        if not result.get("ok"):
            QMessageBox.warning(self, "Git relay", result.get("stderr") or result.get("stdout") or "Clone failed.")
            return
        self._load_projects()
        index = self.project_combo.findData(str(destination))
        if index < 0:
            self.project_combo.addItem(destination.name, str(destination))
            index = self.project_combo.count() - 1
        self.project_combo.setCurrentIndex(index)
        self.status.setText(f"Cloned into {destination}")

    def _new_file(self) -> None:
        folder = self._target_folder()
        name, ok = QInputDialog.getText(self, "New file", "File name (e.g. sections/method.tex):")
        if not ok or not name.strip():
            return
        path = folder / name.strip()
        if path.suffix == "":
            path = path.with_suffix(".tex")
        if path.exists():
            QMessageBox.warning(self, "LaTeX Studio", f"Already exists:\n{path}")
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("", encoding="utf-8")
        self._refresh_tree()
        self.open_file(path)

    def _new_folder(self) -> None:
        folder = self._target_folder()
        name, ok = QInputDialog.getText(self, "New folder", "Folder name:")
        if not ok or not name.strip():
            return
        (folder / name.strip()).mkdir(parents=True, exist_ok=True)
        self._refresh_tree()

    def _rename_item(self) -> None:
        path = self._selected_path()
        if path is None or self.project is None:
            return
        name, ok = QInputDialog.getText(self, "Rename", "New name:", text=path.name)
        if not ok or not name.strip() or name.strip() == path.name:
            return
        target = path.parent / name.strip()
        if target.exists():
            QMessageBox.warning(self, "LaTeX Studio", f"Already exists:\n{target}")
            return
        path.rename(target)
        self._refresh_tree()
        self._refresh_main_files()

    def _delete_item(self) -> None:
        path = self._selected_path()
        if path is None or self.project is None:
            return
        if QMessageBox.question(self, "Delete", f"Delete {path.name}?") != QMessageBox.StandardButton.Yes:
            return
        try:
            if path.is_dir():
                shutil.rmtree(path)
            else:
                path.unlink()
        except OSError as exc:
            QMessageBox.warning(self, "LaTeX Studio", str(exc))
            return
        self._refresh_tree()
        self._refresh_main_files()

    def _tree_activated(self, item: QTreeWidgetItem, _column: int) -> None:
        value = item.data(0, Qt.ItemDataRole.UserRole)
        if value:
            path = Path(value)
            if path.is_file():
                self.open_file(path)

    # -- editor -----------------------------------------------------------
    def open_file(self, path: Path) -> None:
        path = Path(path)
        key = str(path)
        if key in self.documents:
            index = self.doc_tabs.indexOf(self.documents[key])
            if index >= 0:
                self.doc_tabs.setCurrentIndex(index)
            return
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            QMessageBox.warning(self, "LaTeX Studio", f"Cannot read {path}:\n{exc}")
            return
        editor = LatexEditor(text)
        editor.set_wrap(bool(self.settings.get("editor", {}).get("wrap", False)))
        editor.document().setModified(False)
        editor.modificationChanged.connect(lambda modified, key=key: self._document_modified(key, modified))
        self.documents[key] = editor
        self.doc_tabs.addTab(editor, path.name)
        self.doc_tabs.setCurrentWidget(editor)
        self._update_tab_title(key)

    def _document_modified(self, key: str, modified: bool) -> None:
        self._update_tab_title(key)

    def _update_tab_title(self, key: str) -> None:
        editor = self.documents.get(key)
        if editor is None:
            return
        index = self.doc_tabs.indexOf(editor)
        if index >= 0:
            title = Path(key).name
            if editor.document().isModified():
                title += " *"
            self.doc_tabs.setTabText(index, title)

    def _current_editor(self) -> Optional[LatexEditor]:
        widget = self.doc_tabs.currentWidget()
        return widget if isinstance(widget, LatexEditor) else None

    def _current_path(self) -> Optional[Path]:
        editor = self._current_editor()
        if editor is None:
            return None
        for key, value in self.documents.items():
            if value is editor:
                return Path(key)
        return None

    def _save_current(self) -> bool:
        editor = self._current_editor()
        path = self._current_path()
        if editor is None or path is None:
            return False
        try:
            path.write_text(editor.toPlainText(), encoding="utf-8")
        except OSError as exc:
            QMessageBox.warning(self, "LaTeX Studio", f"Cannot save {path}:\n{exc}")
            return False
        editor.document().setModified(False)
        self._update_tab_title(str(path))
        self.status.setText(f"Saved {path.name}")
        return True

    def _save_all(self) -> None:
        for key, editor in list(self.documents.items()):
            if editor.document().isModified():
                path = Path(key)
                try:
                    path.write_text(editor.toPlainText(), encoding="utf-8")
                    editor.document().setModified(False)
                    self._update_tab_title(key)
                except OSError:
                    pass

    def _close_current(self) -> None:
        index = self.doc_tabs.currentIndex()
        if index >= 0:
            self._close_doc(index)

    def _close_doc(self, index: int) -> None:
        editor = self.doc_tabs.widget(index)
        if not isinstance(editor, LatexEditor):
            return
        if editor.document().isModified():
            answer = QMessageBox.question(
                self, "Unsaved changes", f"Save {self.doc_tabs.tabText(index)} before closing?",
                QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard | QMessageBox.StandardButton.Cancel,
            )
            if answer == QMessageBox.StandardButton.Cancel:
                return
            if answer == QMessageBox.StandardButton.Save:
                self.doc_tabs.setCurrentIndex(index)
                if not self._save_current():
                    return
        for key, value in list(self.documents.items()):
            if value is editor:
                del self.documents[key]
                break
        self.doc_tabs.removeTab(index)

    def _find_replace(self) -> None:
        editor = self._current_editor()
        if editor is not None:
            FindReplaceDialog(editor, self).exec()

    # -- build ------------------------------------------------------------
    def _start_build(self) -> None:
        if self.project is None:
            QMessageBox.information(self, "LaTeX Studio", "Open a project first.")
            return
        self._save_all()
        main = Path(self.main_combo.currentData()) if self.main_combo.currentData() else core.detect_main(self.project)
        if main is None or not main.is_file():
            QMessageBox.warning(self, "LaTeX Studio", "Select a valid main .tex file.")
            return
        engine = self.engine_combo.currentData() or core.DEFAULT_ENGINE
        timeout = int(self.timeout_spin.value())
        self.build_log.clear()
        self.build_status.setText("Building…")
        self.build_btn.setEnabled(False)
        self.cancel_btn.setEnabled(True)
        self._append_log(self.build_log, f"Project: {self.project}\nMain: {main}\nEngine: {engine}\n")
        self._run_task(
            lambda: core.build_project(
                self.project, main, engine, timeout, process_callback=self._set_build_process
            ),
            "Building…",
            on_done=self._build_done,
        )

    def _set_build_process(self, process) -> None:
        self.build_process = process
        if process is not None:
            self.cancel_btn.setEnabled(True)

    def _cancel_build(self) -> None:
        if self.build_process is not None:
            try:
                self.build_process.kill()
            except Exception:
                pass
            self.build_status.setText("Cancelling…")

    def _build_done(self, result: Dict[str, Any]) -> None:
        self.build_process = None
        self.cancel_btn.setEnabled(False)
        self.build_btn.setEnabled(True)
        self._append_log(self.build_log, result.get("log", ""))
        self.build_status.setText(
            f"Build OK in {result.get('duration', 0)} s" if result.get("ok")
            else f"Build failed (exit {result.get('returncode')})"
        )
        pdf = result.get("pdf")
        if pdf:
            self._show_preview(Path(pdf))
            self.status.setText(f"PDF: {pdf}")
        else:
            self.preview_label.setText("No PDF produced. See the build log.")

    def _show_preview(self, pdf: Path) -> None:
        try:
            import fitz  # type: ignore

            doc = fitz.open(str(pdf))
            page = doc[0]
            pix = page.get_pixmap(matrix=fitz.Matrix(1.5, 1.5))
            image = QImage.fromData(pix.tobytes("png"))
            self.preview_label.setPixmap(QPixmap.fromImage(image))
            self.preview_label.setText("")
        except Exception:
            self.preview_label.setPixmap(QPixmap())
            self.preview_label.setText(
                f"Preview unavailable (install PyMuPDF for inline preview).\n\nPDF:\n{pdf}\n\nUse Open PDF."
            )

    def _open_pdf(self) -> None:
        if self.project is None:
            return
        pdf = core.pdf_for(self.project, Path(self.main_combo.currentData()) if self.main_combo.currentData() else None)
        if pdf is None:
            QMessageBox.information(self, "LaTeX Studio", "No PDF found. Build the project first.")
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(pdf)))

    def _open_project_folder(self) -> None:
        if self.project is not None:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.project)))

    # -- git relay --------------------------------------------------------
    def _load_git_fields(self) -> None:
        git = self.settings.get("git", {})
        self.git_branch.setText(str(git.get("branch") or "main"))
        self.git_token.setText(str(git.get("token") or ""))
        self.git_name.setText(str(git.get("name") or ""))
        self.git_email.setText(str(git.get("email") or ""))
        self.git_poll.setValue(int(git.get("poll_seconds") or 60))
        self.git_auto.setChecked(bool(git.get("auto_pull")))
        if self.project is not None:
            state = core.status(self.project)
            self.git_remote.setText(state.get("remote", ""))

    def _save_git_config(self) -> None:
        git = self.settings.setdefault("git", {})
        git["branch"] = self.git_branch.text().strip() or "main"
        git["token"] = self.git_token.text().strip()
        git["name"] = self.git_name.text().strip()
        git["email"] = self.git_email.text().strip()
        git["poll_seconds"] = int(self.git_poll.value())
        git["auto_pull"] = self.git_auto.isChecked()
        core.save_settings(self.settings)
        if self.project is not None:
            remote = self.git_remote.text().strip()
            if remote:
                result = core.set_remote(self.project, remote)
                if not result.get("ok"):
                    QMessageBox.warning(self, "Git relay", result.get("stderr") or "Could not set remote.")
                    return
            core.set_identity(self.project, git["name"], git["email"])
        self._configure_git_timer()
        self._refresh_git_status()
        self.status.setText("Git relay configuration saved.")

    def _configure_git_timer(self) -> None:
        git = self.settings.get("git", {})
        if git.get("auto_pull"):
            self.git_timer.start(max(10, int(git.get("poll_seconds") or 60)) * 1000)
        else:
            self.git_timer.stop()

    def _git_init(self) -> None:
        if self.project is None:
            return
        result = core.init_repo(self.project)
        self._append_log(self.git_log, result.get("stdout") or result.get("stderr"))
        remote = self.git_remote.text().strip()
        if remote:
            core.set_remote(self.project, remote)
        core.set_identity(self.project, self.git_name.text(), self.git_email.text())
        self._refresh_git_status()

    def _git_commit(self) -> None:
        if self.project is None:
            return
        message = self.commit_message.text().strip() or "Update paper"
        self._run_task(
            lambda: core.commit(self.project, message, self.git_name.text(), self.git_email.text()),
            "Committing…", on_done=self._after_git,
        )

    def _git_pull(self) -> None:
        if self.project is None:
            return
        branch = self.git_branch.text().strip() or "main"
        token = self.git_token.text().strip()
        self._run_task(lambda: core.pull(self.project, branch, token), "Pulling…", on_done=self._after_git)

    def _git_push(self) -> None:
        if self.project is None:
            return
        branch = self.git_branch.text().strip() or "main"
        token = self.git_token.text().strip()
        self._run_task(lambda: core.push(self.project, branch, token), "Pushing…", on_done=self._after_git)

    def _git_sync(self) -> None:
        if self.project is None:
            return
        branch = self.git_branch.text().strip() or "main"
        token = self.git_token.text().strip()
        self._run_task(lambda: core.sync(self.project, branch, token), "Syncing…", on_done=self._after_git)

    def _git_continue(self) -> None:
        if self.project is None:
            return
        self._run_task(lambda: core.continue_rebase(self.project), "Continuing…", on_done=self._after_git)

    def _git_abort(self) -> None:
        if self.project is None:
            return
        self._run_task(lambda: core.abort_operation(self.project), "Aborting…", on_done=self._after_git)

    def _after_git(self, result: Dict[str, Any]) -> None:
        text = result.get("stdout") or result.get("stderr") or ""
        self._append_log(self.git_log, text)
        conflicts = result.get("conflicts") or []
        if conflicts:
            QMessageBox.warning(
                self, "Git relay conflict",
                "Conflicts:\n" + "\n".join(conflicts) +
                "\n\nResolve the markers in the editor, save, then press Continue. "
                "Press Abort to cancel the operation.",
            )
        elif not result.get("ok"):
            QMessageBox.warning(self, "Git relay", result.get("stderr") or "Git operation failed.")
        self._refresh_git_status()

    def _refresh_git_status(self) -> None:
        if self.project is None:
            self.git_status.setPlainText("No project.")
            return
        state = core.status(self.project)
        if not state.get("repo"):
            self.git_status.setPlainText("No Git repository. Press Initialize repo.")
            return
        lines = [
            f"Branch   : {state.get('branch', '')}",
            f"Remote   : {state.get('remote', '') or '(none)'}",
            f"Changes  : {'yes' if state.get('dirty') else 'clean'}",
            f"Ahead    : {state.get('ahead', 0)}   Behind: {state.get('behind', 0)}",
            f"Last     : {state.get('last', '')}",
        ]
        if state.get("conflicts"):
            lines.append("Conflicts: " + ", ".join(state["conflicts"]))
        self.git_status.setPlainText("\n".join(lines))
        self.git_log.setPlainText(core.log(self.project, 10))

    def _auto_pull(self) -> None:
        if self.project is None or self.worker is not None:
            return
        if not self.git_auto.isChecked():
            return
        branch = self.git_branch.text().strip() or "main"
        token = self.git_token.text().strip()
        self._run_task(lambda: core.pull(self.project, branch, token), "Auto-pulling…", on_done=self._auto_pull_done)

    def _auto_pull_done(self, result: Dict[str, Any]) -> None:
        if result.get("conflicts"):
            self._after_git(result)
        else:
            self._refresh_git_status()

    # -- google drive relay ----------------------------------------------
    def _load_drive_fields(self) -> None:
        cfg = drive.config(self.settings)
        self.drive_client_id.setText(cfg["client_id"])
        self.drive_client_secret.setText(cfg["client_secret"])
        self.drive_folder_id.setText(cfg["folder_id"])
        self.drive_share_email.setText(cfg["share_email"])
        self.drive_poll.setValue(int(cfg["poll_seconds"]))
        self.drive_auto.setChecked(bool(cfg["auto_sync"]))

    def _save_drive_config(self) -> None:
        drive.save_config(self.settings, {
            "client_id": self.drive_client_id.text(),
            "client_secret": self.drive_client_secret.text(),
            "folder_id": self.drive_folder_id.text(),
            "share_email": self.drive_share_email.text(),
            "auto_sync": self.drive_auto.isChecked(),
            "poll_seconds": int(self.drive_poll.value()),
        })
        self._configure_drive_timer()
        self._refresh_drive_status()
        self.status.setText("Google Drive configuration saved.")

    def _configure_drive_timer(self) -> None:
        cfg = drive.config(self.settings)
        if cfg["auto_sync"]:
            self.drive_timer.start(max(30, int(cfg["poll_seconds"])) * 1000)
        else:
            self.drive_timer.stop()

    def _drive_ready(self) -> bool:
        if not drive.GOOGLE_OK:
            QMessageBox.warning(self, "Google Drive", drive.WPM_HINT)
            return False
        return True

    def _drive_authorize(self) -> None:
        if not self._drive_ready():
            return
        self._save_drive_config()
        self._run_task(
            lambda: drive.credentials(self.settings, interactive=True),
            "Authorizing Google Drive…",
            on_done=lambda _creds: self._drive_authorized(),
        )

    def _drive_authorized(self) -> None:
        self._append_log(self.drive_log, "Google Drive authorized.")
        self._refresh_drive_status()

    def _drive_folder(self) -> None:
        if self.project is None or not self._drive_ready():
            return
        self._run_task(
            lambda: drive.ensure_folder(self.project, self.settings),
            "Creating / finding Drive folder…",
            on_done=self._drive_after,
        )

    def _drive_push(self) -> None:
        if self.project is None or not self._drive_ready():
            return
        self._run_task(lambda: drive.push(self.project, self.settings),
                       "Pushing to Google Drive…", on_done=self._drive_after)

    def _drive_pull(self) -> None:
        if self.project is None or not self._drive_ready():
            return
        self._run_task(lambda: drive.pull(self.project, self.settings),
                       "Pulling from Google Drive…", on_done=self._drive_after)

    def _drive_sync(self) -> None:
        if self.project is None or not self._drive_ready():
            return
        self._run_task(lambda: drive.sync(self.project, self.settings),
                       "Syncing Google Drive…", on_done=self._drive_after)

    def _drive_share(self) -> None:
        if self.project is None or not self._drive_ready():
            return
        email = self.drive_share_email.text().strip()
        if not email:
            QMessageBox.information(self, "Google Drive", "Enter a collaborator email first.")
            return
        self._run_task(lambda: drive.share(self.project, self.settings, email),
                       "Sharing Drive folder…", on_done=self._drive_after)

    def _drive_after(self, result: Dict[str, Any]) -> None:
        text = []
        if "pushed" in result:
            text.append(f"Pushed: {result.get('pushed', 0)}")
        if "downloaded" in result:
            text.append(f"Downloaded: {result.get('downloaded', 0)}")
        if result.get("project_id"):
            text.append(f"Folder ID: {result.get('project_id')}")
        if result.get("url"):
            text.append(str(result["url"]))
        self._append_log(self.drive_log, "\n".join(text))
        conflicts = result.get("conflicts") or []
        if conflicts:
            QMessageBox.warning(
                self, "Google Drive conflict",
                "Conflicts / skipped files:\n" + "\n".join(conflicts) +
                "\n\nConflict copies are saved next to the local file. Review and merge them manually.",
            )
        elif not result.get("ok", True):
            QMessageBox.warning(self, "Google Drive", "Sync did not complete cleanly. See the log.")
        self._refresh_drive_status()

    def _refresh_drive_status(self) -> None:
        if self.project is None:
            self.drive_status.setPlainText("No project.")
            return
        state = drive.status(self.project)
        lines = [
            f"Authorized : {'yes' if state.get('authorized') else 'no'}",
            f"Last sync  : {state.get('last_sync') or '(never)'}",
            f"Folder ID  : {state.get('project_id') or '(not created)'}",
            f"Root ID    : {state.get('root_id') or '(not created)'}",
            f"Files      : {state.get('files', 0)}",
        ]
        url = drive.folder_url(self.project)
        if url:
            lines.append(f"URL        : {url}")
        self.drive_status.setPlainText("\n".join(lines))

    def _drive_open_folder(self) -> None:
        if self.project is None:
            return
        url = drive.folder_url(self.project)
        if not url:
            QMessageBox.information(self, "Google Drive", "Create or find the Drive folder first.")
            return
        QDesktopServices.openUrl(QUrl(url))

    def _auto_drive_sync(self) -> None:
        if self.project is None or self.worker is not None:
            return
        if not self.drive_auto.isChecked() or not drive.GOOGLE_OK:
            return
        self._run_task(lambda: drive.sync(self.project, self.settings),
                       "Auto-syncing Google Drive…", on_done=self._drive_after)

    # -- helpers ----------------------------------------------------------
    def _append_log(self, widget: QPlainTextEdit, text: str) -> None:
        if text:
            widget.appendPlainText(text)

    def _run_task(self, function: Callable[[], Any], message: str,
                  on_done: Optional[Callable[[Any], None]] = None) -> None:
        if self.worker is not None and self.worker.isRunning():
            QMessageBox.information(self, "LaTeX Studio", "Another task is still running.")
            return
        self._set_busy(True)
        self.status.setText(message)
        worker = TaskWorker(function, self)
        self.worker = worker
        worker.done.connect(lambda result: self._task_done(result, on_done))
        worker.failed.connect(self._task_failed)
        worker.finished.connect(self._task_finished)
        worker.start()

    def _task_done(self, result: Any, callback: Optional[Callable[[Any], None]]) -> None:
        if callback is not None:
            try:
                callback(result)
            except Exception as exc:
                QMessageBox.warning(self, "LaTeX Studio", str(exc))

    def _task_failed(self, message: str) -> None:
        QMessageBox.warning(self, "LaTeX Studio", message)
        self.status.setText("Task failed.")

    def _task_finished(self) -> None:
        self.worker = None
        self._set_busy(False)

    def _set_busy(self, busy: bool) -> None:
        for widget in self._task_widgets:
            widget.setEnabled(not busy)
        self.cancel_btn.setEnabled(busy and self.build_process is not None)
