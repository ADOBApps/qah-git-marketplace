"""LaTeX editor widget with line numbers and syntax highlighting.

GPL-3.0-or-later.
"""

from __future__ import annotations

import re

from PySide6.QtCore import QRect, QSize, Qt
from PySide6.QtGui import (
    QColor,
    QFont,
    QFontMetricsF,
    QPainter,
    QSyntaxHighlighter,
    QTextCharFormat,
    QTextCursor,
    QTextFormat,
)
from PySide6.QtWidgets import QPlainTextEdit, QTextEdit, QWidget


class LineNumberArea(QWidget):
    def __init__(self, editor: "LatexEditor"):
        super().__init__(editor)
        self.editor = editor

    def sizeHint(self) -> QSize:
        return QSize(self.editor.line_number_area_width(), 0)

    def paintEvent(self, event):
        self.editor.line_number_area_paint_event(event)


class LatexHighlighter(QSyntaxHighlighter):
    def __init__(self, document):
        super().__init__(document)

        def fmt(color: str, bold: bool = False, italic: bool = False) -> QTextCharFormat:
            result = QTextCharFormat()
            result.setForeground(QColor(color))
            if bold:
                result.setFontWeight(QFont.Weight.Bold)
            if italic:
                result.setFontItalic(True)
            return result

        self.comment = fmt("#6b7280", italic=True)
        self.command = fmt("#1d4ed8", bold=True)
        self.math = fmt("#7c3aed")
        self.environment = fmt("#047857", bold=True)
        self.brace = fmt("#b45309")
        self.reference = fmt("#be123c")
        self.number = fmt("#0f766e")
        self.rule = fmt("#6b7280")

        self.rules = [
            (re.compile(r"%[^\n]*"), self.comment),
            (re.compile(r"\\[A-Za-z@]+\*?"), self.command),
            (re.compile(r"\\(?:begin|end)\{[^}]+\}"), self.environment),
            (re.compile(r"\\(?:cite|ref|eqref|autoref|label|url|href)\{[^}]*\}"), self.reference),
            (re.compile(r"\$\$?[^$\n]*\$\$?"), self.math),
            (re.compile(r"\\\[[^\n]*\\\]|\\\([^\n]*\\\)"), self.math),
            (re.compile(r"\{|\}"), self.brace),
            (re.compile(r"(?<![A-Za-z_])\d+(?:\.\d+)?(?![A-Za-z_])"), self.number),
        ]

    def highlightBlock(self, text: str) -> None:
        for pattern, style in self.rules:
            for match in pattern.finditer(text):
                start, end = match.span()
                self.setFormat(start, end - start, style)


class LatexEditor(QPlainTextEdit):
    def __init__(self, text: str = "", parent=None):
        super().__init__(parent)
        self.setPlainText(text)
        font = QFont("Consolas", 11)
        font.setStyleHint(QFont.StyleHint.Monospace)
        self.setFont(font)
        self.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        self.setTabStopDistance(QFontMetricsF(font).horizontalAdvance(" ") * 4)
        self.line_number_area = LineNumberArea(self)
        self.blockCountChanged.connect(self.update_line_number_area_width)
        self.updateRequest.connect(self.update_line_number_area)
        self.cursorPositionChanged.connect(self.highlight_current_line)
        self.highlighter = LatexHighlighter(self.document())
        self.update_line_number_area_width()
        self.highlight_current_line()

    def set_wrap(self, enabled: bool) -> None:
        self.setLineWrapMode(
            QPlainTextEdit.LineWrapMode.WidgetWidth
            if enabled
            else QPlainTextEdit.LineWrapMode.NoWrap
        )

    def line_number_area_width(self) -> int:
        digits = max(2, len(str(max(1, self.blockCount()))))
        return 12 + self.fontMetrics().horizontalAdvance("9") * digits

    def update_line_number_area_width(self) -> None:
        self.setViewportMargins(self.line_number_area_width(), 0, 0, 0)

    def update_line_number_area(self, rect: QRect, dy: int) -> None:
        if dy:
            self.line_number_area.scroll(0, dy)
        else:
            self.line_number_area.update(0, rect.y(), self.line_number_area.width(), rect.height())
        if rect.contains(self.viewport().rect()):
            self.update_line_number_area_width()

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        contents = self.contentsRect()
        self.line_number_area.setGeometry(
            QRect(contents.left(), contents.top(), self.line_number_area_width(), contents.height())
        )

    def line_number_area_paint_event(self, event) -> None:
        painter = QPainter(self.line_number_area)
        painter.fillRect(event.rect(), QColor("#f3f4f6"))
        block = self.firstVisibleBlock()
        number = block.blockNumber() + 1
        top = int(self.blockBoundingGeometry(block).translated(self.contentOffset()).top())
        bottom = top + int(self.blockBoundingRect(block).height())
        painter.setPen(QColor("#6b7280"))
        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                painter.drawText(
                    0, top, self.line_number_area.width() - 6, self.fontMetrics().height(),
                    Qt.AlignmentFlag.AlignRight, str(number),
                )
            block = block.next()
            top = bottom
            bottom = top + int(self.blockBoundingRect(block).height())
            number += 1

    def highlight_current_line(self) -> None:
        selections = []
        if not self.isReadOnly():
            selection = QTextEdit.ExtraSelection()
            selection.format.setBackground(QColor("#eef6ff"))
            selection.format.setProperty(QTextFormat.Property.FullWidthSelection, True)
            selection.cursor = self.textCursor()
            selection.cursor.clearSelection()
            selections.append(selection)
        self.setExtraSelections(selections)

    def keyPressEvent(self, event) -> None:
        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            cursor = self.textCursor()
            text = cursor.block().text()
            indent = re.match(r"\s*", text).group(0)
            previous = text.rstrip()
            extra = ""
            if previous.endswith("{") or re.search(r"\\begin\{[^}]+\}\s*$", previous):
                extra = "    "
            if cursor.positionInBlock() < len(text) and text[cursor.positionInBlock()] == "}":
                extra = ""
                indent = indent[:-4] if indent.endswith("    ") else indent
            super().keyPressEvent(event)
            if indent or extra:
                self.insertPlainText(indent + extra)
            return
        if event.key() == Qt.Key.Key_Tab and not self.textCursor().hasSelection():
            self.insertPlainText("    ")
            return
        super().keyPressEvent(event)
