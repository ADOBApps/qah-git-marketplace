/*=============================================================================
 * pppm.c — PPPM reciprocal-space Ewald (ADOBMD plugin SDK).

 * Reusable solver behind adobmd_pppm.h.  Link libadobmd_pppm (static) and
 * call adobmd_pppm_create() / adobmd_pppm_reciprocal().
 *
 * Cardinal B-spline charge assignment (order 2 = CIC, order 4 = cubic),
 * FFT (embedded radix-2 or FFTW3), influence function with ik
 * differentiation, B-spline gather.
 *
 * References: Hockney & Eastwood (1988); Deserno & Holm (1998);
 *             Essmann et al. (1995).
 *===========================================================================*/
#include "adobmd_pppm.h"

#ifdef USE_FFTW3
#include <fftw3.h>
#endif
#ifdef _OPENMP
#include <omp.h>
#endif

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define PPPM_PI 3.14159265358979323846
#define K_E_SI  2.307077552e-28        /* e^2/(4 pi eps0), J m */
#define MAX_GRID 512                   /* per dimension; guards memory */

struct adobmd_pppm {
    int nx, ny, nz;          /* active grid          */
    int nx_a, ny_a, nz_a;    /* allocated grid       */
    int order;               /* B-spline order       */
    int diff;                /* 0 = ik, 1 = analytic */
    double *q_re, *q_im;     /* charge grid / reciprocal charge */
    double *w_re, *w_im;     /* scratch field        */
    double *gk;              /* per-mode influence   */
    double *tr, *ti;         /* 1-D FFT scratch      */
    int tr_n;
#ifdef USE_FFTW3
    fftw_plan plan_fwd, plan_bwd, plan_c2r;
    fftw_complex *buf;
#endif
};

#ifdef USE_FFTW3
static int g_threads_ready = 0;
static void pppm_threads_init(void)
{
#ifdef _OPENMP
    if (!g_threads_ready) { fftw_init_threads(); g_threads_ready = 1; }
    fftw_plan_with_nthreads(omp_get_max_threads());
#else
    fftw_plan_with_nthreads(1);
#endif
}
#endif

/* ------------------------------------------------------------------------- */
int adobmd_pppm_create(adobmd_pppm_t **out, int order, int diff)
{
    adobmd_pppm_t *p;
    if (!out) return 1;
    p = (adobmd_pppm_t *)calloc(1, sizeof(*p));
    if (!p) return 2;
    p->order = (order == 2) ? 2 : 4;
    p->diff  = (diff != 0) ? 1 : 0;
    *out = p;
    return 0;
}

static void adobmd_pppm_teardown(adobmd_pppm_t *p)
{
    if (!p) return;
    free(p->q_re); free(p->q_im);
    free(p->w_re); free(p->w_im);
    free(p->gk);
    free(p->tr);   free(p->ti);
    p->q_re = p->q_im = p->w_re = p->w_im = NULL;
    p->gk = p->tr = p->ti = NULL;
    p->nx_a = p->ny_a = p->nz_a = 0;
#ifdef USE_FFTW3
    if (p->plan_fwd) { fftw_destroy_plan(p->plan_fwd); p->plan_fwd = NULL; }
    if (p->plan_bwd) { fftw_destroy_plan(p->plan_bwd); p->plan_bwd = NULL; }
    if (p->plan_c2r) { fftw_destroy_plan(p->plan_c2r); p->plan_c2r = NULL; }
    if (p->buf)      { fftw_free(p->buf); p->buf = NULL; }
#endif
}

void adobmd_pppm_destroy(adobmd_pppm_t *p)
{
    if (!p) return;
    adobmd_pppm_teardown(p);
    free(p);
}

static int pppm_next_pow2(int n)
{
    int v = 1;
    if (n < 1) n = 1;
    while (v < n) v <<= 1;
    return v;
}

/* -------------------------------------------------------------------------
 * Grid selection: k_max = pi n / L must reach kcut = 2 alpha sqrt(-ln acc),
 * so n >= kcut L / pi.  Round up to a power of two (min 8, max MAX_GRID).
 * ------------------------------------------------------------------------- */
void adobmd_pppm_pick_grid(double kcut, const adobmd_cell_t *cell,
                           int *nx, int *ny, int *nz)
{
    int a = (int)ceil(kcut * fabs(cell->a[0]) / PPPM_PI);
    int b = (int)ceil(kcut * fabs(cell->b[1]) / PPPM_PI);
    int c = (int)ceil(kcut * fabs(cell->c[2]) / PPPM_PI);
    if (a < 8) a = 8;
    if (b < 8) b = 8;
    if (c < 8) c = 8;
    a = pppm_next_pow2(a); b = pppm_next_pow2(b); c = pppm_next_pow2(c);
    if (a > MAX_GRID) a = MAX_GRID;
    if (b > MAX_GRID) b = MAX_GRID;
    if (c > MAX_GRID) c = MAX_GRID;
    *nx = a; *ny = b; *nz = c;
}

/* ------------------------------------------------------------------------- */
int adobmd_pppm_set_grid(adobmd_pppm_t *p, int nx, int ny, int nz)
{
    long Ng;
    int tr_n;

    nx = pppm_next_pow2(nx);
    ny = pppm_next_pow2(ny);
    nz = pppm_next_pow2(nz);
    if (nx == p->nx_a && ny == p->ny_a && nz == p->nz_a) {
        p->nx = nx; p->ny = ny; p->nz = nz;
        return 0;
    }

    free(p->q_re); free(p->q_im);
    free(p->w_re); free(p->w_im);
    free(p->gk);
    free(p->tr);   free(p->ti);
    p->q_re = p->q_im = p->w_re = p->w_im = NULL;
    p->gk = p->tr = p->ti = NULL;
#ifdef USE_FFTW3
    if (p->plan_fwd) { fftw_destroy_plan(p->plan_fwd); p->plan_fwd = NULL; }
    if (p->plan_bwd) { fftw_destroy_plan(p->plan_bwd); p->plan_bwd = NULL; }
    if (p->plan_c2r) { fftw_destroy_plan(p->plan_c2r); p->plan_c2r = NULL; }
    if (p->buf)      { fftw_free(p->buf); p->buf = NULL; }
#endif

    Ng = (long)nx * ny * nz;
    tr_n = nx > ny ? nx : ny;
    if (nz > tr_n) tr_n = nz;

    p->q_re = (double *)calloc((size_t)Ng, sizeof(double));
    p->q_im = (double *)calloc((size_t)Ng, sizeof(double));
    p->w_re = (double *)calloc((size_t)Ng, sizeof(double));
    p->w_im = (double *)calloc((size_t)Ng, sizeof(double));
    p->gk   = (double *)calloc((size_t)Ng, sizeof(double));
    p->tr   = (double *)calloc((size_t)tr_n, sizeof(double));
    p->ti   = (double *)calloc((size_t)tr_n, sizeof(double));
    if (!p->q_re || !p->q_im || !p->w_re || !p->w_im ||
        !p->gk || !p->tr || !p->ti) {
        adobmd_pppm_teardown(p);
        return 1;
    }
    p->tr_n = tr_n;
    p->nx = p->nx_a = nx;
    p->ny = p->ny_a = ny;
    p->nz = p->nz_a = nz;

#ifdef USE_FFTW3
    pppm_threads_init();
    p->buf = (fftw_complex *)fftw_malloc((size_t)Ng * sizeof(fftw_complex));
    if (!p->buf) { adobmd_pppm_teardown(p); return 1; }
    p->plan_fwd = fftw_plan_dft_3d(nx, ny, nz, p->buf, p->buf,
                                   FFTW_FORWARD, FFTW_MEASURE);
    p->plan_bwd = fftw_plan_dft_3d(nx, ny, nz, p->buf, p->buf,
                                   FFTW_BACKWARD, FFTW_MEASURE);
    p->plan_c2r = fftw_plan_dft_c2r_3d(nx, ny, nz, p->buf, p->w_re,
                                       FFTW_MEASURE);
    if (!p->plan_fwd || !p->plan_bwd || !p->plan_c2r) {
        adobmd_pppm_teardown(p); return 1;
    }
#endif
    return 0;
}

/* -------------------------------------------------------------------------
 * Embedded radix-2 complex FFT.
 * ------------------------------------------------------------------------- */
#ifndef USE_FFTW3
static void fft1d(double *re, double *im, int n, int sign)
{
    int i, k;
    for (i = 1; i < n; ++i) {
        int j;
        {
            int x = i, r = 0, b = n >> 1;
            while (b) { if (x & 1) r |= b; x >>= 1; b >>= 1; }
            j = r;
        }
        if (i < j) {
            double t = re[i]; re[i] = re[j]; re[j] = t;
            t = im[i]; im[i] = im[j]; im[j] = t;
        }
    }
    for (int len = 2; len <= n; len <<= 1) {
        double ang = sign * 2.0 * PPPM_PI / (double)len;
        double wr = cos(ang), wi = sin(ang);
        int half = len >> 1;
        for (i = 0; i < n; i += len) {
            double cr = 1.0, ci = 0.0;
            for (k = 0; k < half; ++k) {
                int a = i + k, b = a + half;
                double xr = re[b] * cr - im[b] * ci;
                double xi = re[b] * ci + im[b] * cr;
                re[b] = re[a] - xr; im[b] = im[a] - xi;
                re[a] += xr;        im[a] += xi;
                {
                    double ncr = cr * wr - ci * wi;
                    ci = cr * wi + ci * wr;
                    cr = ncr;
                }
            }
        }
    }
}

static void fft3d_embedded(adobmd_pppm_t *p, double *re, double *im, int sign)
{
    const int nx = p->nx, ny = p->ny, nz = p->nz;
    const long nynz = (long)ny * nz;
    double *tr = p->tr, *ti = p->ti;
    int i, j, k;

    for (j = 0; j < ny; ++j)
        for (k = 0; k < nz; ++k) {
            long base = (long)j * nz + k;
            for (i = 0; i < nx; ++i) { tr[i] = re[base + (long)i * nynz]; ti[i] = im[base + (long)i * nynz]; }
            fft1d(tr, ti, nx, sign);
            for (i = 0; i < nx; ++i) { re[base + (long)i * nynz] = tr[i]; im[base + (long)i * nynz] = ti[i]; }
        }
    for (i = 0; i < nx; ++i)
        for (k = 0; k < nz; ++k) {
            long base = (long)i * nynz + k;
            for (j = 0; j < ny; ++j) { tr[j] = re[base + (long)j * nz]; ti[j] = im[base + (long)j * nz]; }
            fft1d(tr, ti, ny, sign);
            for (j = 0; j < ny; ++j) { re[base + (long)j * nz] = tr[j]; im[base + (long)j * nz] = ti[j]; }
        }
#pragma omp parallel for private(j) schedule(static)
    for (i = 0; i < nx; ++i)
        for (j = 0; j < ny; ++j) {
            long base = ((long)i * ny + j) * nz;
            fft1d(re + base, im + base, nz, sign);
        }
}
#endif /* !USE_FFTW3 */

static void fft3d(adobmd_pppm_t *p, double *re, double *im, int sign)
{
#ifdef USE_FFTW3
    long Ng = (long)p->nx * p->ny * p->nz;
    long i;
    for (i = 0; i < Ng; ++i) { p->buf[i][0] = re[i]; p->buf[i][1] = im[i]; }
    fftw_execute(sign < 0 ? p->plan_fwd : p->plan_bwd);
    for (i = 0; i < Ng; ++i) { re[i] = p->buf[i][0]; im[i] = p->buf[i][1]; }
#else
    fft3d_embedded(p, re, im, sign);
#endif
}

#ifdef USE_FFTW3
/* Inverse transform of a Hermitian half-spectrum (kz = 0..nz/2) held in
 * p->buf into p->w_re.  No normalisation, matching the complex inverse. */
static void fft3d_c2r(adobmd_pppm_t *p)
{
    fftw_execute(p->plan_c2r);
}
#endif

/* -------------------------------------------------------------------------
 * Cardinal B-spline of order m (m = 2 CIC, m = 4 cubic), support [0,m].
 * ------------------------------------------------------------------------- */
static double bspline(int m, double u)
{
    if (u <= 0.0 || u >= (double)m) return 0.0;
    if (m == 2) return (u < 1.0) ? u : 2.0 - u;
    /* m == 4 */
    if (u < 1.0) return u * u * u / 6.0;
    if (u < 2.0) return (-3.0*u*u*u + 12.0*u*u - 12.0*u + 4.0) / 6.0;
    if (u < 3.0) return (3.0*u*u*u - 24.0*u*u + 60.0*u - 44.0) / 6.0;
    { double v = 4.0 - u; return v * v * v / 6.0; }
}

static double bspline3(double u)
{
    if (u <= 0.0 || u >= 3.0) return 0.0;
    if (u < 1.0) return 0.5 * u * u;
    if (u < 2.0) return 0.5 * (-2.0*u*u + 6.0*u - 3.0);
    { double v = 3.0 - u; return 0.5 * v * v; }
}

/* d/du of the order-m cardinal B-spline. */
static double bspline_d(int m, double u)
{
    if (m == 2) {
        if (u <= 0.0 || u >= 2.0) return 0.0;
        return (u < 1.0) ? 1.0 : -1.0;
    }
    return bspline3(u) - bspline3(u - 1.0);
}

/* Grid points and weights for one coordinate. */
static void spline_1d(int m, double x, double h, int n,
                      int *idx, double *w)
{
    double f = x / h;
    int base = (int)floor(f) - m / 2 + 1;
    for (int t = 0; t < m; ++t) {
        double u = f - (double)(base + t) + 0.5 * (double)m;
        int id = (base + t) % n;
        if (id < 0) id += n;
        idx[t] = id;
        w[t] = bspline(m, u);
    }
}

/* Grid points, weights and d(weight)/dx for one coordinate. */
static void spline_1d_d(int m, double x, double h, int n,
                        int *idx, double *w, double *dw)
{
    double f = x / h;
    int base = (int)floor(f) - m / 2 + 1;
    for (int t = 0; t < m; ++t) {
        double u = f - (double)(base + t) + 0.5 * (double)m;
        int id = (base + t) % n;
        if (id < 0) id += n;
        idx[t] = id;
        w[t]  = bspline(m, u);
        dw[t] = bspline_d(m, u) / h;
    }
}

/* -------------------------------------------------------------------------
 * Reciprocal energy and (optionally) forces (ik differentiation).
 *
 *   W(k)  = prod_d sinc(k_d h_d / 2)^m          (assignment window)
 *   Q(k)  ~ S(k) W(k)
 *   E_rec = (2 pi/V) K_E sum exp(-k^2/4a^2)/k^2 |Q|^2 / W^2
 *   P(k)  = (4 pi/V) K_E exp(...)/k^2 Q / W      (mesh potential)
 *   E(k)  = -i k P(k)  -> inverse FFT -> gather
 * ------------------------------------------------------------------------- */
/* Aliased assignment-window coefficients (LAMMPS compute_gf_denom).
 *   S(sin^2) = sum_l b[l] sin^{2l}(arg),   denominator = (Sx Sy Sz)^2
 */
static void gf_denom_coeffs(int order, double *b)
{
    int l, m;
    for (l = 1; l < order; ++l) b[l] = 0.0;
    b[0] = 1.0;
    for (m = 1; m < order; ++m) {
        for (l = m; l > 0; --l)
            b[l] = 4.0 * (b[l]*(l-m)*(l-m-0.5) - b[l-1]*(l-m-1)*(l-m-1));
        b[0] = 4.0 * (b[0]*(0.0-m)*(0.0-m-0.5));
    }
    {
        double ifact = 1.0;
        for (l = 1; l < 2*order; ++l) ifact *= (double)l;
        for (l = 0; l < order; ++l) b[l] /= ifact;
    }
}

static double gf_poly(const double *b, int order, double sn2)
{
    double p = b[order-1];
    for (int l = order-2; l >= 0; --l) p = b[l] + p * sn2;
    return p;
}

double adobmd_pppm_reciprocal(adobmd_pppm_t *p, int n, const double *pos, const double *q,
                       const adobmd_cell_t *cell, double alpha,
                       double *fx, double *fy, double *fz)
{
    const double Lx = cell->a[0], Ly = cell->b[1], Lz = cell->c[2];
    const double hx = Lx / p->nx, hy = Ly / p->ny, hz = Lz / p->nz;
    const long Ng = (long)p->nx * p->ny * p->nz;
    const double V = Lx * Ly * Lz;
    const double a2 = alpha * alpha;
    const double cE = K_E_SI / (2.0 * V);      /* energy prefactor     */
    const double cP = K_E_SI / V;              /* potential prefactor  */
    const int m = (p->order == 2) ? 2 : 4;
    const int m2 = 2 * m;
    double b[8];
    double energy = 0.0;
    int i, j, k, a;

    if (fabs(cell->a[1]) > 1e-9 * fabs(Lx) ||
        fabs(cell->a[2]) > 1e-9 * fabs(Lx) ||
        fabs(cell->b[0]) > 1e-9 * fabs(Ly) ||
        fabs(cell->b[2]) > 1e-9 * fabs(Ly) ||
        fabs(cell->c[0]) > 1e-9 * fabs(Lz) ||
        fabs(cell->c[1]) > 1e-9 * fabs(Lz)) return NAN;
    if (Lx <= 0.0 || Ly <= 0.0 || Lz <= 0.0) return NAN;

    gf_denom_coeffs(m, b);

    /* --- charge assignment --- */
    memset(p->q_re, 0, (size_t)Ng * sizeof(double));
    memset(p->q_im, 0, (size_t)Ng * sizeof(double));
    for (a = 0; a < n; ++a) {
        int ix[4], iy[4], iz[4];
        double wx[4], wy[4], wz[4], qa = q[a];
        spline_1d(m, pos[3*a],     hx, p->nx, ix, wx);
        spline_1d(m, pos[3*a + 1], hy, p->ny, iy, wy);
        spline_1d(m, pos[3*a + 2], hz, p->nz, iz, wz);
        for (int cx = 0; cx < m; ++cx)
            for (int cy = 0; cy < m; ++cy)
                for (int cz = 0; cz < m; ++cz) {
                    long id = ((long)ix[cx] * p->ny + iy[cy]) * p->nz + iz[cz];
                    p->q_re[id] += qa * wx[cx] * wy[cy] * wz[cz];
                }
    }

    fft3d(p, p->q_re, p->q_im, -1);

    /* --- per-mode influence function (aliased window denominator) ---
     * 1-D tables avoid recomputing sin()/pow() inside the (i,j,k) loops. */
    {
        double *px = (double *)malloc((size_t)p->nx * sizeof(double));
        double *wx = (double *)malloc((size_t)p->nx * sizeof(double));
        double *py = (double *)malloc((size_t)p->ny * sizeof(double));
        double *wy = (double *)malloc((size_t)p->ny * sizeof(double));
        double *pz = (double *)malloc((size_t)p->nz * sizeof(double));
        double *wz = (double *)malloc((size_t)p->nz * sizeof(double));
        if (!px || !wx || !py || !wy || !pz || !wz) {
            free(px); free(wx); free(py); free(wy); free(pz); free(wz);
            return NAN;
        }
        for (i = 0; i < p->nx; ++i) {
            int mi = (i <= p->nx / 2) ? i : i - p->nx;
            double a = PPPM_PI * (double)mi / (double)p->nx;
            double s2 = sin(a); s2 *= s2;
            px[i] = gf_poly(b, m, s2);
            wx[i] = (mi == 0) ? 1.0 : pow(sin(a)/a, (double)m2);
        }
        for (j = 0; j < p->ny; ++j) {
            int mj = (j <= p->ny / 2) ? j : j - p->ny;
            double a = PPPM_PI * (double)mj / (double)p->ny;
            double s2 = sin(a); s2 *= s2;
            py[j] = gf_poly(b, m, s2);
            wy[j] = (mj == 0) ? 1.0 : pow(sin(a)/a, (double)m2);
        }
        for (k = 0; k < p->nz; ++k) {
            int mk = (k <= p->nz / 2) ? k : k - p->nz;
            double a = PPPM_PI * (double)mk / (double)p->nz;
            double s2 = sin(a); s2 *= s2;
            pz[k] = gf_poly(b, m, s2);
            wz[k] = (mk == 0) ? 1.0 : pow(sin(a)/a, (double)m2);
        }
#pragma omp parallel for private(j,k) schedule(static)
        for (i = 0; i < p->nx; ++i) {
            int mi = (i <= p->nx / 2) ? i : i - p->nx;
            double kx = 2.0 * PPPM_PI * mi / Lx;
            for (j = 0; j < p->ny; ++j) {
                int mj = (j <= p->ny / 2) ? j : j - p->ny;
                double ky = 2.0 * PPPM_PI * mj / Ly;
                double pxy = px[i] * py[j];
                double wxy = wx[i] * wy[j];
                for (k = 0; k < p->nz; ++k) {
                    int mk = (k <= p->nz / 2) ? k : k - p->nz;
                    double kz = 2.0 * PPPM_PI * mk / Lz;
                    double k2 = kx*kx + ky*ky + kz*kz;
                    double den;
                    long id = ((long)i * p->ny + j) * p->nz + k;
                    if (k2 == 0.0) { p->gk[id] = 0.0; continue; }
                    den = pxy * pz[k]; den *= den;
                    p->gk[id] = (4.0 * PPPM_PI / k2) * exp(-k2 / (4.0 * a2)) *
                                wxy * wz[k] / den;
                }
            }
        }
        free(px); free(wx); free(py); free(wy); free(pz); free(wz);
    }

    /* --- energy --- */
#pragma omp parallel for reduction(+:energy) schedule(static)
    for (long id = 0; id < Ng; ++id) {
        if (p->gk[id] == 0.0) continue;
        energy += p->gk[id] *
                  (p->q_re[id] * p->q_re[id] + p->q_im[id] * p->q_im[id]);
    }
    energy *= cE;

    if (!fx && !fy && !fz) return energy;

    if (p->diff) {
        /* --- analytic differentiation --- */
#pragma omp parallel for schedule(static)
        for (long id = 0; id < Ng; ++id) {
            p->w_re[id] = cP * p->gk[id] * p->q_re[id];
            p->w_im[id] = cP * p->gk[id] * p->q_im[id];
        }
        fft3d(p, p->w_re, p->w_im, +1);
#pragma omp parallel for schedule(static)
        for (a = 0; a < n; ++a) {
            int ix[4], iy[4], iz[4];
            double wx[4], wy[4], wz[4], dx[4], dy[4], dz[4];
            double fxl = 0.0, fyl = 0.0, fzl = 0.0;
            spline_1d_d(m, pos[3*a],     hx, p->nx, ix, wx, dx);
            spline_1d_d(m, pos[3*a + 1], hy, p->ny, iy, wy, dy);
            spline_1d_d(m, pos[3*a + 2], hz, p->nz, iz, wz, dz);
            for (int cx = 0; cx < m; ++cx)
                for (int cy = 0; cy < m; ++cy)
                    for (int cz = 0; cz < m; ++cz) {
                        long id = ((long)ix[cx] * p->ny + iy[cy]) * p->nz + iz[cz];
                        double phi = p->w_re[id];
                        fxl += dx[cx] * wy[cy] * wz[cz] * phi;
                        fyl += wx[cx] * dy[cy] * wz[cz] * phi;
                        fzl += wx[cx] * wy[cy] * dz[cz] * phi;
                    }
            if (fx) fx[a] -= q[a] * fxl;
            if (fy) fy[a] -= q[a] * fyl;
            if (fz) fz[a] -= q[a] * fzl;
        }
        return energy;
    }

    /* --- ik differentiation --- */
    for (int comp = 0; comp < 3; ++comp) {
        double *out = (comp == 0) ? fx : (comp == 1) ? fy : fz;
        if (!out) continue;
#ifdef USE_FFTW3
        {
            const int nzh = p->nz / 2 + 1;
#pragma omp parallel for private(j,k) schedule(static)
            for (i = 0; i < p->nx; ++i) {
                int mi = (i <= p->nx / 2) ? i : i - p->nx;
                double kx = 2.0 * PPPM_PI * mi / Lx;
                for (j = 0; j < p->ny; ++j) {
                    int mj = (j <= p->ny / 2) ? j : j - p->ny;
                    double ky = 2.0 * PPPM_PI * mj / Ly;
                    for (k = 0; k < nzh; ++k) {
                        long idf = ((long)i * p->ny + j) * p->nz + k;
                        long idh = ((long)i * p->ny + j) * nzh + k;
                        double kc, cp;
                        if (p->gk[idf] == 0.0) {
                            p->buf[idh][0] = 0.0; p->buf[idh][1] = 0.0;
                            continue;
                        }
                        kc = (comp == 0) ? kx : (comp == 1) ? ky
                             : (2.0 * PPPM_PI * k / Lz);
                        cp = cP * p->gk[idf];
                        p->buf[idh][0] =  kc * cp * p->q_im[idf];
                        p->buf[idh][1] = -kc * cp * p->q_re[idf];
                    }
                }
            }
            fft3d_c2r(p);
        }
#else
        for (i = 0; i < p->nx; ++i) {
            int mi = (i <= p->nx / 2) ? i : i - p->nx;
            double kx = 2.0 * PPPM_PI * mi / Lx;
            for (j = 0; j < p->ny; ++j) {
                int mj = (j <= p->ny / 2) ? j : j - p->ny;
                double ky = 2.0 * PPPM_PI * mj / Ly;
                for (k = 0; k < p->nz; ++k) {
                    long id = ((long)i * p->ny + j) * p->nz + k;
                    int mk = (k <= p->nz / 2) ? k : k - p->nz;
                    double kc, cp;
                    if (p->gk[id] == 0.0) { p->w_re[id] = 0.0; p->w_im[id] = 0.0; continue; }
                    kc = (comp == 0) ? kx : (comp == 1) ? ky : (2.0 * PPPM_PI * mk / Lz);
                    cp = cP * p->gk[id];
                    p->w_re[id] =  kc * cp * p->q_im[id];
                    p->w_im[id] = -kc * cp * p->q_re[id];
                }
            }
        }
        fft3d(p, p->w_re, p->w_im, +1);
#endif
#pragma omp parallel for schedule(static)
        for (a = 0; a < n; ++a) {
            int ix[4], iy[4], iz[4];
            double wx[4], wy[4], wz[4], e = 0.0;
            spline_1d(m, pos[3*a],     hx, p->nx, ix, wx);
            spline_1d(m, pos[3*a + 1], hy, p->ny, iy, wy);
            spline_1d(m, pos[3*a + 2], hz, p->nz, iz, wz);
            for (int cx = 0; cx < m; ++cx)
                for (int cy = 0; cy < m; ++cy)
                    for (int cz = 0; cz < m; ++cz) {
                        long id = ((long)ix[cx] * p->ny + iy[cy]) * p->nz + iz[cz];
                        e += wx[cx] * wy[cy] * wz[cz] * p->w_re[id];
                    }
            out[a] += q[a] * e;
        }
    }
    return energy;
}
