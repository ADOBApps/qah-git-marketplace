# Bundled periodic_ff plugin

`periodic_ff.so` / `periodic_ff.dll` are prebuilt. To rebuild:

```bash
./build.sh          # needs the ADOBMD SDK (sdk/pppm.c, include/adobmd_pppm.h)
```

The SDK source is mirrored here (`pppm.c`, `adobmd_pppm.h`, `adobmd_plugin_sdk.h`).
