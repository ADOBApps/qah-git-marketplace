/*=============================================================================
 * periodic_ff.c — generic periodic ionic/molecular plugin for ADOBMD (ABI 2)
 *
 * Buckingham + Lennard-Jones + Coulomb.  Electrostatics are Ewald, either
 *   method ewald   direct reciprocal sum (reference implementation) or
 *   method pppm    particle-particle particle-mesh (FFT reciprocal space)
 * Both use the same Gaussian splitting, so energies agree to the grid error.
 * Analytic forces are provided, so ADOBMD can skip the 6N+1 finite-difference
 * path.
 *
 * Parameter file (indices 0-based; lengths in Angstrom, energies in eV):
 *
 *   format 2
 *   natoms 216
 *   accuracy 1.0e-7
 *   method pppm            # or ewald
 *   grid 32 32 32          # optional; 0 0 0 / absent = automatic
 *   alpha 0.46             # optional, 1/Angstrom
 *   rcut 8.0               # optional, Angstrom
 *   slab 0
 *   charge   0  -1.2
 *   buck     0 1 16957.0 0.194 12.59     # A, rho, C
 *   lj       0 1 3.0 0.01                # sigma, epsilon
 *   exclude  0 1
 *   scale14  0 5
 *
 * The cell comes from adobmd_system_t.cell (ABI 2); if that is NULL the
 * orthorhombic box(3) is used.
 *
 * References: Ewald (1921); de Leeuw, Perram & Smith (1980); Yeh & Berkowitz
 * (1999); Buckingham (1938); Hockney & Eastwood (1988); Deserno & Holm (1998);
 * Essmann et al. (1995).
 *===========================================================================*/

#include "adobmd_plugin.h"
#include "adobmd_plugin_sdk.h"
#include "adobmd_pppm.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#define EV_TO_J 1.602176634e-19
#define K_E_SI  2.307077552e-28       /* e^2/(4 pi eps0), J m */
#define ANG     1.0e-10
#define CUT_MAX (12.0 * ANG)
#define PI      3.14159265358979323846

enum { METHOD_EWALD = 0, METHOD_PPPM = 1 };

static int      g_natoms = 0;
static double   g_accuracy = 1.0e-6;
static int      g_slab = 0;
static int      g_method = METHOD_PPPM;
static int      g_grid[3] = {0, 0, 0};
static int      g_order = 4;      /* B-spline order: 2 or 4 */
static int      g_diff = 0;       /* 1 = analytic, 0 = ik (default) */
static double   g_alpha = 0.0;    /* metres, 0 = automatic */
static double   g_rcut = 0.0;     /* metres, 0 = automatic */
static double   g_cut_nb = 12.0 * ANG;  /* Buckingham/LJ cutoff */
static int      g_have_excl = 0;  /* any exclude/scale14 line */
static int      g_use_cells = 1;  /* cell list for the real-space loop */

/* Species-based parameters, resolved to atom pairs at init using
 * sys->sites[i].z (atomic number).  Much shorter than enumerating every
 * pair by index for a crystal. */
#define MAX_ZPARAM 64
static int g_n_charge_z = 0;
static struct { int z; double q; } g_charge_z[MAX_ZPARAM];
static int g_n_buck_z = 0;
static struct { int za, zb; double a, rho, c; } g_buck_z[MAX_ZPARAM];
static int g_n_lj_z = 0;
static struct { int za, zb; double sig, eps; } g_lj_z[MAX_ZPARAM];
static int g_n_ped_z = 0;
static struct { int za, zb; double d, a, r0, b; } g_ped_z[MAX_ZPARAM];
static double  *g_q = NULL;
static double  *g_buck_a = NULL, *g_buck_rho = NULL, *g_buck_c = NULL;
static double  *g_lj_sigma = NULL, *g_lj_eps = NULL;
static double  *g_ped_d = NULL, *g_ped_a = NULL, *g_ped_r0 = NULL, *g_ped_b = NULL;
static unsigned char *g_excl = NULL, *g_s14 = NULL;
static double  *g_fx = NULL, *g_fy = NULL, *g_fz = NULL;
static adobmd_pppm_t *g_pppm = NULL;

static void reset_state(void)
{
    free(g_q); free(g_buck_a); free(g_buck_rho); free(g_buck_c);
    free(g_lj_sigma); free(g_lj_eps); free(g_excl); free(g_s14);
    free(g_ped_d); free(g_ped_a); free(g_ped_r0); free(g_ped_b);
    g_ped_d = g_ped_a = g_ped_r0 = g_ped_b = NULL;
    free(g_fx); free(g_fy); free(g_fz);
    g_fx = NULL; g_fy = NULL; g_fz = NULL;
    g_q = NULL; g_buck_a = NULL; g_buck_rho = NULL; g_buck_c = NULL;
    g_lj_sigma = NULL; g_lj_eps = NULL; g_excl = NULL; g_s14 = NULL;
    adobmd_pppm_destroy(g_pppm);
    g_pppm = NULL;
    g_natoms = 0; g_accuracy = 1.0e-6; g_slab = 0;
    g_method = METHOD_PPPM;
    g_grid[0] = g_grid[1] = g_grid[2] = 0;
    g_order = 4; g_diff = 0;
    g_alpha = 0.0; g_rcut = 0.0;
    g_cut_nb = 12.0 * ANG; g_have_excl = 0; g_use_cells = 1;
}

static int pair_index(int i, int j) { return i * g_natoms + j; }

static int flag(const unsigned char *mask, int i, int j)
{
    if (!mask || i < 0 || j < 0 || i >= g_natoms || j >= g_natoms) return 0;
    return mask[pair_index(i, j)];
}

/* Exact minimum image for orthorhombic cells (the host always supplies one);
 * falls back to the 27-image search for triclinic cells. */
static void min_image(const adobmd_cell_t *cell, double r[3], int ortho)
{
    if (ortho) {
        r[0] -= cell->a[0] * round(r[0] / cell->a[0]);
        r[1] -= cell->b[1] * round(r[1] / cell->b[1]);
        r[2] -= cell->c[2] * round(r[2] / cell->c[2]);
    } else {
        adobmd_min_image(cell, r);
    }
}

int adobmd_plugin_query(adobmd_plugin_info_t *info)
{
    memset(info, 0, sizeof(*info));
    info->name              = "periodic_ff";
    info->abi_version       = ADOBMD_PLUGIN_ABI_VERSION;
    info->thread_safe       = 1;
    info->needs_forces      = 1;
    info->interaction_order = 0;
    return 0;
}

int adobmd_plugin_init(const adobmd_system_t *sys, const char *params)
{
    reset_state();
    char path[1024];
    if (!params || !*params) {
        fprintf(stderr, "periodic_ff: missing params=\"path\"\n");
        return 1;
    }
    const char *p = params;
    const char *eq = strstr(params, "params=");
    if (eq) p = eq + 7;
    while (*p == '"' || *p == '\'' || isspace((unsigned char)*p)) p++;
    snprintf(path, sizeof(path), "%s", p);
    size_t n = strlen(path);
    while (n > 0 && (path[n-1] == '"' || path[n-1] == '\'' ||
                     isspace((unsigned char)path[n-1]))) path[--n] = '\0';

    FILE *f = fopen(path, "r");
    if (!f) {
        fprintf(stderr, "periodic_ff: cannot open '%s'\n", path);
        return 2;
    }
    int declared = (sys ? sys->natoms : 0);
    char line[1024];
    while (fgets(line, sizeof(line), f)) {
        char tag[64];
        if (line[0] == '#' || isspace((unsigned char)line[0])) continue;
        if (sscanf(line, "%63s", tag) != 1) continue;
        if (!strcmp(tag, "natoms")) sscanf(line, "%*s %d", &declared);
    }
    if (declared <= 0) { fclose(f); return 3; }
    g_natoms = declared;

    g_q = calloc(g_natoms, sizeof(double));
    g_buck_a = calloc((size_t)g_natoms*g_natoms, sizeof(double));
    g_buck_rho = calloc((size_t)g_natoms*g_natoms, sizeof(double));
    g_buck_c = calloc((size_t)g_natoms*g_natoms, sizeof(double));
    g_lj_sigma = calloc((size_t)g_natoms*g_natoms, sizeof(double));
    g_lj_eps = calloc((size_t)g_natoms*g_natoms, sizeof(double));
    g_ped_d  = calloc((size_t)g_natoms*g_natoms, sizeof(double));
    g_ped_a  = calloc((size_t)g_natoms*g_natoms, sizeof(double));
    g_ped_r0 = calloc((size_t)g_natoms*g_natoms, sizeof(double));
    g_ped_b  = calloc((size_t)g_natoms*g_natoms, sizeof(double));
    g_excl = calloc((size_t)g_natoms*g_natoms, 1);
    g_s14 = calloc((size_t)g_natoms*g_natoms, 1);
    g_fx = calloc(g_natoms, sizeof(double));
    g_fy = calloc(g_natoms, sizeof(double));
    g_fz = calloc(g_natoms, sizeof(double));
    if (!g_q || !g_buck_a || !g_buck_rho || !g_buck_c || !g_lj_sigma ||
        !g_lj_eps || !g_excl || !g_s14 || !g_fx || !g_fy || !g_fz ||
        !g_ped_d || !g_ped_a || !g_ped_r0 || !g_ped_b) {
        fclose(f); return 4;
    }


    rewind(f);
    while (fgets(line, sizeof(line), f)) {
        char tag[64];
        if (line[0] == '#' || isspace((unsigned char)line[0])) continue;
        if (sscanf(line, "%63s", tag) != 1) continue;
        if (!strcmp(tag, "accuracy")) {
            sscanf(line, "%*s %lf", &g_accuracy);
            if (g_accuracy <= 0.0) g_accuracy = 1.0e-6;
        } else if (!strcmp(tag, "method")) {
            char m[32];
            if (sscanf(line, "%*s %31s", m) == 1) {
                if (!strcasecmp(m, "pppm")) g_method = METHOD_PPPM;
                else if (!strcasecmp(m, "ewald")) g_method = METHOD_EWALD;
            }
        } else if (!strcmp(tag, "grid")) {
            int a = 0, b = 0, c = 0;
            if (sscanf(line, "%*s %d %d %d", &a, &b, &c) == 3) {
                g_grid[0] = a; g_grid[1] = b; g_grid[2] = c;
            }
        } else if (!strcmp(tag, "diff")) {
            char m[16];
            if (sscanf(line, "%*s %15s", m) == 1) g_diff = strcasecmp(m, "ik") ? 1 : 0;
        } else if (!strcmp(tag, "order")) {
            int v; if (sscanf(line, "%*s %d", &v) == 1 && (v == 2 || v == 4)) g_order = v;
        } else if (!strcmp(tag, "alpha")) {
            double v; if (sscanf(line, "%*s %lf", &v) == 1) g_alpha = v * ANG;
        } else if (!strcmp(tag, "rcut")) {
            double v; if (sscanf(line, "%*s %lf", &v) == 1) g_rcut = v * ANG;
        } else if (!strcmp(tag, "cells")) {
            int v; if (sscanf(line, "%*s %d", &v) == 1) g_use_cells = (v != 0);
        } else if (!strcmp(tag, "cut_nb")) {
            double v; if (sscanf(line, "%*s %lf", &v) == 1) g_cut_nb = v * ANG;
        } else if (!strcmp(tag, "slab")) {
            sscanf(line, "%*s %d", &g_slab);
        } else if (!strcmp(tag, "charge_z")) {
            int z; double q;
            if (sscanf(line, "%*s %d %lf", &z, &q) == 2 && g_n_charge_z < MAX_ZPARAM) {
                g_charge_z[g_n_charge_z].z = z;
                g_charge_z[g_n_charge_z].q = q;
                g_n_charge_z++;
            }
        } else if (!strcmp(tag, "buck_z")) {
            int za, zb; double a, rho, c;
            if (sscanf(line, "%*s %d %d %lf %lf %lf", &za, &zb, &a, &rho, &c) == 5 &&
                g_n_buck_z < MAX_ZPARAM) {
                g_buck_z[g_n_buck_z].za = za;
                g_buck_z[g_n_buck_z].zb = zb;
                g_buck_z[g_n_buck_z].a = a;
                g_buck_z[g_n_buck_z].rho = rho;
                g_buck_z[g_n_buck_z].c = c;
                g_n_buck_z++;
            }
        } else if (!strcmp(tag, "pedone_z")) {
            int za, zb; double d, a, r0, b;
            if (sscanf(line, "%*s %d %d %lf %lf %lf %lf", &za, &zb, &d, &a, &r0, &b) == 6 &&
                g_n_ped_z < MAX_ZPARAM) {
                g_ped_z[g_n_ped_z].za = za; g_ped_z[g_n_ped_z].zb = zb;
                g_ped_z[g_n_ped_z].d  = d * EV_TO_J;
                g_ped_z[g_n_ped_z].a  = a / ANG;
                g_ped_z[g_n_ped_z].r0 = r0 * ANG;
                g_ped_z[g_n_ped_z].b  = b * EV_TO_J * pow(ANG, 12);
                g_n_ped_z++;
            }
        } else if (!strcmp(tag, "pedone")) {
            int i, j; double d, a, r0, b;
            if (sscanf(line, "%*s %d %d %lf %lf %lf %lf", &i, &j, &d, &a, &r0, &b) == 6 &&
                i >= 0 && j >= 0 && i < g_natoms && j < g_natoms) {
                g_ped_d[pair_index(i,j)]  = g_ped_d[pair_index(j,i)]  = d * EV_TO_J;
                g_ped_a[pair_index(i,j)]  = g_ped_a[pair_index(j,i)]  = a / ANG;
                g_ped_r0[pair_index(i,j)] = g_ped_r0[pair_index(j,i)] = r0 * ANG;
                g_ped_b[pair_index(i,j)]  = g_ped_b[pair_index(j,i)]  = b * EV_TO_J * pow(ANG, 12);
            }
        } else if (!strcmp(tag, "lj_z")) {
            int za, zb; double sig, eps;
            if (sscanf(line, "%*s %d %d %lf %lf", &za, &zb, &sig, &eps) == 4 &&
                g_n_lj_z < MAX_ZPARAM) {
                g_lj_z[g_n_lj_z].za = za;
                g_lj_z[g_n_lj_z].zb = zb;
                g_lj_z[g_n_lj_z].sig = sig;
                g_lj_z[g_n_lj_z].eps = eps;
                g_n_lj_z++;
            }
        } else if (!strcmp(tag, "charge")) {
            int i; double q;
            if (sscanf(line, "%*s %d %lf", &i, &q) == 2 &&
                i >= 0 && i < g_natoms) g_q[i] = q;
        } else if (!strcmp(tag, "buck")) {
            int i, j; double a, rho, c;
            if (sscanf(line, "%*s %d %d %lf %lf %lf", &i, &j, &a, &rho, &c) == 5 &&
                i >= 0 && j >= 0 && i < g_natoms && j < g_natoms) {
                g_buck_a[pair_index(i,j)] = a * EV_TO_J;
                g_buck_a[pair_index(j,i)] = a * EV_TO_J;
                g_buck_rho[pair_index(i,j)] = rho * ANG;
                g_buck_rho[pair_index(j,i)] = rho * ANG;
                g_buck_c[pair_index(i,j)] = c * EV_TO_J * pow(ANG, 6);
                g_buck_c[pair_index(j,i)] = c * EV_TO_J * pow(ANG, 6);
            }
        } else if (!strcmp(tag, "lj")) {
            int i, j; double sigma, eps;
            if (sscanf(line, "%*s %d %d %lf %lf", &i, &j, &sigma, &eps) == 4 &&
                i >= 0 && j >= 0 && i < g_natoms && j < g_natoms) {
                g_lj_sigma[pair_index(i,j)] = sigma * ANG;
                g_lj_sigma[pair_index(j,i)] = sigma * ANG;
                g_lj_eps[pair_index(i,j)] = eps * EV_TO_J;
                g_lj_eps[pair_index(j,i)] = eps * EV_TO_J;
            }
        } else if (!strcmp(tag, "exclude") || !strcmp(tag, "scale14")) {
            int i, j;
            if (sscanf(line, "%*s %d %d", &i, &j) == 2 &&
                i >= 0 && j >= 0 && i < g_natoms && j < g_natoms) {
                unsigned char *mask = (tag[0] == 'e') ? g_excl : g_s14;
                mask[pair_index(i,j)] = 1;
                mask[pair_index(j,i)] = 1;
                g_have_excl = 1;
            }
        }
    }
    fclose(f);

    /* Resolve species-based parameters to atom pairs. */
    if (g_n_charge_z || g_n_buck_z || g_n_lj_z || g_n_ped_z) {
        if (!sys || !sys->sites) {
            fprintf(stderr, "periodic_ff: species parameters require sys->sites\n");
        } else {
            for (int i = 0; i < g_natoms; ++i) {
                int zi = sys->sites[i].z;
                for (int t = 0; t < g_n_charge_z; ++t)
                    if (g_charge_z[t].z == zi) g_q[i] = g_charge_z[t].q;
            }
            for (int i = 0; i < g_natoms - 1; ++i) {
                for (int j = i + 1; j < g_natoms; ++j) {
                    int zi = sys->sites[i].z, zj = sys->sites[j].z;
                    int ij = pair_index(i, j), ji = pair_index(j, i);
                    for (int t = 0; t < g_n_buck_z; ++t) {
                        int za = g_buck_z[t].za, zb = g_buck_z[t].zb;
                        if ((za == zi && zb == zj) || (za == zj && zb == zi)) {
                            g_buck_a[ij] = g_buck_a[ji] = g_buck_z[t].a * EV_TO_J;
                            g_buck_rho[ij] = g_buck_rho[ji] = g_buck_z[t].rho * ANG;
                            g_buck_c[ij] = g_buck_c[ji] = g_buck_z[t].c * EV_TO_J * pow(ANG, 6);
                        }
                    }
                    for (int t = 0; t < g_n_ped_z; ++t) {
                        int za = g_ped_z[t].za, zb = g_ped_z[t].zb;
                        if ((za == zi && zb == zj) || (za == zj && zb == zi)) {
                            g_ped_d[ij] = g_ped_d[ji] = g_ped_z[t].d;
                            g_ped_a[ij] = g_ped_a[ji] = g_ped_z[t].a;
                            g_ped_r0[ij] = g_ped_r0[ji] = g_ped_z[t].r0;
                            g_ped_b[ij] = g_ped_b[ji] = g_ped_z[t].b;
                        }
                    }
                    for (int t = 0; t < g_n_lj_z; ++t) {
                        int za = g_lj_z[t].za, zb = g_lj_z[t].zb;
                        if ((za == zi && zb == zj) || (za == zj && zb == zi)) {
                            g_lj_sigma[ij] = g_lj_sigma[ji] = g_lj_z[t].sig * ANG;
                            g_lj_eps[ij] = g_lj_eps[ji] = g_lj_z[t].eps * EV_TO_J;
                        }
                    }
                }
            }
        }
    }

    if (adobmd_pppm_create(&g_pppm, g_order, g_diff) != 0) return 5;
    printf("periodic_ff: %d atoms, method=%s, order=%d, slab=%d, accuracy=%.1e\n",
           g_natoms, g_method == METHOD_PPPM ? "pppm" : "ewald",
           g_order, g_slab, g_accuracy);
    return 0;
}

void adobmd_plugin_finalize(void) { reset_state(); }

/* -------------------------------------------------------------------------
 * Pair body: real-space Ewald + Buckingham + LJ for one pair.
 * ------------------------------------------------------------------------- */
typedef struct {
    const double *pos;
    const adobmd_cell_t *cell;
    double rcut, r_nb, alpha;
    int ortho, periodic, want_forces;
    double *forces;
} pair_ctx_t;

static void pair_body(const pair_ctx_t *c, int i, int j, double *e)
{
    double r[3], dist, scale, dEdr = 0.0;
    if (flag(g_excl, i, j)) return;

    r[0] = c->pos[3*i]   - c->pos[3*j];
    r[1] = c->pos[3*i+1] - c->pos[3*j+1];
    r[2] = c->pos[3*i+2] - c->pos[3*j+2];
    if (c->periodic) min_image(c->cell, r, c->ortho);
    dist = sqrt(adobmd_dot(r, r));
    if (dist < 1.0e-30) return;
    if (c->periodic && dist > c->r_nb) return;
    scale = flag(g_s14, i, j) ? 0.5 : 1.0;

    if (c->periodic) {
        if (dist <= c->rcut) {
            *e += scale * K_E_SI * g_q[i]*g_q[j] * erfc(c->alpha*dist) / dist;
            dEdr = scale * K_E_SI * g_q[i]*g_q[j] *
                   (-erfc(c->alpha*dist)/(dist*dist)
                    - 2.0*c->alpha/sqrt(PI)*exp(-c->alpha*c->alpha*dist*dist)/dist);
        }
    } else {
        *e += scale * K_E_SI * g_q[i]*g_q[j] / dist;
        dEdr = -scale * K_E_SI * g_q[i]*g_q[j]/(dist*dist);
    }

    {
        double A = g_buck_a[pair_index(i,j)];
        double C = g_buck_c[pair_index(i,j)];
        double rho = g_buck_rho[pair_index(i,j)];
        if (A > 0.0 && rho > 0.0) {
            double ex = exp(-dist/rho);
            double d2 = dist*dist;
            double d6 = d2*d2*d2;
            *e += scale * (A*ex - C/d6);
            dEdr += scale * (-A/rho*ex + 6.0*C/(d6*dist));
        }
        {
            double sig = g_lj_sigma[pair_index(i,j)];
            double eps = g_lj_eps[pair_index(i,j)];
            if (sig > 0.0 && eps != 0.0) {
                double sr = sig/dist, sr6 = sr*sr*sr*sr*sr*sr, sr12 = sr6*sr6;
                *e += scale * 4.0*eps*(sr12 - sr6);
                dEdr += scale * 4.0*eps*(-12.0*sr12 + 6.0*sr6)/dist;
            }
        }
        {
            /* Pedone: D[(1 - e^{-a(r-r0)})^2 - 1] + B/r^12 */
            double pd = g_ped_d[pair_index(i,j)];
            if (pd != 0.0) {
                double pa = g_ped_a[pair_index(i,j)];
                double pr0 = g_ped_r0[pair_index(i,j)];
                double pb = g_ped_b[pair_index(i,j)];
                double e1 = exp(-pa * (dist - pr0));
                double d2 = dist*dist;
                double r12 = d2*d2*d2*d2*d2*d2;
                *e += scale * (pd*(e1*e1 - 2.0*e1) + pb/r12);
                dEdr += scale * (pd*2.0*pa*e1*(1.0 - e1) - 12.0*pb/(r12*dist));
            }
        }
    }

    if (c->want_forces && c->forces) {
        double fs = -dEdr/dist;
        c->forces[3*i]   += fs*r[0]; c->forces[3*i+1] += fs*r[1]; c->forces[3*i+2] += fs*r[2];
        c->forces[3*j]   -= fs*r[0]; c->forces[3*j+1] -= fs*r[1]; c->forces[3*j+2] -= fs*r[2];
    }
}

/* -------------------------------------------------------------------------
 * Cell list (only when every dimension has >= 3 cells, so each pair is
 * visited exactly once).  Falls back to the O(N^2) loop otherwise.
 * ------------------------------------------------------------------------- */
static int *g_cell_start = NULL;   /* ncells+1 */
static int *g_cell_items = NULL;   /* n        */
static int *g_cell_of = NULL;      /* n        */
static int  g_cell_nstart = 0, g_cell_nitems = 0;

static int cell_list_build(int n, const double *pos, const adobmd_cell_t *cell,
                           double r_nb, int *ncx, int *ncy, int *ncz)
{
    const double Lx = cell->a[0], Ly = cell->b[1], Lz = cell->c[2];
    int ncell, a, i;
    int *cur;

    *ncx = (int)(Lx / r_nb);
    *ncy = (int)(Ly / r_nb);
    *ncz = (int)(Lz / r_nb);
    if (*ncx < 3 || *ncy < 3 || *ncz < 3) return 0;

    ncell = (*ncx) * (*ncy) * (*ncz);
    if (g_cell_nstart < ncell + 1) {
        int *p = (int *)realloc(g_cell_start, (size_t)(ncell + 1) * sizeof(int));
        if (!p) return 0;
        g_cell_start = p; g_cell_nstart = ncell + 1;
    }
    if (g_cell_nitems < n) {
        int *p = (int *)realloc(g_cell_items, (size_t)n * sizeof(int));
        int *q = (int *)realloc(g_cell_of, (size_t)n * sizeof(int));
        if (!p || !q) return 0;
        g_cell_items = p; g_cell_of = q; g_cell_nitems = n;
    }

    for (i = 0; i <= ncell; ++i) g_cell_start[i] = 0;
    for (a = 0; a < n; ++a) {
        double fx = pos[3*a]   / Lx; fx -= floor(fx);
        double fy = pos[3*a+1] / Ly; fy -= floor(fy);
        double fz = pos[3*a+2] / Lz; fz -= floor(fz);
        int cx = (int)(fx * (*ncx)); if (cx >= *ncx) cx = *ncx - 1;
        int cy = (int)(fy * (*ncy)); if (cy >= *ncy) cy = *ncy - 1;
        int cz = (int)(fz * (*ncz)); if (cz >= *ncz) cz = *ncz - 1;
        g_cell_of[a] = (cx * (*ncy) + cy) * (*ncz) + cz;
        g_cell_start[g_cell_of[a] + 1]++;
    }
    for (i = 1; i <= ncell; ++i) g_cell_start[i] += g_cell_start[i-1];

    cur = (int *)malloc((size_t)ncell * sizeof(int));
    if (!cur) return 0;
    for (i = 0; i < ncell; ++i) cur[i] = g_cell_start[i];
    for (a = 0; a < n; ++a) g_cell_items[cur[g_cell_of[a]]++] = a;
    free(cur);
    return 1;
}

/* ------------------------------------------------------------------------- */
static void compute(const adobmd_system_t *sys, double *energy, double *forces,
                    int want_forces)
{
    const int n = sys->natoms;
    const double *pos = sys->pos;
    adobmd_cell_t cell;
    adobmd_cell_from_system(sys, &cell);
    double V = cell.volume;
    double alpha = 0.0, rcut = CUT_MAX, kcut = 0.0;
    double qsum = 0.0, q2sum = 0.0, mz = 0.0;
    double e = 0.0;
    int ortho = (fabs(cell.a[1]) < 1e-12 * fabs(cell.a[0]) &&
                 fabs(cell.a[2]) < 1e-12 * fabs(cell.a[0]) &&
                 fabs(cell.b[0]) < 1e-12 * fabs(cell.b[1]) &&
                 fabs(cell.b[2]) < 1e-12 * fabs(cell.b[1]) &&
                 fabs(cell.c[0]) < 1e-12 * fabs(cell.c[2]) &&
                 fabs(cell.c[1]) < 1e-12 * fabs(cell.c[2]));

    if (want_forces && forces) memset(forces, 0, (size_t)3*n*sizeof(double));

    if (V > 0.0) {
        double lmin = sqrt(adobmd_dot(cell.a, cell.a));
        double lb = sqrt(adobmd_dot(cell.b, cell.b));
        double lc = sqrt(adobmd_dot(cell.c, cell.c));
        if (lb < lmin) lmin = lb;
        if (lc < lmin) lmin = lc;

        adobmd_ewald_setup(&cell, g_accuracy, CUT_MAX, &alpha, &rcut, &kcut);
        if (g_rcut > 0.0) {
            rcut = g_rcut;
            if (rcut > 0.49 * lmin) rcut = 0.49 * lmin;
            alpha = 3.5 / rcut;
        }
        if (g_alpha > 0.0) {
            alpha = g_alpha;
            if (g_rcut <= 0.0) {
                rcut = sqrt(-log(g_accuracy)) / alpha;
                if (rcut > 0.49 * lmin) rcut = 0.49 * lmin;
            }
        }
        kcut = 2.0 * alpha * sqrt(-log(g_accuracy));
    } else {
        rcut = CUT_MAX;
    }

    /* --- real-space Ewald + Buckingham + LJ --- */
    {
        pair_ctx_t ctx;
        double r_nb = (g_cut_nb > rcut) ? g_cut_nb : rcut;
        int use_cells = 0, ncx = 0, ncy = 0, ncz = 0;

        ctx.pos = pos; ctx.cell = &cell;
        ctx.rcut = rcut; ctx.r_nb = r_nb; ctx.alpha = alpha;
        ctx.ortho = ortho; ctx.periodic = (V > 0.0);
        ctx.want_forces = (want_forces && forces);
        ctx.forces = forces;

        if (V > 0.0 && r_nb > 0.0 && g_use_cells)
            use_cells = cell_list_build(n, pos, &cell, r_nb, &ncx, &ncy, &ncz);

        if (use_cells) {
            for (int i = 0; i < n; ++i) {
                int ci = g_cell_of[i];
                int cx = ci / (ncy * ncz);
                int cy = (ci / ncz) % ncy;
                int cz = ci % ncz;
                for (int dx = -1; dx <= 1; ++dx) {
                    int jx = (cx + dx + ncx) % ncx;
                    for (int dy = -1; dy <= 1; ++dy) {
                        int jy = (cy + dy + ncy) % ncy;
                        for (int dz = -1; dz <= 1; ++dz) {
                            int jz = (cz + dz + ncz) % ncz;
                            int cj = (jx * ncy + jy) * ncz + jz;
                            for (int t = g_cell_start[cj]; t < g_cell_start[cj+1]; ++t) {
                                int j = g_cell_items[t];
                                if (j <= i) continue;
                                pair_body(&ctx, i, j, &e);
                            }
                        }
                    }
                }
            }
        } else {
            for (int i = 0; i < n - 1; ++i)
                for (int j = i + 1; j < n; ++j)
                    pair_body(&ctx, i, j, &e);
        }
    }

    if (V > 0.0) {
        /* --- reciprocal space --- */
        int used_pppm = 0;
        if (g_method == METHOD_PPPM && g_pppm && g_fx && g_fy && g_fz) {
            int nx = g_grid[0], ny = g_grid[1], nz = g_grid[2];
            if (nx <= 0 || ny <= 0 || nz <= 0)
                adobmd_pppm_pick_grid(kcut, &cell, &nx, &ny, &nz);
            if ((double)nx * ny * nz <= 16.7e6 &&
                adobmd_pppm_set_grid(g_pppm, nx, ny, nz) == 0) {
                int use_f = (want_forces && forces) ? 1 : 0;
                double er;
                if (use_f) {
                    memset(g_fx, 0, (size_t)n * sizeof(double));
                    memset(g_fy, 0, (size_t)n * sizeof(double));
                    memset(g_fz, 0, (size_t)n * sizeof(double));
                }
                er = adobmd_pppm_reciprocal(g_pppm, n, pos, g_q, &cell, alpha,
                                     use_f ? g_fx : NULL,
                                     use_f ? g_fy : NULL,
                                     use_f ? g_fz : NULL);
                if (!isnan(er)) {
                    used_pppm = 1;
                    e += er;
                    if (use_f) {
                        for (int a = 0; a < n; ++a) {
                            forces[3*a]   += g_fx[a];
                            forces[3*a+1] += g_fy[a];
                            forces[3*a+2] += g_fz[a];
                        }
                    }
                }
            }
        }

        if (!used_pppm) {
            /* direct reciprocal sum (reference / fallback) */
            double b1[3], b2[3], b3[3];
            adobmd_reciprocal(&cell, b1, b2, b3);
            int n1max = (int)ceil(kcut * sqrt(adobmd_dot(cell.a, cell.a)) / (2.0*PI));
            int n2max = (int)ceil(kcut * sqrt(adobmd_dot(cell.b, cell.b)) / (2.0*PI));
            int n3max = (int)ceil(kcut * sqrt(adobmd_dot(cell.c, cell.c)) / (2.0*PI));
            if (n1max > 64) n1max = 64;
            if (n2max > 64) n2max = 64;
            if (n3max > 64) n3max = 64;

            for (int n1 = -n1max; n1 <= n1max; ++n1) {
                for (int n2 = -n2max; n2 <= n2max; ++n2) {
                    for (int n3 = -n3max; n3 <= n3max; ++n3) {
                        double kx = n1*b1[0] + n2*b2[0] + n3*b3[0];
                        double ky = n1*b1[1] + n2*b2[1] + n3*b3[1];
                        double kz = n1*b1[2] + n2*b2[2] + n3*b3[2];
                        double k2 = kx*kx + ky*ky + kz*kz;
                        if (k2 < 1.0e-30) continue;
                        double sre = 0.0, sim = 0.0;
                        for (int a = 0; a < n; ++a) {
                            double th = kx*pos[3*a] + ky*pos[3*a+1] + kz*pos[3*a+2];
                            sre += g_q[a]*cos(th);
                            sim += g_q[a]*sin(th);
                        }
                        double aket = exp(-k2/(4.0*alpha*alpha))/k2;
                        e += (2.0*PI/V)*aket*(sre*sre + sim*sim)*K_E_SI;
                        if (want_forces && forces) {
                            double coef = (4.0*PI/V)*K_E_SI*aket;
                            for (int a = 0; a < n; ++a) {
                                double th = kx*pos[3*a] + ky*pos[3*a+1] + kz*pos[3*a+2];
                                double w = coef*g_q[a]*(sre*sin(th) - sim*cos(th));
                                forces[3*a]   += w*kx;
                                forces[3*a+1] += w*ky;
                                forces[3*a+2] += w*kz;
                            }
                        }
                    }
                }
            }
        }

        /* --- self, background --- */
        for (int a = 0; a < n; ++a) {
            double q = g_q[a];
            qsum += q; q2sum += q*q; mz += q*pos[3*a+2];
        }
        e -= alpha/sqrt(PI)*q2sum*K_E_SI;
        e -= (PI/(2.0*V*alpha*alpha))*qsum*qsum*K_E_SI;

        /* --- slab correction --- */
        if (g_slab) {
            e -= (2.0*PI/V)*mz*mz*K_E_SI;
            if (want_forces && forces) {
                for (int a = 0; a < n; ++a)
                    forces[3*a+2] += (4.0*PI/V)*mz*g_q[a]*K_E_SI;
            }
        }

        /* --- exclusion / 1-4 correction: remove the smooth erfc complement --- */
        if (g_have_excl)
        for (int i = 0; i < n - 1; ++i) {
            for (int j = i + 1; j < n; ++j) {
                int ex = flag(g_excl, i, j);
                int s14 = flag(g_s14, i, j);
                double scale, r[3], dist, er, u, dUdr, fs;
                if (!ex && !s14) continue;
                scale = ex ? 0.0 : 0.5;
                r[0] = pos[3*i] - pos[3*j];
                r[1] = pos[3*i+1] - pos[3*j+1];
                r[2] = pos[3*i+2] - pos[3*j+2];
                min_image(&cell, r, ortho);
                dist = sqrt(adobmd_dot(r, r));
                if (dist < 1.0e-30) continue;
                er = erf(alpha*dist);
                u = -K_E_SI*g_q[i]*g_q[j]*(1.0 - scale)*er/dist;
                e += u;
                if (want_forces && forces) {
                    dUdr = -K_E_SI*g_q[i]*g_q[j]*(1.0 - scale) *
                           (2.0*alpha/sqrt(PI)*exp(-alpha*alpha*dist*dist)/dist
                            - er/(dist*dist));
                    fs = -dUdr/dist;
                    forces[3*i]   += fs*r[0]; forces[3*i+1] += fs*r[1]; forces[3*i+2] += fs*r[2];
                    forces[3*j]   -= fs*r[0]; forces[3*j+1] -= fs*r[1]; forces[3*j+2] -= fs*r[2];
                }
            }
        }
    }

    *energy = e;
}

double adobmd_plugin_energy(const adobmd_system_t *sys)
{
    double e = 0.0;
    if (!sys || sys->natoms <= 0) return 0.0;
    compute(sys, &e, NULL, 0);
    return e;
}

void adobmd_plugin_forces(const adobmd_system_t *sys, double *forces)
{
    double e = 0.0;
    if (!sys || sys->natoms <= 0 || !forces) return;
    compute(sys, &e, forces, 1);
}

double adobmd_plugin_energy_forces(const adobmd_system_t *sys, double *forces)
{
    double e = 0.0;
    if (!sys || sys->natoms <= 0) return 0.0;
    compute(sys, &e, forces, forces != NULL);
    return e;
}
