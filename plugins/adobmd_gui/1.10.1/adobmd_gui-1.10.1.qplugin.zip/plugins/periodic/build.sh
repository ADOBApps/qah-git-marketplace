#!/usr/bin/env bash
# Build the generic periodic plugin (Linux .so and, if mingw is present, .dll).
#
# The PPPM solver comes from the SDK (../../sdk), linked statically so the
# plugin stays self-contained.
#
#   USE_FFTW=1  (default) use FFTW3 when pkg-config can find it
#   USE_FFTW=0            force the embedded radix-2 FFT
#
# The Windows DLL is built with OpenMP when the cross toolchain can link it,
# and automatically falls back to a serial build otherwise.
set -euo pipefail
cd "$(dirname "$0")"

CC=${CC:-cc}
CFLAGS=${CFLAGS:--O3 -march=native -shared -fPIC -Wall -fopenmp}
USE_FFTW=${USE_FFTW:-1}

# Build the SDK with the same FFT choice so headers and symbols agree.
USE_FFTW=$USE_FFTW ../../sdk/build.sh

FFTW_CFLAGS=""
FFTW_LIBS=""
if [ "$USE_FFTW" != "0" ] && pkg-config --exists fftw3 2>/dev/null; then
  FFTW_CFLAGS="-DUSE_FFTW3 $(pkg-config --cflags fftw3)"
  FFTW_LIBS="$(pkg-config --libs fftw3)"
fi

$CC $CFLAGS $FFTW_CFLAGS -I ../../include periodic_ff.c \
    ../../sdk/lib/linux/libadobmd_pppm.a \
    -o periodic_ff.so -lm -fopenmp -lfftw3_threads $FFTW_LIBS
echo "built $(pwd)/periodic_ff.so"

if command -v x86_64-w64-mingw32-gcc >/dev/null 2>&1; then
  if [ -f ../../sdk/lib/win/.omp ] && \
     x86_64-w64-mingw32-gcc -O2 -shared -fopenmp -I ../../include periodic_ff.c \
       ../../sdk/lib/win/libadobmd_pppm.a \
       -o periodic_ff.dll -lm -static-libgcc 2>/dev/null; then
    echo "built $(pwd)/periodic_ff.dll (OpenMP)"
  else
    echo "periodic_ff.dll: OpenMP unavailable, serial build"
    WIN_OMP=0 USE_FFTW=$USE_FFTW ../../sdk/build.sh >/dev/null
    x86_64-w64-mingw32-gcc -O2 -shared -I ../../include periodic_ff.c \
        ../../sdk/lib/win/libadobmd_pppm.a \
        -o periodic_ff.dll -lm -static-libgcc
    echo "built $(pwd)/periodic_ff.dll (serial)"
  fi
fi
