# periodic_ff — generic periodic plugin (ADOBMD ABI 2)

Buckingham + Lennard-Jones + Coulomb with Ewald electrostatics:

- `method pppm` — particle-particle particle-mesh (FFT reciprocal space)
- `method ewald` — direct reciprocal sum (reference / fallback)

Analytic forces are provided, so ADOBMD skips the 6N+1 finite-difference path.

## Build

```bash
./build.sh              # FFTW3 if available, otherwise embedded radix-2 FFT
USE_FFTW=0 ./build.sh   # force the embedded FFT (no libfftw3 dependency)
```

Produces `periodic_ff.so` and, when MinGW is present, `periodic_ff.dll`
(the DLL always uses the embedded FFT). Both backends give identical results;
FFTW is faster.

## Use

In a `.ff`:

```text
<Plugins>
   periodic   ./plugins/periodic/periodic_ff.so   params="./periodic.params"
</Plugins>
<NonBonded>
   O  O  Plugin periodic
   O  Ti Plugin periodic
   Ti Ti Plugin periodic
</NonBonded>
```

All pairs must be routed to the plugin (one nonbonded form per pair in
ADOBMD). The plugin reads charges and pair parameters from the file.

### Per-atom vs species parameters

Charges and pair terms can be given per atom index (`charge`, `buck`, `lj`)
or per chemical species using the atomic number:

```text
charge_z 22 2.196
charge_z 8 -1.098
buck_z 22 22 31120.421467 0.154 5.246926
buck_z 22 8 16957.662294 0.194 12.592588
buck_z 8 8 11782.850511 0.234 30.222221
```

The species form is resolved to atom pairs at plugin init from
`adobmd_system_t.sites[i].z`, so one file serves any cell containing those
species. The example above is the TiO2 TTAM (Matsui-Akaogi 1991) set,
extracted from OpenKIM model `SM_690504433912_000`.

The Pedone (PMMCS) form, `q_iq_j/r + D[(1-e^{-a(r-r0)})^2-1] + B/r^12`, is
also available:

```text
charge_z 22 2.4
charge_z 8 -1.2
pedone_z 22 8 0.024235 2.254703 2.708943 1.0
pedone_z 8 8 0.042395 1.379316 3.618701 22.0
```

(Pedone et al., *J. Phys. Chem. B* **110**, 11780 (2006), Table 2.)

## Parameters

See `params.example`. Indices are 0-based; lengths in Angstrom; energies in eV.

| tag | meaning |
|---|---|
| `method pppm\|ewald` | reciprocal-space method (default `pppm`) |
| `order 4\|2` | B-spline assignment order (default 4, i.e. cubic) |
| `diff ik\|ad` | force differentiation (default `ik`) |
| `grid nx ny nz` | FFT grid override (default: automatic, power of two) |
| `accuracy 1e-6` | Ewald splitting target (sets α and the grid) |
| `alpha A^-1` | reciprocal width override |
| `rcut A` | real-space cutoff override |
| `cut_nb A` | Buckingham/LJ cutoff (default 12 Å) |
| `cells 0\|1` | real-space cell list (default 1; falls back to O(N²) when the box has <3 cells per axis) |
| `slab 0\|1` | Yeh–Berkowitz slab correction (normal = z) |

`ik` differentiation is the default: with the aliased influence function it is
both faster and more accurate than the un-corrected analytic path.

## Accuracy and cost (NaCl, 216 ions, a = 5.64 Å, L = 16.92 Å)

Relative to the direct Ewald sum at `accuracy 1e-7`:

| grid | h (Å) | energy error | force RMS error | plugin time |
|---|---|---|---|---|
| 16 | 1.06 | 3e-4 | 1.0e-2 | ~2.3 ms |
| 32 | 0.53 | 3e-7 | 1.0e-3 | ~3.7 ms |
| 64 | 0.26 | <1e-8 | 1.1e-4 | ~17 ms |

The automatic grid for `accuracy 1e-7` is 32. For production force accuracy
below 1e-3, set `grid 64 64 64` (or `accuracy 1e-8`).

## Notes

- `needs_forces = 1`, so ADOBMD uses the plugin forces.
- Orthorhombic cells (the ADOBMD host always supplies one); triclinic falls
  back to the direct Ewald sum.
- Real-space uses a cell list when the box has at least 3 cells per axis
  (box ≳ 3× the cutoff); otherwise it uses the O(N²) loop. A Verlet neighbour
  list would be the next step for medium boxes.
- The solver is OpenMP-parallel (k-loops and FFTW threads). Set
  `OMP_NUM_THREADS`. The Windows DLL uses OpenMP when the cross toolchain can
  link it (imports `libgomp-1.dll`, as the Windows host already does) and
  otherwise falls back to a serial build automatically.
- Grid dimensions are powers of two so the embedded radix-2 FFT applies
  everywhere. Memory is ~4 double arrays of `nx*ny*nz`.
