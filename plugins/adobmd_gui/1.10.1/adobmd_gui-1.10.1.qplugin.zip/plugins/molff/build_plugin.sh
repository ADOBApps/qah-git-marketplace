#!/usr/bin/env bash
# Build the generic ADOBMD plugin (molff) for Linux and, if available, Windows.
set -euo pipefail
cd "$(dirname "$0")"

CC=${CC:-cc}
CFLAGS=${CFLAGS:--O3 -march=native -shared -fPIC -Wall}
$CC $CFLAGS -I. molff.c -o molff.so -lm
echo "built $(pwd)/molff.so"

if command -v x86_64-w64-mingw32-gcc >/dev/null 2>&1; then
  x86_64-w64-mingw32-gcc -O2 -shared -I. molff.c -o molff.dll -lm -static-libgcc
  echo "built $(pwd)/molff.dll"
fi
