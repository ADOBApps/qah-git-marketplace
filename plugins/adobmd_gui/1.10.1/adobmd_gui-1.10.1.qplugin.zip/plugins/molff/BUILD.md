# Bundled molff plugin

`molff.so` / `molff.dll` are prebuilt from `molff.c` (ABI 1, no forces).

```bash
cc -O3 -shared -fPIC -I . molff.c -o molff.so -lm
x86_64-w64-mingw32-gcc -O2 -shared -I . molff.c -o molff.dll -lm -static-libgcc
```
