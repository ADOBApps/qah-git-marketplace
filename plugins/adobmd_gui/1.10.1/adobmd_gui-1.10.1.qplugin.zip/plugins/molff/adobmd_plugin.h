/*=============================================================================
 * include/adobmd_plugin.h
 *
 * ADOBMD C plugin ABI, version 1.
 *
 * A plugin is a shared object (.so / .dylib / .dll) that exports the
 * following symbols.  All symbols are optional except
 * `adobmd_plugin_query` and `adobmd_plugin_energy`.
 *
 *   adobmd_plugin_query   (required)  fill in the metadata struct
 *   adobmd_plugin_init    (optional)  called once before first energy call
 *   adobmd_plugin_energy  (required)  compute total energy
 *   adobmd_plugin_forces  (optional)  compute Cartesian forces
 *   adobmd_plugin_finalize(optional)  called once at shutdown
 *
 * Compile with:
 *     cc -O3 -march=native -shared -fPIC my_plugin.c -o my_plugin.so -lm
 *
 * The ABI is frozen at version 1.  Future additions append fields to
 * the end of structs and are gated on the `abi_version` field.
 *=============================================================================*/

#ifndef ADOBMD_PLUGIN_H
#define ADOBMD_PLUGIN_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#define ADOBMD_PLUGIN_ABI_VERSION 1

/* --------------------------------------------------------------------------
 * Per-site data.  Mirrors the <AtomTypes> block of the .ff file.
 *
 * All values are in SI units:
 *     mass     : kg
 *     sigma    : m
 *     epsilon  : J
 *     charge   : elementary charge (C / 1.60217662e-19)
 *     p[5]     : free-form user extras
 * -------------------------------------------------------------------------- */
typedef struct {
    int         z;          /* atomic number                          */
    int         type_idx;   /* 1-based ADOBMD type index              */
    double      mass;       /* kg                                     */
    double      sigma;      /* m                                      */
    double      epsilon;    /* J                                      */
    double      charge;     /* elementary charge                      */
    double      p[5];       /* user extras from <AtomTypes>           */
    double      reserved[4];/* padding for future ABI additions       */
} adobmd_site_t;

/* --------------------------------------------------------------------------
 * System view handed to the plugin on every call.
 *
 *   pos    : 3*natoms doubles, row-major: pos[3*i + k], k=0..2
 *            units: metres
 *   box    : 3 doubles, metres.  Zero vector means "no periodicity".
 *   sites  : natoms records, one per atom
 *   type   : natoms ints, 1-based type index, mirrors sites[i].type_idx
 * -------------------------------------------------------------------------- */
typedef struct {
    int                   natoms;
    const double         *pos;
    const double         *box;
    const adobmd_site_t  *sites;
    const int            *type;
    void                 *reserved[2];
} adobmd_system_t;

/* --------------------------------------------------------------------------
 * Metadata returned by adobmd_plugin_query.
 *
 *   name              : plugin identifier, NUL-terminated
 *   abi_version       : must equal ADOBMD_PLUGIN_ABI_VERSION
 *   thread_safe       : 1 if the plugin may be called from OpenMP threads
 *                       with disjoint regions of the system; 0 otherwise
 *   needs_forces      : 1 if adobmd_plugin_forces is implemented
 *   interaction_order : 2 = pairwise-only plugin
 *                       3 = three-body plugin
 *                       0 = many-body, uses full system view
 *   reserved          : padding, must be zero-initialised
 * -------------------------------------------------------------------------- */
typedef struct {
    const char *name;
    int         abi_version;
    int         thread_safe;
    int         needs_forces;
    int         interaction_order;
    int         reserved[4];
} adobmd_plugin_info_t;

/* ------------------------------- entry points ---------------------------- */

/* Required.  Return 0 on success, non-zero on failure. */
int adobmd_plugin_query(adobmd_plugin_info_t *info);

/* Optional.  Called once after query.  `params` is the raw string from
 * the .ff <Plugins> line, or NULL if none was given. */
int adobmd_plugin_init(const adobmd_system_t *sys, const char *params);

/* Required.  Return total potential energy in joules. */
double adobmd_plugin_energy(const adobmd_system_t *sys);

/* Optional.  Fill forces[3*i + k] in newtons (N).  `forces` is
 * pre-zeroed by ADOBMD. */
void adobmd_plugin_forces(const adobmd_system_t *sys, double *forces);

/* Optional.  Called once at shutdown, before dlclose. */
void adobmd_plugin_finalize(void);

#ifdef __cplusplus
}
#endif

#endif /* ADOBMD_PLUGIN_H */
