"""VASP (POSCAR/OUTCAR) -> ADOBMD importer tab."""
from __future__ import annotations

from PySide6.QtWidgets import QSpinBox, QLineEdit, QMessageBox

from .base import BaseImporterWidget, install_plugin
from . import vasp2adobmd


class VaspImporterWidget(BaseImporterWidget):
    def __init__(self, parent=None):
        super().__init__(
            "Convert a VASP POSCAR/CONTCAR (and optional OUTCAR energy/forces) "
            "into ADOBMD system.data / system.ff / periodic.params / system.conf.",
            parent,
        )
        self.poscar = self.add_file("poscar", "POSCAR / CONTCAR", "VASP (*);;All files (*)")
        self.outcar = self.add_file("outcar", "OUTCAR (optional)", "VASP OUTCAR (*);;All files (*)")
        self.out = self.add_dir("out", "Output directory")
        self.params = self.add_file("params", "periodic.params (optional)",
                                    "Params (*.params);;All files (*)")

        self.charges = QLineEdit()
        self.charges.setPlaceholderText('e.g. "Ti:2.4,O:-1.2"')
        self.add_widget("charges", "Charges", self.charges)

        self.charges_file = self.add_file("charges_file", "Bader ACF.dat (optional)",
                                          "Dat (*.dat);;All files (*)")

        self.nsteps = QSpinBox()
        self.nsteps.setRange(0, 10_000_000)
        self.nsteps.setValue(0)
        self.add_widget("nsteps", "Steps in .conf", self.nsteps)

        self.add_buttons(("Info", self.info), ("Convert", self.convert))

    def _poscar(self):
        path = self.text("poscar")
        if not path:
            QMessageBox.warning(self, "VASP", "Select a POSCAR/CONTCAR first.")
            return None
        return path

    def _common(self):
        argv = []
        out = self.text("out")
        if out:
            argv += ["--out", out]
        params = self.text("params")
        if params:
            argv += ["--params", params]
        charges = self.text("charges")
        if charges:
            argv += ["--charges", charges]
        cf = self.text("charges_file")
        if cf:
            argv += ["--charges-file", cf]
        return argv

    def info(self):
        poscar = self._poscar()
        if not poscar:
            return
        argv = ["info", poscar]
        outcar = self.text("outcar")
        if outcar:
            argv.append(outcar)
        self.run_cli(vasp2adobmd.main, argv)

    def convert(self):
        poscar = self._poscar()
        if not poscar:
            return
        out = self.text("out")
        if not out:
            QMessageBox.warning(self, "VASP", "Select an output directory.")
            return
        argv = ["convert", poscar]
        outcar = self.text("outcar")
        if outcar:
            argv.append(outcar)
        argv += self._common()
        argv += ["--nsteps", str(self.nsteps.value())]
        rc = self.run_cli(vasp2adobmd.main, argv)
        if rc == 0 and install_plugin(out, "periodic", "periodic_ff"):
            self.log.append("copied periodic_ff plugin into the output directory")
        return rc
