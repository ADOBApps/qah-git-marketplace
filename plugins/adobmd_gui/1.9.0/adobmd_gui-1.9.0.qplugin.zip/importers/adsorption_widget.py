"""Adsorption-energy tab: molecule on a periodic slab with the ADOBMD FF."""
from __future__ import annotations

from PySide6.QtWidgets import QLineEdit, QMessageBox

from .base import BaseImporterWidget
from . import adsorption_energy


class AdsorptionWidget(BaseImporterWidget):
    def __init__(self, parent=None):
        super().__init__(
            "Rigid-slab adsorption energy: E_ads = E(complex) - E(slab) - "
            "E(molecule, gas). Nonbonded terms use the periodic plugin (Ewald, "
            "Buckingham/LJ, 1-2/1-3 exclusions); the molecule's harmonic bonded "
            "terms come from its .ff.",
            parent,
        )
        self.complex = self.add_file("complex", "Complex CONTCAR", "VASP (*);;All files (*)")
        self.ff = self.add_file("ff", "Molecule .ff", "Force field (*.ff);;All files (*)")
        self.data = self.add_file("data", "Molecule .data (gas)", "Data (*.data);;All files (*)")
        self.molff = self.add_file("molff", "Molecule _molff.params", "Params (*.params);;All files (*)")
        self.plugin = QLineEdit("./periodic_ff.so")
        self.add_widget("plugin", "periodic_ff plugin", self.plugin)
        self.add_buttons(("Compute E_ads", self.compute))

    def compute(self):
        for key, label in (("complex", "complex CONTCAR"), ("ff", "molecule .ff"),
                           ("data", "molecule .data"), ("molff", "molecule _molff.params")):
            if not self.text(key):
                QMessageBox.warning(self, "Adsorption", f"Select the {label}.")
                return
        try:
            res = adsorption_energy.compute_e_ads(
                self.text("complex"), self.text("ff"), self.text("data"),
                self.text("molff"), self.text("plugin") or "./periodic_ff.so")
        except Exception as exc:
            self.log.append(f"ERROR: {exc}")
            return
        self.log.append(
            f"E_ads = {res['E_ads_eV']:.4f} eV = {res['E_ads_kcal_mol']:.2f} kcal/mol\n"
            f"  complex {res['E_complex_eV']:.4f}  slab {res['E_slab_eV']:.4f}  "
            f"molecule(gas) {res['E_molecule_gas_eV']:.4f} eV\n"
            f"  bonded: complex {res['E_bonded_complex_eV']:.4f}  "
            f"gas {res['E_bonded_gas_eV']:.4f} eV")
