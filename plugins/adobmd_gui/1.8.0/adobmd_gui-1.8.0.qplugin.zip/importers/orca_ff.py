"""
ORCA -> ADOBMD force-field exporter (core, no Qt).

Pipeline
--------
1. Parse an ORCA calculation: optimized XYZ, ``.hess`` (Hessian and
   frequencies), MBIS/CHELPG charges.
2. Infer the molecular topology by covalent radii (bonds, angles, torsions).
3. Fit diagonal harmonic force constants from the Cartesian Hessian using the
   Wilson B matrix:  F_int = (B B^T)^+ B H B^T (B B^T)^+.
4. Build a complete gas-phase FF (bonds, bends, torsions, LJ, Coulomb) and
   validate it by comparing normal-mode frequencies with ORCA.
5. Export ``params.json``, an ADOBMD ``.ff`` (atom types + bonded terms +
   plugin-routed nonbonded pairs), a ``.data`` topology and an ``adobmd.conf``.

Units
-----
ORCA Hessian: Eh/bohr^2.  Internal fit: Eh/A^2 and Eh/rad^2 -> kcal/mol.
ADOBMD user-facing ``.ff``: Angstrom, kcal/mol, degrees.
The generated ``params.json`` is in the same user units so the generic C
plugin can convert once.

This file is part of QAH and is GPL-3.0-or-later.
"""

from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

# -- constants -----------------------------------------------------------------
BOHR_TO_ANG = 0.529177210903
HARTREE_TO_KCAL = 627.5094740631
HARTREE_TO_J = 4.3597447222071e-18
AMU_TO_KG = 1.66053906660e-27
C_LIGHT = 2.99792458e8
ANG_TO_M = 1.0e-10

# sqrt(Eh / (A^2 amu)) / (2 pi c) in cm^-1
FREQ_FACTOR = (
    math.sqrt(HARTREE_TO_J / (ANG_TO_M ** 2 * AMU_TO_KG))
    / (2.0 * math.pi * C_LIGHT)
    / 100.0
)

COVALENT = {"H": 0.31, "C": 0.76, "N": 0.71, "O": 0.66, "F": 0.57,
            "S": 1.05, "P": 1.07, "Cl": 1.02, "Br": 1.20, "I": 1.39,
            "Si": 1.11, "Al": 1.21, "Mg": 1.41, "Li": 1.28, "Na": 1.66,
            "K": 2.03, "Ca": 1.76, "Ti": 1.60, "Zr": 1.75, "Sn": 1.39}
MASS = {"H": 1.008, "C": 12.011, "N": 14.007, "O": 15.999, "F": 18.998,
        "S": 32.06, "P": 30.974, "Cl": 35.45, "Br": 79.904, "I": 126.904,
        "Si": 28.085, "Al": 26.982, "Mg": 24.305, "Li": 6.94, "Na": 22.990,
        "K": 39.098, "Ca": 40.078, "Ti": 47.867, "Zr": 91.224, "Sn": 118.710}

# OPLS-AA element parameters (sigma in A, epsilon in kcal/mol).
ELEMENT_LJ = {
    "H": (2.50, 0.030),
    "C": (3.50, 0.066),
    "N": (3.25, 0.170),
    "O": (3.12, 0.170),
    "F": (2.95, 0.061),
    "S": (3.55, 0.250),
    "P": (3.74, 0.200),
    "Cl": (3.47, 0.265),
    "Br": (3.73, 0.395),
    "I": (4.00, 0.500),
    "Si": (3.83, 0.300),
}

COULOMB_KCAL_A = 332.063713  # kcal/mol * A / e^2
MIN_BOND_K = 1.0             # kcal/mol/A^2
MIN_BEND_K = 0.01            # kcal/mol/rad^2
MIN_TORS_K = 0.001           # kcal/mol/rad^2


class OrcaFFError(ValueError):
    """Raised when an input cannot be understood."""


# -- data ----------------------------------------------------------------------

@dataclass
class Molecule:
    symbols: List[str]
    coords: np.ndarray  # (N, 3) angstrom

    @property
    def natoms(self) -> int:
        return len(self.symbols)

    def copy(self) -> "Molecule":
        return Molecule(list(self.symbols), self.coords.copy())


@dataclass
class Topology:
    bonds: List[Tuple[int, int]] = field(default_factory=list)
    angles: List[Tuple[int, int, int]] = field(default_factory=list)
    torsions: List[Tuple[int, int, int, int]] = field(default_factory=list)
    neighbors: Dict[int, List[int]] = field(default_factory=dict)
    rings: int = 0

    @property
    def n_bonds(self) -> int:
        return len(self.bonds)

    @property
    def n_angles(self) -> int:
        return len(self.angles)

    @property
    def n_torsions(self) -> int:
        return len(self.torsions)

    def exclusions(self) -> set:
        """1-2 and 1-3 pairs (indices i < j)."""
        pairs = set()
        for i, j in self.bonds:
            pairs.add((min(i, j), max(i, j)))
        for j, i, k in self.angles:
            pairs.add((min(i, k), max(i, k)))
        return pairs

    def pairs_14(self) -> set:
        pairs = set()
        for i, j, k, l in self.torsions:
            pairs.add((min(i, l), max(i, l)))
        return pairs


@dataclass
class FFParameters:
    molecule: Molecule
    topology: Topology
    charges: List[float]
    lj: List[Tuple[float, float]]                  # (sigma A, epsilon kcal/mol)
    bond_r0: List[float]
    bond_k: List[float]                            # kcal/mol/A^2
    bend_theta0: List[float]                       # degrees
    bend_k: List[float]                            # kcal/mol/rad^2
    torsion_phi0: List[float]                      # degrees
    torsion_k: List[float]                         # kcal/mol/rad^2
    intramolecular_nonbonded: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "format": "orca2adobmd-params",
            "version": 1,
            "units": {
                "length": "angstrom",
                "energy": "kcal/mol",
                "angle": "degree (equilibrium); radian (force-constant space)",
                "charge": "elementary charge",
            },
            "symbols": self.molecule.symbols,
            "coords": self.molecule.coords.tolist(),
            "charges": self.charges,
            "lj": [[s, e] for s, e in self.lj],
            "bonds": [
                [i, j, r0, k]
                for (i, j), r0, k in zip(
                    self.topology.bonds, self.bond_r0, self.bond_k
                )
            ],
            "angles": [
                [j, i, k, t0, kk]
                for (j, i, k), t0, kk in zip(
                    self.topology.angles, self.bend_theta0, self.bend_k
                )
            ],
            "torsions": [
                [i, j, k, l, p0, kk]
                for (i, j, k, l), p0, kk in zip(
                    self.topology.torsions, self.torsion_phi0, self.torsion_k
                )
            ],
            "metadata": self.metadata,
        }


# -- ORCA parsers --------------------------------------------------------------

def read_xyz(path: os.PathLike | str) -> Molecule:
    lines = Path(path).read_text(errors="ignore").splitlines()
    if len(lines) < 3:
        raise OrcaFFError(f"{path} is not an XYZ file.")
    try:
        natoms = int(lines[0].split()[0])
    except (ValueError, IndexError) as exc:
        raise OrcaFFError(f"Bad atom count in {path}.") from exc
    symbols: List[str] = []
    coords = np.empty((natoms, 3), dtype=float)
    for index in range(natoms):
        parts = lines[2 + index].split()
        if len(parts) < 4:
            raise OrcaFFError(f"Bad atom line {2 + index + 1} in {path}.")
        symbols.append(parts[0])
        coords[index] = [float(x) for x in parts[1:4]]
    return Molecule(symbols, coords)


def read_orca_geometry(path: os.PathLike | str) -> Molecule:
    """Last CARTESIAN COORDINATES (ANGSTROEM) block of an ORCA output."""
    text = Path(path).read_text(errors="ignore")
    start = text.rfind("CARTESIAN COORDINATES (ANGSTROEM)")
    if start < 0:
        raise OrcaFFError("No CARTESIAN COORDINATES block in the ORCA output.")
    lines = text[start:].splitlines()[2:]
    symbols: List[str] = []
    coords: List[List[float]] = []
    for line in lines:
        parts = line.split()
        if len(parts) < 4:
            break
        try:
            values = [float(x) for x in parts[1:4]]
        except ValueError:
            break
        symbols.append(parts[0])
        coords.append(values)
    if not symbols:
        raise OrcaFFError("Empty coordinate block.")
    return Molecule(symbols, np.asarray(coords, dtype=float))


def read_orca_hessian(path: os.PathLike | str) -> Tuple[np.ndarray, np.ndarray]:
    """Return ``(hessian[Eh/bohr^2], frequencies[cm^-1])`` from an ORCA .hess."""
    lines = Path(path).read_text(errors="ignore").splitlines()
    try:
        start = next(
            i for i, line in enumerate(lines) if line.strip() == "$hessian"
        )
    except StopIteration as exc:
        raise OrcaFFError("No $hessian block in the file.") from exc

    cursor = start + 1
    while cursor < len(lines) and not lines[cursor].strip():
        cursor += 1
    dim = int(lines[cursor].split()[0])
    cursor += 1

    hessian = np.zeros((dim, dim), dtype=float)
    column_start = 0
    while cursor < len(lines):
        line = lines[cursor].strip()
        cursor += 1
        if not line:
            continue
        if line.startswith("$"):
            break
        parts = line.split()
        # A column-block header lists 1..5 integer column indices; the last
        # block may have fewer than five (e.g. "130 131").  Data rows start
        # with the row index followed by floating-point values.
        if 1 <= len(parts) <= 5 and all(re.fullmatch(r"\d+", p) for p in parts):
            column_start = int(parts[0])
            continue
        try:
            row = int(parts[0])
            values = [float(x) for x in parts[1:]]
        except (ValueError, IndexError):
            continue
        for offset, value in enumerate(values):
            column = column_start + offset
            if row < dim and column < dim:
                hessian[row, column] = value
    hessian = 0.5 * (hessian + hessian.T)

    frequencies = np.array([], dtype=float)
    freq_start = None
    for index, line in enumerate(lines):
        if line.strip() == "$vibrational_frequencies":
            freq_start = index
            break
    if freq_start is not None:
        cursor = freq_start + 1
        while cursor < len(lines) and not lines[cursor].strip():
            cursor += 1
        try:
            count = int(lines[cursor].split()[0])
        except (ValueError, IndexError):
            count = 0
        cursor += 1
        values: List[float] = []
        while cursor < len(lines) and len(values) < count:
            line = lines[cursor].strip()
            cursor += 1
            if not line or line.startswith("$"):
                break
            parts = line.split()
            if len(parts) >= 2:
                try:
                    values.append(float(parts[1]))
                except ValueError:
                    break
        frequencies = np.array(values, dtype=float)
    return hessian, frequencies


def read_orca_charges(
    property_path: os.PathLike | str, method: str = "mbis"
) -> List[float]:
    """Parse MBIS or CHELPG charges from an ORCA ``.property.txt``."""
    text = Path(property_path).read_text(errors="ignore")
    section = {
        "mbis": "$SCF_MBIS_Population_Analysis",
        "chelpg": "$SCF_CHELPG_Population_Analysis",
    }.get(method.lower())
    if section is None:
        raise OrcaFFError("method must be 'mbis' or 'chelpg'.")
    start = text.find(section)
    if start < 0:
        raise OrcaFFError(f"{section} not found in {property_path}.")
    block = text[start:]
    match = re.search(
        r'&AtomicCharges\s*\[&Type "ArrayOfDoubles", &Dim \((\d+),', block
    )
    if not match:
        raise OrcaFFError("No &AtomicCharges array in the section.")
    count = int(match.group(1))
    values: Dict[int, float] = {}
    for line in block[match.end():].splitlines()[1:]:
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("&"):
            break
        parts = stripped.split()
        if len(parts) != 2:
            continue
        try:
            values[int(parts[0])] = float(parts[1])
        except ValueError:
            continue
    charges = [values[index] for index in range(count)]
    return charges


def read_pc_chelpg(path: os.PathLike | str) -> Tuple[List[float], np.ndarray]:
    """Read ORCA's ``*.pc_chelpg`` (charge x y z, one atom per line)."""
    lines = Path(path).read_text(errors="ignore").splitlines()
    count = int(lines[0].split()[0])
    charges: List[float] = []
    coords: List[List[float]] = []
    for line in lines[1:]:
        parts = line.split()
        if len(parts) < 4 or parts[0].upper() not in ("Q", "QAT"):
            continue
        charges.append(float(parts[1]))
        coords.append([float(x) for x in parts[2:5]])
        if len(charges) == count:
            break
    return charges, np.asarray(coords, dtype=float)


# -- topology ------------------------------------------------------------------

def infer_topology(
    molecule: Molecule, scale: float = 1.2
) -> Topology:
    """Distance-based bonds (no H-H), then angles and torsions."""
    symbols = molecule.symbols
    coords = molecule.coords
    n = len(symbols)
    bonds: List[Tuple[int, int]] = []
    for i in range(n):
        for j in range(i + 1, n):
            if symbols[i] == "H" and symbols[j] == "H":
                continue
            radius = COVALENT.get(symbols[i], 0.8) + COVALENT.get(symbols[j], 0.8)
            if np.linalg.norm(coords[i] - coords[j]) < scale * radius:
                bonds.append((i, j))
    neighbors: Dict[int, List[int]] = {index: [] for index in range(n)}
    for i, j in bonds:
        neighbors[i].append(j)
        neighbors[j].append(i)
    angles: List[Tuple[int, int, int]] = []
    for center in range(n):
        around = sorted(neighbors[center])
        for a in range(len(around)):
            for b in range(a + 1, len(around)):
                angles.append((around[a], center, around[b]))
    torsions: List[Tuple[int, int, int, int]] = []
    for i, j in bonds:
        for a in neighbors[i]:
            if a == j:
                continue
            for b in neighbors[j]:
                if b == i:
                    continue
                torsions.append((a, i, j, b))
    # ring count for a connected graph: E - V + 1
    rings = len(bonds) - n + 1
    return Topology(bonds, angles, torsions, neighbors, rings)


# -- internal coordinates ------------------------------------------------------

def bond_length(coords: np.ndarray, i: int, j: int) -> float:
    return float(np.linalg.norm(coords[i] - coords[j]))


def bond_angle(coords: np.ndarray, i: int, j: int, k: int) -> float:
    a = coords[i] - coords[j]
    b = coords[k] - coords[j]
    na = np.linalg.norm(a)
    nb = np.linalg.norm(b)
    if na < 1e-12 or nb < 1e-12:
        return 0.0
    cosine = float(np.dot(a, b) / (na * nb))
    return math.acos(max(-1.0, min(1.0, cosine)))


def dihedral_angle(
    coords: np.ndarray, i: int, j: int, k: int, l: int
) -> float:
    b1 = coords[j] - coords[i]
    b2 = coords[k] - coords[j]
    b3 = coords[l] - coords[k]
    n1 = np.cross(b1, b2)
    n2 = np.cross(b2, b3)
    if np.linalg.norm(n1) < 1e-12 or np.linalg.norm(n2) < 1e-12:
        return 0.0
    m = np.cross(n1, b2 / np.linalg.norm(b2))
    x = float(np.dot(n1, n2))
    y = float(np.dot(m, n2))
    return math.atan2(y, x)


def internal_coordinates(
    coords: np.ndarray,
    topology: Topology,
    reference: Optional[np.ndarray] = None,
) -> np.ndarray:
    values: List[float] = []
    for i, j in topology.bonds:
        values.append(bond_length(coords, i, j))
    for i, j, k in topology.angles:
        values.append(bond_angle(coords, i, j, k))
    for index, (i, j, k, l) in enumerate(topology.torsions):
        phi = dihedral_angle(coords, i, j, k, l)
        if reference is not None:
            target = float(reference[len(topology.bonds) + len(topology.angles) + index])
            phi = target + _wrap(phi - target)
        values.append(phi)
    return np.asarray(values, dtype=float)


def _wrap(angle: float) -> float:
    while angle > math.pi:
        angle -= 2.0 * math.pi
    while angle < -math.pi:
        angle += 2.0 * math.pi
    return angle


def b_matrix(
    coords: np.ndarray, topology: Topology, step: float = 1.0e-4
) -> np.ndarray:
    """Wilson B matrix (M x 3N) by central differences in angstrom."""
    base = internal_coordinates(coords, topology)
    n = coords.shape[0]
    matrix = np.zeros((base.size, 3 * n), dtype=float)
    for atom in range(n):
        for axis in range(3):
            shifted = coords.copy()
            shifted[atom, axis] += step
            plus = internal_coordinates(shifted, topology, reference=base)
            shifted[atom, axis] -= 2.0 * step
            minus = internal_coordinates(shifted, topology, reference=base)
            matrix[:, 3 * atom + axis] = (plus - minus) / (2.0 * step)
    return matrix


# -- fitting -------------------------------------------------------------------

def _upper_indices(dim: int) -> Tuple[np.ndarray, np.ndarray]:
    return np.triu_indices(dim)


def nonbonded_hessian_kcal(
    coords: np.ndarray,
    topology: Topology,
    charges: Sequence[float],
    lj: Sequence[Tuple[float, float]],
) -> np.ndarray:
    """Analytic LJ + Coulomb Hessian in kcal/mol/A^2."""
    n = coords.shape[0]
    hessian = np.zeros((3 * n, 3 * n), dtype=float)
    for i, j, scale in _nonbonded_pairs(topology):
        delta = coords[i] - coords[j]
        distance = float(np.linalg.norm(delta))
        if distance < 1e-8:
            continue
        unit = delta / distance
        sigma = 0.5 * (lj[i][0] + lj[j][0])
        epsilon = math.sqrt(lj[i][1] * lj[j][1])
        sr = sigma / distance
        sr6 = sr ** 6
        sr12 = sr6 * sr6
        d1 = 4.0 * epsilon * (-12.0 * sr12 / distance + 6.0 * sr6 / distance)
        d2 = 4.0 * epsilon * (156.0 * sr12 - 42.0 * sr6) / distance ** 2
        coulomb = scale * COULOMB_KCAL_A * charges[i] * charges[j]
        d1 -= coulomb / distance ** 2
        d2 += 2.0 * coulomb / distance ** 3
        block = (d2 - d1 / distance) * np.outer(unit, unit) + (d1 / distance) * np.eye(3)
        a = slice(3 * i, 3 * i + 3)
        b = slice(3 * j, 3 * j + 3)
        hessian[a, a] += block
        hessian[b, b] += block
        hessian[a, b] -= block
        hessian[b, a] -= block
    return hessian


def fit_force_constants(
    hessian_bohr: np.ndarray,
    coords: np.ndarray,
    topology: Topology,
    charges: Sequence[float],
    lj: Sequence[Tuple[float, float]],
    regularization: float = 1.0e-4,
    include_nonbonded: bool = False,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, float]:
    """Least-squares force constants for H = B^T diag(k) B + H_nonbonded.

    The Hessian is linear in the force constants when the equilibrium values are
    fixed, so this is a bounded linear least-squares problem. It is far more
    stable than inverting a redundant GF matrix.
    """
    hessian_kcal = hessian_bohr / (BOHR_TO_ANG ** 2) * HARTREE_TO_KCAL
    nonbonded = (
        nonbonded_hessian_kcal(coords, topology, charges, lj)
        if include_nonbonded
        else np.zeros_like(hessian_kcal)
    )
    target = hessian_kcal - nonbonded

    matrix = b_matrix(coords, topology)
    dimension = 3 * coords.shape[0]
    iu = _upper_indices(dimension)
    rows = iu[0].size
    design = np.empty((rows, matrix.shape[0]), dtype=float)
    for index in range(matrix.shape[0]):
        outer = np.outer(matrix[index], matrix[index])
        design[:, index] = outer[iu]
    observation = target[iu]

    # Small ridge term: keeps soft/redundant coordinates finite.
    ridge = math.sqrt(regularization) * np.eye(design.shape[1])
    design_aug = np.vstack([design, ridge])
    observation_aug = np.concatenate([observation, np.zeros(design.shape[1])])

    try:
        from scipy.optimize import nnls

        solution, _ = nnls(design_aug, observation_aug)
    except Exception:
        solution, *_ = np.linalg.lstsq(design_aug, observation_aug, rcond=None)
        solution = np.clip(solution, 0.0, None)

    n_bonds = topology.n_bonds
    n_angles = topology.n_angles
    bond_k = np.clip(solution[:n_bonds], MIN_BOND_K, None)
    bend_k = np.clip(
        solution[n_bonds : n_bonds + n_angles], MIN_BEND_K, None
    )
    torsion_k = np.clip(solution[n_bonds + n_angles :], MIN_TORS_K, None)

    fitted = design @ solution
    denominator = float(np.linalg.norm(observation) * np.linalg.norm(fitted))
    correlation = (
        float(np.dot(observation, fitted) / denominator) if denominator > 0 else 0.0
    )
    residual = float(
        np.sqrt(np.mean((fitted - observation) ** 2))
    )
    return bond_k, bend_k, torsion_k, correlation, residual


def build_parameters(
    molecule: Molecule,
    topology: Topology,
    hessian_bohr: np.ndarray,
    charges: Sequence[float],
    lj: Optional[Sequence[Tuple[float, float]]] = None,
    metadata: Optional[Dict[str, Any]] = None,
    intramolecular_nonbonded: bool = False,
) -> FFParameters:
    coords = molecule.coords
    bond_r0 = np.array(
        [bond_length(coords, i, j) for i, j in topology.bonds], dtype=float
    )
    bend_theta0 = np.array(
        [math.degrees(bond_angle(coords, i, j, k)) for i, j, k in topology.angles],
        dtype=float,
    )
    torsion_phi0 = np.array(
        [math.degrees(dihedral_angle(coords, i, j, k, l))
         for i, j, k, l in topology.torsions],
        dtype=float,
    )
    if lj is None:
        lj = [ELEMENT_LJ.get(symbol, (3.0, 0.1)) for symbol in molecule.symbols]
    lj = [(float(s), float(e)) for s, e in lj]
    bond_k, bend_k, torsion_k, correlation, residual = fit_force_constants(
        hessian_bohr,
        coords,
        topology,
        charges,
        lj,
        include_nonbonded=intramolecular_nonbonded,
    )
    meta = dict(metadata or {})
    meta["hessian_correlation"] = correlation
    meta["hessian_residual_kcal_a2"] = residual
    meta["intramolecular_nonbonded"] = bool(intramolecular_nonbonded)
    return FFParameters(
        molecule=molecule,
        topology=topology,
        charges=[float(q) for q in charges],
        lj=lj,
        bond_r0=bond_r0.tolist(),
        bond_k=bond_k.tolist(),
        bend_theta0=bend_theta0.tolist(),
        bend_k=bend_k.tolist(),
        torsion_phi0=torsion_phi0.tolist(),
        torsion_k=torsion_k.tolist(),
        intramolecular_nonbonded=bool(intramolecular_nonbonded),
        metadata=meta,
    )


# -- force field energy and validation -----------------------------------------

def _nonbonded_pairs(
    topology: Topology,
) -> List[Tuple[int, int, float]]:
    """Pairs to evaluate: 1-2/1-3 excluded, 1-4 scaled by 0.5."""
    n = len(topology.neighbors)
    excluded = topology.exclusions()
    pairs_14 = topology.pairs_14()
    pairs: List[Tuple[int, int, float]] = []
    for i in range(n):
        for j in range(i + 1, n):
            if (i, j) in excluded:
                continue
            scale = 0.5 if (i, j) in pairs_14 else 1.0
            pairs.append((i, j, scale))
    return pairs


def ff_energy(
    coords: np.ndarray, params: FFParameters, nonbonded: bool = True
) -> float:
    """Gas-phase FF energy in kcal/mol (harmonic + LJ + Coulomb)."""
    topo = params.topology
    energy = 0.0
    for (i, j), r0, k in zip(topo.bonds, params.bond_r0, params.bond_k):
        dr = bond_length(coords, i, j) - r0
        energy += 0.5 * k * dr * dr
    for (i, j, k), theta0, kk in zip(
        topo.angles, params.bend_theta0, params.bend_k
    ):
        dtheta = bond_angle(coords, i, j, k) - math.radians(theta0)
        energy += 0.5 * kk * dtheta * dtheta
    for (i, j, k, l), phi0, kk in zip(
        topo.torsions, params.torsion_phi0, params.torsion_k
    ):
        dphi = _wrap(
            dihedral_angle(coords, i, j, k, l) - math.radians(phi0)
        )
        energy += 0.5 * kk * dphi * dphi
    if not nonbonded or not params.intramolecular_nonbonded:
        return float(energy)

    for i, j, scale in _nonbonded_pairs(topo):
        distance = float(np.linalg.norm(coords[i] - coords[j]))
        if distance < 1e-6:
            continue
        sigma = 0.5 * (params.lj[i][0] + params.lj[j][0])
        epsilon = math.sqrt(params.lj[i][1] * params.lj[j][1])
        ratio = sigma / distance
        energy += scale * 4.0 * epsilon * (ratio ** 12 - ratio ** 6)
        energy += (
            scale * COULOMB_KCAL_A * params.charges[i] * params.charges[j] / distance
        )
    return float(energy)


def _gradient(
    coords: np.ndarray, params: FFParameters, step: float = 1.0e-3
) -> np.ndarray:
    n = coords.shape[0]
    gradient = np.zeros((n, 3), dtype=float)
    for atom in range(n):
        for axis in range(3):
            shifted = coords.copy()
            shifted[atom, axis] += step
            plus = ff_energy(shifted, params)
            shifted[atom, axis] -= 2.0 * step
            minus = ff_energy(shifted, params)
            gradient[atom, axis] = (plus - minus) / (2.0 * step)
    return gradient


def ff_hessian_numeric(
    params: FFParameters, step: float = 1.0e-3
) -> np.ndarray:
    """Cartesian Hessian in Eh/A^2 by central differences of the gradient."""
    coords = params.molecule.coords
    n = coords.shape[0]
    hessian = np.zeros((3 * n, 3 * n), dtype=float)
    for atom in range(n):
        for axis in range(3):
            column = 3 * atom + axis
            shifted = coords.copy()
            shifted[atom, axis] += step
            plus = _gradient(shifted, params)
            shifted[atom, axis] -= 2.0 * step
            minus = _gradient(shifted, params)
            hessian[:, column] = (
                (plus - minus) / (2.0 * step)
            ).ravel() / HARTREE_TO_KCAL
    return 0.5 * (hessian + hessian.T)


def _nonbonded_hessian(params: FFParameters) -> np.ndarray:
    """Analytic LJ + Coulomb Hessian (Eh/A^2)."""
    return (
        nonbonded_hessian_kcal(
            params.molecule.coords, params.topology, params.charges, params.lj
        )
        / HARTREE_TO_KCAL
    )


def ff_hessian_analytic(params: FFParameters) -> np.ndarray:
    """FF Hessian (Eh/A^2) from the B matrix and the analytic nonbonded part."""
    matrix = b_matrix(params.molecule.coords, params.topology)
    constants = np.concatenate(
        [params.bond_k, params.bend_k, params.torsion_k]
    )
    hessian = (matrix.T * constants) @ matrix / HARTREE_TO_KCAL
    if params.intramolecular_nonbonded:
        hessian += _nonbonded_hessian(params)
    return 0.5 * (hessian + hessian.T)


def ff_frequencies(params: FFParameters, method: str = "analytic") -> np.ndarray:
    """Harmonic frequencies in cm^-1 (six zeros for translations/rotations)."""
    hessian = (
        ff_hessian_analytic(params)
        if method == "analytic"
        else ff_hessian_numeric(params)
    )
    masses = np.array([MASS.get(s, 12.0) for s in params.molecule.symbols])
    mass_weights = np.repeat(masses, 3)
    weighted = hessian / np.sqrt(np.outer(mass_weights, mass_weights))
    eigenvalues = np.linalg.eigvalsh(weighted)
    frequencies = np.sign(eigenvalues) * FREQ_FACTOR * np.sqrt(np.abs(eigenvalues))
    return frequencies


def validate_frequencies(
    params: FFParameters, orca_frequencies: np.ndarray, ignore: int = 6
) -> Dict[str, Any]:
    """Compare the FF normal modes with ORCA (sorted, lowest 6 ignored)."""
    ff = np.sort(ff_frequencies(params))[ignore:]
    reference = np.sort(np.asarray(orca_frequencies, dtype=float))[ignore:]
    count = min(ff.size, reference.size)
    ff = ff[:count]
    reference = reference[:count]
    difference = ff - reference
    return {
        "n_modes": int(count),
        "rmse_cm1": float(np.sqrt(np.mean(difference ** 2))),
        "max_abs_cm1": float(np.max(np.abs(difference))),
        "mean_signed_cm1": float(np.mean(difference)),
        "worst": [
            {
                "orca_cm1": float(reference[index]),
                "ff_cm1": float(ff[index]),
                "delta_cm1": float(difference[index]),
            }
            for index in np.argsort(np.abs(difference))[-5:][::-1]
        ],
        "ff_frequencies_cm1": ff.tolist(),
        "orca_frequencies_cm1": reference.tolist(),
    }


# -- writers -------------------------------------------------------------------

def write_params_json(params: FFParameters, path: os.PathLike | str) -> str:
    Path(path).write_text(json.dumps(params.to_dict(), indent=2) + "\n")
    return str(path)


def _type_name(index: int, symbol: str) -> str:
    return f"A{index:03d}{symbol}"


def write_plugin_params(
    params: FFParameters,
    path: os.PathLike | str,
    ewald_accuracy: float = 1.0e-6,
    slab_correction: bool = False,
) -> str:
    """Compact text parameters for the generic ADOBMD C plugin (molff)."""
    molecule = params.molecule
    topo = params.topology
    lines = [
        "# molff parameters — generated by orca2adobmd",
        "# indices are 0-based; lengths in Angstrom, energies in kcal/mol",
        f"natoms {molecule.natoms}",
        f"intramolecular_nonbonded {1 if params.intramolecular_nonbonded else 0}",
        f"ewald_accuracy {ewald_accuracy:.6e}",
        f"slab_correction {1 if slab_correction else 0}",
    ]
    for (i, j), r0, k in zip(topo.bonds, params.bond_r0, params.bond_k):
        lines.append(f"bond {i} {j} {r0:.12f} {k:.12f}")
    for (i, j, k), theta0, kk in zip(
        topo.angles, params.bend_theta0, params.bend_k
    ):
        lines.append(f"angle {i} {j} {k} {theta0:.12f} {kk:.12f}")
    for (i, j, k, l), phi0, kk in zip(
        topo.torsions, params.torsion_phi0, params.torsion_k
    ):
        lines.append(f"torsion {i} {j} {k} {l} {phi0:.12f} {kk:.12f}")
    for i, j in sorted(topo.exclusions()):
        lines.append(f"exclude {i} {j}")
    for i, j in sorted(topo.pairs_14()):
        lines.append(f"scale14 {i} {j}")
    Path(path).write_text("\n".join(lines) + "\n")
    return str(path)


def write_adobmd_ff(
    params: FFParameters,
    path: os.PathLike | str,
    plugin_name: str = "molff",
    plugin_path: str = "./molff.so",
    plugin_params: str = "./molff.params",
) -> str:
    """ADOBMD .ff: atom types, bonded terms, plugin-routed nonbonded pairs."""
    molecule = params.molecule
    topo = params.topology
    names = [_type_name(i, s) for i, s in enumerate(molecule.symbols)]
    lines: List[str] = []
    lines.append("# Generated by orca2adobmd")
    lines.append(f"# molecule: {molecule.natoms} atoms, {topo.n_bonds} bonds, "
                 f"{topo.n_angles} angles, {topo.n_torsions} torsions")
    lines.append("# Units: Angstrom, kcal/mol, degrees (ADOBMD converts to SI)")
    lines.append("")
    lines.append("<AtomTypes>")
    lines.append("#  NAME  ELEMENT  MASS  SIGMA  EPSILON  CHARGE")
    for index, symbol in enumerate(molecule.symbols):
        sigma, epsilon = params.lj[index]
        lines.append(
            f"  {names[index]:10s} {symbol:2s} {MASS.get(symbol, 12.0):9.3f} "
            f"{sigma:8.4f} {epsilon:8.5f} {params.charges[index]:12.6f}"
        )
    lines.append("</AtomTypes>")
    lines.append("")

    lines.append("<BondTypes>")
    for (i, j), r0, k in zip(topo.bonds, params.bond_r0, params.bond_k):
        lines.append(
            f"  {names[i]:10s} {names[j]:10s} Harmonic {r0:9.5f} {k:12.5f}"
        )
    lines.append("</BondTypes>")
    lines.append("")

    lines.append("<BendTypes>")
    for (i, j, k), theta0, kk in zip(
        topo.angles, params.bend_theta0, params.bend_k
    ):
        lines.append(
            f"  {names[i]:10s} {names[j]:10s} {names[k]:10s} Harmonic "
            f"{theta0:9.4f} {kk:12.5f}"
        )
    lines.append("</BendTypes>")
    lines.append("")

    lines.append("<TorsionTypes>")
    for (i, j, k, l), phi0, kk in zip(
        topo.torsions, params.torsion_phi0, params.torsion_k
    ):
        lines.append(
            f"  {names[i]:10s} {names[j]:10s} {names[k]:10s} {names[l]:10s} "
            f"Harmonic {phi0:9.3f} {kk:12.5f}"
        )
    lines.append("</TorsionTypes>")
    lines.append("")

    lines.append("<Plugins>")
    lines.append(f'  {plugin_name}  {plugin_path}  params="{plugin_params}"')
    lines.append("</Plugins>")
    lines.append("")

    lines.append("<NonBonded>")
    for i in range(molecule.natoms):
        for j in range(i, molecule.natoms):
            lines.append(f"  {names[i]:10s} {names[j]:10s} Plugin {plugin_name}")
    lines.append("</NonBonded>")
    lines.append("")
    Path(path).write_text("\n".join(lines))
    return str(path)


def write_adobmd_data(
    params: FFParameters, path: os.PathLike | str, box: Optional[float] = None
) -> str:
    molecule = params.molecule
    topo = params.topology
    n = molecule.natoms
    if box is None:
        span = molecule.coords.max(axis=0) - molecule.coords.min(axis=0)
        box = float(max(span) + 10.0)
    lines: List[str] = []
    lines.append("# ADOBMD unified data file — generated by orca2adobmd")
    lines.append(f"{n} atoms")
    lines.append(f"{topo.n_bonds} bonds")
    lines.append(f"{topo.n_angles} angles")
    lines.append(f"{topo.n_torsions} dihedrals")
    lines.append("0 impropers")
    lines.append("")
    lines.append(f"{n} atom types")
    lines.append(f"{topo.n_bonds} bond types")
    lines.append(f"{topo.n_angles} angle types")
    lines.append(f"{topo.n_torsions} dihedral types")
    lines.append("")
    lines.append(f"0.0 {box:.6f} xlo xhi")
    lines.append(f"0.0 {box:.6f} ylo yhi")
    lines.append(f"0.0 {box:.6f} zlo zhi")
    lines.append("")
    lines.append("Masses")
    lines.append("")
    for index, symbol in enumerate(molecule.symbols):
        lines.append(f"{index + 1} {MASS.get(symbol, 12.0):.6f}  # {symbol}")
    lines.append("")
    lines.append("Atoms")
    lines.append("")
    lines.append("# id mol type q x y z")
    for index, symbol in enumerate(molecule.symbols):
        x, y, z = molecule.coords[index]
        lines.append(
            f"{index + 1} 1 {index + 1} {params.charges[index]:.6f} "
            f"{x:.6f} {y:.6f} {z:.6f}"
        )
    lines.append("")
    lines.append("Bonds")
    lines.append("")
    lines.append("# id type atom1 atom2")
    for index, (i, j) in enumerate(topo.bonds):
        lines.append(f"{index + 1} {index + 1} {i + 1} {j + 1}")
    lines.append("")
    lines.append("Angles")
    lines.append("")
    lines.append("# id type atom1 atom2 atom3")
    for index, (i, j, k) in enumerate(topo.angles):
        lines.append(f"{index + 1} {index + 1} {i + 1} {j + 1} {k + 1}")
    lines.append("")
    lines.append("Dihedrals")
    lines.append("")
    lines.append("# id type atom1 atom2 atom3 atom4")
    for index, (i, j, k, l) in enumerate(topo.torsions):
        lines.append(f"{index + 1} {index + 1} {i + 1} {j + 1} {k + 1} {l + 1}")
    lines.append("")
    Path(path).write_text("\n".join(lines))
    return str(path)


def write_adobmd_conf(
    params: FFParameters,
    path: os.PathLike | str,
    data_file: str,
    ff_file: str,
    nsteps: int = 10000,
    temperature: float = 300.0,
    dt_fs: float = 1.0,
    ensemble: str = "NVT",
    output_prefix: str = "./run",
    material: str = "MOL",
) -> str:
    lines = [
        "# ADOBMD input generated by orca2adobmd",
        f"system_file     = {data_file}",
        f"forcefield_file = {ff_file}",
        "potential       = CUSTOM",
        f"material        = {material}",
        f"ensemble        = {ensemble}",
        f"temperature     = {temperature}",
        f"dt_fs           = {dt_fs}",
        f"nsteps          = {nsteps}",
        "nsave           = 100",
        f"output_prefix   = {output_prefix}",
        f"natoms          = {params.molecule.natoms}",
        "",
    ]
    Path(path).write_text("\n".join(lines))
    return str(path)
