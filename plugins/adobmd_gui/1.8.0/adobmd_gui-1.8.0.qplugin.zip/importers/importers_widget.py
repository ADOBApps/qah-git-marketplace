"""Importers tab: OpenKIM, VASP and Quantum ESPRESSO front ends."""
from __future__ import annotations

from PySide6.QtWidgets import QTabWidget

from .kim_widget import KimImporterWidget
from .vasp_widget import VaspImporterWidget
from .qe_widget import QeImporterWidget
from .orca_widget import OrcaImporterWidget


class ImportersWidget(QTabWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.addTab(KimImporterWidget(self), "KIM (OpenKIM)")
        self.addTab(VaspImporterWidget(self), "VASP")
        self.addTab(QeImporterWidget(self), "Quantum ESPRESSO")
        self.addTab(OrcaImporterWidget(self), "ORCA")
