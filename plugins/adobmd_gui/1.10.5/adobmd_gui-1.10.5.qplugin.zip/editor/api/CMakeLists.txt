cmake_minimum_required(VERSION 3.16)
project(highlighter LANGUAGES C)

set(CMAKE_C_STANDARD 11)
set(CMAKE_C_STANDARD_REQUIRED ON)

# --- Detect cross-compilation ---
if(CMAKE_CROSSCOMPILING)
    message(STATUS "Cross-compiling to ${CMAKE_SYSTEM_NAME}")
endif()

# =====================================================================
# Shared Library Target
# =====================================================================
add_library(highlighter SHARED src/highlighter.c)

# Tell the header we are building the DLL (so HL_API = dllexport)
target_compile_definitions(highlighter PRIVATE HIGHLIGHTER_BUILDING)

# =====================================================================
# OpenMP handling
#
# Under MinGW cross-compilation, FindOpenMP is unreliable and libgomp
# is linked as a DLL by default. We bypass the imported target and
# force a static link of libgomp and libwinpthread directly.
# =====================================================================
if(CMAKE_CROSSCOMPILING AND CMAKE_SYSTEM_NAME STREQUAL "Windows")
    message(STATUS "Windows cross-compile: forcing static libgomp and libwinpthread")

    target_compile_options(highlighter PRIVATE -fopenmp)
    target_link_options(highlighter PRIVATE
        -fopenmp
        -static
        -static-libgcc
        -Wl,--exclude-libs,ALL
    )
    target_link_libraries(highlighter PRIVATE
        -Wl,-Bstatic
        -lgomp
        -lwinpthread
        -Wl,-Bdynamic
        m
    )
else()
    find_package(OpenMP REQUIRED COMPONENTS C)
    if(NOT OpenMP_C_FOUND)
        message(FATAL_ERROR "OpenMP for C not found")
    endif()
    target_link_libraries(highlighter PRIVATE OpenMP::OpenMP_C m)
endif()

# =====================================================================
# OpenMP (platform-specific)
# =====================================================================
if(APPLE)
    # Apple clang has no libomp; use Homebrew's LLVM + libomp.
    find_program(HOMEBREW_CC
        NAMES clang
        PATHS /opt/homebrew/opt/llvm/bin /usr/local/opt/llvm/bin
        NO_DEFAULT_PATH
    )
    if(HOMEBREW_CC)
        set(CMAKE_C_COMPILER "${HOMEBREW_CC}")
    endif()
    execute_process(
        COMMAND brew --prefix libomp
        OUTPUT_VARIABLE LIBOMP_PREFIX
        OUTPUT_STRIP_TRAILING_WHITESPACE
        ERROR_QUIET
    )
    if(NOT LIBOMP_PREFIX)
        message(FATAL_ERROR "Install libomp first: brew install libomp")
    endif()
    set(OpenMP_C_FLAGS "-Xpreprocessor -fopenmp -I${LIBOMP_PREFIX}/include")
    set(OpenMP_C_LIB_NAMES "omp")
    set(OpenMP_omp_LIBRARY "${LIBOMP_PREFIX}/lib/libomp.dylib")
    find_package(OpenMP REQUIRED COMPONENTS C)
else()
    find_package(OpenMP REQUIRED COMPONENTS C)
endif()

# =====================================================================
# Native Windows build (MSVC or native MinGW)
# =====================================================================
if(WIN32 AND NOT CMAKE_CROSSCOMPILING)
    target_link_options(highlighter PRIVATE
        -static
        -static-libgcc
        -Wl,--exclude-libs,ALL
    )
endif()

# =====================================================================
# Compiler Flags (C Spec)
# =====================================================================
if(CMAKE_C_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(highlighter PRIVATE
        -Wall
        -Wextra
        $<$<CONFIG:Debug>:-g -O0>
        $<$<CONFIG:Release>:-O3>
    )
endif()

# =====================================================================
# Target Properties & Directories
# =====================================================================
set_target_properties(highlighter PROPERTIES
    POSITION_INDEPENDENT_CODE ON
    LIBRARY_OUTPUT_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/bin"
    RUNTIME_OUTPUT_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/bin"
    ARCHIVE_OUTPUT_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/bin"
    OUTPUT_NAME "qah_highlighter"
)

target_include_directories(highlighter PUBLIC
    $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/include>
    $<INSTALL_INTERFACE:include>
)

# =====================================================================
# Installation Rules
# =====================================================================
install(TARGETS highlighter
    LIBRARY DESTINATION lib
    RUNTIME DESTINATION bin
    ARCHIVE DESTINATION lib
)
install(FILES include/highlighter.h DESTINATION include)