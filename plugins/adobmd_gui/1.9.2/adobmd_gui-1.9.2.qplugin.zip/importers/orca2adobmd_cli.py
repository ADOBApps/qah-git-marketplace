#!/usr/bin/env python3
"""
Terminal interface for the ORCA -> ADOBMD force-field exporter.

Examples
--------
    # inspect a finished ORCA frequency + charge run
    python orca2adobmd_cli.py info --xyz e2_min.xyz \
        --hess 02_freq.hess --property 01_charges.property.txt

    # fit and report the frequency agreement
    python orca2adobmd_cli.py fit ... --json

    # export params.json + .ff + .data + adobmd.conf
    python orca2adobmd_cli.py export ... --out ./adobmd

This file is part of QAH and is GPL-3.0-or-later.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, Optional, Sequence

import numpy as np

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

try:
    from . import orca_ff
except ImportError:  # script use
    import orca_ff  # type: ignore


def _jsonable(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, np.ndarray):
        return _jsonable(value.tolist())
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    return value


def _load(args: argparse.Namespace):
    molecule = orca_ff.read_xyz(args.xyz) if args.xyz else orca_ff.read_orca_geometry(args.out)
    hessian, frequencies = orca_ff.read_orca_hessian(args.hess)
    if molecule.natoms * 3 != hessian.shape[0]:
        raise SystemExit(
            f"geometry has {molecule.natoms} atoms but the Hessian is "
            f"{hessian.shape[0]}x{hessian.shape[0]}"
        )
    charges = orca_ff.read_orca_charges(args.property, args.charges)
    if len(charges) != molecule.natoms:
        raise SystemExit(
            f"{args.charges} charges: {len(charges)} values for {molecule.natoms} atoms"
        )
    topology = orca_ff.infer_topology(molecule)
    params = orca_ff.build_parameters(
        molecule,
        topology,
        hessian,
        charges,
        metadata={"source": str(args.hess), "charge_method": args.charges},
        intramolecular_nonbonded=args.intramolecular_nonbonded,
    )
    return molecule, hessian, frequencies, charges, topology, params


def cmd_info(args: argparse.Namespace) -> int:
    molecule, hessian, frequencies, charges, topology, params = _load(args)
    result = {
        "atoms": molecule.natoms,
        "symbols": molecule.symbols,
        "bonds": topology.n_bonds,
        "angles": topology.n_angles,
        "torsions": topology.n_torsions,
        "rings": topology.rings,
        "hessian_shape": list(hessian.shape),
        "n_frequencies": int(frequencies.size),
        "frequency_min_cm1": float(np.min(frequencies[frequencies > 1.0]))
        if np.any(frequencies > 1.0) else None,
        "frequency_max_cm1": float(np.max(frequencies)) if frequencies.size else None,
        "charge_method": args.charges,
        "charge_sum": float(sum(charges)),
        "charge_min": float(min(charges)),
        "charge_max": float(max(charges)),
        "intramolecular_nonbonded": params.intramolecular_nonbonded,
    }
    if args.json:
        print(json.dumps(_jsonable(result), indent=2))
    else:
        for key, value in result.items():
            print(f"{key:26s}: {value}")
    return 0


def cmd_topology(args: argparse.Namespace) -> int:
    molecule = orca_ff.read_xyz(args.xyz) if args.xyz else orca_ff.read_orca_geometry(args.out)
    topology = orca_ff.infer_topology(molecule)
    result = {
        "atoms": molecule.natoms,
        "bonds": topology.n_bonds,
        "angles": topology.n_angles,
        "torsions": topology.n_torsions,
        "rings": topology.rings,
        "bonds_list": [[i + 1, j + 1] for i, j in topology.bonds],
    }
    if args.json:
        print(json.dumps(_jsonable(result), indent=2))
    else:
        for key in ("atoms", "bonds", "angles", "torsions", "rings"):
            print(f"{key:10s}: {result[key]}")
        print("bonds (1-based):", result["bonds_list"])
    return 0


def cmd_fit(args: argparse.Namespace) -> int:
    molecule, hessian, frequencies, charges, topology, params = _load(args)
    validation = orca_ff.validate_frequencies(params, frequencies)
    result = {
        "hessian_correlation": params.metadata.get("hessian_correlation"),
        "hessian_residual_kcal_a2": params.metadata.get("hessian_residual_kcal_a2"),
        "intramolecular_nonbonded": params.intramolecular_nonbonded,
        "bond_k_min_max": [min(params.bond_k), max(params.bond_k)],
        "bend_k_min_max": [min(params.bend_k), max(params.bend_k)],
        "torsion_k_min_max": ([min(params.torsion_k), max(params.torsion_k)]
                              if params.torsion_k else [0.0, 0.0]),
        "frequency_validation": validation,
    }
    if args.json:
        print(json.dumps(_jsonable(result), indent=2))
    else:
        print(f"hessian correlation     : {result['hessian_correlation']:.4f}")
        print(f"hessian residual        : {result['hessian_residual_kcal_a2']:.2f} kcal/mol/A^2")
        print(f"intramolecular nonbonded: {result['intramolecular_nonbonded']}")
        print(f"bond k (kcal/mol/A^2)   : {min(params.bond_k):.1f} .. {max(params.bond_k):.1f}")
        print(f"bend k (kcal/mol/rad^2) : {min(params.bend_k):.1f} .. {max(params.bend_k):.1f}")
        print(f"torsion k               : {min(params.torsion_k):.2f} .. {max(params.torsion_k):.1f}")
        print(
            f"frequencies             : RMSE {validation['rmse_cm1']:.1f} cm^-1, "
            f"max {validation['max_abs_cm1']:.1f}, mean {validation['mean_signed_cm1']:+.1f}"
        )
        print("worst modes:")
        for worst in validation["worst"]:
            print(
                f"  ORCA {worst['orca_cm1']:8.1f}  FF {worst['ff_cm1']:8.1f}  "
                f"delta {worst['delta_cm1']:+8.1f}"
            )
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    molecule, hessian, frequencies, charges, topology, params = _load(args)
    validation = orca_ff.validate_frequencies(params, frequencies)
    if args.json:
        print(json.dumps(_jsonable(validation), indent=2))
    else:
        print(f"modes : {validation['n_modes']}")
        print(f"RMSE  : {validation['rmse_cm1']:.2f} cm^-1")
        print(f"max   : {validation['max_abs_cm1']:.2f} cm^-1")
        print(f"mean  : {validation['mean_signed_cm1']:+.2f} cm^-1")
        print("ORCA (first 10) :", np.round(validation["orca_frequencies_cm1"][:10], 1))
        print("FF   (first 10) :", np.round(validation["ff_frequencies_cm1"][:10], 1))
    return 0


def cmd_export(args: argparse.Namespace) -> int:
    molecule, hessian, frequencies, charges, topology, params = _load(args)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    stem = args.stem
    params_path = outdir / f"{stem}.json"
    ff_path = outdir / f"{stem}.ff"
    data_path = outdir / f"{stem}.data"
    conf_path = outdir / f"{stem}.conf"
    validation_path = outdir / f"{stem}_validation.json"
    plugin_params_path = outdir / f"{stem}_molff.params"

    orca_ff.write_params_json(params, params_path)
    orca_ff.write_plugin_params(
        params,
        plugin_params_path,
        ewald_accuracy=args.ewald_accuracy,
        slab_correction=args.slab_correction,
    )
    orca_ff.write_adobmd_ff(
        params,
        ff_path,
        plugin_name=args.plugin_name,
        plugin_path=args.plugin_path,
        plugin_params=f"./{plugin_params_path.name}",
    )
    orca_ff.write_adobmd_data(params, data_path, box=args.box)
    orca_ff.write_adobmd_conf(
        params,
        conf_path,
        data_file=f"./{data_path.name}",
        ff_file=f"./{ff_path.name}",
        nsteps=args.nsteps,
        temperature=args.temperature,
        dt_fs=args.dt_fs,
        output_prefix=f"./{stem}_run",
        material=args.material,
    )
    validation = orca_ff.validate_frequencies(params, frequencies)
    validation_path.write_text(json.dumps(_jsonable(validation), indent=2) + "\n")

    result = {
        "params": str(params_path),
        "forcefield": str(ff_path),
        "data": str(data_path),
        "config": str(conf_path),
        "plugin_params": str(plugin_params_path),
        "validation": str(validation_path),
        "frequency_rmse_cm1": validation["rmse_cm1"],
        "hessian_correlation": params.metadata.get("hessian_correlation"),
    }
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        for key, value in result.items():
            print(f"{key:22s}: {value}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="orca2adobmd_cli",
        description="Convert a finished ORCA calculation into an ADOBMD force field.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    def common(item: argparse.ArgumentParser) -> argparse.ArgumentParser:
        item.add_argument("--xyz", default=None, help="optimized XYZ geometry")
        item.add_argument("--out", dest="out", default=None,
                          help="ORCA output to read the geometry from (if no --xyz)")
        item.add_argument("--hess", required=True, help="ORCA .hess file")
        item.add_argument("--property", required=True, help="ORCA .property.txt with charges")
        item.add_argument("--charges", choices=["mbis", "chelpg"], default="mbis")
        item.add_argument("--intramolecular-nonbonded", action="store_true")
        item.add_argument("--json", action="store_true")
        return item

    common(sub.add_parser("info", help="summary of the ORCA case"))
    common(sub.add_parser("topology", help="inferred bonds/angles/torsions"))
    common(sub.add_parser("fit", help="fit force constants and validate frequencies"))
    common(sub.add_parser("validate", help="compare FF frequencies with ORCA"))

    export = common(sub.add_parser("export", help="write params.json, .ff, .data, .conf"))
    export.add_argument("--outdir", dest="outdir", default="adobmd")
    export.add_argument("--stem", default="molecule")
    export.add_argument("--plugin-name", default="molff")
    export.add_argument("--plugin-path", default="./molff.so")
    export.add_argument("--box", type=float, default=None)
    export.add_argument("--material", default="MOL")
    export.add_argument("--nsteps", type=int, default=10000)
    export.add_argument("--temperature", type=float, default=300.0)
    export.add_argument("--dt-fs", type=float, default=1.0)
    export.add_argument("--ewald-accuracy", type=float, default=1.0e-6)
    export.add_argument("--slab-correction", action="store_true")

    # `--out` is overloaded in `common` (ORCA output) and `export` (directory).
    # Keep the export directory under `--outdir` to avoid ambiguity.
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command in {"info", "topology", "fit", "validate", "export"}:
        if not args.xyz and not args.out:
            parser.error("give --xyz (geometry) or --out (ORCA output)")
    handlers = {
        "info": cmd_info,
        "topology": cmd_topology,
        "fit": cmd_fit,
        "validate": cmd_validate,
        "export": cmd_export,
    }
    return int(handlers[args.command](args))


if __name__ == "__main__":
    raise SystemExit(main())
