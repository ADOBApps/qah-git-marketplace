#!/usr/bin/env python3
"""Adsorption energy of a molecule on a periodic slab (ADOBMD force field).

    E_ads = E(complex) - E(slab) - E(molecule, gas)

Nonbonded terms come from the generic periodic plugin (Ewald + Buckingham/LJ),
with the molecule's 1-2/1-3 exclusions; the molecule's harmonic bonds, bends
and torsions come from its ADOBMD `.ff`.  The slab is kept fixed at the
geometry of the complex (rigid-slab adsorption energy).

Usage
-----
    python3 adsorption_energy.py \
        --complex E2/ads_pristine_oh_down/CONTCAR \
        --ff ../molecular/E2/ff/adobmd/e2.ff \
        --data ../molecular/E2/ff/adobmd/e2.data \
        --molff ../molecular/E2/ff/adobmd/e2_molff.params \
        --plugin ./periodic_ff.so --json
"""
from __future__ import annotations

import argparse
import ctypes
import json
import math
import sys
import tempfile
from pathlib import Path
from typing import Optional, Sequence

import numpy as np

try:
    from . import test_periodic as T  # type: ignore
except Exception:  # standalone use
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import test_periodic as T  # type: ignore

EV = 1.602176634e-19
ANG = 1.0e-10
KCAL = 1.0 / 23.060548867
SIG = {"O": 3.12, "Ti": 2.83, "C": 3.50, "H": 2.50}
EPS = {"O": 0.17, "Ti": 0.069, "C": 0.066, "H": 0.030}
QS = {"O": -1.098, "Ti": 2.196}
Z = {"O": 8, "Ti": 22, "C": 6, "H": 1}
BUCK = {"TiTi": (717654.0, 0.154, 120.997),
        "TiO": (391053.0, 0.194, 290.392),
        "OO": (271719.0, 0.234, 696.941)}


def read_contcar(path):
    L = Path(path).read_text().splitlines()
    lat = np.array([[float(x) for x in L[i].split()[:3]] for i in (2, 3, 4)])
    sp = L[5].split()
    cnt = [int(x) for x in L[6].split()]
    i = 7
    if L[i].strip().lower().startswith("s"):
        i += 1
    mode = L[i].strip()
    i += 1
    n = sum(cnt)
    pos = np.array([[float(x) for x in L[i + k].split()[:3]] for k in range(n)])
    if mode.lower().startswith("d"):
        pos = pos @ lat
    syms = []
    for s, c in zip(sp, cnt):
        syms += [s] * c
    return lat, syms, pos


def ff_types(path):
    out = []
    inside = False
    for l in Path(path).read_text().splitlines():
        t = l.strip()
        if t.startswith("<AtomTypes>"):
            inside = True
            continue
        if t.startswith("</AtomTypes>"):
            break
        if inside and t and not t.startswith("#"):
            p = t.split()
            if len(p) == 6:
                out.append((p[0], p[1], float(p[2]), float(p[3]), float(p[4]), float(p[5])))
    return out


def read_mol_data(path):
    L = Path(path).read_text().splitlines()

    def sec(name, ncol):
        try:
            i = L.index(name) + 1
        except ValueError:
            return []
        out = []
        while i < len(L):
            s = L[i].strip()
            if not s or s.startswith("#"):
                i += 1
                continue
            p = s.split()
            if len(p) != ncol:
                break
            out.append([int(x) for x in p])
            i += 1
        return out

    box = None
    for l in L:
        p = l.split()
        if len(p) == 4 and p[2] in ("xlo", "ylo", "zlo"):
            box = float(p[1])
            break
    atoms = []
    i = L.index("Atoms") + 1
    while i < len(L):
        s = L[i].strip()
        if not s or s.startswith("#"):
            i += 1
            continue
        p = s.split()
        if len(p) != 7:
            break
        atoms.append(np.array([float(p[4]), float(p[5]), float(p[6])]))
        i += 1
    return np.array(atoms), sec("Bonds", 4), sec("Angles", 5), sec("Dihedrals", 6), box


def ff_bonded(path):
    b, a, t = {}, {}, {}
    sec = None
    for l in Path(path).read_text().splitlines():
        s = l.strip()
        if s.startswith("<BondTypes>"):
            sec = "b"
            continue
        if s.startswith("<BendTypes>"):
            sec = "a"
            continue
        if s.startswith("<TorsionTypes>"):
            sec = "t"
            continue
        if s.startswith("</"):
            sec = None
            continue
        if not sec or not s or s.startswith("#"):
            continue
        p = s.split()
        if sec == "b" and len(p) == 5:
            b[len(b) + 1] = (float(p[3]), float(p[4]))
        elif sec == "a" and len(p) == 6:
            a[len(a) + 1] = (float(p[4]), float(p[5]))
        elif sec == "t" and len(p) == 7:
            t[len(t) + 1] = (float(p[5]), float(p[6]))
    return b, a, t


def make_params(path, syms, pos, types, mol_local, excl_global):
    n = len(syms)
    mset = set(mol_local)
    lines = ["format 2", f"natoms {n}", "accuracy 1.0e-6", "method pppm",
             "order 4", "cut_nb 10.0", "slab 0"]
    for i, s in enumerate(syms):
        q = types[mol_local.index(i)][5] if i in mset else QS[s]
        lines.append(f"charge {i} {q:.8f}")

    def tinfo(i):
        if i in mset:
            t = types[mol_local.index(i)]
            return t[3], t[4]
        return SIG[syms[i]], EPS[syms[i]]

    for a in range(n - 1):
        for c in range(a + 1, n):
            if a in mset or c in mset:
                sa, ea = tinfo(a)
                sc, ec = tinfo(c)
                lines.append(f"lj {a} {c} {0.5 * (sa + sc):.6f} {math.sqrt(ea * ec) * KCAL:.10f}")
            else:
                k = ("TiTi" if (syms[a] == "Ti" and syms[c] == "Ti")
                     else "OO" if (syms[a] == "O" and syms[c] == "O") else "TiO")
                A, rho, C = BUCK[k]
                lines.append(f"buck {a} {c} {A * KCAL:.8f} {rho:.6f} {C * KCAL:.8f}")
    for (i, j) in excl_global:
        lines.append(f"exclude {i} {j}")
    Path(path).write_text("\n".join(lines) + "\n")


def system_for(lat, syms, pos, types, mol_local):
    n = len(syms)
    mset = set(mol_local)
    p = (ctypes.c_double * (3 * n))(*[c * ANG for xyz in pos for c in xyz])
    b = (ctypes.c_double * 3)(lat[0, 0] * ANG, lat[1, 1] * ANG, lat[2, 2] * ANG)
    cell = (ctypes.c_double * 9)(lat[0, 0] * ANG, 0, 0, 0, lat[1, 1] * ANG, 0, 0, 0, lat[2, 2] * ANG)
    sites = (T.Site * n)()
    tc = (ctypes.c_int * n)()
    for i, s in enumerate(syms):
        sites[i].z = Z[s]
        sites[i].type_idx = i + 1
        sites[i].charge = types[mol_local.index(i)][5] if i in mset else QS[s]
        tc[i] = i + 1
    return T.System(n, p, b, sites, tc, (ctypes.c_void_p * 2)(), cell, None)


def bonded(x, bonds, angles, dih, bt, at, tt):
    e = 0.0
    for b in bonds:
        r0, k = bt[b[1]]
        r = np.linalg.norm(x[b[2] - 1] - x[b[3] - 1])
        e += 0.5 * k * (r - r0) ** 2
    for a in angles:
        th0, k = at[a[1]]
        u = x[a[2] - 1] - x[a[3] - 1]
        v = x[a[4] - 1] - x[a[3] - 1]
        th = math.acos(max(-1, min(1, np.dot(u, v) / (np.linalg.norm(u) * np.linalg.norm(v)))))
        e += 0.5 * k * (th - math.radians(th0)) ** 2
    for t in dih:
        ph0, k = tt[t[1]]
        b1 = x[t[3] - 1] - x[t[2] - 1]
        b2 = x[t[4] - 1] - x[t[3] - 1]
        b3 = x[t[5] - 1] - x[t[4] - 1]
        n1 = np.cross(b1, b2)
        n2 = np.cross(b2, b3)
        m = np.cross(n1, b2 / np.linalg.norm(b2))
        ph = math.atan2(np.dot(m, n2), np.dot(n1, n2))
        d = (ph - math.radians(ph0) + math.pi) % (2 * math.pi) - math.pi
        e += 0.5 * k * d * d
    return e * KCAL


def _relax_molecule(lat, syms, pos, types, mol_idx, bonds, angles, dih, bt, at, tt,
                    lib, tmp, maxiter=200):
    """Relax the molecule with the slab fixed.  Returns a copy of pos."""
    from scipy.optimize import minimize
    import numpy as np

    n = len(mol_idx)
    x0 = pos[mol_idx].ravel()
    # complex system (all atoms)
    sc, pc = _build_sys(lat, syms, pos, types, mol_idx)
    # molecule-only, same cell/positions (intramolecular terms cancel)
    sm, pm = _build_sys(lat, [syms[i] for i in mol_idx],
                        [pos[i] for i in mol_idx], types, list(range(n)))
    make_params(tmp / "rc.params", syms, pos, types, mol_idx, _excl(bonds, angles, mol_idx))
    make_params(tmp / "rm.params", [syms[i] for i in mol_idx], [pos[i] for i in mol_idx],
                types, list(range(n)), _excl(bonds, angles, None))
    rc = str(tmp / "rc.params").encode()
    rm = str(tmp / "rm.params").encode()
    lib.adobmd_plugin_energy_forces.argtypes = [ctypes.POINTER(T.System), ctypes.POINTER(ctypes.c_double)]
    lib.adobmd_plugin_energy_forces.restype = ctypes.c_double
    fc = (ctypes.c_double * (3 * len(syms)))()
    fm = (ctypes.c_double * (3 * n))()
    F2G = 1.0e-10 / EV

    def setx(x):
        xm = x.reshape(n, 3)
        for k, i in enumerate(mol_idx):
            pc[3 * i] = xm[k, 0] * ANG
            pc[3 * i + 1] = xm[k, 1] * ANG
            pc[3 * i + 2] = xm[k, 2] * ANG
        for k in range(3 * n):
            pm[k] = x[k] * ANG

    def eg(x):
        setx(x)
        lib.adobmd_plugin_init(ctypes.byref(sc), rc)
        ec = lib.adobmd_plugin_energy_forces(ctypes.byref(sc), fc) / EV
        lib.adobmd_plugin_init(ctypes.byref(sm), rm)
        em = lib.adobmd_plugin_energy_forces(ctypes.byref(sm), fm) / EV
        g = np.zeros(3 * n)
        for k, i in enumerate(mol_idx):
            g[3 * k] = (-fc[3 * i] + fm[3 * k]) * F2G
            g[3 * k + 1] = (-fc[3 * i + 1] + fm[3 * k + 1]) * F2G
            g[3 * k + 2] = (-fc[3 * i + 2] + fm[3 * k + 2]) * F2G
        h = 1e-4
        for k in range(3 * n):
            xp = x.copy(); xp[k] += h
            xm2 = x.copy(); xm2[k] -= h
            bp = bonded(xp.reshape(n, 3), bonds, angles, dih, bt, at, tt)
            bm = bonded(xm2.reshape(n, 3), bonds, angles, dih, bt, at, tt)
            g[k] += (bp - bm) / (2 * h)
        return (ec - em) + bonded(x.reshape(n, 3), bonds, angles, dih, bt, at, tt), g

    res = minimize(lambda x: eg(x), x0, jac=True, method="L-BFGS-B",
                   options={"maxiter": maxiter, "ftol": 1e-12, "gtol": 1e-5})
    out = pos.copy()
    out[mol_idx] = res.x.reshape(n, 3)
    return out, float(res.fun)


def _excl(bonds, angles, mol_idx):
    ex = set()
    for b in bonds:
        ex.add((min(b[2] - 1, b[3] - 1), max(b[2] - 1, b[3] - 1)))
    for a in angles:
        ex.add((min(a[2] - 1, a[4] - 1), max(a[2] - 1, a[4] - 1)))
    ex = sorted(ex)
    if mol_idx is None:
        return ex
    return [(mol_idx[i], mol_idx[j]) for i, j in ex]


def _build_sys(lat, syms, pos, types, mol_local):
    n = len(syms)
    mset = set(mol_local)
    p = (ctypes.c_double * (3 * n))(*[c * ANG for xyz in pos for c in xyz])
    b = (ctypes.c_double * 3)(lat[0, 0] * ANG, lat[1, 1] * ANG, lat[2, 2] * ANG)
    cell = (ctypes.c_double * 9)(lat[0, 0] * ANG, 0, 0, 0, lat[1, 1] * ANG, 0, 0, 0, lat[2, 2] * ANG)
    sites = (T.Site * n)()
    tc = (ctypes.c_int * n)()
    for i, s in enumerate(syms):
        sites[i].z = Z[s]
        sites[i].type_idx = i + 1
        sites[i].charge = types[mol_local.index(i)][5] if i in mset else QS[s]
        tc[i] = i + 1
    return T.System(n, p, b, sites, tc, (ctypes.c_void_p * 2)(), cell, None), p


def compute_e_ads(complex_path, ff_path, data_path, molff_path, plugin_path,
                  accuracy=1.0e-6, relax=False, relax_maxiter=200):
    lib = ctypes.CDLL(str(plugin_path))
    lib.adobmd_plugin_init.argtypes = [ctypes.POINTER(T.System), ctypes.c_char_p]
    lib.adobmd_plugin_init.restype = ctypes.c_int
    lib.adobmd_plugin_energy.argtypes = [ctypes.POINTER(T.System)]
    lib.adobmd_plugin_energy.restype = ctypes.c_double

    def E(sysm, path):
        if lib.adobmd_plugin_init(ctypes.byref(sysm), str(path).encode()) != 0:
            raise RuntimeError(f"plugin init failed for {path}")
        return lib.adobmd_plugin_energy(ctypes.byref(sysm)) / EV

    lat, syms, pos = read_contcar(complex_path)
    types = ff_types(ff_path)
    gas, bonds, angles, dih, mbox = read_mol_data(data_path)
    bt, at, tt = ff_bonded(ff_path)
    o = [i for i, s in enumerate(syms) if s == "O"]
    c = [i for i, s in enumerate(syms) if s == "C"]
    h = [i for i, s in enumerate(syms) if s == "H"]
    if not c:
        raise ValueError("no carbon atoms: is this a molecular complex?")
    mol_o = [i for i in o if min(np.linalg.norm(pos[c] - pos[i], axis=1)) < 1.6]
    mol_idx = sorted(mol_o) + c + h
    slab_idx = [i for i in range(len(syms)) if i not in mol_idx]
    ex = set()
    for b in bonds:
        ex.add((min(b[2] - 1, b[3] - 1), max(b[2] - 1, b[3] - 1)))
    for a in angles:
        ex.add((min(a[2] - 1, a[4] - 1), max(a[2] - 1, a[4] - 1)))
    excl = sorted(ex)

    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        if relax:
            pos, _ = _relax_molecule(lat, syms, pos, types, mol_idx, bonds, angles,
                                     dih, bt, at, tt, lib, tmp, relax_maxiter)
        make_params(tmp / "c.params", syms, pos, types, mol_idx,
                    [(mol_idx[i], mol_idx[j]) for i, j in excl])
        ec = E(system_for(lat, syms, pos, types, mol_idx), tmp / "c.params")

        make_params(tmp / "s.params", [syms[i] for i in slab_idx], pos[slab_idx],
                    types, [], [])
        es = E(system_for(lat, [syms[i] for i in slab_idx], pos[slab_idx], types, []),
               tmp / "s.params")

        mlat = np.diag([mbox, mbox, mbox]) if mbox else np.diag([40.0, 40.0, 40.0])
        make_params(tmp / "m.params", [syms[i] for i in mol_idx], gas, types,
                    list(range(len(mol_idx))), excl)
        em = E(system_for(mlat, [syms[i] for i in mol_idx], gas, types,
                          list(range(len(mol_idx)))), tmp / "m.params")

    eb_c = bonded(pos[mol_idx], bonds, angles, dih, bt, at, tt)
    eb_g = bonded(gas, bonds, angles, dih, bt, at, tt)
    e_ads = (ec - es - em) + (eb_c - eb_g)
    return {
        "E_ads_eV": e_ads,
        "E_ads_kcal_mol": e_ads * 23.060548867,
        "E_complex_eV": ec,
        "E_slab_eV": es,
        "E_molecule_gas_eV": em,
        "E_bonded_complex_eV": eb_c,
        "E_bonded_gas_eV": eb_g,
        "natoms_complex": len(syms),
        "natoms_molecule": len(mol_idx),
    }


def main(argv: Optional[Sequence[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--complex", required=True, help="CONTCAR of slab+molecule")
    ap.add_argument("--ff", required=True, help="molecule .ff")
    ap.add_argument("--data", required=True, help="molecule .data (gas geometry)")
    ap.add_argument("--molff", required=True, help="molecule _molff.params")
    ap.add_argument("--plugin", default="./periodic_ff.so")
    ap.add_argument("--relax", action="store_true", help="relax the molecule (slab fixed)")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    res = compute_e_ads(args.complex, args.ff, args.data, args.molff, args.plugin,
                        relax=args.relax)
    if args.json:
        print(json.dumps(res, indent=2))
    else:
        print(f"E_ads = {res['E_ads_eV']:.4f} eV = {res['E_ads_kcal_mol']:.2f} kcal/mol")
        print(f"  complex {res['E_complex_eV']:.4f}  slab {res['E_slab_eV']:.4f}  "
              f"molecule(gas) {res['E_molecule_gas_eV']:.4f} eV")
        print(f"  bonded: complex {res['E_bonded_complex_eV']:.4f}  "
              f"gas {res['E_bonded_gas_eV']:.4f} eV")
    return 0


if __name__ == "__main__":
    sys.exit(main())
