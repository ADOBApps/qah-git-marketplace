#!/usr/bin/env python3
"""
qe2adobmd — Quantum ESPRESSO (pw.x) -> ADOBMD importer.

Reads a QE input (CELL_PARAMETERS / ATOMIC_POSITIONS) and, optionally, a QE
output (`! total energy`, final positions, `Forces acting on atoms`), then
writes the same ADOBMD files as vasp2adobmd:

    system.data, system.ff, periodic.params, system.conf, reference.json

Reuses the writers from ../vasp2adobmd.

Examples
--------
    python3 qe2adobmd.py info scf.in scf.out
    python3 qe2adobmd.py convert scf.in scf.out --out ./adobmd --params tio2.params

This file is part of QAH and is GPL-3.0-or-later.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from typing import List, Optional, Sequence, Tuple

import numpy as np

from . import vasp2adobmd as V  # noqa: E402

RY_TO_EV = 13.605693122994
BOHR_TO_ANG = 0.529177210903
RY_BOHR_TO_EV_ANG = RY_TO_EV / BOHR_TO_ANG


class QeError(ValueError):
    pass


def _factor(unit: str, alat_ang: float) -> Optional[float]:
    u = unit.lower()
    if u.startswith("angstrom"):
        return 1.0
    if u.startswith("bohr"):
        return BOHR_TO_ANG
    if u.startswith("alat"):
        return alat_ang
    if u.startswith("crystal"):
        return None
    return 1.0


def _parse_cell(lines: List[str], i: int, alat_ang: float) -> Tuple[np.ndarray, int]:
    header = lines[i]
    m = re.search(r"\((.*?)\)", header)
    unit = m.group(1) if m else "angstrom"
    vec = np.array([[float(x) for x in lines[i + 1 + k].split()[:3]] for k in range(3)])
    f = _factor(unit, alat_ang)
    if f is not None:
        vec *= f
    return vec, i + 4


def _parse_positions(lines: List[str], i: int, nat: int, lattice: np.ndarray,
                     alat_ang: float) -> Tuple[List[str], np.ndarray, int]:
    header = lines[i]
    m = re.search(r"\((.*?)\)", header)
    unit = m.group(1) if m else "angstrom"
    symbols, coords = [], []
    for k in range(nat):
        parts = lines[i + 1 + k].split()
        if len(parts) < 4:
            break
        symbols.append(parts[0])
        coords.append([float(x) for x in parts[1:4]])
    coords = np.array(coords, dtype=float)
    f = _factor(unit, alat_ang)
    if f is None:  # crystal / fractional
        coords = coords @ lattice
    else:
        coords *= f
    return symbols, coords, i + 1 + nat


def read_input(path: str | Path) -> V.VaspSystem:
    lines = Path(path).read_text().splitlines()
    nat = None
    alat_ang = None
    for line in lines:
        m = re.search(r"\bnat\s*=\s*(\d+)", line, re.I)
        if m:
            nat = int(m.group(1))
        m = re.search(r"\bcelldm\(1\)\s*=\s*([0-9.]+)", line, re.I)
        if m:
            alat_ang = float(m.group(1)) * BOHR_TO_ANG
        m = re.search(r"\bA\s*=\s*([0-9.]+)", line)
        if m:
            alat_ang = float(m.group(1))
    if alat_ang is None:
        alat_ang = 1.0

    lattice = None
    symbols = None
    coords = None
    for i, line in enumerate(lines):
        u = line.strip().upper()
        if u.startswith("CELL_PARAMETERS"):
            lattice, _ = _parse_cell(lines, i, alat_ang)
        elif u.startswith("ATOMIC_POSITIONS"):
            if nat is None:
                nat = sum(1 for l in lines[i + 1:] if len(l.split()) >= 4 and not l.strip().isupper())
            symbols, coords, _ = _parse_positions(lines, i, nat, lattice, alat_ang)
    if lattice is None or symbols is None:
        raise QeError(f"{path}: CELL_PARAMETERS / ATOMIC_POSITIONS not found")
    return V.VaspSystem(lattice=lattice, symbols=symbols, coords=coords,
                        comment=f"QE input {Path(path).name}")


def read_output(path: str | Path, system: V.VaspSystem) -> V.VaspSystem:
    lines = Path(path).read_text(errors="ignore").splitlines()
    alat_ang = float(system.lattice[0, 0])

    for line in lines:
        m = re.search(r"!\s+total energy\s*=\s*([-+0-9.Ee]+)\s*Ry", line)
        if m:
            system.energy_ev = float(m.group(1)) * RY_TO_EV

    for i, line in enumerate(lines):
        u = line.strip().upper()
        if u.startswith("CELL_PARAMETERS"):
            system.lattice, _ = _parse_cell(lines, i, alat_ang)
        elif u.startswith("ATOMIC_POSITIONS"):
            system.symbols, system.coords, _ = _parse_positions(
                lines, i, system.natoms, system.lattice, alat_ang)

    idx = None
    for i, line in enumerate(lines):
        if "Forces acting on atoms" in line:
            idx = i
    if idx is not None:
        forces = []
        for line in lines[idx + 1:]:
            if not line.strip():
                if forces:
                    break
                continue
            m = re.search(r"force\s*=\s*([-+0-9.Ee]+)\s+([-+0-9.Ee]+)\s+([-+0-9.Ee]+)", line)
            if m:
                forces.append([float(x) for x in m.groups()])
        if len(forces) == system.natoms:
            system.forces_ev_a = np.array(forces) * RY_BOHR_TO_EV_ANG
    return system


def cmd_info(args: argparse.Namespace) -> int:
    system = read_input(args.input)
    if args.output:
        system = read_output(args.output, system)
    print(f"comment : {system.comment}")
    print(f"natoms  : {system.natoms}")
    print(f"species : {', '.join(dict.fromkeys(system.symbols))}")
    print(f"cell    : {system.box_lengths()} A")
    if system.energy_ev is not None:
        print(f"energy  : {system.energy_ev:.6f} eV")
    if system.forces_ev_a is not None:
        print(f"forces  : max |F| = {np.max(np.abs(system.forces_ev_a)):.6f} eV/A")
    return 0


def cmd_convert(args: argparse.Namespace) -> int:
    system = read_input(args.input)
    if args.output:
        system = read_output(args.output, system)
    system.check_orthorhombic()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    if args.charges_file:
        charges = V.read_bader_charges(args.charges_file)
        if len(charges) != system.natoms:
            raise QeError(f"Bader file has {len(charges)} charges, "
                          f"system has {system.natoms} atoms")
    elif args.charges:
        charges = V.parse_charges(args.charges, system.symbols)
    elif args.params:
        charges = V.read_params_charges(args.params, system.symbols)
    else:
        charges = V.parse_charges(None, system.symbols)
    data = V.write_data(system, charges, out / "system.data")
    if args.params:
        import shutil
        params = out / "periodic.params"
        if Path(args.params).resolve() != params.resolve():
            shutil.copyfile(args.params, params)
    else:
        params = V.write_params(system, charges, out / "periodic.params")
    ff = V.write_ff(system, args.plugin, str(params.resolve()), out / "system.ff")
    conf = V.write_conf(system, data.resolve(), ff.resolve(), out / "system.conf",
                        material=args.material, nsteps=args.nsteps)
    ref = V.write_reference(system, out / "reference.json")
    for p in (data, params, ff, conf, ref):
        print(f"wrote   : {p}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command", required=True)

    def common(p):
        p.add_argument("input")
        p.add_argument("output", nargs="?")

    info = sub.add_parser("info")
    common(info)
    info.set_defaults(func=cmd_info)

    conv = sub.add_parser("convert")
    common(conv)
    conv.add_argument("--out", required=True)
    conv.add_argument("--params", default=None,
                      help="copy an existing periodic.params (e.g. from kim2adobmd)")
    conv.add_argument("--charges", default=None)
    conv.add_argument("--charges-file", default=None,
                      help="Bader ACF.dat (charge column, atom order)")
    conv.add_argument("--plugin", default="./periodic_ff.so",
                      help="path written into the .ff <Plugins> block")
    conv.add_argument("--material", default="TiO2")
    conv.add_argument("--nsteps", type=int, default=0)
    conv.set_defaults(func=cmd_convert)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return int(args.func(args))
    except QeError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
