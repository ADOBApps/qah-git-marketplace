#!/usr/bin/env python3
"""
vasp2adobmd — VASP (POSCAR/OUTCAR) -> ADOBMD importer.

Reads a VASP geometry (POSCAR/CONTCAR) and, optionally, the final energy and
forces from OUTCAR, then writes:

    <out>/system.data        ADOBMD unified data file
    <out>/system.ff          .ff routing every pair to the periodic plugin
    <out>/periodic.params    plugin parameter file (charges; no short-range
                             terms yet — inject TTAM/Pedone when available)
    <out>/system.conf        ADOBMD run configuration
    <out>/reference.json     energy/forces/stress for validation

The cell must be orthorhombic (ADOBMD's box is a 3-vector). The anatase
conventional cell (a = b != c) satisfies this.

Examples
--------
    python3 vasp2adobmd.py info POSCAR OUTCAR
    python3 vasp2adobmd.py convert POSCAR OUTCAR --out ./adobmd \
        --charges "Ti:2.196,O:-1.098"

This file is part of QAH and is GPL-3.0-or-later.
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

# masses (amu) and default formal charges
MASS = {
    "H": 1.008, "C": 12.011, "N": 14.007, "O": 15.999, "F": 18.998,
    "Na": 22.990, "Mg": 24.305, "Al": 26.982, "Si": 28.085, "P": 30.974,
    "S": 32.06, "Cl": 35.45, "K": 39.098, "Ca": 40.078, "Ti": 47.867,
    "V": 50.942, "Cr": 51.996, "Mn": 54.938, "Fe": 55.845, "Co": 58.933,
    "Ni": 58.693, "Cu": 63.546, "Zn": 65.38, "Zr": 91.224, "Sn": 118.710,
}
FORMAL = {"Ti": 4.0, "O": -2.0, "Sn": 4.0, "Zr": 4.0, "Si": 4.0}
SYMBOL_Z = {
    "H": 1, "C": 6, "N": 7, "O": 8, "F": 9, "Na": 11, "Mg": 12, "Al": 13,
    "Si": 14, "P": 15, "S": 16, "Cl": 17, "K": 19, "Ca": 20, "Ti": 22,
    "Cr": 24, "Mn": 25, "Fe": 26, "Co": 27, "Ni": 28, "Cu": 29, "Zn": 30,
    "Zr": 40, "Sn": 50,
}
EV_TO_KCAL = 23.060548867
ANG_TO_BOHR = 1.8897261246257702


class VaspError(ValueError):
    pass


@dataclass
class VaspSystem:
    lattice: np.ndarray          # (3,3) angstrom
    symbols: List[str]
    coords: np.ndarray           # (N,3) angstrom, cartesian
    comment: str = ""
    energy_ev: Optional[float] = None
    forces_ev_a: Optional[np.ndarray] = None   # (N,3) eV/angstrom
    stress_kbar: Optional[np.ndarray] = None

    @property
    def natoms(self) -> int:
        return len(self.symbols)

    def box_lengths(self) -> Tuple[float, float, float]:
        return tuple(float(self.lattice[i, i]) for i in range(3))  # type: ignore

    def check_orthorhombic(self, tol: float = 1e-6) -> None:
        off = self.lattice.copy()
        np.fill_diagonal(off, 0.0)
        if np.max(np.abs(off)) > tol:
            raise VaspError(
                "cell is not orthorhombic; ADOBMD uses an orthorhombic box. "
                f"off-diagonal max = {np.max(np.abs(off)):.3e} A"
            )


def _species_from_potcar(path: Path) -> List[str]:
    if not path.exists():
        return []
    species = []
    for line in path.read_text(errors="ignore").splitlines():
        m = re.search(r"VRHFIN\s*=\s*([A-Za-z]+)", line)
        if m:
            species.append(m.group(1))
    return species


def read_poscar(path: str | Path) -> VaspSystem:
    path = Path(path)
    lines = path.read_text().splitlines()
    if len(lines) < 8:
        raise VaspError(f"{path}: too short for a POSCAR")

    comment = lines[0].strip()
    scale = float(lines[1].split()[0])
    lattice = np.array([[float(x) for x in lines[i].split()[:3]] for i in (2, 3, 4)])
    lattice *= scale

    idx = 5
    tokens = lines[idx].split()
    # VASP5 has a species line; VASP4 does not.
    if tokens and all(re.fullmatch(r"[A-Za-z]+", t) for t in tokens):
        species = tokens
        idx += 1
    else:
        species = _species_from_potcar(path.parent / "POTCAR")
        if not species:
            raise VaspError("no species line in POSCAR and no POTCAR found")

    counts = [int(x) for x in lines[idx].split()]
    idx += 1
    if len(counts) != len(species):
        raise VaspError(f"species {species} and counts {counts} disagree")

    line = lines[idx].strip()
    if line.lower().startswith("s"):
        idx += 1
        line = lines[idx].strip()
    direct = line[:1].lower() == "d"
    idx += 1

    natoms = sum(counts)
    coords = []
    labels = []
    for a in range(natoms):
        parts = lines[idx + a].split()
        coords.append([float(x) for x in parts[:3]])
        labels.append(parts[3] if len(parts) > 3 else None)
    coords = np.array(coords, dtype=float)
    if direct:
        coords = coords @ lattice

    symbols: List[str] = []
    for sym, count in zip(species, counts):
        symbols.extend([sym] * count)
    if all(labels) and len(labels) == natoms:
        # trust per-atom labels when present (they also carry the order)
        symbols = [str(x) for x in labels]

    return VaspSystem(lattice=lattice, symbols=symbols, coords=coords,
                      comment=comment)


def read_outcar(path: str | Path) -> Tuple[Optional[float], Optional[np.ndarray], Optional[np.ndarray]]:
    path = Path(path)
    if not path.exists():
        return None, None, None
    text = path.read_text(errors="ignore").splitlines()

    energy = None
    for line in text:
        m = re.search(r"free\s+energy\s+TOTEN\s*=\s*([-+0-9.Ee]+)\s*eV", line)
        if m:
            energy = float(m.group(1))

    forces = None
    start = None
    for i, line in enumerate(text):
        if "TOTAL-FORCE" in line:
            start = i
    if start is not None:
        rows = []
        for line in text[start + 2:]:
            parts = line.split()
            if len(parts) < 6:
                break
            try:
                rows.append([float(x) for x in parts[3:6]])
            except ValueError:
                break
        if rows:
            forces = np.array(rows, dtype=float)

    stress = None
    for i, line in enumerate(text):
        if "in kB" in line:
            vals = []
            for j in range(i, min(i + 4, len(text))):
                toks = text[j].split()
                if j == i:
                    toks = toks[4:] if len(toks) > 4 else toks
                for t in toks:
                    try:
                        vals.append(float(t))
                    except ValueError:
                        pass
            if len(vals) >= 6:
                stress = np.array(vals[:6], dtype=float)
                break
    return energy, forces, stress


def read_bader_charges(path: str | Path) -> List[float]:
    """Parse the charge column (5th) of a Bader ACF.dat file."""
    charges: List[float] = []
    for line in Path(path).read_text().splitlines():
        parts = line.split()
        if len(parts) >= 5 and parts[0].isdigit():
            charges.append(float(parts[4]))
    if not charges:
        raise VaspError(f"{path}: no Bader charges found")
    return charges


def read_params_charges(path: str | Path, symbols: Sequence[str]) -> List[float]:
    """Read charge_z / charge lines from a periodic_ff parameter file."""
    by_z: Dict[int, float] = {}
    by_index: Dict[int, float] = {}
    for line in Path(path).read_text().splitlines():
        parts = line.split("#")[0].split()
        if not parts:
            continue
        if parts[0] == "charge_z" and len(parts) >= 3:
            by_z[int(parts[1])] = float(parts[2])
        elif parts[0] == "charge" and len(parts) >= 3:
            by_index[int(parts[1])] = float(parts[2])
    out = []
    for i, s in enumerate(symbols):
        if i in by_index:
            out.append(by_index[i])
        else:
            out.append(by_z.get(SYMBOL_Z.get(s, -1), FORMAL.get(s, 0.0)))
    return out


def parse_charges(spec: Optional[str], symbols: Sequence[str]) -> List[float]:
    table: Dict[str, float] = dict(FORMAL)
    if spec:
        for item in spec.split(","):
            if not item.strip():
                continue
            name, value = item.split(":")
            table[name.strip()] = float(value)
    return [table.get(s, 0.0) for s in symbols]


def write_data(system: VaspSystem, charges: Sequence[float], path: Path) -> Path:
    system.check_orthorhombic()
    lx, ly, lz = system.box_lengths()
    species = []
    for s in system.symbols:
        if s not in species:
            species.append(s)
    type_of = {s: i + 1 for i, s in enumerate(species)}

    # wrap into the cell
    frac = np.linalg.solve(system.lattice.T, system.coords.T).T
    frac -= np.floor(frac)
    coords = frac @ system.lattice

    lines: List[str] = []
    lines.append("# ADOBMD data file - generated by vasp2adobmd")
    lines.append(f"{system.natoms} atoms")
    lines.append("0 bonds")
    lines.append("0 angles")
    lines.append("0 dihedrals")
    lines.append("0 impropers")
    lines.append("")
    lines.append(f"{len(species)} atom types")
    lines.append("0 bond types")
    lines.append("0 angle types")
    lines.append("0 dihedral types")
    lines.append("")
    lines.append(f"0.0 {lx:.8f} xlo xhi")
    lines.append(f"0.0 {ly:.8f} ylo yhi")
    lines.append(f"0.0 {lz:.8f} zlo zhi")
    lines.append("")
    lines.append("Masses")
    lines.append("")
    for i, s in enumerate(species):
        lines.append(f"{i + 1} {MASS.get(s, 1.0):.6f}  # {s}")
    lines.append("")
    lines.append("Atoms")
    lines.append("")
    lines.append("# id mol type q x y z")
    for i, s in enumerate(system.symbols):
        x, y, z = coords[i]
        lines.append(
            f"{i + 1} 1 {type_of[s]} {charges[i]:.6f} {x:.8f} {y:.8f} {z:.8f}"
        )
    lines.append("")
    path.write_text("\n".join(lines))
    return path


def write_ff(system: VaspSystem, plugin: str, params: str, path: Path) -> Path:
    species = []
    for s in system.symbols:
        if s not in species:
            species.append(s)
    lines = ["<AtomTypes>"]
    for s in species:
        lines.append(f"  {s}  {s}  {MASS.get(s, 1.0):.3f}  3.0  0.001  0.0")
    lines.append("</AtomTypes>")
    lines.append("")
    lines.append("<Plugins>")
    lines.append(f'  periodic   {plugin}   params="{params}"')
    lines.append("</Plugins>")
    lines.append("")
    lines.append("<NonBonded>")
    for i, a in enumerate(species):
        for b in species[i:]:
            lines.append(f"  {a}  {b}  Plugin periodic")
    lines.append("</NonBonded>")
    lines.append("")
    path.write_text("\n".join(lines))
    return path


def write_params(system: VaspSystem, charges: Sequence[float], path: Path,
                 accuracy: float = 1.0e-6) -> Path:
    lines = ["# periodic_ff parameters - generated by vasp2adobmd",
             "format 2", f"natoms {system.natoms}",
             f"accuracy {accuracy:g}", "method pppm", "order 4", "slab 0"]
    for i, q in enumerate(charges):
        lines.append(f"charge {i} {q:.6f}")
    lines.append("# add buck/lj lines from TTAM or Pedone when available")
    path.write_text("\n".join(lines) + "\n")
    return path


def write_conf(system: VaspSystem, data: Path, ff: Path, path: Path,
               material: str = "TiO2", nsteps: int = 0) -> Path:
    lines = [
        "# ADOBMD input generated by vasp2adobmd",
        f"system_file     = {data}",
        f"forcefield_file = {ff}",
        "potential       = CUSTOM",
        f"material        = {material}",
        "ensemble        = NVE",
        "temperature     = 300.0",
        "dt_fs           = 1.0",
        f"nsteps          = {nsteps}",
        "nsave           = 1",
        f"output_prefix   = {path.parent / 'run'}",
        f"natoms          = {system.natoms}",
        "",
    ]
    path.write_text("\n".join(lines))
    return path


def write_reference(system: VaspSystem, path: Path) -> Path:
    ref = {
        "comment": system.comment,
        "natoms": system.natoms,
        "lattice_angstrom": system.lattice.tolist(),
        "symbols": system.symbols,
        "energy_eV": system.energy_ev,
        "energy_kcal_per_mol": None if system.energy_ev is None
        else system.energy_ev * EV_TO_KCAL,
        "forces_eV_per_angstrom": None if system.forces_ev_a is None
        else system.forces_ev_a.tolist(),
        "stress_kbar": None if system.stress_kbar is None
        else system.stress_kbar.tolist(),
    }
    path.write_text(json.dumps(ref, indent=2) + "\n")
    return path


def cmd_info(args: argparse.Namespace) -> int:
    system = read_poscar(args.poscar)
    energy, forces, stress = read_outcar(args.outcar) if args.outcar else (None, None, None)
    system.energy_ev = energy
    print(f"comment : {system.comment}")
    print(f"natoms  : {system.natoms}")
    print(f"species : {', '.join(dict.fromkeys(system.symbols))}")
    print(f"cell    : {system.box_lengths()} A")
    try:
        system.check_orthorhombic()
        print("cell    : orthorhombic (ADOBMD-compatible)")
    except VaspError as exc:
        print(f"cell    : {exc}")
    if energy is not None:
        print(f"energy  : {energy:.8f} eV = {energy * EV_TO_KCAL:.6f} kcal/mol")
    if forces is not None:
        print(f"forces  : max |F| = {np.max(np.abs(forces)):.6f} eV/A")
    if stress is not None:
        print(f"stress  : {stress}")
    return 0


def cmd_convert(args: argparse.Namespace) -> int:
    system = read_poscar(args.poscar)
    energy, forces, stress = read_outcar(args.outcar) if args.outcar else (None, None, None)
    system.energy_ev, system.forces_ev_a, system.stress_kbar = energy, forces, stress
    system.check_orthorhombic()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    if args.charges_file:
        charges = read_bader_charges(args.charges_file)
        if len(charges) != system.natoms:
            raise VaspError(f"Bader file has {len(charges)} charges, "
                            f"system has {system.natoms} atoms")
    elif args.charges:
        charges = parse_charges(args.charges, system.symbols)
    elif args.params:
        charges = read_params_charges(args.params, system.symbols)
    else:
        charges = parse_charges(None, system.symbols)

    data = write_data(system, charges, out / "system.data")
    if args.params:
        params = out / "periodic.params"
        if Path(args.params).resolve() != params.resolve():
            shutil.copyfile(args.params, params)
    else:
        params = write_params(system, charges, out / "periodic.params",
                              accuracy=args.accuracy)
    ff = write_ff(system, args.plugin, str(params.resolve()), out / "system.ff")
    conf = write_conf(system, data.resolve(), ff.resolve(), out / "system.conf",
                      material=args.material, nsteps=args.nsteps)
    ref = write_reference(system, out / "reference.json")

    print(f"natoms  : {system.natoms}")
    print(f"cell    : {system.box_lengths()} A")
    uniq = {}
    for s, q in zip(system.symbols, charges):
        uniq[s] = q
    print("charges : " + ", ".join(f"{s}={q:g}" for s, q in uniq.items()))
    for p in (data, params, ff, conf, ref):
        print(f"wrote   : {p}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command", required=True)

    info = sub.add_parser("info", help="inspect POSCAR/OUTCAR")
    info.add_argument("poscar")
    info.add_argument("outcar", nargs="?")
    info.set_defaults(func=cmd_info)

    conv = sub.add_parser("convert", help="write ADOBMD input files")
    conv.add_argument("poscar")
    conv.add_argument("outcar", nargs="?")
    conv.add_argument("--out", required=True)
    conv.add_argument("--charges", default=None,
                      help='e.g. "Ti:2.196,O:-1.098" (default: formal charges)')
    conv.add_argument("--charges-file", default=None,
                      help="Bader ACF.dat (charge column, atom order)")
    conv.add_argument("--plugin", default="./periodic_ff.so",
                      help="path written into the .ff <Plugins> block")
    conv.add_argument("--accuracy", type=float, default=1.0e-6)
    conv.add_argument("--params", default=None,
                      help="copy an existing periodic.params (e.g. from kim2adobmd)")
    conv.add_argument("--material", default="TiO2")
    conv.add_argument("--nsteps", type=int, default=0)
    conv.set_defaults(func=cmd_convert)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return int(args.func(args))
    except VaspError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
