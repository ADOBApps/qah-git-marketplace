"""OpenKIM -> ADOBMD periodic.params importer tab."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import (
    QSpinBox, QDoubleSpinBox, QComboBox, QMessageBox,
)

from .base import BaseImporterWidget
from . import kim2adobmd


class KimImporterWidget(BaseImporterWidget):
    def __init__(self, parent=None):
        super().__init__(
            "Extract Buckingham/Coulomb parameters from an OpenKIM model archive "
            "(.txz/.zip) or directory and write an ADOBMD periodic.params file.",
            parent,
        )
        self.archive = self.add_file(
            "archive", "OpenKIM archive",
            "OpenKIM (*.txz *.zip *.tar.gz);;All files (*)",
        )
        self.out = self.add_dir("out", "Output directory")

        self.natoms = QSpinBox()
        self.natoms.setRange(1, 1_000_000)
        self.natoms.setValue(12)
        self.add_widget("natoms", "Atoms", self.natoms)

        self.cutoff = QDoubleSpinBox()
        self.cutoff.setRange(1.0, 50.0)
        self.cutoff.setDecimals(3)
        self.cutoff.setValue(10.0)
        self.add_widget("cutoff", "Cutoff (Å)", self.cutoff)

        self.accuracy = QDoubleSpinBox()
        self.accuracy.setDecimals(10)
        self.accuracy.setRange(1e-12, 1e-1)
        self.accuracy.setValue(1e-5)
        self.accuracy.setSingleStep(1e-6)
        self.add_widget("accuracy", "PPPM accuracy", self.accuracy)

        self.method = QComboBox()
        self.method.addItems(["pppm", "ewald"])
        self.add_widget("method", "Reciprocal method", self.method)

        self.add_buttons(("Inspect", self.inspect),
                         ("Export periodic.params", self.export))

    def _archive(self):
        path = self.text("archive")
        if not path:
            QMessageBox.warning(self, "OpenKIM", "Select an OpenKIM archive first.")
            return None
        return path

    def inspect(self):
        path = self._archive()
        if path:
            self.run_cli(kim2adobmd.main, ["inspect", path])

    def export(self):
        path = self._archive()
        if not path:
            return
        out = self.text("out") or str(Path(path).with_suffix(""))
        Path(out).mkdir(parents=True, exist_ok=True)
        target = str(Path(out) / "periodic.params")
        argv = [
            "export", path,
            "--natoms", str(self.natoms.value()),
            "--out", target,
            "--cutoff", f"{self.cutoff.value():g}",
            "--accuracy", f"{self.accuracy.value():g}",
            "--method", self.method.currentText(),
        ]
        self.run_cli(kim2adobmd.main, argv)
