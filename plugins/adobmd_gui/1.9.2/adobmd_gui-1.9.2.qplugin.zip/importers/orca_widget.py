"""ORCA -> ADOBMD force-field importer tab."""
from __future__ import annotations

from PySide6.QtWidgets import (
    QComboBox, QCheckBox, QSpinBox, QDoubleSpinBox, QLineEdit, QMessageBox,
)

from .base import BaseImporterWidget
from . import orca2adobmd_cli


class OrcaImporterWidget(BaseImporterWidget):
    def __init__(self, parent=None):
        super().__init__(
            "Fit and export a molecule-specific ADOBMD force field from a "
            "finished ORCA calculation (optimized XYZ + Hessian + MBIS/CHELPG "
            "charges). Produces <stem>.ff/.data/.conf and the molff parameters.",
            parent,
        )
        self.xyz = self.add_file("xyz", "Optimized XYZ (optional)", "XYZ (*.xyz);;All files (*)")
        self.hess = self.add_file("hess", "ORCA Hessian (*.hess)", "ORCA Hessian (*.hess);;All files (*)")
        self.property = self.add_file("property", "ORCA charges (*.property.txt)",
                                      "ORCA property (*.property.txt);;All files (*)")

        self.charges = QComboBox()
        self.charges.addItems(["mbis", "chelpg"])
        self.add_widget("charges", "Charge method", self.charges)

        self.nonbonded = QCheckBox("include intramolecular nonbonded terms")
        self.add_widget("nonbonded", "", self.nonbonded)

        self.outdir = self.add_dir("outdir", "Output directory")
        self.stem = QLineEdit("molecule")
        self.add_widget("stem", "File stem", self.stem)
        self.material = QLineEdit("MOL")
        self.add_widget("material", "Material", self.material)

        self.plugin_name = QLineEdit("molff")
        self.add_widget("plugin_name", "Plugin name", self.plugin_name)
        self.plugin_path = QLineEdit("./molff.so")
        self.add_widget("plugin_path", "Plugin path", self.plugin_path)

        self.nsteps = QSpinBox()
        self.nsteps.setRange(0, 10_000_000)
        self.nsteps.setValue(10000)
        self.add_widget("nsteps", "Steps in .conf", self.nsteps)
        self.temperature = QDoubleSpinBox()
        self.temperature.setRange(0.0, 5000.0)
        self.temperature.setValue(300.0)
        self.add_widget("temperature", "Temperature (K)", self.temperature)
        self.dt = QDoubleSpinBox()
        self.dt.setRange(0.01, 10.0)
        self.dt.setDecimals(3)
        self.dt.setValue(1.0)
        self.add_widget("dt", "dt (fs)", self.dt)
        self.accuracy = QDoubleSpinBox()
        self.accuracy.setDecimals(10)
        self.accuracy.setRange(1e-12, 1e-1)
        self.accuracy.setValue(1e-6)
        self.add_widget("accuracy", "Ewald accuracy", self.accuracy)
        self.slab = QCheckBox("slab correction (Yeh–Berkowitz)")
        self.add_widget("slab", "", self.slab)

        self.add_buttons(("Info", self.info), ("Fit", self.fit),
                         ("Export force field", self.export))

    def _required(self):
        hess, prop = self.text("hess"), self.text("property")
        if not hess or not prop:
            QMessageBox.warning(self, "ORCA", "Select the .hess and .property.txt files.")
            return None
        return hess, prop

    def _common(self):
        argv = ["--hess", self.text("hess"), "--property", self.text("property")]
        xyz = self.text("xyz")
        if xyz:
            argv += ["--xyz", xyz]
        argv += ["--charges", self.charges.currentText()]
        if self.nonbonded.isChecked():
            argv.append("--intramolecular-nonbonded")
        return argv

    def info(self):
        if not self._required():
            return
        self.run_cli(orca2adobmd_cli.main, ["info"] + self._common())

    def fit(self):
        if not self._required():
            return
        self.run_cli(orca2adobmd_cli.main, ["fit"] + self._common() + ["--json"])

    def export(self):
        if not self._required():
            return
        outdir = self.text("outdir") or "adobmd"
        argv = ["export"] + self._common() + [
            "--outdir", outdir,
            "--stem", self.text("stem") or "molecule",
            "--material", self.text("material") or "MOL",
            "--plugin-name", self.text("plugin_name") or "molff",
            "--plugin-path", self.text("plugin_path") or "./molff.so",
            "--nsteps", str(self.nsteps.value()),
            "--temperature", f"{self.temperature.value():g}",
            "--dt-fs", f"{self.dt.value():g}",
            "--ewald-accuracy", f"{self.accuracy.value():g}",
        ]
        if self.slab.isChecked():
            argv.append("--slab-correction")
        self.run_cli(orca2adobmd_cli.main, argv)
