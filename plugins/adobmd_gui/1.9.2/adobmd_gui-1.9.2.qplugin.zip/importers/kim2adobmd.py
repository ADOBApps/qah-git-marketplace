#!/usr/bin/env python3
"""
kim2adobmd — extract pair-potential parameters from an OpenKIM model archive
and write an ADOBMD `periodic_ff` parameter file.

Supported archive contents (the KIM "Buckingham" model driver):

    <Model>.pair       s1 s2 A rho C      (A energy, rho length, C energy*length^6)
    <Model>.charges    s q                (q in units of e)
    smspec.edn         :units "real" | "metal" | "si"

Output uses the species-based tags of the periodic plugin:

    charge_z 22 2.196
    buck_z 22 8 16957.66 0.194 12.5926

so the same file serves any cell containing those species.

Examples
--------
    python3 kim2adobmd.py inspect Sim_..._000.txz
    python3 kim2adobmd.py export  Sim_..._000.txz --natoms 12 --out tio2.params

This file is part of QAH and is GPL-3.0-or-later.
"""
from __future__ import annotations

import argparse
import re
import sys
import tarfile
import tempfile
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

EV_PER_KCAL = 1.0 / 23.060548867
J_PER_EV = 1.602176634e-19
BOHR = 5.29177210903e-11

SYMBOL_Z = {
    "H": 1, "He": 2, "Li": 3, "Be": 4, "B": 5, "C": 6, "N": 7, "O": 8,
    "F": 9, "Ne": 10, "Na": 11, "Mg": 12, "Al": 13, "Si": 14, "P": 15,
    "S": 16, "Cl": 17, "Ar": 18, "K": 19, "Ca": 20, "Sc": 21, "Ti": 22,
    "V": 23, "Cr": 24, "Mn": 25, "Fe": 26, "Co": 27, "Ni": 28, "Cu": 29,
    "Zn": 30, "Ga": 31, "Ge": 32, "As": 33, "Se": 34, "Br": 35, "Kr": 36,
    "Rb": 37, "Sr": 38, "Y": 39, "Zr": 40, "Nb": 41, "Mo": 42, "Tc": 43,
    "Ru": 44, "Rh": 45, "Pd": 46, "Ag": 47, "Cd": 48, "In": 49, "Sn": 50,
}

# (energy -> eV factor, length -> Angstrom factor)
UNITS = {
    "real":  (EV_PER_KCAL, 1.0),      # kcal/mol, Angstrom
    "metal": (1.0, 1.0),              # eV, Angstrom
    "si":    (1.0 / J_PER_EV, 1.0e10) # J, m
}


class KimError(ValueError):
    pass


@dataclass
class KimModel:
    name: str
    units: str = "real"
    charges: Dict[str, float] = field(default_factory=dict)
    pairs: List[Tuple[str, str, float, float, float]] = field(default_factory=list)
    extra_files: List[str] = field(default_factory=list)


def _open_archive(path: Path) -> Tuple[Path, Optional[tempfile.TemporaryDirectory]]:
    if path.is_dir():
        return path, None
    tmp = tempfile.TemporaryDirectory()
    dest = Path(tmp.name)
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as zf:
            zf.extractall(dest)
    else:
        with tarfile.open(path) as tf:
            tf.extractall(dest)
    return dest, tmp


def _find(root: Path, suffix: str) -> Optional[Path]:
    hits = sorted(root.rglob(f"*{suffix}"))
    return hits[0] if hits else None


def _parse_units(smspec: Path) -> str:
    if not smspec.exists():
        return "real"
    text = smspec.read_text(errors="ignore")
    m = re.search(r'"units"\s+"([A-Za-z]+)"', text)
    return m.group(1).lower() if m else "real"


def _parse_charges(path: Path) -> Dict[str, float]:
    charges = {}
    for line in path.read_text().splitlines():
        line = line.split("#")[0].strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        charges[parts[0]] = float(parts[1])
    return charges


def _parse_pairs(path: Path) -> List[Tuple[str, str, float, float, float]]:
    pairs = []
    for line in path.read_text().splitlines():
        line = line.split("#")[0].strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) < 5:
            continue
        pairs.append((parts[0], parts[1], float(parts[2]), float(parts[3]), float(parts[4])))
    return pairs


def read_model(archive: str | Path) -> KimModel:
    path = Path(archive)
    root, _tmp = _open_archive(path)
    try:
        pair_file = _find(root, ".pair")
        charge_file = _find(root, ".charges")
        smspec = _find(root, "smspec.edn")
        if pair_file is None:
            raise KimError(f"{path}: no .pair file found")

        units = _parse_units(smspec) if smspec else "real"
        if units not in UNITS:
            raise KimError(f"{path}: unsupported units '{units}' (expected real/metal/si)")

        model = KimModel(name=root.name, units=units)
        if charge_file:
            model.charges = _parse_charges(charge_file)
        model.pairs = _parse_pairs(pair_file)
        model.extra_files = [p.name for p in sorted(root.rglob("*")) if p.is_file()]
        return model
    finally:
        if _tmp is not None:
            _tmp.cleanup()


def _z(symbol: str) -> int:
    if symbol not in SYMBOL_Z:
        raise KimError(f"unknown element symbol '{symbol}'")
    return SYMBOL_Z[symbol]


def write_params(model: KimModel, natoms: int, out: Path,
                 cutoff: float = 10.0, accuracy: float = 1.0e-5,
                 method: str = "pppm") -> Path:
    e_fac, l_fac = UNITS[model.units]
    lines = [
        f"# ADOBMD periodic_ff parameters - extracted from OpenKIM model",
        f"# {model.name}  (units: {model.units})",
        "format 2",
        f"natoms {natoms}",
        f"accuracy {accuracy:g}",
        f"method {method}",
        "order 4",
        f"cut_nb {cutoff:g}",
        "slab 0",
    ]
    for sym, q in model.charges.items():
        lines.append(f"charge_z {_z(sym)} {q:.6f}")
    for s1, s2, a, rho, c in model.pairs:
        a_ev = a * e_fac
        rho_a = rho * l_fac
        c_ev = c * e_fac * l_fac ** 6
        lines.append(
            f"buck_z {_z(s1)} {_z(s2)} {a_ev:.6f} {rho_a:.6f} {c_ev:.6f}"
        )
    out.write_text("\n".join(lines) + "\n")
    return out


def cmd_inspect(args: argparse.Namespace) -> int:
    model = read_model(args.archive)
    print(f"model   : {model.name}")
    print(f"units   : {model.units}")
    print(f"charges : " + ", ".join(f"{s}={q:g}" for s, q in model.charges.items()))
    e_fac, l_fac = UNITS[model.units]
    print("pairs   :")
    for s1, s2, a, rho, c in model.pairs:
        print(f"  {s1}-{s2}: A={a * e_fac:.6f} eV  rho={rho * l_fac:.6f} A  "
              f"C={c * e_fac * l_fac ** 6:.6f} eV A^6")
    return 0


def cmd_export(args: argparse.Namespace) -> int:
    model = read_model(args.archive)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    write_params(model, args.natoms, out, cutoff=args.cutoff,
                 accuracy=args.accuracy, method=args.method)
    print(f"wrote {out}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command", required=True)

    info = sub.add_parser("inspect", help="print the extracted parameters")
    info.add_argument("archive")
    info.set_defaults(func=cmd_inspect)

    exp = sub.add_parser("export", help="write an ADOBMD periodic.params file")
    exp.add_argument("archive")
    exp.add_argument("--natoms", type=int, required=True)
    exp.add_argument("--out", required=True)
    exp.add_argument("--cutoff", type=float, default=10.0)
    exp.add_argument("--accuracy", type=float, default=1.0e-5)
    exp.add_argument("--method", default="pppm")
    exp.set_defaults(func=cmd_export)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return int(args.func(args))
    except KimError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
