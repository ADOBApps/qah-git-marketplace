"""Shared base widget for the ADOBMD importers (KIM / VASP / QE)."""
from __future__ import annotations

import contextlib
import io
from pathlib import Path

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QFormLayout, QHBoxLayout, QLineEdit,
    QPushButton, QFileDialog, QTextEdit, QLabel,
)


class BaseImporterWidget(QWidget):
    def __init__(self, intro: str, parent=None):
        super().__init__(parent)
        self._rows = {}
        outer = QVBoxLayout(self)
        if intro:
            lab = QLabel(intro)
            lab.setWordWrap(True)
            outer.addWidget(lab)
        self.form = QFormLayout()
        outer.addLayout(self.form)
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(160)
        self.log.setPlaceholderText("Output appears here…")
        outer.addWidget(self.log)

    # -- form helpers -----------------------------------------------------
    def add_file(self, key, label, filt, save=False):
        line = QLineEdit()
        btn = QPushButton("Browse…")
        btn.clicked.connect(lambda: self._pick(line, filt, save))
        row = QHBoxLayout()
        row.addWidget(line)
        row.addWidget(btn)
        self.form.addRow(label, row)
        self._rows[key] = line
        return line

    def add_dir(self, key, label):
        line = QLineEdit()
        btn = QPushButton("Browse…")
        btn.clicked.connect(lambda: self._pick_dir(line))
        row = QHBoxLayout()
        row.addWidget(line)
        row.addWidget(btn)
        self.form.addRow(label, row)
        self._rows[key] = line
        return line

    def add_widget(self, key, label, widget):
        self.form.addRow(label, widget)
        return widget

    def add_buttons(self, *buttons):
        row = QHBoxLayout()
        made = []
        for text, slot in buttons:
            btn = QPushButton(text)
            btn.clicked.connect(slot)
            row.addWidget(btn)
            made.append(btn)
        self.form.addRow("", row)
        return made

    def _pick(self, line, filt, save):
        start = line.text().strip() or str(Path.home())
        if save:
            path, _ = QFileDialog.getSaveFileName(self, "Select file", start, filt)
        else:
            path, _ = QFileDialog.getOpenFileName(self, "Select file", start, filt)
        if path:
            line.setText(path)

    def _pick_dir(self, line):
        start = line.text().strip() or str(Path.home())
        path = QFileDialog.getExistingDirectory(self, "Select directory", start)
        if path:
            line.setText(path)

    def text(self, key) -> str:
        return self._rows[key].text().strip()

    # -- execution --------------------------------------------------------
    def run_cli(self, func, argv):
        buf = io.StringIO()
        try:
            with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
                rc = int(func(argv))
        except SystemExit as exc:
            rc = int(exc.code or 0)
        except Exception as exc:  # keep the GUI alive
            buf.write(f"\nERROR: {exc}\n")
            rc = 1
        out = buf.getvalue().rstrip()
        if out:
            self.log.append(out)
        self.log.append(f"[exit {rc}]")
        return rc
