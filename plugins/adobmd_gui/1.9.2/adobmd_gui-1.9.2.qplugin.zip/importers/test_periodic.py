#!/usr/bin/env python3
"""NaCl Madelung and force tests for periodic_ff (ABI 2).

Checks, for both reciprocal methods:
  * energy against the NaCl Madelung constant
  * PPPM energy against the direct Ewald sum
  * analytic forces against central finite differences
"""
import ctypes
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
LIB = HERE / "periodic_ff.so"
K_E = 2.307077552e-28          # J m
MADELUNG = 1.747564594633      # NaCl
ANG = 1.0e-10


class Site(ctypes.Structure):
    _fields_ = [("z", ctypes.c_int), ("type_idx", ctypes.c_int),
                ("mass", ctypes.c_double), ("sigma", ctypes.c_double),
                ("epsilon", ctypes.c_double), ("charge", ctypes.c_double),
                ("p", ctypes.c_double * 5), ("reserved", ctypes.c_double * 4)]


class System(ctypes.Structure):
    _fields_ = [("natoms", ctypes.c_int),
                ("pos", ctypes.POINTER(ctypes.c_double)),
                ("box", ctypes.POINTER(ctypes.c_double)),
                ("sites", ctypes.POINTER(Site)),
                ("type", ctypes.POINTER(ctypes.c_int)),
                ("reserved", ctypes.c_void_p * 2),
                ("cell", ctypes.POINTER(ctypes.c_double)),
                ("mol_id", ctypes.POINTER(ctypes.c_int))]


def build():
    src = HERE / "periodic_ff.c"
    sdk = HERE.parent.parent / "sdk" / "pppm.c"
    hdr = HERE.parent.parent / "include" / "adobmd_pppm.h"
    newer = [f for f in (src, sdk, hdr) if f.stat().st_mtime > (LIB.stat().st_mtime if LIB.exists() else 0)]
    if not LIB.exists() or newer:
        subprocess.run([str(HERE / "build.sh")], check=True)


def lattice(cells=3, a=5.64):
    basis = [((0, 0, 0), 1), ((0, .5, .5), 1), ((.5, 0, .5), 1), ((.5, .5, 0), 1),
             ((.5, 0, 0), -1), ((0, .5, 0), -1), ((0, 0, .5), -1), ((.5, .5, .5), -1)]
    pos, q = [], []
    for ix in range(cells):
        for iy in range(cells):
            for iz in range(cells):
                for f, s in basis:
                    pos.append((np.array([ix, iy, iz], float) + np.array(f)) * a)
                    q.append(s)
    return np.array(pos, float), q, cells * a


class Runner:
    def __init__(self, pos, q, box):
        self.n = len(q)
        self.q = q
        self.box = box
        n = self.n
        self.p = (ctypes.c_double * (3 * n))(*[v * ANG for xyz in pos for v in xyz])
        self.b = (ctypes.c_double * 3)(*[box * ANG] * 3)
        self.sites = (Site * n)()
        self.types = (ctypes.c_int * n)()
        for i in range(n):
            self.sites[i].type_idx = i + 1
            self.sites[i].charge = q[i]
            self.types[i] = i + 1
        self.c = (ctypes.c_double * 9)(box * ANG, 0, 0, 0, box * ANG, 0, 0, 0, box * ANG)
        self.sys = System(n, self.p, self.b, self.sites, self.types,
                          (ctypes.c_void_p * 2)(), self.c, None)

    def set_pos(self, pos):
        for a in range(self.n):
            for k in range(3):
                self.p[3 * a + k] = pos[a, k] * ANG

    def get_pos(self):
        return np.array([[self.p[3 * a + k] / ANG for k in range(3)]
                         for a in range(self.n)])

    def init(self, lib, method):
        pf = self.tmp / f"nacl_{method}.params"
        pf.write_text(f"format 2\nnatoms {self.n}\naccuracy 1.0e-7\n"
                      f"method {method}\nslab 0\n" +
                      "".join(f"charge {i} {v}\n" for i, v in enumerate(self.q)))
        st = lib.adobmd_plugin_init(ctypes.byref(self.sys), str(pf).encode())
        assert st == 0, f"init({method}) -> {st}"

    def energy(self, lib):
        return lib.adobmd_plugin_energy(ctypes.byref(self.sys))

    def forces(self, lib):
        f = (ctypes.c_double * (3 * self.n))()
        lib.adobmd_plugin_forces(ctypes.byref(self.sys), f)
        return np.array([f[3 * a + k] for a in range(self.n) for k in range(3)]).reshape(self.n, 3)


def main():
    build()
    lib = ctypes.CDLL(str(LIB))
    lib.adobmd_plugin_init.argtypes = [ctypes.POINTER(System), ctypes.c_char_p]
    lib.adobmd_plugin_init.restype = ctypes.c_int
    lib.adobmd_plugin_energy.argtypes = [ctypes.POINTER(System)]
    lib.adobmd_plugin_energy.restype = ctypes.c_double
    lib.adobmd_plugin_forces.argtypes = [ctypes.POINTER(System),
                                         ctypes.POINTER(ctypes.c_double)]

    pos, q, box = lattice()
    n = len(q)
    r0 = 0.5 * 5.64 * ANG
    expected = -0.5 * n * MADELUNG * K_E / r0

    with tempfile.TemporaryDirectory() as tmp:
        run = Runner(pos, q, box)
        run.tmp = Path(tmp)

        energies = {}
        for method in ("ewald", "pppm"):
            run.init(lib, method)
            run.set_pos(pos)
            e = run.energy(lib)
            energies[method] = e
            rel = abs(e - expected) / abs(expected)
            print(f"[{method:5s}] E={e:.6e} J  Madelung rel.err={rel:.2e}")
            assert rel < 2e-3, (method, rel)

        rel = abs(energies["pppm"] - energies["ewald"]) / abs(energies["ewald"])
        print(f"PPPM vs direct Ewald: rel={rel:.2e}")
        assert rel < 1e-3, rel

        # forces on a distorted cell (the ideal lattice has zero force)
        distorted = pos.copy()
        distorted[0] += np.array([0.07, -0.04, 0.05])
        distorted[1] += np.array([-0.03, 0.06, -0.02])

        run.init(lib, "ewald")
        run.set_pos(distorted)
        f_ewald = run.forces(lib)
        # finite-difference check for the reference
        h = 1e-4  # Angstrom
        pp = distorted.copy(); pm = distorted.copy()
        pp[0, 0] += h; pm[0, 0] -= h
        run.set_pos(pp); ep = run.energy(lib)
        run.set_pos(pm); em = run.energy(lib)
        run.set_pos(distorted)
        fd = -(ep - em) / (2 * h * ANG)
        err = abs(f_ewald[0, 0] - fd)
        print(f"[ewald] Fx analytic={f_ewald[0,0]:.6e}  FD={fd:.6e}  |d|={err:.2e}")
        assert err < 1e-10 + 1e-3 * abs(fd)

        run.init(lib, "pppm")
        run.set_pos(distorted)
        f_pppm = run.forces(lib)
        scale = np.max(np.abs(f_ewald))
        ferr = np.max(np.abs(f_pppm - f_ewald)) / scale
        print(f"[pppm ] max force error vs Ewald = {ferr:.2e} (relative)")
        assert ferr < 3e-3, ferr

    print("PASS periodic_ff (ewald + pppm)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
