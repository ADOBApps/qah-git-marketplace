"""
data_widget.py - NetworkX-based molecular visualizer with selectable parsers
Now with LuaJIT, Fortran, and Python parser selection
"""

import numpy as np
import matplotlib
matplotlib.use('Qt5Agg')
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
from matplotlib.figure import Figure
import networkx as nx
from matplotlib.collections import LineCollection

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QStyle,
    QLabel, QFileDialog, QGroupBox, QCheckBox, QApplication,
    QComboBox, QSpinBox, QTextEdit, QSplitter, QMessageBox,
    QRadioButton, QToolButton, QMenu, QProgressBar, QDoubleSpinBox
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont, QAction, QDesktopServices
from PySide6.QtCore import QUrl

import time
from pathlib import Path
import os
import traceback

from ..utils.data_parser import ADOBMDData, Atom, Bond

# Try to import LuaJIT parser (ULTRA FAST)
try:
    from ..utils.lua.lua_parser import get_lua_parser
    LUA_PARSER_AVAILABLE = True
    print("[Ok] LuaJIT parser available")
except ImportError as e:
    LUA_PARSER_AVAILABLE = False
    print(f"[Warning] LuaJIT parser not available: {e}")

# Try to import molecular exporter for Schlegel projections
try:
    from ..utils.molecular_exporter import get_molecular_exporter
    SCHLEGEL_AVAILABLE = True
except ImportError as e:
    SCHLEGEL_AVAILABLE = False
    print(f"[Warning] Schlegel exporter not available: {e}")

# Try to import Fortran parser (fast fallback)
try:
    from ..utils.fortran_parser import get_fortran_parser
    FORTRAN_AVAILABLE = True
except ImportError as e:
    FORTRAN_AVAILABLE = False
    print(f"[Warning] Fortran parser not available: {e}")


class SchlegelCanvas(FigureCanvas):
    """Molecular visualizer for Schlegel diagrams using NetworkX"""
    
    def __init__(self, parent=None, width=10, height=8, dpi=100):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        self.ax = self.fig.add_subplot(111)
        super().__init__(self.fig)
        self.setParent(parent)
        
        # Graph structure
        self.graph = None
        self.pos = None
        self.data = None
        self.selected_atom = None
        self.highlighted_nodes = []
        self.projection_point = [0.0, 0.0, 10.0]
        self.view_angle = 45.0
        self.parser_used = "None"
        self.parser_time = 0.0
        
        # Style
        self.fig.patch.set_facecolor('white')
        self.ax.set_facecolor('white')
        self.ax.grid(True, alpha=0.3)
        self.ax.set_aspect('equal')
        
        # Connect pick event
        self.fig.canvas.mpl_connect('pick_event', self.on_pick)
    
    def build_graph(self, data: ADOBMDData):
        """Build NetworkX graph from molecular data"""
        self.data = data
        self.graph = nx.Graph()
        
        # Add nodes (atoms) with attributes
        for atom in data.atoms:
            self.graph.add_node(
                atom.id,
                element=atom.element,
                charge=atom.charge,
                is_qm=atom.is_qm,
                x=atom.x, y=atom.y, z=atom.z,
                radius=data.ELEMENT_RADII.get(atom.element, 0.5),
                color=self._get_atom_color(atom, data)
            )
        
        # Add edges (bonds) with attributes
        for bond in data.bonds:
            if bond.atom1 in self.graph and bond.atom2 in self.graph:
                self.graph.add_edge(
                    bond.atom1, bond.atom2,
                    order=bond.order,
                    type=bond.type_id
                )
        
        return self.graph
    
    def _get_atom_color(self, atom, data):
        """Get color for atom based on attributes"""
        if atom.is_qm:
            return 'red'
        elif data.has_qm_region:
            return 'blue'
        else:
            return data.ELEMENT_COLORS.get(atom.element, 'gray')
    
    def _perspective_projection(self, point):
        """Apply perspective projection for Schlegel diagram"""
        x, y, z = point
        px, py, pz = self.projection_point
        
        dz = pz - z
        if abs(dz) < 1e-10:
            return (x, y)
        
        factor = (pz - min(0, pz)) / dz
        proj_x = x * factor
        proj_y = y * factor
        
        return (proj_x, proj_y)
    
    def _cone_projection(self, point):
        """Apply cone projection for Schlegel diagram"""
        x, y, z = point
        px, py, pz = self.projection_point
        angle_rad = self.view_angle * np.pi / 180.0
        
        r = np.sqrt(x*x + y*y)
        if r < 1e-10:
            return (0.0, 0.0)
        
        dz = pz - z
        factor = np.tan(angle_rad) * dz / r
        proj_x = x * factor
        proj_y = y * factor
        
        return (proj_x, proj_y)
    
    def update_schlegel_positions(self, projection_type='perspective'):
        """Update positions using Schlegel projection"""
        if not self.graph:
            return
        
        self.pos = {}
        for node, attr in self.graph.nodes(data=True):
            point = (attr['x'], attr['y'], attr['z'])
            
            if projection_type == 'perspective':
                self.pos[node] = self._perspective_projection(point)
            else:
                self.pos[node] = self._cone_projection(point)
    
    def plot_system(self, data: ADOBMDData, projection_type='perspective',
                   atom_size=300, color_by='region', highlight_atoms=None):
        """Plot molecular system as Schlegel diagram"""
        self.ax.clear()
        self.ax.grid(True, alpha=0.3)
        
        self.build_graph(data)
        self.update_schlegel_positions(projection_type)
        
        # Prepare node colors
        node_colors = []
        for node, attr in self.graph.nodes(data=True):
            if color_by == 'region':
                color = attr['color']
            elif color_by == 'element':
                color = data.ELEMENT_COLORS.get(attr['element'], 'gray')
            elif color_by == 'charge':
                if attr['charge'] < -0.1:
                    color = 'darkblue'
                elif attr['charge'] > 0.1:
                    color = 'darkred'
                else:
                    color = 'gray'
            else:
                color = 'gray'
            node_colors.append(color)
        
        # Calculate node sizes
        node_sizes = []
        for node, attr in self.graph.nodes(data=True):
            node_sizes.append(attr['radius'] * atom_size)
        
        # Draw nodes
        nx.draw_networkx_nodes(
            self.graph, self.pos,
            node_color=node_colors,
            node_size=node_sizes,
            alpha=0.7,
            linewidths=0.5,
            edgecolors='black',
            ax=self.ax
        )
        
        # Draw highlighted nodes
        if highlight_atoms:
            highlight_nodes = [n for n in self.graph.nodes() if n in highlight_atoms]
            if highlight_nodes:
                highlight_sizes = [node_sizes[i] * 1.2 for i, n in enumerate(self.graph.nodes()) 
                                 if n in highlight_atoms]
                nx.draw_networkx_nodes(
                    self.graph, self.pos,
                    nodelist=highlight_nodes,
                    node_color='yellow',
                    node_size=highlight_sizes,
                    alpha=1.0,
                    linewidths=2,
                    edgecolors='red',
                    ax=self.ax
                )
        
        # Draw edges
        if data.bonds and self.graph.edges():
            nx.draw_networkx_edges(
                self.graph, self.pos,
                edge_color='gray',
                width=1.0,
                alpha=0.5,
                ax=self.ax
            )
        
        self.ax.set_xlabel('Schlegel X')
        self.ax.set_ylabel('Schlegel Y')
        
        qm_info = f" - QM: {len(data.qm_indices)} atoms" if data.has_qm_region else ""
        proj_type = "Perspective" if projection_type == 'perspective' else "Cone"
        parser_info = f" [{self.parser_used}"
        if self.parser_time > 0:
            parser_info += f": {self.parser_time:.1f}ms"
        parser_info += "]"
        self.ax.set_title(f"{data.filename}{parser_info} - {proj_type} Schlegel Preview{qm_info}")
        
        self._auto_scale()
        self.fig.tight_layout()
        self.draw()
    
    def get_degree_distribution(self):
        """Get degree distribution"""
        if self.graph:
            return dict(self.graph.degree())
        return {}

    def find_cycles(self):
        """Find cycles in the graph"""
        if self.graph:
            return list(nx.cycle_basis(self.graph))
        return []
    
    def _auto_scale(self):
        """Auto-scale with padding"""
        if not self.pos:
            return
        
        x_coords = [p[0] for p in self.pos.values()]
        y_coords = [p[1] for p in self.pos.values()]
        
        if not x_coords or not y_coords:
            return
        
        x_min, x_max = min(x_coords), max(x_coords)
        y_min, y_max = min(y_coords), max(y_coords)
        
        if abs(x_max - x_min) < 1e-10:
            x_min -= 5
            x_max += 5
        if abs(y_max - y_min) < 1e-10:
            y_min -= 5
            y_max += 5
        
        x_pad = (x_max - x_min) * 0.1
        y_pad = (y_max - y_min) * 0.1
        
        self.ax.set_xlim(x_min - x_pad, x_max + x_pad)
        self.ax.set_ylim(y_min - y_pad, y_max + y_pad)
    
    def on_pick(self, event):
        """Handle atom selection"""
        if not hasattr(event, 'ind') or not self.graph:
            return
        
        node = list(self.graph.nodes())[event.ind[0]]
        self.selected_atom = node
        self.plot_system(self.data, highlight_atoms=[node])
    
    def set_projection_point(self, x, y, z):
        """Set projection point"""
        self.projection_point = [x, y, z]
        if self.data:
            self.plot_system(self.data)
    
    def set_view_angle(self, angle):
        """Set view angle"""
        self.view_angle = angle
        if self.data:
            self.plot_system(self.data)


class DataVisualizerWidget(QWidget):
    """Main widget with Schlegel diagram visualization and selectable parsers"""
    
    # Parser type constants
    PARSER_LUAJIT = "LuaJIT (JIT)"
    PARSER_FORTRAN = "Fortran"
    PARSER_PYTHON = "Python"
    
    def __init__(self, plugin_instance=None, xyz_widget=None):
        super().__init__()
        self.plugin = plugin_instance
        self.xyz_widget = xyz_widget 
        self.data = None
        self.current_file = ""
        self.last_export_dir = str(Path.home())
        
        # Initialize LuaJIT parser
        self.lua_parser = None
        if LUA_PARSER_AVAILABLE:
            try:
                self.lua_parser = get_lua_parser()
                if self.lua_parser:
                    print("[Ok] LuaJIT ultra-fast parser initialized! (JIT compiled)")
            except Exception as e:
                print(f"[Warning] LuaJIT parser init error: {e}")
                self.lua_parser = None
        
        # Initialize Fortran parser
        self.fortran_parser = None
        if FORTRAN_AVAILABLE:
            try:
                self.fortran_parser = get_fortran_parser()
                if self.fortran_parser:
                    print("[Ok] Fortran parser initialized!")
            except Exception as e:
                print(f"[Warning] Fortran parser init error: {e}")
                self.fortran_parser = None
        
        # Initialize Schlegel exporter
        self.schlegel_exporter = None
        if SCHLEGEL_AVAILABLE:
            try:
                self.schlegel_exporter = get_molecular_exporter()
                if self.schlegel_exporter:
                    print("[Ok] Fortran Schlegel exporter available!")
            except Exception as e:
                print(f"[Warning] Schlegel exporter error: {e}")
        
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # ========== PARSER SELECTION TOOLBAR ==========
        parser_toolbar = QHBoxLayout()
        
        # Label for parser selection
        parser_label = QLabel("Parser Engine:")
        parser_label.setStyleSheet("font-weight: bold;")
        parser_toolbar.addWidget(parser_label)
        
        # ComboBox for parser selection
        self.parser_combo = QComboBox()
        self.parser_combo.setMinimumWidth(180)
        self.parser_combo.setToolTip("Select which parser to use for ADOBMD files")
        
        # Add available parsers with icons and descriptions
        if self.lua_parser:
            self.parser_combo.addItem("LuaJIT (JIT) - Very Fast", self.PARSER_LUAJIT)
        if self.fortran_parser:
            self.parser_combo.addItem("Fortran - The Fastest", self.PARSER_FORTRAN)
        self.parser_combo.addItem("Python - TOO SLOW", self.PARSER_PYTHON)
        
        # Set default selection (LuaJIT if available, else Fortran, else Python)
        if self.lua_parser:
            self.parser_combo.setCurrentIndex(0)
        elif self.fortran_parser:
            self.parser_combo.setCurrentIndex(0 if self.lua_parser else 1 if self.fortran_parser else 0)
        
        parser_toolbar.addWidget(self.parser_combo)
        
        # Performance info label
        self.performance_label = QLabel("")
        self.performance_label.setStyleSheet("color: #2e7d32; font-weight: bold; padding: 5px;")
        parser_toolbar.addWidget(self.performance_label)
        
        parser_toolbar.addStretch()
        
        # Parser availability status
        availability_text = "Available: "
        if self.lua_parser:
            availability_text += "LuaJIT✓ "
        if self.fortran_parser:
            availability_text += "Fortran✓ "
        availability_text += "Python✓"
        
        availability_label = QLabel(availability_text)
        availability_label.setStyleSheet("background-color: #e0e0e0; padding: 2px 10px; border-radius: 3px;")
        parser_toolbar.addWidget(availability_label)
        
        layout.addLayout(parser_toolbar)
        
        # Connect parser selection
        self.parser_combo.currentIndexChanged.connect(self.on_parser_selected)
        
        # Update performance label
        self.update_performance_label()
        
        # ========== MAIN TOOLBAR ==========
        toolbar = QHBoxLayout()
        
        self.load_btn = QPushButton("Load File")
        self.load_btn.clicked.connect(self.load_file)
        self.load_btn.setIcon(
            QApplication.style().standardIcon(QStyle.StandardPixmap.SP_FileIcon)
        )
        toolbar.addWidget(self.load_btn)
        
        # Projection type selector
        toolbar.addWidget(QLabel("Projection:"))
        self.proj_combo = QComboBox()
        self.proj_combo.addItems(["Perspective", "Cone"])
        self.proj_combo.currentTextChanged.connect(self.update_plot)
        self.proj_combo.setFixedWidth(100)
        toolbar.addWidget(self.proj_combo)
        
        # View angle control
        toolbar.addWidget(QLabel("Angle:"))
        self.angle_spin = QDoubleSpinBox()
        self.angle_spin.setRange(10.0, 89.0)
        self.angle_spin.setValue(45.0)
        self.angle_spin.setSuffix("°")
        self.angle_spin.valueChanged.connect(self.update_angle)
        self.angle_spin.setEnabled(False)
        self.angle_spin.setFixedWidth(80)
        toolbar.addWidget(self.angle_spin)
        
        toolbar.addStretch()
        
        self.file_label = QLabel("No file loaded")
        self.file_label.setStyleSheet("color: gray; padding: 5px;")
        toolbar.addWidget(self.file_label)
        
        layout.addLayout(toolbar)
        
        # ========== EXPORT TOOLBAR ==========
        export_bar = QHBoxLayout()
        export_bar.addWidget(QLabel("Schlegel Export:"))
        
        self.export_schlegel_btn = QPushButton("Generate Schlegel Projections")
        self.export_schlegel_btn.setIcon(
            QApplication.style().standardIcon(QStyle.StandardPixmap.SP_DriveHDIcon)
        )
        self.export_schlegel_btn.clicked.connect(self.export_schlegel)
        self.export_schlegel_btn.setEnabled(False)
        export_bar.addWidget(self.export_schlegel_btn)
        
        self.open_folder_btn = QPushButton("Open Folder")
        self.open_folder_btn.setIcon(
            QApplication.style().standardIcon(QStyle.StandardPixmap.SP_DirOpenIcon)
        )
        self.open_folder_btn.clicked.connect(self.open_export_folder)
        self.open_folder_btn.setEnabled(False)
        export_bar.addWidget(self.open_folder_btn)
        
        export_bar.addStretch()
        
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.progress.setFixedWidth(150)
        export_bar.addWidget(self.progress)
        
        layout.addLayout(export_bar)
        
        # ========== MAIN SPLITTER ==========
        splitter = QSplitter(Qt.Horizontal)
        
        # Left panel - Controls
        left = QWidget()
        left_layout = QVBoxLayout(left)
        
        # Display controls
        display_group = QGroupBox("Display")
        display = QVBoxLayout()
        
        color_row = QHBoxLayout()
        color_row.addWidget(QLabel("Color by:"))
        self.color_combo = QComboBox()
        self.color_combo.addItems(["region", "element", "charge"])
        self.color_combo.currentTextChanged.connect(self.update_plot)
        color_row.addWidget(self.color_combo)
        display.addLayout(color_row)
        
        size_row = QHBoxLayout()
        size_row.addWidget(QLabel("Atom size:"))
        self.size_spin = QSpinBox()
        self.size_spin.setRange(50, 1000)
        self.size_spin.setValue(300)
        self.size_spin.valueChanged.connect(self.update_plot)
        size_row.addWidget(self.size_spin)
        display.addLayout(size_row)
        
        self.show_bonds = QCheckBox("Show Bonds")
        self.show_bonds.setChecked(True)
        self.show_bonds.toggled.connect(self.update_plot)
        display.addWidget(self.show_bonds)
        
        display_group.setLayout(display)
        left_layout.addWidget(display_group)
        
        # Projection point controls
        proj_group = QGroupBox("Projection Point (for Fortran)")
        proj_layout = QVBoxLayout()
        
        x_row = QHBoxLayout()
        x_row.addWidget(QLabel("X:"))
        self.proj_x = QDoubleSpinBox()
        self.proj_x.setRange(-100, 100)
        self.proj_x.setValue(0.0)
        self.proj_x.setSingleStep(0.5)
        self.proj_x.valueChanged.connect(self.update_projection_point)
        x_row.addWidget(self.proj_x)
        proj_layout.addLayout(x_row)
        
        y_row = QHBoxLayout()
        y_row.addWidget(QLabel("Y:"))
        self.proj_y = QDoubleSpinBox()
        self.proj_y.setRange(-100, 100)
        self.proj_y.setValue(0.0)
        self.proj_y.setSingleStep(0.5)
        self.proj_y.valueChanged.connect(self.update_projection_point)
        y_row.addWidget(self.proj_y)
        proj_layout.addLayout(y_row)
        
        z_row = QHBoxLayout()
        z_row.addWidget(QLabel("Z:"))
        self.proj_z = QDoubleSpinBox()
        self.proj_z.setRange(-100, 200)
        self.proj_z.setValue(10.0)
        self.proj_z.setSingleStep(0.5)
        self.proj_z.valueChanged.connect(self.update_projection_point)
        z_row.addWidget(self.proj_z)
        proj_layout.addLayout(z_row)
        
        proj_group.setLayout(proj_layout)
        left_layout.addWidget(proj_group)
        
        # Filter controls
        filter_group = QGroupBox("Filter")
        filter = QVBoxLayout()
        
        self.show_all = QRadioButton("Show All")
        self.show_all.setChecked(True)
        self.show_all.toggled.connect(self.filter_atoms)
        filter.addWidget(self.show_all)
        
        self.show_qm = QRadioButton("QM Only")
        self.show_qm.toggled.connect(self.filter_atoms)
        filter.addWidget(self.show_qm)
        
        self.show_mm = QRadioButton("MM Only")
        self.show_mm.toggled.connect(self.filter_atoms)
        filter.addWidget(self.show_mm)
        
        filter_group.setLayout(filter)
        left_layout.addWidget(filter_group)
        
        # Generated files info
        files_group = QGroupBox("Generated Projections")
        self.files_text = QTextEdit()
        self.files_text.setReadOnly(True)
        self.files_text.setMaximumHeight(100)
        self.files_text.setFont(QFont("Courier New", 8))
        files_group.setLayout(QVBoxLayout())
        files_group.layout().addWidget(self.files_text)
        left_layout.addWidget(files_group)
        
        # Statistics
        stats_group = QGroupBox("Statistics")
        self.stats_text = QTextEdit()
        self.stats_text.setReadOnly(True)
        self.stats_text.setMaximumHeight(150)
        self.stats_text.setFont(QFont("Courier New", 9))
        stats_group.setLayout(QVBoxLayout())
        stats_group.layout().addWidget(self.stats_text)
        left_layout.addWidget(stats_group)
        
        left_layout.addStretch()
        
        # Right panel - Canvas
        right = QWidget()
        right_layout = QVBoxLayout(right)
        self.canvas = SchlegelCanvas(self)
        self.toolbar = NavigationToolbar(self.canvas, self)
        right_layout.addWidget(self.toolbar)
        right_layout.addWidget(self.canvas)
        
        splitter.addWidget(left)
        splitter.addWidget(right)
        splitter.setSizes([400, 600])
        
        layout.addWidget(splitter)
    
    def on_parser_selected(self, index):
        """Handle parser selection change"""
        self.update_performance_label()
    
    def update_performance_label(self):
        """Update performance label based on selected parser"""
        parser_type = self.parser_combo.currentData()
        
        if parser_type == self.PARSER_LUAJIT:
            self.performance_label.setText("JIT Compiled - Very Fast")
            self.performance_label.setStyleSheet("color: #2e7d32; font-weight: bold; padding: 5px;")
        elif parser_type == self.PARSER_FORTRAN:
            self.performance_label.setText("Compiled Fortran - Maximum Speed")
            self.performance_label.setStyleSheet("color: #1976d2; font-weight: bold; padding: 5px;")
        else:
            self.performance_label.setText("Python - Too slow")
            self.performance_label.setStyleSheet("color: #f57c00; font-weight: bold; padding: 5px;")
    
    def load_file_luajit(self, file_path):
        """Load file using LuaJIT parser"""
        try:
            start_time = time.time()
            result = self.lua_parser.parse_file(file_path)
            parse_time = (time.time() - start_time) * 1000
            
            if not result:
                return False
            
            self.data = result
            self.canvas.parser_used = "LuaJIT (JIT)"
            self.canvas.parser_time = parse_time
            
            return True
            
        except Exception as e:
            print(f"[Error] LuaJIT parser error: {e}")
            traceback.print_exc()
            return False
    
    def load_file_fortran(self, file_path):
        """Load file using Fortran parser"""
        try:
            start_time = time.time()
            result = self.fortran_parser.parse_file(file_path)
            parse_time = (time.time() - start_time) * 1000
            
            if not result:
                return False
            
            # Convert to ADOBMDData
            self.data = ADOBMDData()
            self.data.filename = Path(file_path).name
            
            # Convert atoms
            self.data.atoms = []
            for a in result['atoms']:
                atom = Atom(
                    id=int(a['id']),
                    type_id=int(a['type_id']),
                    molecule=int(a['molecule']),
                    element=str(a['element']),
                    x=float(a['x']),
                    y=float(a['y']),
                    z=float(a['z']),
                    charge=float(a['charge']),
                    is_qm=bool(a['is_qm'])
                )
                self.data.atoms.append(atom)
            
            # Convert bonds
            self.data.bonds = []
            if 'bonds' in result:
                for b in result['bonds']:
                    bond = Bond(
                        id=int(b['id']),
                        type_id=int(b['type_id']),
                        atom1=int(b['atom1']),
                        atom2=int(b['atom2']),
                        order=int(b.get('order', b['type_id']))
                    )
                    self.data.bonds.append(bond)
            
            # Set box
            if result['header']['has_box']:
                self.data.has_box = True
                self.data.box_lo = result['header']['box_lo']
                self.data.box_hi = result['header']['box_hi']
            
            # Set QM indices
            self.data.qm_indices = result.get('qm_indices', [])
            self.data.has_qm_region = result.get('has_qm', False)
            
            self.data.natoms = len(self.data.atoms)
            self.data.nbonds = len(self.data.bonds)
            
            self.canvas.parser_used = "Fortran"
            self.canvas.parser_time = parse_time
            
            return True
            
        except Exception as e:
            print(f"[Error] Fortran parser error: {e}")
            traceback.print_exc()
            return False
    
    def load_file_python(self, file_path):
        """Python parser fallback"""
        try:
            from ..utils.data_parser import ADOBMDData
            
            start_time = time.time()
            self.data = ADOBMDData()
            success = self.data.load(file_path)
            parse_time = (time.time() - start_time) * 1000
            
            if success:
                self.canvas.parser_used = "Python"
                self.canvas.parser_time = parse_time
                return True
            return False
            
        except Exception as e:
            print(f"[Error] Python parser error: {e}")
            return False
    
    def load_file(self):
        """Load file with selected parser"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select ADOBMD Data File", "",
            "ADOBMD Files (*.data);;All Files (*)"
        )
        
        if not file_path:
            return
        
        self.current_file = file_path
        self.progress.setVisible(True)
        self.progress.setRange(0, 0)
        QApplication.processEvents()
        
        start = time.time()
        success = False
        parser_type = self.parser_combo.currentData()
        parse_time = 0
        
        print(f"\n{'='*60}")
        print(f"[Loading] Using parser: {parser_type}")
        print(f"[Loading] File: {file_path}")
        
        # Use selected parser
        if parser_type == self.PARSER_LUAJIT and self.lua_parser:
            success = self.load_file_luajit(file_path)
            if success:
                parse_time = self.canvas.parser_time
        
        elif parser_type == self.PARSER_FORTRAN and self.fortran_parser:
            success = self.load_file_fortran(file_path)
            if success:
                parse_time = self.canvas.parser_time
        
        else:
            success = self.load_file_python(file_path)
            if success:
                parse_time = self.canvas.parser_time
        
        total_time = (time.time() - start) * 1000

        if success:
            # After successful load, update XYZ widget
            self.update_xyz_widget()
            # Push to the real 3D viewer
            if self.xyz_widget is not None and hasattr(self.xyz_widget, "update_with_adobmd"):
                self.xyz_widget.update_with_adobmd(self.data)
        else:
            QMessageBox.critical(self, "Error", 
                                f"Failed to load file with {parser_type} parser\n\n"
                                f"File: {file_path}")
            self.progress.setVisible(False)
            return
        
        # Update file label
        time_str = f"{parse_time:.1f}ms parse + {total_time - parse_time:.1f}ms total"
        self.file_label.setText(f"{self.data.filename} ({parser_type}: {time_str})")
        
        # Enable controls
        self.export_schlegel_btn.setEnabled(True)
        
        self.update_plot()
        self.update_statistics()
        
        self.progress.setVisible(False)
        
        # Show success message
        speed_note = ""
        if parser_type == self.PARSER_LUAJIT:
            speed_note = "\n\nJIT compilation active - Very fast!"
        elif parser_type == self.PARSER_FORTRAN:
            speed_note = "\n\nFortran compiled parser - Maximum speed achieved!"
        
        QMessageBox.information(self, "Success", 
                               f"Loaded {len(self.data.atoms)} atoms, "
                               f"{len(self.data.bonds)} bonds\n\n"
                               f"Parser: {parser_type}\n"
                               f"Parse time: {parse_time:.1f} ms\n"
                               f"Total time: {total_time:.1f} ms{speed_note}")
        
        print(f"[Loading] Success! Parse time: {parse_time:.1f}ms")
        print(f"{'='*60}\n")
    
    def export_schlegel(self):
        """Generate Schlegel projection files"""
        if not self.data or not self.schlegel_exporter:
            QMessageBox.warning(self, "Warning", "Schlegel exporter not available")
            return
        
        dir_path = QFileDialog.getExistingDirectory(
            self, "Select Directory for Schlegel Projections", 
            self.last_export_dir
        )
        
        if not dir_path:
            return
        
        self.last_export_dir = dir_path
        base_name = Path(dir_path) / Path(self.current_file).stem
        
        self.progress.setVisible(True)
        self.progress.setRange(0, 0)
        QApplication.processEvents()
        
        try:
            # Prepare data
            atoms_list = []
            for atom in self.data.atoms:
                atoms_list.append({
                    'id': atom.id,
                    'type_id': atom.type_id,
                    'molecule': atom.molecule,
                    'element': atom.element,
                    'x': atom.x,
                    'y': atom.y,
                    'z': atom.z,
                    'charge': atom.charge,
                    'is_qm': atom.is_qm
                })
            
            bonds_list = []
            for bond in self.data.bonds:
                bonds_list.append({
                    'id': bond.id,
                    'type_id': bond.type_id,
                    'atom1': bond.atom1,
                    'atom2': bond.atom2,
                    'order': bond.order
                })
            
            proj_point = (self.proj_x.value(), self.proj_y.value(), self.proj_z.value())
            view_angle = self.angle_spin.value()
            
            start_time = time.time()
            success = self.schlegel_exporter.export_all(
                str(base_name),
                atoms_list,
                bonds_list,
                box=(self.data.box_hi[0] - self.data.box_lo[0],
                     self.data.box_hi[1] - self.data.box_lo[1],
                     self.data.box_hi[2] - self.data.box_lo[2]) if self.data.has_box else None,
                projection_point=proj_point,
                view_angle=view_angle
            )
            
            elapsed = (time.time() - start_time) * 1000
            
            if success:
                files = [
                    f"{base_name}.xyz", f"{base_name}.pdb", f"{base_name}.sdf",
                    f"{base_name}.mol2", f"{base_name}.cif", f"{base_name}.gro",
                    f"{base_name}_xy.txt", f"{base_name}_xz.txt", f"{base_name}_yz.txt",
                    f"{base_name}_schlegel.txt", f"{base_name}_qm_mm.txt",
                ]
                
                existing_files = [f for f in files if Path(f).exists()]
                
                self.files_text.clear()
                self.files_text.append("Fortran generated:")
                for f in existing_files[:5]:
                    self.files_text.append(f"  • {Path(f).name}")
                if len(existing_files) > 5:
                    self.files_text.append(f"  ... and {len(existing_files)-5} more")
                
                self.open_folder_btn.setEnabled(True)
                
                QMessageBox.information(
                    self, "Success",
                    f"Generated {len(existing_files)} files in {elapsed:.1f}ms\n\n"
                    f"Saved to:\n{dir_path}"
                )
            else:
                QMessageBox.critical(self, "Error", "Export failed")
                
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Export failed: {str(e)}")
            traceback.print_exc()
        
        self.progress.setVisible(False)
    
    def open_export_folder(self):
        """Open folder with exported files"""
        if hasattr(self, 'last_export_dir') and Path(self.last_export_dir).exists():
            QDesktopServices.openUrl(QUrl.fromLocalFile(self.last_export_dir))
    
    def update_plot(self):
        """Update visualization"""
        if not self.data:
            return
        
        proj_type = 'perspective' if self.proj_combo.currentText() == 'Perspective' else 'cone'
        
        atoms_to_show = []
        if self.show_all.isChecked():
            atoms_to_show = self.data.atoms
        elif self.show_qm.isChecked():
            atoms_to_show = [a for a in self.data.atoms if a.is_qm]
        elif self.show_mm.isChecked():
            atoms_to_show = [a for a in self.data.atoms if not a.is_qm]
        
        if len(atoms_to_show) != len(self.data.atoms):
            filtered = ADOBMDData()
            filtered.atoms = atoms_to_show
            filtered.bonds = self.data.bonds
            filtered.has_box = self.data.has_box
            filtered.box_lo = self.data.box_lo
            filtered.box_hi = self.data.box_hi
            filtered.filename = self.data.filename
            filtered.qm_indices = self.data.qm_indices
            filtered.has_qm_region = self.data.has_qm_region
            plot_data = filtered
        else:
            plot_data = self.data
        
        self.canvas.plot_system(
            plot_data,
            projection_type=proj_type,
            atom_size=self.size_spin.value(),
            color_by=self.color_combo.currentText()
        )
    
    def update_projection_point(self):
        """Update projection point"""
        self.canvas.set_projection_point(
            self.proj_x.value(),
            self.proj_y.value(),
            self.proj_z.value()
        )
    
    def update_angle(self):
        """Update view angle"""
        self.canvas.set_view_angle(self.angle_spin.value())
        self.angle_spin.setEnabled(self.proj_combo.currentText() == 'Cone')
    
    def filter_atoms(self):
        """Filter atoms"""
        self.update_plot()
        self.update_statistics()
    
    def update_statistics(self):
        """Update statistics display"""
        if not self.data:
            return
        
        stats = self.data.get_statistics()
        
        graph_stats = ""
        if hasattr(self.canvas, 'graph') and self.canvas.graph:
            try:
                degrees = self.canvas.get_degree_distribution()
                if degrees:
                    avg_degree = sum(degrees.values()) / len(degrees)
                    cycles = self.canvas.find_cycles()
                    
                    graph_stats = f"\nGraph Analysis:\n"
                    graph_stats += f"  Average degree: {avg_degree:.2f}\n"
                    graph_stats += f"  Cycles found: {len(cycles)}\n"
                    if cycles:
                        graph_stats += f"  Largest cycle: {len(max(cycles, key=len))} atoms\n"
            except Exception as e:
                pass
        
        parser_info = f"\nParser: {getattr(self.canvas, 'parser_used', 'Unknown')}"
        if hasattr(self.canvas, 'parser_time') and self.canvas.parser_time > 0:
            parser_info += f" ({self.canvas.parser_time:.1f}ms)"
        
        parser_used = getattr(self.canvas, 'parser_used', '')
        if "LuaJIT" in parser_used:
            parser_info += "\nJIT compiled - Very fast"
        elif "Fortran" in parser_used:
            parser_info += "\nCompiled Fortran - Maximum speed"
        
        text = f"""File: {self.data.filename}
Atoms: {stats['atoms']}
Bonds: {stats['bonds']}
QM atoms: {stats['qm_atoms']}
MM atoms: {stats['mm_atoms']}

Elements:
{chr(10).join(f'  {k}: {v}' for k, v in sorted(stats['elements'].items()))}
{graph_stats}"""
        
        if stats['box']:
            box = stats['box']
            text += f"\nBox: {box[0]:.1f} x {box[1]:.1f} x {box[2]:.1f} Å³"
        
        text += parser_info
        
        self.stats_text.setText(text)

    def cleanup(self):
        """Clean up resources"""
        if self.lua_parser:
            try:
                self.lua_parser.cleanup()
            except:
                pass
            self.lua_parser = None
        
        if self.fortran_parser and hasattr(self.fortran_parser, 'cleanup'):
            try:
                self.fortran_parser.cleanup()
            except:
                pass
            self.fortran_parser = None

    def clear(self):
        """Clear current data"""
        self.data = None
        self.current_file = ""
        self.file_label.setText("No file loaded")
        self.export_schlegel_btn.setEnabled(False)
        self.open_folder_btn.setEnabled(False)
        self.stats_text.clear()
        self.files_text.clear()
        self.canvas.ax.clear()
        self.canvas.ax.set_title("No data loaded")
        self.canvas.draw()

    def update_xyz_widget(self):
        """Update the XYZ widget with current data"""
        if hasattr(self, 'xyz_widget') and self.xyz_widget and self.data:
            # Get positions and elements
            positions = np.array([[atom.x, atom.y, atom.z] for atom in self.data.atoms])
            elements = [atom.element for atom in self.data.atoms]
            
            # Update XYZ widget
            self.xyz_widget.update_with_elements(positions, elements)
            
            # Optionally set coloring mode to element
            self.xyz_widget.set_coloring_mode('element')