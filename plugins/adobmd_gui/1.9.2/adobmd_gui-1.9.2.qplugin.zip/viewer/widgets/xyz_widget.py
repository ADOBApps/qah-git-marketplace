"""
xyz_widget.py - Combined widget with 2D Static, 3D Interactive, and Schlegel Diagram tabs
ADDED: Color by Element feature and connection methods for data_widget
"""

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QTabWidget,
    QLabel, QPushButton, QComboBox, QFileDialog,
    QMessageBox, QScrollArea, QSizePolicy, QCheckBox,
    QSlider, QColorDialog, QButtonGroup, QRadioButton,
    QStackedWidget
)
from PySide6.QtGui import QGuiApplication, QColor, QPixmap, QPainter
from PySide6.QtCore import Qt, Signal
import numpy as np
import os
import logging
import matplotlib
matplotlib.use('Qt5Agg')
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# Import Schlegel tab - will be created after predictor is set
from .schlegel_tab import SchlegelTab

# near top
from .adobmd_gl_widget import Adobmd3DWidget

# Try to import predictor directly
try:
    from ..models.fullerene_predictor import EnhancedFullerenePredictor
    PREDICTOR_AVAILABLE = True
except ImportError:
    PREDICTOR_AVAILABLE = False
    logging.error("[Warning] Predictor not available in xyz_widget")


class XYZVisualizationWidget(QWidget):
    """Main visualization widget with multiple tabs"""
    
    # Signals for structure changes
    structure_changed = Signal(object)
    nano_onion_changed = Signal(object, object)
    
    # Element colors (RGB) for visualization - ADDED from adapted version
    ELEMENT_COLORS = {
        # --- User Defined Core Elements ---
        'H': (1.0, 1.0, 1.0),    # White
        'C': (0.2, 0.2, 0.2),    # Dark gray
        'N': (0.0, 0.0, 1.0),    # Blue
        'O': (1.0, 0.0, 0.0),    # Red
        'F': (0.0, 1.0, 0.0),    # Green
        'Na': (0.0, 0.5, 0.5),   # Teal
        'Mg': (0.5, 0.5, 0.0),   # Olive
        'Al': (0.6, 0.6, 0.6),   # Silver
        'Si': (0.5, 0.5, 0.5),   # Gray
        'P': (1.0, 0.5, 0.0),    # Orange
        'S': (1.0, 1.0, 0.0),    # Yellow
        'Cl': (0.0, 1.0, 0.0),   # Green
        'K': (0.5, 0.0, 0.5),    # Purple
        'Ca': (0.3, 0.3, 0.8),   # Light blue
        'Fe': (1.0, 0.5, 0.0),   # Orange-brown
        'Co': (0.5, 0.5, 0.8),   # Light blue-gray
        'Ni': (0.6, 0.6, 0.6),   # Silver
        'Cu': (0.8, 0.5, 0.2),   # Copper
        'Zn': (0.6, 0.6, 0.8),   # Light blue-gray
        'Au': (1.0, 0.8, 0.0),   # Gold
        'Ag': (0.8, 0.8, 0.8),   # Silver
        'Ti': (0.6, 0.6, 0.8),   # Light blue-gray
        'Sn': (0.5, 0.5, 0.5),   # Gray
        'Pb': (0.3, 0.3, 0.5),   # Dark gray-blue

        # --- Noble Gases ---
        'He': (0.85, 1.0, 1.0),  # Light cyan
        'Ne': (0.70, 0.89, 0.96),# Cyan
        'Ar': (0.50, 0.82, 0.89),# Pale blue
        'Kr': (0.36, 0.72, 0.82),# Medium blue
        'Xe': (0.26, 0.62, 0.69),# Dark cyan-blue
        'Rn': (0.26, 0.51, 0.59),# Dark teal
        
        # --- Alkali & Alkaline Earth Metals ---
        'Li': (0.80, 0.50, 1.0), # Purple
        'Be': (0.76, 1.0, 0.0),  # Yellow-green
        'Rb': (0.44, 0.18, 0.69),# Deep violet
        'Sr': (0.0, 1.0, 0.0),   # Bright green
        'Cs': (0.34, 0.09, 0.56),# Dark violet
        'Ba': (0.0, 0.79, 0.0),  # Green
        
        # --- Other Nonmetals & Metalloids ---
        'B': (1.0, 0.71, 0.71),  # Pinkish
        'As': (0.74, 0.50, 0.89),# Mauve
        'Se': (1.0, 0.63, 0.0),  # Deep orange
        'Br': (0.65, 0.16, 0.16),# Dark red/brown
        'Te': (0.83, 0.48, 0.0), # Burnt orange
        'I': (0.58, 0.0, 0.58),  # Dark magenta
        
        # --- Post-Transition Metals ---
        'Ga': (0.76, 0.56, 0.56),# Rosy brown
        'In': (0.65, 0.46, 0.45),# Mauve-gray
        'Tl': (0.65, 0.33, 0.30),# Rust
        'Bi': (0.62, 0.31, 0.71),# Purple-gray
        
        # --- Remaining Transition Metals ---
        'Sc': (0.90, 0.90, 0.90),# Off-white
        'V':  (0.65, 0.65, 0.67),# Gray
        'Cr': (0.54, 0.60, 0.78),# Blue-gray
        'Mn': (0.61, 0.48, 0.78),# Purple-gray
        'Y':  (0.58, 1.0, 1.0),  # Cyan
        'Zr': (0.58, 0.88, 0.88),# Pale cyan
        'Nb': (0.45, 0.76, 0.79),# Teal
        'Mo': (0.33, 0.71, 0.71),# Dark cyan
        'Tc': (0.23, 0.62, 0.62),# Darker cyan
        'Ru': (0.14, 0.56, 0.56),# Teal-gray
        'Rh': (0.04, 0.49, 0.55),# Dark teal
        'Pd': (0.0, 0.41, 0.52), # Very dark teal
        'Cd': (1.0, 0.85, 0.56), # Pale gold
        'Hf': (0.30, 0.76, 1.0), # Bright sky blue
        'Ta': (0.30, 0.65, 1.0), # Cornflower blue
        'W':  (0.13, 0.58, 0.84),# Steel blue
        'Re': (0.15, 0.49, 0.67),# Slate blue
        'Os': (0.15, 0.40, 0.59),# Dark slate blue
        'Ir': (0.09, 0.33, 0.53),# Very dark slate
        'Pt': (0.82, 0.82, 0.88),# Pale silver
        'Hg': (0.71, 0.71, 0.82),# Lilac gray
        
        # --- Lanthanides ---
        'La': (0.44, 0.83, 1.0), # Pale sky blue
        'Ce': (1.0, 1.0, 0.78),  # Pale yellow
        'Pr': (0.85, 1.0, 0.78), # Pale yellow-green
        'Nd': (0.78, 1.0, 0.78), # Pale green
        'Sm': (0.56, 1.0, 0.78), # Mint green
        'Eu': (0.38, 1.0, 0.78), # Bright mint
        'Gd': (0.27, 1.0, 0.78), # Spring green
        'Tb': (0.19, 1.0, 0.78), # Medium spring green
        'Dy': (0.12, 1.0, 0.78), # Jade
        'Ho': (0.0, 1.0, 0.61),  # Emerald
        'Er': (0.0, 0.90, 0.46), # Sea green
        'Tm': (0.0, 0.83, 0.32), # Forest green
        'Yb': (0.0, 0.75, 0.22), # Dark forest green
        'Lu': (0.0, 0.67, 0.14), # Very dark green
    }
    
    def __init__(self):
        super().__init__()
        self.predictor = None

        # Initialize predictor - either use passed one or create new one
        if PREDICTOR_AVAILABLE:
            try:
                self.predictor = EnhancedFullerenePredictor()
                logging.info("[OK] Predictor loaded directly in xyz_widget")
            except Exception as e:
                logging.info(f"[Warning] Failed to load predictor: {e}")
                self.predictor = None
        else:
            self.predictor = None
        
        # Data storage
        self.current_positions = None
        self.current_shell_info = None
        self.current_L = None
        self.is_nano_onion = False
        self.loaded_from_file = False
        self.loaded_file_info = None
        self.current_pixmap = None
        
        # Store element list for coloring
        self.elements_list = []
        
        # Coloring mode for 3D Interactive
        self.coloring_mode = 'single'  # 'single', 'element', 'shell'
        
        # Display settings for interactive 3D mode
        self.atom_size = 50
        self.show_bonds = True
        self.bond_threshold = 1.8
        self.atom_color = 'orange'
        self.background_color = '#f0f0f0'
        self.bond_color = 'gray'
        self.bond_alpha = 0.3
        self.shell_colors = ['red', 'blue', 'green', 'purple', 'orange', 'brown']
        self.view_mode = '2d_static'  # default to original 2D
        
        # Initialize UI first (without schlegel_tab)
        self.init_ui()

        # ADOBMD 3D
        self.adobmd_3d_widget = Adobmd3DWidget(self)
        self.tab_widget.insertTab(0, self.adobmd_3d_widget, "ADOBMD 3D")
        
        # Create Schlegel tab after UI is set up and predictor is ready
        self.schlegel_tab = SchlegelTab(self.predictor, self)
        self.tab_widget.addTab(self.schlegel_tab, "Schlegel Diagram")
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Top controls area
        top_controls = self.create_top_controls()
        layout.addWidget(top_controls)
        
        # Create tab widget for different visualization types
        self.tab_widget = QTabWidget()
        
        # Tab 1: 2D/3D Visualizations
        self.viz_tab = self.create_viz_tab()
        self.tab_widget.addTab(self.viz_tab, "3D Visualization")
        
        # Note: Schlegel tab will be added after __init__
        
        layout.addWidget(self.tab_widget)
        
        self.setLayout(layout)
    
    def create_top_controls(self):
        """Create the top control panel with file operations and common controls"""
        top_widget = QWidget()
        top_layout = QHBoxLayout(top_widget)
        
        # File operations group
        file_group = QGroupBox("File Operations")
        file_layout = QHBoxLayout()
        
        self.load_btn = QPushButton("Load XYZ File")
        self.load_btn.clicked.connect(self.load_xyz_file)
        file_layout.addWidget(self.load_btn)
        
        self.clear_btn = QPushButton("Clear Loaded")
        self.clear_btn.clicked.connect(self.clear_loaded_structure)
        self.clear_btn.setEnabled(False)
        file_layout.addWidget(self.clear_btn)
        
        file_layout.addStretch()
        
        self.file_info_label = QLabel("No file loaded")
        file_layout.addWidget(self.file_info_label)
        
        file_group.setLayout(file_layout)
        
        # Common controls
        controls_group = QGroupBox("Common Controls")
        controls_layout = QHBoxLayout()
        
        controls_layout.addWidget(QLabel("Structure:"))
        self.structure_info = QLabel("No structure loaded")
        controls_layout.addWidget(self.structure_info)
        
        controls_layout.addStretch()
        
        controls_group.setLayout(controls_layout)
        
        # Add to top layout
        top_layout.addWidget(file_group)
        top_layout.addWidget(controls_group)
        
        return top_widget
    
    def create_viz_tab(self):
        """Create the 3D visualization tab"""
        tab = QWidget()
        layout = QHBoxLayout(tab)
        
        # Screen-based sizing
        screen = QGuiApplication.primaryScreen()
        screen_geometry = screen.availableSize()
        left_panel_width = screen_geometry.width() * 0.25
        
        # Left control panel
        left_panel = QWidget()
        left_panel.setMaximumWidth(left_panel_width)
        
        # Create scroll area for left panel
        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        left_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        left_scroll.setMaximumWidth(left_panel_width)
        left_scroll.setMinimumWidth(250)
        
        # Create content widget for scroll area
        left_content = QWidget()
        left_layout = QVBoxLayout(left_content)
        left_layout.setSpacing(10)
        left_layout.setContentsMargins(10, 10, 10, 10)
        
        # View mode selection
        view_group = QGroupBox("Visualization Mode")
        view_layout = QVBoxLayout()
        
        # Radio buttons for mode selection
        mode_selection_layout = QHBoxLayout()
        self.view_2d_static_radio = QRadioButton("3D Static")
        self.view_3d_interactive_radio = QRadioButton("3D Interactive")
        self.view_2d_static_radio.setChecked(True)
        
        self.view_button_group = QButtonGroup()
        self.view_button_group.addButton(self.view_2d_static_radio)
        self.view_button_group.addButton(self.view_3d_interactive_radio)
        self.view_button_group.buttonClicked.connect(self.toggle_view_mode)
        
        mode_selection_layout.addWidget(self.view_2d_static_radio)
        mode_selection_layout.addWidget(self.view_3d_interactive_radio)
        mode_selection_layout.addStretch()
        view_layout.addLayout(mode_selection_layout)
        
        # Performance hint
        self.performance_hint = QLabel("")
        self.performance_hint.setStyleSheet("color: #666; font-size: 10px;")
        view_layout.addWidget(self.performance_hint)
        
        view_group.setLayout(view_layout)
        
        # Interactive 3D controls (only enabled in interactive mode)
        self.interactive_controls_group = QGroupBox("Interactive 3D Controls")
        interactive_layout = QVBoxLayout()
        
        # Coloring mode selection - ADDED
        coloring_layout = QHBoxLayout()
        coloring_layout.addWidget(QLabel("Color by:"))
        self.coloring_mode_combo = QComboBox()
        self.coloring_mode_combo.addItems(["Single Color", "Element", "Shell"])
        self.coloring_mode_combo.setCurrentIndex(0)
        self.coloring_mode_combo.currentIndexChanged.connect(self.on_coloring_mode_changed)
        coloring_layout.addWidget(self.coloring_mode_combo)
        coloring_layout.addStretch()
        interactive_layout.addLayout(coloring_layout)
        
        # Bond threshold control
        threshold_layout = QHBoxLayout()
        threshold_layout.addWidget(QLabel("Bond Threshold (Å):"))
        self.threshold_slider = QSlider(Qt.Horizontal)
        self.threshold_slider.setRange(10, 30)
        self.threshold_slider.setValue(18)
        self.threshold_slider.setTickInterval(2)
        self.threshold_slider.valueChanged.connect(self.update_bond_threshold)
        threshold_layout.addWidget(self.threshold_slider)
        self.threshold_label = QLabel("1.80")
        threshold_layout.addWidget(self.threshold_label)
        interactive_layout.addLayout(threshold_layout)
        
        # Atom size control
        size_layout = QHBoxLayout()
        size_layout.addWidget(QLabel("Atom Size:"))
        self.size_slider = QSlider(Qt.Horizontal)
        self.size_slider.setRange(10, 200)
        self.size_slider.setValue(50)
        self.size_slider.setTickInterval(10)
        self.size_slider.valueChanged.connect(self.update_atom_size)
        size_layout.addWidget(self.size_slider)
        self.size_label = QLabel("50")
        size_layout.addWidget(self.size_label)
        interactive_layout.addLayout(size_layout)
        
        # Show bonds checkbox
        self.bonds_checkbox = QCheckBox("Show Bonds")
        self.bonds_checkbox.setChecked(True)
        self.bonds_checkbox.stateChanged.connect(self.toggle_bonds)
        interactive_layout.addWidget(self.bonds_checkbox)
        
        # Color selection (only for single color mode)
        color_layout = QHBoxLayout()
        color_layout.addWidget(QLabel("Atom Color:"))
        self.color_btn = QPushButton("Choose Color")
        self.color_btn.clicked.connect(self.choose_atom_color)
        color_layout.addWidget(self.color_btn)
        interactive_layout.addLayout(color_layout)
        
        # Background color
        bg_color_layout = QHBoxLayout()
        bg_color_layout.addWidget(QLabel("Background:"))
        self.bg_color_btn = QPushButton("Choose Color")
        self.bg_color_btn.clicked.connect(self.choose_background_color)
        bg_color_layout.addWidget(self.bg_color_btn)
        interactive_layout.addLayout(bg_color_layout)
        
        # Shell coloring for nano-onions
        self.shell_color_checkbox = QCheckBox("Color by shell (nano-onions)")
        self.shell_color_checkbox.setChecked(True)
        self.shell_color_checkbox.stateChanged.connect(self.update_visualization)
        interactive_layout.addWidget(self.shell_color_checkbox)
        
        self.interactive_controls_group.setLayout(interactive_layout)
        self.interactive_controls_group.setEnabled(False)
        
        # Size controls (common for all modes)
        controls_group = QGroupBox("View Controls")
        controls_layout = QHBoxLayout()
        
        controls_layout.addWidget(QLabel("Size:"))
        self.size_combo = QComboBox()
        self.size_combo.addItems(["600x450", "800x600", "1000x750", "1200x900"])
        self.size_combo.setCurrentIndex(0)
        self.size_combo.currentTextChanged.connect(self.update_visualization)
        controls_layout.addWidget(self.size_combo)
        
        self.update_btn = QPushButton("Update")
        self.update_btn.clicked.connect(self.update_visualization)
        self.update_btn.setEnabled(False)
        controls_layout.addWidget(self.update_btn)
        
        controls_layout.addStretch()
        
        controls_group.setLayout(controls_layout)
        
        # Analysis group
        analysis_group = QGroupBox("Structural Analysis")
        analysis_layout = QVBoxLayout()
        
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setMinimumHeight(150)
        
        self.analysis_text = QLabel("No analysis available")
        self.analysis_text.setWordWrap(True)
        self.analysis_text.setStyleSheet("padding: 10px; background-color: #f8f9fa;")
        self.analysis_text.setAlignment(Qt.AlignmentFlag.AlignTop)
        
        scroll_area.setWidget(self.analysis_text)
        analysis_layout.addWidget(scroll_area)
        analysis_group.setLayout(analysis_layout)
        
        # Add all to left panel
        left_layout.addWidget(view_group)
        left_layout.addWidget(self.interactive_controls_group)
        left_layout.addWidget(controls_group)
        left_layout.addWidget(analysis_group)
        left_layout.addStretch()
        
        # Set the content widget for scroll area
        left_scroll.setWidget(left_content)
        
        # Create a container for the scroll area
        left_container = QWidget()
        left_container_layout = QVBoxLayout(left_container)
        left_container_layout.setContentsMargins(0, 0, 0, 0)
        left_container_layout.addWidget(left_scroll)
        left_container.setMaximumWidth(left_panel_width)
        left_container.setMinimumWidth(250)
        
        # Right panel with stacked widget for different visualization types
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        
        # Create stacked widget to hold all visualization types
        self.stacked_widget = QStackedWidget()
        
        # Widget 1: 2D Static visualization (QLabel with pixmap)
        self.static_2d_widget = QWidget()
        static_2d_layout = QVBoxLayout(self.static_2d_widget)
        
        self.scroll_area_2d = QScrollArea()
        self.scroll_area_2d.setWidgetResizable(True)
        self.scroll_area_2d.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroll_area_2d.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroll_area_2d.setMinimumSize(400, 300)
        
        self.vis_container_2d = QWidget()
        self.vis_container_layout_2d = QVBoxLayout(self.vis_container_2d)
        
        self.visualization_label_2d = QLabel()
        self.visualization_label_2d.setAlignment(Qt.AlignCenter)
        self.visualization_label_2d.setText("No structure to visualize\n\nLoad an XYZ file or generate a structure")
        self.visualization_label_2d.setStyleSheet("border: 1px solid gray; background-color: white; color: #666; padding: 20px;")
        self.visualization_label_2d.setWordWrap(True)
        self.visualization_label_2d.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        
        self.vis_container_layout_2d.addWidget(self.visualization_label_2d)
        self.scroll_area_2d.setWidget(self.vis_container_2d)
        
        static_2d_layout.addWidget(self.scroll_area_2d)
        
        # Widget 2: Interactive 3D visualization (matplotlib)
        self.interactive_3d_widget = QWidget()
        interactive_3d_layout = QVBoxLayout(self.interactive_3d_widget)

        self.figure = Figure(figsize=(10, 8), dpi=100)
        self.figure.patch.set_facecolor(self.background_color)
        self.canvas = FigureCanvas(self.figure)
        self.canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        
        self.toolbar = NavigationToolbar(self.canvas, self)
        
        interactive_3d_layout.addWidget(self.toolbar)
        interactive_3d_layout.addWidget(self.canvas)
        
        self.ax = self.figure.add_subplot(111, projection='3d')
        self.ax.set_facecolor(self.background_color)
        
        # Add all widgets to stacked widget
        self.stacked_widget.addWidget(self.static_2d_widget)
        self.stacked_widget.addWidget(self.interactive_3d_widget)
        
        right_layout.addWidget(self.stacked_widget)
        
        # Add both panels to layout
        layout.addWidget(left_container)
        layout.addWidget(right_panel, 1)
        
        return tab
    
    def on_coloring_mode_changed(self, index):
        """Handle coloring mode change"""
        mode_text = self.coloring_mode_combo.currentText()
        if mode_text == "Single Color":
            self.coloring_mode = 'single'
        elif mode_text == "Element":
            self.coloring_mode = 'element'
        elif mode_text == "Shell":
            self.coloring_mode = 'shell'
        
        # Update visualization
        if self.view_mode == '3d_interactive' and self.current_positions is not None:
            self.plot_interactive_3d()
    
    def get_element_color(self, element):
        """Get RGB color for an element"""
        return self.ELEMENT_COLORS.get(element, (0.7, 0.7, 0.7))  # Default gray
    
    def toggle_view_mode(self):
        """Toggle between visualization modes"""
        if self.view_2d_static_radio.isChecked():
            self.view_mode = '2d_static'
            self.stacked_widget.setCurrentIndex(0)
            self.interactive_controls_group.setEnabled(False)
            self.performance_hint.setText("2D Static - Fast rendering")
        else:
            self.view_mode = '3d_interactive'
            self.stacked_widget.setCurrentIndex(1)
            self.interactive_controls_group.setEnabled(True)
            
            if self.current_positions is not None:
                n_atoms = len(self.current_positions)
                if n_atoms > 1000:
                    self.performance_hint.setText("Large structure - may be slow")
                else:
                    self.performance_hint.setText("3D Interactive - Mouse controls available")
            else:
                self.performance_hint.setText("3D Interactive - Mouse controls available")
        
        self.update_visualization()
    
    def find_bonds(self, positions, threshold=None):
        """Find bonds between atoms based on distance"""
        if threshold is None:
            threshold = self.bond_threshold
            
        n_atoms = len(positions)
        bonds = []
        
        for i in range(n_atoms):
            for j in range(i + 1, n_atoms):
                dist = np.linalg.norm(positions[i] - positions[j])
                if dist < threshold:
                    bonds.append((i, j, dist))
        
        return bonds
    
    def get_colors_for_atoms(self, positions):
        """Get colors for atoms based on current coloring mode"""
        n_atoms = len(positions)
        colors = []
        
        if self.coloring_mode == 'element' and self.elements_list:
            # Element-based coloring
            for i in range(n_atoms):
                if i < len(self.elements_list):
                    elem = self.elements_list[i]
                    colors.append(self.get_element_color(elem))
                else:
                    colors.append((0.7, 0.7, 0.7))
        
        elif self.coloring_mode == 'shell' and self.is_nano_onion and self.current_shell_info:
            # Shell-based coloring
            for i, shell in enumerate(self.current_shell_info):
                n_shell_atoms = shell['n_atoms']
                color = self.shell_colors[i % len(self.shell_colors)]
                colors.extend([color] * n_shell_atoms)
        
        else:
            # Single color mode
            colors = self.atom_color
        
        return colors
    
    def plot_interactive_3d(self):
        """Plot the current structure in interactive 3D"""
        if self.current_positions is None:
            self.ax.clear()
            self.ax.text(0.5, 0.5, 0.5, "No structure loaded", ha='center', va='center')
            self.ax.set_title("No structure loaded")
            self.canvas.draw()
            return
        
        self.ax.clear()
        positions = self.current_positions
        colors = self.get_colors_for_atoms(positions)
        
        # Plot atoms
        self.ax.scatter(
            positions[:, 0], positions[:, 1], positions[:, 2],
            c=colors, s=self.atom_size, alpha=0.8,
            edgecolors='black', linewidth=0.5
        )
        
        # Plot bonds if enabled
        if self.show_bonds:
            bonds = self.find_bonds(positions, self.bond_threshold)
            for i, j, _ in bonds:
                self.ax.plot(
                    [positions[i, 0], positions[j, 0]],
                    [positions[i, 1], positions[j, 1]],
                    [positions[i, 2], positions[j, 2]],
                    color=self.bond_color, alpha=self.bond_alpha, linewidth=1
                )
        
        # Set labels and title
        self.ax.set_xlabel('X (Å)')
        self.ax.set_ylabel('Y (Å)')
        self.ax.set_zlabel('Z (Å)')
        
        # Set title based on coloring mode and structure
        coloring_mode_name = self.coloring_mode_combo.currentText()
        title = f"3D Interactive - {coloring_mode_name} Coloring"
        
        if self.loaded_from_file and self.loaded_file_info:
            filename = os.path.basename(self.loaded_file_info['file_path'])
            title += f"\n{filename} | {len(positions)} atoms"
        elif self.is_nano_onion and self.current_shell_info:
            shell_str = " → ".join([f"C_{60*s['L']**2}" for s in self.current_shell_info])
            title += f"\nNano-Onion: {shell_str} | Total: {len(positions)} atoms"
        elif self.elements_list and self.coloring_mode == 'element':
            unique_elements = sorted(set(self.elements_list))
            title += f"\nElements: {', '.join(unique_elements)} | {len(positions)} atoms"
        else:
            title += f"\n{len(positions)} atoms"
        
        self.ax.set_title(title)
        
        # Set axis limits
        max_range = np.max(positions) - np.min(positions)
        mid = np.mean(positions, axis=0)
        self.ax.set_xlim(mid[0] - max_range/2, mid[0] + max_range/2)
        self.ax.set_ylim(mid[1] - max_range/2, mid[1] + max_range/2)
        self.ax.set_zlim(mid[2] - max_range/2, mid[2] + max_range/2)
        
        # Set colors
        self.ax.set_facecolor(self.background_color)
        self.figure.patch.set_facecolor(self.background_color)
        
        self.canvas.draw()
    
    def update_visualization(self):
        """Update visualization based on current mode"""
        if self.current_positions is None:
            return
        
        try:
            size_str = self.size_combo.currentText()
            width, height = map(int, size_str.split('x'))
            
            if self.view_mode == '2d_static':
                # Use 2D visualization
                if self.loaded_from_file and self.loaded_file_info:
                    pixmap = self.predictor.create_structure_plot(
                        self.current_positions, 
                        L=self.loaded_file_info['L'],
                        size=(width, height)
                    )
                elif self.is_nano_onion and self.current_shell_info is not None:
                    pixmap = self.predictor.create_structure_plot(
                        self.current_positions, 
                        shell_info=self.current_shell_info,
                        size=(width, height)
                    )
                else:
                    pixmap = self.predictor.create_structure_plot(
                        self.current_positions, 
                        L=self.current_L,
                        size=(width, height)
                    )
                
                self.visualization_label_2d.setPixmap(pixmap)
                self.visualization_label_2d.setStyleSheet("border: 1px solid gray; background-color: white;")
                self.visualization_label_2d.setMinimumSize(width, height)
            else:
                self.plot_interactive_3d()
                
        except Exception as e:
            error_msg = f"Visualization error: {str(e)}"
            if self.view_mode == '2d_static':
                self.visualization_label_2d.setText(error_msg)
            else:
                self.ax.clear()
                self.ax.text(0.5, 0.5, 0.5, error_msg, ha='center', va='center')
                self.canvas.draw()
            
            QMessageBox.warning(self, "Visualization Error", error_msg)
    
    def update_bond_threshold(self):
        """Update bond threshold from slider"""
        self.bond_threshold = self.threshold_slider.value() / 10.0
        self.threshold_label.setText(f"{self.bond_threshold:.2f}")
        if self.view_mode == '3d_interactive' and self.current_positions is not None and self.show_bonds:
            self.plot_interactive_3d()
    
    def update_atom_size(self):
        """Update atom size from slider"""
        self.atom_size = self.size_slider.value()
        self.size_label.setText(str(self.atom_size))
        if self.view_mode == '3d_interactive' and self.current_positions is not None:
            self.plot_interactive_3d()
    
    def toggle_bonds(self):
        """Toggle bond visibility"""
        self.show_bonds = self.bonds_checkbox.isChecked()
        if self.view_mode == '3d_interactive' and self.current_positions is not None:
            self.plot_interactive_3d()
    
    def choose_atom_color(self):
        """Open color dialog for atom color"""
        color = QColorDialog.getColor()
        if color.isValid():
            self.atom_color = color.name()
            if self.view_mode == '3d_interactive' and self.current_positions is not None:
                self.plot_interactive_3d()
    
    def choose_background_color(self):
        """Open color dialog for background color"""
        color = QColorDialog.getColor()
        if color.isValid():
            self.background_color = color.name()
            if self.view_mode == '3d_interactive' and self.current_positions is not None:
                self.ax.set_facecolor(self.background_color)
                self.figure.patch.set_facecolor(self.background_color)
                self.canvas.draw()
    
    def load_xyz_file(self):
        """Load XYZ file and visualize it"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Load XYZ File", "", "XYZ Files (*.xyz)")
        
        if file_path:
            try:
                if self.predictor is not None:
                    positions, comment, n_atoms = self.predictor.load_xyz_file(file_path)
                    L = self.predictor.estimate_L_from_atoms(n_atoms)
                    # Also extract elements from XYZ file
                    elements = self._extract_elements_from_xyz(file_path)
                else:
                    # Simple parsing when predictor not available
                    positions, n_atoms, elements = self._parse_xyz_with_elements(file_path)
                    L = int(np.sqrt(n_atoms / 60)) if n_atoms > 0 else 1
                    comment = ""
                
                self.current_positions = positions
                self.elements_list = elements
                self.current_L = L
                self.current_shell_info = None
                self.is_nano_onion = False
                self.loaded_from_file = True
                self.loaded_file_info = {
                    'file_path': file_path,
                    'comment': comment,
                    'n_atoms': n_atoms,
                    'L': L
                }
                
                filename = os.path.basename(file_path)
                self.file_info_label.setText(f"Loaded: {filename}")
                self.structure_info.setText(f"Loaded: {filename} ({n_atoms} atoms)")
                self.clear_btn.setEnabled(True)
                self.update_btn.setEnabled(True)
                
                # Update performance hint
                if n_atoms > 1000 and self.view_mode == '3d_interactive':
                    self.performance_hint.setText("Large structure - may be slow")
                
                # Update visualization in current tab
                self.update_visualization()
                self.update_analysis()
                
                # Update Schlegel tab
                self.schlegel_tab.update_structure(positions)
                
                # Emit signal
                self.structure_changed.emit({
                    'positions': positions,
                    'L': L,
                    'file_info': self.loaded_file_info,
                    'is_nano_onion': False,
                    'loaded_from_file': True,
                    'elements': elements
                })
                
                QMessageBox.information(self, "Success", 
                                       f"Successfully loaded {n_atoms} atoms from {filename}")
                
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Error loading file: {str(e)}")
    
    def _extract_elements_from_xyz(self, file_path):
        """Extract element symbols from XYZ file"""
        elements = []
        with open(file_path, 'r') as f:
            lines = f.readlines()
        
        n_atoms = int(lines[0].strip())
        for i in range(2, 2 + n_atoms):
            parts = lines[i].split()
            if len(parts) >= 1:
                elements.append(parts[0])
        
        return elements
    
    def _parse_xyz_with_elements(self, file_path):
        """Parse XYZ file with element information"""
        with open(file_path, 'r') as f:
            lines = f.readlines()
        
        n_atoms = int(lines[0].strip())
        positions = []
        elements = []
        
        for i in range(2, 2 + n_atoms):
            parts = lines[i].split()
            if len(parts) >= 4:
                elements.append(parts[0])
                x, y, z = float(parts[1]), float(parts[2]), float(parts[3])
                positions.append([x, y, z])
        
        return np.array(positions), n_atoms, elements
    
    def clear_loaded_structure(self):
        """Clear the currently loaded structure"""
        self.current_positions = None
        self.current_shell_info = None
        self.current_L = None
        self.is_nano_onion = False
        self.loaded_from_file = False
        self.loaded_file_info = None
        self.elements_list = []
        
        # Clear all visualizations
        self.visualization_label_2d.setText("No structure to visualize\n\nLoad an XYZ file or generate a structure")
        self.ax.clear()
        self.ax.set_title("No structure loaded")
        self.canvas.draw()
        
        # Update UI
        self.file_info_label.setText("No file loaded")
        self.structure_info.setText("No structure loaded")
        self.clear_btn.setEnabled(False)
        self.update_btn.setEnabled(False)
        self.analysis_text.setText("No analysis available")
        self.performance_hint.setText("")
        
        # Clear Schlegel tab
        if hasattr(self, 'schlegel_tab'):
            self.schlegel_tab.clear_structure()
    
    def update_structure(self, positions, L):
        """Update with predicted structure"""
        self.current_positions = positions
        self.current_L = L
        self.current_shell_info = None
        self.is_nano_onion = False
        self.loaded_from_file = False
        self.loaded_file_info = None
        # For predicted structures, set all elements to Carbon by default
        self.elements_list = ['C'] * len(positions)
        
        self.file_info_label.setText("Generated structure")
        self.structure_info.setText(f"Single Fullerene: C_{60*L**2}")
        self.clear_btn.setEnabled(True)
        self.update_btn.setEnabled(True)
        
        n_atoms = len(positions)
        if n_atoms > 1000 and self.view_mode == '3d_interactive':
            self.performance_hint.setText("Large structure - may be slow")
        else:
            self.performance_hint.setText("")
        
        self.update_visualization()
        self.update_analysis()
        
        if hasattr(self, 'schlegel_tab'):
            self.schlegel_tab.update_structure(positions)
        
        self.structure_changed.emit({
            'positions': positions,
            'L': L,
            'is_nano_onion': False,
            'loaded_from_file': False,
            'elements': self.elements_list
        })
    
    def update_nano_onion(self, positions, shell_info):
        """Update with nano-onion structure"""
        self.current_positions = positions
        self.current_shell_info = shell_info
        self.is_nano_onion = True
        self.current_L = None
        self.loaded_from_file = False
        self.loaded_file_info = None
        # For nano-onions, set all elements to Carbon by default
        self.elements_list = ['C'] * len(positions)
        
        shell_str = " → ".join([f"C_{60*s['L']**2}" for s in shell_info])
        self.file_info_label.setText("Generated nano-onion")
        self.structure_info.setText(f"Nano-Onion: {shell_str}")
        self.clear_btn.setEnabled(True)
        self.update_btn.setEnabled(True)
        
        n_atoms = len(positions)
        if n_atoms > 1000 and self.view_mode == '3d_interactive':
            self.performance_hint.setText("Large nano-onion - may be slow")
        elif n_atoms > 500 and self.view_mode == '3d_interactive':
            self.performance_hint.setText("Medium nano-onion - may be slow")
        else:
            self.performance_hint.setText("")
        
        self.update_visualization()
        self.update_analysis()
        
        if hasattr(self, 'schlegel_tab'):
            self.schlegel_tab.update_structure(positions, shell_info)
        
        self.nano_onion_changed.emit(positions, shell_info)
    
    def update_analysis(self):
        """Update structural analysis information"""
        if self.current_positions is None:
            self.analysis_text.setText("No analysis available")
            return
        
        try:
            analysis_text = f"""
            <div style="font-family: Arial, sans-serif; line-height: 1.4;">
            <h3 style="margin: 0 0 10px 0;">Structural Analysis</h3>
            <table style="width: 100%; border-collapse: collapse;">
                <tr><td style="padding: 4px; border-bottom: 1px solid #eee;"><b>Atoms:</b></td>
                <td style="padding: 4px; border-bottom: 1px solid #eee;">{len(self.current_positions)}</td>
            </table>
            """
            
            if self.elements_list and self.coloring_mode == 'element':
                unique_elements = sorted(set(self.elements_list))
                element_counts = {elem: self.elements_list.count(elem) for elem in unique_elements}
                analysis_text += f"""
                <tr><td style="padding: 4px; border-bottom: 1px solid #eee;"><b>Elements:</b></td>
                <td style="padding: 4px; border-bottom: 1px solid #eee;">{', '.join([f"{k}({v})" for k, v in element_counts.items()])}</td>
                </tr>
                """
            
            if self.is_nano_onion and self.current_shell_info:
                analysis_text += f"""
                <tr><td style="padding: 4px; border-bottom: 1px solid #eee;"><b>Shells:</b></td>
                <td style="padding: 4px; border-bottom: 1px solid #eee;">{len(self.current_shell_info)}</td>
                </tr>
                """
            
            analysis_text += """
            </table>
            </div>
            """
            
            self.analysis_text.setText(analysis_text)
            
        except Exception as e:
            self.analysis_text.setText(f"Analysis error: {str(e)}")
    
    def get_current_structure_info(self):
        """Get information about the current structure"""
        if self.current_positions is None:
            return None
        
        info = {
            'positions': self.current_positions,
            'n_atoms': len(self.current_positions),
            'is_nano_onion': self.is_nano_onion,
            'loaded_from_file': self.loaded_from_file,
            'elements': self.elements_list
        }
        
        if self.loaded_from_file and self.loaded_file_info:
            info.update(self.loaded_file_info)
        elif self.is_nano_onion and self.current_shell_info:
            info['shell_info'] = self.current_shell_info
        else:
            info['L'] = self.current_L
        
        return info
    
    # ========== METHODS FOR DATA_WIDGET CONNECTION ==========
    
    def update_with_elements(self, positions, elements, shell_info=None):
        """
        Update widget with positions and element list from data_widget
        This method connects the data_widget to xyz_widget
        """
        self.current_positions = positions
        self.elements_list = elements
        self.current_shell_info = shell_info
        
        if shell_info:
            self.is_nano_onion = True
            self.current_L = None
        else:
            self.is_nano_onion = False
        
        # Update display
        self.update_visualization()
        self.update_analysis()
        
        # Update structure info
        if shell_info:
            shell_str = " → ".join([f"C_{60*s['L']**2}" for s in shell_info])
            self.structure_info.setText(f"Nano-Onion: {shell_str}")
        else:
            self.structure_info.setText(f"Structure: {len(positions)} atoms")
        
        self.file_info_label.setText("From ADOBMD Data")
        self.update_btn.setEnabled(True)
        self.clear_btn.setEnabled(True)
        
        # Update Schlegel tab
        if hasattr(self, 'schlegel_tab'):
            self.schlegel_tab.update_structure(positions, shell_info)
    
    def set_coloring_mode(self, mode):
        """Set the coloring mode programmatically"""
        if mode == 'single':
            self.coloring_mode_combo.setCurrentIndex(0)
        elif mode == 'element':
            self.coloring_mode_combo.setCurrentIndex(1)
        elif mode == 'shell':
            self.coloring_mode_combo.setCurrentIndex(2)
    
    def refresh_view(self):
        """Refresh the current view"""
        self.update_visualization()