# adobmd_gui/viewer/widgets/fast_renderer_adobmd.py
"""
ADOBMD-specific extension of the molecular_assembly fast renderer.

Adds:
  - Per-atom colors (element OR QM/MM OR custom palette)
  - Authoritative bonds coming from the ADOBMD `Bonds` section
  - Unit-cell wireframe drawn in the same QGraphicsScene
  - Representation switcher (ball_stick / sticks / vdw)
  - Supercell expansion (nx, ny, nz)

The rendering pipeline, camera, and picking are inherited unchanged
from fast_renderer.py so it feels like the vasp_poscar_editor 3D view.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Sequence, Tuple

import numpy as np
from PySide6.QtCore import Qt, QPointF, QRectF
from PySide6.QtGui import (
    QColor, QPainter, QPainterPath, QPen, QBrush, QFont,
)
from PySide6.QtWidgets import (
    QGraphicsItem, QGraphicsScene, QGraphicsView,
)

# Import the originals — do NOT copy them, keep a single source of truth.
from ...molecular_assembly.fast_renderer import (
    Camera, BondedMoleculeItem, FastMolecularView,
    ELEMENT_QCOLORS, DEFAULT_COLOR, VDW_RADII, COVALENT_RADII,
    MAX_BOND_LENGTH,
)

# Representative atomic radii (Å) for the "ball-and-stick" preset.
# 40% of VdW radius — the classic PyMOL "ball and stick" look.
BALL_STICK_SCALE = 0.40


def _canonical_element(symbol: str) -> str:
    """
    Convert an ADOBMD-stored element string (often upper-case, e.g.
    'FE', 'CL', 'PT') to the capitalized form used by
    molecular_assembly.fast_renderer's tables ('Fe', 'Cl', 'Pt').
    """
    if not symbol:
        return ""
    s = symbol.strip()
    if len(s) == 1:
        return s.upper()
    return s[0].upper() + s[1:].lower()


@dataclass
class AtomView:
    """Per-atom display state pushed into the renderer."""
    index: int
    element: str
    x: float
    y: float
    z: float
    is_qm: bool = False
    charge: float = 0.0
    color: Optional[QColor] = None   # explicit override; else use element


@dataclass
class BondView:
    i: int
    j: int
    order: int = 1


@dataclass
class BoxView:
    """Wireframe for the simulation cell."""
    lo: np.ndarray = field(default_factory=lambda: np.zeros(3))
    hi: np.ndarray = field(default_factory=lambda: np.zeros(3))
    visible: bool = True


# =============================================================================
#  BondedMoleculeItem subclass with ADOBMD semantics
# =============================================================================
class AdobmdMoleculeItem(BondedMoleculeItem):
    """
    Same rendering core as BondedMoleculeItem, but:
      * accepts a list[AtomView] so per-atom colors/charges/QM flags travel
        with the atoms,
      * trusts caller-supplied bonds instead of computing them,
      * exposes `set_representation()` for ball_stick / sticks / vdw.
    """

    def __init__(self, camera: Camera = None, parent=None):
        super().__init__(camera=camera, parent=parent)
        self._atom_views: List[AtomView] = []
        self._user_bonds: Optional[List[Tuple[int, int]]] = None
        self._representation = "ball_stick"     # or "sticks", "vdw"
        self._qm_color = QColor(255, 80, 80)    # QM = red-ish
        self._mm_color = QColor(80, 140, 255)   # MM = blue-ish
        self._color_mode = "element"            # "element" | "qm_mm" | "custom"

    # ------------------------------------------------------------------
    # Public ADOBMD API
    # ------------------------------------------------------------------
    def set_atoms(self, atom_views: Sequence[AtomView]) -> None:  # type: ignore[override]
        if not atom_views:
            self.prepareGeometryChange()
            self._atom_views = []
            self._positions_3d = np.zeros((0, 3))
            self._elements = []
            self._colors = []
            self._radii = np.zeros(0)
            self._bonds = []
            self._bonds_dirty = False
            self.update()
            return

        positions = np.array(
            [[a.x, a.y, a.z] for a in atom_views], dtype=np.float64
        )
        elements = [a.element for a in atom_views]

        self.prepareGeometryChange()
        self._atom_views = list(atom_views)
        self._positions_3d = positions
        self._elements = elements

        # colour list is derived from mode + atom view
        self._colors = [self._color_for(a) for a in self._atom_views]

        # radius depends on the representation
        self._rebuild_radii()
        self._bonds = []
        self._bonds_dirty = True
        self._reproject()

    def set_bonds(self, bonds: Sequence[Tuple[int, int]]) -> None:
        """Set the authoritative bond list (0-based atom indices)."""
        self._user_bonds = [(int(i), int(j)) for i, j in bonds]
        self._bonds = list(self._user_bonds)
        self._bonds_dirty = False
        self.update()

    def set_color_mode(self, mode: str) -> None:
        """'element' | 'qm_mm' | 'custom'"""
        self._color_mode = mode
        self._colors = [self._color_for(a) for a in self._atom_views]
        # Force a repaint that survives any QGraphicsView caching.
        self.prepareGeometryChange()
        self.update()

    def set_representation(self, rep: str) -> None:
        """'ball_stick' | 'sticks' | 'vdw'"""
        self._representation = rep
        self._rebuild_radii()
        self.prepareGeometryChange()
        self.update()

    def set_custom_palette(self, qm_color: QColor, mm_color: QColor) -> None:
        """Override the QM / MM colours used when color_mode == 'qm_mm'."""
        self._qm_color = QColor(qm_color)
        self._mm_color = QColor(mm_color)
        if self._color_mode == "qm_mm":
            self._colors = [self._color_for(a) for a in self._atom_views]
            self.prepareGeometryChange()
            self.update()

    # ------------------------------------------------------------------
    # Overrides
    # ------------------------------------------------------------------
    def _rebuild_radii(self) -> None:
        rep = self._representation
        radii = []
        for a in self._atom_views:
            elem_key = _canonical_element(a.element)
            base = VDW_RADII.get(elem_key, 1.5)
            if rep == "ball_stick":
                radii.append(base * BALL_STICK_SCALE * self.atom_scale)
            elif rep == "sticks":
                radii.append(base * 0.15 * self.atom_scale)
            else:                       # vdw
                radii.append(base * self.atom_scale)
        self._radii = np.array(radii, dtype=np.float64)

    def set_atom_scale(self, scale: float) -> None:
        self.atom_scale = float(scale)
        self._rebuild_radii()
        self.bond_width = max(0.04, self.atom_scale * 0.75)
        self.prepareGeometryChange()
        self.update()

    def _compute_bonds(self) -> None:
        # If the caller gave us authoritative bonds, never re-derive them.
        if self._user_bonds is not None:
            self._bonds = list(self._user_bonds)
            self._bonds_dirty = False
            return
        super()._compute_bonds()

    # ------------------------------------------------------------------
    # Colour resolution
    # ------------------------------------------------------------------
    def _color_for(self, a: AtomView) -> QColor:
        if self._color_mode == "custom" and a.color is not None:
            return a.color
        if self._color_mode == "qm_mm":
            return self._qm_color if a.is_qm else self._mm_color
        elem_key = _canonical_element(a.element)
        return ELEMENT_QCOLORS.get(elem_key, DEFAULT_COLOR)


# =============================================================================
#  Cell wireframe
# =============================================================================
class CellBoxItem(QGraphicsItem):
    """
    Unit-cell parallelepiped drawn as 12 line segments in the same
    scene as the molecule. Camera is shared so it projects identically.
    """

    def __init__(self, camera: Camera, parent=None):
        super().__init__(parent)
        self._camera = camera
        self._corners_3d = np.zeros((8, 3))
        self._corners_2d = np.zeros((8, 2))
        self._visible = True
        # A 1-px cosmetic solid pen — visible on every DPI, no dash math.
        self._pen = QPen(QColor(120, 120, 200, 220))
        self._pen.setWidthF(1.0)
        self._pen.setStyle(Qt.SolidLine)
        self._pen.setCosmetic(True)

        # The 12 edges of a parallelepiped, as index pairs into the 8 corners.
        # Corner order: (0,0,0),(1,0,0),(1,1,0),(0,1,0),(0,0,1),(1,0,1),
        #               (1,1,1),(0,1,1)
        self._edges = [
            (0, 1), (1, 2), (2, 3), (3, 0),       # bottom
            (4, 5), (5, 6), (6, 7), (7, 4),       # top
            (0, 4), (1, 5), (2, 6), (3, 7),       # verticals
        ]

    def set_box(self, lo: np.ndarray, hi: np.ndarray) -> None:
        lo = np.asarray(lo, dtype=np.float64)
        hi = np.asarray(hi, dtype=np.float64)
        a, b, c = hi - lo
        origin = lo
        self._corners_3d = np.array([
            origin,
            origin + np.array([a, 0, 0]),
            origin + np.array([a, b, 0]),
            origin + np.array([0, b, 0]),
            origin + np.array([0, 0, c]),
            origin + np.array([a, 0, c]),
            origin + np.array([a, b, c]),
            origin + np.array([0, b, c]),
        ])
        self.prepareGeometryChange()
        self._reproject()
        self.update()

    def set_visible(self, v: bool) -> None:
        self._visible = bool(v)
        scene = self.scene()
        if scene is not None:
            scene.update()
        else:
            self.update()

    def _reproject(self) -> None:
        if self._camera is None:
            self._corners_2d = self._corners_3d[:, :2]
            return
        self._corners_2d = self._camera.project(self._corners_3d)
        self.prepareGeometryChange()
        self.update()

    # QGraphicsItem protocol
    def boundingRect(self) -> QRectF:
        xy = self._corners_2d
        x, y = xy[:, 0], xy[:, 1]
        pad = 1.0
        return QRectF(
            float(x.min()) - pad, float(y.min()) - pad,
            float(x.max() - x.min()) + 2 * pad,
            float(y.max() - y.min()) + 2 * pad,
        )

    def paint(self, painter: QPainter, option, widget=None):
        if not self._visible:
            return
        painter.setPen(self._pen)
        path = QPainterPath()
        for i, j in self._edges:
            path.moveTo(
                float(self._corners_2d[i, 0]), float(self._corners_2d[i, 1])
            )
            path.lineTo(
                float(self._corners_2d[j, 0]), float(self._corners_2d[j, 1])
            )
        painter.drawPath(path)


# =============================================================================
#  Camera helpers
# =============================================================================
def fit_camera_to(camera: Camera, positions: np.ndarray,
                  view_widget: FastMolecularView) -> None:
    """
    Auto-fit: reset rotation, compute a zoom such that the bounding box
    of `positions` fits within the widget viewport with ~10% margin.
    """
    if len(positions) == 0:
        return
    camera.set_rotation(0, 0, 0)
    camera.pan_x = 0.0
    camera.pan_y = 0.0
    camera.zoom = 1.0
    camera._dirty = True

    R = camera.get_matrix()
    rotated = positions @ R.T
    xy = rotated[:, :2]
    span_x = float(xy[:, 0].max() - xy[:, 0].min()) or 1.0
    span_y = float(xy[:, 1].max() - xy[:, 1].min()) or 1.0

    vp = view_widget.viewport()
    w = max(vp.width(), 200)
    h = max(vp.height(), 200)
    zoom = min(w / span_x, h / span_y) * 0.85
    camera.zoom = zoom

    # Re-centre the projected mass centre at (0, 0)
    cx = float(xy[:, 0].mean())
    cy = float(xy[:, 1].mean())
    camera.pan_x = -cx * zoom
    camera.pan_y = -cy * zoom


# =============================================================================
#  View (subclass of FastMolecularView; adds box item + convenience)
# =============================================================================
class AdobmdView(FastMolecularView):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.cell_box = CellBoxItem(self.camera)
        self.scene_.addItem(self.cell_box)
        self._molecule_item: Optional[AdobmdMoleculeItem] = None

    def set_molecule(self, item: AdobmdMoleculeItem) -> None:
        if self._molecule_item is not None:
            self.remove_molecule(self._molecule_item)
        self._molecule_item = item
        self.add_molecule(item)

    def _reproject_all(self):        # type: ignore[override]
        super()._reproject_all()
        self.cell_box._reproject()

    def fit_view(self) -> None:
        if self._molecule_item is not None:
            fit_camera_to(self.camera, self._molecule_item.positions_3d, self)
            self._reproject_all()
            self.camera_changed.emit()

    def set_box_visible(self, v: bool) -> None:
        self.cell_box.set_visible(v)

    def set_box(self, lo, hi) -> None:
        self.cell_box.set_box(lo, hi)
        self.scene_.update()