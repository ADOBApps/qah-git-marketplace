"""
about_schlegel.py - Information panel for Schlegel diagrams
Reference: https://doi.org/10.1016/j.cplett.2006.02.100
"""

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
    QGroupBox, QScrollArea, QFrame
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap, QColor, QPainter, QPolygon
from PySide6.QtCore import QPoint


class AboutSchlegelWidget(QWidget):
    """Information widget about Schlegel diagrams"""
    
    def __init__(self):
        super().__init__()
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Title
        title = QLabel("About Schlegel Diagrams")
        title.setStyleSheet("font-size: 16px; font-weight: bold; margin: 10px;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        # Reference
        ref_label = QLabel(
            "Reference: Schlegel diagrams for fullerenes and carbon nano-onions.\n"
            "DOI: 10.1016/j.cplett.2006.02.100"
        )
        ref_label.setStyleSheet("color: #666; font-size: 10px; padding: 5px;")
        ref_label.setOpenExternalLinks(True)
        ref_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(ref_label)
        
        # Description
        desc_group = QGroupBox("What is a Schlegel diagram?")
        desc_layout = QVBoxLayout()
        desc_text = QLabel(
            "A Schlegel diagram is a 2D projection of a 3D polyhedral graph. "
            "For fullerenes, it provides a planar representation where:\n\n"
            "• Atoms are projected onto a plane\n"
            "• The outer ring represents the boundary of the projection\n"
            "• All edges are shown without crossings\n"
            "• Ring centers (pentagons and hexagons) are marked\n\n"
            "This visualization helps analyze the connectivity and topology "
            "of fullerene structures."
        )
        desc_text.setWordWrap(True)
        desc_layout.addWidget(desc_text)
        desc_group.setLayout(desc_layout)
        layout.addWidget(desc_group)
        
        # Methods explanation
        methods_group = QGroupBox("Available Methods")
        methods_layout = QVBoxLayout()
        
        methods_text = QLabel(
            "<b>1. Perspective Projection:</b> Projects the 3D structure onto a plane "
            "using a focal point above the molecule. Best for visualizing depth.\n\n"
            "<b>2. Cone Projection:</b> Projects onto a cone surface before flattening. "
            "Provides different distortion properties.\n\n"
            "<b>3. Tutte Embedding:</b> Graph-theoretic method placing outer ring on a circle "
            "and solving for interior positions using barycentric coordinates.\n\n"
            "<b>4. Tutte with Scaling:</b> Same as Tutte but with radial scaling to "
            "improve spacing.\n\n"
            "<b>5. Spring Embedding:</b> Treats bonds as springs to find energy minimum.\n\n"
            "<b>6. Spring + Coulomb:</b> Adds repulsive forces between atoms.\n\n"
            "<b>7. PPG Embedding:</b> Pisanski-Plestenjak-Graovac method using distance matrix.\n\n"
            "<b>8. Kamada-Kawai:</b> Force-directed layout based on graph distances."
        )
        methods_text.setWordWrap(True)
        methods_layout.addWidget(methods_text)
        methods_group.setLayout(methods_layout)
        layout.addWidget(methods_group)
        
        # Symbol legend
        legend_group = QGroupBox("Symbol Legend")
        legend_layout = QVBoxLayout()
        
        # Create custom widget for legend with symbols
        legend_widget = QWidget()
        legend_grid = QHBoxLayout(legend_widget)
        
        # Atom symbol
        atom_box = QFrame()
        atom_box.setFrameStyle(QFrame.Box)
        atom_box.setLineWidth(1)
        atom_layout = QVBoxLayout(atom_box)
        
        atom_pixmap = QPixmap(50, 50)
        atom_pixmap.fill(Qt.white)
        painter = QPainter(atom_pixmap)
        painter.setBrush(QColor(0, 0, 255))
        painter.setPen(Qt.black)
        painter.drawEllipse(15, 15, 20, 20)
        painter.end()
        
        atom_label = QLabel()
        atom_label.setPixmap(atom_pixmap)
        atom_label.setAlignment(Qt.AlignCenter)
        atom_layout.addWidget(atom_label)
        atom_layout.addWidget(QLabel("Atom (blue circle)"))
        legend_grid.addWidget(atom_box)
        
        # Pentagon symbol
        pentagon_box = QFrame()
        pentagon_box.setFrameStyle(QFrame.Box)
        pentagon_box.setLineWidth(1)
        pentagon_layout = QVBoxLayout(pentagon_box)
        
        pentagon_pixmap = QPixmap(50, 50)
        pentagon_pixmap.fill(Qt.white)
        painter = QPainter(pentagon_pixmap)
        painter.setBrush(QColor(255, 0, 0))
        painter.setPen(Qt.black)
        
        # Create QPolygon with QPoints for pentagon (triangle shape for marker)
        polygon = QPolygon([
            QPoint(25, 10),  # top
            QPoint(40, 30),  # right
            QPoint(35, 45),  # bottom right
            QPoint(15, 45),  # bottom left
            QPoint(10, 30)   # left
        ])
        painter.drawPolygon(polygon)
        painter.end()
        
        pentagon_label = QLabel()
        pentagon_label.setPixmap(pentagon_pixmap)
        pentagon_label.setAlignment(Qt.AlignCenter)
        pentagon_layout.addWidget(pentagon_label)
        pentagon_layout.addWidget(QLabel("Pentagon (red ▲)"))
        legend_grid.addWidget(pentagon_box)
        
        # Hexagon symbol
        hexagon_box = QFrame()
        hexagon_box.setFrameStyle(QFrame.Box)
        hexagon_box.setLineWidth(1)
        hexagon_layout = QVBoxLayout(hexagon_box)
        
        hexagon_pixmap = QPixmap(50, 50)
        hexagon_pixmap.fill(Qt.white)
        painter = QPainter(hexagon_pixmap)
        painter.setBrush(QColor(0, 255, 0))
        painter.setPen(Qt.black)
        
        # Create QPolygon with QPoints for hexagon
        hexagon = QPolygon([
            QPoint(25, 10),  # top
            QPoint(40, 20),  # top right
            QPoint(40, 35),  # bottom right
            QPoint(25, 45),  # bottom
            QPoint(10, 35),  # bottom left
            QPoint(10, 20)   # top left
        ])
        painter.drawPolygon(hexagon)
        painter.end()
        
        hexagon_label = QLabel()
        hexagon_label.setPixmap(hexagon_pixmap)
        hexagon_label.setAlignment(Qt.AlignCenter)
        hexagon_layout.addWidget(hexagon_label)
        hexagon_layout.addWidget(QLabel("Hexagon (green ⬢)"))
        legend_grid.addWidget(hexagon_box)
        
        legend_layout.addWidget(legend_widget)
        legend_group.setLayout(legend_layout)
        layout.addWidget(legend_group)
        
        # Add stretch at the end
        layout.addStretch()
        
        # Put everything in a scroll area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        container = QWidget()
        container.setLayout(layout)
        scroll.setWidget(container)
        
        main_layout = QVBoxLayout(self)
        main_layout.addWidget(scroll)