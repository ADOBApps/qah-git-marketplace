# adobmd_gui/viewer/widgets/adobmd_gl_widget.py
"""
ADOBMD 3D viewer — native Qt renderer (no OpenGL).

Mirrors the layout and workflow of molecular_assembly/assembly_widget_v2.py:
  * left panel: file actions, objects list, display controls, measurement,
                export
  * right panel: AdobmdView with drag-orbit / wheel-zoom / click-pick

Consumes ADOBMDData so bonds and QM flags come from the `.data` file
instead of a distance threshold.

PARSER
------
`load_file()` tries the Fortran shared library first (`fortran_parser.py`);
if unavailable or it returns nothing usable, it falls back to the pure
Python parser in `data_parser.py`. The status bar shows which backend
ran and how long it took.
"""

from __future__ import annotations

import logging
import math
import time
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QImage, QPainter
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QSplitter, QGroupBox,
    QPushButton, QLabel, QFileDialog, QMessageBox, QListWidget,
    QComboBox, QCheckBox, QGridLayout, QScrollArea, QFrame,
    QApplication, QStyle, QSpinBox, QDoubleSpinBox, QColorDialog
)

from .fast_renderer_adobmd import (
    AtomView, BoxView, AdobmdMoleculeItem, AdobmdView,
)
from ..utils.data_parser import ADOBMDData

# ---------------------------------------------------------------------------
# Fortran parser (optional)
# ---------------------------------------------------------------------------
try:
    from ..utils.fortran_parser import get_fortran_parser, FortranParser
    _FORTRAN_OK = True
except Exception:
    _FORTRAN_OK = False
    FortranParser = None        # type: ignore
    get_fortran_parser = None   # type: ignore


def _load_with_fortran(path: str) -> Tuple[Optional[dict], float]:
    """Try the Fortran parser. Return (parsed_dict | None, elapsed_ms)."""
    if not _FORTRAN_OK:
        return None, 0.0
    parser = get_fortran_parser()
    if parser is None:
        return None, 0.0
    t0 = time.perf_counter()
    try:
        result = parser.parse_file(path)
    except Exception as e:
        logging.warning(f"Fortran parser raised: {e}")
        result = None
    elapsed_ms = (time.perf_counter() - t0) * 1000.0
    return result, elapsed_ms


class Adobmd3DWidget(QWidget):
    """Real 3D viewer for ADOBMD unified .data files."""

    file_loaded = Signal(object)        # ADOBMDData
    selection_changed = Signal(list)    # list[int]

    # NEW: scale presets, mirroring assembly_widget_v2._update_atom_size.
    # Index 0 = Smallest, index 5 = Medium (default), index 15 = 10X.
    _ATOM_SCALES = (
        0.20, 0.35, 0.55, 0.75,
        0.95, 1.00, 1.20, 1.40,
        1.60, 1.80, 2.00, 3.00,
        4.00, 5.00, 6.00, 10.0,
    )

    def __init__(self, parent=None):
        super().__init__(parent)
        self._data: Optional[ADOBMDData] = None
        self._molecule: Optional[AdobmdMoleculeItem] = None
        self._supercell = (1, 1, 1)
        self._parser_backend = ""
        self._parser_ms = 0.0
        self._init_ui()

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------
    def _init_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        splitter = QSplitter(Qt.Horizontal)
        left = self._build_left_panel()
        left.setMinimumWidth(280)
        left.setMaximumWidth(420)
        splitter.addWidget(left)
        splitter.addWidget(self._build_view_panel())
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([320, 800])
        layout.addWidget(splitter)

    def _build_left_panel(self) -> QWidget:
        content = QWidget()
        v = QVBoxLayout(content)
        v.setContentsMargins(6, 6, 6, 6)
        v.setSpacing(6)

        # Load
        load_group = QGroupBox("Load")
        ll = QVBoxLayout(load_group)
        self.load_btn = QPushButton("Load .data File")
        self.load_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_DirOpenIcon)
        )
        self.load_btn.clicked.connect(self._on_load_clicked)
        ll.addWidget(self.load_btn)
        v.addWidget(load_group)

        # Representation
        rep_group = QGroupBox("Representation")
        rl = QVBoxLayout(rep_group)
        row = QHBoxLayout()
        row.addWidget(QLabel("Style:"))
        self.rep_combo = QComboBox()
        self.rep_combo.addItems(["Ball & Stick", "Sticks", "VdW spheres"])
        self.rep_combo.currentIndexChanged.connect(self._on_rep_changed)
        row.addWidget(self.rep_combo)
        rl.addLayout(row)

        # CHANGED: many more Size presets (was 5, now 16).
        row2 = QHBoxLayout()
        row2.addWidget(QLabel("Size:"))
        self.size_combo = QComboBox()
        self.size_combo.addItems([
            "Smallest", "Small", "Medium", "Large",
            "X-Large", "Default", "1.2X", "1.4X",
            "1.6X", "1.8X", "2X", "3X",
            "4X", "5X", "6X", "10X",
        ])
        self.size_combo.setCurrentIndex(2)      # Medium
        self.size_combo.currentIndexChanged.connect(self._on_size_changed)
        row2.addWidget(self.size_combo)
        rl.addLayout(row2)

        row3 = QHBoxLayout()
        row3.addWidget(QLabel("Color by:"))
        self.color_combo = QComboBox()
        self.color_combo.addItems(["Element", "QM/MM region", "Custom"])
        self.color_combo.currentIndexChanged.connect(self._on_color_changed)
        row3.addWidget(self.color_combo)
        rl.addLayout(row3)
        v.addWidget(rep_group)

        # Scene
        scene_group = QGroupBox("Scene")
        sl = QVBoxLayout(scene_group)
        self.show_box_chk = QCheckBox("Show unit cell")
        self.show_box_chk.setChecked(True)
        self.show_box_chk.toggled.connect(self._on_show_box)
        sl.addWidget(self.show_box_chk)

        self.show_bonds_chk = QCheckBox("Show bonds")
        self.show_bonds_chk.setChecked(True)
        self.show_bonds_chk.toggled.connect(self._on_show_bonds)
        sl.addWidget(self.show_bonds_chk)

        sc_row = QHBoxLayout()
        sc_row.addWidget(QLabel("Supercell:"))
        self.nx_spin = QSpinBox(); self.nx_spin.setRange(1, 6); self.nx_spin.setValue(1)
        self.ny_spin = QSpinBox(); self.ny_spin.setRange(1, 6); self.ny_spin.setValue(1)
        self.nz_spin = QSpinBox(); self.nz_spin.setRange(1, 6); self.nz_spin.setValue(1)
        for s in (self.nx_spin, self.ny_spin, self.nz_spin):
            s.valueChanged.connect(self._on_supercell_changed)
        sc_row.addWidget(self.nx_spin)
        sc_row.addWidget(self.ny_spin)
        sc_row.addWidget(self.nz_spin)
        sl.addLayout(sc_row)
        v.addWidget(scene_group)

        # Measurement panel (same UX as assembly_widget_v2)
        meas_group = QGroupBox("Measurement (click up to 4 atoms)")
        ml = QVBoxLayout(meas_group)
        self._meas_sel_label = QLabel("Selected (0/4): —")
        self._meas_sel_label.setWordWrap(True)
        ml.addWidget(self._meas_sel_label)
        self._meas_dist = QLabel("Distance: —")
        self._meas_dist.setStyleSheet("color:#1565c0;")
        ml.addWidget(self._meas_dist)
        self._meas_angle = QLabel("Angle: —")
        self._meas_angle.setStyleSheet("color:#2e7d32;")
        ml.addWidget(self._meas_angle)
        self._meas_dihedral = QLabel("Dihedral: —")
        self._meas_dihedral.setStyleSheet("color:#b8860b;")
        ml.addWidget(self._meas_dihedral)
        clear_btn = QPushButton("Clear selection")
        clear_btn.clicked.connect(self._on_clear_measurement)
        ml.addWidget(clear_btn)
        v.addWidget(meas_group)

        # Camera + export
        cam_group = QGroupBox("Camera / Export")
        cl = QGridLayout(cam_group)
        self.reset_view_btn = QPushButton("Reset View")
        self.reset_view_btn.clicked.connect(self._on_reset_view)
        cl.addWidget(self.reset_view_btn, 0, 0)
        self.fit_view_btn = QPushButton("Fit to view")
        self.fit_view_btn.clicked.connect(self._on_fit_view)
        cl.addWidget(self.fit_view_btn, 0, 1)
        self.bg_btn = QPushButton("Background…")
        self.bg_btn.clicked.connect(self._on_pick_background)
        cl.addWidget(self.bg_btn, 1, 0)
        self.export_png_btn = QPushButton("Screenshot")
        self.export_png_btn.clicked.connect(self._on_export_png)
        cl.addWidget(self.export_png_btn, 1, 1)
        v.addWidget(cam_group)

        v.addStretch()

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setWidget(content)
        return scroll

    def _build_view_panel(self) -> QWidget:
        panel = QWidget()
        v = QVBoxLayout(panel)
        v.setContentsMargins(0, 0, 0, 0)

        self.view = AdobmdView()
        self.view.atom_clicked.connect(self._on_atom_clicked)
        self.view.selection_changed.connect(self._on_selection_changed)
        v.addWidget(self.view)

        self.status = QLabel(
            "Drag with left button to orbit, right/middle to pan, "
            "wheel to zoom. Click an atom to select."
        )
        self.status.setStyleSheet("padding: 4px; background: #eee;")
        v.addWidget(self.status)
        return panel

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------
    def _on_load_clicked(self):
        fp, _ = QFileDialog.getOpenFileName(
            self, "Open ADOBMD .data File", "",
            "ADOBMD Files (*.data);;All files (*)",
        )
        if fp:
            self.load_file(fp)

    def load_file(self, path: str) -> bool:
        """
        Load a .data file. Fortran parser is tried first; if unavailable
        or it returns no atoms, fall back to the pure-Python parser.
        """
        # --- 1. Fortran path (fast) ----------------------------------
        fast_result, fast_ms = _load_with_fortran(path)
        if fast_result and fast_result.get('atoms'):
            data = ADOBMDData()
            if data.load_from_parsed(fast_result, filename=path):
                self._parser_backend = 'fortran'
                self._parser_ms = fast_ms
                self.load_data(data)
                logging.info(
                    f"[ADOBMD] Fortran parsed {data.natoms} atoms "
                    f"in {fast_ms:.1f} ms"
                )
                return True
            logging.warning(
                "Fortran result could not be adapted to ADOBMDData; "
                "falling back to Python parser"
            )

        # --- 2. Python path (slow, always works) --------------------
        t0 = time.perf_counter()
        data = ADOBMDData()
        ok = data.load(path)
        py_ms = (time.perf_counter() - t0) * 1000.0

        if not ok:
            QMessageBox.critical(
                self, "Error", f"Failed to parse .data file:\n{path}"
            )
            return False

        self._parser_backend = 'python'
        self._parser_ms = py_ms
        self.load_data(data)
        logging.info(
            f"[ADOBMD] Python parsed {data.natoms} atoms "
            f"in {py_ms:.1f} ms"
        )
        return True

    def load_data(self, data: ADOBMDData) -> None:
        """Populate from a fully-parsed ADOBMDData instance."""
        self._data = data
        self._supercell = (1, 1, 1)
        self.nx_spin.setValue(1)
        self.ny_spin.setValue(1)
        self.nz_spin.setValue(1)
        self._rebuild_molecule()
        self._update_status()
        self.file_loaded.emit(data)

    # ------------------------------------------------------------------
    # Rebuild pipeline
    # ------------------------------------------------------------------
    def _rebuild_molecule(self) -> None:
        if self._data is None:
            return

        atoms, bonds = self._build_supercell()

        item = AdobmdMoleculeItem(camera=self.view.camera)
        item.set_atoms(atoms)
        item.set_bonds(bonds)
        item.set_color_mode(self._color_mode())
        item.set_representation(self._rep_mode())
        item.set_atom_scale(self._scale_value())
        item.set_show_bonds(self.show_bonds_chk.isChecked())

        self._molecule = item
        self.view.set_molecule(item)

        # --- Box ------------------------------------------------------
        # Prefer the box read from the file. Fall back to an atom-derived
        # bounding box with 5 Å padding when the file has no xlo/ylo/zlo,
        # so the wireframe is never left at a degenerate (0,0,0)-(0,0,0)
        # state (which used to paint a single invisible point).
        lo, hi = self._cell_bounds(atoms)
        self.view.set_box(lo, hi)
        self.view.set_box_visible(self.show_box_chk.isChecked())
        self.view.fit_view()

    def _cell_bounds(self, atoms: List[AtomView]) -> Tuple[np.ndarray, np.ndarray]:
        """Return (lo, hi) in Å for the cell wireframe."""
        if self._data is not None and self._data.has_box:
            lo = np.array(self._data.box_lo, dtype=np.float64)
            hi = np.array(self._data.box_hi, dtype=np.float64)
            nx, ny, nz = self._supercell
            a, b, c = hi - lo
            hi = lo + np.array([a * nx, b * ny, c * nz])
            return lo, hi

        # Fallback: atom-derived bounding box with padding.
        if not atoms:
            return np.zeros(3), np.zeros(3)
        pos = np.array([[a.x, a.y, a.z] for a in atoms], dtype=np.float64)
        pad = 5.0
        return pos.min(axis=0) - pad, pos.max(axis=0) + pad

    def _build_supercell(self):
        """Return (AtomView[], list[(i,j)]) after applying supercell."""
        d = self._data
        atoms: List[AtomView] = []
        base_bonds = [(b.atom1 - 1, b.atom2 - 1) for b in d.bonds]
        n_base = len(d.atoms)

        nx, ny, nz = self._supercell
        a = b = c = 0.0
        if d.has_box:
            a = float(d.box_hi[0] - d.box_lo[0])
            b = float(d.box_hi[1] - d.box_lo[1])
            c = float(d.box_hi[2] - d.box_lo[2])

        cell_count = nx * ny * nz
        for ix in range(nx):
            for iy in range(ny):
                for iz in range(nz):
                    offset = np.array([ix * a, iy * b, iz * c])
                    cell_idx = ix * ny * nz + iy * nz + iz
                    base = cell_idx * n_base
                    for atom in d.atoms:
                        atoms.append(AtomView(
                            index=base + (atom.id - 1),
                            element=atom.element,
                            x=atom.x + offset[0],
                            y=atom.y + offset[1],
                            z=atom.z + offset[2],
                            is_qm=atom.is_qm,
                            charge=atom.charge,
                        ))

        bonds: List[Tuple[int, int]] = []
        if cell_count == 1:
            bonds = base_bonds
        else:
            for cell_idx in range(cell_count):
                base = cell_idx * n_base
                for i, j in base_bonds:
                    bonds.append((base + i, base + j))

        return atoms, bonds

    # ------------------------------------------------------------------
    # Display handlers
    # ------------------------------------------------------------------
    def _rep_mode(self) -> str:
        return {0: "ball_stick", 1: "sticks", 2: "vdw"}[
            self.rep_combo.currentIndex()
        ]

    def _scale_value(self) -> float:
        # CHANGED: use the module-level preset table.
        idx = self.size_combo.currentIndex()
        if 0 <= idx < len(self._ATOM_SCALES):
            return self._ATOM_SCALES[idx]
        return 1.0

    def _color_mode(self) -> str:
        return {0: "element", 1: "qm_mm", 2: "custom"}[
            self.color_combo.currentIndex()
        ]

    def _on_rep_changed(self, _):
        if self._molecule is not None:
            self._molecule.set_representation(self._rep_mode())

    def _on_size_changed(self, _):
        # CHANGED: also re-apply the current representation because the
        # VdW/spheres radii depend on the representation the user picked
        # *before* changing the size.
        if self._molecule is not None:
            self._molecule.set_atom_scale(self._scale_value())

    def _on_color_changed(self, _):
        if self._molecule is not None:
            self._molecule.set_color_mode(self._color_mode())

    def _on_show_box(self, checked: bool):
        self.view.set_box_visible(bool(checked))

    def _on_show_bonds(self, checked: bool):
        if self._molecule is not None:
            self._molecule.set_show_bonds(bool(checked))

    def _on_supercell_changed(self, _):
        self._supercell = (
            self.nx_spin.value(), self.ny_spin.value(), self.nz_spin.value()
        )
        self._rebuild_molecule()

    # ------------------------------------------------------------------
    # Camera
    # ------------------------------------------------------------------
    def _on_reset_view(self):
        self.view.reset_view()

    def _on_fit_view(self):
        self.view.fit_view()

    def _on_pick_background(self):
        cur = self.view.scene_.backgroundBrush().color()
        c = QColorDialog.getColor(cur, self, "Background color")
        if c.isValid():
            self.view.set_background_color(c)

    def _on_export_png(self):
        if self._data is None:
            return
        fp, _ = QFileDialog.getSaveFileName(
            self, "Save screenshot", "adobmd.png", "PNG (*.png)"
        )
        if not fp:
            return
        rect = self.view.viewport().rect()
        img = QImage(rect.size(), QImage.Format_ARGB32)
        img.fill(self.view.scene_.backgroundBrush().color())
        p = QPainter(img)
        self.view.scene_.render(p, target=img.rect(),
                                source=self.view.scene_.sceneRect())
        p.end()
        img.save(fp)
        self.status.setText(f"Saved screenshot: {fp}")

    # ------------------------------------------------------------------
    # Measurement (identical logic to assembly_widget_v2)
    # ------------------------------------------------------------------
    def _on_atom_clicked(self, idx: int):
        self._update_measurement()

    def _on_selection_changed(self, _sel):
        self._update_measurement()
        self.selection_changed.emit(self.view.selected)

    def _on_clear_measurement(self):
        self.view.clear_selection()
        self._update_measurement()

    def _all_positions(self) -> np.ndarray:
        if self._molecule is None:
            return np.zeros((0, 3))
        return self._molecule.positions_3d

    def _all_elements(self) -> List[str]:
        if self._molecule is None:
            return []
        return self._molecule.elements

    def _update_measurement(self):
        sel = self.view.selected
        pos = self._all_positions()
        elem = self._all_elements()

        if len(pos) == 0:
            self._meas_sel_label.setText("Selected (0/4): —")
            self._meas_dist.setText("Distance: —")
            self._meas_angle.setText("Angle: —")
            self._meas_dihedral.setText("Dihedral: —")
            return

        labels = [f"{elem[i]}#{i}" for i in sel if 0 <= i < len(elem)]
        self._meas_sel_label.setText(
            f"Selected ({len(sel)}/4): "
            + (", ".join(labels) if labels else "—")
        )

        if len(sel) >= 2:
            d = float(np.linalg.norm(pos[sel[1]] - pos[sel[0]]))
            self._meas_dist.setText(f"d(1–2) = {d:.4f} Å")
        else:
            self._meas_dist.setText("Distance: —")

        if len(sel) >= 3:
            v1 = pos[sel[0]] - pos[sel[1]]
            v2 = pos[sel[2]] - pos[sel[1]]
            n1, n2 = np.linalg.norm(v1), np.linalg.norm(v2)
            if n1 > 0 and n2 > 0:
                c = float(np.dot(v1, v2) / (n1 * n2))
                a = math.degrees(math.acos(max(-1.0, min(1.0, c))))
                self._meas_angle.setText(f"∠(1–2–3) = {a:.2f}°")
        if len(sel) >= 4:
            p1, p2, p3, p4 = pos[sel[0]], pos[sel[1]], pos[sel[2]], pos[sel[3]]
            b1 = p2 - p1
            b2 = p3 - p2
            b3 = p4 - p3
            n1 = np.cross(b1, b2)
            n2 = np.cross(b2, b3)
            b2n = b2 / np.linalg.norm(b2) if np.linalg.norm(b2) > 0 else np.array([0, 0, 1])
            m1 = np.cross(n1, b2n)
            x = float(np.dot(n1, n2))
            y = float(np.dot(m1, n2))
            dh = math.degrees(math.atan2(y, x))
            self._meas_dihedral.setText(f"τ(1–2–3–4) = {dh:.2f}°")

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------
    def _update_status(self):
        if self._data is None:
            return
        d = self._data
        n_qm = sum(1 for a in d.atoms if a.is_qm)

        backend = getattr(self, '_parser_backend', '')
        ms = getattr(self, '_parser_ms', 0.0)
        suffix = ""
        if backend:
            suffix = f"  [{backend}"
            if ms > 0:
                suffix += f", {ms:.1f} ms"
            suffix += "]"

        self.status.setText(
            f"{d.filename} — {d.natoms} atoms ({n_qm} QM), "
            f"{d.nbonds} bonds{suffix}"
        )