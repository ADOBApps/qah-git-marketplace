"""
schlegel_tab.py - Enhanced Schlegel diagram tab with all methods and progress indicator
"""

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox,
    QLabel, QPushButton, QComboBox, QSpinBox,
    QDoubleSpinBox, QRadioButton, QButtonGroup,
    QScrollArea, QSizePolicy, QCheckBox, QTabWidget,
    QProgressBar, QMessageBox
)
from PySide6.QtGui import QGuiApplication, QPixmap
from PySide6.QtCore import Qt, QThread, Signal
import numpy as np
import time

from ..utils.schlegel_diagram import SchlegelVisualizer
from .about_schlegel import AboutSchlegelWidget


class SchlegelWorker(QThread):
    """Worker thread for Schlegel diagram generation"""
    
    progress = Signal(int)
    finished = Signal(object)
    error = Signal(str)
    
    def __init__(self, visualizer, positions, method, params):
        super().__init__()
        self.visualizer = visualizer
        self.positions = positions
        self.method = method
        self.params = params
    
    def run(self):
        try:
            self.progress.emit(10)
            
            # Generate diagram with progress simulation
            time.sleep(0.1)  # Small delay for UI update
            self.progress.emit(30)
            
            pixmap = self.visualizer.visualize(
                self.positions,
                method=self.method,
                outer_ring_size=self.params.get('outer_size', 5),
                projection_angle=self.params.get('angle', 30.0),
                boost=self.params.get('boost', 1.0),
                fscale=self.params.get('fscale', 1.0),
                scale_ppg=self.params.get('scale_ppg', 1.0),
                is1=self.params.get('is1', 0),
                is2=self.params.get('is2', 0),
                is3=self.params.get('is3', 0),
                show_atoms=self.params.get('show_atoms', True),
                show_rings=self.params.get('show_rings', True),
                show_bonds=self.params.get('show_bonds', True),
                size=self.params.get('size', (800, 600))
            )
            
            self.progress.emit(90)
            time.sleep(0.1)
            self.progress.emit(100)
            
            self.finished.emit(pixmap)
            
        except Exception as e:
            self.error.emit(str(e))


class SchlegelTab(QWidget):
    """Enhanced tab for Schlegel diagram visualization with all methods"""
    
    def __init__(self, predictor, main_window):
        super().__init__()
        self.predictor = predictor
        self.main_window = main_window
        self.current_pixmap = None
        self.current_positions = None
        self.current_shell_info = None
        
        self.schlegel = SchlegelVisualizer()
        self.worker = None
        
        self.init_ui()
    
    def init_ui(self):
        # Main layout with tabs
        main_layout = QVBoxLayout()
        
        # Create tab widget for diagram and info
        self.tab_widget = QTabWidget()
        
        # Diagram tab
        self.diagram_tab = self.create_diagram_tab()
        self.tab_widget.addTab(self.diagram_tab, "Diagram")
        
        # About tab
        self.about_tab = AboutSchlegelWidget()
        self.tab_widget.addTab(self.about_tab, "About")
        
        main_layout.addWidget(self.tab_widget)
        self.setLayout(main_layout)
    
    def create_diagram_tab(self):
        """Create the main diagram generation tab"""
        tab = QWidget()
        layout = QHBoxLayout(tab)
        
        # Screen-based sizing
        screen = QGuiApplication.primaryScreen()
        screen_geometry = screen.availableSize()
        left_panel_width = screen_geometry.width() * 0.3
        
        # Left control panel with scrollbar
        left_panel_container = QWidget()
        left_panel_container.setMaximumWidth(left_panel_width)
        
        # Create scroll area for left panel
        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        left_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        left_scroll.setMaximumWidth(left_panel_width)
        left_scroll.setMinimumWidth(250)
        
        # Create content widget for scroll area
        left_content = QWidget()
        left_layout = QVBoxLayout(left_content)
        left_layout.setSpacing(10)
        left_layout.setContentsMargins(10, 10, 10, 10)
        
        # Method selection (expanded with all 8 methods)
        method_group = QGroupBox("Schlegel Method")
        method_layout = QVBoxLayout()
        
        self.method_combo = QComboBox()
        self.method_combo.addItems([
            "1: Perspective Projection",
            "2: Cone Projection",
            "3: Tutte Embedding (Basic)",
            "4: Tutte with Radial Scaling",
            "5: Spring Embedding",
            "6: Spring + Coulomb Embedding",
            "7: PPG Embedding (Distance-based)",
            "8: Kamada-Kawai Embedding"
        ])
        self.method_combo.setCurrentIndex(0)
        self.method_combo.currentIndexChanged.connect(self.on_method_changed)
        method_layout.addWidget(self.method_combo)
        
        # Method description
        self.method_desc = QLabel(
            "Perspective projection: Projects 3D structure onto a plane "
            "using a focal point above the molecule."
        )
        self.method_desc.setWordWrap(True)
        self.method_desc.setStyleSheet("color: #666; font-size: 10px; padding: 5px;")
        method_layout.addWidget(self.method_desc)
        
        method_group.setLayout(method_layout)
        left_layout.addWidget(method_group)
        
        # Alignment parameters (for methods 1-2)
        self.alignment_group = QGroupBox("Alignment Parameters")
        alignment_layout = QVBoxLayout()
        
        align_grid = QHBoxLayout()
        align_grid.addWidget(QLabel("IS1:"))
        self.is1_spin = QSpinBox()
        self.is1_spin.setRange(0, 999)
        self.is1_spin.setValue(0)
        self.is1_spin.setToolTip("First atom index (0 for default)")
        align_grid.addWidget(self.is1_spin)
        
        align_grid.addWidget(QLabel("IS2:"))
        self.is2_spin = QSpinBox()
        self.is2_spin.setRange(0, 999)
        self.is2_spin.setValue(0)
        align_grid.addWidget(self.is2_spin)
        
        align_grid.addWidget(QLabel("IS3:"))
        self.is3_spin = QSpinBox()
        self.is3_spin.setRange(0, 999)
        self.is3_spin.setValue(0)
        align_grid.addWidget(self.is3_spin)
        
        alignment_layout.addWidget(QLabel("Atom indices for alignment (0 = auto):"))
        alignment_layout.addLayout(align_grid)
        alignment_layout.addStretch()
        
        self.alignment_group.setLayout(alignment_layout)
        left_layout.addWidget(self.alignment_group)
        
        # Parameters group (dynamic based on method)
        self.params_group = QGroupBox("Method Parameters")
        self.params_layout = QVBoxLayout()
        self.params_group.setLayout(self.params_layout)
        left_layout.addWidget(self.params_group)
        
        # Display options
        display_group = QGroupBox("Display Options")
        display_layout = QVBoxLayout()
        
        self.show_atoms_check = QCheckBox("Show Atoms")
        self.show_atoms_check.setChecked(True)
        display_layout.addWidget(self.show_atoms_check)
        
        self.show_rings_check = QCheckBox("Show Rings")
        self.show_rings_check.setChecked(True)
        display_layout.addWidget(self.show_rings_check)
        
        self.show_bonds_check = QCheckBox("Show Bonds")
        self.show_bonds_check.setChecked(True)
        display_layout.addWidget(self.show_bonds_check)
        
        self.show_indices_check = QCheckBox("Show Atom Indices")
        self.show_indices_check.setChecked(False)
        display_layout.addWidget(self.show_indices_check)
        
        display_group.setLayout(display_layout)
        left_layout.addWidget(display_group)
        
        # Size control
        size_group = QGroupBox("Image Size")
        size_layout = QHBoxLayout()
        
        size_layout.addWidget(QLabel("Size:"))
        self.size_combo = QComboBox()
        self.size_combo.addItems(["600x450", "800x600", "1000x750", "1200x900"])
        self.size_combo.setCurrentIndex(1)
        size_layout.addWidget(self.size_combo)
        
        size_group.setLayout(size_layout)
        left_layout.addWidget(size_group)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        left_layout.addWidget(self.progress_bar)
        
        # Generate button
        self.generate_btn = QPushButton("Generate Schlegel Diagram")
        self.generate_btn.clicked.connect(self.generate_diagram)
        self.generate_btn.setEnabled(False)
        left_layout.addWidget(self.generate_btn)
        
        # Cancel button
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self.cancel_generation)
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.setVisible(False)
        left_layout.addWidget(self.cancel_btn)
        
        # Status label
        self.status_label = QLabel("Load or generate a structure first")
        self.status_label.setStyleSheet("color: #666; padding: 5px;")
        self.status_label.setWordWrap(True)
        left_layout.addWidget(self.status_label)
        
        # Analysis group
        analysis_group = QGroupBox("Schlegel Analysis")
        analysis_layout = QVBoxLayout()
        
        analysis_scroll = QScrollArea()
        analysis_scroll.setWidgetResizable(True)
        analysis_scroll.setMinimumHeight(150)
        analysis_scroll.setMaximumHeight(250)
        
        self.analysis_text = QLabel("No analysis available")
        self.analysis_text.setWordWrap(True)
        self.analysis_text.setStyleSheet("padding: 10px; background-color: #f8f9fa;")
        self.analysis_text.setAlignment(Qt.AlignmentFlag.AlignTop)
        
        analysis_scroll.setWidget(self.analysis_text)
        analysis_layout.addWidget(analysis_scroll)
        analysis_group.setLayout(analysis_layout)
        
        left_layout.addWidget(analysis_group)
        left_layout.addStretch()
        
        # Set the content widget for scroll area
        left_scroll.setWidget(left_content)
        
        # Create a container for the scroll area
        left_container = QWidget()
        left_container_layout = QVBoxLayout(left_container)
        left_container_layout.setContentsMargins(0, 0, 0, 0)
        left_container_layout.addWidget(left_scroll)
        left_container.setMaximumWidth(left_panel_width)
        left_container.setMinimumWidth(250)
        
        # Right panel with visualization
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        
        # Scroll area for image
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroll_area.setMinimumSize(500, 400)
        
        # Container for image
        self.vis_container = QWidget()
        self.vis_container_layout = QVBoxLayout(self.vis_container)
        
        self.visualization_label = QLabel()
        self.visualization_label.setAlignment(Qt.AlignCenter)
        self.visualization_label.setText(
            "Generate Schlegel diagram\n\n"
            "Select parameters and click Generate\n\n"
            "Reference: DOI: 10.1016/j.cplett.2006.02.100"
        )
        self.visualization_label.setStyleSheet(
            "border: 1px solid gray; background-color: white; color: #666; padding: 20px;"
        )
        self.visualization_label.setWordWrap(True)
        self.visualization_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        
        self.vis_container_layout.addWidget(self.visualization_label)
        self.scroll_area.setWidget(self.vis_container)
        
        right_layout.addWidget(self.scroll_area)
        
        # Add to main layout
        layout.addWidget(left_container)
        layout.addWidget(right_panel, 1)
        
        # Initialize parameters for default method
        self.update_method_parameters(0)
        
        return tab
    
    def on_method_changed(self, index):
        """Update UI based on selected method"""
        descriptions = [
            "Perspective projection: Projects 3D structure onto a plane "
            "using a focal point above the molecule. Best for visualizing depth.",
            
            "Cone projection: Projects onto a cone surface before flattening. "
            "Provides different distortion properties than perspective projection.",
            
            "Tutte embedding (basic): Places outer ring on a circle and solves "
            "for interior positions using barycentric coordinates.",
            
            "Tutte with radial scaling: Same as basic Tutte but with additional "
            "radial scaling to improve spacing between vertices.",
            
            "Spring embedding: Treats bonds as springs and finds energy minimum. "
            "Produces aesthetically pleasing layouts.",
            
            "Spring + Coulomb embedding: Adds repulsive Coulomb forces between "
            "atoms to prevent overlapping.",
            
            "PPG embedding (Pisanski-Plestenjak-Graovac): Distance-based method "
            "using the graph distance matrix for weighting.",
            
            "Kamada-Kawai embedding: Force-directed layout based on graph "
            "distances. Good for revealing structural symmetry."
        ]
        
        self.method_desc.setText(descriptions[index])
        self.update_method_parameters(index)
    
    def update_method_parameters(self, method_index):
        """Update parameter inputs based on selected method"""
        # Clear existing parameters
        for i in reversed(range(self.params_layout.count())):
            widget = self.params_layout.itemAt(i).widget()
            if widget:
                widget.deleteLater()
        
        method = method_index + 1  # 1-based indexing
        
        # Common parameters
        if method <= 2:  # Projection methods
            # Outer ring size
            ring_layout = QHBoxLayout()
            ring_layout.addWidget(QLabel("Outer Ring Size:"))
            self.outer_size_spin = QSpinBox()
            self.outer_size_spin.setRange(5, 6)
            self.outer_size_spin.setValue(5)
            ring_layout.addWidget(self.outer_size_spin)
            self.params_layout.addLayout(ring_layout)
            
            # Projection angle
            angle_layout = QHBoxLayout()
            angle_layout.addWidget(QLabel("Projection Angle (°):"))
            self.angle_spin = QDoubleSpinBox()
            self.angle_spin.setRange(10.0, 60.0)
            self.angle_spin.setValue(30.0)
            angle_layout.addWidget(self.angle_spin)
            self.params_layout.addLayout(angle_layout)
            
            if method == 2:  # Cone projection only
                boost_layout = QHBoxLayout()
                boost_layout.addWidget(QLabel("Boost factor:"))
                self.boost_spin = QDoubleSpinBox()
                self.boost_spin.setRange(0.5, 3.0)
                self.boost_spin.setValue(1.0)
                self.boost_spin.setSingleStep(0.1)
                boost_layout.addWidget(self.boost_spin)
                self.params_layout.addLayout(boost_layout)
        
        elif method == 3 or method == 4:  # Tutte methods
            ring_layout = QHBoxLayout()
            ring_layout.addWidget(QLabel("Outer Ring Size:"))
            self.outer_size_spin = QSpinBox()
            self.outer_size_spin.setRange(5, 6)
            self.outer_size_spin.setValue(5)
            ring_layout.addWidget(self.outer_size_spin)
            self.params_layout.addLayout(ring_layout)
            
            if method == 4:  # Tutte with scaling
                fscale_layout = QHBoxLayout()
                fscale_layout.addWidget(QLabel("Scale factor:"))
                self.fscale_spin = QDoubleSpinBox()
                self.fscale_spin.setRange(0.1, 5.0)
                self.fscale_spin.setValue(1.0)
                fscale_layout.addWidget(self.fscale_spin)
                self.params_layout.addLayout(fscale_layout)
        
        elif method == 5 or method == 6:  # Spring embeddings
            ring_layout = QHBoxLayout()
            ring_layout.addWidget(QLabel("Outer Ring Size:"))
            self.outer_size_spin = QSpinBox()
            self.outer_size_spin.setRange(5, 6)
            self.outer_size_spin.setValue(5)
            ring_layout.addWidget(self.outer_size_spin)
            self.params_layout.addLayout(ring_layout)
        
        elif method == 7:  # PPG
            ring_layout = QHBoxLayout()
            ring_layout.addWidget(QLabel("Outer Ring Size:"))
            self.outer_size_spin = QSpinBox()
            self.outer_size_spin.setRange(5, 6)
            self.outer_size_spin.setValue(5)
            ring_layout.addWidget(self.outer_size_spin)
            self.params_layout.addLayout(ring_layout)
            
            scale_layout = QHBoxLayout()
            scale_layout.addWidget(QLabel("Scale PPG:"))
            self.scale_ppg_spin = QDoubleSpinBox()
            self.scale_ppg_spin.setRange(0.1, 5.0)
            self.scale_ppg_spin.setValue(1.0)
            scale_layout.addWidget(self.scale_ppg_spin)
            self.params_layout.addLayout(scale_layout)
        
        elif method == 8:  # Kamada-Kawai
            fscale_layout = QHBoxLayout()
            fscale_layout.addWidget(QLabel("Scale factor:"))
            self.fscale_spin = QDoubleSpinBox()
            self.fscale_spin.setRange(0.1, 5.0)
            self.fscale_spin.setValue(1.0)
            fscale_layout.addWidget(self.fscale_spin)
            self.params_layout.addLayout(fscale_layout)
        
        # Add stretch to parameters layout
        self.params_layout.addStretch()
    
    def generate_diagram(self):
        """Generate Schlegel diagram with progress indication"""
        if self.current_positions is None:
            self.status_label.setText("No structure loaded!")
            return
        
        # Show progress
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.generate_btn.setEnabled(False)
        self.cancel_btn.setEnabled(True)
        self.cancel_btn.setVisible(True)
        self.status_label.setText("Generating Schlegel diagram...")
        
        # Get parameters
        size_str = self.size_combo.currentText()
        width, height = map(int, size_str.split('x'))
        method_index = self.method_combo.currentIndex()
        method = method_index + 1  # 1-based for Fortran compatibility
        
        # Collect parameters based on method
        params = {
            'outer_size': getattr(self, 'outer_size_spin', None).value() if hasattr(self, 'outer_size_spin') else 5,
            'angle': getattr(self, 'angle_spin', None).value() if hasattr(self, 'angle_spin') else 30.0,
            'boost': getattr(self, 'boost_spin', None).value() if hasattr(self, 'boost_spin') else 1.0,
            'fscale': getattr(self, 'fscale_spin', None).value() if hasattr(self, 'fscale_spin') else 1.0,
            'scale_ppg': getattr(self, 'scale_ppg_spin', None).value() if hasattr(self, 'scale_ppg_spin') else 1.0,
            'is1': self.is1_spin.value(),
            'is2': self.is2_spin.value(),
            'is3': self.is3_spin.value(),
            'show_atoms': self.show_atoms_check.isChecked(),
            'show_rings': self.show_rings_check.isChecked(),
            'show_bonds': self.show_bonds_check.isChecked(),
            'show_indices': self.show_indices_check.isChecked(),
            'size': (width, height)
        }
        
        # Create and start worker thread
        self.worker = SchlegelWorker(self.schlegel, self.current_positions, method, params)
        self.worker.progress.connect(self.update_progress)
        self.worker.finished.connect(self.on_generation_finished)
        self.worker.error.connect(self.on_generation_error)
        self.worker.start()
    
    def update_progress(self, value):
        """Update progress bar"""
        self.progress_bar.setValue(value)
    
    def cancel_generation(self):
        """Cancel ongoing generation"""
        if self.worker and self.worker.isRunning():
            self.worker.terminate()
            self.worker.wait()
            self.reset_ui_after_cancel()
    
    def reset_ui_after_cancel(self):
        """Reset UI after cancellation"""
        self.progress_bar.setVisible(False)
        self.generate_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.setVisible(False)
        self.status_label.setText("Generation cancelled")
    
    def on_generation_finished(self, pixmap):
        """Handle successful generation"""
        self.current_pixmap = pixmap
        
        # Update display
        size_str = self.size_combo.currentText()
        width, height = map(int, size_str.split('x'))
        
        self.visualization_label.setPixmap(pixmap)
        self.visualization_label.setStyleSheet("border: 1px solid gray; background-color: white;")
        self.visualization_label.setMinimumSize(width, height)
        
        # Update UI
        self.progress_bar.setVisible(False)
        self.generate_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.setVisible(False)
        self.status_label.setText("Schlegel diagram generated successfully")
        
        # Update analysis
        self.update_analysis()
    
    def on_generation_error(self, error_msg):
        """Handle generation error"""
        QMessageBox.critical(self, "Generation Error", f"Error: {error_msg}")
        self.visualization_label.setText(f"Error generating diagram:\n{error_msg}")
        self.reset_ui_after_cancel()
    
    def update_structure(self, positions, shell_info=None):
        """Update with new structure from main window"""
        self.current_positions = positions
        self.current_shell_info = shell_info
        self.generate_btn.setEnabled(True)
        self.status_label.setText(f"Structure loaded ({len(positions)} atoms). Click Generate.")
        
        # Clear previous diagram
        self.visualization_label.setText(
            "Structure updated.\nClick Generate to create Schlegel diagram\n\n"
            "Reference: DOI: 10.1016/j.cplett.2006.02.100"
        )
        self.visualization_label.setStyleSheet(
            "border: 1px solid gray; background-color: white; color: #666; padding: 20px;"
        )
    
    def clear_structure(self):
        """Clear current structure"""
        self.current_positions = None
        self.current_shell_info = None
        self.generate_btn.setEnabled(False)
        self.status_label.setText("Load or generate a structure first")
        self.visualization_label.setText(
            "No structure to visualize\n\nLoad or generate a structure first\n\n"
            "Reference: DOI: 10.1016/j.cplett.2006.02.100"
        )
        self.visualization_label.setStyleSheet(
            "border: 1px solid gray; background-color: white; color: #666; padding: 20px;"
        )
        self.analysis_text.setText("No analysis available")
    
    def update_analysis(self):
        """Update analysis text"""
        analysis = self.schlegel.get_analysis()
        
        if analysis:
            method_name = self.method_combo.currentText()
            
            analysis_text = f"""
            <div style="font-family: Arial, sans-serif; line-height: 1.4;">
            <h3 style="margin: 0 0 10px 0;">Schlegel Diagram Analysis</h3>
            <table style="width: 100%; border-collapse: collapse;">
                <tr><td style="padding: 4px; border-bottom: 1px solid #eee;"><b>Method:</b></td>
                    <td style="padding: 4px; border-bottom: 1px solid #eee;">{method_name}</td></tr>
                <tr><td style="padding: 4px; border-bottom: 1px solid #eee;"><b>Atoms:</b></td>
                    <td style="padding: 4px; border-bottom: 1px solid #eee;">{analysis.get('n_atoms', 'N/A')}</td></tr>
                <tr><td style="padding: 4px; border-bottom: 1px solid #eee;"><b>Pentagons:</b></td>
                    <td style="padding: 4px; border-bottom: 1px solid #eee;">{analysis.get('n_pentagons', 'N/A')}</td></tr>
                <tr><td style="padding: 4px; border-bottom: 1px solid #eee;"><b>Hexagons:</b></td>
                    <td style="padding: 4px; border-bottom: 1px solid #eee;">{analysis.get('n_hexagons', 'N/A')}</td></tr>
            """
            
            if 'outer_ring_size' in analysis:
                analysis_text += f"""
                <tr><td style="padding: 4px; border-bottom: 1px solid #eee;"><b>Outer Ring Size:</b></td>
                    <td style="padding: 4px; border-bottom: 1px solid #eee;">{analysis.get('outer_ring_size', 'N/A')}</td></tr>
                """
            
            analysis_text += f"""
                <tr><td style="padding: 4px; border-bottom: 1px solid #eee;"><b>Avg Radius:</b></td>
                    <td style="padding: 4px; border-bottom: 1px solid #eee;">{analysis.get('avg_radius', 0):.2f}</td></tr>
                <tr><td style="padding: 4px;"><b>Max Radius:</b></td>
                    <td style="padding: 4px;">{analysis.get('max_radius', 0):.2f}</td></tr>
            </table>
            
            <p style="font-size: 10px; color: #666; margin-top: 10px;">
            Reference: DOI: 10.1016/j.cplett.2006.02.100
            </p>
            </div>
            """
            
            self.analysis_text.setText(analysis_text)
        else:
            self.analysis_text.setText("No analysis available")