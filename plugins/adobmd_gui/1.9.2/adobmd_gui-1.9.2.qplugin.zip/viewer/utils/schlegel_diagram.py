"""
schlegel_diagram.py - Complete Schlegel diagram generation for fullerenes
Based on the Fortran schlegel.f90 code with all algorithms
"""

import numpy as np
import matplotlib.pyplot as plt
import networkx as nx
from scipy.spatial import KDTree
from scipy.optimize import minimize
from PySide6.QtGui import QPixmap
import io
import logging


class SchlegelDiagram:
    """Generate Schlegel diagrams for fullerenes and nano-onions"""
    
    def __init__(self):
        self.layout_2d = None
        self.rings_2d = None
        self.outer_ring_indices = None
        self.ring_types = None  # 'P' for pentagon, 'H' for hexagon
        self.adjacency = None
        self.n5r = 0  # number of pentagons
        self.n6r = 0  # number of hexagons
        self.n5m = []  # pentagon ring members
        self.n6m = []  # hexagon ring members
        self.cr5 = []  # pentagon centers
        self.cr6 = []  # hexagon centers
        self.ic3 = None  # adjacency indices
        
    def generate_from_positions(self, positions, method=1, 
                                is1=0, is2=0, is3=0,
                                projection_angle=30.0, 
                                bond_threshold=1.8,
                                boost=1.0, fscale=1.0, 
                                scale_ppg=1.0, epsf=0.12,
                                outer_ring_size=5):  # ADDED THIS PARAMETER
        """
        Generate Schlegel diagram from 3D positions
        Implements algorithms from Fortran code:
        
        method:
        1 - Perspective projection
        2 - Cone projection
        3 - Tutte embedding (basic)
        4 - Tutte embedding with radial scaling
        5 - Spring embedding
        6 - Spring + Coulomb embedding
        7 - Pisanski-Plestenjak-Graovac embedding
        8 - Kamada-Kawai embedding
        
        Args:
            positions: numpy array of 3D coordinates (N x 3)
            method: algorithm selection (1-8)
            is1, is2, is3: alignment indices (vertex, edge, or ring)
            projection_angle: angle for cone/perspective projection (degrees)
            bond_threshold: bond distance threshold
            boost: extra boost for last ring points (cone projection)
            fscale: scaling factor for Tutte graphs
            scale_ppg: scaling for PPG algorithm
            epsf: tolerance for circle detection
            outer_ring_size: size of outer ring (5 for pentagon, 6 for hexagon)  # ADDED DOCSTRING
        
        Returns:
            2D layout coordinates (N x 2)
        """
        n_atoms = len(positions)
        
        # Compute adjacency matrix
        self.adjacency = self._compute_adjacency(positions, bond_threshold)
        
        # Create graph
        G = nx.from_numpy_array(self.adjacency)
        
        # Detect rings (pentagons and hexagons)
        self._detect_rings_from_graph(G, positions)
        
        # Store adjacency for IC3 (3 nearest neighbors)
        self.ic3 = np.zeros((n_atoms, 3), dtype=int)
        for i in range(n_atoms):
            neighbors = np.where(self.adjacency[i] > 0)[0]
            self.ic3[i, :len(neighbors)] = neighbors[:3]
        
        if method <= 2:
            # Projection methods (1: perspective, 2: cone)
            layout = self._projection_method(positions, method, 
                                            is1, is2, is3,
                                            projection_angle, boost, epsf)
        else:
            # Graph embedding methods (3-8)
            layout = self._embedding_method(G, method - 2,
                                           is1, is2, is3,
                                           fscale, scale_ppg,
                                           outer_ring_size)  # PASS THE PARAMETER
        
        self.layout_2d = layout
        return layout
    
    def _compute_adjacency(self, positions, bond_threshold=1.8):
        """Compute adjacency matrix from distances"""
        n = len(positions)
        adj = np.zeros((n, n), dtype=int)
        
        for i in range(n):
            for j in range(i+1, n):
                dist = np.linalg.norm(positions[i] - positions[j])
                if dist < bond_threshold:
                    adj[i, j] = adj[j, i] = 1
        
        return adj
    
    def _detect_rings_from_graph(self, G, positions):
        """Detect pentagonal and hexagonal rings from graph"""
        # Find all cycles of length 5 and 6
        rings_5 = []
        rings_6 = []
        
        # Use cycle basis to find rings
        cycle_basis = nx.cycle_basis(G)
        
        for cycle in cycle_basis:
            if len(cycle) == 5:
                rings_5.append(cycle)
            elif len(cycle) == 6:
                rings_6.append(cycle)
        
        # Remove duplicates
        self.n5m = []
        self.n6m = []
        self.ring_types = []
        
        for ring in rings_5:
            ring_sorted = sorted(ring)
            if ring_sorted not in [sorted(r) for r in self.n5m]:
                self.n5m.append(ring)
                self.ring_types.append('P')
        
        for ring in rings_6:
            ring_sorted = sorted(ring)
            if ring_sorted not in [sorted(r) for r in self.n6m]:
                self.n6m.append(ring)
                self.ring_types.append('H')
        
        self.n5r = len(self.n5m)
        self.n6r = len(self.n6m)
        
        # Calculate ring centers
        self.cr5 = []
        for ring in self.n5m:
            center = np.mean(positions[ring], axis=0)
            self.cr5.append(center)
        
        self.cr6 = []
        for ring in self.n6m:
            center = np.mean(positions[ring], axis=0)
            self.cr6.append(center)
    
    def _align_for_schlegel(self, positions, is1, is2, is3):
        """
        Align fullerene for Schlegel projection (Fortran lines 50-150)
        Rotates so that selected point/edge/face is at the top
        """
        n_atoms = len(positions)
        centered = positions.copy()
        
        # Determine alignment point
        if is1 == 0:
            # Original input
            rotation = np.eye(3)
            return centered, rotation
        
        if is2 == 0:
            # Vertex alignment
            c = positions[is1-1].copy()  # Fortran 1-indexed to Python 0-indexed
            logging.info(f"Vertex {is1} chosen for alignment")
        
        elif is3 == 0:
            # Edge alignment
            c = 0.5 * (positions[is1-1] + positions[is2-1])
            dist = np.linalg.norm(positions[is1-1] - positions[is2-1])
            logging.info(f"Edge between {is1} and {is2} chosen, distance: {dist:.4f}")
        
        else:
            # Ring center alignment
            c = self._find_ring_center(is1, is2, is3)
            if c is None:
                logging.info("Ring not found, using vertex alignment")
                c = positions[is1-1]
        
        # Normalize vector
        c = c / np.linalg.norm(c)
        
        # Create rotation matrix to align c with z-axis
        z_axis = np.array([0, 0, 1])
        
        if np.allclose(c, z_axis):
            rotation = np.eye(3)
        else:
            v = np.cross(c, z_axis)
            s = np.linalg.norm(v)
            c_dot = np.dot(c, z_axis)
            
            # Rodrigues rotation formula
            vx = np.array([[0, -v[2], v[1]],
                          [v[2], 0, -v[0]],
                          [-v[1], v[0], 0]])
            
            rotation = np.eye(3) + vx + np.dot(vx, vx) * ((1 - c_dot) / (s * s))
        
        # Apply rotation
        aligned = np.dot(centered, rotation.T)
        
        return aligned, rotation
    
    def _find_ring_center(self, is1, is2, is3):
        """Find ring center containing three atoms (Fortran lines 80-130)"""
        # Check pentagons
        for i, ring in enumerate(self.n5m):
            if (is1-1 in ring and is2-1 in ring and is3-1 in ring):
                return self.cr5[i].copy()
        
        # Check hexagons
        for i, ring in enumerate(self.n6m):
            if (is1-1 in ring and is2-1 in ring and is3-1 in ring):
                return self.cr6[i].copy()
        
        return None
    
    def _sort_by_z(self, positions):
        """Sort vertices by z-coordinate (Fortran lines 160-190)"""
        n = len(positions)
        indices = list(range(n))
        
        # Sort by z-coordinate descending
        indices.sort(key=lambda i: -positions[i, 2])
        
        sorted_positions = positions[indices].copy()
        return sorted_positions, indices
    
    def _perspective_projection(self, positions, angle=30.0):
        """Perspective projection (Fortran lines 300-340)"""
        x, y, z = positions[:, 0], positions[:, 1], positions[:, 2]
        
        z_max = np.max(z)
        z_min = np.min(z)
        rmin = np.max(np.linalg.norm(positions, axis=1))
        
        # Set projection point
        if angle == 0:
            scale = 0.45
            app = scale * rmin + z_max
        else:
            app = angle + z_max
        
        zproj = app - z_min
        
        # Project
        factor = zproj / (app - z)
        x_proj = x * factor
        y_proj = y * factor
        
        return np.column_stack([x_proj, y_proj]), app
    
    def _cone_projection(self, positions, angle=30.0, boost=1.0, eps=1e-8):
        """Cone projection (Fortran lines 210-270)"""
        x, y, z = positions[:, 0], positions[:, 1], positions[:, 2]
        rmin = np.max(np.linalg.norm(positions, axis=1))
        
        app = rmin + np.max(z)
        sfac = np.tan(np.radians(angle))
        
        r_xy = np.sqrt(x**2 + y**2)
        factor = np.zeros_like(r_xy)
        
        mask = r_xy > eps
        factor[mask] = (app - z[mask]) / r_xy[mask] * sfac
        factor[~mask] = 1.0
        
        # Extra boost for last ring points
        n_atoms = len(positions)
        i_boost = int(n_atoms - boost)
        if i_boost > 0:
            factor[i_boost:] *= boost
        
        x_proj = x * factor
        y_proj = y * factor
        
        return np.column_stack([x_proj, y_proj]), factor
    
    def _projection_method(self, positions, method, is1, is2, is3, 
                          angle, boost, epsf):
        """Combined projection method handler"""
        # Align structure
        aligned, rotation = self._align_for_schlegel(positions, is1, is2, is3)
        
        # Sort by z-coordinate
        sorted_pos, sort_idx = self._sort_by_z(aligned)
        
        # Rotate to put an edge of last ring at bottom
        last_ring_idx = len(self.n5m) + len(self.n6m) - 1
        if last_ring_idx >= 0:
            sorted_pos = self._rotate_last_ring_edge(sorted_pos, last_ring_idx)
        
        # Apply projection
        if method == 1:
            layout, _ = self._perspective_projection(sorted_pos, angle)
        else:
            layout, _ = self._cone_projection(sorted_pos, angle, boost, epsf)
        
        # Map back to original indices
        final_layout = np.zeros_like(layout)
        for i, idx in enumerate(sort_idx):
            final_layout[idx] = layout[i]
        
        return final_layout
    
    def _rotate_last_ring_edge(self, positions, last_ring_idx):
        """Rotate to put edge of last ring at bottom (Fortran lines 200-250)"""
        # Find shortest edge in last ring
        if last_ring_idx < len(self.n5m):
            ring = self.n5m[last_ring_idx]
        else:
            ring = self.n6m[last_ring_idx - len(self.n5m)]
        
        min_dist = float('inf')
        best_edge = None
        
        for i in range(len(ring)):
            for j in range(i+1, len(ring)):
                dist = np.linalg.norm(positions[ring[i]] - positions[ring[j]])
                if dist < min_dist:
                    min_dist = dist
                    best_edge = (ring[i], ring[j])
        
        if best_edge is None:
            return positions
        
        # Calculate edge midpoint
        i, j = best_edge
        mid = 0.5 * (positions[i] + positions[j])
        
        # Calculate rotation angle
        x, y = mid[0], mid[1]
        angle = np.arctan2(x, y) + np.pi
        
        # Create rotation matrix around z-axis
        cos_a = np.cos(angle)
        sin_a = np.sin(angle)
        rot_z = np.array([[cos_a, -sin_a, 0],
                         [sin_a, cos_a, 0],
                         [0, 0, 1]])
        
        # Apply rotation
        rotated = np.dot(positions, rot_z.T)
        
        return rotated
    
    def _tutte_embedding(self, G, outer_ring):
        """Tutte embedding (barycentric embedding)"""
        n = G.number_of_nodes()
        
        # Position outer ring on a circle
        theta = np.linspace(0, 2*np.pi, len(outer_ring), endpoint=False)
        radius = 10.0
        outer_pos = {
            v: (radius * np.cos(t), radius * np.sin(t))
            for v, t in zip(outer_ring, theta)
        }
        
        # Initialize positions
        pos = {}
        for v in G.nodes():
            if v in outer_ring:
                pos[v] = outer_pos[v]
            else:
                pos[v] = (0.0, 0.0)
        
        # Solve for interior vertices
        interior = [v for v in G.nodes() if v not in outer_ring]
        n_interior = len(interior)
        
        if n_interior == 0:
            return np.array([pos[i] for i in range(n)])
        
        # Build linear system
        A = np.zeros((n_interior, n_interior))
        bx = np.zeros(n_interior)
        by = np.zeros(n_interior)
        
        for i, v in enumerate(interior):
            neighbors = list(G.neighbors(v))
            degree = len(neighbors)
            
            for w in neighbors:
                if w in interior:
                    j = interior.index(w)
                    A[i, j] = -1.0 / degree
                else:
                    bx[i] += pos[w][0] / degree
                    by[i] += pos[w][1] / degree
            A[i, i] = 1.0
        
        # Solve
        try:
            x_interior = np.linalg.solve(A, bx)
            y_interior = np.linalg.solve(A, by)
        except np.linalg.LinAlgError:
            x_interior = np.linalg.lstsq(A, bx, rcond=None)[0]
            y_interior = np.linalg.lstsq(A, by, rcond=None)[0]
        
        # Combine
        layout = np.zeros((n, 2))
        for v in outer_ring:
            layout[v] = pos[v]
        for i, v in enumerate(interior):
            layout[v] = [x_interior[i], y_interior[i]]
        
        return layout
    
    def _find_outer_ring(self, G, is1, is2, is3, default_size=5):
        """Find outer ring for Tutte embedding (Fortran lines 380-440)"""
        if is1 <= 0 or is2 <= 0 or is3 <= 0:
            # Take first pentagon
            if len(self.n5m) > 0:
                return self.n5m[0], 5
            return None, 0
        
        # Find ring containing is1, is2, is3
        for ring in self.n5m:
            if (is1-1 in ring and is2-1 in ring and is3-1 in ring):
                return ring, 5
        
        for ring in self.n6m:
            if (is1-1 in ring and is2-1 in ring and is3-1 in ring):
                return ring, 6
        
        return None, 0
    
    def _compute_distance_matrix(self, G):
        """Compute distance matrix for graph"""
        n = G.number_of_nodes()
        dist_matrix = np.zeros((n, n), dtype=int)
        
        for i in range(n):
            lengths = nx.single_source_shortest_path_length(G, i)
            for j, d in lengths.items():
                dist_matrix[i, j] = d
        
        return dist_matrix
    
    def _spring_embedding(self, G, outer_ring, with_coulomb=False):
        """Spring embedding (Fortran func2d/dfunc2d with IOP=1,2)"""
        n = G.number_of_nodes()
        
        # Initial layout from Tutte
        layout = self._tutte_embedding(G, outer_ring)
        
        # Energy minimization
        r = 2.0  # desired bond length
        f = 0.1  # force constant
        
        def energy(x):
            x = x.reshape(-1, 2)
            e = 0
            for i in range(n):
                for j in range(i+1, n):
                    if self.adjacency[i, j]:
                        dist = np.linalg.norm(x[i] - x[j])
                        e += (dist - r)**2
            e *= f
            
            if with_coulomb:
                for i in range(n):
                    if i not in outer_ring:
                        rv = np.linalg.norm(x[i])
                        if rv > 0:
                            e += 0.3 / rv
            return e
        
        def gradient(x):
            x = x.reshape(-1, 2)
            grad = np.zeros_like(x)
            
            for i in range(n):
                if i in outer_ring:
                    continue
                
                for j in range(n):
                    if i != j and self.adjacency[i, j]:
                        vec = x[i] - x[j]
                        dist = np.linalg.norm(vec)
                        if dist > 0:
                            grad[i] += 2 * f * (dist - r) * vec / dist
                
                if with_coulomb and i not in outer_ring:
                    rv = np.linalg.norm(x[i])
                    if rv > 0:
                        grad[i] -= 0.3 * x[i] / (rv**3)
            
            return grad.flatten()
        
        # Optimize
        result = minimize(energy, layout.flatten(), method='BFGS',
                         jac=gradient, options={'maxiter': 100})
        
        return result.x.reshape(-1, 2)
    
    def _ppg_embedding(self, G, outer_ring, dist_matrix, maxd, scale_ppg):
        """Pisanski-Plestenjak-Graovac embedding (Fortran IOP=3)"""
        n = G.number_of_nodes()
        
        # Initial layout from Tutte
        layout = self._tutte_embedding(G, outer_ring)
        
        rpermax = float(maxd)
        af = scale_ppg * (1.4 + rpermax / 24.0)
        
        def energy(x):
            x = x.reshape(-1, 2)
            e = 0
            
            for i in range(n):
                if i in outer_ring:
                    continue
                    
                maxu = min(dist_matrix[i, list(outer_ring)])
                
                for j in range(n):
                    if j > i and self.adjacency[i, j]:
                        maxp = min(dist_matrix[j, list(outer_ring)])
                        vec = x[i] - x[j]
                        dist2 = np.dot(vec, vec)
                        dup = 2*maxd - maxu - maxp
                        weight = np.exp(af * dup / rpermax)
                        e += dist2 * weight
            
            return e
        
        def gradient(x):
            x = x.reshape(-1, 2)
            grad = np.zeros_like(x)
            
            for i in range(n):
                if i in outer_ring:
                    continue
                    
                maxu = min(dist_matrix[i, list(outer_ring)])
                
                for j in range(n):
                    if i != j and self.adjacency[i, j]:
                        maxp = min(dist_matrix[j, list(outer_ring)])
                        vec = x[i] - x[j]
                        dup = 2*maxd - maxu - maxp
                        weight = np.exp(af * dup / rpermax)
                        grad[i] += 2 * vec * weight
            
            return grad.flatten()
        
        # Optimize
        result = minimize(energy, layout.flatten(), method='BFGS',
                         jac=gradient, options={'maxiter': 100})
        
        return result.x.reshape(-1, 2)
    
    def _kamada_kawai_embedding(self, G, dist_matrix, fscale):
        """Kamada-Kawai embedding (Fortran IOP=4)"""
        n = G.number_of_nodes()
        
        # Initial random layout
        layout = np.random.randn(n, 2) * 5
        
        r = 2.0  # desired bond length
        f = 0.1  # force constant
        
        def energy(x):
            x = x.reshape(-1, 2)
            e = 0
            
            for i in range(n):
                for j in range(i+1, n):
                    dd = float(dist_matrix[i, j])
                    vec = x[i] - x[j]
                    dist = np.linalg.norm(vec)
                    e += ((dist - fscale * dd) / dd)**2
            
            return f * e
        
        def gradient(x):
            x = x.reshape(-1, 2)
            grad = np.zeros_like(x)
            
            for i in range(n):
                for j in range(n):
                    if i != j:
                        dd = float(dist_matrix[i, j])
                        vec = x[i] - x[j]
                        dist = np.linalg.norm(vec)
                        if dist > 0:
                            grad[i] += 2 * f * (dist - fscale * dd) * vec / (dist * dd * dd)
            
            return grad.flatten()
        
        # Optimize
        result = minimize(energy, layout.flatten(), method='BFGS',
                         jac=gradient, options={'maxiter': 100})
        
        return result.x.reshape(-1, 2)
    
    def _embedding_method_old(self, G, method_idx, is1, is2, is3, fscale, scale_ppg, outer_ring_size=5):
        """Handle graph embedding methods (Fortran lines 350-480)"""
        
        # Find outer ring
        outer_ring, lring = self._find_outer_ring(G, is1, is2, is3)
        if outer_ring is None:
            logging.info(f"No outer ring found, using first ring of size {outer_ring_size}")
            # Try to find a ring of specified size
            if outer_ring_size == 5 and len(self.n5m) > 0:
                outer_ring = self.n5m[0]
                lring = 5
            elif outer_ring_size == 6 and len(self.n6m) > 0:
                outer_ring = self.n6m[0]
                lring = 6
            else:
                # Ultimate fallback: use first pentagon
                if len(self.n5m) > 0:
                    outer_ring = self.n5m[0]
                    lring = 5
                else:
                    raise ValueError("No rings found")
        
        self.outer_ring_indices = list(outer_ring)
        
        # Compute distance matrix if needed
        dist_matrix = None
        maxd = None
        if method_idx >= 2:  # methods needing distance matrix
            dist_matrix = self._compute_distance_matrix(G)
            maxd = np.max(dist_matrix)
        
        # Select embedding method
        if method_idx == 1:
            # Basic Tutte embedding
            layout = self._tutte_embedding(G, outer_ring)
            
            # Radial scaling if fscale > 0
            if fscale > 0:
                layout = self._scale_tutte(layout, outer_ring, fscale)
        
        elif method_idx == 2:
            # Spring embedding
            layout = self._spring_embedding(G, outer_ring, with_coulomb=False)
        
        elif method_idx == 3:
            # Spring + Coulomb embedding
            layout = self._spring_embedding(G, outer_ring, with_coulomb=True)
        
        elif method_idx == 4:
            # PPG embedding
            if dist_matrix is None or maxd is None:
                dist_matrix = self._compute_distance_matrix(G)
                maxd = np.max(dist_matrix)
            layout = self._ppg_embedding(G, outer_ring, dist_matrix, maxd, scale_ppg)
        
        elif method_idx == 5:
            # Kamada-Kawai embedding
            if dist_matrix is None:
                dist_matrix = self._compute_distance_matrix(G)
            layout = self._kamada_kawai_embedding(G, dist_matrix, fscale)
        
        else:
            raise ValueError(f"Unknown embedding method: {method_idx}")
        
        # Shift to barycenter of outer ring
        center = np.mean(layout[list(outer_ring)], axis=0)
        layout = layout - center
        
        return layout

    def _embedding_method(self, G, method_idx, is1, is2, is3, fscale, scale_ppg, outer_ring_size=5):
        """Handle graph embedding methods (Fortran lines 350-480)"""
        
        # Find outer ring
        outer_ring, lring = self._find_outer_ring(G, is1, is2, is3)
        if outer_ring is None:
            logging.info(f"No outer ring found, using first ring of size {outer_ring_size}")
            # Try to find a ring of specified size
            if outer_ring_size == 5 and len(self.n5m) > 0:
                outer_ring = self.n5m[0]
                lring = 5
            elif outer_ring_size == 6 and len(self.n6m) > 0:
                outer_ring = self.n6m[0]
                lring = 6
            else:
                # Ultimate fallback: use first pentagon
                if len(self.n5m) > 0:
                    outer_ring = self.n5m[0]
                    lring = 5
                else:
                    raise ValueError("No rings found")
        
        self.outer_ring_indices = list(outer_ring)
        
        # Compute distance matrix if needed
        dist_matrix = None
        maxd = None
        if method_idx >= 2:  # methods needing distance matrix
            dist_matrix = self._compute_distance_matrix(G)
            maxd = np.max(dist_matrix)
        
        # Select embedding method
        if method_idx == 1:
            # Basic Tutte embedding
            layout = self._tutte_embedding(G, outer_ring)
            
            # Radial scaling if fscale > 0
            if fscale > 0:
                layout = self._scale_tutte(layout, outer_ring, fscale)
        
        elif method_idx == 2:
            # Spring embedding
            layout = self._spring_embedding(G, outer_ring, with_coulomb=False)
        
        elif method_idx == 3:
            # Spring + Coulomb embedding
            layout = self._spring_embedding(G, outer_ring, with_coulomb=True)
        
        elif method_idx == 4:
            # PPG embedding
            if dist_matrix is None or maxd is None:
                dist_matrix = self._compute_distance_matrix(G)
                maxd = np.max(dist_matrix)
            layout = self._ppg_embedding(G, outer_ring, dist_matrix, maxd, scale_ppg)
        
        elif method_idx == 5 or method_idx == 6:  # FIX: Handle both 5 and 6 for Kamada-Kawai
            # Kamada-Kawai embedding
            if dist_matrix is None:
                dist_matrix = self._compute_distance_matrix(G)
            layout = self._kamada_kawai_embedding(G, dist_matrix, fscale)
        
        else:
            raise ValueError(f"Unknown embedding method: {method_idx}")
        
        # Shift to barycenter of outer ring
        center = np.mean(layout[list(outer_ring)], axis=0)
        layout = layout - center
        
        return layout

    def _scale_tutte(self, layout, outer_ring, fs):
        """Linear scaling of Tutte graph (Fortran ScaleTutte)"""
        # Find minimum distance of outer ring
        rmin = float('inf')
        for i in outer_ring:
            r = np.linalg.norm(layout[i])
            rmin = min(rmin, r)
        
        # Scale interior vertices
        scaled = layout.copy()
        for i in range(len(layout)):
            if i not in outer_ring:
                r = np.linalg.norm(layout[i])
                if rmin > 0:
                    scale = 1.0 + 0.5 * fs * (rmin - r) / rmin
                    scaled[i] = layout[i] * scale
        
        return scaled
    
    def project_rings(self):
        """Project ring centers to 2D"""
        if self.layout_2d is None:
            return None
        
        ring_centers = []
        for ring in self.n5m + self.n6m:
            center = np.mean(self.layout_2d[ring], axis=0)
            ring_centers.append(center)
        
        self.rings_2d = np.array(ring_centers)
        return self.rings_2d
    
    def draw_schlegel(self, figsize=(10, 10), show_atoms=True, show_rings=True,
                     atom_color='blue', ring_colors=None, bond_color='gray',
                     atom_size=100, show_indices=False):
        """
        Draw Schlegel diagram with matplotlib
        
        Args:
            figsize: figure size in inches
            show_atoms: whether to show atoms
            show_rings: whether to show ring centers
            atom_color: color for atoms
            ring_colors: colors for rings (dict with 'P' and 'H' colors)
            bond_color: color for bonds
            atom_size: size of atom markers
            show_indices: show atom indices as text
        
        Returns:
            matplotlib figure and axis
        """
        if self.layout_2d is None:
            raise ValueError("No layout generated")
        
        fig, ax = plt.subplots(figsize=figsize)
        
        # Draw bonds
        if bond_color is not None and hasattr(self, 'adjacency') and self.adjacency is not None:
            n = len(self.layout_2d)
            for i in range(n):
                for j in range(i+1, n):
                    if self.adjacency[i, j]:
                        ax.plot([self.layout_2d[i, 0], self.layout_2d[j, 0]],
                               [self.layout_2d[i, 1], self.layout_2d[j, 1]],
                               color=bond_color, linewidth=1, alpha=0.5, zorder=1)
        
        # Draw atoms
        if show_atoms:
            ax.scatter(self.layout_2d[:, 0], self.layout_2d[:, 1],
                      c=atom_color, s=atom_size, edgecolors='black',
                      linewidth=0.5, zorder=2)
            
            if show_indices:
                for i in range(len(self.layout_2d)):
                    ax.annotate(str(i+1), (self.layout_2d[i, 0], self.layout_2d[i, 1]),
                               fontsize=6, ha='center', va='center')
        
        # Draw rings
        if show_rings and self.rings_2d is not None:
            if ring_colors is None:
                ring_colors = {'P': 'red', 'H': 'green'}
            
            for i, center in enumerate(self.rings_2d):
                if i < len(self.n5m):
                    color = ring_colors['P']
                    marker = '^'  # triangle for pentagon
                else:
                    color = ring_colors['H']
                    marker = 's'  # square for hexagon
                
                ax.scatter(center[0], center[1], c=color, marker=marker,
                          s=atom_size*1.5, edgecolors='black', linewidth=0.5,
                          zorder=3)
        
        ax.set_aspect('equal')
        ax.axis('off')
        
        return fig, ax
    
    def to_qpixmap(self, width=800, height=600, **kwargs):
        """Convert current Schlegel diagram to QPixmap"""
        fig, ax = self.draw_schlegel(figsize=(width/100, height/100), **kwargs)
        
        fig.tight_layout(pad=0)
        
        # Save to buffer
        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=100, bbox_inches='tight',
                   facecolor='white', edgecolor='none')
        buf.seek(0)
        
        # Create QPixmap
        pixmap = QPixmap()
        pixmap.loadFromData(buf.getvalue(), 'PNG')
        
        plt.close(fig)
        
        return pixmap
    
    def get_analysis(self):
        """Get structural analysis of Schlegel diagram"""
        if self.layout_2d is None:
            return {}
        
        analysis = {
            'n_atoms': len(self.layout_2d),
            'n_pentagons': len(self.n5m),
            'n_hexagons': len(self.n6m),
            'diagram_type': 'Schlegel'
        }
        
        if self.outer_ring_indices is not None:
            analysis['outer_ring_size'] = len(self.outer_ring_indices)
        
        # Calculate metrics
        coords = self.layout_2d
        center = np.mean(coords, axis=0)
        radii = np.linalg.norm(coords - center, axis=1)
        
        analysis['avg_radius'] = float(np.mean(radii))
        analysis['max_radius'] = float(np.max(radii))
        analysis['min_radius'] = float(np.min(radii))
        
        return analysis


class SchlegelVisualizer:
    """High-level interface for Schlegel diagram visualization"""
    
    def __init__(self):
        self.diagram = SchlegelDiagram()
        self.current_positions = None
    
    def visualize(self, positions, method=1, **kwargs):
        """
        Generate and return Schlegel diagram pixmap
        
        Args:
            positions: 3D coordinates (N x 3)
            method: 1-8 (see SchlegelDiagram.generate_from_positions)
            **kwargs: additional arguments including:
                - outer_ring_size: size of outer ring (5 or 6)
                - projection_angle: angle for projection methods
                - boost: boost factor for cone projection
                - fscale: scale factor for Tutte methods
                - scale_ppg: scale factor for PPG method
                - is1, is2, is3: alignment indices
                - show_atoms, show_rings, show_bonds: display options
                - size: tuple (width, height) for output image
        
        Returns:
            QPixmap of Schlegel diagram
        """
        self.current_positions = positions
        
        # Generate layout with all parameters
        self.diagram.generate_from_positions(
            positions, 
            method=method,
            outer_ring_size=kwargs.get('outer_ring_size', 5),
            projection_angle=kwargs.get('projection_angle', 30.0),
            boost=kwargs.get('boost', 1.0),
            fscale=kwargs.get('fscale', 1.0),
            scale_ppg=kwargs.get('scale_ppg', 1.0),
            is1=kwargs.get('is1', 0),
            is2=kwargs.get('is2', 0),
            is3=kwargs.get('is3', 0)
        )
        
        # Project rings
        self.diagram.project_rings()
        
        # Generate pixmap with display options
        size = kwargs.get('size', (800, 600))
        show_atoms = kwargs.get('show_atoms', True)
        show_rings = kwargs.get('show_rings', True)
        show_bonds = kwargs.get('show_bonds', True)
        show_indices = kwargs.get('show_indices', False)
        
        return self.diagram.to_qpixmap(
            width=size[0], height=size[1],
            show_atoms=show_atoms, show_rings=show_rings,
            bond_color='gray' if show_bonds else None,
            atom_color=kwargs.get('atom_color', 'blue'),
            show_indices=show_indices
        )
    
    def get_analysis(self):
        """Get analysis of current Schlegel diagram"""
        return self.diagram.get_analysis()