-- ADOBMD File Parser in LuaJIT
-- Simplified version with all functions exposed globally

function trim(s)
    if not s then return "" end
    return (s:gsub("^%s+", ""):gsub("%s+$", ""))
end

function parse_counts(line)
    local counts = {}
    for num, key in line:gmatch("(%S+)%s+(%S+)") do
        counts[key] = tonumber(num)
    end
    return counts
end

function parse_box(line)
    local lo, hi = line:match("(%S+)%s+(%S+)%s+xlo xhi")
    if lo and hi then
        return {tonumber(lo), tonumber(hi)}
    end
    return nil
end

function parse_atom(line)
    local id, mol, type_id, charge, x, y, z, region = 
        line:match("(%d+)%s+(%d+)%s+(%d+)%s+(%S+)%s+(%S+)%s+(%S+)%s+(%S+)%s*(%S*)")
    
    if id and mol and type_id and charge and x and y and z then
        local atom = {
            id = tonumber(id),
            molecule = tonumber(mol),
            type_id = tonumber(type_id),
            charge = tonumber(charge),
            x = tonumber(x),
            y = tonumber(y),
            z = tonumber(z),
            is_qm = false
        }
        
        if region and (region:upper() == "QM" or region:upper() == "Q") then
            atom.is_qm = true
        end
        
        return atom
    end
    return nil
end

function parse_bond(line)
    local id, type_id, a1, a2 = line:match("(%d+)%s+(%d+)%s+(%d+)%s+(%d+)")
    
    if id and type_id and a1 and a2 then
        return {
            id = tonumber(id),
            type_id = tonumber(type_id),
            atom1 = tonumber(a1),
            atom2 = tonumber(a2)
        }
    end
    return nil
end

function parse_adobmd(content)
    if not content then return {} end
    
    local data = {
        atoms = {},
        bonds = {},
        qm_indices = {},
        has_qm = false,
        has_box = false,
        box_lo = {0, 0, 0},
        box_hi = {0, 0, 0},
        counts = {}
    }
    
    local lines = {}
    for line in content:gmatch("[^\n]+") do
        table.insert(lines, line)
    end
    
    local i = 1
    local n_lines = #lines
    
    -- Skip comments
    while i <= n_lines do
        local line = lines[i]
        if line and line:match("^#") then
            i = i + 1
        else
            break
        end
    end
    
    -- Parse counts and box
    while i <= n_lines do
        local line = trim(lines[i])
        if line == "" then
            i = i + 1
        elseif line:match("atoms$") then
            local counts = parse_counts(line)
            if counts.atoms then
                data.counts.atoms = counts.atoms
            end
            i = i + 1
        elseif line:match("bonds$") then
            local counts = parse_counts(line)
            if counts.bonds then
                data.counts.bonds = counts.bonds
            end
            i = i + 1
        elseif line:match("xlo xhi") then
            local box = parse_box(line)
            if box then
                data.has_box = true
                data.box_lo[1] = box[1]
                data.box_hi[1] = box[2]
            end
            i = i + 1
        elseif line:match("ylo yhi") then
            local box = parse_box(line)
            if box then
                data.box_lo[2] = box[1]
                data.box_hi[2] = box[2]
            end
            i = i + 1
        elseif line:match("zlo zhi") then
            local box = parse_box(line)
            if box then
                data.box_lo[3] = box[1]
                data.box_hi[3] = box[2]
            end
            i = i + 1
        elseif line == "Atoms" then
            i = i + 1
            break
        else
            i = i + 1
        end
    end
    
    -- Parse atoms
    local expected_atoms = data.counts.atoms or 0
    local atom_count = 0
    
    while i <= n_lines and atom_count < expected_atoms do
        local line = trim(lines[i])
        if line ~= "" and not line:match("^#") then
            local atom = parse_atom(line)
            if atom then
                table.insert(data.atoms, atom)
                if atom.is_qm then
                    table.insert(data.qm_indices, atom.id)
                    data.has_qm = true
                end
                atom_count = atom_count + 1
            end
        end
        i = i + 1
    end
    
    -- Parse bonds
    local expected_bonds = data.counts.bonds or 0
    local bond_count = 0
    
    while i <= n_lines and bond_count < expected_bonds do
        local line = trim(lines[i])
        if line ~= "" and not line:match("^#") then
            local bond = parse_bond(line)
            if bond then
                table.insert(data.bonds, bond)
                bond_count = bond_count + 1
            end
        end
        i = i + 1
    end
    
    return data
end