-- Serialize parsed data for Python consumption

function serialize_result(data)
    if not data then return {} end
    
    local result = {
        natoms = #data.atoms,
        nbonds = #data.bonds,
        has_box = data.has_box,
        has_qm = data.has_qm,
        box_lo = data.box_lo,
        box_hi = data.box_hi,
        atoms = {},
        bonds = {}
    }
    
    -- Convert atoms
    for _, atom in ipairs(data.atoms) do
        table.insert(result.atoms, {
            id = atom.id,
            type_id = atom.type_id,
            molecule = atom.molecule,
            element = get_element(atom.type_id),
            x = atom.x,
            y = atom.y,
            z = atom.z,
            charge = atom.charge,
            is_qm = atom.is_qm and 1 or 0
        })
    end
    
    -- Convert bonds
    for _, bond in ipairs(data.bonds) do
        table.insert(result.bonds, {
            id = bond.id,
            type_id = bond.type_id,
            atom1 = bond.atom1,
            atom2 = bond.atom2
        })
    end
    
    return result
end