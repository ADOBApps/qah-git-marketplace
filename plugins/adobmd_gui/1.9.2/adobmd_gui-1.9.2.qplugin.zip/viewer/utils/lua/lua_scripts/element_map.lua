-- Element type mapping for ADOBMD

-- Global table
element_map = {
    -- Carbon allotropes
    [1] = "C",   -- sp3 carbon
    [2] = "C",   -- sp2 carbon
    [3] = "C",   -- aromatic carbon
    
    -- Common elements
    [4] = "H",
    [5] = "N",
    [6] = "O",
    [7] = "F",
    [8] = "Cl",
    [9] = "Br",
    [10] = "I",
    [11] = "S",
    [12] = "P",
    
    -- Metals
    [13] = "Fe",
    [14] = "Cu",
    [15] = "Zn",
    [16] = "Au",
    [17] = "Ag",
    
    -- Default
    [0] = "X"
}

-- Global function
function get_element(type_id)
    return element_map[type_id] or "X"
end

-- Verify function exists
_G["get_element"] = get_element