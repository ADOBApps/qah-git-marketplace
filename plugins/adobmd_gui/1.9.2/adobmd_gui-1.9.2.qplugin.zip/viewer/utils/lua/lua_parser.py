"""
lua_parser.py - Ultra-fast ADOBMD parser using LuaJIT bridge
Uses LuaJIT's JIT compilation for lightning-fast text processing
External Lua scripts for better maintainability
"""

import os
import numpy as np
from pathlib import Path
from typing import Optional, Dict, List, Tuple
import time
import re
import json

# Import the LuaJIT bridge
try:
    from plugins.libs.lua.luajit_bridge import get_luajit_bridge
    LUAJIT_AVAILABLE = True
    print("[LuaJIT] Bridge module found")
except ImportError as e:
    LUAJIT_AVAILABLE = False
    print(f"[Warning] LuaJIT bridge not available: {e}")

# Import the ADOBMD data structures
try:
    from ...utils.data_parser import ADOBMDData, Atom, Bond
except ImportError:
    from dataclasses import dataclass
    from typing import List, Tuple
    
    @dataclass
    class Atom:
        id: int
        type_id: int
        molecule: int
        element: str
        x: float
        y: float
        z: float
        charge: float
        is_qm: bool = False
    
    @dataclass
    class Bond:
        id: int
        type_id: int
        atom1: int
        atom2: int
        order: int = 1
    
    class ADOBMDData:
        def __init__(self):
            self.filename = ""
            self.atoms = []
            self.bonds = []
            self.qm_indices = []
            self.has_qm_region = False
            self.has_box = False
            self.box_lo = [0.0, 0.0, 0.0]
            self.box_hi = [0.0, 0.0, 0.0]
            self.natoms = 0
            self.nbonds = 0

ELEMENT_COLORS = {
    'H': (1.0, 1.0, 1.0),    # White
    'C': (0.2, 0.2, 0.2),    # Dark gray
    'N': (0.0, 0.0, 1.0),    # Blue
    'O': (1.0, 0.0, 0.0),    # Red
    'F': (0.0, 1.0, 0.0),    # Green
    'Cl': (0.0, 1.0, 0.0),   # Green
    'Br': (0.5, 0.2, 0.0),   # Brown
    'I': (0.6, 0.0, 0.8),    # Purple
    'S': (1.0, 1.0, 0.0),    # Yellow
    'P': (1.0, 0.5, 0.0),    # Orange
    'Si': (0.5, 0.5, 0.5),   # Gray
    'Fe': (1.0, 0.5, 0.0),   # Orange-brown
    'Cu': (0.8, 0.5, 0.2),   # Copper
    'Zn': (0.6, 0.6, 0.8),   # Light blue-gray
    'Au': (1.0, 0.8, 0.0),   # Gold
    'Ag': (0.8, 0.8, 0.8),   # Silver
    'X': (0.7, 0.7, 0.7),    # Default gray
}

ELEMENT_RADII = {
    'H': 0.3, 'C': 0.7, 'N': 0.65, 'O': 0.6, 'F': 0.5,
    'Cl': 1.0, 'Br': 1.15, 'I': 1.4, 'S': 1.0, 'P': 1.0,
    'Si': 1.1, 'Fe': 1.4, 'Cu': 1.4, 'Zn': 1.4, 'Au': 1.5,
    'Ag': 1.5, 'X': 0.7,
}

QM_COLOR = (1.0, 0.2, 0.2)    # Red for QM
MM_COLOR = (0.2, 0.6, 1.0)    # Blue for MM

class LuaADOBMDParser:
    """
    Ultra-fast ADOBMD parser using LuaJIT
    Leverages JIT compilation for maximum performance
    External Lua scripts for maintainability
    """
    
    def __init__(self):
        """Initialize LuaJIT parser"""
        self.bridge = None
        self.lua_state = None
        self._initialized = False
        
        # Find Lua scripts directory
        self.script_dir = Path(__file__).parent / "lua_scripts"
        
        print("[LuaJIT] Initializing parser...")
        
        if not LUAJIT_AVAILABLE:
            print("[Error] LuaJIT bridge not available")
            return
        
        try:
            print("[LuaJIT] Getting bridge...")
            self.bridge = get_luajit_bridge()
            if not self.bridge:
                print("[Error] Failed to get LuaJIT bridge")
                return
            print("[LuaJIT] Bridge obtained")
            
            print("[LuaJIT] Initializing Lua state...")
            self.lua_state = self.bridge.init()
            if not self.lua_state:
                print("[Error] Failed to initialize Lua state")
                return
            print("[LuaJIT] Lua state initialized")
            
            # Load Lua scripts
            print("[LuaJIT] Loading Lua scripts...")
            if not self._load_lua_scripts():
                print("[Error] Failed to load Lua scripts")
                return
            
            print("[LuaJIT] Parser loaded successfully")
            
            self._initialized = True
            print("[Ok] LuaJIT ADOBMD parser initialized successfully")
            
        except Exception as e:
            print(f"[Error] LuaJIT parser initialization failed: {e}")
            import traceback
            traceback.print_exc()
            self._initialized = False
    
    def _load_lua_script(self, filename: str) -> bool:
        """Load a single Lua script file"""
        script_path = self.script_dir / filename
        if not script_path.exists():
            print(f"[Error] Lua script not found: {script_path}")
            return False
        
        try:
            with open(script_path, 'r', encoding='utf-8') as f:
                script_content = f.read()
            
            success = self.bridge.execute_script(self.lua_state, script_content)
            if not success:
                error = self.bridge.get_last_error(self.lua_state)
                print(f"[Error] Failed to load {filename}: {error}")
                return False
            
            print(f"[LuaJIT] Loaded: {filename}")
            return True
            
        except Exception as e:
            print(f"[Error] Failed to read {filename}: {e}")
            return False
    
    def _load_lua_scripts(self) -> bool:
        """Load all Lua scripts in order"""
        # Load in dependency order
        scripts = [
            "element_map.lua",      # First: element mapping
            "adobmd_parser.lua",    # Second: parser functions
            "result_serializer.lua" # Third: result serializer
        ]
        
        for script in scripts:
            if not self._load_lua_script(script):
                return False
        
        # Verify functions are loaded - use numeric returns for boolean
        print("[LuaJIT] Verifying functions...")
        
        # Check parse_adobmd - return 1 if exists, 0 otherwise
        self.bridge.execute_script(self.lua_state, 
            "_test_parse = (type(parse_adobmd) == 'function') and 1 or 0")
        test_parse = self._get_global_int("_test_parse")
        print(f"[LuaJIT] parse_adobmd loaded: {test_parse == 1}")
        
        # Check get_element
        self.bridge.execute_script(self.lua_state, 
            "_test_element = (type(get_element) == 'function') and 1 or 0")
        test_element = self._get_global_int("_test_element")
        print(f"[LuaJIT] get_element loaded: {test_element == 1}")
        
        # Check serialize_result
        self.bridge.execute_script(self.lua_state, 
            "_test_serialize = (type(serialize_result) == 'function') and 1 or 0")
        test_serialize = self._get_global_int("_test_serialize")
        print(f"[LuaJIT] serialize_result loaded: {test_serialize == 1}")
        
        # List all functions for debugging
        self.bridge.execute_script(self.lua_state, """
            local funcs = {}
            for k, v in pairs(_G) do
                if type(v) == 'function' then
                    table.insert(funcs, k)
                end
            end
            _G["_loaded_functions"] = table.concat(funcs, ", ")
        """)
        loaded_funcs = self.bridge.get_global_string(self.lua_state, "_loaded_functions")
        print(f"[LuaJIT] Loaded functions: {loaded_funcs}")
        
        if test_parse != 1:
            print("[Error] parse_adobmd not loaded correctly")
            return False
        
        print("[Ok] All Lua functions loaded successfully")
        return True
    
    def parse_file(self, filepath: str) -> Optional[ADOBMDData]:
        """
        Parse ADOBMD file using LuaJIT
        """
        if not self._initialized:
            print("[Error] Parser not initialized")
            return None
        
        if not os.path.exists(filepath):
            print(f"[Error] File not found: {filepath}")
            return None
        
        start_time = time.time()
        
        try:
            # Read file content
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            
            print(f"[LuaJIT] Parsing file: {os.path.basename(filepath)} ({len(content)} bytes)")
            
            # Escape content for Lua
            escaped_content = content.replace('\\', '\\\\').replace('`', '\\`')
            
            # Create wrapper that calls parse_adobmd and stores result
            wrapper = f"""
            -- Parse the content
            local content = [==[{escaped_content}]==]
            local data = parse_adobmd(content)
            
            -- Add elements to atoms
            for _, atom in ipairs(data.atoms) do
                atom.element = get_element(atom.type_id)
            end
            
            -- Serialize result
            local result = serialize_result(data)
            
            -- Store individual values in globals
            _G["_parse_natoms"] = result.natoms
            _G["_parse_nbonds"] = result.nbonds
            _G["_parse_has_box"] = result.has_box and 1 or 0
            _G["_parse_has_qm"] = result.has_qm and 1 or 0
            
            if result.has_box then
                _G["_parse_box_lo1"] = result.box_lo[1]
                _G["_parse_box_lo2"] = result.box_lo[2]
                _G["_parse_box_lo3"] = result.box_lo[3]
                _G["_parse_box_hi1"] = result.box_hi[1]
                _G["_parse_box_hi2"] = result.box_hi[2]
                _G["_parse_box_hi3"] = result.box_hi[3]
            end
            
            -- Store atoms
            for i, atom in ipairs(result.atoms) do
                _G["_parse_atom_id_"..i] = atom.id
                _G["_parse_atom_mol_"..i] = atom.molecule
                _G["_parse_atom_type_"..i] = atom.type_id
                _G["_parse_atom_element_"..i] = atom.element
                _G["_parse_atom_charge_"..i] = atom.charge
                _G["_parse_atom_x_"..i] = atom.x
                _G["_parse_atom_y_"..i] = atom.y
                _G["_parse_atom_z_"..i] = atom.z
                _G["_parse_atom_qm_"..i] = atom.is_qm
            end
            
            -- Store bonds
            for i, bond in ipairs(result.bonds) do
                _G["_parse_bond_id_"..i] = bond.id
                _G["_parse_bond_type_"..i] = bond.type_id
                _G["_parse_bond_a1_"..i] = bond.atom1
                _G["_parse_bond_a2_"..i] = bond.atom2
            end
            
            _G["_parse_success"] = 1
            """
            
            # Execute parser
            success = self.bridge.execute_script(self.lua_state, wrapper)
            
            if not success:
                error = self.bridge.get_last_error(self.lua_state)
                print(f"[Error] LuaJIT parser error: {error}")
                return None
            
            # Check success
            parse_success = self._get_global_int("_parse_success")
            if parse_success == 0:
                print("[Error] Parsing failed")
                return None
            
            # Extract data
            natoms = self._get_global_int("_parse_natoms")
            nbonds = self._get_global_int("_parse_nbonds")
            
            if natoms == 0:
                print("[Error] No atoms parsed")
                return None
            
            # Create data object
            data = ADOBMDData()
            data.filename = Path(filepath).name
            
            # Extract atoms
            atoms = []
            for i in range(1, natoms + 1):
                atom_id = self._get_global_int(f"_parse_atom_id_{i}")
                atom_mol = self._get_global_int(f"_parse_atom_mol_{i}")
                atom_type = self._get_global_int(f"_parse_atom_type_{i}")
                element = self._get_global_string(f"_parse_atom_element_{i}")
                atom_charge = self._get_global_float(f"_parse_atom_charge_{i}")
                x = self._get_global_float(f"_parse_atom_x_{i}")
                y = self._get_global_float(f"_parse_atom_y_{i}")
                z = self._get_global_float(f"_parse_atom_z_{i}")
                is_qm = self._get_global_int(f"_parse_atom_qm_{i}") == 1
                # Get color based on element and QM status
                if is_qm:
                    color = QM_COLOR
                elif data.has_qm_region:
                    color = MM_COLOR
                else:
                    color = ELEMENT_COLORS.get(element, (0.7, 0.7, 0.7))

                radius = ELEMENT_RADII.get(element, 0.7)
                atom = Atom(
                    id=atom_id,
                    type_id=atom_type,
                    molecule=atom_mol,
                    element=element,
                    x=x, y=y, z=z,
                    charge=atom_charge,
                    is_qm=is_qm,
                    color=color,
                    radius=radius 
                )
                atoms.append(atom)
                
                if is_qm:
                    data.qm_indices.append(atom_id)
            
            # Extract bonds
            bonds = []
            for i in range(1, nbonds + 1):
                bond_id = self._get_global_int(f"_parse_bond_id_{i}")
                bond_type = self._get_global_int(f"_parse_bond_type_{i}")
                atom1 = self._get_global_int(f"_parse_bond_a1_{i}")
                atom2 = self._get_global_int(f"_parse_bond_a2_{i}")
                
                bond = Bond(
                    id=bond_id,
                    type_id=bond_type,
                    atom1=atom1,
                    atom2=atom2,
                    order=bond_type
                )
                bonds.append(bond)
            
            # Extract box
            has_box = self._get_global_int("_parse_has_box") == 1
            if has_box:
                data.has_box = True
                data.box_lo = [
                    self._get_global_float("_parse_box_lo1"),
                    self._get_global_float("_parse_box_lo2"),
                    self._get_global_float("_parse_box_lo3")
                ]
                data.box_hi = [
                    self._get_global_float("_parse_box_hi1"),
                    self._get_global_float("_parse_box_hi2"),
                    self._get_global_float("_parse_box_hi3")
                ]
            
            data.atoms = atoms
            data.bonds = bonds
            data.natoms = len(atoms)
            data.nbonds = len(bonds)
            data.has_qm_region = len(data.qm_indices) > 0
            
            elapsed = time.time() - start_time
            print(f"LuaJIT parsed {len(atoms)} atoms in {elapsed*1000:.1f}ms")
            
            return data
            
        except Exception as e:
            print(f"[Error] LuaJIT parser exception: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def _get_global_int(self, name: str) -> int:
        """Get integer global from Lua state"""
        try:
            val = self.bridge.get_global_number(self.lua_state, name)
            return int(val) if val is not None else 0
        except:
            return 0
    
    def _get_global_float(self, name: str) -> float:
        """Get float global from Lua state"""
        try:
            val = self.bridge.get_global_number(self.lua_state, name)
            return float(val) if val is not None else 0.0
        except:
            return 0.0
    
    def _get_global_string(self, name: str) -> str:
        """Get string global from Lua state"""
        try:
            val = self.bridge.get_global_string(self.lua_state, name)
            return val if val else ""
        except:
            return ""
    
    def cleanup(self):
        """Clean up Lua state"""
        if self.bridge and self.lua_state:
            self.bridge.close(self.lua_state)
            self.lua_state = None
            self._initialized = False
            print("[Cleanup] LuaJIT parser cleaned up")
    
    def __del__(self):
        self.cleanup()


# Singleton instance
_parser = None

def get_lua_parser() -> Optional[LuaADOBMDParser]:
    """Get or create LuaJIT parser singleton"""
    global _parser
    if _parser is None and LUAJIT_AVAILABLE:
        print("[LuaJIT] Creating parser instance...")
        _parser = LuaADOBMDParser()
    return _parser


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        parser = get_lua_parser()
        if parser:
            data = parser.parse_file(sys.argv[1])
            if data:
                print(f"Success: {data.natoms} atoms, {data.nbonds} bonds")
                if data.atoms:
                    print(f"First atom: {data.atoms[0].element} at ({data.atoms[0].x}, {data.atoms[0].y}, {data.atoms[0].z})")
            else:
                print("Parse failed")
        else:
            print("Parser not available")
    else:
        print("Usage: python lua_parser.py <file.data>")