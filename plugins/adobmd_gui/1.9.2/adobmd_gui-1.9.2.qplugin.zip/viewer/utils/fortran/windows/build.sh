# sudo apt install gfortran-mingw-w64-x86-64

# Build the Fortran source file into an object file with position-independent code
x86_64-w64-mingw32-gfortran -c ../molecular_export_full.f90 -o libmolexport.o -fPIC

# Build the DLL with static linking to the Fortran runtime libraries
x86_64-w64-mingw32-gfortran -shared -o libmolexport.dll libmolexport.o -static-libgfortran -static-libgcc -static -lquadmath

# Verify the DLL was created and check its dependencies
x86_64-w64-mingw32-objdump -p libmolexport.dll | grep "DLL Name"

# Build the Fortran source file into an object file with position-independent code
x86_64-w64-mingw32-gfortran -c ../libadobmd_parser.f90 -o libadobmd_parser.o -fPIC

# Build the DLL with static linking to the Fortran runtime libraries
x86_64-w64-mingw32-gfortran -shared -o libadobmd_parser.dll libadobmd_parser.o -static-libgfortran -static-libgcc -static -lquadmath

# Verify the DLL was created and check its dependencies
x86_64-w64-mingw32-objdump -p libadobmd_parser.dll | grep "DLL Name"
