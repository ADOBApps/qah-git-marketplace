! libadobmd_parser.f90 - Fixed memory management
! Compile: gfortran -shared -fPIC -O3 -o libadobmd_parser.so libadobmd_parser.f90

module adobmd_parser
    use iso_c_binding
    implicit none
    
    ! Constants
    integer, parameter :: MAX_LINE_LEN = 256
    integer, parameter :: MAX_FILENAME_LEN = 256
    
    ! Atom structure (C-compatible)
    type, bind(C) :: atom_t
        integer(c_int) :: id
        integer(c_int) :: type_id
        integer(c_int) :: molecule
        character(c_char) :: element(3)
        real(c_double) :: x, y, z
        real(c_double) :: charge
        integer(c_int) :: is_qm
    end type atom_t
    
    ! Bond structure
    type, bind(C) :: bond_t
        integer(c_int) :: id
        integer(c_int) :: type_id
        integer(c_int) :: atom1
        integer(c_int) :: atom2
        integer(c_int) :: order
    end type bond_t
    
    ! Parser result
    type, bind(C) :: parse_result_t
        integer(c_int) :: natoms
        integer(c_int) :: nbonds
        integer(c_int) :: nqm
        real(c_double) :: box_lo(3)
        real(c_double) :: box_hi(3)
        integer(c_int) :: has_box
        type(c_ptr) :: atoms
        type(c_ptr) :: bonds
        character(c_char) :: filename(MAX_FILENAME_LEN)
    end type parse_result_t
    
contains
    
    ! Helper: Convert C string to Fortran string
    subroutine c_f_string(c_str, f_str)
        character(c_char), intent(in) :: c_str(*)
        character(len=*), intent(out) :: f_str
        integer :: i
        
        f_str = ''
        i = 1
        do while (c_str(i) /= c_null_char .and. i < len(f_str))
            f_str(i:i) = c_str(i)
            i = i + 1
        end do
    end subroutine c_f_string
    
    ! Helper: Convert Fortran string to C string
    subroutine f_c_string(f_str, c_str)
        character(len=*), intent(in) :: f_str
        character(c_char), intent(out) :: c_str(*)
        integer :: i, len_str
        
        len_str = len_trim(f_str)
        do i = 1, len_str
            c_str(i) = f_str(i:i)
        end do
        c_str(len_str + 1) = c_null_char
    end subroutine f_c_string

    ! ------------------------------------------------------------------
    ! Helper: strip anything after '#' and trailing whitespace
    ! ------------------------------------------------------------------
    pure function strip_comment(s) result(out)
        character(len=*), intent(in) :: s
        character(len=len(s)) :: out
        integer :: p
        out = s
        p = index(out, '#')
        if (p > 0) out(p:) = ' '
        out = out(1:len_trim(out))
    end function strip_comment

    ! ------------------------------------------------------------------
    ! Helper: whole-string (trimmed) comparison
    ! ------------------------------------------------------------------
    pure logical function ieq(a, b)
        character(len=*), intent(in) :: a, b
        ieq = (trim(adjustl(a)) == trim(adjustl(b)))
    end function ieq

    ! ------------------------------------------------------------------
    ! Helper: extract the whitespace-delimited token that follows the Nth
    ! integer in `work`. Used by parse_atoms to find the region tag.
    ! ------------------------------------------------------------------
    pure function token_after_n_ints(work, nskip) result(tok)
        character(len=*), intent(in) :: work
        integer,          intent(in) :: nskip
        character(len=32) :: tok

        integer :: p, k, tokens, len_work
        tok = ''
        len_work = len_trim(work)
        p = 1
        tokens = 0
        ! Advance past `nskip` tokens
        do while (p <= len_work .and. tokens < nskip)
            ! skip whitespace
            do while (p <= len_work .and. (work(p:p) == ' ' .or. work(p:p) == char(9)))
                p = p + 1
            end do
            ! skip the token itself
            do while (p <= len_work .and. work(p:p) /= ' ' .and. work(p:p) /= char(9))
                p = p + 1
            end do
            tokens = tokens + 1
        end do
        ! skip whitespace before the next token
        do while (p <= len_work .and. (work(p:p) == ' ' .or. work(p:p) == char(9)))
            p = p + 1
        end do
        if (p > len_work) return
        k = 1
        do while (p <= len_work .and. work(p:p) /= ' ' .and. work(p:p) /= char(9) .and. k <= len(tok))
            tok(k:k) = work(p:p)
            p = p + 1
            k = k + 1
        end do
    end function token_after_n_ints
    
    ! ==================================================================
    ! parse_header — token-based, crash-safe
    ! ==================================================================
    subroutine parse_header(unit, natoms, nbonds, natom_types, has_box, box_lo, box_hi)
        integer, intent(in) :: unit
        integer, intent(out) :: natoms, nbonds, natom_types
        logical, intent(out) :: has_box
        real(8), intent(out) :: box_lo(3), box_hi(3)
        
        character(len=MAX_LINE_LEN) :: line, work
        integer :: ios, lead_val
        real(8) :: v1, v2
        logical :: reading_header
        character(len=MAX_LINE_LEN) :: rest
        integer :: k
        
        natoms = 0; nbonds = 0; natom_types = 0
        has_box = .false.
        box_lo = 0.0d0; box_hi = 0.0d0
        reading_header = .true.
        
        do while (reading_header)
            read(unit, '(A)', iostat=ios) line
            if (ios /= 0) exit
            
            line = adjustl(line)
            if (len_trim(line) == 0) cycle
            if (line(1:1) == '#') cycle
            
            work = strip_comment(line)
            if (len_trim(work) == 0) cycle

            ! --- xlo / ylo / zlo are FLOAT-FIRST lines -----------------
            if (index(work, 'xlo xhi') > 0) then
                read(work, *, iostat=ios) v1, v2
                if (ios == 0) then
                    box_lo(1) = v1; box_hi(1) = v2
                    has_box = .true.
                end if
                cycle
            elseif (index(work, 'ylo yhi') > 0) then
                read(work, *, iostat=ios) v1, v2
                if (ios == 0) then
                    box_lo(2) = v1; box_hi(2) = v2
                end if
                cycle
            elseif (index(work, 'zlo zhi') > 0) then
                read(work, *, iostat=ios) v1, v2
                if (ios == 0) then
                    box_lo(3) = v1; box_hi(3) = v2
                end if
                cycle
            end if

            ! --- "Masses" section header stops the header -------------
            if (ieq(work, 'Masses')) then
                backspace(unit)
                reading_header = .false.
                exit
            end if

            ! --- INT-first keywords: "<n> atoms", "<n> bonds", ... -----
            read(work, *, iostat=ios) lead_val
            if (ios /= 0) cycle        ! not integer-first → skip

            ! Extract everything after the first integer
            rest = ''
            k = 1
            do while (k <= len_trim(work) .and. work(k:k) /= ' ' .and. work(k:k) /= char(9))
                k = k + 1
            end do
            do while (k <= len_trim(work) .and. (work(k:k) == ' ' .or. work(k:k) == char(9)))
                k = k + 1
            end do
            if (k <= len_trim(work)) rest = work(k:)

            select case (trim(rest))
            case ('atoms')
                natoms = lead_val
            case ('bonds')
                nbonds = lead_val
            case ('angles')
                ! ignored
            case ('dihedrals')
                ! ignored
            case ('impropers')
                ! ignored
            case ('atom types')
                natom_types = lead_val
            case ('bond types')
                ! ignored
            case default
                ! unrecognised "<n> <keyword>" line → ignore
            end select
        end do
        
        if (reading_header) then
            backspace(unit)
        end if
    end subroutine parse_header

    ! ------------------------------------------------------------------
    ! parse_type_elements
    ! FIX: `do while (i < natom_types)` with a manual counter — the DO
    ! variable can't be touched inside a `do i = 1, N` loop.
    ! ------------------------------------------------------------------
    subroutine parse_type_elements(unit, natom_types, type_elements)
        integer, intent(in) :: unit, natom_types
        character(len=2), intent(out) :: type_elements(:)
        
        character(len=MAX_LINE_LEN) :: line, work
        integer :: i, type_id, ios, idx
        real(8) :: mass
        integer :: comment_pos
        
        type_elements = 'X'

        ! Skip to Masses section
        rewind(unit)
        do
            read(unit, '(A)', iostat=ios) line
            if (ios /= 0) return
            if (trim(adjustl(line)) == 'Masses') exit
        end do
        
        ! Skip blank/comment lines before the first data row
        do
            read(unit, '(A)', iostat=ios) line
            if (ios /= 0) return
            work = adjustl(line)
            if (len_trim(work) > 0 .and. work(1:1) /= '#') exit
        end do
        backspace(unit)
        
        ! Read masses — manual counter, skip blank/comment lines
        i = 0
        do while (i < natom_types)
            read(unit, '(A)', iostat=ios) line
            if (ios /= 0) exit
            work = strip_comment(line)
            if (len_trim(work) == 0) cycle

            read(work, *, iostat=ios) type_id, mass
            if (ios /= 0) cycle
            if (type_id < 1 .or. type_id > size(type_elements)) cycle

            i = i + 1

            type_elements(type_id) = 'X'
            comment_pos = index(line, '#')
            if (comment_pos > 0) then
                do idx = comment_pos + 1, len_trim(line)
                    if (line(idx:idx) >= 'A' .and. line(idx:idx) <= 'Z') then
                        if (idx + 1 <= len_trim(line) .and. &
                            line(idx+1:idx+1) >= 'a' .and. line(idx+1:idx+1) <= 'z') then
                            type_elements(type_id) = line(idx:idx+1)
                        else
                            type_elements(type_id) = line(idx:idx)
                        end if
                        exit
                    end if
                end do
            end if
        end do
    end subroutine parse_type_elements
    
    ! ------------------------------------------------------------------
    ! parse_atoms
    ! FIX: manual counter, and region tag extracted via token_after_n_ints
    ! (does not touch the DO variable and does not scan for 'Q' anywhere).
    ! ------------------------------------------------------------------
    subroutine parse_atoms(unit, natoms, atoms, type_elements, qm_indices, nqm)
        integer, intent(in) :: unit, natoms
        type(atom_t), intent(out) :: atoms(:)
        character(len=2), intent(in) :: type_elements(:)
        integer, intent(out) :: qm_indices(:)
        integer, intent(out) :: nqm
        
        character(len=MAX_LINE_LEN) :: line, work
        character(len=32) :: region
        integer :: i, ios, atom_id, type_id, molecule
        real(8) :: x, y, z, charge
        character(len=2) :: element
        logical :: is_qm
        
        ! Skip to Atoms section
        rewind(unit)
        do
            read(unit, '(A)', iostat=ios) line
            if (ios /= 0) exit
            if (trim(adjustl(line)) == 'Atoms') exit
        end do
        
        ! Skip blank/comment lines before first atom
        do
            read(unit, '(A)', iostat=ios) line
            if (ios /= 0) exit
            work = adjustl(line)
            if (len_trim(work) > 0 .and. work(1:1) /= '#') exit
        end do
        backspace(unit)
        
        nqm = 0
        i = 0
        do while (i < natoms)
            read(unit, '(A)', iostat=ios) line
            if (ios /= 0) exit
            work = strip_comment(line)
            if (len_trim(work) == 0) cycle

            read(work, *, iostat=ios) atom_id, molecule, type_id, charge, x, y, z
            if (ios /= 0) cycle
            if (type_id < 1 .or. type_id > size(type_elements)) cycle

            i = i + 1

            ! Region tag = the token after the 7th number
            region = token_after_n_ints(work, 7)
            is_qm = (trim(region) == 'QM' .or. trim(region) == 'Q' .or. &
                     trim(region) == 'qm' .or. trim(region) == 'q')
            if (is_qm) then
                nqm = nqm + 1
                qm_indices(nqm) = atom_id
            end if
            
            element = type_elements(type_id)
            
            atoms(i)%id = atom_id
            atoms(i)%type_id = type_id
            atoms(i)%molecule = molecule
            atoms(i)%element = transfer(trim(element)//c_null_char, atoms(i)%element)
            atoms(i)%x = x
            atoms(i)%y = y
            atoms(i)%z = z
            atoms(i)%charge = charge
            atoms(i)%is_qm = merge(1, 0, is_qm)
        end do
    end subroutine parse_atoms
    
    ! ------------------------------------------------------------------
    ! parse_bonds
    ! FIX: manual counter.
    ! ------------------------------------------------------------------
    subroutine parse_bonds(unit, nbonds, bonds)
        integer, intent(in) :: unit, nbonds
        type(bond_t), intent(out) :: bonds(:)
        
        character(len=MAX_LINE_LEN) :: line, work
        integer :: i, ios, bond_id, bond_type, atom1, atom2
        
        if (nbonds == 0) return
        
        rewind(unit)
        do
            read(unit, '(A)', iostat=ios) line
            if (ios /= 0) exit
            if (trim(adjustl(line)) == 'Bonds') exit
        end do
        
        do
            read(unit, '(A)', iostat=ios) line
            if (ios /= 0) exit
            work = adjustl(line)
            if (len_trim(work) > 0 .and. work(1:1) /= '#') exit
        end do
        backspace(unit)
        
        i = 0
        do while (i < nbonds)
            read(unit, '(A)', iostat=ios) line
            if (ios /= 0) exit
            work = strip_comment(line)
            if (len_trim(work) == 0) cycle
            read(work, *, iostat=ios) bond_id, bond_type, atom1, atom2
            if (ios /= 0) cycle

            i = i + 1
            bonds(i)%id = bond_id
            bonds(i)%type_id = bond_type
            bonds(i)%atom1 = atom1
            bonds(i)%atom2 = atom2
            bonds(i)%order = bond_type
        end do
    end subroutine parse_bonds
    
    ! ------------------------------------------------------------------
    ! parse_file — unchanged (bonds allocated with max(nbonds,1) so the
    ! allocatable array is valid even when nbonds == 0)
    ! ------------------------------------------------------------------
    subroutine parse_file(filename_c, result_c) bind(C, name="parse_file")
        character(c_char), intent(in) :: filename_c(*)
        type(parse_result_t), intent(out) :: result_c
        
        character(len=256) :: filename
        integer :: unit, natoms, nbonds, natom_types, nqm, ios
        real(8) :: box_lo(3), box_hi(3)
        logical :: has_box
        type(atom_t), pointer :: atoms(:)
        type(bond_t), pointer :: bonds(:)
        character(len=2), allocatable :: type_elements(:)
        integer, allocatable :: qm_indices(:)
        
        result_c%natoms = 0
        result_c%nbonds = 0
        result_c%nqm = 0
        result_c%has_box = 0
        result_c%atoms = c_null_ptr
        result_c%bonds = c_null_ptr
        
        call c_f_string(filename_c, filename)
        call f_c_string(trim(filename), result_c%filename)
        
        open(newunit=unit, file=filename, status='old', action='read', iostat=ios)
        if (ios /= 0) then
            result_c%natoms = -1
            return
        end if
        
        call parse_header(unit, natoms, nbonds, natom_types, has_box, box_lo, box_hi)

        if (natoms <= 0 .or. natom_types <= 0) then
            result_c%natoms = -1
            close(unit)
            return
        end if
        
        allocate(atoms(natoms))
        allocate(bonds(max(nbonds, 1)))
        allocate(type_elements(natom_types))
        allocate(qm_indices(natoms))
        
        call parse_type_elements(unit, natom_types, type_elements)
        call parse_atoms(unit, natoms, atoms, type_elements, qm_indices, nqm)
        
        if (nbonds > 0) then
            call parse_bonds(unit, nbonds, bonds)
        end if
        
        close(unit)
        
        result_c%natoms = natoms
        result_c%nbonds = nbonds
        result_c%nqm = nqm
        result_c%box_lo = box_lo
        result_c%box_hi = box_hi
        result_c%has_box = merge(1, 0, has_box)
        result_c%atoms = c_loc(atoms)
        result_c%bonds = c_loc(bonds)
        
        deallocate(type_elements)
        deallocate(qm_indices)
    end subroutine parse_file
    
    ! ------------------------------------------------------------------
    ! free_result — unchanged
    ! ------------------------------------------------------------------
    subroutine free_result(result_c) bind(C, name="free_result")
        type(parse_result_t), intent(inout) :: result_c
        type(atom_t), pointer :: atoms(:)
        type(bond_t), pointer :: bonds(:)
        
        if (c_associated(result_c%atoms)) then
            call c_f_pointer(result_c%atoms, atoms, [result_c%natoms])
            deallocate(atoms)
            result_c%atoms = c_null_ptr
        end if
        
        if (c_associated(result_c%bonds)) then
            call c_f_pointer(result_c%bonds, bonds, [max(result_c%nbonds, 1)])
            deallocate(bonds)
            result_c%bonds = c_null_ptr
        end if
        
        result_c%natoms = 0
        result_c%nbonds = 0
        result_c%nqm = 0
    end subroutine free_result
    
    subroutine get_version(version_str) bind(C, name="get_version")
        character(c_char), intent(out) :: version_str(*)
        call f_c_string('ADOBMD Fortran Parser v1.0.3 (robust header + safe counters)', version_str)
    end subroutine get_version

end module adobmd_parser