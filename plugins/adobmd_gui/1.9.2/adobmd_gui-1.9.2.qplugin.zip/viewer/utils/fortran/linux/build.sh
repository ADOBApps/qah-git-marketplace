gfortran -shared -fPIC -O3 -o libmolexport.so ../molecular_export_full.f90
gfortran -shared -fPIC -O3 -o libadobmd_parser.so ../libadobmd_parser.f90