import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.multioutput import MultiOutputRegressor
import joblib
from scipy.spatial.distance import pdist, squareform
import matplotlib.pyplot as plt
from matplotlib.backends.backend_agg import FigureCanvasAgg
import io
import math
import logging

class FullereneFeatureEngineer:
    """Enhanced feature engineer for fullerenes with better feature engineering"""
    
    @staticmethod
    def calculate_structural_properties(L):
        """Calculate structural properties using the correct formulas"""
        n_atoms = 60 * L**2
        pentagons = 12  # Fixed number of pentagons
        hexagons = (60 * L**2 - 20) // 2  # Using formula: hexagons = ((60*L²) - 20) / 2
        
        return {
            'n_atoms': n_atoms,
            'pentagons': pentagons,
            'hexagons': hexagons,
            'pentagon_density': pentagons / n_atoms,
            'hexagon_density': hexagons / n_atoms
        }
    
    @staticmethod
    def estimate_radius(L, method='empirical'):
        """
        Estimate radius for a fullerene of layer L
        """
        if method == 'empirical':
            # Enhanced empirical scaling based on C60 radius of ~3.55 Å
            base_radius = 3.55
            return base_radius * (L ** 0.55)  # Adjusted exponent for better scaling
        elif method == 'theoretical':
            # Theoretical estimation based on bond lengths and geometry
            return 1.4 * (10 * L ** 0.6)  # Improved scaling
        else:
            raise ValueError("Method must be 'empirical' or 'theoretical'")
    
    @staticmethod
    def generate_enhanced_features(L, n_points=None):
        """Generate enhanced features for better ML performance"""
        if n_points is None:
            n_points = 60 * L**2
            
        # Calculate structural properties
        structural_props = FullereneFeatureEngineer.calculate_structural_properties(L)
        
        # Enhanced feature set
        features = []
        golden_ratio = (1 + 5**0.5) / 2
        
        for i in range(n_points):
            # Fibonacci sphere sampling
            theta = 2 * np.pi * i / golden_ratio
            phi = np.arccos(1 - 2 * (i + 0.5) / n_points)
            
            # Enhanced feature vector with more meaningful features
            feature_vector = [
                L,                          # Layer number
                theta,                      # Azimuthal angle
                phi,                        # Polar angle
                np.sin(theta),              # Periodic features
                np.cos(theta),
                np.sin(phi),
                np.cos(phi),
                np.sin(2 * theta),          # Higher frequency components
                np.cos(2 * theta),
                np.sin(2 * phi),
                np.cos(2 * phi),
                theta * phi,                # Angle interactions
                L * theta,                  # Layer-angle interactions
                L * phi,
                L**2,                       # Quadratic terms
                np.sqrt(L),                 # Root terms
                np.log(L + 1),              # Log terms
                structural_props['pentagon_density'],  # Structural properties
                structural_props['hexagon_density'],
                structural_props['pentagons'] / 100.0,  # Scaled counts
                structural_props['hexagons'] / 1000.0,
                np.sin(theta) * structural_props['pentagon_density'],  # Interaction terms
                np.cos(theta) * structural_props['hexagon_density'],
                np.sin(phi) * L,            # More interactions
                np.cos(phi) * L,
            ]
            features.append(feature_vector)
            
        return np.array(features)

class NanoOnionGenerator:
    """Generator for nano-onions (concentric fullerenes)"""
    
    @staticmethod
    def calculate_shell_properties(L, custom_radius=None):
        """Calculate properties for a specific shell layer L"""
        n_atoms = 60 * L**2
        pentagons = 12
        hexagons = (60 * L**2 - 20) // 2
        
        # Use custom radius if provided, otherwise estimate
        if custom_radius is not None:
            radius = custom_radius
        else:
            radius = FullereneFeatureEngineer.estimate_radius(L)
        
        return {
            'L': L,
            'n_atoms': n_atoms,
            'pentagons': pentagons,
            'hexagons': hexagons,
            'radius': radius,
            'estimated_radius': FullereneFeatureEngineer.estimate_radius(L),
            'is_custom_radius': custom_radius is not None
        }
    
    @staticmethod
    def get_radius_suggestions(layers):
        """
        Get radius suggestions for multiple layers
        
        Returns:
        - Dictionary with empirical and theoretical radius estimates for each layer
        """
        suggestions = {}
        for L in layers:
            suggestions[L] = {
                'empirical': FullereneFeatureEngineer.estimate_radius(L, 'empirical'),
                'theoretical': FullereneFeatureEngineer.estimate_radius(L, 'theoretical'),
                'n_atoms': 60 * L**2,
                'pentagons': 12,
                'hexagons': (60 * L**2 - 20) // 2
            }
        return suggestions
    
    @staticmethod
    def generate_nano_onion(layers, interlayer_distance=3.0, custom_radii=None):
        """
        Generate a nano-onion structure with concentric fullerenes
        
        Parameters:
        - layers: list of L values for each shell [inner_L, middle_L, outer_L, ...]
        - interlayer_distance: distance between shells in Angstroms
        - custom_radii: dictionary {L: radius} for custom radii per layer
        """
        all_positions = []
        all_elements = []
        shell_info = []
        
        if custom_radii is None:
            custom_radii = {}
        
        for i, L in enumerate(layers):
            # Calculate shell properties with optional custom radius
            custom_radius = custom_radii.get(L)
            shell_props = NanoOnionGenerator.calculate_shell_properties(L, custom_radius)
            n_atoms = shell_props['n_atoms']
            
            # Calculate shell radius (base radius + interlayer spacing)
            shell_radius = shell_props['radius'] + i * interlayer_distance
            
            # Generate spherical distribution using Fibonacci sampling
            positions = NanoOnionGenerator._generate_spherical_shell(n_atoms, shell_radius)
            
            # Apply fullerene constraints
            optimized_positions = NanoOnionGenerator._apply_fullerene_constraints(positions, L)
            
            all_positions.extend(optimized_positions)
            all_elements.extend(['C'] * n_atoms)
            
            # Add shell information including structural properties
            shell_info.append({
                'L': L,
                'n_atoms': n_atoms,
                'pentagons': shell_props['pentagons'],
                'hexagons': shell_props['hexagons'],
                'radius': shell_radius,
                'base_radius': shell_props['radius'],
                'estimated_radius': shell_props['estimated_radius'],
                'is_custom_radius': shell_props['is_custom_radius'],
                'shell_index': i,
                'interlayer_offset': i * interlayer_distance
            })
        
        return np.array(all_positions), all_elements, shell_info
    
    @staticmethod
    def _generate_spherical_shell(n_atoms, radius):
        """Generate points on a spherical shell using Fibonacci sampling"""
        positions = []
        golden_ratio = (1 + 5**0.5) / 2
        
        for i in range(n_atoms):
            theta = 2 * np.pi * i / golden_ratio
            phi = np.arccos(1 - 2 * (i + 0.5) / n_atoms)
            
            x = radius * np.sin(phi) * np.cos(theta)
            y = radius * np.sin(phi) * np.sin(theta)
            z = radius * np.cos(phi)
            
            positions.append([x, y, z])
            
        return np.array(positions)
    
    @staticmethod
    def _apply_fullerene_constraints(positions, L, iterations=30):
        """Apply geometric constraints for fullerene structure"""
        optimized = positions.copy()
        n_atoms = len(positions)
        target_distance = 1.4
        learning_rate = 0.01
        
        for iteration in range(iterations):
            for i in range(n_atoms):
                distances = np.linalg.norm(optimized - optimized[i], axis=1)
                neighbor_indices = np.argsort(distances)[1:4]
                
                for j in neighbor_indices:
                    vec = optimized[j] - optimized[i]
                    current_dist = np.linalg.norm(vec)
                    
                    if current_dist > 0:
                        correction = (target_distance - current_dist) * vec / current_dist
                        optimized[i] += learning_rate * correction
                        optimized[j] -= learning_rate * correction * 0.5
            
            learning_rate *= 0.95
        
        return optimized
    
    @staticmethod
    def old_analyze_nano_onion(positions, shell_info):
        """Analyze structural properties of nano-onion"""
        analysis = {}
        start_idx = 0
        
        for shell in shell_info:
            n_atoms = shell['n_atoms']
            end_idx = start_idx + n_atoms
            shell_positions = positions[start_idx:end_idx]
            
            # Analyze individual shell
            distances = pdist(shell_positions)
            coordination_numbers = []
            distance_matrix = squareform(pdist(shell_positions))
            
            for i in range(n_atoms):
                neighbors = np.sum(distance_matrix[i] < 1.8) - 1
                coordination_numbers.append(neighbors)
            
            shell_analysis = {
                'n_atoms': n_atoms,
                'L': shell['L'],
                'pentagons': shell['pentagons'],
                'hexagons': shell['hexagons'],
                'base_radius': shell['base_radius'],
                'estimated_radius': shell['estimated_radius'],
                'is_custom_radius': shell['is_custom_radius'],
                'interlayer_offset': shell['interlayer_offset'],
                'actual_radius': np.mean(np.linalg.norm(shell_positions, axis=1)),
                'avg_coordination': np.mean(coordination_numbers),
                'std_coordination': np.std(coordination_numbers),
                'avg_distance': np.mean(distances),
                'std_distance': np.std(distances),
                'min_distance': np.min(distances),
                'max_distance': np.max(distances)
            }
            
            analysis[f"Shell_L{shell['L']}"] = shell_analysis
            start_idx = end_idx
        
        # Analyze inter-shell distances
        analysis['total_atoms'] = len(positions)
        analysis['number_of_shells'] = len(shell_info)
        analysis['total_pentagons'] = sum(shell['pentagons'] for shell in shell_info)
        analysis['total_hexagons'] = sum(shell['hexagons'] for shell in shell_info)
        analysis['custom_radii_used'] = any(shell['is_custom_radius'] for shell in shell_info)
        
        return analysis

    @staticmethod
    def analyze_nano_onion(positions, shell_info):
        """Analyze structural properties of nano-onion"""
        from scipy.spatial.distance import pdist, squareform
        import numpy as np
        
        analysis = {}
        start_idx = 0
        
        for shell in shell_info:
            n_atoms = shell['n_atoms']
            end_idx = start_idx + n_atoms
            shell_positions = positions[start_idx:end_idx]
            
            # Analyze individual shell
            distances = pdist(shell_positions)
            coordination_numbers = []
            distance_matrix = squareform(pdist(shell_positions))
            
            for i in range(n_atoms):
                neighbors = np.sum(distance_matrix[i] < 1.8) - 1
                coordination_numbers.append(neighbors)
            
            shell_analysis = {
                'n_atoms': n_atoms,
                'L': shell['L'],
                'pentagons': shell['pentagons'],
                'hexagons': shell['hexagons'],
                'base_radius': shell['base_radius'],
                'estimated_radius': shell['estimated_radius'],
                'is_custom_radius': shell['is_custom_radius'],
                'interlayer_offset': shell['interlayer_offset'],
                'actual_radius': np.mean(np.linalg.norm(shell_positions, axis=1)),
                'avg_coordination': np.mean(coordination_numbers),
                'std_coordination': np.std(coordination_numbers),
                'avg_distance': np.mean(distances),
                'std_distance': np.std(distances),
                'min_distance': np.min(distances),
                'max_distance': np.max(distances)
            }
            
            analysis[f"Shell_L{shell['L']}"] = shell_analysis
            start_idx = end_idx
        
        # Analyze inter-shell distances
        analysis['total_atoms'] = len(positions)
        analysis['number_of_shells'] = len(shell_info)
        analysis['total_pentagons'] = sum(shell['pentagons'] for shell in shell_info)
        analysis['total_hexagons'] = sum(shell['hexagons'] for shell in shell_info)
        analysis['custom_radii_used'] = any(shell['is_custom_radius'] for shell in shell_info)
        
        return analysis

#=========================================================
# Feature engineering based on real fullerene structures
class BaseFeatureEngineer:
    """Base class for feature engineers to ensure interface compatibility"""
    
    def generate_enhanced_features(self, L, n_points=None):
        """Base method that should be implemented by subclasses"""
        raise NotImplementedError("Subclasses must implement generate_enhanced_features")
    
    def calculate_structural_properties(self, L):
        """Calculate structural properties using the correct formulas"""
        n_atoms = 60 * L**2
        pentagons = 12
        hexagons = (60 * L**2 - 20) // 2
        
        return {
            'n_atoms': n_atoms,
            'pentagons': pentagons,
            'hexagons': hexagons,
            'pentagon_density': pentagons / n_atoms,
            'hexagon_density': hexagons / n_atoms
        }
    
    def estimate_radius(self, L, method='empirical'):
        """Estimate radius for a fullerene of layer L"""
        if method == 'empirical':
            base_radius = 3.55
            return base_radius * (L ** 0.55)
        elif method == 'theoretical':
            return 1.4 * (10 * L ** 0.6)
        else:
            raise ValueError("Method must be 'empirical' or 'theoretical'")

class RealStructureFeatureEngineer(BaseFeatureEngineer):
    """Feature engineering based on real fullerene structures"""
    
    def __init__(self, real_structures_analysis):
        self.real_structures = real_structures_analysis
        self.base_geometries = self.extract_base_geometries()
    
    def generate_enhanced_features(self, L, n_points=None):
        """Implement the required interface method"""
        return self.generate_scaled_features(L, n_points)
    
    def extract_base_geometries(self):
        """Extract the fundamental geometric patterns from real structures"""
        base_geometries = {}
        
        for L, analysis in self.real_structures.items():
            positions = analysis['positions']
            center = analysis['center']
            
            # Convert to spherical coordinates relative to center
            spherical_coords = []
            for pos in positions:
                vec = pos - center
                r = np.linalg.norm(vec)
                theta = np.arctan2(vec[1], vec[0])  # azimuthal
                phi = np.arccos(vec[2] / r)         # polar
                spherical_coords.append([r, theta, phi])
            
            base_geometries[L] = {
                'spherical_coords': np.array(spherical_coords),
                'cartesian_positions': positions,
                'radius': analysis['actual_radius'],
                'bond_length': analysis['avg_bond_length']
            }
        
        return base_geometries
    
    def generate_scaled_features(self, target_L, n_points=None):
        """Generate features by scaling from known real structures"""
        if n_points is None:
            n_points = 60 * target_L**2
        
        # Find the closest known structure to scale from
        known_Ls = sorted(self.base_geometries.keys())
        base_L = None
        
        for L in known_Ls:
            if L <= target_L:
                base_L = L
            else:
                break
        
        if base_L is None:
            base_L = min(known_Ls)  # Start from smallest known
        
        # If we have the exact structure, use it directly
        if target_L in self.base_geometries:
            exact_positions = self.base_geometries[target_L]['cartesian_positions']
            return self.positions_to_features(exact_positions)
        
        # For larger structures, extrapolate from the largest known
        if target_L > max(known_Ls):
            base_L = max(known_Ls)
            return self.extrapolate_structure(base_L, target_L, n_points)
        else:
            # Interpolate between known structures
            return self.interpolate_structure(target_L, n_points)
    
    def positions_to_features(self, positions):
        """Convert positions to feature vectors that preserve structure"""
        features = []
        center = np.mean(positions, axis=0)
        
        for pos in positions:
            vec = pos - center
            r = np.linalg.norm(vec)
            theta = np.arctan2(vec[1], vec[0])
            phi = np.arccos(vec[2] / r)
            
            # Features that preserve local geometry
            feature_vector = [
                r, theta, phi,
                np.sin(theta), np.cos(theta),
                np.sin(phi), np.cos(phi),
                vec[0], vec[1], vec[2],  # Keep Cartesian coordinates
                r * np.sin(phi) * np.cos(theta),  # x in spherical
                r * np.sin(phi) * np.sin(theta),  # y in spherical  
                r * np.cos(phi),                  # z in spherical
            ]
            features.append(feature_vector)
        
        return np.array(features)
    
    def extrapolate_structure(self, base_L, target_L, n_points):
        """Extrapolate structure from known base to target size"""
        base_geometry = self.base_geometries[base_L]
        base_coords = base_geometry['spherical_coords']
        
        # Scale the spherical coordinates
        radius_scale = target_L / base_L
        
        scaled_coords = base_coords.copy()
        scaled_coords[:, 0] *= radius_scale  # Scale radius
        
        # If we need more points, use Fibonacci sampling for additional atoms
        if n_points > len(scaled_coords):
            additional_points = n_points - len(scaled_coords)
            additional_coords = self.fibonacci_sphere(additional_points, scaled_coords[:, 0].mean())
            scaled_coords = np.vstack([scaled_coords, additional_coords])
        
        # Convert back to Cartesian and features
        cartesian_positions = self.spherical_to_cartesian(scaled_coords)
        return self.positions_to_features(cartesian_positions)
    
    def fibonacci_sphere(self, n_points, radius):
        """Generate points on sphere using Fibonacci sampling"""
        coords = []
        golden_ratio = (1 + 5**0.5) / 2
        
        for i in range(n_points):
            theta = 2 * np.pi * i / golden_ratio
            phi = np.arccos(1 - 2 * (i + 0.5) / n_points)
            coords.append([radius, theta, phi])
        
        return np.array(coords)
    
    def spherical_to_cartesian(self, spherical_coords):
        """Convert spherical to Cartesian coordinates"""
        positions = []
        for r, theta, phi in spherical_coords:
            x = r * np.sin(phi) * np.cos(theta)
            y = r * np.sin(phi) * np.sin(theta)
            z = r * np.cos(phi)
            positions.append([x, y, z])
        return np.array(positions)
    
    def interpolate_structure(self, target_L, n_points):
        """Interpolate between two known structures (for intermediate sizes)"""
        known_Ls = sorted(self.base_geometries.keys())
        
        # Find bounding known structures
        lower_L = None
        upper_L = None
        
        for L in known_Ls:
            if L <= target_L:
                lower_L = L
            else:
                upper_L = L
                break
        
        if lower_L is None or upper_L is None:
            return self.extrapolate_structure(known_Ls[0], target_L, n_points)
        
        # Linear interpolation between structures
        lower_geom = self.base_geometries[lower_L]
        upper_geom = self.base_geometries[upper_L]
        
        # Interpolation factor (0 = lower, 1 = upper)
        t = (target_L - lower_L) / (upper_L - lower_L)
        
        # Interpolate spherical coordinates
        interpolated_coords = self.interpolate_spherical(
            lower_geom['spherical_coords'], 
            upper_geom['spherical_coords'], 
            t, n_points
        )
        
        cartesian_positions = self.spherical_to_cartesian(interpolated_coords)
        return self.positions_to_features(cartesian_positions)
    
    def interpolate_spherical(self, lower_coords, upper_coords, t, n_points):
        """Interpolate between two sets of spherical coordinates"""
        # This is a simplified interpolation - in practice you'd want
        # to match points based on angular similarity
        if len(lower_coords) >= n_points:
            return lower_coords[:n_points]
        else:
            # Use Fibonacci sampling for the target size
            avg_radius = (1-t) * np.mean(lower_coords[:, 0]) + t * np.mean(upper_coords[:, 0])
            return self.fibonacci_sphere(n_points, avg_radius)

#=========================================================
class ScalableNanoOnionPredictor:
    """
    Base class for scalable nano-onion prediction with layer management
    and progressive building capabilities
    """
    
    def __init__(self):
        self.max_theoretical_layers = 12  # Conservative estimate
        self.current_max_tested = 0       # Will be updated during operations
        self.strain_threshold = 0.15      # Maximum allowed strain
        self.energy_threshold = 2.0       # Maximum formation energy (eV/atom)
        self.built_structures = {}        # Cache of built structures
        self.layer_properties = {}        # Properties for each layer
    
    def initialize_layer_properties(self):
        """Initialize default properties for all possible layers"""
        for L in range(1, self.max_theoretical_layers + 1):
            n_atoms = 60 * L**2
            pentagons = 12
            hexagons = (n_atoms - 20) // 2
            
            self.layer_properties[L] = {
                'n_atoms': n_atoms,
                'pentagons': pentagons,
                'hexagons': hexagons,
                'expected_radius': self.calculate_expected_radius(L),
                'theoretical_strain': self.calculate_theoretical_strain(L),
                'stability_class': self.classify_stability(L)
            }
    
    def calculate_expected_radius(self, L):
        """Calculate expected radius for layer L"""
        self.base_radii = {
            1: 3.55, 2: 7.10, 3: 10.65, 4: 14.20,
            5: 17.75, 6: 21.30, 7: 24.85, 8: 28.40,
            9: 31.95, 10: 35.50, 11: 39.05, 12: 42.60
        }
        return self.base_radii.get(L, 3.55 * L)
    
    def calculate_theoretical_strain_old(self, L):
        """Calculate theoretical strain for layer L"""
        if L == 1:
            return 0.0
        # Strain increases with layer number due to curvature constraints
        return 0.008 * (L - 1) ** 1.4
    
    def calculate_theoretical_strain(self, L):
        """
        Calculate theoretical strain for layer L based on Euler's theorem 
        for polyhedra and the specific geometric model in image_c3ca83.png.
        """
        # a = C-C bond length in planar graphene. 
        # If your radii are based on the 3.55 step, we use that as the reference 'a'.
        a = 3.55 
        
        # Retrieve the radius for this layer from your base_radii dictionary
        # Example: Layer 1 = 3.55, Layer 2 = 7.10, etc.
        R = self.base_radii.get(L)
        
        if not R:
            return 0.0

        # Applying Formula (3): ε = sqrt(1 + (a² / 4R²)) - 1
        term = 1 + (a**2 / (4 * R**2))
        strain = math.sqrt(term) - 1
        
        return strain
    
    def classify_stability(self, L):
        """Classify stability of layer L"""
        if L <= 4:
            return "high"
        elif L <= 8:
            return "moderate" 
        elif L <= 12:
            return "low"
        else:
            return "theoretical"
    
    def calculate_accumulated_strain(self, layers):
        """Calculate total accumulated strain for a set of layers"""
        if not layers:
            return 0.0
        
        total_strain = 0.0
        sorted_layers = sorted(layers)
        
        for i, L in enumerate(sorted_layers):
            # Base strain for this layer
            layer_strain = self.calculate_theoretical_strain(L)
            
            # Additional strain from interlayer interactions
            if i > 0:
                prev_L = sorted_layers[i-1]
                interlayer_strain = 0.002 * (L - prev_L) ** 2
                layer_strain += interlayer_strain
            
            total_strain += layer_strain
        
        return total_strain
    
    def estimate_formation_energy(self, L, existing_layers=None):
        """Estimate formation energy for adding layer L"""
        if existing_layers is None:
            existing_layers = []
        
        base_energy = 0.1 * L  # Base energy increases with size
        
        # Strain penalty
        strain = self.calculate_accumulated_strain(existing_layers + [L])
        strain_penalty = 5.0 * strain ** 2
        
        # Curvature penalty (higher for larger L)
        curvature_penalty = 0.05 * (L - 1) ** 1.5
        
        return base_energy + strain_penalty + curvature_penalty
    
    def can_add_layer(self, current_layers, new_L):
        """Check if we can safely add another layer"""
        if new_L > self.max_theoretical_layers:
            return False, f"Exceeds theoretical maximum ({self.max_theoretical_layers})"
        
        if new_L in current_layers:
            return False, f"Layer {new_L} already exists"
        
        # Check geometric constraints
        strain = self.calculate_accumulated_strain(current_layers + [new_L])
        if strain > self.strain_threshold:
            return False, f"Strain too high: {strain:.3f} > {self.strain_threshold}"
        
        # Check energy stability
        energy = self.estimate_formation_energy(new_L, current_layers)
        if energy > self.energy_threshold:
            return False, f"Formation energy too high: {energy:.3f} eV > {self.energy_threshold}"
        
        # Check layer ordering
        if current_layers and new_L <= max(current_layers):
            return False, "New layer must be larger than existing layers"
        
        return True, f"Layer {new_L} can be added (strain: {strain:.3f}, energy: {energy:.3f} eV)"
    
    def progressive_build(self, target_layers):
        """Build layers progressively with validation at each step"""
        built_layers = []
        successful_structures = {}
        
        logging.info("Starting progressive nano-onion build...")
        
        for L in sorted(target_layers):
            can_build, message = self.can_add_layer(built_layers, L)
            
            if can_build:
                logging.info(f"Building layer {L} (C{60*L**2})...")
                
                try:
                    # This method should be implemented by child class
                    structure = self.build_single_layer(L, built_layers)
                    built_layers.append(L)
                    successful_structures[L] = structure
                    
                    # Update current maximum
                    self.current_max_tested = max(self.current_max_tested, L)
                    
                    logging.info(f"Successfully built layer {L}")
                    logging.info(f"   - Atoms: {60*L**2}")
                    logging.info(f"   - Expected radius: {self.calculate_expected_radius(L):.2f} Å")
                    logging.info(f"   - Stability: {self.classify_stability(L)}")
                    
                except Exception as e:
                    logging.info(f"Failed to build layer {L}: {str(e)}")
                    break
            else:
                logging.info(f"Cannot add layer {L}: {message}")
                break
        
        # Final summary
        total_atoms = sum(60*L**2 for L in built_layers)
        max_radius = self.calculate_expected_radius(max(built_layers)) if built_layers else 0
        
        logging.info(f"\nBuild Summary:")
        logging.info(f"   - Layers built: {built_layers}")
        logging.info(f"   - Total atoms: {total_atoms}")
        logging.info(f"   - Maximum radius: {max_radius:.2f} Å")
        logging.info(f"   - Success rate: {len(built_layers)}/{len(target_layers)}")
        
        return built_layers, successful_structures
    
    def build_single_layer(self, L, existing_layers):
        """
        Build a single layer - to be implemented by child class
        This is where the actual structure prediction happens
        """
        raise NotImplementedError("Child classes must implement build_single_layer")
    
    def get_build_capacity(self):
        """Get information about build capacity"""
        return {
            'max_theoretical_layers': self.max_theoretical_layers,
            'current_max_tested': self.current_max_tested,
            'high_stability_layers': [L for L in range(1, 13) if self.classify_stability(L) == "high"],
            'moderate_stability_layers': [L for L in range(1, 13) if self.classify_stability(L) == "moderate"],
            'strain_threshold': self.strain_threshold,
            'energy_threshold': self.energy_threshold
        }
    
    def optimize_build_sequence(self, target_layers):
        """Find the optimal sequence to build layers"""
        sequences = []
        
        # Try different build orders
        for sequence in self.generate_sequences(target_layers):
            strain = self.calculate_accumulated_strain(sequence)
            energy = sum(self.estimate_formation_energy(L, sequence[:i]) for i, L in enumerate(sequence))
            sequences.append({
                'sequence': sequence,
                'total_strain': strain,
                'total_energy': energy,
                'score': 1.0 / (1.0 + strain + 0.1 * energy)
            })
        
        # Return best sequence
        sequences.sort(key=lambda x: x['score'], reverse=True)
        return sequences[0] if sequences else None
    
    def generate_sequences(self, layers):
        """Generate all possible build sequences"""
        from itertools import permutations
        # Only consider sequences that are strictly increasing
        return [seq for seq in permutations(layers) if all(seq[i] < seq[i+1] for i in range(len(seq)-1))]
    
    def validate_complete_structure(self, structure_dict):
        """Validate a complete multi-layer structure"""
        validation = {
            'layers': sorted(structure_dict.keys()),
            'layer_validation': {},
            'global_validation': {},
            'warnings': [],
            'recommendations': []
        }
        
        layers = sorted(structure_dict.keys())
        
        for L in layers:
            positions = structure_dict[L]
            n_atoms = len(positions)
            expected_atoms = 60 * L**2
            
            layer_validation = {
                'atoms_actual': n_atoms,
                'atoms_expected': expected_atoms,
                'atoms_match': n_atoms == expected_atoms,
                'radius_actual': np.mean(np.linalg.norm(positions, axis=1)),
                'radius_expected': self.calculate_expected_radius(L),
                'stability_class': self.classify_stability(L)
            }
            
            validation['layer_validation'][L] = layer_validation
            
            if not layer_validation['atoms_match']:
                validation['warnings'].append(f"Layer {L}: Atom count mismatch ({n_atoms} vs {expected_atoms})")
        
        # Global validation
        validation['global_validation'] = {
            'total_layers': len(layers),
            'total_atoms': sum(len(positions) for positions in structure_dict.values()),
            'max_layer': max(layers) if layers else 0,
            'strain_estimate': self.calculate_accumulated_strain(layers),
            'build_quality': self.assess_build_quality(layers)
        }
        
        # Recommendations
        if len(layers) < self.max_theoretical_layers:
            next_L = max(layers) + 1 if layers else 1
            can_add, message = self.can_add_layer(layers, next_L)
            if can_add:
                validation['recommendations'].append(f"Can add layer {next_L}: {message}")
        
        return validation
    
    def assess_build_quality(self, layers):
        """Assess overall quality of the built structure"""
        if not layers:
            return "Empty"
        
        max_L = max(layers)
        strain = self.calculate_accumulated_strain(layers)
        
        if max_L >= 8 and strain < 0.1:
            return "Excellent"
        elif max_L >= 6 and strain < 0.12:
            return "Very Good"
        elif max_L >= 4 and strain < 0.15:
            return "Good"
        else:
            return "Fair"


class EnhancedFullerenePredictor(ScalableNanoOnionPredictor):
    """Enhanced predictor with better ML models and feature engineering"""
    
    def __init__(self):
        # Initialize parent class first
        super().__init__()  # CHANGED: Call parent constructor
        
        # Then initialize child class attributes
        self.models = {}
        self.scaler = StandardScaler()
        self.feature_engineer = FullereneFeatureEngineer()
        self.nano_onion_generator = NanoOnionGenerator()
        self.is_trained = False
        self.training_history = []
        self.best_model_name = None
        # new attributes for LAMMPS integration
        self.lammps_data = {}
        self.pentagon_constraints = {}
        self.stress_patterns = {}
        self.four_layer_geometry = {}
        
        # Initialize parent class properties
        self.initialize_layer_properties()  # CHANGED: Now available from parent
        self.initialize_four_layer_constraints()
        
        # Initialize models
        self.initialize_models()

    #=========================================================
    # New methods for ScalableNanoOnionPredictor integration
    def initialize_four_layer_constraints(self):
        """Initialize constraints specific to 4-layer nano-onion"""
        self.four_layer_geometry = {
            'layers': [1, 2, 3, 4],  # C60, C240, C540, C960
            'required_pentagons': 12,  # Each layer must have exactly 12 pentagons
            'optimal_spacing': self.calculate_initial_layer_spacing(),
            'euler_constraints': self.calculate_euler_constraints()
        }

    def calculate_initial_layer_spacing(self):
        """Calculate initial layer spacing estimates for four-layer system"""
        return {
            1: 0.0,      # Innermost layer
            2: 3.4,      # C60-C240 spacing
            3: 3.4,      # C240-C540 spacing  
            4: 3.4       # C540-C960 spacing
        }
    
    def calculate_euler_constraints(self):
        """Calculate Euler formula constraints for four layers"""
        euler_data = {}
        for L in range(1, 5):
            n_atoms = 60 * L**2
            # For a spherical polyhedron: 12 pentagons required, rest are hexagons
            pentagons = 12
            hexagons = (n_atoms - 20) // 2
            faces = pentagons + hexagons
            edges = (5 * pentagons + 6 * hexagons) // 2
            
            euler_data[L] = {
                'vertices': n_atoms,
                'edges': edges,
                'faces': faces,
                'pentagons': pentagons,
                'hexagons': hexagons,
                'valid': (n_atoms - edges + faces) == 2  # Should equal 2 for sphere
            }
        
        return euler_data

    def calculate_optimal_pentagon_separation(self, stress_analysis):
        """Calculate optimal pentagon separation to minimize stress"""
        return {
            'min_distance': 6.0,  # Minimum distance between pentagons in Å
            'max_distance': 12.0, # Maximum distance for even distribution
            'preferred_angles': [72, 144, 216, 288]  # Preferred angular separation
        }

    def calculate_curvature_limits(self):
        """Calculate curvature limits for stable four-layer structure"""
        return {
            'max_curvature': 0.15,  # Maximum allowed curvature
            'min_radius': 3.0,      # Minimum radius for stability
            'smoothing_factor': 0.8 # Curvature smoothing parameter
        }

    def minimize_stress_concentration(self, positions, stress_concentration):
        """Minimize stress concentration in the structure"""
        optimized = positions.copy()
        n_atoms = len(positions)
        
        # Simple stress minimization through iterative relaxation
        for iteration in range(15):
            for i in range(n_atoms):
                # Calculate repulsive forces from neighbors
                distances = np.linalg.norm(optimized - optimized[i], axis=1)
                too_close = distances < 1.2  # Avoid too close neighbors
                too_close[i] = False  # Skip self
                
                if np.any(too_close):
                    # Move away from too-close neighbors
                    repulsion = np.sum((optimized[i] - optimized[too_close]) / 
                                     distances[too_close, np.newaxis]**2, axis=0)
                    optimized[i] += 0.01 * repulsion
        
        return optimized

    def build_single_layer(self, L, existing_layers=None):
        """
        Implement the abstract method from parent class
        Build a single layer using ML prediction
        """
        if existing_layers is None:
            existing_layers = []
        
        logging.info(f"Building layer {L} using ML prediction...")
        
        # Use custom radius based on layer position
        custom_radius = None
        if existing_layers:
            # Adjust radius based on existing layers
            base_radius = self.calculate_expected_radius(L)
            interlayer_spacing = 3.4
            custom_radius = base_radius + len(existing_layers) * interlayer_spacing
        
        # Predict the structure
        positions = self.predict_structure(L, self.best_model_name, custom_radius)
        
        # Apply layer-specific optimizations
        if L == 4:
            positions = self.optimize_outer_layer(positions)
        
        # Apply geometric constraints
        optimized_positions = self.apply_geometric_constraints(positions, L)
        
        logging.info(f"   Layer {L} built with {len(positions)} atoms")
        logging.info(f"   Actual radius: {np.mean(np.linalg.norm(optimized_positions, axis=1)):.2f} Å")
        
        return optimized_positions
    
    def optimize_outer_layer(self, positions):
        """Apply special optimizations for the outer layer (C960)"""
        n_atoms = len(positions)
        
        # Apply pentagon distribution constraints
        optimized_positions = self.distribute_pentagons_optimally(positions, 12)
        
        # Minimize surface stress
        optimized_positions = self.minimize_surface_stress(optimized_positions)
        
        # Ensure proper curvature
        optimized_positions = self.optimize_layer_curvature(optimized_positions, 4)
        
        return optimized_positions
    
    def minimize_surface_stress(self, positions):
        """Minimize surface stress through geometric optimization"""
        # Simple stress minimization through iterative relaxation
        optimized = positions.copy()
        n_atoms = len(positions)
        
        for iteration in range(10):
            for i in range(n_atoms):
                # Calculate repulsive forces from neighbors
                distances = np.linalg.norm(optimized - optimized[i], axis=1)
                too_close = distances < 1.2  # Avoid too close neighbors
                too_close[i] = False  # Skip self
                
                if np.any(too_close):
                    # Move away from too-close neighbors
                    repulsion = np.sum((optimized[i] - optimized[too_close]) / 
                                     distances[too_close, np.newaxis]**2, axis=0)
                    optimized[i] += 0.01 * repulsion
        
        return optimized
    
    def optimize_layer_curvature(self, positions, L):
        """Optimize layer curvature for stability"""
        # Ensure smooth curvature by projecting to ideal sphere
        center = np.mean(positions, axis=0)
        radii = np.linalg.norm(positions - center, axis=1)
        target_radius = np.mean(radii)
        
        # Project to sphere
        normalized = (positions - center) / radii[:, np.newaxis]
        optimized = normalized * target_radius
        
        return optimized

    # New method to initialize models
    def initialize_models(self):
        """Initialize machine learning models"""
        # Random Forest with tuning
        rf_model = RandomForestRegressor(
            n_estimators=200,
            max_depth=20,
            min_samples_split=5,
            min_samples_leaf=2,
            max_features='sqrt',
            bootstrap=True,
            random_state=42,
            n_jobs=-1
        )
        
        # Gradient Boosting with tuning
        gb_model = GradientBoostingRegressor(
            n_estimators=200,
            learning_rate=0.1,
            max_depth=8,
            min_samples_split=5,
            min_samples_leaf=2,
            subsample=0.8,
            random_state=42
        )
        
        # SVR with better parameters
        svr_model = SVR(
            kernel='rbf',
            C=10.0,
            gamma='scale',
            epsilon=0.1
        )
        
        # Enhanced MLP
        mlp_model = MLPRegressor(
            hidden_layer_sizes=(100, 50, 25),
            activation='relu',
            solver='adam',
            alpha=0.001,
            learning_rate='adaptive',
            learning_rate_init=0.001,
            max_iter=1000,
            early_stopping=True,
            validation_fraction=0.2,
            n_iter_no_change=20,
            random_state=42
        )
        
        self.models = {
            'random_forest': MultiOutputRegressor(rf_model),
            'gradient_boosting': MultiOutputRegressor(gb_model),
            'svr_rbf': MultiOutputRegressor(svr_model),
            'mlp': mlp_model
        }

    # New methods for LAMMPS integration
    def run_lammps_optimization(self, positions, L):
        """Run LAMMPS simulation on predicted structure"""
        import subprocess
        import os
        
        # Write LAMMPS input files
        self.write_lammps_input(positions, L)
        
        # Run LAMMPS
        try:
            result = subprocess.run(['lmp_serial', '-in', 'optimize_fullerenes.in'], 
                                  capture_output=True, text=True, cwd=os.getcwd())
            
            if result.returncode == 0:
                return self.parse_lammps_output('lammps_output.txt')
            else:
                logging.info(f"LAMMPS error: {result.stderr}")
                return self.get_fallback_analysis()
                
        except Exception as e:
            logging.info(f"LAMMPS execution failed: {e}")
            return self.get_fallback_analysis()
    
    def write_lammps_input(self, positions, L):
        """Write LAMMPS input file for structure optimization"""
        n_atoms = len(positions)
        
        lammps_script = f"""
# LAMMPS input for fullerene optimization
units metal
atom_style full
boundary p p p

# AIREBO potential for carbon
pair_style airebo 3.0 1 1
pair_coeff * * CH.airebo C

# Read structure
read_data fullerene_structure.data

# Minimization with constraints
min_style cg
minimize 1e-10 1e-10 10000 10000

# NVT equilibration
fix nvt all nvt temp 300 300 0.1
run 5000
unfix nvt

# Structural analysis
compute coord all coord/atom cutoff 1.8
compute stress all stress/atom NULL
compute bent all property/atom bent
compute eb all ebond

# Output
thermo 100
thermo_style custom step temp epair emol etotal press
dump analysis all custom 100 lammps_output.txt id type x y z c_coord c_stress[1] c_stress[2] c_stress[3]
run 2000
"""
        
        with open('optimize_fullerenes.in', 'w') as f:
            f.write(lammps_script)
        
        # Write structure data file
        self.write_lammps_data_file(positions, 'fullerene_structure.data')
    
    def update_with_lammps_data(self, bond_analysis, stress_analysis, L):
        """Update prediction model based on LAMMPS results"""
        key = f"L{L}"
        
        if key not in self.lammps_data:
            self.lammps_data[key] = []
        
        self.lammps_data[key].append({
            'bond_analysis': bond_analysis,
            'stress_analysis': stress_analysis,
            'pentagon_patterns': self.extract_pentagon_patterns(bond_analysis),
            'optimal_radii': self.calculate_optimal_radii(stress_analysis)
        })
        
        # Update pentagon constraints for 4-layer structure
        if L == 4:
            self.update_four_layer_constraints(bond_analysis, stress_analysis)
    
    def update_four_layer_constraints(self, bond_analysis, stress_analysis):
        """Specific constraints for 4-layer nano-onion with 12 pentagons"""
        self.pentagon_constraints = {
            'required_pentagons': 12,
            'pentagon_separation': self.calculate_optimal_pentagon_separation(stress_analysis),
            'high_stress_avoidance': stress_analysis['stress_locations'],
            'layer_spacing': self.optimize_layer_spacing(),
            'curvature_constraints': self.calculate_curvature_limits()
        }
    
    def predict_with_lammps_constraints(self, L, bond_analysis, stress_analysis):
        """Generate prediction using LAMMPS-derived constraints"""
        base_positions = self.predict_structure(L, self.best_model_name)
        
        # Apply LAMMPS-informed constraints
        if L == 4:
            return self.apply_four_layer_optimization(base_positions, bond_analysis)
        else:
            return self.apply_general_optimization(base_positions, stress_analysis)
    
    def apply_four_layer_optimization(self, positions, bond_analysis):
        """Special optimization for 4-layer structure with 12 pentagons"""
        n_atoms = len(positions)
        
        # Ensure exactly 12 pentagons using Euler's formula
        # For a spherical structure: V - E + F = 2
        # Where F = 12 pentagons + H hexagons
        pentagons = 12
        hexagons = (n_atoms - 20) // 2  # Derived from Euler's formula
        
        # Apply pentagon distribution constraints
        optimized_positions = self.distribute_pentagons_optimally(
            positions, pentagons, bond_analysis['pentagon_stability']
        )
        
        # Minimize stress concentration
        optimized_positions = self.minimize_stress_concentration(
            optimized_positions, bond_analysis['stress_concentration']
        )
        
        return optimized_positions
    
    def distribute_pentagons_optimally(self, positions, n_pentagons, stability_data=None):
        """
        Distribute pentagons optimally to minimize energy and stress concentration
        Based on the isolated pentagon rule and stress minimization principles
        """
        n_atoms = len(positions)
        center = np.mean(positions, axis=0)
        
        # If no stability data provided, use default values
        if stability_data is None:
            stability_data = {
                'avg_bond_length': 1.44,
                'bond_std': 0.05,
                'pentagon_stability': 0.8,
                'stress_concentration': []
            }
        
        # Convert to spherical coordinates for easier pentagon placement
        spherical_coords = []
        for pos in positions:
            x, y, z = pos - center
            r = np.linalg.norm(pos - center)
            theta = np.arctan2(y, x)  # azimuthal angle
            phi = np.arccos(z / r)    # polar angle
            spherical_coords.append([r, theta, phi])
        
        spherical_coords = np.array(spherical_coords)
        
        # Strategy: Place pentagons at vertices of an icosahedron (12 vertices)
        # This follows the isolated pentagon rule for stable fullerenes
        
        # Generate icosahedron vertices for pentagon placement
        icosahedron_vertices = self.generate_icosahedron_vertices()
        
        # Find closest atoms to icosahedron vertices for pentagon centers
        pentagon_centers = []
        for vertex in icosahedron_vertices:
            # Convert vertex to spherical coordinates
            vertex_theta = np.arctan2(vertex[1], vertex[0])
            vertex_phi = np.arccos(vertex[2] / np.linalg.norm(vertex))
            
            # Find atom closest to this vertex
            angular_distances = []
            for i, (r, theta, phi) in enumerate(spherical_coords):
                # Calculate angular distance
                angular_dist = self.angular_distance(theta, phi, vertex_theta, vertex_phi)
                angular_distances.append((i, angular_dist))
            
            # Sort by angular distance and take the closest
            angular_distances.sort(key=lambda x: x[1])
            pentagon_centers.append(angular_distances[0][0])
        
        # Ensure we have exactly 12 pentagon centers
        pentagon_centers = pentagon_centers[:12]
        
        # Now adjust the positions to promote pentagon formation around these centers
        optimized_positions = positions.copy()
        
        # Apply pentagon formation constraints iteratively
        for iteration in range(20):
            for center_idx in pentagon_centers:
                center_pos = optimized_positions[center_idx]
                
                # Find neighbors of the pentagon center
                distances = np.linalg.norm(optimized_positions - center_pos, axis=1)
                neighbor_indices = np.argsort(distances)[1:6]  # 5 neighbors for pentagon
                
                # Adjust positions to form a regular pentagon
                neighbor_positions = optimized_positions[neighbor_indices]
                
                # Calculate current center of neighbors
                current_center = np.mean(neighbor_positions, axis=0)
                
                # Vector from pentagon center to neighbor center
                center_to_center = current_center - center_pos
                
                # Ideal pentagon should have neighbors in a plane perpendicular to radial direction
                radial_dir = center_pos / np.linalg.norm(center_pos)
                
                # Project neighbors to plane perpendicular to radial direction
                for i, neighbor_idx in enumerate(neighbor_indices):
                    neighbor_pos = optimized_positions[neighbor_idx]
                    
                    # Vector from pentagon center to neighbor
                    center_to_neighbor = neighbor_pos - center_pos
                    
                    # Remove radial component to get tangential component
                    radial_component = np.dot(center_to_neighbor, radial_dir) * radial_dir
                    tangential_component = center_to_neighbor - radial_component
                    
                    # Ideal pentagon: neighbors equally spaced at 72 degrees
                    ideal_angle = 2 * np.pi * i / 5
                    current_angle = np.arctan2(tangential_component[1], tangential_component[0])
                    
                    # Calculate correction to move toward ideal angle
                    angle_correction = ideal_angle - current_angle
                    
                    # Rotate tangential component to ideal angle
                    rotation_matrix = np.array([
                        [np.cos(angle_correction), -np.sin(angle_correction), 0],
                        [np.sin(angle_correction), np.cos(angle_correction), 0],
                        [0, 0, 1]
                    ])
                    
                    # Apply rotation to tangential component
                    corrected_tangential = rotation_matrix @ tangential_component
                    
                    # Reconstruct position with corrected tangential component
                    corrected_neighbor = center_pos + radial_component + corrected_tangential
                    
                    # Apply correction gradually
                    learning_rate = 0.1 * (0.95 ** iteration)
                    optimized_positions[neighbor_idx] += learning_rate * (corrected_neighbor - neighbor_pos)
        
        # Apply stress minimization based on stability data
        if stability_data and 'stress_concentration' in stability_data:
            optimized_positions = self.minimize_pentagon_stress(optimized_positions, pentagon_centers, stability_data)
        
        return optimized_positions

    def generate_icosahedron_vertices(self):
        """Generate the 12 vertices of an icosahedron for pentagon placement"""
        # Golden ratio
        phi = (1 + np.sqrt(5)) / 2
        
        # Icosahedron vertices (normalized)
        vertices = []
        
        # All permutations of (0, ±1, ±φ)
        for x in [0, 1, -1]:
            for y in [0, 1, -1]:
                for z in [0, 1, -1]:
                    if abs(x) + abs(y) + abs(z) == 1:  # Only permutations with one non-zero
                        if x != 0:
                            vertices.append([x, y*phi, z*phi])
                        elif y != 0:
                            vertices.append([x*phi, y, z*phi])
                        else:
                            vertices.append([x*phi, y*phi, z])
        
        # Remove duplicates and normalize
        unique_vertices = []
        for v in vertices:
            v_norm = v / np.linalg.norm(v)
            # Check if this vertex is already in our list (within tolerance)
            is_duplicate = False
            for existing in unique_vertices:
                if np.linalg.norm(v_norm - existing) < 1e-10:
                    is_duplicate = True
                    break
            if not is_duplicate:
                unique_vertices.append(v_norm)
        
        return np.array(unique_vertices)

    def angular_distance(self, theta1, phi1, theta2, phi2):
        """Calculate angular distance between two points on a sphere"""
        # Using the haversine formula for spherical distance
        d_theta = theta2 - theta1
        d_phi = phi2 - phi1
        
        a = np.sin(d_phi/2)**2 + np.cos(phi1) * np.cos(phi2) * np.sin(d_theta/2)**2
        angular_dist = 2 * np.arcsin(np.sqrt(a))
        
        return angular_dist

    def minimize_pentagon_stress(self, positions, pentagon_centers, stability_data):
        """Minimize stress concentration around pentagons"""
        optimized = positions.copy()
        n_atoms = len(positions)
        
        # Stress minimization parameters from LAMMPS data
        target_bond_length = stability_data.get('avg_bond_length', 1.44)
        bond_std = stability_data.get('bond_std', 0.05)
        
        for center_idx in pentagon_centers:
            center_pos = optimized[center_idx]
            
            # Find pentagon neighbors
            distances = np.linalg.norm(optimized - center_pos, axis=1)
            pentagon_neighbors = np.argsort(distances)[1:6]  # 5 neighbors
            
            # Apply bond length optimization around pentagon
            for neighbor_idx in pentagon_neighbors:
                current_dist = np.linalg.norm(optimized[neighbor_idx] - center_pos)
                
                if abs(current_dist - target_bond_length) > bond_std:
                    # Adjust bond length toward target
                    direction = (optimized[neighbor_idx] - center_pos) / current_dist
                    correction = (target_bond_length - current_dist) * direction
                    
                    # Apply correction (more aggressive for pentagon bonds)
                    optimized[neighbor_idx] += 0.5 * correction
                    optimized[center_idx] -= 0.2 * correction  # Smaller correction for center
            
            # Also optimize bonds between pentagon neighbors
            for i in range(5):
                ni1 = pentagon_neighbors[i]
                ni2 = pentagon_neighbors[(i + 1) % 5]
                
                current_dist = np.linalg.norm(optimized[ni1] - optimized[ni2])
                
                if abs(current_dist - target_bond_length) > bond_std:
                    direction = (optimized[ni2] - optimized[ni1]) / current_dist
                    correction = (target_bond_length - current_dist) * direction
                    
                    optimized[ni1] += 0.3 * correction
                    optimized[ni2] -= 0.3 * correction
        
        return optimized

    def validate_pentagon_distribution(self, positions, pentagon_centers):
        """Validate that pentagons are properly distributed and isolated"""
        validation_results = {
            'total_pentagons': len(pentagon_centers),
            'pentagon_isolation': [],
            'bond_lengths': [],
            'angular_distribution': []
        }
        
        center = np.mean(positions, axis=0)
        
        for i, center_idx in enumerate(pentagon_centers):
            center_pos = positions[center_idx]
            
            # Check pentagon neighbors
            distances = np.linalg.norm(positions - center_pos, axis=1)
            neighbors = np.argsort(distances)[1:6]
            
            # Check bond lengths
            bond_lengths = [np.linalg.norm(positions[neighbor] - center_pos) for neighbor in neighbors]
            validation_results['bond_lengths'].extend(bond_lengths)
            
            # Check if pentagon is isolated (no other pentagons too close)
            other_pentagon_distances = []
            for other_center in pentagon_centers:
                if other_center != center_idx:
                    dist = np.linalg.norm(positions[other_center] - center_pos)
                    other_pentagon_distances.append(dist)
            
            min_other_distance = min(other_pentagon_distances) if other_pentagon_distances else float('inf')
            validation_results['pentagon_isolation'].append(min_other_distance)
            
            # Check angular distribution of neighbors
            neighbor_vectors = [positions[neighbor] - center_pos for neighbor in neighbors]
            neighbor_angles = []
            
            for j in range(5):
                v1 = neighbor_vectors[j]
                v2 = neighbor_vectors[(j + 1) % 5]
                
                # Calculate angle between neighbors
                cos_angle = np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2))
                angle = np.degrees(np.arccos(np.clip(cos_angle, -1, 1)))
                neighbor_angles.append(angle)
            
            validation_results['angular_distribution'].append(neighbor_angles)
        
        # Calculate summary statistics
        validation_results['avg_bond_length'] = np.mean(validation_results['bond_lengths'])
        validation_results['std_bond_length'] = np.std(validation_results['bond_lengths'])
        validation_results['min_pentagon_separation'] = min(validation_results['pentagon_isolation'])
        validation_results['avg_pentagon_angle'] = np.mean([np.mean(angles) for angles in validation_results['angular_distribution']])
        
        return validation_results

    def calculate_four_layer_geometry(self):
        """Calculate optimal geometry for 4-layer carbon nano-onion"""
        layers = [1, 2, 3, 4]  # C60, C240, C540, C960
        
        # Euler's formula constraints for each layer
        constraints = {}
        for L in layers:
            n_atoms = 60 * L**2
            pentagons = 12  # Each layer must have exactly 12 pentagons
            hexagons = (n_atoms - 20) // 2  # Derived from Euler's formula
            
            constraints[L] = {
                'atoms': n_atoms,
                'pentagons': pentagons,
                'hexagons': hexagons,
                'faces': pentagons + hexagons,
                'edges': (5 * pentagons + 6 * hexagons) // 2,
                'expected_radius': self.calculate_expected_radius(L)
            }
        
        return constraints

    def optimize_layer_spacing(self):
        """Optimize interlayer distances using LAMMPS data"""
        # Use LAMMPS stress analysis to find optimal layer spacing
        # that minimizes interlayer stress while maintaining stability
        optimal_spacing = {}
        
        for L in range(1, 5):
            spacing_data = self.analyze_interlayer_stress(L)
            optimal_spacing[L] = spacing_data['min_stress_distance']
        
        return optimal_spacing
    
    #=========================================================

    def create_enhanced_models(self):
        """Create enhanced ML models with better hyperparameters"""
        
        # Random Forest with tuning
        rf_model = RandomForestRegressor(
            n_estimators=200,
            max_depth=20,
            min_samples_split=5,
            min_samples_leaf=2,
            max_features='sqrt',
            bootstrap=True,
            random_state=42,
            n_jobs=-1
        )
        
        # Gradient Boosting with tuning
        gb_model = GradientBoostingRegressor(
            n_estimators=200,
            learning_rate=0.1,
            max_depth=8,
            min_samples_split=5,
            min_samples_leaf=2,
            subsample=0.8,
            random_state=42
        )
        
        # SVR with better parameters
        svr_model = SVR(
            kernel='rbf',
            C=10.0,
            gamma='scale',
            epsilon=0.1
        )
        
        # Enhanced MLP
        mlp_model = MLPRegressor(
            hidden_layer_sizes=(100, 50, 25),
            activation='relu',
            solver='adam',
            alpha=0.001,
            learning_rate='adaptive',
            learning_rate_init=0.001,
            max_iter=1000,
            early_stopping=True,
            validation_fraction=0.2,
            n_iter_no_change=20,
            random_state=42
        )
        
        return {
            'random_forest': MultiOutputRegressor(rf_model),
            'gradient_boosting': MultiOutputRegressor(gb_model),
            'svr_rbf': MultiOutputRegressor(svr_model),
            'mlp': mlp_model
        }
    
    def load_xyz_file(self, file_path):
        """Load XYZ file and extract atomic positions"""
        try:
            with open(file_path, 'r') as f:
                lines = f.readlines()
            
            n_atoms = int(lines[0].strip())
            comment = lines[1].strip()
            
            coordinates = []
            for i in range(2, 2 + n_atoms):
                parts = lines[i].split()
                if len(parts) >= 4:
                    element = parts[0]
                    x, y, z = float(parts[1]), float(parts[2]), float(parts[3])
                    coordinates.append([x, y, z])
            
            return np.array(coordinates), comment, n_atoms
            
        except Exception as e:
            raise ValueError(f"Error loading XYZ file: {str(e)}")
    
    def estimate_L_from_atoms(self, n_atoms):
        """Estimate L based on number of atoms"""
        L = np.sqrt(n_atoms / 60)
        return int(round(L))
    
    def calculate_structural_properties(self, L):
        return self.feature_engineer.calculate_structural_properties(L)
    
    def estimate_radius(self, L, method='empirical'):
        return self.feature_engineer.estimate_radius(L, method)
    
    def get_radius_suggestions(self, layers):
        return self.nano_onion_generator.get_radius_suggestions(layers)
    
    def prepare_training_data_from_files(self, file_paths):
        """Prepare enhanced training data with better features"""
        all_features = []
        all_positions = []
        file_info = []
        
        for file_path in file_paths:
            try:
                positions, comment, n_atoms = self.load_xyz_file(file_path)
                L = self.estimate_L_from_atoms(n_atoms)
                
                logging.info(f"Processing {file_path}: L={L}, n_atoms={n_atoms}")
                
                # Generate enhanced features
                features = self.feature_engineer.generate_enhanced_features(L, n_atoms)
                
                # Verify dimensions match
                if len(features) != n_atoms:
                    logging.info(f"Adjusting features: {len(features)} -> {n_atoms}")
                    if len(features) > n_atoms:
                        features = features[:n_atoms]
                    else:
                        padding = np.zeros((n_atoms - len(features), features.shape[1]))
                        features = np.vstack([features, padding])
                
                if len(positions) != n_atoms:
                    logging.info(f"Adjusting positions: {len(positions)} -> {n_atoms}")
                    if len(positions) > n_atoms:
                        positions = positions[:n_atoms]
                    else:
                        padding = np.zeros((n_atoms - len(positions), 3))
                        positions = np.vstack([positions, padding])
                
                all_features.append(features)
                all_positions.append(positions)
                file_info.append({
                    'file': file_path,
                    'L': L,
                    'n_atoms': n_atoms,
                    'comment': comment
                })
                
            except Exception as e:
                logging.error(f"Error processing {file_path}: {e}")
                continue
        
        if not all_features:
            raise ValueError("No valid training data could be loaded")
        
        X = np.vstack(all_features)
        y = np.vstack(all_positions)
        
        logging.info(f"Enhanced training data: X.shape={X.shape}, y.shape={y.shape}")
        logging.info(f"Feature range: [{X.min():.3f}, {X.max():.3f}]")
        logging.info(f"Target range: [{y.min():.3f}, {y.max():.3f}]")
        
        return X, y, file_info
    
    def train_models(self, X, y, test_size=0.2):
        """Train enhanced models with better validation"""
        # Data preprocessing
        if np.any(np.isnan(X)) or np.any(np.isinf(X)):
            logging.info("Cleaning X...")
            X = np.nan_to_num(X)
        
        if np.any(np.isnan(y)) or np.any(np.isinf(y)):
            logging.info("Cleaning y...")
            y = np.nan_to_num(y)
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42, shuffle=True
        )
        
        # Scale features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        logging.info(f"Training set: {X_train_scaled.shape}, Test set: {X_test_scaled.shape}")
        
        # Create enhanced models
        models_config = self.create_enhanced_models()
        
        results = {}
        best_r2 = -np.inf
        
        for name, model in models_config.items():
            logging.info(f"\n--- Training {name} ---")
            
            try:
                # Train model
                model.fit(X_train_scaled, y_train)
                
                # Predict
                y_pred = model.predict(X_test_scaled)
                
                # Calculate metrics
                mse = mean_squared_error(y_test, y_pred)
                r2 = r2_score(y_test, y_pred)
                
                # Cross-validation
                cv_scores = cross_val_score(
                    model, X_train_scaled, y_train, 
                    scoring='neg_mean_squared_error', cv=3
                )
                cv_mean = -cv_scores.mean()
                
                # Store results
                results[name] = {
                    'model': model,
                    'mse': mse,
                    'r2': r2,
                    'cv_score': cv_mean,
                    'cv_std': cv_scores.std()
                }
                
                # Update best model
                if r2 > best_r2:
                    best_r2 = r2
                    self.best_model_name = name
                
                self.training_history.append({
                    'model': name,
                    'mse': mse,
                    'r2': r2,
                    'cv_score': cv_mean
                })
                
                logging.info(f"  MSE: {mse:.4f}")
                logging.info(f"  R²: {r2:.4f}")
                logging.info(f"  CV Score: {cv_mean:.4f} ± {cv_scores.std():.4f}")
                
                # Additional diagnostics
                residuals = y_test - y_pred
                logging.info(f"  Residuals - Mean: {np.mean(residuals):.4f}, Std: {np.std(residuals):.4f}")
                
            except Exception as e:
                logging.error(f"Error training {name}: {e}")
                continue
        
        if results:
            self.models = results
            self.is_trained = True
            logging.info(f"\nTraining completed! Best model: {self.best_model_name} (R²: {best_r2:.4f})")
        else:
            logging.info("\nNo models were successfully trained")
        
        return results

    def predict_structure(self, L, model_name=None, custom_radius=None):
        """Predict structure with automatic model selection"""
        if not self.is_trained:
            raise ValueError("Model has not been trained")
        
        # Use best model if none specified
        if model_name is None:
            if self.best_model_name:
                model_name = self.best_model_name
            else:
                model_name = 'random_forest'
        
        n_atoms = 60 * L**2
        
        if hasattr(self.feature_engineer, 'generate_scaled_features'):
            # Use real structure-based features
            features = self.feature_engineer.generate_scaled_features(L, n_atoms)
        else:
            # Fallback to old method if needed
            features = self.feature_engineer.generate_enhanced_features(L, n_atoms)
        
        features_scaled = self.scaler.transform(features)
        
        if model_name not in self.models:
            raise ValueError(f"Model {model_name} not found")
        
        model = self.models[model_name]['model']
        predicted_positions = model.predict(features_scaled)
        
        # Scale to custom radius if provided
        if custom_radius is not None:
            current_radius = np.mean(np.linalg.norm(predicted_positions, axis=1))
            if current_radius > 0:
                scale_factor = custom_radius / current_radius
                predicted_positions *= scale_factor
        
        return predicted_positions
    
    def predict_nano_onion(self, layers, interlayer_distance=3.0, model_name=None, custom_radii=None):
        """Predict a complete nano-onion structure"""
        if not self.is_trained:
            raise ValueError("Model has not been trained")
        
        all_positions = []
        shell_info = []
        
        if custom_radii is None:
            custom_radii = {}
        
        for i, L in enumerate(layers):
            # Use custom radius if provided
            custom_radius = custom_radii.get(L)
            
            # Predict individual shell
            shell_positions = self.predict_structure(L, model_name, custom_radius)
            
            # Calculate shell properties
            shell_props = self.nano_onion_generator.calculate_shell_properties(L, custom_radius)
            shell_radius = shell_props['radius'] + i * interlayer_distance
            
            # Scale positions to target radius if no custom radius was used in prediction
            if custom_radius is None:
                current_radius = np.mean(np.linalg.norm(shell_positions, axis=1))
                if current_radius > 0:
                    scale_factor = shell_radius / current_radius
                    shell_positions *= scale_factor
            
            # Apply geometric constraints
            optimized_shell = self.apply_geometric_constraints(shell_positions, L)
            
            all_positions.extend(optimized_shell)
            shell_info.append({
                'L': L,
                'n_atoms': 60 * L**2,
                'pentagons': shell_props['pentagons'],
                'hexagons': shell_props['hexagons'],
                'radius': shell_radius,
                'base_radius': shell_props['radius'],
                'estimated_radius': shell_props['estimated_radius'],
                'is_custom_radius': shell_props['is_custom_radius'],
                'shell_index': i,
                'interlayer_offset': i * interlayer_distance
            })
        
        return np.array(all_positions), shell_info
    
    def apply_geometric_constraints(self, positions, L, iterations=50):
        """Apply geometric constraints for fullerenes"""
        optimized = positions.copy()
        n_atoms = len(positions)
        target_distance = 1.4
        learning_rate = 0.01
        
        for iteration in range(iterations):
            for i in range(n_atoms):
                distances = np.linalg.norm(optimized - optimized[i], axis=1)
                neighbor_indices = np.argsort(distances)[1:4]
                
                for j in neighbor_indices:
                    vec = optimized[j] - optimized[i]
                    current_dist = np.linalg.norm(vec)
                    
                    if current_dist > 0:
                        correction = (target_distance - current_dist) * vec / current_dist
                        optimized[i] += learning_rate * correction
                        optimized[j] -= learning_rate * correction * 0.5
            
            learning_rate *= 0.95
        
        return optimized
    
    def analyze_structure(self, positions, L):
        """Analyze structural properties"""
        n_atoms = len(positions)
        distances = pdist(positions)
        distance_matrix = squareform(distances)
        
        coordination_numbers = []
        for i in range(n_atoms):
            neighbors = np.sum(distance_matrix[i] < 1.8) - 1
            coordination_numbers.append(neighbors)
        
        radii = np.linalg.norm(positions, axis=1)
        
        # Calculate structural properties
        structural_props = self.calculate_structural_properties(L)
        
        analysis = {
            'n_atoms': n_atoms,
            'L': L,
            'pentagons': structural_props['pentagons'],
            'hexagons': structural_props['hexagons'],
            'estimated_radius': self.estimate_radius(L),
            'actual_radius': np.mean(radii),
            'avg_coordination': np.mean(coordination_numbers),
            'std_coordination': np.std(coordination_numbers),
            'avg_distance': np.mean(distances),
            'std_distance': np.std(distances),
            'min_distance': np.min(distances),
            'max_distance': np.max(distances)
        }
        
        return analysis
    
    def save_model(self, file_path):
        """Save trained model"""
        if not self.is_trained:
            raise ValueError("No trained model to save")
        
        model_data = {
            'models': self.models,
            'scaler': self.scaler,
            'training_history': self.training_history,
            'is_trained': self.is_trained,
            'best_model_name': self.best_model_name
        }
        
        joblib.dump(model_data, file_path)
    
    def load_model(self, file_path):
        """Load trained model"""
        model_data = joblib.load(file_path)
        
        self.models = model_data['models']
        self.scaler = model_data['scaler']
        self.training_history = model_data['training_history']
        self.is_trained = model_data['is_trained']
        self.best_model_name = model_data.get('best_model_name', 'random_forest')
    
    def create_structure_plot(self, positions, L=None, size=(800, 600), shell_info=None):
        """Create structure visualization and return as QPixmap"""
        from matplotlib.backends.backend_agg import FigureCanvasAgg
        import io
        
        fig = plt.figure(figsize=(size[0]/100, size[1]/100), dpi=100)
        ax = fig.add_subplot(111, projection='3d')
        
        x, y, z = positions[:, 0], positions[:, 1], positions[:, 2]
        
        # Color different shells if shell_info is provided
        if shell_info is not None:
            start_idx = 0
            colors = ['red', 'blue', 'green', 'orange', 'purple']
            
            for i, shell in enumerate(shell_info):
                end_idx = start_idx + shell['n_atoms']
                shell_color = colors[i % len(colors)]
                
                label = f'Shell L{shell["L"]}'
                if shell['is_custom_radius']:
                    label += ' (custom radius)'
                
                ax.scatter(x[start_idx:end_idx], y[start_idx:end_idx], z[start_idx:end_idx], 
                          c=shell_color, s=20, alpha=0.7, label=label)
                
                start_idx = end_idx
            
            ax.legend()
        else:
            # Single shell
            ax.scatter(x, y, z, c='red', s=20, alpha=0.8)
            
            # Plot bonds (limited for performance)
            for i in range(min(100, len(positions))):
                distances = np.linalg.norm(positions - positions[i], axis=1)
                neighbors = np.argsort(distances)[1:4]
                
                for neighbor in neighbors:
                    if neighbor < i:
                        continue
                    ax.plot([x[i], x[neighbor]], 
                           [y[i], y[neighbor]], 
                           [z[i], z[neighbor]], 'b-', alpha=0.3, linewidth=0.5)
        
        ax.set_xlabel('X (Å)')
        ax.set_ylabel('Y (Å)')
        ax.set_zlabel('Z (Å)')
        
        if L is not None:
            structural_props = self.calculate_structural_properties(L)
            estimated_radius = self.estimate_radius(L)
            actual_radius = np.mean(np.linalg.norm(positions, axis=1))
            ax.set_title(f'Fullerene C_{60*L**2}\n(P:{structural_props["pentagons"]}, H:{structural_props["hexagons"]})\nRadius: {actual_radius:.2f} Å (est: {estimated_radius:.2f} Å)')
        elif shell_info is not None:
            shell_str = "->".join([f"C_{60*s['L']**2}" for s in shell_info])
            custom_info = " [Custom radii]" if any(s['is_custom_radius'] for s in shell_info) else ""
            ax.set_title(f'Nano-Onion: {shell_str}{custom_info}')
        else:
            ax.set_title('Molecular Structure')
        
        # Convert to QPixmap
        canvas = FigureCanvasAgg(fig)
        canvas.draw()
        
        buf = io.BytesIO()
        canvas.print_png(buf)
        buf.seek(0)
        
        from PySide6.QtGui import QPixmap
        pixmap = QPixmap()
        pixmap.loadFromData(buf.getvalue(), "PNG")
        
        plt.close(fig)
        return pixmap
