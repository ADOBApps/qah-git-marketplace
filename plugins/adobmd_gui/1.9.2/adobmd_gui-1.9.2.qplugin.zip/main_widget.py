"""
main_widget.py - Main widget for ADOBMD Visualizer plugin
"""

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTabWidget,
    QLabel, QPushButton, QFileDialog, QMessageBox
)
from PySide6.QtCore import Qt, Signal
from pathlib import Path
import logging

from .viewer.widgets.data_widget import DataVisualizerWidget
from .viewer.widgets.xyz_widget import XYZVisualizationWidget
from .converter.converter_widget import ConverterWidget
from .editor.editor_widget import AdobmdEditorWidget

# Import MD Widget
try:
    from .md_engine.md_widget import MDWidget
    MD_AVAILABLE = True
except ImportError as e:
    MD_AVAILABLE = False
    logging.warning(f"MD Widget not available: {e}")

# Import the KIM / VASP / QE importers
try:
    from .importers.importers_widget import ImportersWidget
    IMPORTERS_AVAILABLE = True
except ImportError as e:
    IMPORTERS_AVAILABLE = False
    logging.warning(f"Importers not available: {e}")


class VisualizerWidget(QWidget):
    """Main widget combining XYZ and ADOBMD visualizers"""
    
    structure_changed = Signal(object)
    nano_onion_changed = Signal(object, object)
    
    def __init__(self, plugin_instance=None):
        super().__init__()
        self.plugin = plugin_instance
        
        self.init_ui()
        
        logging.info("VisualizerWidget initialized")
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Create tab widget
        self.tab_widget = QTabWidget()

        
        self.convert = ConverterWidget()
        self.xyz_widget = XYZVisualizationWidget()
        self.data_widget = DataVisualizerWidget(self.plugin, self.xyz_widget)
        self.editor = AdobmdEditorWidget(self)
        self.tab_widget.addTab(self.editor, "Editor")

        # Tab 1: Convert form molecules formtat to ADOBMD data
        self.tab_widget.addTab(self.convert, "Molecule to ADOBMD Data")

        # Tab 1b: KIM / VASP / QE importers
        if IMPORTERS_AVAILABLE:
            self.importers = ImportersWidget()
            self.tab_widget.addTab(self.importers, "Importers")
        else:
            self.importers = None
        
        # Tab 2: ADOBMD Data
        self.tab_widget.addTab(self.data_widget, "ADOBMD Data")
        
        # Tab 3: XYZ Visualization - now self-contained
        self.tab_widget.addTab(self.xyz_widget, "Viewer")
        
        # Tab 4: MD Simulation (if available)
        if MD_AVAILABLE:
            self.md_widget = MDWidget()
            self.tab_widget.addTab(self.md_widget, "MD Simulation")
        else:
            self.md_widget = None
        
        layout.addWidget(self.tab_widget)
        
        # Connect signals
        self.connect_signals()
    
    def connect_signals(self):
        """Connect signals from child widgets"""
        if hasattr(self.xyz_widget, 'structure_changed'):
            self.xyz_widget.structure_changed.connect(self.structure_changed.emit)
        
        if hasattr(self.xyz_widget, 'nano_onion_changed'):
            self.xyz_widget.nano_onion_changed.connect(self.nano_onion_changed.emit)
    
    def load_file(self, file_path=None):
        """Load file based on extension"""
        if not file_path:
            file_path, _ = QFileDialog.getOpenFileName(
                self, "Load Structure File", "",
                "All Files (*.xyz *.data);;XYZ Files (*.xyz);;Data Files (*.data)"
            )
        
        if not file_path:
            return
        
        ext = Path(file_path).suffix.lower()
        
        if ext == '.xyz':
            self.tab_widget.setCurrentWidget(self.xyz_widget)
            self.xyz_widget.load_xyz_file(file_path)
        elif ext == '.data':
            self.tab_widget.setCurrentWidget(self.data_widget)
            if hasattr(self.data_widget, 'load_file'):
                self.data_widget.load_file(file_path)
    
    def cleanup(self):
        """Clean up resources"""
        if hasattr(self, 'xyz_widget'):
            self.xyz_widget.deleteLater()
        if hasattr(self, 'data_widget'):
            self.data_widget.deleteLater()
        if hasattr(self, 'md_widget') and self.md_widget:
            self.md_widget.deleteLater()