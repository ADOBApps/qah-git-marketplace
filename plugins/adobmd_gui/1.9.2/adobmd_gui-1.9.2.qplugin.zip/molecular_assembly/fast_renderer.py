# molecular_assembly/fast_renderer.py
"""
Native Qt molecular renderer — NO MATPLOTLIB.

Provides:
  - BondedMoleculeItem : a QGraphicsItem that draws atoms + bonds, plus
                         label modes, selection rings, and click picking.
  - FastMolecularView : a QGraphicsView with 3D orbit camera, click picking,
                         selection tracking and background color control.

The camera pre-projects 3D atom positions to 2D scene coordinates on
every mouse move, so Qt's paint() only ever works with 2D points.
This is the same trick MolDraw / VESTA use.
"""

from PySide6.QtWidgets import (
    QGraphicsItem, QGraphicsScene, QGraphicsView
)
from PySide6.QtGui import (
    QPainter, QPen, QBrush, QColor, QPainterPath, QFont,
)
from PySide6.QtCore import Qt, QPointF, QRectF, Signal
import numpy as np
from typing import List, Tuple, Optional
import math


# =====================================================================
# Element colors
# =====================================================================
ELEMENT_QCOLORS = {
    'H':  QColor(255, 255, 255),
    'C':  QColor(50,  50,  50),
    'N':  QColor(0,   0,   255),
    'O':  QColor(255, 0,   0),
    'F':  QColor(0,   255, 0),
    'Si': QColor(128, 128, 128),
    'P':  QColor(255, 128, 0),
    'S':  QColor(255, 220, 0),
    'Cl': QColor(0,   255, 0),
    'Fe': QColor(255, 128, 0),
    'Co': QColor(128, 128, 200),
    'Ni': QColor(150, 150, 150),
    'Cu': QColor(200, 128, 50),
    'Zn': QColor(150, 150, 200),
    'Au': QColor(255, 200, 0),
    'Ag': QColor(200, 200, 200),
    'Pt': QColor(210, 210, 225),
    'Pd': QColor(0,   105, 133),
    'Ti': QColor(150, 150, 200),
    'Al': QColor(150, 150, 150),
    'Mg': QColor(128, 128, 0),
    'Na': QColor(0,   128, 128),
    'K':  QColor(128, 0,   128),
    'Ca': QColor(75,  75,  200),
    'V':  QColor(166, 166, 171),
    'Cr': QColor(138, 153, 199),
    'Mn': QColor(156, 122, 199),
    'B':  QColor(255, 181, 181),
    'Li': QColor(204, 128, 255),
    'Be': QColor(194, 255, 0),
    'Ga': QColor(194, 143, 143),
    'Ge': QColor(102, 143, 143),
    'As': QColor(189, 128, 227),
    'Se': QColor(255, 161, 0),
    'Br': QColor(166, 41,  41),
    'Rb': QColor(112, 46,  176),
    'Sr': QColor(0,   255, 0),
    'Y':  QColor(148, 255, 255),
    'Zr': QColor(148, 224, 224),
    'Nb': QColor(115, 194, 201),
    'Mo': QColor(84,  181, 181),
    'Ru': QColor(36,  143, 143),
    'Rh': QColor(10,  125, 140),
    'Cd': QColor(255, 217, 143),
    'In': QColor(166, 117, 115),
    'Sn': QColor(102, 128, 128),
    'Sb': QColor(158, 99,  181),
    'Te': QColor(212, 122, 0),
    'I':  QColor(148, 0,   148),
    'Cs': QColor(87,  23,  143),
    'Ba': QColor(0,   201, 0),
    'La': QColor(112, 212, 255),
    'Ce': QColor(255, 255, 199),
    'W':  QColor(33,  148, 214),
    'Re': QColor(38,  125, 171),
    'Os': QColor(38,  102, 150),
    'Ir': QColor(23,  84,  135),
    'Hg': QColor(181, 181, 209),
    'Pb': QColor(87,  89,  97),
    'Bi': QColor(158, 79,  181),
}
DEFAULT_COLOR = QColor(180, 180, 180)


# Covalent radii (Å) for bond detection
COVALENT_RADII = {
    'H': 0.31, 'He': 0.28, 'Li': 1.28, 'Be': 0.96, 'B': 0.84,
    'C': 0.76, 'N': 0.71, 'O': 0.66, 'F': 0.57, 'Ne': 0.58,
    'Na': 1.66, 'Mg': 1.41, 'Al': 1.21, 'Si': 1.11, 'P': 1.07,
    'S': 1.05, 'Cl': 1.02, 'Ar': 1.06, 'K': 2.03, 'Ca': 1.76,
    'Sc': 1.70, 'Ti': 1.60, 'V': 1.53, 'Cr': 1.39, 'Mn': 1.39,
    'Fe': 1.32, 'Co': 1.26, 'Ni': 1.24, 'Cu': 1.32, 'Zn': 1.22,
    'Ga': 1.22, 'Ge': 1.20, 'As': 1.19, 'Se': 1.20, 'Br': 1.20,
    'Kr': 1.16, 'Rb': 2.20, 'Sr': 1.95, 'Y': 1.90, 'Zr': 1.75,
    'Nb': 1.64, 'Mo': 1.54, 'Tc': 1.47, 'Ru': 1.46, 'Rh': 1.42,
    'Pd': 1.39, 'Ag': 1.45, 'Cd': 1.44, 'In': 1.42, 'Sn': 1.39,
    'Sb': 1.39, 'Te': 1.38, 'I': 1.39, 'Xe': 1.40, 'Cs': 2.44,
    'Ba': 2.15, 'La': 2.07, 'Ce': 2.04, 'W': 1.62, 'Re': 1.51,
    'Os': 1.44, 'Ir': 1.41, 'Pt': 1.36, 'Au': 1.36, 'Hg': 1.32,
    'Tl': 1.45, 'Pb': 1.46, 'Bi': 1.48,
}

# Van der Waals radii (Å) — the standard size for "atomic sphere" views
VDW_RADII = {
    'H': 1.20, 'He': 1.40, 'Li': 1.82, 'Be': 1.53, 'B': 1.92,
    'C': 1.70, 'N': 1.55, 'O': 1.52, 'F': 1.47, 'Ne': 1.54,
    'Na': 2.27, 'Mg': 1.73, 'Al': 1.84, 'Si': 2.10, 'P': 1.80,
    'S': 1.80, 'Cl': 1.75, 'Ar': 1.88, 'K': 2.75, 'Ca': 2.31,
    'Sc': 2.30, 'Ti': 2.15, 'V': 2.05, 'Cr': 2.05, 'Mn': 2.05,
    'Fe': 2.05, 'Co': 2.00, 'Ni': 1.97, 'Cu': 1.96, 'Zn': 2.01,
    'Ga': 1.87, 'Ge': 2.11, 'As': 1.85, 'Se': 1.90, 'Br': 1.85,
    'Kr': 2.02, 'Rb': 3.03, 'Sr': 2.49, 'Y': 2.40, 'Zr': 2.30,
    'Nb': 2.15, 'Mo': 2.10, 'Tc': 2.05, 'Ru': 2.05, 'Rh': 2.00,
    'Pd': 2.05, 'Ag': 2.10, 'Cd': 2.20, 'In': 2.20, 'Sn': 2.25,
    'Sb': 2.20, 'Te': 2.06, 'I': 1.98, 'Xe': 2.16, 'Cs': 3.43,
    'Ba': 2.68, 'La': 2.50, 'Ce': 2.48, 'W': 2.10, 'Re': 2.05,
    'Os': 2.00, 'Ir': 2.00, 'Pt': 2.05, 'Au': 2.10, 'Hg': 2.05,
    'Tl': 1.96, 'Pb': 2.02, 'Bi': 2.07,
}

# Hard ceiling for any single bond, in Å. Prevents runaway closure on
# dense metal clusters where (r_i + r_j) * tolerance can exceed next-
# nearest-neighbour distances.
MAX_BOND_LENGTH = 2.4


# =====================================================================
# BondedMoleculeItem
# =====================================================================
class BondedMoleculeItem(QGraphicsItem):
    """
    A molecule rendered as colored circles + bond lines.

    Positions are stored in **3D** (Å). The item projects them to 2D
    whenever the camera moves; paint() then only touches the cached 2D.
    """

    def __init__(self, camera: "Camera" = None, parent=None):
        super().__init__(parent)
        self._camera = camera

        # 3D data (source of truth)
        self._positions_3d: np.ndarray = np.zeros((0, 3))
        self._elements: List[str] = []
        self._colors: List[QColor] = []
        self._radii: np.ndarray = np.zeros(0, dtype=np.float64)

        # 2D projected cache
        self._xy = np.zeros((0, 2))

        # Rendering parameters
        self.atom_scale = 0.35
        self.show_bonds = True
        self.render_style = "flat"
        self.bond_color = QColor(80, 80, 80, 200)
        self.bond_width = max(0.04, self.atom_scale * 0.75)
        self.alpha = 255
        self._bond_tolerance = 1.25

        # Selection + labels
        self.label_mode = "none"          # "none" | "symbol" | "index" | "both"
        self.selected: List[int] = []
        self._highlight_color = QColor(255, 215, 0)

        self._bonds: List[Tuple[int, int]] = []
        self._bonds_dirty = True

        self.setFlag(QGraphicsItem.ItemUsesExtendedStyleOption, True)

    # -----------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------
    def _rebuild_radii(self):
        self._radii = np.array(
            [VDW_RADII.get(e, 1.5) * self.atom_scale for e in self._elements],
            dtype=np.float64,
        )

    def set_atoms(self, positions, elements):
        pos = np.asarray(positions, dtype=np.float64)
        if pos.ndim != 2 or pos.shape[1] != 3:
            raise ValueError(f"positions must be (N,3), got {pos.shape}")
        if len(elements) != len(pos):
            raise ValueError(
                f"len(elements)={len(elements)} != len(positions)={len(pos)}"
            )

        self.prepareGeometryChange()
        self._positions_3d = pos
        self._elements = list(elements)
        self._colors = [ELEMENT_QCOLORS.get(e, DEFAULT_COLOR) for e in self._elements]
        self._rebuild_radii()
        self._bonds_dirty = True
        self._reproject()

    def set_atom_scale(self, scale: float):
        self.atom_scale = float(scale)
        self._rebuild_radii()
        # Bond sticks scale with atom size so they don't disappear under
        # large spheres or become ropes for tiny ones. 0.15 Å base × 0.75
        # lands at ~0.11 Å for the default 0.35 atom scale — visually the
        # same weight as before for Medium, but grows/shrinks with the rest.
        self.bond_width = max(0.04, self.atom_scale * 0.75)
        self.prepareGeometryChange()
        self.update()

    def set_camera(self, camera: "Camera"):
        self._camera = camera
        self._reproject()

    def set_show_bonds(self, show: bool):
        self.show_bonds = bool(show)
        self.update()

    def set_render_style(self, style: str):
        self.render_style = style
        self.update()

    def set_label_mode(self, mode: str):
        self.label_mode = mode
        self.update()

    def set_selected(self, indices):
        self.selected = list(indices)
        self.update()

    def set_bond_tolerance(self, tol: float):
        """Loosen or tighten the bond criterion (1.0 = strict, 1.25 = default)."""
        self._bond_tolerance = float(tol)
        self._bonds_dirty = True
        self.update()

    @property
    def positions_3d(self) -> np.ndarray:
        return self._positions_3d.copy()

    @property
    def positions_2d(self) -> np.ndarray:
        return self._xy.copy()

    @property
    def elements(self) -> List[str]:
        return list(self._elements)

    @property
    def n_atoms(self) -> int:
        return len(self._positions_3d)

    @property
    def bonds(self):
        if self._bonds_dirty:
            self._compute_bonds()
        return self._bonds

    # -----------------------------------------------------------------
    # Projection
    # -----------------------------------------------------------------
    def _reproject(self):
        if self._camera is None or len(self._positions_3d) == 0:
            self._xy = (
                self._positions_3d[:, :2].copy()
                if len(self._positions_3d)
                else np.zeros((0, 2))
            )
            return
        self._xy = self._camera.project(self._positions_3d)
        self.prepareGeometryChange()
        self.update()

    # -----------------------------------------------------------------
    # Geometry
    # -----------------------------------------------------------------
    def boundingRect(self) -> QRectF:
        if len(self._xy) == 0:
            return QRectF()
        max_r = float(self._radii.max()) if len(self._radii) else 0.0
        x = self._xy[:, 0]
        y = self._xy[:, 1]
        return QRectF(
            float(x.min()) - max_r, float(y.min()) - max_r,
            float(x.max() - x.min()) + 2 * max_r,
            float(y.max() - y.min()) + 2 * max_r,
        )

    # -----------------------------------------------------------------
    # Picking
    # -----------------------------------------------------------------
    def hit_test(self, scene_pos: QPointF) -> Optional[int]:
        """Return index of the topmost atom whose projected sphere contains
        scene_pos (falls back to the nearest atom within 2 radii)."""
        if len(self._xy) == 0:
            return None
        p = np.array([scene_pos.x(), scene_pos.y()])
        d2 = np.sum((self._xy - p) ** 2, axis=1)
        r2 = self._radii ** 2
        inside = np.where(d2 <= r2)[0]
        if len(inside):
            if self._camera is not None:
                R = self._camera.get_matrix()
                z = (self._positions_3d @ R.T)[:, 2]
                return int(inside[np.argmax(z[inside])])
            return int(inside[0])
        j = int(np.argmin(d2))
        if d2[j] <= (2.0 * self._radii[j]) ** 2:
            return j
        return None

    # -----------------------------------------------------------------
    # Paint
    # -----------------------------------------------------------------
    def paint(self, painter: QPainter, option, widget=None):
        n = len(self._xy)
        if n == 0:
            return

        xs = self._xy[:, 0]
        ys = self._xy[:, 1]
        rs = self._radii
        max_r = float(rs.max()) if n else 0.0

        visible = None
        if option is not None:
            r = option.exposedRect
            if not r.isNull():
                x0, x1 = r.left() - max_r, r.right() + max_r
                y0, y1 = r.top() - max_r, r.bottom() + max_r
                visible = (xs >= x0) & (xs <= x1) & (ys >= y0) & (ys <= y1)

        # ---- BONDS ----
        if self.show_bonds:
            if self._bonds_dirty:
                self._compute_bonds()
            if self._bonds:
                pen = QPen(self.bond_color)
                pen.setWidthF(self.bond_width)
                pen.setCapStyle(Qt.RoundCap)
                painter.setPen(pen)
                path = QPainterPath()
                for i, j in self._bonds:
                    if visible is not None and not (visible[i] or visible[j]):
                        continue
                    path.moveTo(float(xs[i]), float(ys[i]))
                    path.lineTo(float(xs[j]), float(ys[j]))
                painter.drawPath(path)

        # ---- ATOMS ----
        buckets = {}
        for i in range(n):
            if visible is not None and not visible[i]:
                continue
            color = self._colors[i]
            r_q = round(float(rs[i]) * 20) / 20.0
            key = (color.rgb(), r_q)
            if key not in buckets:
                buckets[key] = (color, r_q, [])
            buckets[key][2].append(i)

        painter.setPen(Qt.NoPen)
        for (_, _), (color, r_q, idxs) in buckets.items():
            if self.alpha < 255:
                c = QColor(color)
                c.setAlpha(self.alpha)
                painter.setBrush(c)
            else:
                painter.setBrush(color)
            for i in idxs:
                painter.drawEllipse(
                    QPointF(float(xs[i]), float(ys[i])),
                    r_q, r_q,
                )

        # ---- SELECTION RINGS ----
        if self.selected:
            pen = QPen(self._highlight_color)
            pen.setWidthF(max(1.5, 0.06 * max(rs.max() if n else 0.1, 0.1)))
            painter.setPen(pen)
            painter.setBrush(Qt.NoBrush)
            for idx in self.selected:
                if 0 <= idx < n:
                    painter.drawEllipse(
                        QPointF(float(xs[idx]), float(ys[idx])),
                        float(rs[idx]) * 1.35, float(rs[idx]) * 1.35,
                    )

        # ---- LABELS ----
        if self.label_mode != "none":
            painter.setFont(QFont("Monospace", 9))
            for i in range(n):
                if visible is not None and not visible[i]:
                    continue
                if self.label_mode == "symbol":
                    text = self._elements[i]
                elif self.label_mode == "index":
                    text = str(i)
                else:
                    text = f"{self._elements[i]} {i}"
                tx = float(xs[i]) + float(rs[i]) + 2.0
                ty = float(ys[i]) - float(rs[i]) - 2.0
                painter.setPen(QPen(QColor(0, 0, 0, 200)))
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    painter.drawText(QPointF(tx + dx, ty + dy), text)
                painter.setPen(QPen(QColor(255, 255, 255)))
                painter.drawText(QPointF(tx, ty), text)

        # ---- SELECTION ORDER BADGES ----
        if self.selected:
            painter.setFont(QFont("Monospace", 10, QFont.Bold))
            for rank, idx in enumerate(self.selected):
                if 0 <= idx < n:
                    painter.setPen(QPen(QColor(0, 0, 0, 220)))
                    painter.drawText(
                        QPointF(
                            float(xs[idx]) - 6,
                            float(ys[idx]) - float(rs[idx]) - 6,
                        ),
                        str(rank + 1),
                    )
                    painter.setPen(QPen(self._highlight_color))
                    painter.drawText(
                        QPointF(
                            float(xs[idx]) - 7,
                            float(ys[idx]) - float(rs[idx]) - 7,
                        ),
                        str(rank + 1),
                    )

    # -----------------------------------------------------------------
    # Bond detection (vectorised, chunked for large systems)
    # -----------------------------------------------------------------
    def _compute_bonds(self):
        n = len(self._positions_3d)
        if n < 2:
            self._bonds = []
            self._bonds_dirty = False
            return

        radii = np.array(
            [COVALENT_RADII.get(e, 1.0) for e in self._elements],
            dtype=np.float64,
        )

        if n <= 3000:
            diff = self._positions_3d[:, None, :] - self._positions_3d[None, :, :]
            dist_sq = np.einsum("ijk,ijk->ij", diff, diff)
            radii_sum = radii[:, None] + radii[None, :]
            threshold = np.minimum(radii_sum * self._bond_tolerance, MAX_BOND_LENGTH)
            threshold_sq = threshold ** 2
            mask = np.triu(dist_sq < threshold_sq, k=1)
            i_idx, j_idx = np.where(mask)
            self._bonds = list(zip(i_idx.tolist(), j_idx.tolist()))
        else:
            self._bonds = []
            chunk = 500
            for start in range(0, n, chunk):
                end = min(start + chunk, n)
                diff = (
                    self._positions_3d[start:end, None, :]
                    - self._positions_3d[None, :, :]
                )
                dist_sq = np.einsum("ijk,ijk->ij", diff, diff)
                radii_sum = radii[start:end, None] + radii[None, :]
                threshold = np.minimum(
                    radii_sum * self._bond_tolerance, MAX_BOND_LENGTH
                )
                threshold_sq = threshold ** 2
                rows, cols = np.where(dist_sq < threshold_sq)
                for rr, cc in zip(rows.tolist(), cols.tolist()):
                    gi = start + rr
                    if cc > gi:
                        self._bonds.append((gi, cc))

        self._bonds_dirty = False


# =====================================================================
# Camera
# =====================================================================
class Camera:
    """Orthographic orbit camera. rot_* in degrees, pan in scene px."""

    def __init__(self):
        self.rot_x = 0.0
        self.rot_y = 0.0
        self.rot_z = 0.0
        self.pan_x = 0.0
        self.pan_y = 0.0
        self.zoom = 1.0
        self._matrix = np.eye(3)
        self._dirty = True

    def set_rotation(self, rx: float, ry: float, rz: float):
        if (rx, ry, rz) != (self.rot_x, self.rot_y, self.rot_z):
            self.rot_x, self.rot_y, self.rot_z = rx, ry, rz
            self._dirty = True

    def get_matrix(self) -> np.ndarray:
        if not self._dirty:
            return self._matrix
        rx, ry, rz = map(math.radians, (self.rot_x, self.rot_y, self.rot_z))
        cx, sx = math.cos(rx), math.sin(rx)
        cy, sy = math.cos(ry), math.sin(ry)
        cz, sz = math.cos(rz), math.sin(rz)
        Rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
        Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
        Rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
        self._matrix = Rz @ Ry @ Rx
        self._dirty = False
        return self._matrix

    def project(self, positions: np.ndarray) -> np.ndarray:
        if len(positions) == 0:
            return np.zeros((0, 2))
        R = self.get_matrix()
        rotated = positions @ R.T
        xy = rotated[:, :2] * self.zoom
        xy[:, 0] += self.pan_x
        xy[:, 1] += self.pan_y
        return xy


# =====================================================================
# FastMolecularView
# =====================================================================
class FastMolecularView(QGraphicsView):
    """Interactive view: left-drag = orbit, right/middle-drag = pan, wheel = zoom.
    A short left click (no drag) picks an atom and toggles its selection."""

    camera_changed = Signal()
    atom_clicked = Signal(int)
    selection_changed = Signal(list)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.scene_ = QGraphicsScene()
        self.scene_.setBackgroundBrush(QBrush(QColor(245, 245, 245)))
        self.setScene(self.scene_)
        self.setRenderHint(QPainter.Antialiasing, True)
        self.setViewportUpdateMode(QGraphicsView.FullViewportUpdate)
        self.setOptimizationFlag(QGraphicsView.DontAdjustForAntialiasing, True)
        self.setDragMode(QGraphicsView.NoDrag)
        self.setTransformationAnchor(QGraphicsView.NoAnchor)
        self.setResizeAnchor(QGraphicsView.NoAnchor)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setMouseTracking(True)

        self.camera = Camera()
        self.molecule_items: List[BondedMoleculeItem] = []

        self.selected: List[int] = []
        self._last_mouse = None
        self._mode = None  # "rotate" | "pan"
        self._moved = False

    # -----------------------------------------------------------------
    def add_molecule(self, item: BondedMoleculeItem):
        item.set_camera(self.camera)
        self.scene_.addItem(item)
        self.molecule_items.append(item)
        item.set_selected(self.selected)
        self._reproject_all()

    def remove_molecule(self, item: BondedMoleculeItem):
        if item in self.molecule_items:
            self.scene_.removeItem(item)
            self.molecule_items.remove(item)

    def _reproject_all(self):
        for item in self.molecule_items:
            item._rebuild_radii()
            item._reproject()
        self.scene_.update()

    def set_background_color(self, color: QColor):
        self.scene_.setBackgroundBrush(QBrush(color))

    def set_label_mode(self, mode: str):
        for it in self.molecule_items:
            it.set_label_mode(mode)

    def set_show_bonds(self, show: bool):
        for it in self.molecule_items:
            it.set_show_bonds(show)

    def set_atom_scale(self, scale: float):
        for it in self.molecule_items:
            it.set_atom_scale(scale)
        self._reproject_all()

    def clear_selection(self):
        self.selected = []
        for it in self.molecule_items:
            it.set_selected([])
        self.selection_changed.emit([])

    def reset_view(self):
        self.camera.set_rotation(0.0, 0.0, 0.0)
        self.camera.pan_x = 0.0
        self.camera.pan_y = 0.0
        self.camera.zoom = 1.0
        self._reproject_all()
        self.camera_changed.emit()

    def _apply_selection_to_items(self):
        for it in self.molecule_items:
            it.set_selected(self.selected)

    # -----------------------------------------------------------------
    # Mouse
    # -----------------------------------------------------------------
    def mousePressEvent(self, event):
        self._last_mouse = event.position()
        self._moved = False
        if event.button() == Qt.LeftButton:
            self._mode = "rotate"
            self.setCursor(Qt.ClosedHandCursor)
        elif event.button() in (Qt.MiddleButton, Qt.RightButton):
            self._mode = "pan"
            self.setCursor(Qt.SizeAllCursor)
        event.accept()

    def mouseMoveEvent(self, event):
        if self._last_mouse is None or self._mode is None:
            return event.accept()

        delta = event.position() - self._last_mouse
        if abs(delta.x()) > 3 or abs(delta.y()) > 3:
            self._moved = True

        if self._mode == "rotate":
            self.camera.rot_y += delta.x() * 0.5
            self.camera.rot_x += delta.y() * 0.5
            self.camera._dirty = True
            self._reproject_all()
            self.camera_changed.emit()
        elif self._mode == "pan":
            self.camera.pan_x += delta.x()
            self.camera.pan_y += delta.y()
            self._reproject_all()
            self.camera_changed.emit()

        self._last_mouse = event.position()
        event.accept()

    def mouseReleaseEvent(self, event):
        if self._mode == "rotate" and not self._moved and self.molecule_items:
            sp = self.mapToScene(event.position().toPoint())
            picked = None
            for it in self.molecule_items:
                idx = it.hit_test(sp)
                if idx is not None:
                    picked = (it, idx)
                    break
            if picked is not None:
                it, idx = picked
                self.atom_clicked.emit(idx)
                if idx in self.selected:
                    self.selected.remove(idx)
                else:
                    if len(self.selected) >= 4:
                        self.selected.pop(0)
                    self.selected.append(idx)
                self._apply_selection_to_items()
                self.selection_changed.emit(self.selected)

        self._mode = None
        self._last_mouse = None
        self.setCursor(Qt.ArrowCursor)
        event.accept()

    def wheelEvent(self, event):
        factor = 1.15 if event.angleDelta().y() > 0 else 1.0 / 1.15
        self.camera.zoom *= factor
        self._reproject_all()
        self.camera_changed.emit()