"""
md_widget.py - MD Simulation widget for ADOBMD GUI

Inputs exposed to the user:
    .data   atoms / bonds / box / QM region
    .ff     force-field rules (AtomTypes, BondTypes, NonBonded, ...)
    .conf   full md_input configuration (potential, ensemble, ensemble
            params, analysis flags, ONIOM/EHT/xTB flags, minimization, ...)

The .conf can either be picked from disk, or generated from the current UI
via "Save .conf from UI", edited in the text pane, and then used at Start.
At Start time, the widget:
    1. writes the current .conf to disk (if the user asked for it),
    2. pushes system_file / forcefield_file / qm_region_file / config_file
       into the bridge,
    3. calls runner.start() as before.

Parser selection, plots, console, measurement, restart etc. are unchanged.
"""

import os
import re
import time
import logging
import traceback
from pathlib import Path

import numpy as np
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QLabel,
    QPushButton, QComboBox, QSpinBox, QDoubleSpinBox,
    QTextEdit, QProgressBar, QTabWidget, QFileDialog,
    QMessageBox, QCheckBox, QGridLayout, QSplitter,
    QScrollArea, QRadioButton, QButtonGroup, QLineEdit,
    QSizePolicy,
)
from PySide6.QtWidgets import QMainWindow, QVBoxLayout as _QVL, QWidget as _QW
from PySide6.QtCore import Qt, QTimer, Signal, QThread
from PySide6.QtGui import QFont
import matplotlib
matplotlib.use('Qt5Agg')
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
from matplotlib.figure import Figure

from .ffi_bridge import get_adobmd_bridge
from .md_runner import MDRunner, SimulationStatus

# ---------------------------------------------------------------------------
# Optional parsers
# ---------------------------------------------------------------------------
FORTRAN_AVAILABLE = False
LUA_AVAILABLE = False

try:
    from ..viewer.utils.fortran_parser import get_fortran_parser
    FORTRAN_AVAILABLE = True
except Exception as e:
    logging.warning(f"Fortran parser not available: {e}")

try:
    from ..viewer.utils.lua.lua_parser import get_lua_parser
    LUA_AVAILABLE = True
except Exception as e:
    logging.warning(f"LuaJIT parser not available: {e}")


# ---------------------------------------------------------------------------
# .conf parser / writer — mirrors md_input.f90's key set.
# ---------------------------------------------------------------------------

_CONF_KEYS = {
    # system
    "natoms": "int", "nsteps": "int", "nsave": "int",
    "dt_fs": "float", "density": "float",
    "temperature": "float", "pressure": "float", "box_size": "float",
    # potential / ensemble
    "potential": "str", "material": "str", "ensemble": "str",
    # thermostat / barostat
    "gamma_ps": "float", "tau_p_ps": "float", "compressibility": "float",
    # output
    "output_prefix": "str", "coords_file": "str", "system_file": "str",
    # ff files
    "meam_library_file": "str", "meam_parameter_file": "str",
    "eam_tabulated_file": "str", "forcefield_file": "str",
    # EHT / ONIOM
    "enable_eht": "bool", "enable_oniom": "bool", "enable_xtb": "bool",
    "qm_method": "str", "eht_total_charge": "int",
    "qm_region_file": "str", "eht_cutoff": "float",
    "eht_basis_set": "str", "eht_double_zeta": "bool",
    "eht_print_orbitals": "bool", "eht_print_density": "bool",
    "eht_output_level": "int", "mm_potential": "str",
    # xTB
    "xtb_accuracy": "float", "xtb_method": "str", "xtb_max_iter": "int",
    "xtb_verbosity": "int", "xtb_temperature": "float",
    # ML / NN
    "ml_weights_file": "str", "nn_weights_file": "str",
    # analysis
    "compute_msd": "bool", "compute_vacf": "bool",
    "compute_pdf": "bool", "compute_pressure": "bool",
    "msd_start": "int", "msd_interval": "int", "vacf_interval": "int",
    "pdf_qmax_inv_angstrom": "float", "pdf_dq_inv_angstrom": "float",
    "pdf_interval": "int", "analysis_prefix": "str",
    # minimization
    "enable_minimization": "bool", "minimization_method": "str",
    "force_tolerance": "float", "energy_tolerance": "float",
    "max_minimization_steps": "int", "verbose_minimization": "bool",
    "lbfgs_memory": "int", "line_search_tolerance": "float",
}


def _parse_conf(text: str) -> dict:
    out: dict = {}
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip()
        v = v.strip().strip('"').strip("'")
        if k not in _CONF_KEYS:
            continue
        typ = _CONF_KEYS[k]
        try:
            if typ == "int":
                out[k] = int(float(v))
            elif typ == "float":
                out[k] = float(v)
            elif typ == "bool":
                out[k] = v.lower() in ("true", ".true.", "1", "yes", "y")
            else:
                out[k] = v
        except ValueError:
            continue
    return out


def _write_conf(path: str, params: dict) -> None:
    lines = [
        "# ADOBMD MD configuration",
        "# Generated by ADOBMD GUI",
        "",
    ]
    order = [
        "natoms", "nsteps", "nsave", "dt_fs", "density",
        "temperature", "pressure", "box_size",
        "potential", "material", "ensemble",
        "gamma_ps", "tau_p_ps", "compressibility",
        "system_file", "forcefield_file", "qm_region_file",
        "meam_library_file", "meam_parameter_file", "eam_tabulated_file",
        "enable_eht", "enable_oniom", "enable_xtb", "qm_method",
        "eht_total_charge", "eht_cutoff", "eht_basis_set",
        "eht_double_zeta", "eht_print_orbitals", "eht_print_density",
        "eht_output_level", "mm_potential",
        "xtb_accuracy", "xtb_method", "xtb_max_iter",
        "xtb_verbosity", "xtb_temperature",
        "ml_weights_file", "nn_weights_file",
        "output_prefix", "coords_file",
        "compute_msd", "compute_vacf", "compute_pdf", "compute_pressure",
        "msd_start", "msd_interval", "vacf_interval",
        "pdf_qmax_inv_angstrom", "pdf_dq_inv_angstrom", "pdf_interval",
        "analysis_prefix",
        "enable_minimization", "minimization_method",
        "force_tolerance", "energy_tolerance",
        "max_minimization_steps", "verbose_minimization",
        "lbfgs_memory", "line_search_tolerance",
    ]
    seen = set()
    for k in order:
        if k not in params or k in seen:
            continue
        seen.add(k)
        v = params[k]
        if isinstance(v, bool):
            v = "true" if v else "false"
        lines.append(f"{k} = {v}")
    for k, v in params.items():
        if k in seen:
            continue
        if isinstance(v, bool):
            v = "true" if v else "false"
        lines.append(f"{k} = {v}")
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")


def _format_conf(params: dict) -> str:
    import tempfile, os
    tmp = tempfile.NamedTemporaryFile(
        mode="w", suffix=".conf", delete=False, encoding="utf-8")
    tmp.close()
    try:
        _write_conf(tmp.name, params)
        return Path(tmp.name).read_text(encoding="utf-8")
    finally:
        try:
            os.unlink(tmp.name)
        except OSError:
            pass


class PlotWindow(QMainWindow):
    """Standalone window that hosts a Matplotlib figure + navigation toolbar.

    Constructed with an existing Figure; the figure is reparented into the
    window's canvas. `refresh(figure_builder)` lets the caller re-render
    into this window after a new run, so the pop-out stays current.
    """
    def __init__(
        self,
        figure,
        title: str = "Plot",
        parent=None,
        size: tuple[int, int] | None = None
    ):
        super().__init__(parent)
        self.setWindowTitle(title)
        if size is not None:
            self.resize(*size)
        else:
            self.resize(900, 600)

        central = _QW()
        self.setCentralWidget(central)
        v = _QVL(central)

        # Reuse the same Figure instance passed by the caller so any
        # subsequent `figure.clear(); ...; canvas.draw()` from the source
        # widget is immediately visible here too.
        self.figure = figure
        self.canvas = FigureCanvas(self.figure)
        # Match the fixed canvas size used inside the scrollable panel.
        if size is not None:
            self.canvas.setFixedSize(*size)
        self.toolbar = NavigationToolbar(self.canvas, self)
        v.addWidget(self.toolbar)
        v.addWidget(self.canvas)

    def save_png(self, path: str) -> None:
        self.figure.savefig(path, dpi=150, bbox_inches="tight")


# ---------------------------------------------------------------------------
# LoadFileWorker
# ---------------------------------------------------------------------------
class LoadFileWorker(QThread):
    finished = Signal(object)
    error = Signal(str)
    progress = Signal(str)

    def __init__(self, file_path: str, parser_type: str):
        super().__init__()
        self.file_path = file_path
        self.parser_type = parser_type

    def run(self):
        try:
            data = None
            if self.parser_type == "Fortran (Very Fast)" and FORTRAN_AVAILABLE:
                self.progress.emit("Using Fortran parser...")
                try:
                    p = get_fortran_parser()
                    if p:
                        r = p.parse_file(self.file_path)
                        if r:
                            data = self._convert_fortran_result(r)
                except Exception as e:
                    self.progress.emit(f"Fortran parser failed: {e}")
            if data is None and self.parser_type == "LuaJIT (Fast)" and LUA_AVAILABLE:
                self.progress.emit("Using LuaJIT parser...")
                try:
                    p = get_lua_parser()
                    if p:
                        data = p.parse_file(self.file_path)
                except Exception as e:
                    self.progress.emit(f"LuaJIT parser failed: {e}")
            if data is None:
                self.progress.emit("Using Python parser...")
                data = self._load_with_python(self.file_path)
            if data and len(data.atoms) > 0:
                self.finished.emit(data)
            else:
                self.error.emit("No atoms found in file")
        except Exception as e:
            self.error.emit(f"Load error: {e}\n{traceback.format_exc()}")

    def _convert_fortran_result(self, result: dict):
        from ..viewer.utils.data_parser import ADOBMDData, Atom, Bond
        data = ADOBMDData()
        data.filename = result.get('filename', '')
        for a in result.get('atoms', []):
            try:
                atom = Atom(
                    id=int(a.get('id', 0)), type_id=int(a.get('type_id', 0)),
                    molecule=int(a.get('molecule', 0)),
                    element=str(a.get('element', 'C')),
                    x=float(a.get('x', 0.0)), y=float(a.get('y', 0.0)),
                    z=float(a.get('z', 0.0)),
                    charge=float(a.get('charge', 0.0)),
                    is_qm=bool(a.get('is_qm', False)),
                )
                data.atoms.append(atom)
                if atom.is_qm:
                    data.qm_indices.append(atom.id)
            except Exception as e:
                logging.warning(f"Error converting atom: {e}")
        for b in result.get('bonds', []):
            try:
                data.bonds.append(Bond(
                    id=int(b.get('id', 0)),
                    type_id=int(b.get('type_id', 0)),
                    atom1=int(b.get('atom1', 0)),
                    atom2=int(b.get('atom2', 0)),
                    order=int(b.get('order', b.get('type_id', 1))),
                ))
            except Exception as e:
                logging.warning(f"Error converting bond: {e}")
        hdr = result.get('header', {}) or {}
        if hdr.get('has_box', False):
            data.has_box = True
            data.box_lo = hdr.get('box_lo', [0.0, 0.0, 0.0])
            data.box_hi = hdr.get('box_hi', [0.0, 0.0, 0.0])
        data.natoms = len(data.atoms)
        data.nbonds = len(data.bonds)
        data.has_qm_region = len(data.qm_indices) > 0
        return data

    def _load_with_python(self, file_path: str):
        from ..viewer.utils.data_parser import ADOBMDData
        data = ADOBMDData()
        if data.load(file_path):
            return data
        return None


# ---------------------------------------------------------------------------
# MDWidget
# ---------------------------------------------------------------------------
class MDWidget(QWidget):
    """Molecular Dynamics Simulation Widget"""

    simulation_started = Signal()
    simulation_stopped = Signal()
    data_updated = Signal(dict)

    PARSER_PYTHON = "Python (Slow)"
    PARSER_LUAJIT = "LuaJIT (Fast)"
    PARSER_FORTRAN = "Fortran (Very Fast)"

    def __init__(self, parent=None):
        super().__init__(parent)
        self.runner = MDRunner()
        self.current_data = None
        self.parser_type = self.PARSER_PYTHON
        self.load_worker = None
        self._last_run_target_temp = None

        self._data_path: str = ""
        self._ff_path: str = ""
        self._meam_library_path: str = ""
        self._meam_param_path: str = ""
        self._eam_tabulated_path: str = ""
        self._ml_weights_path: str = ""
        self._nn_weights_path: str = ""
        self._conf_path: str = ""
        self._qm_region_path: str = ""
        self._auto_conf_path: str = ""

        self.runner = MDRunner(parent=self)
        self.runner.step_ready.connect(self.on_simulation_step)
        self.runner.finished.connect(self.on_simulation_finished)
        self.runner.error.connect(self.on_simulation_error)

        self.init_ui()
        self.setup_timer()
        self._update_start_enabled()

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------
    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        splitter_main = QSplitter(Qt.Vertical)
        splitter = QSplitter(Qt.Horizontal)

        left_panel = self.create_controls_panel()
        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setWidget(left_panel)
        splitter.addWidget(left_scroll)

        right_panel = self.create_visualization_panel()
        right_scroll = QScrollArea()
        right_scroll.setWidgetResizable(True)
        right_scroll.setWidget(right_panel)
        splitter.addWidget(right_scroll)

        splitter.setSizes([440, 560])
        splitter_main.addWidget(splitter)

        bottom_panel = self.create_console_panel()
        bottom_scroll = QScrollArea()
        bottom_scroll.setWidgetResizable(True)
        bottom_scroll.setWidget(bottom_panel)
        splitter_main.addWidget(bottom_scroll)

        splitter_main.setStretchFactor(0, 1)
        splitter_main.setStretchFactor(1, 0)
        splitter_main.setSizes([720, 260])
        layout.addWidget(splitter_main)

    def create_controls_panel(self) -> QWidget:
        panel = QWidget()
        layout = QVBoxLayout(panel)

        # ---- parser selection ---------------------------------------
        parser_group = QGroupBox("Parser Selection")
        parser_layout = QVBoxLayout()
        self.parser_python_radio = QRadioButton(self.PARSER_PYTHON)
        self.parser_lua_radio = QRadioButton(self.PARSER_LUAJIT)
        self.parser_fortran_radio = QRadioButton(self.PARSER_FORTRAN)
        self.parser_fortran_radio.setEnabled(FORTRAN_AVAILABLE)
        self.parser_lua_radio.setEnabled(LUA_AVAILABLE)
        self.parser_fortran_radio.setChecked(True)
        self.parser_type = self.PARSER_FORTRAN
        self.parser_python_radio.toggled.connect(
            lambda c: self.on_parser_changed(self.PARSER_PYTHON, c))
        self.parser_fortran_radio.toggled.connect(
            lambda c: self.on_parser_changed(self.PARSER_FORTRAN, c))
        self.parser_lua_radio.toggled.connect(
            lambda c: self.on_parser_changed(self.PARSER_LUAJIT, c))
        parser_layout.addWidget(self.parser_python_radio)
        if LUA_AVAILABLE:
            parser_layout.addWidget(self.parser_lua_radio)
        else:
            lbl = QLabel("LuaJIT parser not available")
            lbl.setStyleSheet("color: gray; font-style: italic;")
            parser_layout.addWidget(lbl)
        if FORTRAN_AVAILABLE:
            parser_layout.addWidget(self.parser_fortran_radio)
        else:
            lbl = QLabel("Fortran parser not available")
            lbl.setStyleSheet("color: gray; font-style: italic;")
            parser_layout.addWidget(lbl)
        parser_layout.addStretch()
        parser_group.setLayout(parser_layout)
        layout.addWidget(parser_group)

        self.parser_status_label = QLabel("Using Fortran parser")
        self.parser_status_label.setStyleSheet(
            "color: #f57c00; font-size: 10px; padding: 2px;")
        layout.addWidget(self.parser_status_label)

        # ---- input files --------------------------------------------
        inputs_group = QGroupBox("Input Files")
        ig = QGridLayout(inputs_group)
        ig.setVerticalSpacing(4)

        ig.addWidget(QLabel("Data (.data):"), 0, 0)
        self.data_line = QLineEdit()
        self.data_line.setReadOnly(True)
        self.data_line.setPlaceholderText("(none)")
        ig.addWidget(self.data_line, 0, 1)
        self.load_structure_btn = QPushButton("Load…")
        self.load_structure_btn.clicked.connect(self.load_structure)
        ig.addWidget(self.load_structure_btn, 0, 2)

        ig.addWidget(QLabel("Config (.conf):"), 1, 0)
        self.conf_line = QLineEdit()
        self.conf_line.setReadOnly(True)
        self.conf_line.setPlaceholderText("(auto-generated on Start)")
        ig.addWidget(self.conf_line, 1, 1)
        self.conf_btn = QPushButton("Browse…")
        self.conf_btn.clicked.connect(self.pick_conf)
        ig.addWidget(self.conf_btn, 1, 2)

        ig.addWidget(QLabel("Force field (.ff):"), 2, 0)
        self.ff_line = QLineEdit()
        self.ff_line.setReadOnly(True)
        self.ff_line.setPlaceholderText("(optional)")
        ig.addWidget(self.ff_line, 2, 1)
        self.ff_btn = QPushButton("Browse…")
        self.ff_btn.clicked.connect(self.pick_ff)
        ig.addWidget(self.ff_btn, 2, 2)

        # ---- per-method file inputs (all optional) ------------------
        self.meam_library_line = QLineEdit()
        self.meam_library_line.setReadOnly(True)
        self.meam_library_line.setPlaceholderText("(MEAM only)")
        self.meam_library_btn = QPushButton("Browse…")
        self.meam_library_btn.clicked.connect(self.pick_meam_library)

        self.meam_param_line = QLineEdit()
        self.meam_param_line.setReadOnly(True)
        self.meam_param_line.setPlaceholderText("(MEAM only)")
        self.meam_param_btn = QPushButton("Browse…")
        self.meam_param_btn.clicked.connect(self.pick_meam_param)

        self.eam_tab_line = QLineEdit()
        self.eam_tab_line.setReadOnly(True)
        self.eam_tab_line.setPlaceholderText("(EAM_TABULATED only)")
        self.eam_tab_btn = QPushButton("Browse…")
        self.eam_tab_btn.clicked.connect(self.pick_eam_tabulated)

        self.ml_weights_line = QLineEdit()
        self.ml_weights_line.setReadOnly(True)
        self.ml_weights_line.setPlaceholderText("(ML_AIREBO only)")
        self.ml_weights_btn = QPushButton("Browse…")
        self.ml_weights_btn.clicked.connect(self.pick_ml_weights)

        self.nn_weights_line = QLineEdit()
        self.nn_weights_line.setReadOnly(True)
        self.nn_weights_line.setPlaceholderText("(NN_AIREBO only)")
        self.nn_weights_btn = QPushButton("Browse…")
        self.nn_weights_btn.clicked.connect(self.pick_nn_weights)

        self.qm_region_line = QLineEdit()
        self.qm_region_line.setReadOnly(True)
        self.qm_region_line.setPlaceholderText("(QM / ONIOM only)")
        self.qm_region_btn = QPushButton("Browse…")
        self.qm_region_btn.clicked.connect(self.pick_qm_region)

        row = 3
        for lbl_text, line_w, btn_w, handler in [
            ("MEAM library:",  self.meam_library_line, self.meam_library_btn, None),
            ("MEAM params:",   self.meam_param_line,   self.meam_param_btn,   None),
            ("EAM tabulated:", self.eam_tab_line,      self.eam_tab_btn,      None),
            ("ML weights:",    self.ml_weights_line,   self.ml_weights_btn,   None),
            ("NN weights:",    self.nn_weights_line,   self.nn_weights_btn,   None),
            ("QM region:",     self.qm_region_line,    self.qm_region_btn,    None),
        ]:
            ig.addWidget(QLabel(lbl_text), row, 0)
            ig.addWidget(line_w, row, 1)
            ig.addWidget(btn_w, row, 2)
            row += 1

        self.conf_clear_btn = QPushButton("Clear")
        self.conf_clear_btn.clicked.connect(self.clear_conf)
        ig.addWidget(self.conf_clear_btn, row, 2)

        layout.addWidget(inputs_group)

        # ---- system summary -----------------------------------------
        system_group = QGroupBox("System Setup")
        system_layout = QGridLayout()
        system_layout.addWidget(QLabel("Atoms:"), 0, 0)
        self.atoms_label = QLabel("0")
        system_layout.addWidget(self.atoms_label, 0, 1)
        for i, (lbl, attr, default) in enumerate([
            ("Box X (Å):", "box_x", 50.0),
            ("Box Y (Å):", "box_y", 50.0),
            ("Box Z (Å):", "box_z", 50.0),
        ]):
            system_layout.addWidget(QLabel(lbl), i + 1, 0)
            sb = QDoubleSpinBox()
            sb.setRange(10, 500)
            sb.setValue(default)
            sb.setSingleStep(5)
            setattr(self, attr, sb)
            system_layout.addWidget(sb, i + 1, 1)
        system_group.setLayout(system_layout)
        layout.addWidget(system_group)

        # ---- potential / method -------------------------------------
        potential_group = QGroupBox("Potential / Method")
        pl = QGridLayout(potential_group)
        pl.addWidget(QLabel("Potential:"), 0, 0)
        self.potential_combo = QComboBox()
        self.potential_combo.addItems([
            "LJ", "SW", "AIREBO", "EHT", "XTB", "ONIOM",
            "ML_AIREBO", "NN_AIREBO", "EAM_TABULATED",
        ])
        self.potential_combo.currentTextChanged.connect(self.on_potential_changed)
        pl.addWidget(self.potential_combo, 0, 1)

        self.qm_method_label = QLabel("QM Method:")
        self.qm_method_combo = QComboBox()
        self.qm_method_combo.addItems(["EHT", "XTB"])
        self.qm_method_combo.setEnabled(False)
        pl.addWidget(self.qm_method_label, 1, 0)
        pl.addWidget(self.qm_method_combo, 1, 1)

        self.mm_potential_label = QLabel("MM Potential:")
        self.mm_potential_combo = QComboBox()
        self.mm_potential_combo.addItems(["LJ", "SW", "AIREBO"])
        self.mm_potential_combo.setEnabled(False)
        pl.addWidget(self.mm_potential_label, 2, 0)
        pl.addWidget(self.mm_potential_combo, 2, 1)

        pl.addWidget(QLabel("Total charge:"), 3, 0)
        self.charge_spin = QSpinBox()
        self.charge_spin.setRange(-10, 10)
        self.charge_spin.setValue(0)
        self.charge_spin.setEnabled(False)
        pl.addWidget(self.charge_spin, 3, 1)
        potential_group.setLayout(pl)
        layout.addWidget(potential_group)

        # ---- MD parameters ------------------------------------------
        md_group = QGroupBox("MD Parameters")
        ml = QGridLayout(md_group)
        ml.addWidget(QLabel("Ensemble:"), 0, 0)
        self.ensemble_combo = QComboBox()
        self.ensemble_combo.addItems(["NVE", "NVT", "NPT", "MINIMIZATION"])
        ml.addWidget(self.ensemble_combo, 0, 1)
        ml.addWidget(QLabel("Temperature (K):"), 1, 0)
        self.temp_spin = QDoubleSpinBox()
        self.temp_spin.setRange(0, 5000)
        self.temp_spin.setValue(300)
        ml.addWidget(self.temp_spin, 1, 1)
        ml.addWidget(QLabel("Time step (fs):"), 2, 0)
        self.dt_spin = QDoubleSpinBox()
        self.dt_spin.setRange(0.1, 10)
        self.dt_spin.setValue(1.0)
        self.dt_spin.setSingleStep(0.5)
        ml.addWidget(self.dt_spin, 2, 1)
        ml.addWidget(QLabel("Total steps:"), 3, 0)
        self.steps_spin = QSpinBox()
        self.steps_spin.setRange(100, 1000000)
        self.steps_spin.setValue(10000)
        self.steps_spin.setSingleStep(1000)
        ml.addWidget(self.steps_spin, 3, 1)
        ml.addWidget(QLabel("Sample every:"), 4, 0)
        self.sample_spin = QSpinBox()
        self.sample_spin.setRange(1, 1000)
        self.sample_spin.setValue(10)
        ml.addWidget(self.sample_spin, 4, 1)
        md_group.setLayout(ml)
        layout.addWidget(md_group)

        # ---- .conf editor -------------------------------------------
        conf_editor_group = QGroupBox("Configuration (.conf)")
        cel = QVBoxLayout(conf_editor_group)
        self.conf_edit = QTextEdit()
        self.conf_edit.setFont(QFont("Courier New", 9))
        self.conf_edit.setPlaceholderText(
            "Empty. Click 'Generate from UI' to populate from the current "
            "settings, or pick a .conf with the Browse button above."
        )
        self.conf_edit.setMinimumHeight(140)
        cel.addWidget(self.conf_edit)

        btn_row = QHBoxLayout()
        self.gen_conf_btn = QPushButton("Generate from UI")
        self.gen_conf_btn.clicked.connect(self.generate_conf_from_ui)
        btn_row.addWidget(self.gen_conf_btn)
        self.save_conf_btn = QPushButton("Save .conf…")
        self.save_conf_btn.clicked.connect(self.save_conf_to_disk)
        btn_row.addWidget(self.save_conf_btn)
        self.load_conf_btn = QPushButton("Reload from file")
        self.load_conf_btn.clicked.connect(self.reload_conf_from_disk)
        btn_row.addWidget(self.load_conf_btn)
        btn_row.addStretch()
        cel.addLayout(btn_row)

        layout.addWidget(conf_editor_group)

        # ---- run buttons --------------------------------------------
        control_group = QGroupBox("Simulation Control")
        cl = QHBoxLayout()
        self.start_btn = QPushButton("Start")
        self.start_btn.setStyleSheet("background-color: #4CAF50; color: white;")
        self.start_btn.clicked.connect(self.start_simulation)
        self.start_btn.setEnabled(False)
        cl.addWidget(self.start_btn)
        self.pause_btn = QPushButton("Pause")
        self.pause_btn.setEnabled(False)
        self.pause_btn.clicked.connect(self.pause_simulation)
        cl.addWidget(self.pause_btn)
        self.resume_btn = QPushButton("Resume")
        self.resume_btn.setEnabled(False)
        self.resume_btn.clicked.connect(self.resume_simulation)
        cl.addWidget(self.resume_btn)
        self.stop_btn = QPushButton("Stop")
        self.stop_btn.setStyleSheet("background-color: #f44336; color: white;")
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self.stop_simulation)
        cl.addWidget(self.stop_btn)
        control_group.setLayout(cl)
        layout.addWidget(control_group)

        # ---- progress -----------------------------------------------
        progress_group = QGroupBox("Progress")
        pl2 = QVBoxLayout(progress_group)
        self.progress_bar = QProgressBar()
        pl2.addWidget(self.progress_bar)
        self.status_label = QLabel("Ready")
        pl2.addWidget(self.status_label)
        progress_group.setLayout(pl2)
        layout.addWidget(progress_group)

        layout.addStretch()
        return panel

    def create_visualization_panel(self) -> QWidget:
        panel = QWidget()
        layout = QVBoxLayout(panel)

        # -------- Shared plot-size control ------------------------------
        size_group = QGroupBox("Plot size (scroll to pan)")
        sl = QHBoxLayout(size_group)
        sl.addWidget(QLabel("Width (px):"))
        self.plot_width_spin = QSpinBox()
        self.plot_width_spin.setRange(200, 4000)
        self.plot_width_spin.setValue(800)
        self.plot_width_spin.setSingleStep(50)
        self.plot_width_spin.valueChanged.connect(self._on_plot_size_changed)
        sl.addWidget(self.plot_width_spin)

        sl.addWidget(QLabel("Height (px):"))
        self.plot_height_spin = QSpinBox()
        self.plot_height_spin.setRange(150, 3000)
        self.plot_height_spin.setValue(400)
        self.plot_height_spin.setSingleStep(25)
        self.plot_height_spin.valueChanged.connect(self._on_plot_size_changed)
        sl.addWidget(self.plot_height_spin)

        reset_btn = QPushButton("Reset")
        reset_btn.setToolTip("Restore 800 × 400")
        reset_btn.clicked.connect(
            lambda: (self.plot_width_spin.setValue(800),
                    self.plot_height_spin.setValue(400)))
        sl.addWidget(reset_btn)
        sl.addStretch()
        layout.addWidget(size_group)

        # -------- Energy ------------------------------------------------
        energy_group = QGroupBox("Energy")
        el = QVBoxLayout(energy_group)

        pop_e = QHBoxLayout()
        pop_e.addStretch()
        self.pop_energy_btn = QPushButton("Pop out…")
        self.pop_energy_btn.setToolTip("Open this plot in its own window")
        self.pop_energy_btn.clicked.connect(self._pop_out_energy)
        pop_e.addWidget(self.pop_energy_btn)
        el.addLayout(pop_e)

        self.figure = Figure(figsize=(8, 4), dpi=100)
        self.canvas = FigureCanvas(self.figure)
        self.toolbar = NavigationToolbar(self.canvas, self)
        el.addWidget(self.toolbar)
        el.addWidget(self._make_plot_container(
            self.figure, self.canvas, energy_group, "energy"))
        layout.addWidget(energy_group)

        # -------- Temperature -------------------------------------------
        temp_group = QGroupBox("Temperature")
        tl = QVBoxLayout(temp_group)

        pop_t = QHBoxLayout()
        pop_t.addStretch()
        self.pop_temp_btn = QPushButton("Pop out…")
        self.pop_temp_btn.setToolTip("Open this plot in its own window")
        self.pop_temp_btn.clicked.connect(self._pop_out_temperature)
        pop_t.addWidget(self.pop_temp_btn)
        tl.addLayout(pop_t)

        self.temp_figure = Figure(figsize=(8, 3), dpi=100)
        self.temp_canvas = FigureCanvas(self.temp_figure)
        tl.addWidget(self._make_plot_container(
            self.temp_figure, self.temp_canvas, temp_group, "temp"))
        layout.addWidget(temp_group)

        # -------- Pressure ----------------------------------------------
        pressure_group = QGroupBox("Pressure")
        prl = QVBoxLayout(pressure_group)

        pop_p = QHBoxLayout()
        pop_p.addStretch()
        self.pop_pressure_btn = QPushButton("Pop out…")
        self.pop_pressure_btn.setToolTip(
            "Open the pressure plot in its own window "
            "(populated once md_runner captures pressure)")
        self.pop_pressure_btn.clicked.connect(self._pop_out_pressure)
        pop_p.addWidget(self.pop_pressure_btn)
        prl.addLayout(pop_p)

        self.pressure_figure = Figure(figsize=(8, 3), dpi=100)
        self.pressure_canvas = FigureCanvas(self.pressure_figure)
        prl.addWidget(self._make_plot_container(
            self.pressure_figure, self.pressure_canvas, pressure_group, "pressure"))
        layout.addWidget(pressure_group)

        self._energy_window = None
        self._temp_window = None
        self._pressure_window = None

        # Sync figures/canvas sizes on first display.
        QTimer.singleShot(0, lambda: self._apply_plot_size(
            self.plot_width_spin.value(),
            self.plot_height_spin.value()))

        return panel

    # ------------------------------------------------------------------
    # Plot sizing / scrollable plot containers
    # ------------------------------------------------------------------
    def _make_plot_container(self, figure, canvas, group_box, plot_key):
        """Wrap a FigureCanvas in a QScrollArea with a fixed, user-controlled
        pixel size so the user can scroll around a plot larger than the panel.

        `plot_key` is one of 'energy', 'temp', 'pressure' — used to remember
        per-plot sizes and to route size changes to the right canvas.
        """
        # Remember the canvas + figure by key so the size spinboxes know
        # what to resize.
        if not hasattr(self, "_plot_registry"):
            self._plot_registry = {}
        self._plot_registry[plot_key] = (figure, canvas)

        # The canvas must be able to be larger than its container.
        canvas.setSizePolicy(
            QSizePolicy.Ignored, QSizePolicy.Ignored)
        # Initial pixel size — matches the current figsize at 100 dpi.
        w = int(figure.get_figwidth() * figure.dpi)
        h = int(figure.get_figheight() * figure.dpi)
        canvas.setFixedSize(w, h)

        scroll = QScrollArea()
        scroll.setWidgetResizable(False)   # do NOT shrink the canvas
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setWidget(canvas)
        scroll.setMinimumHeight(220)       # keeps the group box usable
        return scroll

    def _apply_plot_size(self, width: int, height: int) -> None:
        """Resize every registered plot canvas to width × height (px)."""
        if not hasattr(self, "_plot_registry"):
            return
        for figure, canvas in self._plot_registry.values():
            # Keep the figure's aspect ratio in sync so tight_layout() and
            # saved PNGs match what the user sees.
            dpi = figure.dpi or 100
            figure.set_size_inches(width / dpi, height / dpi, forward=False)
            canvas.setFixedSize(width, height)
            try:
                figure.tight_layout()
            except Exception:
                pass
            canvas.draw_idle()

    def _on_plot_size_changed(self, *_args) -> None:
        self._apply_plot_size(
            self.plot_width_spin.value(),
            self.plot_height_spin.value())

    def create_console_panel(self) -> QWidget:
        panel = QGroupBox("Console Output")
        layout = QVBoxLayout(panel)
        self.console = QTextEdit()
        self.console.setReadOnly(True)
        self.console.setFont(QFont("Courier New", 10))
        layout.addWidget(self.console)
        return panel

    def setup_timer(self):
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.update_display)
        self.update_timer.start(500)

    def _update_start_enabled(self):
        running = self.runner.status == SimulationStatus.RUNNING
        self.start_btn.setEnabled(self.runner.is_ready() and not running)

    # ------------------------------------------------------------------
    # Parser handling
    # ------------------------------------------------------------------
    def on_parser_changed(self, parser_type: str, checked: bool):
        if not checked:
            return
        self.parser_type = parser_type
        if parser_type == self.PARSER_PYTHON:
            self.parser_status_label.setText("Using Python parser (most stable)")
            self.parser_status_label.setStyleSheet(
                "color: #2e7d32; font-size: 10px; padding: 2px;")
        elif parser_type == self.PARSER_FORTRAN:
            self.parser_status_label.setText("Using Fortran parser (fast - experimental)")
            self.parser_status_label.setStyleSheet(
                "color: #f57c00; font-size: 10px; padding: 2px;")
        elif parser_type == self.PARSER_LUAJIT:
            self.parser_status_label.setText("Using LuaJIT parser (fast - experimental)")
            self.parser_status_label.setStyleSheet(
                "color: #f57c00; font-size: 10px; padding: 2px;")

    # ------------------------------------------------------------------
    # .data loading
    # ------------------------------------------------------------------
    def load_structure(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Load ADOBMD Data File", "",
            "ADOBMD Files (*.data);;All Files (*)"
        )
        if not file_path:
            return
        self._data_path = file_path
        self.data_line.setText(file_path)
        # Tell the runner where the .data lives so outputs land next to it.
        self.runner.set_output_paths(file_path)

        self.load_structure_btn.setEnabled(False)
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, 0)
        self.status_label.setText("Loading file...")

        self.load_worker = LoadFileWorker(file_path, self.parser_type)
        self.load_worker.progress.connect(self.log_message)
        self.load_worker.finished.connect(self.on_load_finished)
        self.load_worker.error.connect(self.on_load_error)
        self.load_worker.start()

    def on_load_finished(self, data):
        try:
            start_time = time.time()
            if not data or len(data.atoms) == 0:
                self.on_load_error("No atoms found in file")
                return

            atomic_numbers, positions = [], []
            element_to_z = {
                'H': 1, 'He': 2, 'Li': 3, 'Be': 4, 'B': 5, 'C': 6,
                'N': 7, 'O': 8, 'F': 9, 'Ne': 10, 'Na': 11, 'Mg': 12,
                'Al': 13, 'Si': 14, 'P': 15, 'S': 16, 'Cl': 17, 'Ar': 18,
                'K': 19, 'Ca': 20, 'Fe': 26, 'Co': 27, 'Ni': 28, 'Cu': 29,
                'Zn': 30, 'Ag': 47, 'Au': 79,
            }
            for atom in data.atoms:
                atomic_numbers.append(element_to_z.get(atom.element, 6))
                positions.append([atom.x, atom.y, atom.z])
            positions = np.array(positions, dtype=np.float64)

            if data.has_box:
                box = (data.box_hi[0] - data.box_lo[0],
                       data.box_hi[1] - data.box_lo[1],
                       data.box_hi[2] - data.box_lo[2])
            else:
                mn = np.min(positions, axis=0)
                mx = np.max(positions, axis=0)
                pad = 5.0
                box = (mx[0]-mn[0]+2*pad, mx[1]-mn[1]+2*pad, mx[2]-mn[2]+2*pad)

            self.box_x.setValue(box[0])
            self.box_y.setValue(box[1])
            self.box_z.setValue(box[2])
            self.atoms_label.setText(str(len(atomic_numbers)))

            # Re-affirm output paths now that we have the real data_path.
            self.runner.set_output_paths(self._data_path)

            setup_error = None
            try:
                self.runner.potential = self.potential_combo.currentText()
                self.runner.qm_method = self.qm_method_combo.currentText()
                self.runner.mm_potential = self.mm_potential_combo.currentText()
                self.runner.total_charge = self.charge_spin.value()
                self.runner.temperature = self.temp_spin.value()
                self.runner.dt_fs = self.dt_spin.value()
                self.runner.setup_system(atomic_numbers, positions, box=box)
            except Exception as e:
                setup_error = str(e)
                self.log_message(f"Runner setup error: {e}")

            elapsed = (time.time() - start_time) * 1000
            self.log_message(f"Loaded structure: {len(atomic_numbers)} atoms")
            self.log_message(f"  Box: {box[0]:.1f} x {box[1]:.1f} x {box[2]:.1f} Å")
            self.log_message(f"  Total time: {elapsed:.1f}ms")
            self.log_message(
                f"  Outputs will be written next to: {self._data_path or '(cwd)'}"
            )

            if not self._conf_path:
                self.generate_conf_from_ui()

            self._update_start_enabled()

            if setup_error:
                QMessageBox.warning(
                    self, "MD not ready",
                    f"Loaded {len(atomic_numbers)} atoms in {elapsed:.1f}ms, "
                    f"but the MD engine rejected the system:\n\n{setup_error}"
                )
            else:
                QMessageBox.information(
                    self, "Success",
                    f"Loaded {len(atomic_numbers)} atoms in {elapsed:.1f}ms"
                )
        except Exception as e:
            self.on_load_error(f"Error processing data: {e}\n{traceback.format_exc()}")
        finally:
            self.load_structure_btn.setEnabled(True)
            self.progress_bar.setVisible(False)
            self.status_label.setText("Ready")
            if self.load_worker is not None:
                try:
                    self.load_worker.wait(1000)
                except Exception:
                    pass
                self.load_worker = None

    def on_load_error(self, error_msg: str):
        self.log_message(f"ERROR: {error_msg}")
        QMessageBox.critical(self, "Load Error", f"Failed to load structure:\n{error_msg}")
        self.load_structure_btn.setEnabled(True)
        self.progress_bar.setVisible(False)
        self.status_label.setText("Ready")
        self._update_start_enabled()
        if self.load_worker is not None:
            try:
                self.load_worker.wait(1000)
            except Exception:
                pass
            self.load_worker = None

    # ------------------------------------------------------------------
    # .ff / .conf pickers
    # ------------------------------------------------------------------
    def pick_ff(self):
        fp, _ = QFileDialog.getOpenFileName(
            self, "Select force-field file", "",
            "Force-field Files (*.ff);;All Files (*)"
        )
        if fp:
            self._ff_path = fp
            self.ff_line.setText(fp)

    def pick_meam_library(self):
        fp, _ = QFileDialog.getOpenFileName(
            self, "Select MEAM library file", "",
            "MEAM library (*.library *.meam *.txt);;All Files (*)")
        if fp:
            self._meam_library_path = fp
            self.meam_library_line.setText(fp)

    def pick_meam_param(self):
        fp, _ = QFileDialog.getOpenFileName(
            self, "Select MEAM parameter file", "",
            "MEAM parameter (*.param *.meam *.txt);;All Files (*)")
        if fp:
            self._meam_param_path = fp
            self.meam_param_line.setText(fp)

    def pick_eam_tabulated(self):
        fp, _ = QFileDialog.getOpenFileName(
            self, "Select EAM tabulated file", "",
            "EAM tables (*.eam *.eam.alloy *.txt);;All Files (*)")
        if fp:
            self._eam_tabulated_path = fp
            self.eam_tab_line.setText(fp)

    def pick_ml_weights(self):
        fp, _ = QFileDialog.getOpenFileName(
            self, "Select ML weights file", "",
            "Weights (*.npz *.pt *.h5 *.pkl *.bin);;All Files (*)")
        if fp:
            self._ml_weights_path = fp
            self.ml_weights_line.setText(fp)

    def pick_nn_weights(self):
        fp, _ = QFileDialog.getOpenFileName(
            self, "Select NN weights file", "",
            "Weights (*.npz *.pt *.h5 *.pkl *.bin);;All Files (*)")
        if fp:
            self._nn_weights_path = fp
            self.nn_weights_line.setText(fp)

    def pick_qm_region(self):
        fp, _ = QFileDialog.getOpenFileName(
            self, "Select QM region file", "",
            "QM region (*.qm *.txt *.dat);;All Files (*)")
        if fp:
            self._qm_region_path = fp
            self.qm_region_line.setText(fp)

    def pick_conf(self):
        fp, _ = QFileDialog.getOpenFileName(
            self, "Select .conf", "",
            "ADOBMD Config (*.conf *.input);;All Files (*)"
        )
        if not fp:
            return
        self._conf_path = fp
        self.conf_line.setText(fp)
        try:
            self.conf_edit.setPlainText(
                Path(fp).read_text(encoding="utf-8"))
            self._apply_conf_to_ui(_parse_conf(self.conf_edit.toPlainText()))
        except Exception as e:
            self.log_message(f"Failed to read .conf: {e}")

    def clear_conf(self):
        self._conf_path = ""
        self.conf_line.setText("")
        self.conf_edit.clear()
        self._ff_path = ""
        self._meam_library_path = ""
        self._meam_param_path = ""
        self._eam_tabulated_path = ""
        self._ml_weights_path = ""
        self._nn_weights_path = ""
        self._qm_region_path = ""
        self.ff_line.clear()
        self.meam_library_line.clear()
        self.meam_param_line.clear()
        self.eam_tab_line.clear()
        self.ml_weights_line.clear()
        self.nn_weights_line.clear()
        self.qm_region_line.clear()

    def reload_conf_from_disk(self):
        if not self._conf_path:
            return
        try:
            self.conf_edit.setPlainText(
                Path(self._conf_path).read_text(encoding="utf-8"))
            self._apply_conf_to_ui(_parse_conf(self.conf_edit.toPlainText()))
        except Exception as e:
            self.log_message(f"Failed to reload .conf: {e}")

    # ------------------------------------------------------------------
    # .conf <-> UI  round-trip
    # ------------------------------------------------------------------
    def _default_output_prefix(self) -> str:
        """Prefix for output files: <data_stem> next to the .data, or
        ./adobmd when no data file was loaded."""
        if self._data_path:
            p = Path(self._data_path)
            return str(p.with_suffix(""))
        return str(Path.cwd() / "adobmd")

    def _ui_to_conf(self) -> dict:
        """Collect every parameter that md_input.f90 understands."""
        params: dict = {
            "potential": self.potential_combo.currentText(),
            "ensemble": self.ensemble_combo.currentText(),
            "temperature": self.temp_spin.value(),
            "dt_fs": self.dt_spin.value(),
            "nsteps": self.steps_spin.value(),
            "nsave": self.sample_spin.value(),
            "box_size": max(self.box_x.value(), self.box_y.value(), self.box_z.value()),
            "system_file": self._data_path or "",
            "forcefield_file":     self._ff_path or "",
            "meam_library_file":   self._meam_library_path or "",
            "meam_parameter_file": self._meam_param_path or "",
            "eam_tabulated_file":  self._eam_tabulated_path or "",
            "ml_weights_file":     self._ml_weights_path or "",
            "nn_weights_file":     self._nn_weights_path or "",
            "qm_region_file":      self._qm_region_path or "",
            "qm_method": self.qm_method_combo.currentText(),
            "mm_potential": self.mm_potential_combo.currentText(),
            "eht_total_charge": self.charge_spin.value(),
            "enable_eht": self.potential_combo.currentText() in ("EHT", "ONIOM"),
            "enable_xtb": self.potential_combo.currentText() == "XTB",
            "enable_oniom": self.potential_combo.currentText() == "ONIOM",
            "output_prefix": self._default_output_prefix(),
        }
        if hasattr(self, "natoms_last_loaded"):
            params["natoms"] = self.natoms_last_loaded
        else:
            try:
                params["natoms"] = int(self.atoms_label.text())
            except ValueError:
                params["natoms"] = 0
        # Preserve extra keys already present in the text pane.
        current = _parse_conf(self.conf_edit.toPlainText())
        for k, v in current.items():
            if k not in params:
                params[k] = v
        return params

    def _apply_conf_to_ui(self, params: dict) -> None:
        try:
            if "potential" in params:
                idx = self.potential_combo.findText(str(params["potential"]))
                if idx >= 0:
                    self.potential_combo.setCurrentIndex(idx)
            if "ensemble" in params:
                idx = self.ensemble_combo.findText(str(params["ensemble"]))
                if idx >= 0:
                    self.ensemble_combo.setCurrentIndex(idx)
            if "temperature" in params:
                self.temp_spin.setValue(float(params["temperature"]))
            if "dt_fs" in params:
                self.dt_spin.setValue(float(params["dt_fs"]))
            if "nsteps" in params:
                self.steps_spin.setValue(int(params["nsteps"]))
            if "nsave" in params:
                self.sample_spin.setValue(int(params["nsave"]))
            if "qm_method" in params:
                idx = self.qm_method_combo.findText(str(params["qm_method"]))
                if idx >= 0:
                    self.qm_method_combo.setCurrentIndex(idx)
            if "mm_potential" in params:
                idx = self.mm_potential_combo.findText(str(params["mm_potential"]))
                if idx >= 0:
                    self.mm_potential_combo.setCurrentIndex(idx)
            if "eht_total_charge" in params:
                self.charge_spin.setValue(int(params["eht_total_charge"]))
            if not self._data_path and params.get("system_file"):
                self._data_path = params["system_file"]
                self.data_line.setText(self._data_path)
                self.runner.set_output_paths(self._data_path)
            if not self._ff_path and params.get("forcefield_file"):
                self._ff_path = params["forcefield_file"]
                self.ff_line.setText(self._ff_path)
            if not self._meam_library_path and params.get("meam_library_file"):
                self._meam_library_path = params["meam_library_file"]
                self.meam_library_line.setText(self._meam_library_path)
            if not self._meam_param_path and params.get("meam_parameter_file"):
                self._meam_param_path = params["meam_parameter_file"]
                self.meam_param_line.setText(self._meam_param_path)
            if not self._eam_tabulated_path and params.get("eam_tabulated_file"):
                self._eam_tabulated_path = params["eam_tabulated_file"]
                self.eam_tab_line.setText(self._eam_tabulated_path)
            if not self._ml_weights_path and params.get("ml_weights_file"):
                self._ml_weights_path = params["ml_weights_file"]
                self.ml_weights_line.setText(self._ml_weights_path)
            if not self._nn_weights_path and params.get("nn_weights_file"):
                self._nn_weights_path = params["nn_weights_file"]
                self.nn_weights_line.setText(self._nn_weights_path)
            if params.get("qm_region_file"):
                self._qm_region_path = params["qm_region_file"]
                self.qm_region_line.setText(self._qm_region_path)
            self.on_potential_changed(self.potential_combo.currentText())
        except Exception as e:
            self.log_message(f"Error applying .conf: {e}")

    def generate_conf_from_ui(self):
        self.conf_edit.setPlainText(_format_conf(self._ui_to_conf()))

    def save_conf_to_disk(self):
        if not self.conf_edit.toPlainText().strip():
            self.generate_conf_from_ui()
        base = self._data_path or "adobmd"
        default = str(Path(base).with_suffix(".conf"))
        fp, _ = QFileDialog.getSaveFileName(
            self, "Save .conf", default,
            "ADOBMD Config (*.conf *.input);;All Files (*)"
        )
        if not fp:
            return
        try:
            Path(fp).write_text(self.conf_edit.toPlainText(), encoding="utf-8")
            self._conf_path = fp
            self.conf_line.setText(fp)
            self.log_message(f".conf written: {fp}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Could not write .conf:\n{e}")

    # ------------------------------------------------------------------
    # Potential handler
    # ------------------------------------------------------------------
    def on_potential_changed(self, potential: str):
        is_oniom = (potential == "ONIOM")
        is_qm = (potential in ["EHT", "XTB", "ONIOM"])
        self.qm_method_combo.setEnabled(is_qm)
        self.mm_potential_combo.setEnabled(is_oniom)
        self.charge_spin.setEnabled(is_qm)
        self.qm_method_label.setVisible(is_qm)
        self.mm_potential_label.setVisible(is_oniom)

    def log_message(self, message: str):
        self.console.append(f"[{self.get_timestamp()}] {message}")

    def get_timestamp(self) -> str:
        from datetime import datetime
        return datetime.now().strftime("%H:%M:%S")

    # ------------------------------------------------------------------
    # Start / pause / resume / stop
    # ------------------------------------------------------------------
    def start_simulation(self):
        if self.runner.status == SimulationStatus.RUNNING:
            return
        if not self.runner.is_ready():
            QMessageBox.warning(self, "MD not ready",
                                "Load a structure and verify libadobmd is available.")
            self._update_start_enabled()
            return

        self.runner.potential = self.potential_combo.currentText()
        self.runner.qm_method = self.qm_method_combo.currentText()
        self.runner.mm_potential = self.mm_potential_combo.currentText()
        self.runner.total_charge = self.charge_spin.value()
        self.runner.temperature = self.temp_spin.value()
        self.runner.dt_fs = self.dt_spin.value()
        # Forward the seven file-path inputs to the runner. `conf_params`
        # below may override with values from the .conf text pane.
        conf_params = _parse_conf(self.conf_edit.toPlainText())

        self.runner.set_forcefield_files(
            forcefield_file     = conf_params.get("forcefield_file", self._ff_path),
            meam_library_file   = conf_params.get("meam_library_file", self._meam_library_path),
            meam_parameter_file = conf_params.get("meam_parameter_file", self._meam_param_path),
            eam_tabulated_file  = conf_params.get("eam_tabulated_file", self._eam_tabulated_path),
            ml_weights_file     = conf_params.get("ml_weights_file", self._ml_weights_path),
            nn_weights_file     = conf_params.get("nn_weights_file", self._nn_weights_path),
        )
        self.runner.set_qm_region_file(
            conf_params.get("qm_region_file", self._qm_region_path))
        self.runner.gamma_ps = float(conf_params.get("gamma_ps", self.runner.gamma_ps))
        self._last_run_target_temp = self.temp_spin.value()

        # only ever set the .conf by hand.
        if self._data_path:
            self.runner.set_output_paths(self._data_path)

        conf_params = _parse_conf(self.conf_edit.toPlainText())

        # If the .conf pane is empty, or doesn't specify an output_prefix,
        # fall back to a sensible default derived from the .data filename.
        output_prefix = conf_params.get("output_prefix", "").strip()
        if not output_prefix:
            output_prefix = self._default_output_prefix()
            # Reflect the choice back into the pane so the user can see it.
            self.conf_edit.setPlainText(
                _format_conf({**self._ui_to_conf(),
                              **conf_params,
                              "output_prefix": output_prefix}))
        self.runner.set_output_prefix(output_prefix)

        # Log where files will land so the user isn't guessing.
        resolved = self.runner._resolve_prefix()
        self.log_message(f"Output prefix: {resolved}")
        self.log_message(f"  .final.data     : {resolved.with_suffix('.final.data')}")
        self.log_message(f"  .final.xyz      : {resolved.with_suffix('.final.xyz')}")
        self.log_message(f"  .trajectory.xyz : {resolved.with_suffix('.trajectory.xyz')}")
        self.log_message(f"  .run.info       : {resolved.with_suffix('.run.info')}")

        self.runner.start(
            total_steps=self.steps_spin.value(),
            sample_interval=self.sample_spin.value(),
        )

        if self.runner.status != SimulationStatus.RUNNING:
            self._update_start_enabled()
            return

        self.start_btn.setEnabled(False)
        self.pause_btn.setEnabled(True)
        self.stop_btn.setEnabled(True)
        self.status_label.setText("Running...")
        self.progress_bar.setMaximum(self.steps_spin.value())
        self.progress_bar.setValue(0)
        self.log_message(
            f"Simulation started: {self.steps_spin.value()} steps, "
            f"dt={self.dt_spin.value()}fs, ensemble={self.ensemble_combo.currentText()}")
        self.simulation_started.emit()

    def pause_simulation(self):
        self.runner.pause()
        self.pause_btn.setEnabled(False)
        self.resume_btn.setEnabled(True)
        self.status_label.setText("Paused")
        self.log_message("Simulation paused")

    def resume_simulation(self):
        self.runner.resume()
        self.pause_btn.setEnabled(True)
        self.resume_btn.setEnabled(False)
        self.status_label.setText("Running...")
        self.log_message("Simulation resumed")

    def stop_simulation(self):
        self.runner.stop()
        self.reset_ui()
        self.log_message("Simulation stopped")

    def on_simulation_step(self, step: int, time_ps: float, energy: float):
        self.progress_bar.setValue(step)
        self.status_label.setText(
            f"Step: {step}/{self.steps_spin.value()} | "
            f"Time: {time_ps:.2f} ps | E: {energy:.3f} eV"
        )

    def on_simulation_finished(self, results):
        self.reset_ui()
        self.log_message(f"Simulation completed: {len(results.time)} frames")
        self.plot_results(results)
        self.simulation_stopped.emit()

    def on_simulation_error(self, error_msg: str):
        self.reset_ui()
        self.log_message(f"ERROR: {error_msg}")
        QMessageBox.critical(self, "Simulation Error", error_msg)
        self.simulation_stopped.emit()

    def reset_ui(self):
        self.pause_btn.setEnabled(False)
        self.resume_btn.setEnabled(False)
        self.stop_btn.setEnabled(False)
        self.progress_bar.setValue(0)
        self.status_label.setText("Ready")
        self._update_start_enabled()

    def update_display(self):
        if self.runner.status == SimulationStatus.RUNNING:
            last_frame = self.runner.results.get_last_frame()
            if last_frame:
                self.data_updated.emit(last_frame)

    def plot_results(self, results):
        if not results.time:
            return

        self.figure.clear()
        self.temp_figure.clear()

        # -------- Energy ------------------------------------------------
        ax1 = self.figure.add_subplot(111)
        ax1.plot(results.time, results.energy_total, 'b-', label='Total Energy')
        if getattr(results, "energy_potential", None) and any(results.energy_potential):
            ax1.plot(results.time, results.energy_potential, 'g--', label='Potential')
        if getattr(results, "energy_kinetic", None) and any(results.energy_kinetic):
            ax1.plot(results.time, results.energy_kinetic, 'r--', label='Kinetic')
        ax1.set_xlabel('Time (ps)')
        ax1.set_ylabel('Energy (eV)')
        ax1.set_title('Energy vs Time')
        ax1.legend()
        ax1.grid(True, alpha=0.3)

        # -------- Temperature -------------------------------------------
        ax2 = self.temp_figure.add_subplot(111)
        ax2.plot(results.time, results.temperature, 'r-', label='Temperature')
        target = (self._last_run_target_temp
                if self._last_run_target_temp is not None
                else self.temp_spin.value())
        ax2.axhline(y=target, color='g', linestyle='--',
                    label=f'Target: {target:.0f} K')
        ax2.set_xlabel('Time (ps)')
        ax2.set_ylabel('Temperature (K)')
        ax2.set_title('Temperature vs Time')
        ax2.legend()
        ax2.grid(True, alpha=0.3)

        # -------- Pressure (if present) ---------------------------------
        if getattr(self, "pressure_figure", None) is not None:
            self.pressure_figure.clear()
            ax3 = self.pressure_figure.add_subplot(111)
            pressure = getattr(results, "pressure", None)
            if pressure and any(pressure):
                ax3.plot(results.time, pressure, 'm-', label='Pressure')
                ax3.set_ylabel('Pressure (GPa)')
                ax3.legend()
            else:
                ax3.text(0.5, 0.5,
                        "pressure not available\n"
                        "(md_runner doesn't capture it yet)",
                        ha='center', va='center',
                        transform=ax3.transAxes,
                        fontsize=11, color='#888')
            ax3.set_xlabel('Time (ps)')
            ax3.set_title('Pressure vs Time')
            ax3.grid(True, alpha=0.3)
            if hasattr(self, "pressure_canvas"):
                self.pressure_canvas.draw()
            if getattr(self, "_pressure_window", None) is not None:
                self._pressure_window.canvas.draw()

        self.figure.tight_layout()
        self.temp_figure.tight_layout()
        self.canvas.draw()
        self.temp_canvas.draw()

        # -------- Refresh any open pop-out windows ----------------------
        for attr, fig, canvas in [
            ("_energy_window",   self.figure,        self.canvas),
            ("_temp_window",     self.temp_figure,   self.temp_canvas),
            ("_pressure_window", getattr(self, "pressure_figure", None),
                                getattr(self, "pressure_canvas", None)),
        ]:
            w = getattr(self, attr, None)
            if w is not None and fig is not None:
                w.figure = fig
                w.canvas.draw()

    def _pop_out_energy(self):
        if self._energy_window is None:
            self._energy_window = PlotWindow(self.figure, "Energy vs Time", self)
            self._energy_window.finished = None  # no-op; Qt does cleanup
        self._energy_window.show()
        self._energy_window.raise_()
        self._energy_window.activateWindow()

    def _pop_out_temperature(self):
        if self._temp_window is None:
            self._temp_window = PlotWindow(self.temp_figure, "Temperature vs Time", self)
        self._temp_window.show()
        self._temp_window.raise_()
        self._temp_window.activateWindow()

    def _pop_out_pressure(self):
        if self._pressure_window is None:
            self._pressure_window = PlotWindow(
                self.pressure_figure, "Pressure vs Time", self)
        self._pressure_window.show()
        self._pressure_window.raise_()
        self._pressure_window.activateWindow()

    def cleanup(self):
        if hasattr(self, 'update_timer'):
            self.update_timer.stop()
        if self.load_worker is not None:
            try:
                self.load_worker.wait(1000)
            except Exception:
                pass
            self.load_worker = None
        self.runner.cleanup()