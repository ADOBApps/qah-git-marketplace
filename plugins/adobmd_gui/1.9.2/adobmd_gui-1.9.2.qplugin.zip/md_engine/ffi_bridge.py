"""
ffi_bridge.py - FFI bridge to ADOBMD Fortran shared library

Matches the C-ABI surface exported by src/adobmd_module.f90.
"""

import ctypes
import logging
import platform
import sys
import os
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np

if platform.system() == "Windows":
    LIB_EXT = ".dll"
    LIB_FOLDER = "windows"
elif platform.system() == "Darwin":
    LIB_EXT = ".dylib"
    LIB_FOLDER = "macos"
else:
    LIB_EXT = ".so"
    LIB_FOLDER = "linux"


def find_library() -> Optional[Path]:
    here = Path(__file__).parent.resolve()
    candidates = [
        here / "lib" / LIB_FOLDER / f"libadobmd{LIB_EXT}",
        here.parent.parent / "lib" / LIB_FOLDER / f"libadobmd{LIB_EXT}",
        here.parent.parent.parent / "lib" / LIB_FOLDER / f"libadobmd{LIB_EXT}",
        here.parent / "lib_linux" / f"libadobmd{LIB_EXT}",
        here.parent / "lib_win"   / f"libadobmd{LIB_EXT}",
        Path(f"./libadobmd{LIB_EXT}"),
        Path(f"/usr/local/lib/libadobmd{LIB_EXT}"),
        Path(f"/usr/lib/libadobmd{LIB_EXT}"),
    ]
    for p in candidates:
        if p.exists():
            return p
    return None


def _add_dll_dir(lib_path: Path) -> None:
    if platform.system() != "Windows":
        return
    if sys.version_info >= (3, 8):
        os.add_dll_directory(str(lib_path.parent))
    else:
        os.environ["PATH"] = str(lib_path.parent) + os.pathsep + \
                             os.environ.get("PATH", "")


class ADOBMDFortranBridge:
    """
    ctypes bridge to the ADOBMD shared library.

    All handles are opaque `c_void_p` values.  The Fortran side resolves
    them with c_f_pointer.  Each instance owns exactly one handle.
    """

    QM_METHOD_EHT = 1
    QM_METHOD_XTB = 2

    POTENTIAL_LJ            = 1
    POTENTIAL_SW            = 2
    POTENTIAL_QSC           = 3
    POTENTIAL_REAXFF        = 4
    POTENTIAL_MEAM          = 5
    POTENTIAL_AIREBO        = 6
    POTENTIAL_ML_AIREBO     = 7
    POTENTIAL_NN_AIREBO     = 8
    POTENTIAL_EAM_TABULATED = 9
    POTENTIAL_EHT           = 10
    POTENTIAL_ONIOM         = 11
    POTENTIAL_TERSOFF       = 13

    def __init__(self):
        self.lib: Optional[ctypes.CDLL] = None
        self.handle: Optional[int] = None
        self._initialized = False
        # Track which optional symbols exist in the loaded .so, so we can
        # ignore missing file-path setters on older builds.
        self._has_ff_file_setters = False

        lib_path = find_library()
        if lib_path is None:
            logging.warning("[Warning] ADOBMD library not found")
            return

        _add_dll_dir(lib_path)

        try:
            self.lib = ctypes.CDLL(str(lib_path))
            self._setup_functions()
            logging.info(f"[Ok] Loaded ADOBMD library: {lib_path}")
        except Exception as e:  # noqa: BLE001
            logging.error(f"[Error] Failed to load ADOBMD library: {e}")
            self.lib = None
            return

        self.handle = self._call_initialize()
        if self.handle:
            self._initialized = True
            logging.info("[Ok] ADOBMD engine initialized")
        else:
            logging.error("[Error] Failed to initialize ADOBMD engine")

    def _setup_functions(self):
        L = self.lib

        L.adobmd_initialize.argtypes = []
        L.adobmd_initialize.restype  = ctypes.c_void_p

        L.adobmd_finalize.argtypes = [ctypes.c_void_p]
        L.adobmd_finalize.restype  = None

        L.adobmd_set_natoms.argtypes = [ctypes.c_void_p, ctypes.c_int]
        L.adobmd_set_natoms.restype  = None

        L.adobmd_set_atomic_numbers.argtypes = [
            ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_int)]
        L.adobmd_set_atomic_numbers.restype  = None

        L.adobmd_set_coordinates.argtypes = [
            ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_double)]
        L.adobmd_set_coordinates.restype  = None

        L.adobmd_set_velocities.argtypes = [
            ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_double)]
        L.adobmd_set_velocities.restype  = None

        L.adobmd_set_masses.argtypes = [
            ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_double)]
        L.adobmd_set_masses.restype  = None

        L.adobmd_set_box.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(ctypes.c_double)]
        L.adobmd_set_box.restype  = None

        L.adobmd_set_potential.argtypes       = [ctypes.c_void_p, ctypes.c_char_p]
        L.adobmd_set_potential.restype        = None

        L.adobmd_set_mm_potential.argtypes    = [ctypes.c_void_p, ctypes.c_char_p]
        L.adobmd_set_mm_potential.restype     = None

        L.adobmd_set_qm_method.argtypes       = [ctypes.c_void_p, ctypes.c_char_p]
        L.adobmd_set_qm_method.restype        = None

        L.adobmd_set_total_charge.argtypes    = [ctypes.c_void_p, ctypes.c_int]
        L.adobmd_set_total_charge.restype     = None

        L.adobmd_set_ensemble.argtypes        = [
            ctypes.c_void_p, ctypes.c_char_p, ctypes.c_double]
        L.adobmd_set_ensemble.restype         = None

        L.adobmd_set_qm_region.argtypes = [
            ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_int)]
        L.adobmd_set_qm_region.restype  = None

        L.adobmd_set_connectivity.argtypes = [
            ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_int)]
        L.adobmd_set_connectivity.restype  = None

        L.adobmd_set_temperature.argtypes = [ctypes.c_void_p, ctypes.c_double]
        L.adobmd_set_temperature.restype  = None

        L.adobmd_set_time_step.argtypes   = [ctypes.c_void_p, ctypes.c_double]
        L.adobmd_set_time_step.restype    = None

        L.adobmd_set_xtb_accuracy.argtypes = [ctypes.c_void_p, ctypes.c_double]
        L.adobmd_set_xtb_accuracy.restype  = None

        L.adobmd_set_xtb_max_iter.argtypes = [ctypes.c_void_p, ctypes.c_int]
        L.adobmd_set_xtb_max_iter.restype  = None

        L.adobmd_set_xtb_verbosity.argtypes = [ctypes.c_void_p, ctypes.c_int]
        L.adobmd_set_xtb_verbosity.restype  = None

        L.adobmd_get_energy.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(ctypes.c_double)]
        L.adobmd_get_energy.restype  = None

        L.adobmd_get_forces.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(ctypes.c_double)]
        L.adobmd_get_forces.restype  = None

        L.adobmd_get_positions.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(ctypes.c_double)]
        L.adobmd_get_positions.restype  = None

        L.adobmd_get_velocities.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(ctypes.c_double)]
        L.adobmd_get_velocities.restype  = None

        L.adobmd_recompute_forces.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(ctypes.c_double)]
        L.adobmd_recompute_forces.restype  = None

        L.adobmd_run_md_step.argtypes = [ctypes.c_void_p]
        L.adobmd_run_md_step.restype  = None

        L.adobmd_get_version.argtypes = []
        L.adobmd_get_version.restype  = ctypes.c_char_p

        # --- Optional file-path setters (added in newer libadobmd) ------
        self._has_ff_file_setters = True
        optional_setters = [
            "adobmd_set_forcefield_file",
            "adobmd_set_meam_library_file",
            "adobmd_set_meam_parameter_file",
            "adobmd_set_eam_tabulated_file",
            "adobmd_set_ml_weights_file",
            "adobmd_set_nn_weights_file",
            "adobmd_set_qm_region_file",
        ]
        for name in optional_setters:
            try:
                fn = getattr(L, name)
                fn.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
                fn.restype  = None
            except AttributeError:
                self._has_ff_file_setters = False
                logging.warning(
                    "[Warning] libadobmd does not export %s; "
                    "file-path options will be ignored.", name)

    def _call_initialize(self) -> Optional[int]:
        try:
            return self.lib.adobmd_initialize()
        except Exception as e:  # noqa: BLE001
            logging.error(f"Initialize error: {e}")
            return None

    def is_available(self) -> bool:
        return self.lib is not None and self._initialized

    # ------------------------------------------------------------------
    # Setters
    # ------------------------------------------------------------------
    def set_natoms(self, natoms: int) -> None:
        if not self.is_available() or natoms <= 0:
            return
        self.lib.adobmd_set_natoms(self.handle, natoms)

    def set_atomic_numbers(self, atomic_numbers: List[int]) -> None:
        if not self.is_available():
            return
        n = len(atomic_numbers)
        if n == 0:
            return
        arr = (ctypes.c_int * n)(*atomic_numbers)
        self.lib.adobmd_set_atomic_numbers(self.handle, n, arr)

    def set_coordinates(self, positions: np.ndarray) -> None:
        if not self.is_available():
            return
        if positions.ndim != 2 or positions.shape[1] != 3:
            raise ValueError("positions must be (natoms, 3)")
        natoms = positions.shape[0]
        coords_f = np.ascontiguousarray(positions, dtype=np.float64)
        ptr = coords_f.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
        self.lib.adobmd_set_coordinates(self.handle, natoms, ptr)

    def set_velocities(self, velocities: np.ndarray) -> None:
        if not self.is_available():
            return
        if velocities.ndim != 2 or velocities.shape[1] != 3:
            raise ValueError("velocities must be (natoms, 3)")
        natoms = velocities.shape[0]
        vel_f = np.ascontiguousarray(velocities, dtype=np.float64)
        ptr = vel_f.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
        self.lib.adobmd_set_velocities(self.handle, natoms, ptr)

    def set_masses(self, masses: np.ndarray) -> None:
        if not self.is_available():
            return
        natoms = masses.shape[0]
        masses_f = np.ascontiguousarray(masses, dtype=np.float64)
        ptr = masses_f.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
        self.lib.adobmd_set_masses(self.handle, natoms, ptr)

    def set_box(self, box: Tuple[float, float, float]) -> None:
        if not self.is_available():
            return
        arr = (ctypes.c_double * 3)(float(box[0]), float(box[1]), float(box[2]))
        self.lib.adobmd_set_box(self.handle, arr)

    def set_potential(self, potential_name: str) -> None:
        if not self.is_available():
            return
        self.lib.adobmd_set_potential(self.handle, potential_name.encode("utf-8"))

    def set_mm_potential(self, potential_name: str) -> None:
        if not self.is_available():
            return
        self.lib.adobmd_set_mm_potential(
            self.handle, potential_name.encode("utf-8"))

    def set_qm_method(self, method: str) -> None:
        if not self.is_available():
            return
        self.lib.adobmd_set_qm_method(self.handle, method.encode("utf-8"))

    def set_total_charge(self, charge: int) -> None:
        if not self.is_available():
            return
        self.lib.adobmd_set_total_charge(self.handle, int(charge))

    def set_ensemble(self, name: str, gamma_ps: float = 0.1) -> None:
        if not self.is_available():
            return
        self.lib.adobmd_set_ensemble(
            self.handle, name.encode("utf-8"), float(gamma_ps))

    def set_qm_region(self, indices: List[int]) -> None:
        if not self.is_available():
            return
        n = len(indices)
        if n == 0:
            self.lib.adobmd_set_qm_region(
                self.handle, 0, ctypes.POINTER(ctypes.c_int)())
            return
        arr = (ctypes.c_int * n)(*[int(i) for i in indices])
        self.lib.adobmd_set_qm_region(self.handle, n, arr)

    def set_connectivity(self, connectivity: np.ndarray) -> None:
        if not self.is_available():
            return
        if connectivity.ndim != 2 or connectivity.shape[0] != connectivity.shape[1]:
            raise ValueError("connectivity must be square (natoms, natoms)")
        natoms = connectivity.shape[0]
        conn_c = np.ascontiguousarray(connectivity, dtype=np.int32)
        ptr = conn_c.ctypes.data_as(ctypes.POINTER(ctypes.c_int))
        self.lib.adobmd_set_connectivity(self.handle, natoms, ptr)

    def set_temperature(self, temperature: float) -> None:
        if not self.is_available():
            return
        self.lib.adobmd_set_temperature(self.handle, float(temperature))

    def set_time_step(self, dt_fs: float) -> None:
        if not self.is_available():
            return
        self.lib.adobmd_set_time_step(self.handle, float(dt_fs))

    def set_xtb_accuracy(self, accuracy: float) -> None:
        if not self.is_available():
            return
        self.lib.adobmd_set_xtb_accuracy(self.handle, float(accuracy))

    def set_xtb_max_iter(self, max_iter: int) -> None:
        if not self.is_available():
            return
        self.lib.adobmd_set_xtb_max_iter(self.handle, int(max_iter))

    def set_xtb_verbosity(self, verbosity: int) -> None:
        if not self.is_available():
            return
        self.lib.adobmd_set_xtb_verbosity(self.handle, int(verbosity))

    # ------------------------------------------------------------------
    # File-path setters (no-op if the loaded .so predates them)
    # ------------------------------------------------------------------
    def _call_path_setter(self, name: str, path: str) -> None:
        if not self.is_available() or not path:
            return
        fn = getattr(self.lib, name, None)
        if fn is None:
            return
        try:
            fn(self.handle, str(path).encode("utf-8"))
        except Exception as e:  # noqa: BLE001
            logging.warning("[MD] %s failed: %s", name, e)

    def set_forcefield_file(self, path: str) -> None:
        self._call_path_setter("adobmd_set_forcefield_file", path)

    def set_meam_library_file(self, path: str) -> None:
        self._call_path_setter("adobmd_set_meam_library_file", path)

    def set_meam_parameter_file(self, path: str) -> None:
        self._call_path_setter("adobmd_set_meam_parameter_file", path)

    def set_eam_tabulated_file(self, path: str) -> None:
        self._call_path_setter("adobmd_set_eam_tabulated_file", path)

    def set_ml_weights_file(self, path: str) -> None:
        self._call_path_setter("adobmd_set_ml_weights_file", path)

    def set_nn_weights_file(self, path: str) -> None:
        self._call_path_setter("adobmd_set_nn_weights_file", path)

    def set_qm_region_file(self, path: str) -> None:
        self._call_path_setter("adobmd_set_qm_region_file", path)

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------
    def get_forces(self, natoms: int) -> np.ndarray:
        if not self.is_available() or natoms <= 0:
            return np.zeros((max(natoms, 0), 3))
        buf = np.zeros((natoms, 3), dtype=np.float64, order="C")
        ptr = buf.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
        self.lib.adobmd_get_forces(self.handle, ptr)
        return buf

    def get_positions(self, natoms: int) -> np.ndarray:
        if not self.is_available() or natoms <= 0:
            return np.zeros((max(natoms, 0), 3))
        buf = np.zeros((natoms, 3), dtype=np.float64, order="C")
        ptr = buf.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
        self.lib.adobmd_get_positions(self.handle, ptr)
        return buf

    def get_velocities(self, natoms: int) -> np.ndarray:
        if not self.is_available() or natoms <= 0:
            return np.zeros((max(natoms, 0), 3))
        buf = np.zeros((natoms, 3), dtype=np.float64, order="C")
        ptr = buf.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
        self.lib.adobmd_get_velocities(self.handle, ptr)
        return buf

    def get_energy(self) -> float:
        if not self.is_available():
            return 0.0
        e = ctypes.c_double()
        self.lib.adobmd_get_energy(self.handle, ctypes.byref(e))
        return float(e.value)

    def recompute_forces(self) -> float:
        if not self.is_available():
            return 0.0
        e = ctypes.c_double()
        self.lib.adobmd_recompute_forces(self.handle, ctypes.byref(e))
        return float(e.value)

    def run_md_step(self) -> None:
        if not self.is_available():
            return
        self.lib.adobmd_run_md_step(self.handle)

    def get_version(self) -> str:
        if not self.is_available():
            return "Not available"
        v = self.lib.adobmd_get_version()
        return v.decode("utf-8").strip() if v else "Unknown"

    # ------------------------------------------------------------------
    def cleanup(self) -> None:
        if self.lib and self.handle:
            self.lib.adobmd_finalize(self.handle)
            self.handle = None
            self._initialized = False

    def __del__(self):
        try:
            self.cleanup()
        except Exception:  # noqa: BLE001
            pass


_bridge: Optional[ADOBMDFortranBridge] = None


def get_adobmd_bridge() -> Optional[ADOBMDFortranBridge]:
    global _bridge
    if _bridge is None:
        _bridge = ADOBMDFortranBridge()
    return _bridge if _bridge.is_available() else None