"""
ADOBMD tools for the file editor.

Single consolidated module. Everything ADOBMD-specific lives here:

  1. FileTypeDetector          — .data / .ff / .conf detection
  2. AdobmdSyntaxHighlighter   — pure-Python highlighter (3 rule sets)
  3. SimpleTextEditor          — small editor widget (SSH-plugin compatible)
  4. NativeAdobmdHighlighter   — C-backed highlighter with Python fallback
  5. validate_adobmd_data      — .data sanity checks
  6. create_adobmd_template    — insert minimal .data file
  7. extract_xyz_coords        — Atoms section → XYZ
  8. renumber_atoms            — rewrite id column as 1..N
  9. QmRegionDialog            — build/edit QM region list
 10. convert_units             — Å↔Bohr, eV↔Hartree on coordinates
"""

import re
import tempfile
from pathlib import Path, PurePosixPath
from typing import Callable, List, Optional

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QTextEdit, QMessageBox,
    QApplication, QStyle, QToolBar, QStatusBar,
    QDialog, QDialogButtonBox, QHBoxLayout, QSpinBox,
    QPushButton, QLineEdit, QFileDialog,
)
from PySide6.QtGui import (
    QFont, QAction, QIcon, QKeySequence,
    QSyntaxHighlighter, QTextCharFormat, QColor,
)
from PySide6.QtCore import Signal

from .line_number_editor import NumberedTextEdit
from .file_type_detector import FileTypeDetector

# ===========================================================================
# 1. File type detection
# ===========================================================================
# class FileTypeDetector:
#     """Detect ADOBMD file types (single source of truth)."""

#     _EXT_MAP = {
#         '.data':  'adobmd_data',
#         '.ff':    'adobmd_ff',
#         '.conf':  'adobmd_conf',
#         '.input': 'adobmd_conf',
#         '.txt':   'text',
#         '.md':    'text',
#     }

#     @staticmethod
#     def detect_file_type(filepath: str):
#         if not filepath or not Path(filepath).exists():
#             return "unknown", False

#         if FileTypeDetector._is_binary_file(filepath):
#             return "binary", True

#         ext = Path(filepath).suffix.lower()
#         if ext in FileTypeDetector._EXT_MAP:
#             return FileTypeDetector._EXT_MAP[ext], False

#         content_type = FileTypeDetector._detect_by_content(filepath)
#         if content_type:
#             return content_type, False

#         return "text", False

#     @staticmethod
#     def detect_from_name_only(name: str) -> str:
#         if not name:
#             return ""
#         ext = PurePosixPath(name).suffix.lower()
#         return FileTypeDetector._EXT_MAP.get(ext, "")

#     @staticmethod
#     def is_supported_filename(name: str) -> bool:
#         if not name:
#             return False
#         ext = PurePosixPath(name).suffix.lower()
#         return ext in FileTypeDetector._EXT_MAP

#     @staticmethod
#     def _is_binary_file(filepath: str) -> bool:
#         try:
#             with open(filepath, 'rb') as f:
#                 chunk = f.read(4096)
#         except Exception:
#             return False

#         if not chunk:
#             return False
#         if chunk.startswith((b'\xff\xfe\x00\x00', b'\x00\x00\xfe\xff')):
#             return False
#         if chunk.startswith((b'\xff\xfe', b'\xfe\xff')):
#             return False
#         if chunk.startswith(b'\xef\xbb\xbf'):
#             return False
#         try:
#             chunk.decode('utf-8')
#             return False
#         except UnicodeDecodeError:
#             pass
#         if b'\x00' in chunk:
#             return True
#         allowed = bytearray(
#             {7, 8, 9, 10, 12, 13, 27}
#             | (set(range(0x20, 0x100)) - {0x7f})
#         )
#         return bool(chunk.translate(None, allowed))

#     @staticmethod
#     def _detect_by_content(filepath: str):
#         try:
#             with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
#                 head = f.read(2000)
#             low = head.lower()

#             if ("adobmd unified data" in low
#                     or (" atoms" in low and " bonds" in low
#                         and ("atom types" in low or "xlo xhi" in low))):
#                 return "adobmd_data"

#             if ("<atomtypes>" in low or "<bondtypes>" in low
#                     or "<bendtypes>" in low or "<torsiontypes>" in low
#                     or "<nonbonded>" in low or "<regions>" in low
#                     or "<plugins>" in low):
#                 return "adobmd_ff"

#             for ln in head.splitlines():
#                 s = ln.strip()
#                 if not s or s[0] in "#!":
#                     continue
#                 if "=" in s:
#                     key = s.split("=", 1)[0].replace("_", "").strip()
#                     if key.isalnum():
#                         return "adobmd_conf"
#         except Exception:
#             pass
#         return None


# ===========================================================================
# 2. Pure-Python syntax highlighter
# ===========================================================================
class AdobmdSyntaxHighlighter(QSyntaxHighlighter):
    """Syntax highlighter for ADOBMD .data / .ff / .conf files."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.file_type = "text"
        self.highlighting_rules = []
        self.setup_highlighting()

    def set_document_type(self, file_type: str):
        self.file_type = file_type or "text"
        self.setup_highlighting()
        self.rehighlight()

    def setup_highlighting(self):
        self.highlighting_rules = []
        dispatch = {
            "adobmd_data": self.setup_data_highlighting,
            "adobmd_ff":   self.setup_ff_highlighting,
            "adobmd_conf": self.setup_conf_highlighting,
        }
        dispatch.get(self.file_type, self.setup_text_highlighting)()

    def _fmt(self, color, bold=False, underline=False):
        f = QTextCharFormat()
        f.setForeground(QColor(color))
        if bold:
            f.setFontWeight(QFont.Bold)
        if underline:
            f.setFontUnderline(True)
        return f

    def setup_data_highlighting(self):
        self.highlighting_rules.append((
            r'^\s*(Atoms|Bonds|Angles|Dihedrals|Impropers|Masses|'
            r'Velocities|Pair|PairIJ)\b',
            self._fmt("#569CD6", bold=True)))
        self.highlighting_rules.append((
            r'\b(atoms|bonds|angles|dihedrals|impropers|'
            r'atom\s+types|bond\s+types|angle\s+types|'
            r'dihedral\s+types|improper\s+types|'
            r'xlo\s+xhi|ylo\s+yhi|zlo\s+zhi|xy\s+xz\s+yz)\b',
            self._fmt("#DCDCAA")))
        self.highlighting_rules.append((
            r'\b(QM|MM|Q|M)\b', self._fmt("#FF79C6", bold=True)))
        self.highlighting_rules.append((
            r'[-+]?\d*\.\d+(?:[dDeE][-+]?\d+)?', self._fmt("#B5CEA8")))
        self.highlighting_rules.append((
            r'\b\d+\b', self._fmt("#B5CEA8")))
        self.highlighting_rules.append((
            r'\b([A-Z][a-z]?)\b', self._fmt("#4EC9B0")))
        self.highlighting_rules.append((
            r'#.*', self._fmt("#6A9955")))

    def setup_ff_highlighting(self):
        self.highlighting_rules.append((
            r'<[^>]+>', self._fmt("#C586C0", bold=True)))
        self.highlighting_rules.append((
            r'^\s*(atomtype|bond|bend|angle|torsion|dihedral|'
            r'inversion|improper|nonbond|region|region_potential|'
            r'coupling|plugin|override)\b',
            self._fmt("#569CD6", bold=True)))
        self.highlighting_rules.append((
            r'\b(atoms|override)\b', self._fmt("#FF79C6", bold=True)))
        self.highlighting_rules.append((
            r'\b(\.true\.|\.false\.|true|false)\b', self._fmt("#CE9178")))
        self.highlighting_rules.append((
            r'[-+]?\d*\.\d+(?:[dDeE][-+]?\d+)?', self._fmt("#B5CEA8")))
        self.highlighting_rules.append((
            r'\b\d+\b', self._fmt("#B5CEA8")))
        self.highlighting_rules.append((
            r'[!#].*', self._fmt("#6A9955")))

    def setup_conf_highlighting(self):
        self.highlighting_rules.append((
            r'^\s*[A-Za-z_][A-Za-z0-9_]*\s*(?==)',
            self._fmt("#569CD6", bold=True)))
        self.highlighting_rules.append((
            r'\b(\.true\.|\.false\.|true|false)\b', self._fmt("#CE9178")))
        self.highlighting_rules.append((
            r'[-+]?\d*\.\d+(?:[dDeE][-+]?\d+)?', self._fmt("#B5CEA8")))
        self.highlighting_rules.append((
            r'\b\d+\b', self._fmt("#B5CEA8")))
        self.highlighting_rules.append((
            r'[#!].*', self._fmt("#6A9955")))

    def setup_text_highlighting(self):
        self.highlighting_rules.append((
            r'https?://\S+', self._fmt("#569CD6", underline=True)))
        self.highlighting_rules.append((
            r'\b[\w\.-]+@[\w\.-]+\.\w+\b', self._fmt("#4EC9B0")))
        self.highlighting_rules.append((
            r'\b\d+\b', self._fmt("#B5CEA8")))

    def highlightBlock(self, text):
        for pattern, fmt in self.highlighting_rules:
            for m in re.finditer(pattern, text, re.IGNORECASE):
                self.setFormat(m.start(), m.end() - m.start(), fmt)


# ===========================================================================
# 3. SimpleTextEditor widget (unchanged behaviour)
# ===========================================================================
class SimpleTextEditor(QWidget):
    """Text editor with ADOBMD syntax highlighting."""

    upload_requested = Signal(str, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.current_file = None
        self.temp_path = None
        self.remote_path = None
        self.main_window = None
        self.current_file_type = "text"
        self.highlighter = None
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        toolbar = QToolBar()

        self.file_label = QLabel("No file open")
        self.file_label.setStyleSheet(
            "QLabel { padding: 4px; font-weight: bold; color: #2196F3; }"
        )
        toolbar.addWidget(self.file_label)

        self.type_label = QLabel("type: text")
        self.type_label.setStyleSheet(
            "QLabel { padding: 4px 8px; background: #e3f2fd;"
            " color: #0d47a1; border-radius: 3px; font-weight: bold; }"
        )
        toolbar.addWidget(self.type_label)

        toolbar.addSeparator()

        self.save_action = QAction(QIcon(), "Save", self)
        self.save_action.setIcon(
            QApplication.style().standardIcon(QStyle.SP_DialogSaveButton))
        self.save_action.setShortcut(QKeySequence("Ctrl+S"))
        self.save_action.triggered.connect(self.save_file)
        self.save_action.setEnabled(False)
        toolbar.addAction(self.save_action)

        self.save_back_action = QAction(QIcon(), "Save && Upload", self)
        self.save_back_action.setIcon(
            QApplication.style().standardIcon(QStyle.SP_ArrowUp))
        self.save_back_action.setShortcut(QKeySequence("Ctrl+Shift+S"))
        self.save_back_action.triggered.connect(self.save_and_upload)
        self.save_back_action.setEnabled(False)
        toolbar.addAction(self.save_back_action)

        toolbar.addSeparator()

        undo_action = QAction(QIcon(), "Undo", self)
        undo_action.setIcon(
            QApplication.style().standardIcon(QStyle.SP_ArrowBack))
        undo_action.setShortcut(QKeySequence("Ctrl+Z"))
        undo_action.triggered.connect(self.undo)
        toolbar.addAction(undo_action)

        redo_action = QAction(QIcon(), "Redo", self)
        redo_action.setIcon(
            QApplication.style().standardIcon(QStyle.SP_ArrowForward))
        redo_action.setShortcut(QKeySequence("Ctrl+Y"))
        redo_action.triggered.connect(self.redo)
        toolbar.addAction(redo_action)

        layout.addWidget(toolbar)

        self.text_edit = NumberedTextEdit()
        self.text_edit.textChanged.connect(self.on_text_changed)
        self.highlighter = NativeAdobmdHighlighter(self.text_edit.document())
        layout.addWidget(self.text_edit)

        self.status_bar = QStatusBar()
        layout.addWidget(self.status_bar)

    def set_main_window(self, main_window):
        self.main_window = main_window

    def _apply_file_type(self, file_type: str, filename: str = ""):
        self.current_file_type = file_type or "text"
        self.type_label.setText(f"type: {self.current_file_type}")
        if self.highlighter is not None:
            try:
                self.highlighter.set_document_type(
                    self.current_file_type, filename=filename)
            except TypeError:
                self.highlighter.set_document_type(self.current_file_type)

    def _detect_type_for(self, local_path, remote_path) -> str:
        if remote_path:
            name = PurePosixPath(remote_path).name
            ftype = FileTypeDetector.detect_from_name_only(name)
            if ftype:
                return ftype
        if local_path and Path(local_path).exists():
            ftype, _ = FileTypeDetector.detect_file_type(str(local_path))
            if ftype not in ("unknown", "binary"):
                return ftype
        return "text"

    def load_file(self, content: str, filename: str, remote_path: str = None):
        self.text_edit.blockSignals(True)
        self.text_edit.setPlainText(content)
        self.text_edit.blockSignals(False)

        self.current_file = filename
        self.remote_path = remote_path

        file_type = self._detect_type_for(self.temp_path, remote_path)
        self._apply_file_type(file_type, filename=filename)

        if remote_path:
            display_path = PurePosixPath(remote_path).parent
            self.file_label.setText(
                f"Editing: {filename} (from: {display_path})")
        else:
            self.file_label.setText(f"Editing: {filename}")

        self.save_action.setEnabled(False)
        self.save_back_action.setEnabled(False)
        self.status_bar.showMessage(
            f"Loaded {len(content)} characters — detected as {file_type}")

    def load_temp_file(self, temp_path: Path, remote_path: str = None):
        try:
            for encoding in ('utf-8', 'latin-1', 'cp1252'):
                try:
                    content = temp_path.read_text(encoding=encoding)
                    break
                except UnicodeDecodeError:
                    continue
            else:
                content = temp_path.read_bytes().decode(
                    'utf-8', errors='replace')

            self.temp_path = temp_path
            self.remote_path = remote_path
            self.load_file(content, temp_path.name, remote_path)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load file: {e}")

    def save_file(self):
        if not self.temp_path:
            temp_dir = Path.home() / "ADOBMD" / "temp"
            temp_dir.mkdir(parents=True, exist_ok=True)
            self.temp_path = Path(
                tempfile.mktemp(suffix=".txt", dir=str(temp_dir)))
        try:
            content = self.text_edit.toPlainText()
            self.temp_path.write_text(content, encoding='utf-8')
            self.save_action.setEnabled(False)
            self.status_bar.showMessage(f"Saved to: {self.temp_path.name}")
            return True
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save: {e}")
            return False

    def save_and_upload(self):
        if not self.save_file():
            return
        if not self.remote_path:
            QMessageBox.warning(
                self, "Warning",
                "No remote path associated with this file.")
            return
        if not self.main_window or not getattr(
                self.main_window, 'sftp_client', None):
            QMessageBox.warning(
                self, "Warning", "Not connected to server.")
            return

        reply = QMessageBox.question(
            self, "Confirm Upload",
            f"Upload '{self.current_file}' to server?\n"
            f"Destination: {self.remote_path}\n\n"
            "This will overwrite the original file on the server.",
            QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            if hasattr(self.main_window, 'upload_edited_file'):
                self.main_window.upload_edited_file(
                    self.temp_path, self.remote_path)
            else:
                self.upload_requested.emit(
                    str(self.temp_path), self.remote_path)

    def get_content(self) -> str:
        return self.text_edit.toPlainText()

    def undo(self):
        self.text_edit.undo()

    def redo(self):
        self.text_edit.redo()

    def on_text_changed(self):
        self.save_action.setEnabled(True)
        self.save_back_action.setEnabled(True)


# ===========================================================================
# 4. Native C-backed highlighter with Python fallback
# ===========================================================================
import numpy as np

try:
    from .api.highlighter_wrapper import (
        NativeHighlighter, get_native_highlighter, detect_program,
        PROG_UNKNOWN, PROG_ADOBMD_DATA, PROG_ADOBMD_FF, PROG_ADOBMD_CONF,
        HL_KEYWORD, HL_TYPE, HL_COMMENT, HL_STRING, HL_TAG, HL_NUMBER,
        HL_CONSTANT, HL_OPERATOR, HL_SECTION, HL_DIRECTIVE, HL_CARD,
        HL_ROUTE, HL_SPECIES, HL_COORD,
    )
    _NATIVE_IMPORT_OK = True
except Exception:
    _NATIVE_IMPORT_OK = False


if _NATIVE_IMPORT_OK:
    _PROGRAM_FOR_TYPE = {
        "adobmd_data": PROG_ADOBMD_DATA,
        "adobmd_ff":   PROG_ADOBMD_FF,
        "adobmd_conf": PROG_ADOBMD_CONF,
    }
else:
    _PROGRAM_FOR_TYPE = {}


class NativeAdobmdHighlighter(AdobmdSyntaxHighlighter):
    """Native C-backed highlighter with pure-Python fallback."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._native_enabled = True
        self._native = get_native_highlighter() if _NATIVE_IMPORT_OK else None
        self._program = PROG_UNKNOWN if _NATIVE_IMPORT_OK else 0
        self._cap = 256
        self._buf_starts = np.zeros(self._cap, np.int32)
        self._buf_lens   = np.zeros(self._cap, np.int32)
        self._buf_types  = np.zeros(self._cap, np.int32)
        self._formats = {
            HL_KEYWORD:   self._fmt("#569CD6", bold=True),
            HL_TYPE:      self._fmt("#DCDCAA", bold=True),
            HL_COMMENT:   self._fmt("#6A9955"),
            HL_STRING:    self._fmt("#CE9178"),
            HL_TAG:       self._fmt("#C586C0"),
            HL_NUMBER:    self._fmt("#B5CEA8"),
            HL_CONSTANT:  self._fmt("#FF79C6"),
            HL_OPERATOR:  self._fmt("#FF79C6"),
            HL_SECTION:   self._fmt("#C586C0", bold=True),
            HL_DIRECTIVE: self._fmt("#DCDCAA"),
            HL_CARD:      self._fmt("#569CD6", bold=True),
            HL_ROUTE:     self._fmt("#569CD6", bold=True),
            HL_SPECIES:   self._fmt("#FF79C6", bold=True),
            HL_COORD:     self._fmt("#B5CEA8"),
        } if _NATIVE_IMPORT_OK else {}

    def set_document_type(self, file_type: str, filename: str = ""):
        self.file_type = file_type or "text"
        if _NATIVE_IMPORT_OK and self._native is not None:
            if filename:
                self._program = detect_program(filename, "")
            else:
                self._program = _PROGRAM_FOR_TYPE.get(
                    self.file_type, PROG_UNKNOWN)
        else:
            self._program = 0
        super().set_document_type(self.file_type)

    def highlightBlock(self, text):
        if (
            self._native_enabled
            and self._native is not None
            and _NATIVE_IMPORT_OK
            and self._program != PROG_UNKNOWN
        ):
            try:
                n = self._native.lex_line_into(
                    text,
                    self._buf_starts, self._buf_lens, self._buf_types,
                    program=self._program,
                )
            except Exception:
                n = 0
            if n > 0:
                for i in range(n):
                    fmt = self._formats.get(int(self._buf_types[i]))
                    if fmt is not None:
                        self.setFormat(
                            int(self._buf_starts[i]),
                            int(self._buf_lens[i]),
                            fmt,
                        )
                return
        super().highlightBlock(text)

    @property
    def native_available(self) -> bool:
        """True if the C library loaded and the symbol set is bound."""
        return _NATIVE_IMPORT_OK and self._native is not None

    def set_native_enabled(self, enabled: bool) -> None:
        """Force-disable the C path when False; falls back to Python rules."""
        self._native_enabled = bool(enabled)
        self.rehighlight()


# ===========================================================================
# 5. Section helper (used by tools below)
# ===========================================================================
def _section_block(text: str, name: str) -> Optional[str]:
    pattern = re.compile(
        rf'^\s*{name}\s*$', re.MULTILINE | re.IGNORECASE)
    m = pattern.search(text)
    if not m:
        return None
    start = m.end()
    next_hdr = re.search(
        r'^\s*(Atoms|Bonds|Angles|Dihedrals|Impropers|'
        r'Masses|Velocities|Pair|PairIJ|Bond|Angle|Dihedral|Improper)\s*$',
        text[start:], re.MULTILINE | re.IGNORECASE)
    end = start + next_hdr.start() if next_hdr else len(text)
    return text[start:end]


def _find_section_start(text: str, name: str) -> Optional[int]:
    pattern = re.compile(
        rf'^\s*{name}\s*$', re.MULTILINE | re.IGNORECASE)
    m = pattern.search(text)
    return m.start() if m else None


# ===========================================================================
# 6. Validate .data
# ===========================================================================
def validate_adobmd_data(get_text: Callable[[], str],
                         file_type: str,
                         is_binary: bool,
                         notify) -> None:
    if file_type != "adobmd_data" or is_binary:
        notify("info", "This action requires an ADOBMD .data file")
        return
    text = get_text()
    errors: List[str] = []
    warnings: List[str] = []

    m_atoms = re.search(
        r'^\s*(\d+)\s+atoms\b', text, re.MULTILINE | re.IGNORECASE)
    m_bonds = re.search(
        r'^\s*(\d+)\s+bonds\b', text, re.MULTILINE | re.IGNORECASE)
    if not m_atoms:
        errors.append("Missing '<N> atoms' header line")
    if not m_bonds:
        errors.append("Missing '<M> bonds' header line")

    if ("xlo xhi" not in text or "ylo yhi" not in text
            or "zlo zhi" not in text):
        warnings.append("Missing box bounds (xlo/ylo/zlo)")

    if m_atoms:
        expected = int(m_atoms.group(1))
        atoms_block = _section_block(text, "Atoms")
        if atoms_block is not None:
            actual = sum(1 for ln in atoms_block.splitlines()
                         if ln.strip() and not ln.strip().startswith('#'))
            if actual != expected:
                errors.append(
                    f"Atoms header says {expected}, section contains {actual}")

    if m_bonds:
        expected = int(m_bonds.group(1))
        bonds_block = _section_block(text, "Bonds")
        if bonds_block is not None:
            actual = sum(1 for ln in bonds_block.splitlines()
                         if ln.strip() and not ln.strip().startswith('#'))
            if actual != expected:
                errors.append(
                    f"Bonds header says {expected}, section contains {actual}")

    if not errors and not warnings:
        notify("info", "ADOBMD .data file appears valid.")
        return
    msg = []
    if errors:
        msg.append(f"{len(errors)} error(s):")
        msg.extend(f"  • {e}" for e in errors)
    if warnings:
        msg.append(f"{len(warnings)} warning(s):")
        msg.extend(f"  • {w}" for w in warnings)
    notify("warning" if errors else "info", "\n".join(msg))


# ===========================================================================
# 7. Create template
# ===========================================================================
def create_adobmd_template(set_text: Callable[[str], None]) -> None:
    set_text("""# ADOBMD Unified Data File
# Title: Template H2 molecule
# Generated by ADOBMD Editor

2 atoms
1 bonds
0 angles
0 dihedrals
0 impropers

1 atom types
1 bond types

0.0 10.000000 xlo xhi
0.0 10.000000 ylo yhi
0.0 10.000000 zlo zhi

Masses

1 1.008000  # H

Atoms

# id mol type q x y z [region]
1 1 1 0.000000 4.500000 5.000000 5.000000 QM
2 1 1 0.000000 5.500000 5.000000 5.000000 QM

Bonds

# id type atom1 atom2
1 1 1 2

# QM Region Summary
# 2 QM atoms
# QM indices: 1, 2
""")


# ===========================================================================
# 8. Extract Atoms → XYZ
# ===========================================================================
def extract_xyz_coords(get_text: Callable[[], str],
                       file_type: str,
                       is_binary: bool,
                       set_clipboard: Callable[[str], None],
                       notify) -> None:
    if file_type != "adobmd_data" or is_binary:
        notify("info", "This action requires an ADOBMD .data file")
        return

    text = get_text()
    masses_block = _section_block(text, "Masses") or ""
    type_to_symbol = {}
    for ln in masses_block.splitlines():
        ln = ln.strip()
        if not ln or ln.startswith('#'):
            continue
        parts = ln.split('#', 1)
        head = parts[0].split()
        if len(head) < 2:
            continue
        try:
            tid = int(head[0])
        except ValueError:
            continue
        symbol = "X"
        if len(parts) > 1:
            m = re.search(r'\b([A-Z][a-z]?)\b', parts[1])
            if m:
                symbol = m.group(1)
        type_to_symbol[tid] = symbol

    atoms_block = _section_block(text, "Atoms")
    if atoms_block is None:
        notify("warning", "No Atoms section found")
        return

    lines = []
    for ln in atoms_block.splitlines():
        s = ln.strip()
        if not s or s.startswith('#'):
            continue
        toks = s.split('#')[0].split()
        if len(toks) < 7:
            continue
        try:
            type_id = int(toks[2])
            x, y, z = float(toks[4]), float(toks[5]), float(toks[6])
        except (ValueError, IndexError):
            continue
        element = type_to_symbol.get(type_id, "X")
        lines.append(f"{element:<2} {x:15.8f} {y:15.8f} {z:15.8f}")

    if not lines:
        notify("warning", "No atom lines could be parsed")
        return

    xyz = f"{len(lines)}\nADOBMD Atoms section\n" + "\n".join(lines)
    set_clipboard(xyz)
    notify("info", f"Copied {len(lines)} atoms as XYZ to clipboard")


# ===========================================================================
# 9. Renumber atom IDs
# ===========================================================================
def renumber_atoms(text: str, notify) -> Optional[str]:
    if _find_section_start(text, "Atoms") is None:
        notify("warning", "No Atoms section found")
        return None

    lines = text.splitlines(keepends=True)
    out = []
    atom_index = 0
    in_atoms = False
    for ln in lines:
        stripped = ln.strip()
        if stripped.lower() == "atoms":
            in_atoms = True
            out.append(ln)
            continue
        if in_atoms:
            if stripped and not stripped.startswith('#'):
                if re.match(r'^(Atoms|Bonds|Angles|Dihedrals|Impropers|'
                            r'Masses|Velocities|Pair|PairIJ)\s*$',
                            stripped, re.IGNORECASE):
                    in_atoms = False
                    out.append(ln)
                    continue
                atom_index += 1
                toks = stripped.split(None, 1)
                if len(toks) == 2 and toks[0].lstrip('-').isdigit():
                    new_ln = ln.replace(toks[0], str(atom_index), 1)
                    out.append(new_ln)
                    continue
        out.append(ln)

    if atom_index == 0:
        notify("warning", "No atom records were renumbered")
        return None
    notify("info", f"Renumbered {atom_index} atoms to 1..{atom_index}")
    return "".join(out)


# ===========================================================================
# 10. QM region dialog
# ===========================================================================
class QmRegionDialog(QDialog):
    """Small dialog to build a QM-region list for ADOBMD."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Edit QM Region")
        self.setMinimumWidth(380)

        layout = QVBoxLayout(self)

        layout.addWidget(QLabel(
            "Enter QM atom indices (space/comma separated; "
            "ranges like 1-10 allowed):"
        ))

        self.entry = QLineEdit()
        self.entry.setPlaceholderText("1 2 3 10-20 25")
        layout.addWidget(self.entry)

        btn_row = QHBoxLayout()
        self.write_sidecar_btn = QPushButton("Save sidecar .qm.txt…")
        self.write_sidecar_btn.clicked.connect(self._save_sidecar)
        btn_row.addWidget(self.write_sidecar_btn)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        box = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        box.accepted.connect(self.accept)
        box.rejected.connect(self.reject)
        layout.addWidget(box)

    def _parse_indices(self) -> List[int]:
        indices: List[int] = []
        for tok in re.split(r'[\s,]+', self.entry.text().strip()):
            if not tok:
                continue
            if '-' in tok:
                try:
                    a, b = tok.split('-', 1)
                    lo, hi = int(a), int(b)
                    if lo <= hi:
                        indices.extend(range(lo, hi + 1))
                except ValueError:
                    continue
            else:
                try:
                    indices.append(int(tok))
                except ValueError:
                    continue
        return sorted(set(indices))

    def _save_sidecar(self):
        indices = self._parse_indices()
        if not indices:
            QMessageBox.warning(self, "Warning", "No valid indices")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save QM region file", "region.qm.txt",
            "Text files (*.txt)")
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                for idx in indices:
                    f.write(f"{idx}\n")
            QMessageBox.information(
                self, "Saved",
                f"Wrote {len(indices)} indices to:\n{path}")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def build_region_file(self) -> str:
        indices = self._parse_indices()
        return "\n".join(str(i) for i in indices) + "\n"

# ===========================================================================
# 11. Convert units
# ===========================================================================
_ANG_TO_BOHR = 1.8897259886
_BOHR_TO_ANG = 1.0 / _ANG_TO_BOHR


def convert_units(text: str, notify) -> Optional[str]:
    """Convert Atoms-section coordinates between Å and Bohr."""
    atoms_start = _find_section_start(text, "Atoms")
    if atoms_start is None:
        notify("warning", "No Atoms section found")
        return None

    coords = []
    for ln in text[atoms_start:].splitlines():
        s = ln.strip()
        if not s or s.startswith('#'):
            continue
        if re.match(r'^(Bonds|Angles|Dihedrals|Impropers|Masses|'
                    r'Velocities|Pair|PairIJ)\s*$', s, re.IGNORECASE):
            break
        toks = s.split('#')[0].split()
        if len(toks) >= 7:
            try:
                coords.append(abs(float(toks[4])))
            except ValueError:
                pass

    if not coords:
        notify("warning", "Could not read any coordinates")
        return None

    mean_x = sum(coords) / len(coords)
    to_bohr = mean_x < 100.0
    factor = _ANG_TO_BOHR if to_bohr else _BOHR_TO_ANG
    label = "Å→Bohr" if to_bohr else "Bohr→Å"

    lines = text.splitlines(keepends=True)
    out = []
    in_atoms = False
    converted = 0
    for ln in lines:
        stripped = ln.strip()
        if stripped.lower() == "atoms":
            in_atoms = True
            out.append(ln)
            continue
        if in_atoms and stripped and not stripped.startswith('#'):
            if re.match(r'^(Bonds|Angles|Dihedrals|Impropers|Masses|'
                        r'Velocities|Pair|PairIJ)\s*$',
                        stripped, re.IGNORECASE):
                in_atoms = False
                out.append(ln)
                continue
            toks = ln.split()
            if len(toks) >= 7:
                try:
                    x = float(toks[4]) * factor
                    y = float(toks[5]) * factor
                    z = float(toks[6]) * factor
                    toks[4] = f"{x:.6f}"
                    toks[5] = f"{y:.6f}"
                    toks[6] = f"{z:.6f}"
                    out.append(" ".join(toks) + "\n")
                    converted += 1
                    continue
                except (ValueError, IndexError):
                    pass
        out.append(ln)

    if converted == 0:
        notify("info", "Nothing to convert.")
        return None

    notify("info", f"Converted {converted} atom coordinates ({label}).")
    return "".join(out)
