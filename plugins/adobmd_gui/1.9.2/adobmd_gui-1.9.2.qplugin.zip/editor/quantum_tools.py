"""ORCA/VASP/QE/Gaussian helper actions. Pure functions of editor + file_type.

Two groups of functionality live here:

  Pure functions
  --------------
  validate_orca, validate_vasp, validate_qe, validate_gaussian,
  create_orca_template, extract_orca_coords, convert_qe_units

  These take callables (`get_text`, `set_text`, `set_clipboard`,
  `notify`) so they never touch widget internals. That makes them
  trivially testable with plain strings.

  Dialog factories
  ----------------
  KpointsDialog, PoscarConvertDialog

  These return a QDialog whose `exec()` writes the result through the
  caller-provided `set_text` callback. They are still widget-agnostic;
  the dialog is self-contained.
"""

from typing import Callable, Optional

from PySide6.QtWidgets import (
    QDialog, QDialogButtonBox, QVBoxLayout, QHBoxLayout,
    QLabel, QSpinBox, QGroupBox, QRadioButton, QComboBox,
    QMessageBox,
)


# ===========================================================================
# Helpers
# ===========================================================================
def _notify_kind_to_icon(kind: str) -> str:
    """Internal: map a notify() verb to a QMessageBox severity."""
    return kind


# ===========================================================================
# ORCA
# ===========================================================================
def validate_orca(get_text: Callable[[], str], file_type: str,
                  is_binary: bool, notify) -> None:
    if file_type != "orca" or is_binary:
        notify("info", "This action requires an ORCA input file")
        return
    text = get_text()
    errors = []

    if "! " not in text:
        errors.append("No route section found (lines starting with '!')")
    if "*xyz" not in text and "*int" not in text:
        errors.append("No coordinates section found")

    # Extra sanity checks
    lines = text.split("\n")
    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        if stripped.startswith("!") and len(stripped) < 3:
            errors.append(f"Line {i}: empty route command")

    if errors:
        notify(
            "warning",
            f"Found {len(errors)} issue(s):\n\n"
            + "\n".join(f"• {e}" for e in errors),
        )
    else:
        notify("info", "ORCA input file appears valid")


def create_orca_template(set_text: Callable[[str], None]) -> None:
    set_text("""! B3LYP DEF2-SVP OPT FREQ
%pal
nprocs 4
end
%maxcore 2000

* xyz 0 1
  C    0.000000   0.000000   0.000000
  H    0.000000   0.000000   1.090000
  H    1.026000   0.000000  -0.363000
  H   -0.513000  -0.889000  -0.363000
  H   -0.513000   0.889000  -0.363000
*""")


def extract_orca_coords(get_text, file_type, is_binary, set_clipboard,
                        notify) -> None:
    if file_type != "orca" or is_binary:
        notify("info", "This action requires an ORCA input file")
        return
    text = get_text()
    start = text.find("*xyz")
    if start == -1:
        # Try *int
        start = text.find("*int")
    if start == -1:
        notify("warning", "No coordinates section found (*xyz or *int)")
        return
    end = text.find("*", start + 1)
    if end == -1:
        end = len(text)
    coords = text[start:end].strip()
    set_clipboard(coords)
    notify("info", "Coordinates copied to clipboard")


# ===========================================================================
# VASP
# ===========================================================================
def validate_vasp(get_text, file_type, is_binary, notify) -> None:
    if file_type != "vasp" or is_binary:
        notify("info", "This action requires a VASP input file")
        return
    text = get_text()
    if "SYSTEM =" not in text:
        notify("warning", "Missing SYSTEM parameter")
    elif "ENCUT =" not in text:
        notify("warning", "Missing ENCUT parameter")
    else:
        notify("info", "VASP input appears valid")


def convert_poscar(text: str,
                   notify) -> Optional[str]:
    """
    Placeholder POSCAR conversion.

    Detects the 'Direct' / 'Cartesian' line and flips it. Real
    conversion needs the lattice matrix (lines 3–5); that's a proper
    math task, so we only toggle the label here and warn the user.

    Returns the modified text, or None if nothing was changed.
    """
    lines = text.split("\n")
    if len(lines) < 8:
        notify("warning", "Invalid POSCAR format (fewer than 8 lines)")
        return None

    coord_type_line = -1
    for i, line in enumerate(lines):
        if line.strip().lower() in ("direct", "cartesian"):
            coord_type_line = i
            break

    if coord_type_line == -1:
        notify("warning", "Could not find coordinate type "
                          "(Direct / Cartesian)")
        return None

    current = lines[coord_type_line].strip().lower()
    new_type = "Cartesian" if current == "direct" else "Direct"
    lines[coord_type_line] = new_type

    notify(
        "info",
        f"Label changed from {current.title()} to {new_type}.\n\n"
        "Note: actual coordinate conversion requires the lattice "
        "matrix and has NOT been applied.",
    )
    return "\n".join(lines)


class KpointsDialog(QDialog):
    """Generate a VASP KPOINTS file interactively."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Generate KPOINTS")
        self.setMinimumSize(300, 220)

        layout = QVBoxLayout(self)

        grid = QHBoxLayout()
        grid.addWidget(QLabel("Grid:"))
        self.kx = QSpinBox(); self.kx.setRange(1, 50); self.kx.setValue(4)
        self.ky = QSpinBox(); self.ky.setRange(1, 50); self.ky.setValue(4)
        self.kz = QSpinBox(); self.kz.setRange(1, 50); self.kz.setValue(4)
        grid.addWidget(self.kx)
        grid.addWidget(self.ky)
        grid.addWidget(self.kz)
        layout.addLayout(grid)

        center_group = QGroupBox("Centering")
        center_layout = QVBoxLayout()
        self.gamma_radio = QRadioButton("Gamma-centered")
        self.gamma_radio.setChecked(True)
        self.monkhorst_radio = QRadioButton("Monkhorst-Pack")
        center_layout.addWidget(self.gamma_radio)
        center_layout.addWidget(self.monkhorst_radio)
        center_group.setLayout(center_layout)
        layout.addWidget(center_group)

        # Optional shift
        shift_group = QGroupBox("Shift")
        shift_layout = QHBoxLayout()
        self.sx = QSpinBox(); self.sx.setRange(0, 1); self.sx.setValue(0)
        self.sy = QSpinBox(); self.sy.setRange(0, 1); self.sy.setValue(0)
        self.sz = QSpinBox(); self.sz.setRange(0, 1); self.sz.setValue(0)
        shift_layout.addWidget(self.sx)
        shift_layout.addWidget(self.sy)
        shift_layout.addWidget(self.sz)
        shift_group.setLayout(shift_layout)
        layout.addWidget(shift_group)

        box = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        )
        box.accepted.connect(self.accept)
        box.rejected.connect(self.reject)
        layout.addWidget(box)

    def kpoints_text(self) -> str:
        mode = "Gamma" if self.gamma_radio.isChecked() else "Monkhorst-Pack"
        return (
            "Automatic mesh\n"
            "0\n"
            f"{mode}\n"
            f"{self.kx.value()} {self.ky.value()} {self.kz.value()}\n"
            f"{self.sx.value()} {self.sy.value()} {self.sz.value()}\n"
        )


# ===========================================================================
# Quantum ESPRESSO
# ===========================================================================
def validate_qe(get_text, file_type, is_binary, notify) -> None:
    if file_type not in ("qe", "qe_in") or is_binary:
        notify("info", "This action requires a QE input file")
        return
    text = get_text()
    errors = []

    if "&control" not in text.lower():
        errors.append("Missing &control namelist")
    if "&system" not in text.lower():
        errors.append("Missing &system namelist")
    if "ATOMIC_SPECIES" not in text:
        errors.append("Missing ATOMIC_SPECIES card")
    if "ATOMIC_POSITIONS" not in text:
        errors.append("Missing ATOMIC_POSITIONS card")
    if "K_POINTS" not in text:
        errors.append("Missing K_POINTS card")

    if errors:
        notify(
            "warning",
            f"Found {len(errors)} issue(s):\n\n"
            + "\n".join(f"• {e}" for e in errors),
        )
    else:
        notify("info", "QE input appears structurally valid")


# Ry -> eV
_RY_TO_EV = 13.605693122994
# Bohr -> Angstrom
_BOHR_TO_ANG = 0.529177210903


def convert_qe_units(get_text: str, notify) -> Optional[str]:
    """
    Convert the most common energy/length parameters in a QE input from
    Ry / Bohr to eV / Angstrom.

    Only handles simple `key = number [Ry|Bohr]` lines. Everything else
    is left untouched. Returns the new text, or None if no conversions
    were found.
    """
    import re

    converted = 0
    out_lines = []

    # ecutwfc / ecutrho are in Ry; celldm(1) is in Bohr.
    ry_keys = ("ecutwfc", "ecutrho")
    bohr_keys = ("celldm(1)",)

    for line in get_text.split("\n"):
        stripped = line.strip()

        # energy keys: ecutwfc = 30 [Ry]
        m = re.match(
            r"^(\s*)(ecutwfc|ecutrho)(\s*=\s*)([0-9.eE+-]+)(.*)$",
            line, re.IGNORECASE,
        )
        if m:
            try:
                value = float(m.group(4))
                new_value = value * _RY_TO_EV
                out_lines.append(
                    f"{m.group(1)}{m.group(2)}{m.group(3)}"
                    f"{new_value:.6f}  ! was {value} Ry"
                )
                converted += 1
                continue
            except ValueError:
                pass

        # celldm(1) in Bohr
        m = re.match(
            r"^(\s*)(celldm\(1\))(\s*=\s*)([0-9.eE+-]+)(.*)$",
            line, re.IGNORECASE,
        )
        if m:
            try:
                value = float(m.group(4))
                new_value = value * _BOHR_TO_ANG
                out_lines.append(
                    f"{m.group(1)}{m.group(2)}{m.group(3)}"
                    f"{new_value:.6f}  ! was {value} Bohr"
                )
                converted += 1
                continue
            except ValueError:
                pass

        out_lines.append(line)

    if converted == 0:
        notify(
            "info",
            "No convertible quantities found.\n"
            "This only converts ecutwfc, ecutrho (Ry → eV) and "
            "celldm(1) (Bohr → Å).",
        )
        return None

    notify(
        "info",
        f"Converted {converted} value(s): Ry → eV, Bohr → Å.\n"
        "A '! was X Ry/Bohr' comment records the original value."
    )
    return "\n".join(out_lines)


# ===========================================================================
# Gaussian
# ===========================================================================
def validate_gaussian(get_text, file_type, is_binary, notify) -> None:
    if file_type not in ("gaussian", "gaussian_log") or is_binary:
        notify("info", "This action requires a Gaussian input file")
        return
    text = get_text()
    errors = []

    if not text.lstrip().startswith("#") and "\n#" not in text:
        errors.append("No route section found (line starting with '#')")

    lines = [l for l in text.split("\n") if l.strip()]
    if len(lines) < 3:
        errors.append("File too short to be a valid Gaussian input")

    # Look for charge/multiplicity + coordinates: two integers on one line
    import re
    charge_re = re.compile(r"^\s*-?\d+\s+\d+\s*$")
    if not any(charge_re.match(l) for l in lines):
        errors.append("No charge/multiplicity line found")

    if errors:
        notify(
            "warning",
            f"Found {len(errors)} issue(s):\n\n"
            + "\n".join(f"• {e}" for e in errors),
        )
    else:
        notify("info", "Gaussian input appears structurally valid")