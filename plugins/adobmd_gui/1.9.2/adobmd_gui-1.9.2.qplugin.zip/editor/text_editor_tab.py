"""
One editor tab = one file.

Owns:
  - NumberedTextEdit (the code editor with line numbers)
  - its NativeAdobmdHighlighter
  - its LoadingOverlay (during large-file loads)
  - its FindReplaceDialog (lazily created)

Emits:
  - modified()
  - saved(path)
  - closed()

The parent (QuantumEditorWidget) is responsible for putting this in a
QTabWidget and connecting signals.
"""

import os
from pathlib import Path
from typing import Optional

from PySide6.QtCore import Signal, Slot, QThread
from PySide6.QtWidgets import QWidget, QVBoxLayout
from PySide6.QtWidgets import QApplication

from .binary_widget import BinaryEditorWidget, LoadingOverlay
from .find_replace_dialog import FindReplaceDialog
from .line_number_editor import NumberedTextEdit
from .file_type_detector import FileTypeDetector
from .adobmd_tool import NativeAdobmdHighlighter


# Files above this size get an asynchronous load with progress.
LARGE_FILE_BYTES = 5 * 1024 * 1024   # 5 MB


class _TextLoaderWorker(QThread):
    """Reads a text file in the background and emits progress."""

    progress = Signal(int)          # 0..100
    finished = Signal(str, str)     # (content, error_message)

    def __init__(self, filepath: str):
        super().__init__()
        self.filepath = filepath

    def run(self):
        try:
            try:
                total = os.path.getsize(self.filepath)
            except OSError:
                total = 0
            chunks = []
            read = 0
            chunk_size = 256 * 1024
            with open(self.filepath, "r", encoding="utf-8",
                      errors="ignore") as f:
                while True:
                    chunk = f.read(chunk_size)
                    if not chunk:
                        break
                    chunks.append(chunk)
                    read += len(chunk)
                    if total:
                        self.progress.emit(int(read * 100 / total))
            self.progress.emit(100)
            self.finished.emit("".join(chunks), "")
        except Exception as e:
            self.finished.emit("", str(e))


class TextEditorTab(QWidget):
    """One tab. Wraps either a NumberedTextEdit or a BinaryEditorWidget."""

    modified = Signal()
    saved = Signal(str)
    closed = Signal()

    def __init__(self, filepath: str = "", parent=None):
        super().__init__(parent)
        self.filepath = filepath
        self.file_type = "text"
        self.is_binary = False
        self._find_dialog: Optional[FindReplaceDialog] = None
        self._loader: Optional[_TextLoaderWorker] = None

        if filepath:
            self.file_type, self.is_binary = FileTypeDetector.detect_file_type(
                filepath
            )
        else:
            self.file_type, self.is_binary = "text", False

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        if self.is_binary:
            self.editor = BinaryEditorWidget()
            layout.addWidget(self.editor)
            if filepath:
                self.editor.load_file(filepath)
            # BinaryEditorWidget owns its own spinner.
            self._overlay = None
        else:
            self.editor = NumberedTextEdit()
            self.editor.textChanged.connect(self._on_text_changed)
            self.editor.find_requested.connect(self.show_find_dialog)
            self._attach_highlighter()

            self._overlay = LoadingOverlay(self)
            self._overlay.setGeometry(self.rect())

            layout.addWidget(self.editor)

            if filepath:
                self._load_from_disk(filepath)

    # ------------------------------------------------------------------
    # Highlighter
    # ------------------------------------------------------------------
    def _attach_highlighter(self):
        h = NativeAdobmdHighlighter(self.editor.document())
        h.set_document_type(
            self.file_type,
            filename=Path(self.filepath).name if self.filepath else "",
        )
        self.editor.highlighter = h

    def set_file_type(self, file_type: str):
        self.file_type = file_type or "text"
        if hasattr(self.editor, "highlighter"):
            self.editor.highlighter.set_document_type(
                self.file_type,
                filename=Path(self.filepath).name if self.filepath else "",
            )
            self.editor.highlighter.rehighlight()

    # ------------------------------------------------------------------
    # Loading (with overlay)
    # ------------------------------------------------------------------
    def _load_from_disk(self, filepath: str):
        try:
            size = os.path.getsize(filepath)
        except OSError:
            size = 0

        if size and size < LARGE_FILE_BYTES:
            # Synchronous but with a one-frame overlay flash so slow
            # network shares don't look frozen.
            self.show_loading(
                title=f"Loading {Path(filepath).name}",
                detail=f"{size:,} bytes",
                total_bytes=size,
            )
            QApplication.processEvents()
            try:
                with open(filepath, "r", encoding="utf-8",
                          errors="ignore") as f:
                    content = f.read()
                self.editor.setPlainText(content)
                self._attach_highlighter()
            finally:
                self.hide_loading()
            return

        # Large file: async with live progress.
        self.show_loading(
            title=f"Loading {Path(filepath).name}",
            detail=f"0 / {size:,} bytes" if size else "Reading…",
            total_bytes=size,
        )

        loader = _TextLoaderWorker(filepath)
        self._loader = loader

        def on_progress(pct: int):
            if size:
                self.update_loading(
                    pct,
                    detail=f"{int(size * pct / 100):,} / {size:,} bytes",
                )
            else:
                self.update_loading(0, detail=f"{pct}%")

        def on_finished(content: str, error: str):
            try:
                if error:
                    self.hide_loading()
                    return
                if self._overlay is not None:
                    self.update_loading(
                        100, detail="Applying syntax highlighting…"
                    )
                    QApplication.processEvents()
                self.editor.setPlainText(content)
                self._attach_highlighter()
            finally:
                self.hide_loading()
                self._loader = None

        loader.progress.connect(on_progress)
        loader.finished.connect(on_finished)
        loader.start()

    def show_loading(self, title: str, detail: str = "",
                     total_bytes: int = 0):
        if self._overlay is not None:
            self._overlay.show_loading(title, detail, total_bytes)

    def update_loading(self, pct: int, detail: str = ""):
        if self._overlay is not None:
            self._overlay.update_progress(pct, detail)

    def hide_loading(self):
        if self._overlay is not None:
            self._overlay.hide_loading()

    # ------------------------------------------------------------------
    # Find / Replace
    # ------------------------------------------------------------------
    @Slot()
    def show_find_dialog(self):
        if self.is_binary:
            return
        if self._find_dialog is None:
            self._find_dialog = FindReplaceDialog(
                editor=self.editor,
                scope_provider=None,
                parent=self.window(),
            )
        cursor = self.editor.textCursor()
        if cursor.hasSelection():
            sel = cursor.selectedText().replace("\u2029", "\n")
            if "\n" not in sel:
                self._find_dialog.find_input.setText(sel)
        self._find_dialog.showFind()

    @Slot()
    def show_replace_dialog(self):
        if self.is_binary:
            return
        if self._find_dialog is None:
            self._find_dialog = FindReplaceDialog(
                editor=self.editor,
                scope_provider=None,
                parent=self.window(),
            )
        self._find_dialog.showReplace()

    # ------------------------------------------------------------------
    # Save
    # ------------------------------------------------------------------
    def save(self, filepath: Optional[str] = None) -> bool:
        if self.is_binary:
            self.editor.save_file()
            return True
        target = filepath or self.filepath
        if not target:
            return False
        try:
            with open(target, "w", encoding="utf-8") as f:
                f.write(self.editor.toPlainText())
            self.filepath = target
            self.saved.emit(target)
            return True
        except Exception:
            return False

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------
    def is_modified(self) -> bool:
        if self.is_binary:
            return False
        return self.editor.document().isModified()

    def clear_modified(self):
        if not self.is_binary:
            self.editor.document().setModified(False)

    def plain_text(self) -> str:
        if self.is_binary:
            return ""
        return self.editor.toPlainText()

    def set_plain_text(self, text: str):
        if not self.is_binary:
            self.editor.setPlainText(text)

    def text_editor(self) -> Optional[NumberedTextEdit]:
        return None if self.is_binary else self.editor

    # ------------------------------------------------------------------
    # Signals
    # ------------------------------------------------------------------
    @Slot()
    def _on_text_changed(self):
        self.modified.emit()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self._overlay is not None:
            self._overlay.setGeometry(self.rect())

    def closeEvent(self, event):
        if self._find_dialog is not None:
            self._find_dialog.close()
        if self._loader is not None and self._loader.isRunning():
            self._loader.wait(1000)
        super().closeEvent(event)