"""All QSS strings and palette handling for the quantum editor."""

from PySide6.QtGui import QColor, QPalette
from PySide6.QtWidgets import QApplication, QWidget


DARK_QSS = """
    QWidget { background-color: rgb(53, 53, 53); color: white; }
    QPushButton, QComboBox, QToolButton {
        background-color: rgb(65, 65, 65); color: white;
        border: 1px solid #444; padding: 4px; border-radius: 2px;
    }
    QPushButton:hover, QComboBox:hover, QToolButton:hover {
        background-color: rgb(80, 80, 80); border: 1px solid #2a82da;
    }
    QPushButton:pressed, QToolButton:pressed {
        background-color: rgb(40, 40, 40);
    }
    QTabBar::tab {
        background: #444; color: white; padding: 8px;
        border-top-left-radius: 4px; border-top-right-radius: 4px;
    }
    QTabBar::tab:hover { background: #555; }
    QTabBar::tab:selected {
        background: #2b2b2b; border-bottom: 2px solid #2a82da;
    }
    QTextEdit, QPlainTextEdit, QLineEdit, QTreeView, QTableWidget {
        background-color: rgb(25, 25, 25); color: white;
        alternate-background-color: rgb(53, 53, 53);
        selection-background-color: rgb(42, 130, 218);
        selection-color: black; border: none;
    }
    QTextEdit:hover, QTreeView:hover { border: 1px solid #3d3d3d; }
    QStatusBar {
        margin: 0px; padding: 0px;
        border-top: 1px solid #444;
        background-color: #1e1e1e; color: #d4d4d4;
    }
    QStatusBar::item { border: none; }
    QToolTip {
        background-color: #1e1e1e; color: white;
        border: 1px solid #2a82da; padding: 2px;
    }
"""

LIGHT_QSS = (
    "QTextEdit { background-color: white; color: black; }"
    "QPlainTextEdit { background-color: white; color: black; }"
)


def apply_theme(widget: QWidget, theme_name: str):
    if theme_name == "Dark":
        widget.setStyleSheet(DARK_QSS)
    elif theme_name == "Light":
        QApplication.setPalette(QApplication.style().standardPalette())
        widget.setStyleSheet(LIGHT_QSS)
    else:
        # widget.setPalette(QApplication.style().standardPalette())
        # widget.setStyleSheet("")
        pass