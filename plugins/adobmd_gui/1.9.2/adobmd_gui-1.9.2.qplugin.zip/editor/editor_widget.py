"""
ADOBMD File Editor — shell widget.

Adapted from QAH's QuantumEditorWidget (moder_file_editor / plugin_ui.py)
to live inside the ADOBMD GUI plugin.

Assembles:
  - FileExplorer (left)
  - QTabWidget of TextEditorTab (right)
  - Toolbar, status bar
  - Theme switching
  - Find/Replace retargeting
  - ADOBMD Tools menu (Validate, Template, Extract XYZ,
                      Renumber, QM region, Unit conversion)
  - Real Settings dialog (font, tabs, theme, autosave)

All per-tab logic lives in TextEditorTab; all file-tree logic in
FileExplorer; all ADOBMD-specific actions in adobmd_tool.
"""

from pathlib import Path
from typing import List, Optional

from PySide6.QtCore import Qt, QSettings, QTimer
from PySide6.QtGui import QAction, QKeySequence, QFont
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QSplitter, QTabWidget,
    QFileDialog, QMessageBox, QToolBar, QStatusBar, QApplication,
    QStyle, QLabel, QPushButton, QMenu, QDialog,
)

from .file_type_detector import FileTypeDetector
from .binary_widget import SpinnerWidget
from .file_explorer import FileExplorer
from .text_editor_tab import TextEditorTab
from .settings_dialog import SettingsDialog
from . import theme as _theme
from . import adobmd_tool


class AdobmdEditorWidget(QWidget):
    """Top-level editor widget for ADOBMD GUI."""

    def __init__(self, plugin_instance=None):
        super().__init__()
        self.plugin = plugin_instance
        self.settings = QSettings("ADOBMD", "AdobmdEditorWidget")
        self._find_dialog = None
        self._find_target = None

        self.status_bar = QStatusBar()
        self.status_bar.setMaximumHeight(22)
        self.status_bar.setSizeGripEnabled(False)
        self.status_bar.setStyleSheet("""
            QStatusBar {
                margin: 0px;
                padding: 0px;
                border-top: 1px solid #cccccc;
                background: #f0f0f0;
            }
            QStatusBar::item { border: None; }
        """)

        self._build_ui()
        self._connect_signals()

        # Auto-save timer (interval configured by _restore_editor_settings).
        self._auto_save = QTimer(self)
        self._auto_save.timeout.connect(self._on_auto_save)

        # Restore theme, font, tabs, autosave. Order matters:
        #   - stop the timer first (in case persisted value is "disabled")
        #   - restore settings
        #   - start the timer with the persisted interval
        saved_theme = self.settings.value("theme", "System")
        self.apply_theme(saved_theme)
        self._restore_editor_settings()

    # ==================================================================
    # UI construction
    # ==================================================================
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._make_toolbar())

        split = QSplitter(Qt.Horizontal)
        split.setHandleWidth(1)

        self.explorer = FileExplorer(self.settings)
        split.addWidget(self.explorer)

        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.setTabsClosable(True)
        split.addWidget(self.tabs)

        split.setStretchFactor(0, 1)
        split.setStretchFactor(1, 4)
        root.addWidget(split)
        root.addWidget(self.status_bar)

        self.setWindowTitle("ADOBMD File Editor")
        self.new_file()

    def _make_toolbar(self) -> QToolBar:
        bar = QToolBar()

        self.file_type_label = QLabel("No file")
        self.file_type_label.setStyleSheet(
            "color: #2196F3; font-weight: bold; padding: 4px;"
            "border: 1px solid #2196F3; border-radius: 3px;"
        )
        bar.addWidget(self.file_type_label)

        self.toolbar_spinner = SpinnerWidget(self, size=18, color="#2a82da")
        self.toolbar_spinner.setVisible(False)
        bar.addWidget(self.toolbar_spinner)
        bar.addSeparator()

        for text, shortcut, slot, icon in [
            ("New", "Ctrl+N", self.new_file, QStyle.SP_FileIcon),
            ("Open", "Ctrl+O", self.open_file, QStyle.SP_DirOpenIcon),
            ("Save", "Ctrl+S", self.save_file, QStyle.SP_DialogSaveButton),
            ("Delete", "Ctrl+D", self._delete_selected, QStyle.SP_TrashIcon),
        ]:
            act = QAction(text, self)
            act.setIcon(QApplication.style().standardIcon(icon))
            act.setShortcut(QKeySequence(shortcut))
            act.triggered.connect(slot)
            bar.addAction(act)

        bar.addSeparator()

        for text, shortcut, slot in [
            ("Undo", "Ctrl+Z", lambda: self._on_undo_redo(False)),
            ("Redo", "Ctrl+Y", lambda: self._on_undo_redo(True)),
            ("Find", "Ctrl+F", self.show_find),
            ("Replace", "Ctrl+H", self.show_replace),
            ("Go to Line", "Ctrl+G", self.show_goto_line),
        ]:
            act = QAction(text, self)
            act.setShortcut(QKeySequence(shortcut))
            act.triggered.connect(slot)
            bar.addAction(act)

        bar.addSeparator()
        bar.addWidget(self._make_adobmd_menu())

        self.settings_action = QAction("Settings", self)
        self.settings_action.setIcon(
            QApplication.style().standardIcon(QStyle.SP_ComputerIcon)
        )
        self.settings_action.triggered.connect(self.open_settings)
        bar.addAction(self.settings_action)

        return bar

    def _make_adobmd_menu(self) -> QPushButton:
        btn = QPushButton("ADOBMD Tools")
        btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50; color: white;
                border: none; padding: 5px 10px; border-radius: 3px;
            }
            QPushButton:hover { background-color: #45a049; }
        """)
        menu = QMenu(btn)

        menu.addAction("Validate .data file", self._tool_validate_data)
        menu.addAction("Create .data template", self._tool_create_template)
        menu.addSeparator()
        menu.addAction("Extract Atoms section → XYZ (clipboard)",
                       self._tool_extract_xyz)
        menu.addAction("Renumber atom IDs", self._tool_renumber)
        menu.addSeparator()
        menu.addAction("Edit QM region…", self._tool_qm_region_dialog)
        menu.addAction("Convert units (Å↔Bohr, eV↔Hartree)…",
                       self._tool_convert_units)

        btn.setMenu(menu)
        return btn

    def _connect_signals(self):
        self.tabs.tabCloseRequested.connect(self._close_tab)
        self.tabs.currentChanged.connect(self._on_tab_changed)
        self.explorer.fileActivated.connect(self.open_path)
        self.explorer.fileDeleted.connect(self._on_file_deleted)

    # ==================================================================
    # File loading
    # ==================================================================
    def open_file(self):
        filename, _ = QFileDialog.getOpenFileName(
            self, "Open File", "",
            "ADOBMD Files (*.data *.ff *.conf *.input);;"
            "Unified Data (*.data);;"
            "Force Field (*.ff);;"
            "Configuration (*.conf *.input);;"
            "Plain Text (*.txt *.md);;"
            "All Files (*.*)"
        )
        if filename:
            self.open_path(filename)

    def open_path(self, filepath: str):
        """Open or focus a tab for the given file path."""
        for i in range(self.tabs.count()):
            if self.tabs.tabToolTip(i) == filepath:
                self.tabs.setCurrentIndex(i)
                return

        self._start_toolbar_spinner()
        QApplication.processEvents()

        try:
            tab = TextEditorTab(filepath=filepath)
        except Exception as e:
            self._stop_toolbar_spinner()
            QMessageBox.critical(
                self, "Open Error", f"Could not open file:\n{e}"
            )
            return
        finally:
            self._stop_toolbar_spinner()

        self._apply_saved_settings_to_tab(tab)

        tab.modified.connect(lambda t=tab: self._mark_modified(t))
        tab.saved.connect(lambda p, t=tab: self._on_tab_saved(t, p))
        tab.closed.connect(lambda t=tab: self._on_tab_closed(t))

        idx = self.tabs.addTab(tab, Path(filepath).name)
        self.tabs.setTabToolTip(idx, filepath)
        self.tabs.setCurrentIndex(idx)

        self.status_bar.showMessage(f"Opened: {filepath}", 3000)

    # ------------------------------------------------------------------
    # Toolbar spinner helpers
    # ------------------------------------------------------------------
    def _start_toolbar_spinner(self):
        self.toolbar_spinner.setVisible(True)
        self.toolbar_spinner.start()

    def _stop_toolbar_spinner(self):
        self.toolbar_spinner.stop()
        self.toolbar_spinner.setVisible(False)

    def new_file(self):
        tab = TextEditorTab()
        self._apply_saved_settings_to_tab(tab)

        tab.modified.connect(lambda t=tab: self._mark_modified(t))
        tab.saved.connect(lambda p, t=tab: self._on_tab_saved(t, p))
        tab.closed.connect(lambda t=tab: self._on_tab_closed(t))

        idx = self.tabs.addTab(tab, "new.data")
        self.tabs.setTabToolTip(idx, "")
        self.tabs.setCurrentIndex(idx)

    def _close_tab(self, index: int):
        tab = self.tabs.widget(index)
        if not isinstance(tab, TextEditorTab):
            return
        if tab.is_modified():
            reply = QMessageBox.question(
                self, "Unsaved Changes",
                "Save before closing?",
                QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel,
            )
            if reply == QMessageBox.Cancel:
                return
            if reply == QMessageBox.Save:
                if not self._save_tab(tab):
                    return
        self._detach_find_dialog_for(tab)
        self.tabs.removeTab(index)
        tab.deleteLater()

    def _on_tab_closed(self, tab: TextEditorTab):
        idx = self.tabs.indexOf(tab)
        if idx >= 0:
            self._detach_find_dialog_for(tab)
            self.tabs.removeTab(idx)

    # ==================================================================
    # Save
    # ==================================================================
    def save_file(self):
        tab = self.current_tab()
        if tab is None:
            return
        if not tab.filepath:
            self.save_file_as()
            return
        if tab.save():
            self.status_bar.showMessage(f"Saved: {tab.filepath}", 3000)

    def save_file_as(self):
        tab = self.current_tab()
        if tab is None:
            return
        filename, _ = QFileDialog.getSaveFileName(
            self, "Save File As", tab.filepath or "",
            "ADOBMD Data Files (*.data);;"
            "Force Field (*.ff);;"
            "Configuration (*.conf *.input);;"
            "Plain Text (*.txt *.md);;"
            "All Files (*.*)"
        )
        if not filename:
            return
        if tab.save(filename):
            idx = self.tabs.currentIndex()
            self.tabs.setTabText(idx, Path(filename).name)
            self.tabs.setTabToolTip(idx, filename)
            ftype, is_bin = FileTypeDetector.detect_file_type(filename)
            tab.file_type = ftype
            tab.is_binary = is_bin
            if hasattr(tab, "set_file_type"):
                tab.set_file_type(ftype)
            self.file_type_label.setText(ftype.upper())
            self.status_bar.showMessage(f"Saved as: {filename}", 3000)

    def _save_tab(self, tab: TextEditorTab) -> bool:
        if not tab.filepath:
            self.save_file_as()
            return tab.filepath != ""
        return tab.save()

    # ==================================================================
    # Helpers
    # ==================================================================
    def current_tab(self) -> Optional[TextEditorTab]:
        w = self.tabs.currentWidget()
        return w if isinstance(w, TextEditorTab) else None

    def _on_undo_redo(self, redo: bool):
        tab = self.current_tab()
        if tab is None or tab.is_binary:
            return
        ed = tab.text_editor()
        if ed is not None:
            (ed.redo if redo else ed.undo)()

    def _mark_modified(self, tab: TextEditorTab):
        idx = self.tabs.indexOf(tab)
        if idx < 0:
            return
        title = self.tabs.tabText(idx)
        if not title.endswith("*"):
            self.tabs.setTabText(idx, title + "*")

    def _on_tab_saved(self, tab: TextEditorTab, path: str):
        idx = self.tabs.indexOf(tab)
        if idx < 0:
            return
        title = self.tabs.tabText(idx).rstrip("*")
        self.tabs.setTabText(idx, title)

    def _on_tab_changed(self, index: int):
        tab = self.tabs.widget(index)
        if not isinstance(tab, TextEditorTab):
            self.file_type_label.setText("NO FILE")
            return
        self.file_type_label.setText(tab.file_type.upper())
        if self._find_dialog is not None and not tab.is_binary:
            ed = tab.text_editor()
            if ed is not None:
                self._find_dialog._editor = ed
                self._find_target = tab

    def _on_file_deleted(self, filepath: str):
        for i in range(self.tabs.count() - 1, -1, -1):
            tp = self.tabs.tabToolTip(i)
            if tp == filepath or tp.startswith(filepath + "/"):
                self._close_tab(i)

    def _delete_selected(self):
        self.explorer.delete_selected()

    def _on_auto_save(self):
        tab = self.current_tab()
        if tab and tab.filepath and tab.is_modified():
            if tab.save():
                self.status_bar.showMessage(
                    f"Auto-saved: {tab.filepath}", 2000
                )

    # ==================================================================
    # Find / Replace
    # ==================================================================
    def show_find(self):
        self._open_find("find")

    def show_replace(self):
        self._open_find("replace")

    def _open_find(self, mode: str):
        tab = self.current_tab()
        if tab is None or tab.is_binary:
            return
        ed = tab.text_editor()
        if ed is None:
            return

        if self._find_dialog is None:
            from .find_replace_dialog import FindReplaceDialog
            self._find_dialog = FindReplaceDialog(
                editor=ed,
                scope_provider=self._all_text_editors,
                parent=self,
            )

        self._find_dialog._editor = ed
        self._find_target = tab

        if mode == "replace":
            self._find_dialog.showReplace()
        else:
            self._find_dialog.showFind()

    def _detach_find_dialog_for(self, tab: TextEditorTab):
        if self._find_target is tab:
            if self._find_dialog is not None:
                self._find_dialog.close()
            self._find_dialog = None
            self._find_target = None

    def _all_text_editors(self) -> List:
        result = []
        for i in range(self.tabs.count()):
            t = self.tabs.widget(i)
            if isinstance(t, TextEditorTab) and not t.is_binary:
                ed = t.text_editor()
                if ed is not None:
                    result.append(ed)
        return result

    def show_goto_line(self):
        tab = self.current_tab()
        if tab is None or tab.is_binary:
            return
        ed = tab.text_editor()
        if ed is not None and hasattr(ed, "_prompt_goto_line"):
            ed._prompt_goto_line()

    # ==================================================================
    # ADOBMD tools
    # ==================================================================
    def _notify(self, kind: str, message: str):
        if kind == "warning":
            QMessageBox.warning(self, "ADOBMD Tools", message)
        elif kind == "error":
            QMessageBox.critical(self, "ADOBMD Tools", message)
        else:
            QMessageBox.information(self, "ADOBMD Tools", message)

    def _current_text_context(self):
        """
        Return (get_text, set_text, file_type, is_binary) for the
        current tab, or None if the tab is absent/binary.

        `set_text` preserves undo history and marks the tab modified
        so tool-driven edits are visible in the tab title and trigger
        the save prompt on close.
        """
        tab = self.current_tab()
        if tab is None:
            self._notify("info", "Open a file first.")
            return None
        if tab.is_binary:
            return (
                lambda: "",
                lambda s: None,
                tab.file_type,
                True,
            )
        ed = tab.text_editor()
        if ed is None:
            self._notify("info", "No text editor available.")
            return None

        def _set_text(new_text: str):
            if not isinstance(new_text, str):
                return
            if new_text == ed.toPlainText():
                return
            cursor = ed.textCursor()
            ed.beginEditBlock()
            try:
                ed.selectAll()
                ed.insertPlainText(new_text)
            finally:
                ed.endEditBlock()
                ed.setTextCursor(cursor)
            # Mark modified so the tab title shows "*"
            doc = ed.document()
            doc.setModified(True)

        return (
            ed.toPlainText,
            _set_text,
            tab.file_type,
            False,
        )

    # ---- Validate .data --------------------------------------------
    def _tool_validate_data(self):
        ctx = self._current_text_context()
        if ctx is None:
            return
        get_text, _, ftype, is_bin = ctx
        adobmd_tool.validate_adobmd_data(
            get_text, ftype, is_bin, self._notify
        )

    # ---- Create template ------------------------------------------
    def _tool_create_template(self):
        tab = self.current_tab()
        if tab is None or tab.is_binary:
            self._notify("info", "This action requires a text editor.")
            return
        _, set_text, _, _ = self._current_text_context()
        adobmd_tool.create_adobmd_template(set_text)

    # ---- Extract Atoms → XYZ ---------------------------------------
    def _tool_extract_xyz(self):
        ctx = self._current_text_context()
        if ctx is None:
            return
        get_text, _, ftype, is_bin = ctx
        adobmd_tool.extract_xyz_coords(
            get_text, ftype, is_bin,
            lambda s: QApplication.clipboard().setText(s),
            self._notify,
        )

    # ---- Renumber atom IDs -----------------------------------------
    def _tool_renumber(self):
        ctx = self._current_text_context()
        if ctx is None:
            return
        get_text, set_text, ftype, is_bin = ctx
        if ftype != "adobmd_data" or is_bin:
            self._notify(
                "info", "This action requires an ADOBMD .data file"
            )
            return
        new_text = adobmd_tool.renumber_atoms(get_text(), self._notify)
        if new_text is not None:
            set_text(new_text)

    # ---- QM region dialog -------------------------------------------
    def _tool_qm_region_dialog(self):
        """
        Open the QM-region builder. The dialog does NOT overwrite the
        document; it only writes the region to a sidecar .qm.txt file
        if the user clicks "Save sidecar". If they accept, we append
        a short "# QM indices: …" comment at the bottom of the file
        so it can be referenced by md_input.f90.
        """
        ctx = self._current_text_context()
        if ctx is None:
            return
        get_text, set_text, ftype, is_bin = ctx
        if ftype != "adobmd_data" or is_bin:
            self._notify(
                "info", "This action requires an ADOBMD .data file"
            )
            return

        dlg = adobmd_tool.QmRegionDialog(self)
        if dlg.exec() != QDialog.Accepted:
            return

        indices = dlg._parse_indices()
        if not indices:
            self._notify("info", "No QM indices entered.")
            return

        # Append a QM-index comment to the end of the file, unless the
        # user already has one (we replace it in place).
        text = get_text()
        new_line = "# QM indices: " + ", ".join(str(i) for i in indices)
        lines = text.splitlines()
        replaced = False
        for i, ln in enumerate(lines):
            if ln.strip().startswith("# QM indices:"):
                lines[i] = new_line
                replaced = True
                break
        if not replaced:
            if lines and lines[-1].strip():
                lines.append("")
            lines.append(new_line)
        new_text = "\n".join(lines) + "\n"

        set_text(new_text)
        self.status_bar.showMessage(
            f"Recorded {len(indices)} QM indices in file", 3000
        )

    # ---- Unit converter --------------------------------------------
    def _tool_convert_units(self):
        ctx = self._current_text_context()
        if ctx is None:
            return
        get_text, set_text, ftype, is_bin = ctx
        if ftype != "adobmd_data" or is_bin:
            self._notify(
                "info", "This action requires an ADOBMD .data file"
            )
            return
        new_text = adobmd_tool.convert_units(
            get_text(), self._notify
        )
        if new_text is not None:
            set_text(new_text)

    # ==================================================================
    # Settings / theme
    # ==================================================================
    def open_settings(self):
        dlg = SettingsDialog(
            apply_font=self._apply_font,
            apply_tabs=self._apply_tabs,
            apply_theme=self.apply_theme,
            apply_autosave=self._apply_autosave,
            apply_highlighter_mode=self._apply_highlighter_mode,
            parent=self,
        )
        dlg.exec()

    def apply_theme(self, name: str):
        _theme.apply_theme(self, name)
        self.settings.setValue("theme", name)

    def _apply_font(self, font: QFont):
        for i in range(self.tabs.count()):
            t = self.tabs.widget(i)
            if not isinstance(t, TextEditorTab) or t.is_binary:
                continue
            ed = t.text_editor()
            if ed is not None:
                ed.setFont(font)

    def _apply_tabs(self, tab_size: int, use_spaces: bool):
        for i in range(self.tabs.count()):
            t = self.tabs.widget(i)
            if not isinstance(t, TextEditorTab) or t.is_binary:
                continue
            ed = t.text_editor()
            if ed is None:
                continue
            metrics = ed.fontMetrics()
            ed.setTabStopDistance(
                tab_size * metrics.horizontalAdvance(" ")
            )
            ed.use_spaces = use_spaces
            ed.tab_size = tab_size

    def _apply_autosave(self, enabled: bool, seconds: int):
        # Always stop the timer first so an in-flight tick cannot fire
        # against a stale configuration while we are restarting.
        self._auto_save.stop()
        if enabled:
            self._auto_save.setInterval(max(5, int(seconds)) * 1000)
            self._auto_save.start()

    def _restore_editor_settings(self):
        s = self.settings

        family = s.value("font_family", "Consolas", type=str)
        size = s.value("font_size", 11, type=int)
        bold = s.value("font_bold", False, type=bool)
        italic = s.value("font_italic", False, type=bool)
        font = QFont(family, size)
        font.setBold(bold)
        font.setItalic(italic)
        self._apply_font(font)

        tab_size = s.value("tab_size", 4, type=int)
        use_spaces = s.value("use_spaces", True, type=bool)
        self._apply_tabs(tab_size, use_spaces)

        autosave_enabled = s.value("autosave_enabled", True, type=bool)
        autosave_interval = s.value("autosave_interval", 60, type=int)
        self._apply_autosave(autosave_enabled, autosave_interval)

        self._apply_highlighter_mode(
            s.value("use_native_highlighter", True, type=bool)
        )

    def _apply_saved_settings_to_tab(self, tab: TextEditorTab):
        if not isinstance(tab, TextEditorTab) or tab.is_binary:
            return
        ed = tab.text_editor()
        if ed is None:
            return

        s = self.settings
        font = QFont(
            s.value("font_family", "Consolas", type=str),
            s.value("font_size", 11, type=int),
        )
        font.setBold(s.value("font_bold", False, type=bool))
        font.setItalic(s.value("font_italic", False, type=bool))
        ed.setFont(font)

        tab_size = s.value("tab_size", 4, type=int)
        use_spaces = s.value("use_spaces", True, type=bool)
        metrics = ed.fontMetrics()
        ed.setTabStopDistance(
            tab_size * metrics.horizontalAdvance(" ")
        )
        ed.use_spaces = use_spaces
        ed.tab_size = tab_size
    
        use_native = s.value("use_native_highlighter", True, type=bool)
        hl = getattr(ed, "highlighter", None) if ed is not None else None
        if hl is not None and hasattr(hl, "set_native_enabled"):
            hl.set_native_enabled(use_native)

    def _apply_highlighter_mode(self, use_native: bool):
        self.settings.setValue("use_native_highlighter", use_native)
        for i in range(self.tabs.count()):
            t = self.tabs.widget(i)
            if not isinstance(t, TextEditorTab) or t.is_binary:
                continue
            ed = t.text_editor()
            hl = getattr(ed, "highlighter", None) if ed else None
            if hl is not None and hasattr(hl, "set_native_enabled"):
                hl.set_native_enabled(use_native)

    def set_native_highlighter(self, enabled: bool) -> None:
        """Forward the user preference to the highlighter, if it supports it."""
        ed = self.text_editor()
        hl = getattr(ed, "highlighter", None) if ed is not None else None
        if hl is not None and hasattr(hl, "set_native_enabled"):
            hl.set_native_enabled(enabled)