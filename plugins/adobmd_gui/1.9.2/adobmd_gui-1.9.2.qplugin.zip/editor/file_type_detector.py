"""
ADOBMD file type detection.

Owns the single source of truth for:
    .data  -> "adobmd_data"
    .ff    -> "adobmd_ff"
    .conf  -> "adobmd_conf"   (and .input)
    .txt   -> "text"
    .md    -> "text"
    anything binary        -> "binary"
    anything else          -> "text"
"""

from pathlib import Path, PurePosixPath


class FileTypeDetector:
    """Detect ADOBMD file types."""

    _EXT_MAP = {
        '.data':  'adobmd_data',
        '.ff':    'adobmd_ff',
        '.conf':  'adobmd_conf',
        '.input': 'adobmd_conf',
        '.txt':   'text',
        '.md':    'text',
    }

    @staticmethod
    def detect_file_type(filepath: str):
        """
        Detect file type and whether it's binary.

        Returns: (file_type, is_binary)
        """
        if not filepath or not Path(filepath).exists():
            return "unknown", False

        if FileTypeDetector._is_binary_file(filepath):
            return "binary", True

        ext = Path(filepath).suffix.lower()
        if ext in FileTypeDetector._EXT_MAP:
            return FileTypeDetector._EXT_MAP[ext], False

        content_type = FileTypeDetector._detect_by_content(filepath)
        if content_type:
            return content_type, False

        return "text", False

    @staticmethod
    def detect_from_name_only(name: str) -> str:
        """Detect type using ONLY a filename (no filesystem access)."""
        if not name:
            return ""
        ext = PurePosixPath(name).suffix.lower()
        return FileTypeDetector._EXT_MAP.get(ext, "")

    @staticmethod
    def is_supported_filename(name: str) -> bool:
        """True if `name` is one of the ADOBMD-recognised extensions."""
        if not name:
            return False
        ext = PurePosixPath(name).suffix.lower()
        return ext in FileTypeDetector._EXT_MAP

    @staticmethod
    def _is_binary_file(filepath: str) -> bool:
        try:
            with open(filepath, 'rb') as f:
                chunk = f.read(4096)
        except Exception:
            return False

        if not chunk:
            return False

        # Explicit BOMs -> text
        if chunk.startswith((b'\xff\xfe\x00\x00', b'\x00\x00\xfe\xff')):
            return False
        if chunk.startswith((b'\xff\xfe', b'\xfe\xff')):
            return False
        if chunk.startswith(b'\xef\xbb\xbf'):
            return False

        # Try UTF-8 first
        try:
            chunk.decode('utf-8')
            return False
        except UnicodeDecodeError:
            pass

        # Embedded NUL -> binary
        if b'\x00' in chunk:
            return True

        # Windows-1252 / Latin-1 fallback
        allowed = bytearray(
            {7, 8, 9, 10, 12, 13, 27}
            | (set(range(0x20, 0x100)) - {0x7f})
        )
        return bool(chunk.translate(None, allowed))

    @staticmethod
    def _detect_by_content(filepath: str):
        """Content sniff for files whose extension is unknown or generic."""
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                head = f.read(2000)
            low = head.lower()

            # .data header
            if ("adobmd unified data" in low
                    or (" atoms" in low and " bonds" in low
                        and ("atom types" in low or "xlo xhi" in low))):
                return "adobmd_data"

            # .ff sections
            if ("<atomtypes>" in low or "<bondtypes>" in low
                    or "<bendtypes>" in low or "<torsiontypes>" in low
                    or "<nonbonded>" in low or "<regions>" in low
                    or "<plugins>" in low):
                return "adobmd_ff"

            # .conf: any non-comment line that has "key = value"
            for ln in head.splitlines():
                s = ln.strip()
                if not s or s[0] in "#!":
                    continue
                if "=" in s:
                    key = s.split("=", 1)[0].replace("_", "").strip()
                    if key.isalnum():
                        return "adobmd_conf"
        except Exception:
            pass
        return None