from pathlib import Path

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QProgressBar,
    QPushButton, QLabel, QMessageBox, QAbstractItemView,
    QTableWidget, QHeaderView, QTableWidgetItem, QStackedLayout,
    QSizePolicy
)
from PySide6.QtGui import (
    QFont, QMovie, QPainter, QColor, QPen, QPixmap
)
from PySide6.QtCore import (
    Qt, QThread, Signal, QTimer, QSize, QPropertyAnimation,
    QEasingCurve, QRectF
)


# ===========================================================================
# Spinner widget (custom painted, no external asset required)
# ===========================================================================
class SpinnerWidget(QWidget):
    """
    A small hand-drawn loading spinner.

    Rotates a set of tapered arcs around a circle. Uses QPainter so it
    needs no image assets and works on every platform.
    """

    def __init__(self, parent=None, size=48, color="#2a82da", num_arcs=12):
        super().__init__(parent)
        self._size = size
        self._color = QColor(color)
        self._num_arcs = num_arcs
        self._angle = 0
        self.setFixedSize(size, size)

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._advance)
        self._timer.setInterval(70)

    def start(self):
        self.show()
        self._timer.start()

    def stop(self):
        self._timer.stop()
        self.hide()

    def _advance(self):
        self._angle = (self._angle + 30) % 360
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        cx = self._size / 2.0
        cy = self._size / 2.0
        radius = self._size / 2.0 - 6.0
        arc_len = 360.0 / self._num_arcs

        for i in range(self._num_arcs):
            # Fade alpha from the leading arc (bright) to trailing (dim).
            step = (i + self._angle / arc_len) % self._num_arcs
            alpha = int(30 + 200 * (step / self._num_arcs))
            color = QColor(self._color)
            color.setAlpha(alpha)

            pen = QPen(color)
            pen.setWidth(3)
            pen.setCapStyle(Qt.RoundCap)
            painter.setPen(pen)

            start_angle = int((i * arc_len + self._angle) * 16)
            painter.drawArc(
                QRectF(cx - radius, cy - radius, radius * 2, radius * 2),
                start_angle,
                int(arc_len * 16),
            )

        painter.end()


# ===========================================================================
# Loading overlay: dim background + spinner + labels
# ===========================================================================
class LoadingOverlay(QWidget):
    """
    Semi-transparent overlay drawn on top of a parent widget.

    Shows a spinner, a status message, and an optional determinate
    progress bar. Call show_loading() / update_progress() / hide_loading().
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setStyleSheet(
            "LoadingOverlay { background-color: rgba(20, 20, 20, 200); }"
        )

        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)
        layout.setSpacing(12)

        self.spinner = SpinnerWidget(self, size=56, color="#2a82da")
        layout.addWidget(self.spinner, alignment=Qt.AlignHCenter)

        self.title_label = QLabel("Loading…")
        self.title_label.setAlignment(Qt.AlignCenter)
        self.title_label.setStyleSheet(
            "color: #f8f8f2; font-size: 16px; font-weight: bold;"
        )
        layout.addWidget(self.title_label)

        self.detail_label = QLabel("")
        self.detail_label.setAlignment(Qt.AlignCenter)
        self.detail_label.setStyleSheet("color: #b0b0b0; font-size: 12px;")
        layout.addWidget(self.detail_label)

        # Thin determinate bar under the labels. Hidden if the total
        # size is unknown.
        self.progress = QProgressBar()
        self.progress.setFixedWidth(260)
        self.progress.setTextVisible(False)
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setStyleSheet(
            "QProgressBar {"
            "  border: 1px solid #444;"
            "  border-radius: 3px;"
            "  background: #2b2b2b;"
            "  height: 6px;"
            "}"
            "QProgressBar::chunk {"
            "  background-color: #2a82da;"
            "  border-radius: 2px;"
            "}"
        )
        layout.addWidget(self.progress, alignment=Qt.AlignHCenter)
        self.progress.setVisible(False)

        self.hide()

    # --- overlay sizing ------------------------------------------------
    def setParent(self, parent):
        super().setParent(parent)
        if parent is not None:
            self.setGeometry(parent.rect())

    def resizeEvent(self, event):
        super().resizeEvent(event)
        # Ensure we cover the whole parent whenever the parent resizes.
        if self.parent() is not None:
            self.setGeometry(self.parent().rect())

    # --- public API ----------------------------------------------------
    def show_loading(self, title="Loading…", detail="", total_bytes=0):
        self.title_label.setText(title)
        self.detail_label.setText(detail)
        if total_bytes > 0:
            self.progress.setRange(0, 100)
            self.progress.setValue(0)
            self.progress.setVisible(True)
        else:
            self.progress.setRange(0, 0)  # busy
            self.progress.setVisible(True)
        self.setGeometry(self.parent().rect() if self.parent() else self.rect())
        self.raise_()
        self.show()
        self.spinner.start()

    def update_progress(self, percent: int, detail=None):
        if detail is not None:
            self.detail_label.setText(detail)
        if self.progress.maximum() == 0:
            return  # indeterminate mode
        self.progress.setValue(max(0, min(100, int(percent))))

    def hide_loading(self):
        self.spinner.stop()
        self.hide()


# ===========================================================================
# Streaming worker
# ===========================================================================
class BinaryLoaderWorker(QThread):
    # Signals to communicate with the UI
    progress = Signal(int)          # 0..100 (or 0 when size unknown)
    chunk_loaded = Signal(list)     # [[offset, hex, ascii], ...]
    finished = Signal(int)          # total bytes, or -1 on error

    def __init__(self, filepath):
        super().__init__()
        self.filepath = filepath

    def run(self):
        try:
            chunk_size = 16
            batch_size = 100  # send 100 rows at a time
            batch_data = []
            offset = 0

            # Determine total size for the progress bar (cheap stat call).
            try:
                total = Path(self.filepath).stat().st_size
            except OSError:
                total = 0

            with open(self.filepath, 'rb') as f:
                while True:
                    chunk = f.read(chunk_size)
                    if not chunk:
                        break

                    hex_values = " ".join(f"{b:02x}" for b in chunk)
                    ascii_text = "".join(
                        chr(b) if 32 <= b <= 126 else "." for b in chunk
                    )
                    batch_data.append([f"{offset:08x}", hex_values, ascii_text])
                    offset += len(chunk)

                    if len(batch_data) >= batch_size:
                        self.chunk_loaded.emit(batch_data)
                        batch_data = []
                        if total:
                            self.progress.emit(int(offset * 100 / total))

            if batch_data:
                self.chunk_loaded.emit(batch_data)

            self.progress.emit(100)
            self.finished.emit(offset)
        except Exception as e:
            print(f"Worker Error: {e}")
            self.finished.emit(-1)


# ===========================================================================
# Binary editor widget
# ===========================================================================
class BinaryEditorWidget(QWidget):
    """Binary file editor widget"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.filepath = None
        self.original_data = None
        self.loader = None
        self._bytes_loaded = 0
        self._total_bytes = 0

        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # ---- Toolbar ---------------------------------------------------
        toolbar_widget = QWidget()
        toolbar = QHBoxLayout(toolbar_widget)
        toolbar.setContentsMargins(6, 4, 6, 4)

        self.file_label = QLabel("No file loaded")
        toolbar.addWidget(self.file_label)

        toolbar.addStretch()

        # Indeterminate spinner shown next to the label during load too.
        self.toolbar_spinner = SpinnerWidget(self, size=20, color="#2a82da")
        self.toolbar_spinner.setVisible(False)
        toolbar.addWidget(self.toolbar_spinner)

        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setMaximumWidth(200)
        self.progress_bar.setTextVisible(True)
        toolbar.addWidget(self.progress_bar)

        layout.addWidget(toolbar_widget)

        # ---- Table -----------------------------------------------------
        self.hex_table = QTableWidget(0, 3)
        self.hex_table.setHorizontalHeaderLabels(
            ["Offset", "Hex Data (0-F)", "ASCII"]
        )
        self.hex_table.horizontalHeader().setSectionResizeMode(
            1, QHeaderView.Stretch
        )
        self.hex_table.horizontalHeader().setSectionResizeMode(
            QHeaderView.Interactive
        )
        self.hex_table.setFont(QFont("Courier New", 10))
        layout.addWidget(self.hex_table)

        # ---- Overlay ---------------------------------------------------
        # Parented to the widget itself so it covers toolbar + table.
        # We keep it last in the child order so it paints on top.
        self.overlay = LoadingOverlay(self)
        self.overlay.setGeometry(self.rect())

    # --- overlay management -------------------------------------------
    def resizeEvent(self, event):
        super().resizeEvent(event)
        # Keep the overlay covering the whole widget.
        self.overlay.setGeometry(self.rect())

    # --- loading -------------------------------------------------------
    def load_file(self, filepath: str):
        """Load a binary file using the streaming worker."""
        self.filepath = filepath
        self.hex_table.setRowCount(0)
        self._bytes_loaded = 0

        if self.loader is not None and self.loader.isRunning():
            self.loader.wait()

        try:
            self._total_bytes = Path(filepath).stat().st_size
        except OSError:
            self._total_bytes = 0

        # Show toolbar indicators.
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, 100 if self._total_bytes else 0)
        self.progress_bar.setValue(0)
        self.progress_bar.setFormat("%p%")
        self.toolbar_spinner.setVisible(True)
        self.toolbar_spinner.start()

        # Show the centered overlay.
        name = Path(filepath).name
        if self._total_bytes:
            self.overlay.show_loading(
                title=f"Loading {name}",
                detail=f"0 / {self._total_bytes:,} bytes",
                total_bytes=self._total_bytes,
            )
        else:
            self.overlay.show_loading(
                title=f"Loading {name}",
                detail="Reading…",
                total_bytes=0,
            )

        # Kick off the worker.
        self.loader = BinaryLoaderWorker(filepath)
        self.loader.chunk_loaded.connect(self.add_batch_to_table)
        self.loader.progress.connect(self._on_progress)
        self.loader.finished.connect(self.on_load_finished)
        self.loader.start()

    def add_batch_to_table(self, batch):
        """Adds a batch of rows to the table safely."""
        self.hex_table.blockSignals(True)
        current_row = self.hex_table.rowCount()
        self.hex_table.setRowCount(current_row + len(batch))
        for i, row_data in enumerate(batch):
            self.hex_table.setItem(
                current_row + i, 0, QTableWidgetItem(row_data[0])
            )
            self.hex_table.setItem(
                current_row + i, 1, QTableWidgetItem(row_data[1])
            )
            self.hex_table.setItem(
                current_row + i, 2, QTableWidgetItem(row_data[2])
            )
        self.hex_table.blockSignals(False)

        # Approximate bytes loaded so far, for the overlay detail line.
        self._bytes_loaded += len(batch) * 16

    def _on_progress(self, percent: int):
        """Called from the worker thread signal (queued to main thread)."""
        self.progress_bar.setValue(percent)
        if self._total_bytes:
            self.overlay.update_progress(
                percent,
                detail=(
                    f"{min(self._bytes_loaded, self._total_bytes):,} / "
                    f"{self._total_bytes:,} bytes"
                ),
            )
        else:
            # Indeterminate: still update the bytes counter line.
            self.overlay.update_progress(0,
                detail=f"{self._bytes_loaded:,} bytes read…")

    def on_load_finished(self, total_bytes: int):
        """Called when the streaming worker finishes (or fails)."""
        # Toolbar cleanup.
        self.progress_bar.setVisible(False)
        self.toolbar_spinner.stop()
        self.toolbar_spinner.setVisible(False)

        # Overlay cleanup.
        self.overlay.hide_loading()

        if total_bytes < 0:
            self.file_label.setText(
                f"Failed to load: {Path(self.filepath).name}"
            )
            QMessageBox.critical(
                self, "Load Error",
                f"Failed to read file:\n{self.filepath}"
            )
        else:
            self.file_label.setText(
                f"Loaded: {Path(self.filepath).name} ({total_bytes:,} bytes)"
            )

    # --- saving --------------------------------------------------------
    def save_file(self):
        """Save binary file from the table contents."""
        if not self.filepath:
            return
        try:
            data = self.hex_table.get_data()
            with open(self.filepath, 'wb') as f:
                f.write(data)
            self.original_data = data
            QMessageBox.information(self, "Success", "File saved successfully")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save file: {e}")

    def is_modified(self) -> bool:
        """Binary editor doesn't currently track modifications."""
        return False