"""
Standalone Find & Replace dialog for QTextEdit / QPlainTextEdit widgets.

Part of QAH.

Design notes
------------
The dialog never imports a specific editor class. It calls the editor
through a tiny, duck-typed interface:

    Required on the editor widget:
        .document()                 -> QTextDocument
        .textCursor()               -> QTextCursor
        .setTextCursor(cursor)      -> None
        .toPlainText()              -> str
        .setExtraSelections(list)   -> None
        .ensureCursorVisible()      -> None
        .ExtraSelection             -> type attribute

    Optional:
        ._refresh_extra_selections()   (NumberedTextEdit)

Because QTextEdit and QPlainTextEdit both expose every required method,
the dialog works on either without changes.

The `All Open Editors` scope requires the caller to supply a
`scope_provider` callable that returns a list of editor widgets.

Public API
----------
    dlg = FindReplaceDialog(editor, scope_provider=my_tabs_editors,
                            parent=self)
    dlg.showFind()        # focus the Find field
    dlg.showReplace()     # focus the Find field, expand Replace row
    FindReplaceDialog.find_in_editor(editor, "text")   # static helper
"""

from __future__ import annotations

import re
from typing import Callable, List, Optional

from PySide6.QtCore import (
    Qt, QRegularExpression, Slot,
)
from PySide6.QtGui import (
    QColor, QFont, QTextCharFormat, QTextCursor,
)
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QGridLayout, QHBoxLayout,
    QLabel, QLineEdit, QMessageBox, QPlainTextEdit, QPushButton,
    QTextEdit, QVBoxLayout, QWidget,
)


# ===========================================================================
# Highlight formats (shared across all instances)
# ===========================================================================
_MATCH_FMT = QTextCharFormat()
_MATCH_FMT.setBackground(QColor("#f1c40f"))
_MATCH_FMT.setForeground(QColor("#2c3e50"))

_CURRENT_MATCH_FMT = QTextCharFormat()
_CURRENT_MATCH_FMT.setBackground(QColor("#e67e22"))
_CURRENT_MATCH_FMT.setForeground(QColor("#2c3e50"))


# ===========================================================================
# Helpers
# ===========================================================================
def _is_text_editor(widget) -> bool:
    """True for anything we can drive: QTextEdit or QPlainTextEdit."""
    return isinstance(widget, (QTextEdit, QPlainTextEdit))


def _editor_extra_selections(editor) -> list:
    """Fetch existing ExtraSelections without crashing on plain widgets."""
    if hasattr(editor, "extraSelections"):
        try:
            return list(editor.extraSelections())
        except Exception:
            return []
    return []


def _is_search_highlight(sel) -> bool:
    """Best-effort check: is this ExtraSelection one of ours?"""
    try:
        bg = sel.format.background().color()
        return bg in (
            _MATCH_FMT.background().color(),
            _CURRENT_MATCH_FMT.background().color(),
        )
    except Exception:
        return False


# ===========================================================================
# The dialog
# ===========================================================================
class FindReplaceDialog(QDialog):
    """
    Non-modal Find & Replace dialog that works on any text editor.

    Parameters
    ----------
    editor :
        The text editor to search. Must expose the methods listed in the
        module docstring (satisfied by QTextEdit and QPlainTextEdit).
    scope_provider : callable, optional
        Returns a list of editor widgets for the "All Open Editors"
        scope. If None, that scope option is disabled.
    parent : QWidget, optional
        Parent widget for the dialog.
    """

    def __init__(self, editor, scope_provider: Optional[Callable] = None,
                 parent: Optional[QWidget] = None):
        super().__init__(parent)
        self._editor = editor
        self._scope_provider = scope_provider
        self._matches: List[QTextCursor] = []
        self._editor_matches: List[tuple] = []   # [(editor, cursor), ...]
        self._current_index = -1
        self._highlight_editors = set()

        self.setWindowTitle("Find & Replace")
        self.setMinimumWidth(540)
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
        self.setModal(False)

        self._build_ui()
        self._connect_signals()
        self._update_scope_availability()

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------
    def showFind(self):
        """Show the dialog with the Find field focused."""
        self._replace_row_widget.setVisible(False)
        self.show()
        self.raise_()
        self.activateWindow()
        self.find_input.setFocus()
        self.find_input.selectAll()
        self._refresh_matches()

    def showReplace(self):
        """Show the dialog with the Replace row visible."""
        self._replace_row_widget.setVisible(True)
        self.show()
        self.raise_()
        self.activateWindow()
        self.find_input.setFocus()
        self.find_input.selectAll()
        self._refresh_matches()

    @staticmethod
    def find_in_editor(editor, text: str) -> bool:
        """
        Quick 'find next occurrence of `text`' without opening a dialog.

        Returns True if a match was found and the cursor was moved.
        """
        if not text or not editor:
            return False
        cursor = editor.textCursor()
        doc = editor.document()
        found = doc.find(text, cursor)
        if found.isNull():
            start = QTextCursor(doc)
            found = doc.find(text, start)
        if found.isNull():
            return False
        editor.setTextCursor(found)
        editor.ensureCursorVisible()
        return True

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------
    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 10, 10, 10)
        outer.setSpacing(6)

        ui_font = QFont("Segoe UI", 10)

        # Find row
        find_row = QHBoxLayout()
        find_row.setSpacing(6)
        find_label = QLabel("Find:")
        find_label.setFont(ui_font)
        find_row.addWidget(find_label)

        self.find_input = QLineEdit()
        self.find_input.setFont(ui_font)
        self.find_input.setPlaceholderText("Search text…")
        find_row.addWidget(self.find_input, 1)
        outer.addLayout(find_row)

        # Replace row (hidden until showReplace)
        self._replace_row_widget = QWidget()
        replace_row = QHBoxLayout(self._replace_row_widget)
        replace_row.setContentsMargins(0, 0, 0, 0)
        replace_row.setSpacing(6)

        replace_label = QLabel("Repl:")
        replace_label.setFont(ui_font)
        replace_row.addWidget(replace_label)

        self.replace_input = QLineEdit()
        self.replace_input.setFont(ui_font)
        self.replace_input.setPlaceholderText("Replacement text…")
        replace_row.addWidget(self.replace_input, 1)

        self._replace_row_widget.setVisible(False)
        outer.addWidget(self._replace_row_widget)

        # Options grid
        options = QGridLayout()
        options.setHorizontalSpacing(12)
        options.setVerticalSpacing(4)

        self.case_check = QCheckBox("Case sensitive")
        self.case_check.setFont(ui_font)
        options.addWidget(self.case_check, 0, 0)

        self.whole_check = QCheckBox("Whole word")
        self.whole_check.setFont(ui_font)
        options.addWidget(self.whole_check, 0, 1)

        self.regex_check = QCheckBox("Regex")
        self.regex_check.setFont(ui_font)
        options.addWidget(self.regex_check, 0, 2)

        self.wrap_check = QCheckBox("Wrap around")
        self.wrap_check.setFont(ui_font)
        self.wrap_check.setChecked(True)
        options.addWidget(self.wrap_check, 1, 0)

        self.multiline_check = QCheckBox("Multiline")
        self.multiline_check.setFont(ui_font)
        self.multiline_check.setToolTip(
            "Allow the search pattern to span line breaks"
        )
        options.addWidget(self.multiline_check, 1, 1)

        outer.addLayout(options)

        # Scope row
        scope_row = QHBoxLayout()
        scope_row.setSpacing(6)
        scope_label = QLabel("Scope:")
        scope_label.setFont(ui_font)
        scope_row.addWidget(scope_label)

        self.scope_combo = QComboBox()
        self.scope_combo.setFont(ui_font)
        self.scope_combo.addItems(
            ["Current File", "Selection", "All Open Editors"]
        )
        scope_row.addWidget(self.scope_combo, 1)
        outer.addLayout(scope_row)

        # Buttons
        buttons = QHBoxLayout()
        buttons.setSpacing(6)

        self.prev_btn = QPushButton("◀ Prev")
        self.prev_btn.setFont(ui_font)
        buttons.addWidget(self.prev_btn)

        self.next_btn = QPushButton("Next ▶")
        self.next_btn.setFont(ui_font)
        buttons.addWidget(self.next_btn)

        buttons.addStretch(1)

        self.replace_btn = QPushButton("Replace")
        self.replace_btn.setFont(ui_font)
        buttons.addWidget(self.replace_btn)

        self.replace_all_btn = QPushButton("Replace All")
        self.replace_all_btn.setFont(ui_font)
        buttons.addWidget(self.replace_all_btn)

        self.close_btn = QPushButton("Close")
        self.close_btn.setFont(ui_font)
        buttons.addWidget(self.close_btn)

        outer.addLayout(buttons)

        # Status line
        self.match_label = QLabel("No matches")
        self.match_label.setFont(ui_font)
        self.match_label.setStyleSheet("color: #888;")
        outer.addWidget(self.match_label)

        # Dark theme
        self.setStyleSheet("""
            QDialog { background-color: #2b2b2b; }
            QLabel { color: #e0e0e0; }
            QLineEdit, QComboBox {
                background-color: #3c3f41;
                color: #e0e0e0;
                border: 1px solid #555;
                padding: 4px;
                border-radius: 3px;
            }
            QPushButton {
                background-color: #3c3f41;
                color: #e0e0e0;
                border: 1px solid #555;
                padding: 5px 10px;
                border-radius: 3px;
            }
            QPushButton:hover { background-color: #4a4d4f; }
            QPushButton:pressed { background-color: #2a2d2f; }
            QPushButton:disabled { color: #777; }
            QCheckBox { color: #e0e0e0; }
        """)

    # ------------------------------------------------------------------
    # Signals
    # ------------------------------------------------------------------
    def _connect_signals(self):
        self.find_input.textChanged.connect(self._on_options_changed)
        self.find_input.returnPressed.connect(self.find_next)
        self.replace_input.returnPressed.connect(self.replace_current)

        self.case_check.stateChanged.connect(self._on_options_changed)
        self.whole_check.stateChanged.connect(self._on_options_changed)
        self.regex_check.stateChanged.connect(self._on_options_changed)
        self.multiline_check.stateChanged.connect(self._on_options_changed)
        self.scope_combo.currentIndexChanged.connect(self._on_options_changed)

        self.prev_btn.clicked.connect(self.find_previous)
        self.next_btn.clicked.connect(self.find_next)
        self.replace_btn.clicked.connect(self.replace_current)
        self.replace_all_btn.clicked.connect(self.replace_all)
        self.close_btn.clicked.connect(self.close)

    # ------------------------------------------------------------------
    # Scope helpers
    # ------------------------------------------------------------------
    def _update_scope_availability(self):
        model = self.scope_combo.model()
        item = model.item(2)
        if item is not None:
            item.setEnabled(self._scope_provider is not None)

    def _editors_in_scope(self) -> List:
        scope = self.scope_combo.currentText()
        if scope == "Current File":
            return [self._editor]
        if scope == "Selection":
            return [self._editor]
        if scope == "All Open Editors":
            if self._scope_provider is None:
                return [self._editor]
            try:
                editors = list(self._scope_provider())
            except Exception:
                editors = []
            return [e for e in editors if _is_text_editor(e)]
        return [self._editor]

    # ------------------------------------------------------------------
    # Regex build
    # ------------------------------------------------------------------
    def _build_regex(self) -> QRegularExpression:
        pattern = self.find_input.text()
        if not pattern:
            return QRegularExpression()

        if not self.regex_check.isChecked():
            pattern = re.escape(pattern)

        if self.whole_check.isChecked():
            pattern = r"\b" + pattern + r"\b"

        flags = QRegularExpression.NoPatternOption
        if not self.case_check.isChecked():
            flags |= QRegularExpression.CaseInsensitiveOption
        if self.multiline_check.isChecked():
            flags |= QRegularExpression.MultilineOption

        return QRegularExpression(pattern, flags)

    # ------------------------------------------------------------------
    # Match discovery
    # ------------------------------------------------------------------
    @Slot()
    def _on_options_changed(self):
        self._refresh_matches()

    def _search_range(self, editor) -> tuple:
        doc = editor.document()
        if self.scope_combo.currentText() == "Selection":
            cursor = editor.textCursor()
            if cursor.hasSelection():
                return cursor.selectionStart(), cursor.selectionEnd()
        return 0, doc.characterCount()

    def _refresh_matches(self):
        self._clear_highlights()
        self._matches = []
        self._editor_matches = []
        self._current_index = -1

        pattern = self.find_input.text()
        if not pattern:
            self._set_status("No matches", error=True)
            self._set_buttons_enabled(False)
            return

        regex = self._build_regex()
        if not regex.isValid():
            self._set_status(
                f"Invalid regex: {regex.errorString()}", error=True
            )
            self._set_buttons_enabled(False)
            return

        self._set_buttons_enabled(True)

        for editor in self._editors_in_scope():
            try:
                text = editor.toPlainText()
            except Exception:
                continue
            start, end = self._search_range(editor)
            if start >= end:
                continue

            window = text[start:end]
            it = regex.globalMatch(window)
            while it.hasNext():
                m = it.next()
                cursor = QTextCursor(editor.document())
                cursor.setPosition(start + m.capturedStart())
                cursor.setPosition(
                    start + m.capturedEnd(), QTextCursor.KeepAnchor
                )
                self._matches.append(cursor)
                self._editor_matches.append((editor, cursor))

        n = len(self._matches)
        if n == 0:
            self._set_status("No matches", error=True)
            return

        self._set_status(f"{n} match(es)", error=False)
        self._apply_highlights()
        self._current_index = -1
        self.find_next()

    def _set_buttons_enabled(self, enabled: bool):
        for b in (self.next_btn, self.prev_btn,
                  self.replace_btn, self.replace_all_btn):
            b.setEnabled(enabled)

    # ------------------------------------------------------------------
    # Highlight management
    # ------------------------------------------------------------------
    def _clear_highlights(self):
        for editor in list(self._highlight_editors):
            try:
                if hasattr(editor, "_refresh_extra_selections"):
                    editor._refresh_extra_selections()
                else:
                    editor.setExtraSelections(
                        _editor_extra_selections(editor)
                    )
            except Exception:
                pass
        self._highlight_editors.clear()

    def _apply_highlights(self):
        by_editor = {}
        for editor, cursor in self._editor_matches:
            by_editor.setdefault(id(editor), (editor, []))[1].append(cursor)

        current_editor = None
        current_cursor = None
        if 0 <= self._current_index < len(self._editor_matches):
            current_editor, current_cursor = \
                self._editor_matches[self._current_index]

        for _, (editor, cursors) in by_editor.items():
            existing = [
                s for s in _editor_extra_selections(editor)
                if not _is_search_highlight(s)
            ]
            new_sels = []
            for c in cursors:
                sel = editor.ExtraSelection()
                sel.cursor = c
                if editor is current_editor and c == current_cursor:
                    sel.format = _CURRENT_MATCH_FMT
                else:
                    sel.format = _MATCH_FMT
                new_sels.append(sel)
            try:
                editor.setExtraSelections(existing + new_sels)
                self._highlight_editors.add(editor)
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------
    @Slot()
    def find_next(self):
        if not self._matches:
            self._refresh_matches()
            if not self._matches:
                return
        n = len(self._matches)
        self._current_index = (self._current_index + 1) % n
        self._select_current()

    @Slot()
    def find_previous(self):
        if not self._matches:
            self._refresh_matches()
            if not self._matches:
                return
        n = len(self._matches)
        self._current_index = (self._current_index - 1) % n
        self._select_current()

    def _select_current(self):
        if not (0 <= self._current_index < len(self._matches)):
            return
        editor, cursor = self._editor_matches[self._current_index]
        editor.setTextCursor(cursor)
        editor.ensureCursorVisible()
        self._set_status(
            f"{self._current_index + 1} of {len(self._matches)}",
            error=False,
        )
        self._apply_highlights()

    # ------------------------------------------------------------------
    # Replace
    # ------------------------------------------------------------------
    @Slot()
    def replace_current(self):
        if not self._matches:
            self._refresh_matches()
            if not self._matches:
                return
        if not (0 <= self._current_index < len(self._matches)):
            self.find_next()
            return

        editor, cursor = self._editor_matches[self._current_index]
        replacement = self.replace_input.text()

        cursor.beginEditBlock()
        cursor.insertText(replacement)
        cursor.endEditBlock()

        self._refresh_matches()

    @Slot()
    def replace_all(self):
        if not self._matches:
            self._refresh_matches()
            if not self._matches:
                return

        replacement = self.replace_input.text()
        count = len(self._matches)

        by_editor = {}
        for editor, cursor in self._editor_matches:
            by_editor.setdefault(id(editor), (editor, []))[1].append(cursor)

        for _, (editor, cursors) in by_editor.items():
            edit = editor.textCursor()
            edit.beginEditBlock()
            for c in sorted(cursors, key=lambda x: x.position(),
                            reverse=True):
                c.insertText(replacement)
            edit.endEditBlock()

        self._refresh_matches()
        QMessageBox.information(
            self, "Replace All",
            f"Replaced {count} occurrence(s)."
        )

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------
    def _set_status(self, text: str, error: bool):
        self.match_label.setText(text)
        self.match_label.setStyleSheet(
            "color: #f44336;" if error else "color: #4CAF50;"
        )

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    def closeEvent(self, event):
        self._clear_highlights()
        super().closeEvent(event)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self.close()
            return
        if event.key() in (Qt.Key_Return, Qt.Key_Enter):
            if self.replace_input.hasFocus():
                self.replace_current()
                return
            self.find_next()
            return
        super().keyPressEvent(event)