"""
Settings dialog for the ADOBMD File Editor.

Live-preview + persist of:
  * Font family / size / bold / italic
  * Tab size, use-spaces toggle
  * Theme (Dark / Light / System)
  * Auto-save on/off
  * Auto-save interval (seconds)
  * Syntax-highlighting engine (native C vs. Python fallback)

Changes are applied via callbacks the caller supplies, so this widget
never imports editor internals. Persistence uses QSettings.
"""

from PySide6.QtCore import Qt, QSettings
from PySide6.QtGui import QFont, QFontDatabase
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout, QGroupBox,
    QLabel, QComboBox, QSpinBox, QCheckBox, QPushButton,
    QDialogButtonBox, QFontComboBox, QApplication,
)


class SettingsDialog(QDialog):
    """
    Settings dialog. Caller wires callbacks:

        SettingsDialog(
            apply_font=lambda font: ...,
            apply_tabs=lambda size, use_spaces: ...,
            apply_theme=lambda name: ...,
            apply_autosave=lambda enabled, seconds: ...,
            apply_highlighter_mode=lambda use_native: ...,
            parent=...
        )

    Restores from `QSettings("ADOBMD", "AdobmdEditorWidget")`.
    """

    def __init__(self, apply_font, apply_tabs, apply_theme,
                 apply_autosave, apply_highlighter_mode, parent=None):
        super().__init__(parent)
        self._apply_font = apply_font
        self._apply_tabs = apply_tabs
        self._apply_theme = apply_theme
        self._apply_autosave = apply_autosave
        self._apply_highlighter_mode = apply_highlighter_mode

        self.settings = QSettings("ADOBMD", "AdobmdEditorWidget")

        self.setWindowTitle("Settings")
        self.setMinimumWidth(480)

        self._build_ui()
        self._load_from_settings()

    # ------------------------------------------------------------------
    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setSpacing(10)

        # ---- Font group ---------------------------------------------
        font_group = QGroupBox("Editor Font")
        font_layout = QGridLayout(font_group)

        font_layout.addWidget(QLabel("Family:"), 0, 0)
        self.font_family = QFontComboBox()
        font_layout.addWidget(self.font_family, 0, 1, 1, 2)

        font_layout.addWidget(QLabel("Size:"), 1, 0)
        self.font_size = QSpinBox()
        self.font_size.setRange(6, 72)
        self.font_size.setValue(11)
        font_layout.addWidget(self.font_size, 1, 1)

        self.font_bold = QCheckBox("Bold")
        font_layout.addWidget(self.font_bold, 1, 2)

        self.font_italic = QCheckBox("Italic")
        font_layout.addWidget(self.font_italic, 2, 2)

        font_layout.setColumnStretch(1, 1)
        outer.addWidget(font_group)

        # ---- Indentation group --------------------------------------
        indent_group = QGroupBox("Indentation")
        indent_layout = QGridLayout(indent_group)

        indent_layout.addWidget(QLabel("Tab width:"), 0, 0)
        self.tab_width = QSpinBox()
        self.tab_width.setRange(1, 16)
        self.tab_width.setValue(4)
        indent_layout.addWidget(self.tab_width, 0, 1)

        self.use_spaces = QCheckBox("Insert spaces instead of tabs")
        self.use_spaces.setChecked(True)
        indent_layout.addWidget(self.use_spaces, 1, 0, 1, 2)

        indent_layout.setColumnStretch(1, 1)
        outer.addWidget(indent_group)

        # ---- Appearance group ---------------------------------------
        appearance = QGroupBox("Appearance")
        appearance_layout = QGridLayout(appearance)

        appearance_layout.addWidget(QLabel("Theme:"), 0, 0)
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["System", "Dark", "Light"])
        appearance_layout.addWidget(self.theme_combo, 0, 1)
        appearance_layout.setColumnStretch(1, 1)
        outer.addWidget(appearance)

        # ---- Auto-save group ----------------------------------------
        autosave = QGroupBox("Auto-save")
        autosave_layout = QGridLayout(autosave)

        self.autosave_enabled = QCheckBox("Enable auto-save")
        autosave_layout.addWidget(self.autosave_enabled, 0, 0, 1, 2)

        autosave_layout.addWidget(QLabel("Interval (seconds):"), 1, 0)
        self.autosave_interval = QSpinBox()
        self.autosave_interval.setRange(5, 3600)
        self.autosave_interval.setValue(60)
        autosave_layout.addWidget(self.autosave_interval, 1, 1)

        autosave_layout.setColumnStretch(1, 1)
        outer.addWidget(autosave)

        # ---- Syntax highlighting group ------------------------------
        hl_group = QGroupBox("Syntax Highlighting")
        hl_layout = QVBoxLayout(hl_group)

        self.use_native_hl = QCheckBox(
            "Use native C highlighter (fast, OpenMP-accelerated)"
        )
        self.use_native_hl.setChecked(True)
        hl_layout.addWidget(self.use_native_hl)

        self.hl_status = QLabel("")
        self.hl_status.setStyleSheet(
            "color: #888; font-size: 10px; padding-left: 4px;"
        )
        self.hl_status.setWordWrap(True)
        hl_layout.addWidget(self.hl_status)

        # Probe once, at construction time, so the status line is
        # accurate before the user touches the checkbox.
        native_available = self._probe_native_highlighter()
        if native_available:
            self.hl_status.setText(
                "Native library: available. Uncheck to force the "
                "slower Python fallback."
            )
        else:
            self.hl_status.setText(
                "Native library: not available on this system. "
                "The Python fallback will be used regardless of this "
                "setting."
            )
            self.use_native_hl.setChecked(False)

        outer.addWidget(hl_group)

        # ---- Live-preview wiring ------------------------------------
        self.font_family.currentFontChanged.connect(self._on_change)
        self.font_size.valueChanged.connect(self._on_change)
        self.font_bold.stateChanged.connect(self._on_change)
        self.font_italic.stateChanged.connect(self._on_change)
        self.tab_width.valueChanged.connect(self._on_change)
        self.use_spaces.stateChanged.connect(self._on_change)
        self.theme_combo.currentIndexChanged.connect(self._on_change)
        self.autosave_enabled.stateChanged.connect(self._on_change)
        self.autosave_interval.valueChanged.connect(self._on_change)
        self.use_native_hl.stateChanged.connect(self._on_change)

        # ---- Buttons ------------------------------------------------
        buttons = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel
            | QDialogButtonBox.RestoreDefaults
        )
        buttons.accepted.connect(self._on_accept)
        buttons.rejected.connect(self.reject)
        buttons.button(QDialogButtonBox.RestoreDefaults).clicked.connect(
            self._restore_defaults
        )
        outer.addWidget(buttons)

    # ------------------------------------------------------------------
    @staticmethod
    def _probe_native_highlighter() -> bool:
        """
        Return True if the native C highlighter is importable AND the
        shared library loads. Never raises.
        """
        try:
            from .adobmd_tool import NativeAdobmdHighlighter
            hl = NativeAdobmdHighlighter(None)
            return bool(getattr(hl, "native_available", False))
        except Exception:
            return False

    # ------------------------------------------------------------------
    def _load_from_settings(self):
        s = self.settings

        family = s.value("font_family", "Consolas", type=str)
        size = s.value("font_size", 11, type=int)
        bold = s.value("font_bold", False, type=bool)
        italic = s.value("font_italic", False, type=bool)

        # Fallback if the saved font isn't installed.
        families = QFontDatabase.families()
        if family not in families:
            family = "Consolas" if "Consolas" in families else families[0]

        self.font_family.setCurrentFont(QFont(family))
        self.font_size.setValue(size)
        self.font_bold.setChecked(bold)
        self.font_italic.setChecked(italic)

        self.tab_width.setValue(s.value("tab_size", 4, type=int))
        self.use_spaces.setChecked(
            s.value("use_spaces", True, type=bool)
        )
        theme = s.value("theme", "System", type=str)
        idx = self.theme_combo.findText(theme)
        self.theme_combo.setCurrentIndex(max(0, idx))

        self.autosave_enabled.setChecked(
            s.value("autosave_enabled", True, type=bool)
        )
        self.autosave_interval.setValue(
            s.value("autosave_interval", 60, type=int)
        )

        # Native highlighter preference — only restore True if the
        # library actually loads; otherwise force the Python fallback
        # so the checkbox reflects the effective behaviour.
        saved = s.value("use_native_highlighter", True, type=bool)
        if saved and self._probe_native_highlighter():
            self.use_native_hl.setChecked(True)
        else:
            self.use_native_hl.setChecked(False)

    # ------------------------------------------------------------------
    def _current_font(self) -> QFont:
        f = self.font_family.currentFont()
        f.setPointSize(self.font_size.value())
        f.setBold(self.font_bold.isChecked())
        f.setItalic(self.font_italic.isChecked())
        return f

    def _on_change(self, *_):
        """Called on every control change. Applies live; does not save."""
        if self._apply_font is not None:
            self._apply_font(self._current_font())
        if self._apply_tabs is not None:
            self._apply_tabs(
                self.tab_width.value(),
                self.use_spaces.isChecked(),
            )
        if self._apply_theme is not None:
            self._apply_theme(self.theme_combo.currentText())
        if self._apply_autosave is not None:
            self._apply_autosave(
                self.autosave_enabled.isChecked(),
                self.autosave_interval.value(),
            )
        if self._apply_highlighter_mode is not None:
            self._apply_highlighter_mode(self.use_native_hl.isChecked())

    # ------------------------------------------------------------------
    def _restore_defaults(self):
        families = QFontDatabase.families()
        default_family = "Consolas" if "Consolas" in families else families[0]
        self.font_family.setCurrentFont(QFont(default_family))
        self.font_size.setValue(11)
        self.font_bold.setChecked(False)
        self.font_italic.setChecked(False)
        self.tab_width.setValue(4)
        self.use_spaces.setChecked(True)
        self.theme_combo.setCurrentText("System")
        self.autosave_enabled.setChecked(True)
        self.autosave_interval.setValue(60)
        # Default to native if it loads, otherwise Python.
        self.use_native_hl.setChecked(self._probe_native_highlighter())
        self._on_change()

    # ------------------------------------------------------------------
    def _on_accept(self):
        s = self.settings
        s.setValue("font_family", self.font_family.currentFont().family())
        s.setValue("font_size", self.font_size.value())
        s.setValue("font_bold", self.font_bold.isChecked())
        s.setValue("font_italic", self.font_italic.isChecked())
        s.setValue("tab_size", self.tab_width.value())
        s.setValue("use_spaces", self.use_spaces.isChecked())
        s.setValue("theme", self.theme_combo.currentText())
        s.setValue("autosave_enabled", self.autosave_enabled.isChecked())
        s.setValue("autosave_interval", self.autosave_interval.value())
        s.setValue("use_native_highlighter", self.use_native_hl.isChecked())
        s.sync()
        self.accept()

    # ------------------------------------------------------------------
    def reject(self):
        """
        On Cancel, revert any live-preview changes by reloading the
        saved values and re-applying them.
        """
        self._load_from_settings()
        self._on_change()
        super().reject()