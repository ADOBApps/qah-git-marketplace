"""
Line-numbered code editor for QAH.

Provides `NumberedTextEdit`, a QPlainTextEdit subclass with:
  * a left gutter showing 1-based line numbers
  * the current line highlighted in a subtle way
  * proper 1..N numbering that updates as lines are added/removed
  * Ctrl+G opens a "Go to line" dialog
  * a `find_requested` signal so the parent can open Find/Replace

Why QPlainTextEdit and not QTextEdit:
  QPlainTextEdit uses a lazy block layout — it only lays out visible
  paragraphs. That makes huge files open instantly and keeps the
  line-number gutter cost O(visible rows), not O(file size).
"""

from PySide6.QtCore import QRect, QSize, Qt, Signal
from PySide6.QtGui import (
    QColor, QFont, QPainter, QTextFormat, QTextOption,
)
from PySide6.QtWidgets import (
    QPlainTextEdit, QTextEdit, QWidget, QInputDialog,
)


class LineNumberArea(QWidget):
    """
    Left gutter. Delegates painting to the editor so line numbers stay
    in sync with the block layout.
    """

    def __init__(self, editor: "NumberedTextEdit"):
        super().__init__(editor)
        self._editor = editor

    def sizeHint(self) -> QSize:
        return QSize(self._editor.line_number_area_width(), 0)

    def paintEvent(self, event):
        self._editor.line_number_area_paint_event(event)


class NumberedTextEdit(QPlainTextEdit):
    """
    QPlainTextEdit with a line-number gutter.

    Public API mirrors QPlainTextEdit; the gutter is an internal child.
    """

    #: Emitted when the user presses Ctrl+F / Ctrl+H.
    #  NOTE: this must be a *class* attribute (no `self.`), otherwise
    #  Python tries to evaluate `self` at class-definition time and the
    #  whole class fails to build.
    find_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)

        font = QFont("Consolas", 11)
        font.setStyleHint(QFont.Monospace)
        self.setFont(font)

        self.setLineWrapMode(QPlainTextEdit.NoWrap)
        self.setWordWrapMode(QTextOption.NoWrap)

        self._line_number_area = LineNumberArea(self)

        self.blockCountChanged.connect(self._update_gutter_width)
        self.updateRequest.connect(self._update_gutter)
        self.cursorPositionChanged.connect(self._highlight_current_line)

        self._update_gutter_width(0)
        self._highlight_current_line()

    # ----- gutter plumbing ---------------------------------------------
    def line_number_area_width(self) -> int:
        digits = 1
        max_block = max(1, self.blockCount())
        while max_block >= 10:
            max_block //= 10
            digits += 1
        return 12 + self.fontMetrics().horizontalAdvance("9") * digits

    def _update_gutter_width(self, _block_count: int):
        self.setViewportMargins(self.line_number_area_width(), 0, 0, 0)

    def _update_gutter(self, rect: QRect, dy: int):
        if dy:
            self._line_number_area.scroll(0, dy)
        else:
            self._line_number_area.update(
                0, rect.y(),
                self._line_number_area.width(),
                rect.height(),
            )
        if rect.contains(self.viewport().rect()):
            self._update_gutter_width(0)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        cr = self.contentsRect()
        self._line_number_area.setGeometry(
            QRect(cr.left(), cr.top(),
                  self.line_number_area_width(), cr.height())
        )

    def line_number_area_paint_event(self, event):
        painter = QPainter(self._line_number_area)
        painter.fillRect(event.rect(), QColor("#1e1e1e"))
        painter.setFont(self.font())

        block = self.firstVisibleBlock()
        block_number = block.blockNumber()
        top = self.blockBoundingGeometry(block).translated(
            self.contentOffset()
        ).top()
        bottom = top + self.blockBoundingRect(block).height()

        current_line = self.textCursor().blockNumber()
        normal_color = QColor("#858585")
        current_color = QColor("#c6c6c6")

        width = self._line_number_area.width() - 6
        height = self.fontMetrics().height()

        while block.isValid() and (top <= event.rect().bottom()):
            if block.isVisible() and (bottom >= event.rect().top()):
                number = str(block_number + 1)
                painter.setPen(
                    current_color if block_number == current_line
                    else normal_color
                )
                painter.drawText(
                    0, int(top), width, height,
                    Qt.AlignRight | Qt.AlignVCenter,
                    number,
                )
            block = block.next()
            top = bottom
            bottom = top + self.blockBoundingRect(block).height()
            block_number += 1

    # ----- current-line highlight -------------------------------------
    def _highlight_current_line(self):
        if self.isReadOnly():
            self.setExtraSelections([])
            return

        selection = QTextEdit.ExtraSelection()
        selection.format.setBackground(QColor("#2a2d3a"))
        selection.format.setProperty(QTextFormat.FullWidthSelection, True)
        selection.cursor = self.textCursor()
        selection.cursor.clearSelection()
        self.setExtraSelections([selection])

    def _refresh_extra_selections(self):
        """
        Public-ish helper used by the Find/Replace dialog.

        Re-emits the editor's own extra selections (currently just the
        current-line highlight) so external code can safely call
        setExtraSelections() and then let us restore our own highlights.
        """
        self._highlight_current_line()

    # ----- go to line --------------------------------------------------
    def goto_line(self, line_1based: int):
        """Move the cursor to the given 1-based line and scroll to it."""
        line = max(1, min(line_1based, self.blockCount()))
        block = self.document().findBlockByNumber(line - 1)
        if not block.isValid():
            return
        cursor = self.textCursor()
        cursor.movePosition(cursor.MoveOperation.Start)
        cursor.setPosition(block.position())
        self.setTextCursor(cursor)
        self.centerCursor()
        self.setFocus()

    # ----- key handling ------------------------------------------------
    def keyPressEvent(self, event):
        mods = event.modifiers()

        # Ctrl+G -> Go to line dialog
        if event.key() == Qt.Key_G and (mods & Qt.ControlModifier):
            self._prompt_goto_line()
            return

        # Ctrl+F / Ctrl+H -> emit find_requested so the parent opens
        # the standalone Find/Replace dialog.
        if mods & Qt.ControlModifier and event.key() in (Qt.Key_F, Qt.Key_H):
            self.find_requested.emit()
            return

        super().keyPressEvent(event)

    def _prompt_goto_line(self):
        line, ok = QInputDialog.getInt(
            self, "Go to Line",
            f"Line (1–{self.blockCount()}):",
            self.textCursor().blockNumber() + 1,
            1, self.blockCount(), 1,
        )
        if ok:
            self.goto_line(line)