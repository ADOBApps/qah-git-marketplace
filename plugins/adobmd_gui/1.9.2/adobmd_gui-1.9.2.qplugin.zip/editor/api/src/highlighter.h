#ifndef HIGHLIGHTER_H
#define HIGHLIGHTER_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(_WIN32) || defined(_WIN64)
#  define HL_EXPORT __declspec(dllexport)
#else
#  define HL_EXPORT __attribute__((visibility("default")))
#endif

/* Token types */
enum {
    HL_NONE = 0, HL_KEYWORD, HL_TYPE, HL_COMMENT, HL_STRING,
    HL_TAG, HL_NUMBER, HL_CONSTANT, HL_OPERATOR, HL_SECTION,
    HL_DIRECTIVE, HL_CARD, HL_ROUTE, HL_SPECIES, HL_COORD
};

/* Program identifiers (ADOBMD-only) */
enum {
    HL_PROG_UNKNOWN     = 0,
    HL_PROG_ADOBMD_DATA = 1,   /* .data  — unified data file */
    HL_PROG_ADOBMD_FF   = 2,   /* .ff    — force-field file  */
    HL_PROG_ADOBMD_CONF = 3    /* .conf  — MD configuration  */
};

/* Error codes */
enum {
    HL_OK = 0, HL_ERR_OPEN, HL_ERR_NOMEM, HL_ERR_BADARG, HL_ERR_TOO_SMALL
};

HL_EXPORT int hl_scan_file(const char* path, int* n_lines, int* max_tokens);
HL_EXPORT int hl_count_buffer_tokens(const char* text, int len, int program);
HL_EXPORT int hl_parse_buffer(const char* text, int len,
                              int* line_out, int* start_out,
                              int* len_out, int* type_out,
                              int max_tokens, int* n_tokens_out,
                              int program);
HL_EXPORT int hl_parse_file(const char* path,
                            int* line_out, int* start_out,
                            int* len_out, int* type_out,
                            int max_tokens, int* n_tokens_out,
                            int program);
HL_EXPORT int hl_lex_line_direct(const char* line, int len,
                                 int* starts, int* lens, int* types,
                                 int max_tokens, int program);
HL_EXPORT void hl_set_num_threads(int n);

#ifdef __cplusplus
}
#endif
#endif