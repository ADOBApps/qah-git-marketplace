#include "highlighter.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <limits.h>

#ifdef _OPENMP
#  include <omp.h>
#endif

#ifdef _WIN32
#  define strncasecmp _strnicmp
#  define strcasecmp  _stricmp
#else
#  include <strings.h>
#endif

/* ============================================================
 * ADOBMD .data — unified data file (read by unified_reader.f90)
 * ============================================================ */

static const char* ADOBMD_DATA_SECTIONS[] = {
    "Atoms", "Bonds", "Angles", "Dihedrals", "Impropers",
    "Masses", "Velocities", "Pair", "PairIJ",
    "Bond", "Angle", "Dihedral", "Improper",
    NULL
};

static const char* ADOBMD_DATA_HEADERS[] = {
    "atoms", "bonds", "angles", "dihedrals", "impropers",
    "atom types", "bond types", "angle types",
    "dihedral types", "improper types",
    "xlo xhi", "ylo yhi", "zlo zhi", "xy xz yz",
    NULL
};

/* ============================================================
 * ADOBMD .ff — force-field file (read by ff_reader.f90)
 * ============================================================ */

static const char* ADOBMD_FF_SECTIONS[] = {
    "AtomTypes", "BondTypes", "BendTypes", "AngleTypes",
    "TorsionTypes", "DihedralTypes",
    "InversionTypes", "ImproperTypes",
    "NonBonded", "NonBondedTypes",
    "Regions", "RegionPotentials",
    "Coupling", "Couplings", "Plugins",
    NULL
};

static const char* ADOBMD_FF_KEYWORDS[] = {
    "atomtype", "bond", "bend", "angle", "torsion", "dihedral",
    "inversion", "improper", "nonbond", "region", "region_potential",
    "coupling", "plugin", "override", "atoms",
    NULL
};

/* ============================================================
 * ADOBMD .conf — MD configuration (read by md_input.f90)
 * ============================================================ */

static const char* ADOBMD_CONF_KEYS[] = {
    /* system */
    "natoms", "nsteps", "nsave", "dt_fs", "density", "temperature",
    "pressure", "box_size",
    /* potential / ensemble */
    "potential", "material", "ensemble",
    /* thermostat / barostat */
    "gamma_ps", "tau_p_ps", "compressibility",
    /* output */
    "output_prefix", "coords_file", "system_file",
    /* force-field files */
    "meam_library_file", "meam_parameter_file",
    "eam_tabulated_file", "forcefield_file",
    /* EHT / ONIOM */
    "enable_eht", "enable_oniom", "enable_xtb", "qm_method",
    "eht_total_charge", "qm_region_file", "eht_cutoff",
    "eht_basis_set", "eht_double_zeta", "eht_print_orbitals",
    "eht_print_density", "eht_output_level", "mm_potential",
    /* xTB */
    "xtb_accuracy", "xtb_method", "xtb_max_iter",
    "xtb_verbosity", "xtb_temperature",
    /* ML / NN weights */
    "ml_weights_file", "nn_weights_file",
    /* analysis */
    "compute_msd", "compute_vacf", "compute_pdf", "compute_pressure",
    "msd_start", "msd_interval", "vacf_interval",
    "pdf_qmax_inv_angstrom", "pdf_dq_inv_angstrom", "pdf_interval",
    "analysis_prefix",
    /* minimization */
    "enable_minimization", "minimization_method",
    "force_tolerance", "energy_tolerance",
    "max_minimization_steps", "verbose_minimization",
    "lbfgs_memory", "line_search_tolerance",
    NULL
};

/* ============================================================
 * Small helpers
 * ============================================================ */

static int in_list(const char* w, int len, const char** list) {
    for (int i = 0; list[i]; i++)
        if ((int)strlen(list[i]) == len && strncasecmp(w, list[i], len) == 0)
            return 1;
    return 0;
}

static int is_number(const char* s, int len) {
    if (len <= 0) return 0;
    int d = 0;
    for (int i = 0; i < len; i++) {
        char c = s[i];
        if (isdigit((unsigned char)c)) d = 1;
        else if (c != '.' && c != '-' && c != '+' &&
                 c != 'e' && c != 'E' && c != 'd' && c != 'D') return 0;
    }
    return d;
}

static int is_logical(const char* s, int len) {
    if (len == 4 && strncasecmp(s, "true",  4) == 0) return 1;
    if (len == 5 && strncasecmp(s, "false", 5) == 0) return 1;
    if (len == 6 && strncasecmp(s, ".true.", 6) == 0) return 1;
    if (len == 7 && strncasecmp(s, ".false.", 7) == 0) return 1;
    return 0;
}

static int is_adobmd_region_tag(const char* s, int len) {
    if (len <= 0 || len > 4) return 0;
    if (len == 2 &&
        (s[0]=='Q'||s[0]=='q') && (s[1]=='M'||s[1]=='m')) return 1;
    if (len == 2 &&
        (s[0]=='M'||s[0]=='m') && (s[1]=='M'||s[1]=='m')) return 1;
    if (len == 1 && (s[0]=='Q'||s[0]=='q')) return 1;
    if (len == 1 && (s[0]=='M'||s[0]=='m')) return 1;
    return 0;
}

static int looks_like_element(const char* s, int len) {
    if (len < 1 || len > 2) return 0;
    if (!isupper((unsigned char)s[0])) return 0;
    for (int k = 1; k < len; k++)
        if (!isalpha((unsigned char)s[k])) return 0;
    return 1;
}

/* ============================================================
 * Per-program lexer
 *
 * Writes tokens into starts/lens/types when non-NULL and n < cap.
 * Always returns the TRUE token count.
 * ============================================================ */

static int lex_line_program(const char* line, int len,
                            int* starts, int* lens, int* types,
                            int cap, int program) {
    int n = 0;
#define EMIT(s,l,t) do { \
    if (starts && n < cap) { starts[n]=(s); lens[n]=(l); types[n]=(t); } \
    n++; \
} while(0)

    int i = 0;

    /* ---------- .data ---------- */
    if (program == HL_PROG_ADOBMD_DATA) {
        while (i < len) {
            if (line[i] == '#') { EMIT(i, len - i, HL_COMMENT); break; }
            if (isspace((unsigned char)line[i])) { i++; continue; }

            int s = i;
            while (i < len && !isspace((unsigned char)line[i]) &&
                   line[i] != '#') i++;
            int wl = i - s;
            if (wl <= 0) { i++; continue; }

            if (is_number(line + s, wl))          { EMIT(s, wl, HL_NUMBER);   continue; }
            if (is_adobmd_region_tag(line + s, wl)){ EMIT(s, wl, HL_CONSTANT); continue; }
            if (in_list(line + s, wl, ADOBMD_DATA_SECTIONS))
                { EMIT(s, wl, HL_SECTION);  continue; }
            if (in_list(line + s, wl, ADOBMD_DATA_HEADERS))
                { EMIT(s, wl, HL_KEYWORD);  continue; }
            if (looks_like_element(line + s, wl))
                { EMIT(s, wl, HL_SPECIES);  continue; }

            EMIT(s, wl, HL_NONE);
        }
        return n;
    }

    /* ---------- .ff ---------- */
    if (program == HL_PROG_ADOBMD_FF) {
        while (i < len) {
            if (line[i] == '!' || line[i] == '#') {
                EMIT(i, len - i, HL_COMMENT); break;
            }
            if (isspace((unsigned char)line[i])) { i++; continue; }

            /* Section tag  <Name>  or  </Name> */
            if (line[i] == '<') {
                int s = i++;
                while (i < len && line[i] != '>') i++;
                if (i < len) i++;                 /* include '>' */
                EMIT(s, i - s, HL_SECTION);
                continue;
            }

            int s = i;
            while (i < len && !isspace((unsigned char)line[i]) &&
                   line[i] != '!' && line[i] != '#') i++;
            int wl = i - s;
            if (wl <= 0) { i++; continue; }

            if (is_number(line + s, wl))           { EMIT(s, wl, HL_NUMBER);  continue; }
            if (is_logical(line + s, wl))          { EMIT(s, wl, HL_CONSTANT); continue; }
            if (in_list(line + s, wl, ADOBMD_FF_KEYWORDS))
                { EMIT(s, wl, HL_KEYWORD); continue; }
            if (looks_like_element(line + s, wl))
                { EMIT(s, wl, HL_SPECIES); continue; }

            EMIT(s, wl, HL_NONE);
        }
        return n;
    }

    /* ---------- .conf ---------- */
    if (program == HL_PROG_ADOBMD_CONF) {
        while (i < len) {
            if (line[i] == '#' || line[i] == '!') {
                EMIT(i, len - i, HL_COMMENT); break;
            }
            if (isspace((unsigned char)line[i])) { i++; continue; }

            /* Key up to '=' */
            int s = i;
            while (i < len && !isspace((unsigned char)line[i]) &&
                   line[i] != '=' && line[i] != '#' && line[i] != '!') i++;
            int wl = i - s;
            if (wl > 0) {
                if (in_list(line + s, wl, ADOBMD_CONF_KEYS))
                    EMIT(s, wl, HL_KEYWORD);
                else
                    EMIT(s, wl, HL_NONE);
            }

            /* Skip '=' */
            while (i < len && isspace((unsigned char)line[i])) i++;
            if (i < len && line[i] == '=') i++;
            while (i < len && isspace((unsigned char)line[i])) i++;

            /* Value up to whitespace or comment */
            int vs = i;
            while (i < len && !isspace((unsigned char)line[i]) &&
                   line[i] != '#' && line[i] != '!') i++;
            int vl = i - vs;
            if (vl > 0) {
                if (is_number(line + vs, vl))  EMIT(vs, vl, HL_NUMBER);
                else if (is_logical(line + vs, vl)) EMIT(vs, vl, HL_CONSTANT);
                else EMIT(vs, vl, HL_STRING);
            }
        }
        return n;
    }

    /* Fallback (should never run for ADOBMD builds) */
    while (i < len && isspace((unsigned char)line[i])) i++;
    if (i < len) {
        int s = i;
        while (i < len && !isspace((unsigned char)line[i])) i++;
        EMIT(s, i - s, HL_NONE);
    }

#undef EMIT
    return n;
}

/* ============================================================
 * Thread control
 * ============================================================ */

HL_EXPORT void hl_set_num_threads(int n) {
#ifdef _OPENMP
    if (n > 0) omp_set_num_threads(n);
#else
    (void)n;
#endif
}

/* ============================================================
 * File scan / token estimation
 * ============================================================ */

HL_EXPORT int hl_scan_file(const char* path, int* n_lines_out,
                           int* max_tokens_out) {
    if (!path || !n_lines_out || !max_tokens_out) return HL_ERR_BADARG;

    FILE* fp = fopen(path, "rb");
    if (!fp) return HL_ERR_OPEN;

    long bytes = 0;
    int lines = 0;
    char chunk[8192];
    size_t n;
    while ((n = fread(chunk, 1, sizeof(chunk), fp)) > 0) {
        bytes += (long)n;
        for (size_t i = 0; i < n; i++) if (chunk[i] == '\n') lines++;
    }
    fclose(fp);

    *n_lines_out = lines + 1;
    long est = bytes / 4 + 32;
    if (est > (long)INT_MAX) est = INT_MAX;
    *max_tokens_out = (int)est;
    return HL_OK;
}

/* ============================================================
 * Exact token count
 * ============================================================ */

HL_EXPORT int hl_count_buffer_tokens(const char* text, int len, int program) {
    if (!text || len <= 0) return 0;

    int n_lines = 1;
    for (int i = 0; i < len; i++) if (text[i] == '\n') n_lines++;

    int* line_starts = (int*)malloc(sizeof(int) * (n_lines + 1));
    int* line_lens   = (int*)malloc(sizeof(int) * n_lines);
    int* per_line    = (int*)calloc((size_t)n_lines, sizeof(int));
    if (!line_starts || !line_lens || !per_line) {
        free(line_starts); free(line_lens); free(per_line);
        return 0;
    }

    line_starts[0] = 0;
    int idx = 0;
    for (int i = 0; i < len; i++) {
        if (text[i] == '\n') {
            line_lens[idx] = i - line_starts[idx];
            idx++;
            line_starts[idx] = i + 1;
        }
    }
    line_lens[idx] = len - line_starts[idx];

    #pragma omp parallel for schedule(dynamic, 1024)
    for (int i = 0; i < n_lines; i++) {
        per_line[i] = lex_line_program(
            text + line_starts[i], line_lens[i],
            NULL, NULL, NULL, 0, program
        );
    }

    long total = 0;
    for (int i = 0; i < n_lines; i++) total += per_line[i];
    if (total > INT_MAX) total = INT_MAX;

    free(line_starts);
    free(line_lens);
    free(per_line);
    return (int)total;
}

/* ============================================================
 * Buffer parse
 * ============================================================ */

HL_EXPORT int hl_parse_buffer(const char* text, int len,
                              int* line_out, int* start_out,
                              int* len_out, int* type_out,
                              int max_tokens, int* n_tokens_out,
                              int program) {
    if (n_tokens_out) *n_tokens_out = 0;
    if (!text || len <= 0 ||
        !line_out || !start_out || !len_out || !type_out ||
        max_tokens <= 0) {
        return HL_ERR_BADARG;
    }

    int n_lines = 1;
    for (int i = 0; i < len; i++) if (text[i] == '\n') n_lines++;

    int* line_starts = (int*)malloc(sizeof(int) * (n_lines + 1));
    int* line_lens   = (int*)malloc(sizeof(int) * n_lines);
    int* per_line    = (int*)calloc((size_t)n_lines, sizeof(int));
    if (!line_starts || !line_lens || !per_line) {
        free(line_starts); free(line_lens); free(per_line);
        return HL_ERR_NOMEM;
    }

    line_starts[0] = 0;
    int idx = 0;
    for (int i = 0; i < len; i++) {
        if (text[i] == '\n') {
            line_lens[idx] = i - line_starts[idx];
            idx++;
            line_starts[idx] = i + 1;
        }
    }
    line_lens[idx] = len - line_starts[idx];

    #pragma omp parallel for schedule(dynamic, 1024)
    for (int i = 0; i < n_lines; i++) {
        per_line[i] = lex_line_program(
            text + line_starts[i], line_lens[i],
            NULL, NULL, NULL, 0, program
        );
    }

    long total = 0;
    for (int i = 0; i < n_lines; i++) total += per_line[i];

    if (total > max_tokens) {
        if (n_tokens_out)
            *n_tokens_out = (int)(total > INT_MAX ? INT_MAX : total);
        free(line_starts); free(line_lens); free(per_line);
        return HL_ERR_TOO_SMALL;
    }
    if (n_tokens_out) *n_tokens_out = (int)total;

    int* offsets = (int*)malloc(sizeof(int) * n_lines);
    if (!offsets) {
        free(line_starts); free(line_lens); free(per_line);
        return HL_ERR_NOMEM;
    }
    int running = 0;
    for (int i = 0; i < n_lines; i++) {
        offsets[i] = running;
        running += per_line[i];
    }

    #pragma omp parallel for schedule(dynamic, 1024)
    for (int i = 0; i < n_lines; i++) {
        int n = per_line[i];
        if (n == 0) continue;
        int base = offsets[i];
        lex_line_program(
            text + line_starts[i], line_lens[i],
            start_out + base, len_out + base, type_out + base,
            n, program
        );
        for (int t = 0; t < n; t++) line_out[base + t] = i;
    }

    free(line_starts);
    free(line_lens);
    free(per_line);
    free(offsets);
    return HL_OK;
}

/* ============================================================
 * File parse
 * ============================================================ */

HL_EXPORT int hl_parse_file(const char* path,
                            int* line_out, int* start_out,
                            int* len_out, int* type_out,
                            int max_tokens, int* n_tokens_out,
                            int program) {
    if (n_tokens_out) *n_tokens_out = 0;
    if (!path) return HL_ERR_BADARG;

    FILE* fp = fopen(path, "rb");
    if (!fp) return HL_ERR_OPEN;

    if (fseek(fp, 0, SEEK_END) != 0) { fclose(fp); return HL_ERR_OPEN; }
    long fsize = ftell(fp);
    if (fsize < 0) { fclose(fp); return HL_ERR_OPEN; }
    rewind(fp);

    if ((unsigned long)fsize > (unsigned long)INT_MAX) {
        fclose(fp); return HL_ERR_BADARG;
    }

    char* buffer = (char*)malloc((size_t)fsize + 1);
    if (!buffer) { fclose(fp); return HL_ERR_NOMEM; }

    size_t rd = fread(buffer, 1, (size_t)fsize, fp);
    fclose(fp);
    buffer[rd] = '\0';

    int status = hl_parse_buffer(
        buffer, (int)rd,
        line_out, start_out, len_out, type_out,
        max_tokens, n_tokens_out, program
    );
    free(buffer);
    return status;
}

/* ============================================================
 * Single-line fast path
 * ============================================================ */

HL_EXPORT int hl_lex_line_direct(const char* line, int len,
                                 int* starts, int* lens, int* types,
                                 int max_tokens, int program) {
    if (!line || len <= 0 || max_tokens <= 0) return 0;
    if (!starts || !lens || !types) return 0;
    return lex_line_program(line, len, starts, lens, types, max_tokens, program);
}