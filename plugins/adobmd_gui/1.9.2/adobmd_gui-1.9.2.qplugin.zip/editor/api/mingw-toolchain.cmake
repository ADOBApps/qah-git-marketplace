# ============================================================================
#  mingw-toolchain.cmake
#
#  Toolchain file for cross-compiling the highlighter library on Linux for
#  Windows (x86_64). Produces a fully statically-linked shared library with
#  no MinGW runtime DLL dependencies.
#
#  Usage:
#    mkdir build-windows && cd build-windows
#    cmake .. -DCMAKE_TOOLCHAIN_FILE=../mingw-toolchain.cmake \
#             -DCMAKE_BUILD_TYPE=Release
#    cmake --build . --parallel
# ============================================================================

set(CMAKE_SYSTEM_NAME Windows)
set(CMAKE_SYSTEM_PROCESSOR x86_64)

# Compilers (C only — no Fortran needed for this project)
set(CMAKE_C_COMPILER   x86_64-w64-mingw32-gcc)
set(CMAKE_RC_COMPILER  x86_64-w64-mingw32-windres)

# Sysroot (where the MinGW headers and libraries live)
set(CMAKE_FIND_ROOT_PATH /usr/x86_64-w64-mingw32)

# Search behavior
set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)
set(CMAKE_FIND_ROOT_PATH_MODE_LIBRARY ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_INCLUDE ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_PACKAGE ONLY)

# Cross-compiled binaries cannot be executed on the host, so CMake's
# try_run() probes must be disabled. This also makes FindOpenMP work
# reliably instead of silently failing.
set(CMAKE_TRY_COMPILE_TARGET_TYPE STATIC_LIBRARY)

# Fully static runtime for shared libraries, executables and modules.
# This prevents libgcc_s_seh-1.dll / libwinpthread-1.dll from being
# recorded as load-time dependencies of libhighlighter.dll.
set(CMAKE_SHARED_LINKER_FLAGS_INIT "-static -static-libgcc")
set(CMAKE_EXE_LINKER_FLAGS_INIT    "-static -static-libgcc")
set(CMAKE_MODULE_LINKER_FLAGS_INIT "-static -static-libgcc")