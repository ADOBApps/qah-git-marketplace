file(REMOVE_RECURSE
  "/home/adob/QAH/plugin_projects/adobmd_gui/editor/api/bin/libqah_highlighter.dll"
  "/home/adob/QAH/plugin_projects/adobmd_gui/editor/api/bin/libqah_highlighter.dll.a"
  "/home/adob/QAH/plugin_projects/adobmd_gui/editor/api/bin/libqah_highlighter.pdb"
  "CMakeFiles/highlighter.dir/src/highlighter.c.obj"
  "CMakeFiles/highlighter.dir/src/highlighter.c.obj.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/highlighter.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
