# Empty dependencies file for highlighter.
# This may be replaced when dependencies are built.
