rm -rf build build-windows bin
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
cmake --build . --parallel
cd ..

# --- Windows cross-compile ---
mkdir -p build-windows && cd build-windows
cmake .. \
    -DCMAKE_TOOLCHAIN_FILE=../mingw-toolchain.cmake \
    -DCMAKE_BUILD_TYPE=Release
cmake --build . --parallel
cd ..

# --- Verify the Windows DLL ---
x86_64-w64-mingw32-objdump -p bin/libqah_highlighter.dll | grep "DLL Name"