"""
ADOBMD file-type detection + syntax highlighting.

Handles only the formats ADOBMD itself reads:
    .data  — unified data file
    .ff    — force-field file
    .conf  — MD configuration (also accepts .input)
plus plain text for anything else the user opens.
"""

import re
import tempfile
from pathlib import Path, PurePosixPath

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QTextEdit, QMessageBox,
    QApplication, QStyle, QToolBar, QStatusBar
)
from PySide6.QtGui import (
    QFont, QAction, QIcon, QKeySequence,
    QSyntaxHighlighter, QTextCharFormat, QColor
)
from PySide6.QtCore import Signal

from .line_number_editor import NumberedTextEdit


# ===========================================================================
# File type detection — ADOBMD only
# ===========================================================================
class FileTypeDetector:
    """Detect ADOBMD file types."""

    _EXT_MAP = {
        '.data':  'adobmd_data',
        '.ff':    'adobmd_ff',
        '.conf':  'adobmd_conf',
        '.input': 'adobmd_conf',
        '.txt':   'text',
        '.md':    'text',
    }

    @staticmethod
    def detect_file_type(filepath: str):
        if not filepath or not Path(filepath).exists():
            return "unknown", False

        if FileTypeDetector._is_binary_file(filepath):
            return "binary", True

        ext = Path(filepath).suffix.lower()
        if ext in FileTypeDetector._EXT_MAP:
            return FileTypeDetector._EXT_MAP[ext], False

        content_type = FileTypeDetector._detect_by_content(filepath)
        if content_type:
            return content_type, False

        return "text", False

    @staticmethod
    def detect_from_name_only(name: str) -> str:
        if not name:
            return ""
        ext = PurePosixPath(name).suffix.lower()
        return FileTypeDetector._EXT_MAP.get(ext, "")

    @staticmethod
    def is_supported_filename(name: str) -> bool:
        if not name:
            return False
        ext = PurePosixPath(name).suffix.lower()
        return ext in FileTypeDetector._EXT_MAP

    @staticmethod
    def _is_binary_file(filepath: str) -> bool:
        try:
            with open(filepath, 'rb') as f:
                chunk = f.read(4096)
        except Exception:
            return False

        if not chunk:
            return False

        if chunk.startswith((b'\xff\xfe\x00\x00', b'\x00\x00\xfe\xff')):
            return False
        if chunk.startswith((b'\xff\xfe', b'\xfe\xff')):
            return False
        if chunk.startswith(b'\xef\xbb\xbf'):
            return False

        try:
            chunk.decode('utf-8')
            return False
        except UnicodeDecodeError:
            pass

        if b'\x00' in chunk:
            return True

        allowed = bytearray(
            {7, 8, 9, 10, 12, 13, 27}
            | (set(range(0x20, 0x100)) - {0x7f})
        )
        return bool(chunk.translate(None, allowed))

    @staticmethod
    def _detect_by_content(filepath: str):
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                head = f.read(2000)
            low = head.lower()

            if ("adobmd unified data" in low
                    or (" atoms" in low and " bonds" in low
                        and ("atom types" in low or "xlo xhi" in low))):
                return "adobmd_data"

            if ("<atomtypes>" in low or "<bondtypes>" in low
                    or "<bendtypes>" in low or "<torsiontypes>" in low
                    or "<nonbonded>" in low or "<regions>" in low
                    or "<plugins>" in low):
                return "adobmd_ff"

            for ln in head.splitlines():
                s = ln.strip()
                if not s or s[0] in "#!":
                    continue
                if "=" in s and s.split("=", 1)[0].replace("_", "").isalnum():
                    return "adobmd_conf"
        except Exception:
            pass
        return None


# ===========================================================================
# Syntax highlighter — 3 ADOBMD rule sets
# ===========================================================================
class AdobmdSyntaxHighlighter(QSyntaxHighlighter):
    """Syntax highlighter for ADOBMD .data / .ff / .conf files."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.file_type = "text"
        self.highlighting_rules = []
        self.setup_highlighting()

    def set_document_type(self, file_type: str):
        self.file_type = file_type or "text"
        self.setup_highlighting()
        self.rehighlight()

    def setup_highlighting(self):
        self.highlighting_rules = []
        dispatch = {
            "adobmd_data": self.setup_data_highlighting,
            "adobmd_ff":   self.setup_ff_highlighting,
            "adobmd_conf": self.setup_conf_highlighting,
        }
        dispatch.get(self.file_type, self.setup_text_highlighting)()

    def _fmt(self, color, bold=False, underline=False):
        f = QTextCharFormat()
        f.setForeground(QColor(color))
        if bold:
            f.setFontWeight(QFont.Bold)
        if underline:
            f.setFontUnderline(True)
        return f

    def setup_data_highlighting(self):
        # Section headers: Atoms, Bonds, Masses, ...
        self.highlighting_rules.append((
            r'^\s*(Atoms|Bonds|Angles|Dihedrals|Impropers|Masses|'
            r'Velocities|Pair|PairIJ)\b',
            self._fmt("#569CD6", bold=True)))
        # Header keywords
        self.highlighting_rules.append((
            r'\b(atoms|bonds|angles|dihedrals|impropers|'
            r'atom\s+types|bond\s+types|angle\s+types|'
            r'dihedral\s+types|improper\s+types|'
            r'xlo\s+xhi|ylo\s+yhi|zlo\s+zhi|xy\s+xz\s+yz)\b',
            self._fmt("#DCDCAA")))
        # Region tags
        self.highlighting_rules.append((
            r'\b(QM|MM|Q|M)\b',
            self._fmt("#FF79C6", bold=True)))
        # Numbers
        self.highlighting_rules.append((
            r'[-+]?\d*\.\d+(?:[dDeE][-+]?\d+)?',
            self._fmt("#B5CEA8")))
        self.highlighting_rules.append((
            r'\b\d+\b',
            self._fmt("#B5CEA8")))
        # Element symbols
        self.highlighting_rules.append((
            r'\b([A-Z][a-z]?)\b',
            self._fmt("#4EC9B0")))
        # Comments
        self.highlighting_rules.append((
            r'#.*',
            self._fmt("#6A9955")))

    def setup_ff_highlighting(self):
        # Section tags: <AtomTypes>, </AtomTypes>, ...
        self.highlighting_rules.append((
            r'<[^>]+>',
            self._fmt("#C586C0", bold=True)))
        # Keyword prefixes at line start
        self.highlighting_rules.append((
            r'^\s*(atomtype|bond|bend|angle|torsion|dihedral|'
            r'inversion|improper|nonbond|region|region_potential|'
            r'coupling|plugin|override)\b',
            self._fmt("#569CD6", bold=True)))
        # 'atoms', 'override'
        self.highlighting_rules.append((
            r'\b(atoms|override)\b',
            self._fmt("#FF79C6", bold=True)))
        # Logical literals
        self.highlighting_rules.append((
            r'\b(\.true\.|\.false\.|true|false)\b',
            self._fmt("#CE9178")))
        # Numbers
        self.highlighting_rules.append((
            r'[-+]?\d*\.\d+(?:[dDeE][-+]?\d+)?',
            self._fmt("#B5CEA8")))
        self.highlighting_rules.append((
            r'\b\d+\b',
            self._fmt("#B5CEA8")))
        # Comments
        self.highlighting_rules.append((
            r'[!#].*',
            self._fmt("#6A9955")))

    def setup_conf_highlighting(self):
        # Keys before '=' — covered by the pattern below (any identifier)
        self.highlighting_rules.append((
            r'^\s*[A-Za-z_][A-Za-z0-9_]*\s*(?==)',
            self._fmt("#569CD6", bold=True)))
        # Logical values
        self.highlighting_rules.append((
            r'\b(\.true\.|\.false\.|true|false)\b',
            self._fmt("#CE9178")))
        # Numbers
        self.highlighting_rules.append((
            r'[-+]?\d*\.\d+(?:[dDeE][-+]?\d+)?',
            self._fmt("#B5CEA8")))
        self.highlighting_rules.append((
            r'\b\d+\b',
            self._fmt("#B5CEA8")))
        # Comments
        self.highlighting_rules.append((
            r'[#!].*',
            self._fmt("#6A9955")))

    def setup_text_highlighting(self):
        self.highlighting_rules.append((
            r'https?://\S+', self._fmt("#569CD6", underline=True)))
        self.highlighting_rules.append((
            r'\b[\w\.-]+@[\w\.-]+\.\w+\b', self._fmt("#4EC9B0")))
        self.highlighting_rules.append((
            r'\b\d+\b', self._fmt("#B5CEA8")))

    def highlightBlock(self, text):
        for pattern, fmt in self.highlighting_rules:
            for m in re.finditer(pattern, text, re.IGNORECASE):
                self.setFormat(m.start(), m.end() - m.start(), fmt)


# ===========================================================================
# Editor widget (verbatim from reference — no quantum-specific content)
# ===========================================================================
class SimpleTextEditor(QWidget):
    """Text editor with ADOBMD syntax highlighting."""

    upload_requested = Signal(str, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.current_file = None
        self.temp_path = None
        self.remote_path = None
        self.main_window = None
        self.current_file_type = "text"
        self.highlighter = None
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        toolbar = QToolBar()

        self.file_label = QLabel("No file open")
        self.file_label.setStyleSheet(
            "QLabel { padding: 4px; font-weight: bold; color: #2196F3; }"
        )
        toolbar.addWidget(self.file_label)

        self.type_label = QLabel("type: text")
        self.type_label.setStyleSheet(
            "QLabel { padding: 4px 8px; background: #e3f2fd;"
            " color: #0d47a1; border-radius: 3px; font-weight: bold; }"
        )
        toolbar.addWidget(self.type_label)

        toolbar.addSeparator()

        self.save_action = QAction(QIcon(), "Save", self)
        self.save_action.setIcon(
            QApplication.style().standardIcon(QStyle.SP_DialogSaveButton))
        self.save_action.setShortcut(QKeySequence("Ctrl+S"))
        self.save_action.triggered.connect(self.save_file)
        self.save_action.setEnabled(False)
        toolbar.addAction(self.save_action)

        self.save_back_action = QAction(QIcon(), "Save && Upload", self)
        self.save_back_action.setIcon(
            QApplication.style().standardIcon(QStyle.SP_ArrowUp))
        self.save_back_action.setShortcut(QKeySequence("Ctrl+Shift+S"))
        self.save_back_action.triggered.connect(self.save_and_upload)
        self.save_back_action.setEnabled(False)
        toolbar.addAction(self.save_back_action)

        toolbar.addSeparator()

        undo_action = QAction(QIcon(), "Undo", self)
        undo_action.setIcon(
            QApplication.style().standardIcon(QStyle.SP_ArrowBack))
        undo_action.setShortcut(QKeySequence("Ctrl+Z"))
        undo_action.triggered.connect(self.undo)
        toolbar.addAction(undo_action)

        redo_action = QAction(QIcon(), "Redo", self)
        redo_action.setIcon(
            QApplication.style().standardIcon(QStyle.SP_ArrowForward))
        redo_action.setShortcut(QKeySequence("Ctrl+Y"))
        redo_action.triggered.connect(self.redo)
        toolbar.addAction(redo_action)

        layout.addWidget(toolbar)

        self.text_edit = NumberedTextEdit()
        self.text_edit.textChanged.connect(self.on_text_changed)
        self.highlighter = NativeAdobmdHighlighter(self.text_edit.document())
        layout.addWidget(self.text_edit)

        self.status_bar = QStatusBar()
        layout.addWidget(self.status_bar)

    def set_main_window(self, main_window):
        self.main_window = main_window

    def _apply_file_type(self, file_type: str, filename: str = ""):
        self.current_file_type = file_type or "text"
        self.type_label.setText(f"type: {self.current_file_type}")
        if self.highlighter is not None:
            try:
                self.highlighter.set_document_type(
                    self.current_file_type, filename=filename)
            except TypeError:
                self.highlighter.set_document_type(self.current_file_type)

    def _detect_type_for(self, local_path, remote_path) -> str:
        if remote_path:
            name = PurePosixPath(remote_path).name
            ftype = FileTypeDetector.detect_from_name_only(name)
            if ftype:
                return ftype
        if local_path and Path(local_path).exists():
            ftype, _ = FileTypeDetector.detect_file_type(str(local_path))
            if ftype not in ("unknown", "binary"):
                return ftype
        return "text"

    def load_file(self, content: str, filename: str, remote_path: str = None):
        self.text_edit.blockSignals(True)
        self.text_edit.setPlainText(content)
        self.text_edit.blockSignals(False)

        self.current_file = filename
        self.remote_path = remote_path

        file_type = self._detect_type_for(self.temp_path, remote_path)
        self._apply_file_type(file_type, filename=filename)

        if remote_path:
            display_path = PurePosixPath(remote_path).parent
            self.file_label.setText(
                f"Editing: {filename} (from: {display_path})")
        else:
            self.file_label.setText(f"Editing: {filename}")

        self.save_action.setEnabled(False)
        self.save_back_action.setEnabled(False)
        self.status_bar.showMessage(
            f"Loaded {len(content)} characters — detected as {file_type}")

    def load_temp_file(self, temp_path: Path, remote_path: str = None):
        try:
            for encoding in ('utf-8', 'latin-1', 'cp1252'):
                try:
                    content = temp_path.read_text(encoding=encoding)
                    break
                except UnicodeDecodeError:
                    continue
            else:
                content = temp_path.read_bytes().decode(
                    'utf-8', errors='replace')

            self.temp_path = temp_path
            self.remote_path = remote_path
            self.load_file(content, temp_path.name, remote_path)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load file: {e}")

    def save_file(self):
        if not self.temp_path:
            temp_dir = Path.home() / "ADOBMD" / "temp"
            temp_dir.mkdir(parents=True, exist_ok=True)
            self.temp_path = Path(
                tempfile.mktemp(suffix=".txt", dir=str(temp_dir)))
        try:
            content = self.text_edit.toPlainText()
            self.temp_path.write_text(content, encoding='utf-8')
            self.save_action.setEnabled(False)
            self.status_bar.showMessage(f"Saved to: {self.temp_path.name}")
            return True
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save: {e}")
            return False

    def save_and_upload(self):
        if not self.save_file():
            return
        if not self.remote_path:
            QMessageBox.warning(
                self, "Warning",
                "No remote path associated with this file.")
            return
        if not self.main_window or not getattr(
                self.main_window, 'sftp_client', None):
            QMessageBox.warning(
                self, "Warning",
                "Not connected to server.")
            return

        reply = QMessageBox.question(
            self, "Confirm Upload",
            f"Upload '{self.current_file}' to server?\n"
            f"Destination: {self.remote_path}\n\n"
            "This will overwrite the original file on the server.",
            QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            if hasattr(self.main_window, 'upload_edited_file'):
                self.main_window.upload_edited_file(
                    self.temp_path, self.remote_path)
            else:
                self.upload_requested.emit(
                    str(self.temp_path), self.remote_path)

    def get_content(self) -> str:
        return self.text_edit.toPlainText()

    def undo(self):
        self.text_edit.undo()

    def redo(self):
        self.text_edit.redo()

    def on_text_changed(self):
        self.save_action.setEnabled(True)
        self.save_back_action.setEnabled(True)


# ===========================================================================
# Native (C) highlighter — ADOBMD-only
# ===========================================================================
import numpy as np

try:
    from .api.highlighter_wrapper import (
        NativeHighlighter, get_native_highlighter, detect_program,
        PROG_UNKNOWN, PROG_ADOBMD_DATA, PROG_ADOBMD_FF, PROG_ADOBMD_CONF,
        HL_KEYWORD, HL_TYPE, HL_COMMENT, HL_STRING, HL_TAG, HL_NUMBER,
        HL_CONSTANT, HL_OPERATOR, HL_SECTION, HL_DIRECTIVE, HL_CARD,
        HL_ROUTE, HL_SPECIES, HL_COORD,
    )
    _NATIVE_IMPORT_OK = True
except Exception:
    _NATIVE_IMPORT_OK = False


if _NATIVE_IMPORT_OK:
    _PROGRAM_FOR_TYPE = {
        "adobmd_data": PROG_ADOBMD_DATA,
        "adobmd_ff":   PROG_ADOBMD_FF,
        "adobmd_conf": PROG_ADOBMD_CONF,
    }
else:
    _PROGRAM_FOR_TYPE = {}


class NativeAdobmdHighlighter(AdobmdSyntaxHighlighter):
    """Native C-backed highlighter with pure-Python fallback."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._native = get_native_highlighter() if _NATIVE_IMPORT_OK else None
        self._program = PROG_UNKNOWN if _NATIVE_IMPORT_OK else 0
        self._cap = 256
        self._buf_starts = np.zeros(self._cap, np.int32)
        self._buf_lens   = np.zeros(self._cap, np.int32)
        self._buf_types  = np.zeros(self._cap, np.int32)
        self._formats = {
            HL_KEYWORD:   self._fmt("#569CD6", bold=True),
            HL_TYPE:      self._fmt("#DCDCAA", bold=True),
            HL_COMMENT:   self._fmt("#6A9955"),
            HL_STRING:    self._fmt("#CE9178"),
            HL_TAG:       self._fmt("#C586C0"),
            HL_NUMBER:    self._fmt("#B5CEA8"),
            HL_CONSTANT:  self._fmt("#FF79C6"),
            HL_OPERATOR:  self._fmt("#FF79C6"),
            HL_SECTION:   self._fmt("#C586C0", bold=True),
            HL_DIRECTIVE: self._fmt("#DCDCAA"),
            HL_CARD:      self._fmt("#569CD6", bold=True),
            HL_ROUTE:     self._fmt("#569CD6", bold=True),
            HL_SPECIES:   self._fmt("#FF79C6", bold=True),
            HL_COORD:     self._fmt("#B5CEA8"),
        } if _NATIVE_IMPORT_OK else {}

    def set_document_type(self, file_type: str, filename: str = ""):
        self.file_type = file_type or "text"
        if _NATIVE_IMPORT_OK and self._native is not None:
            if filename:
                self._program = detect_program(filename, "")
            else:
                self._program = _PROGRAM_FOR_TYPE.get(
                    self.file_type, PROG_UNKNOWN)
        else:
            self._program = 0
        super().set_document_type(self.file_type)

    def highlightBlock(self, text):
        if (self._native is not None
                and _NATIVE_IMPORT_OK
                and self._program != PROG_UNKNOWN):
            try:
                n = self._native.lex_line_into(
                    text,
                    self._buf_starts, self._buf_lens, self._buf_types,
                    program=self._program,
                )
            except Exception:
                n = 0
            if n > 0:
                for i in range(n):
                    fmt = self._formats.get(int(self._buf_types[i]))
                    if fmt is not None:
                        self.setFormat(
                            int(self._buf_starts[i]),
                            int(self._buf_lens[i]),
                            fmt,
                        )
                return
        super().highlightBlock(text)