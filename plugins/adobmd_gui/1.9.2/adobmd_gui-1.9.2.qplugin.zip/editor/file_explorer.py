"""
ADOBMD file explorer tree with Name / Detected / Size columns,
lazy folder-size computation, and a "Show sizes" toggle.

Only ADOBMD file extensions are listed as "detected":
    .data  -> adobmd_data
    .ff    -> adobmd_ff
    .conf  -> adobmd_conf
    .txt   -> text
    .md    -> text
Anything else shows as "file" but can still be opened.
"""

import shutil
from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt, Signal, QSettings
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QCheckBox, QTreeWidget, QTreeWidgetItem, QInputDialog,
    QFileDialog, QMessageBox, QApplication, QStyle,
)

from .adobmd_tool import FileTypeDetector


def _format_size(num_bytes: int) -> str:
    if num_bytes < 0:
        return "—"
    if num_bytes < 1024:
        return f"{num_bytes} B"
    for unit in ("KB", "MB", "GB", "TB"):
        num_bytes /= 1024.0
        if num_bytes < 1024:
            if num_bytes >= 100 or num_bytes == int(num_bytes):
                return f"{int(num_bytes)} {unit}"
            return f"{num_bytes:.1f} {unit}"
    return f"{num_bytes:.0f} PB"


def _dir_size(path: Path, follow_symlinks: bool = False,
              max_entries: int = 200_000) -> int:
    total = 0
    count = 0
    stack = [path]
    while stack:
        current = stack.pop()
        try:
            for entry in current.iterdir():
                count += 1
                if count > max_entries:
                    return 0
                try:
                    if entry.is_dir():
                        if follow_symlinks or not entry.is_symlink():
                            stack.append(entry)
                    elif entry.is_file():
                        total += entry.stat().st_size
                except OSError:
                    continue
        except OSError:
            continue
    return total


class FileExplorer(QWidget):
    """Left pane: project tree with sizes and file operations."""

    fileActivated = Signal(str)
    fileDeleted = Signal(str)
    projectChanged = Signal(str)

    def __init__(self, settings: QSettings, parent=None):
        super().__init__(parent)
        self.settings = settings
        self.project_path: Optional[Path] = None
        self._show_sizes = self.settings.value("show_sizes", True, type=bool)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        bar = QHBoxLayout()

        new_btn = QPushButton("New folder")
        new_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_DirHomeIcon))
        new_btn.clicked.connect(self.new_folder)
        bar.addWidget(new_btn)

        refresh_btn = QPushButton("Refresh")
        refresh_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_BrowserReload))
        refresh_btn.clicked.connect(self.refresh)
        bar.addWidget(refresh_btn)

        self.show_sizes_check = QCheckBox("Show sizes")
        self.show_sizes_check.setChecked(self._show_sizes)
        self.show_sizes_check.toggled.connect(self._on_show_sizes_toggled)
        bar.addWidget(self.show_sizes_check)
        bar.addStretch()

        layout.addLayout(bar)

        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Name", "Detected", "Size"])
        self.tree.setColumnWidth(0, 220)
        self.tree.setColumnWidth(1, 90)
        self.tree.setColumnWidth(2, 80)
        self.tree.setRootIsDecorated(True)
        self.tree.setUniformRowHeights(True)
        self.tree.headerItem().setTextAlignment(
            2, Qt.AlignRight | Qt.AlignVCenter)
        self.tree.setColumnHidden(2, not self._show_sizes)
        self.tree.itemDoubleClicked.connect(self._on_double_click)
        self.tree.itemExpanded.connect(self._on_expanded)
        layout.addWidget(self.tree)

        self.project_label = QLabel("No project open")
        layout.addWidget(self.project_label)

        open_btn = QPushButton("Open Project Folder")
        open_btn.setIcon(
            QApplication.style().standardIcon(QStyle.SP_DirOpenIcon))
        open_btn.clicked.connect(self.open_project)
        layout.addWidget(open_btn)

    def open_project(self):
        directory = QFileDialog.getExistingDirectory(
            self, "Open Project Folder")
        if directory:
            self.project_path = Path(directory)
            self.project_label.setText(f"Project: {directory}")
            self.projectChanged.emit(directory)
            self.refresh()

    def new_folder(self):
        if not self.project_path:
            QMessageBox.warning(
                self, "No Project", "Please open a project first")
            return
        name, ok = QInputDialog.getText(self, "New Folder", "Folder name:")
        if ok and name:
            try:
                (self.project_path / name).mkdir(exist_ok=True)
                self.refresh()
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed: {e}")

    def refresh(self):
        if not self.project_path:
            self.tree.clear()
            return
        self.tree.clear()
        self._populate(None, self.project_path)
        if self.tree.topLevelItemCount():
            self.tree.expandItem(self.tree.topLevelItem(0))

    def _populate(self, parent_item, path: Path):
        root = parent_item is None
        if root:
            root_item = QTreeWidgetItem(
                self.tree,
                [path.name, "", "…" if self._show_sizes else ""],
            )
            root_item.setIcon(
                0, QApplication.style().standardIcon(QStyle.SP_DirIcon))
            root_item.setData(0, Qt.UserRole, str(path))
            if self._show_sizes:
                root_item.setData(2, Qt.UserRole, "pending")
            parent_item = root_item

        for item in sorted(
            path.iterdir(),
            key=lambda x: (not x.is_dir(), x.name.lower()),
        ):
            if item.is_dir():
                dir_item = QTreeWidgetItem(
                    parent_item,
                    [item.name, "", "…" if self._show_sizes else ""],
                )
                dir_item.setIcon(
                    0,
                    QApplication.style().standardIcon(QStyle.SP_DirIcon))
                dir_item.setData(0, Qt.UserRole, str(item))
                if self._show_sizes:
                    dir_item.setData(2, Qt.UserRole, "pending")
                self._populate(dir_item, item)
            else:
                detected = (
                    FileTypeDetector.detect_from_name_only(item.name)
                    or "file"
                )
                if self._show_sizes:
                    try:
                        size = item.stat().st_size
                        size_text = _format_size(size)
                    except OSError:
                        size = -1
                        size_text = "—"
                else:
                    size = -1
                    size_text = ""
                file_item = QTreeWidgetItem(
                    parent_item, [item.name, detected, size_text])
                file_item.setIcon(
                    0,
                    QApplication.style().standardIcon(QStyle.SP_FileIcon))
                file_item.setData(0, Qt.UserRole, str(item))
                if self._show_sizes and size >= 0:
                    file_item.setToolTip(2, f"{size:,} bytes")

    def _on_expanded(self, item: QTreeWidgetItem):
        if not self._show_sizes:
            return
        if item.data(2, Qt.UserRole) != "pending":
            return
        filepath = item.data(0, Qt.UserRole)
        if not filepath:
            return
        path_obj = Path(filepath)
        if not path_obj.is_dir():
            return
        item.setText(2, "…")
        item.setData(2, Qt.UserRole, "computing")
        QApplication.processEvents()
        try:
            size = _dir_size(path_obj)
            try:
                has_children = any(path_obj.iterdir())
            except OSError:
                has_children = False
            if size == 0 and has_children:
                item.setText(2, "—")
                item.setToolTip(2, "Folder too large to size")
            else:
                item.setText(2, _format_size(size))
                item.setToolTip(2, f"{size:,} bytes")
        except OSError:
            item.setText(2, "—")
            item.setToolTip(2, "Unreadable")
        finally:
            item.setData(2, Qt.UserRole, "done")

    def _on_show_sizes_toggled(self, checked: bool):
        self._show_sizes = bool(checked)
        self.tree.setColumnHidden(2, not self._show_sizes)
        self.settings.setValue("show_sizes", self._show_sizes)

    def _on_double_click(self, item: QTreeWidgetItem, column: int):
        filepath = item.data(0, Qt.UserRole)
        if not filepath:
            return
        p = Path(filepath)
        if p.is_file():
            self.fileActivated.emit(filepath)

    def delete_selected(self, confirmed_paths: Optional[set] = None):
        sel = self.tree.selectedItems()
        if not sel:
            return
        item = sel[0]
        filepath = item.data(0, Qt.UserRole)
        if not filepath:
            return
        path_obj = Path(filepath)
        is_dir = path_obj.is_dir()
        item_type = "folder and all its contents" if is_dir else "file"
        reply = QMessageBox.question(
            self, "Confirm Deletion",
            f"Delete this {item_type} permanently?\n{path_obj.name}",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return
        try:
            if is_dir:
                shutil.rmtree(path_obj)
            else:
                path_obj.unlink()
            parent = item.parent()
            if parent:
                parent.removeChild(item)
                if self._show_sizes:
                    parent.setText(2, "…")
                    parent.setData(2, Qt.UserRole, "pending")
            else:
                idx = self.tree.indexOfTopLevelItem(item)
                self.tree.takeTopLevelItem(idx)
            self.fileDeleted.emit(filepath)
        except Exception as e:
            QMessageBox.critical(self, "Deletion Error", str(e))