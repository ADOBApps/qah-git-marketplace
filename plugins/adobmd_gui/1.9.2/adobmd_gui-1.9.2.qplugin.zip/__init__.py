"""
Author: Acxel Orozco
Date: 2026-03-09
Description: ADOBMD Visualizer - Visualize and export ADOBMD data files
"""

from pathlib import Path
from typing import Optional
import logging
import sys

from PySide6.QtWidgets import QWidget
from PySide6.QtGui import QIcon
from PySide6.QtCore import QObject

from plugins.libs.plugin_manager import PluginInfo


class ADOBMDVisualizer(QObject):
    """Main plugin class for ADOBMD Visualizer"""
    
    def __init__(self, plugin_info: PluginInfo):
        super().__init__()
        self.plugin_info = plugin_info
        self.ui_widget = None
        self.icon = None
        self.logger = self._setup_logging()
        
        # Load icon if available
        plugin_dir = Path(__file__).parent
        icon_path = plugin_dir / "icon.png"
        if icon_path.exists():
            self.icon = QIcon(str(icon_path))
    
    def _setup_logging(self):
        """Setup logging for the plugin"""
        logger = logging.getLogger('ADOBMDVisualizer')
        logger.setLevel(logging.INFO)
        
        if not logger.handlers:
            handler = logging.StreamHandler(sys.stdout)
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        
        return logger
    
    def initialize(self) -> bool:
        """Initialize plugin resources"""
        try:
            self.logger.info(f"Initializing plugin {self.plugin_info.name}")
            
            # Verify required modules are available
            try:
                from .viewer.widgets.data_widget import DataVisualizerWidget
                from .viewer.widgets.xyz_widget import XYZVisualizationWidget
                from .converter.converter_widget import ConverterWidget
                from .md_engine.md_widget import MDWidget
                self.logger.info("Widget modules loaded successfully")
            except ImportError as e:
                self.logger.error(f"Failed to import widgets: {e}")
                return False
            
            return True
        except Exception as e:
            self.logger.error(f"Failed to initialize plugin: {e}")
            return False
    
    def get_widget(self) -> Optional[QWidget]:
        """Get the main UI widget"""
        if self.ui_widget is None:
            try:
                # Import the main widget
                from .main_widget import VisualizerWidget
                
                # Create the main widget with plugin instance reference
                self.ui_widget = VisualizerWidget(self)
                
                self.logger.info("Main widget created successfully")
                
            except Exception as e:
                self.logger.error(f"Failed to create widget: {e}")
                import traceback
                traceback.print_exc()
                return None
        
        return self.ui_widget
    
    def cleanup(self):
        """Clean up plugin resources"""
        self.logger.info("Cleaning up plugin resources")
        
        if self.ui_widget:
            if hasattr(self.ui_widget, 'cleanup'):
                self.ui_widget.cleanup()
            
            self.ui_widget.deleteLater()
            self.ui_widget = None


# Plugin factory function
Plugin = ADOBMDVisualizer