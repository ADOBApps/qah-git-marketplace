"""Protonation Lab plugin entry point.

Structure-based pH-dependent protonation and pKa analysis.
GPL-3.0-or-later.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QObject
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QWidget

try:
    from plugins.libs.plugin_manager import PluginInfo
except Exception:  # other QAH builds may use a different module layout
    PluginInfo = object  # type: ignore

__version__ = "0.2.0"


class ProtonationLabPlugin(QObject):
    def __init__(self, plugin_info: PluginInfo):
        super().__init__()
        self.plugin_info = plugin_info
        self.ui_widget: Optional[QWidget] = None
        self.icon: Optional[QIcon] = None
        plugin_dir = Path(__file__).parent
        for name in ("icon.svg", "icon.png"):
            path = plugin_dir / name
            if path.is_file():
                self.icon = QIcon(str(path))
                break

    def initialize(self) -> bool:
        try:
            logging.info(
                "Initializing %s version %s",
                getattr(self.plugin_info, "name", "Protonation Lab"),
                getattr(self.plugin_info, "version", __version__),
            )
            return True
        except Exception as exc:
            logging.exception("Protonation Lab initialization failed: %s", exc)
            return False

    def get_widget(self) -> Optional[QWidget]:
        if self.ui_widget is None:
            try:
                from .protonation_widget import ProtonationLabWidget

                self.ui_widget = ProtonationLabWidget(self)
            except Exception as exc:
                logging.exception("Could not create Protonation Lab widget: %s", exc)
                return None
        return self.ui_widget

    def cleanup(self) -> None:
        if self.ui_widget is not None:
            try:
                if self.ui_widget.worker is not None and self.ui_widget.worker.isRunning():
                    self.ui_widget.worker.quit()
                    self.ui_widget.worker.wait(2000)
            except Exception:
                pass


Plugin = ProtonationLabPlugin
