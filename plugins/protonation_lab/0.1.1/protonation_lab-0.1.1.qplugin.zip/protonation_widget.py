"""Protonation Lab UI.

GPL-3.0-or-later.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from . import protonation_core as core

try:
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
    from matplotlib.figure import Figure

    MATPLOTLIB_OK = True
except Exception:
    FigureCanvasQTAgg = None  # type: ignore
    Figure = None  # type: ignore
    MATPLOTLIB_OK = False


class AnalyzeWorker(QThread):
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, structure, parameters: Dict[str, Any], parent=None):
        super().__init__(parent)
        self.structure = structure
        self.parameters = parameters

    def run(self) -> None:
        try:
            self.done.emit(core.analyze(self.structure, **self.parameters))
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class ProtonationLabWidget(QWidget):
    def __init__(self, plugin=None, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.structure: Optional[core.Structure] = None
        self.result: Optional[Dict[str, Any]] = None
        self.worker: Optional[AnalyzeWorker] = None
        self._build_ui()

    # -- construction -----------------------------------------------------
    def _build_ui(self) -> None:
        outer_layout = QVBoxLayout(self)
        outer_layout.setContentsMargins(0, 0, 0, 0)
        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(8, 8, 8, 8)
        header = QHBoxLayout()
        title = QLabel("<b>Protonation Lab</b>")
        title.setFont(QFont("Segoe UI", 15, QFont.Weight.Bold))
        header.addWidget(title)
        subtitle = QLabel("pH-dependent protonation states, pKa and titration")
        subtitle.setStyleSheet("color:#6b7280;")
        header.addWidget(subtitle, 1)
        self.status = QLabel("Load a PDB or mmCIF file.")
        self.status.setStyleSheet("color:#6b7280;")
        self.status.setWordWrap(True)
        header.addWidget(self.status)
        layout.addLayout(header)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._scroll_page(self._build_structure_tab(), 480), "Structure")
        self.tabs.addTab(self._scroll_page(self._build_protonation_tab(), 620), "Protonation")
        self.tabs.addTab(self._scroll_page(self._build_titration_tab(), 520), "Titration")
        self.tabs.addTab(self._scroll_page(self._build_report_tab(), 420), "Report")
        self.tabs.addTab(self._scroll_page(self._build_help_tab(), 420), "Help")
        layout.addWidget(self.tabs, 1)

        content.setMinimumSize(900, 620)
        outer = QScrollArea()
        outer.setWidgetResizable(True)
        outer.setFrameShape(QFrame.Shape.NoFrame)
        outer.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        outer.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        outer.setWidget(content)
        outer_layout.addWidget(outer, 1)

    def _scroll_page(self, page: QWidget, min_height: int = 420) -> QScrollArea:
        if page.layout() is not None:
            page.layout().activate()
        page.setMinimumWidth(0)
        hint = page.sizeHint()
        page.setMinimumHeight(max(min_height, min(950, int(hint.height()))))
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setWidget(page)
        return scroll

    def _text_pane(self, widget: QPlainTextEdit) -> QPlainTextEdit:
        widget.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        widget.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        return widget

    def _build_structure_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        box = QGroupBox("Structure")
        box_layout = QVBoxLayout(box)
        row = QHBoxLayout()
        load = QPushButton("Load PDB / mmCIF…")
        load.clicked.connect(self._load_structure)
        row.addWidget(load)
        self.structure_path = QLabel("No structure loaded.")
        self.structure_path.setWordWrap(True)
        row.addWidget(self.structure_path, 1)
        box_layout.addLayout(row)
        self.structure_info = self._text_pane(QPlainTextEdit())
        self.structure_info.setReadOnly(True)
        self.structure_info.setFont(QFont("Consolas", 9))
        self.structure_info.setMaximumHeight(150)
        box_layout.addWidget(self.structure_info)
        layout.addWidget(box)

        box = QGroupBox("Input warnings")
        box_layout = QVBoxLayout(box)
        self.structure_warnings = self._text_pane(QPlainTextEdit())
        self.structure_warnings.setReadOnly(True)
        self.structure_warnings.setFont(QFont("Consolas", 9))
        box_layout.addWidget(self.structure_warnings)
        layout.addWidget(box, 1)
        return page

    def _build_protonation_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        box = QGroupBox("Run")
        form = QFormLayout(box)
        form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.ph = QDoubleSpinBox()
        self.ph.setRange(0.0, 14.0)
        self.ph.setDecimals(2)
        self.ph.setSingleStep(0.1)
        self.ph.setValue(7.0)
        form.addRow("pH:", self.ph)
        self.ionic = QDoubleSpinBox()
        self.ionic.setRange(0.0, 1.0)
        self.ionic.setDecimals(3)
        self.ionic.setSingleStep(0.05)
        self.ionic.setValue(0.15)
        form.addRow("Ionic strength (M):", self.ionic)
        self.temperature = QDoubleSpinBox()
        self.temperature.setRange(273.15, 350.0)
        self.temperature.setDecimals(2)
        self.temperature.setValue(298.15)
        self.temperature.setSuffix(" K")
        form.addRow("Temperature:", self.temperature)
        self.mc_moves = QSpinBox()
        self.mc_moves.setRange(5000, 200000)
        self.mc_moves.setSingleStep(5000)
        self.mc_moves.setValue(20000)
        form.addRow("MC moves:", self.mc_moves)
        self.seed = QSpinBox()
        self.seed.setRange(0, 2147483647)
        self.seed.setValue(20261109)
        form.addRow("Random seed:", self.seed)
        row = QHBoxLayout()
        self.run_btn = QPushButton("Run protonation")
        self.run_btn.clicked.connect(self._run)
        row.addWidget(self.run_btn)
        self.run_status = QLabel("No analysis yet.")
        self.run_status.setStyleSheet("color:#6b7280;")
        self.run_status.setWordWrap(True)
        row.addWidget(self.run_status, 1)
        form.addRow("", row)
        layout.addWidget(box)

        self.site_table = QTableWidget(0, 10)
        self.site_table.setHorizontalHeaderLabels([
            "Chain", "Residue", "Number", "Site", "pKa int", "pKa app",
            "Prot @ pH", "MC", "State", "Flag",
        ])
        self.site_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.site_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.site_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.site_table.verticalHeader().setVisible(False)
        self.site_table.setWordWrap(True)
        self.site_table.itemSelectionChanged.connect(self._selection_changed)
        layout.addWidget(self.site_table, 1)
        return page

    def _build_titration_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        row = QHBoxLayout()
        row.addWidget(QLabel("Site curve:"))
        self.site_combo = QComboBox()
        self.site_combo.setMinimumWidth(280)
        self.site_combo.currentIndexChanged.connect(self._plot)
        row.addWidget(self.site_combo, 1)
        row.addStretch(1)
        layout.addLayout(row)
        self.summary_label = QLabel("Run the analysis to see titration curves.")
        self.summary_label.setWordWrap(True)
        layout.addWidget(self.summary_label)
        if MATPLOTLIB_OK:
            self.canvas = FigureCanvasQTAgg(Figure(figsize=(8, 5), tight_layout=True))
            self.canvas.setMinimumHeight(360)
        else:
            self.canvas = QLabel("matplotlib is not available; titration plots are disabled.")
        layout.addWidget(self.canvas, 1)
        return page

    def _build_report_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        row = QHBoxLayout()
        export_csv = QPushButton("Export CSV…")
        export_csv.clicked.connect(self._export_csv)
        export_json = QPushButton("Export JSON…")
        export_json.clicked.connect(self._export_json)
        export_pdb = QPushButton("Export protonated PDB…")
        export_pdb.clicked.connect(self._export_pdb)
        for button in (export_csv, export_json, export_pdb):
            row.addWidget(button)
        row.addStretch(1)
        layout.addLayout(row)
        self.report = self._text_pane(QPlainTextEdit())
        self.report.setReadOnly(True)
        self.report.setFont(QFont("Consolas", 9))
        layout.addWidget(self.report, 1)
        return page

    def _build_help_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        browser = QTextBrowser()
        browser.setOpenExternalLinks(True)
        browser.setHtml(
            "<h2>Protonation Lab</h2>"
            "<p>Structure-based pH-dependent protonation and pKa analysis for "
            "proteins and metalloproteins.</p>"
            "<h3>Workflow</h3>"
            "<ol>"
            "<li>Load a PDB or mmCIF structure.</li>"
            "<li>Set pH, ionic strength and temperature.</li>"
            "<li>Press <b>Run protonation</b>.</li>"
            "<li>Inspect the site table and titration curves.</li>"
            "<li>Export CSV/JSON and a protonated coordinate copy.</li>"
            "</ol>"
            "<h3>Model</h3>"
            "<p>v0.1 uses solvent-accessible-surface burial, screened Coulomb "
            "electrostatics with a distance-dependent dielectric, Debye-Hückel "
            "ionic screening, mean-field titration and Monte Carlo microstate "
            "sampling. A finite-difference Poisson-Boltzmann grid solver is the "
            "next planned refinement.</p>"
            "<h3>Limitations</h3>"
            "<ul>"
            "<li>The current model is an analytic continuum approximation, not a "
            "full finite-difference PB calculation.</li>"
            "<li>No missing hydrogens or atoms are rebuilt. The exported PDB "
            "contains state REMARKs and histidine state names.</li>"
            "<li>Histidine is represented by one neutral tautomer plus the "
            "cationic state; both tautomers and rotamers are not fully sampled.</li>"
            "<li>Metal ions are fixed charges; protonation-redox coupling is not "
            "predicted.</li>"
            "<li>Results near the target pH, in buried sites, and at metal centres "
            "carry the largest uncertainty.</li>"
            "</ul>"
            "<h3>Export</h3>"
            "<p>The CSV contains pKa, protonation and state per site. The JSON "
            "contains the full result. The protonated PDB preserves coordinates "
            "and adds state REMARKs; it does not add hydrogens.</p>"
        )
        layout.addWidget(browser)
        return page

    # -- structure --------------------------------------------------------
    def _load_structure(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Load structure", str(Path.home()),
            "Structures (*.pdb *.ent *.cif *.mmcif);;All files (*)",
        )
        if not path:
            return
        try:
            structure = core.parse_structure(Path(path))
        except Exception as exc:
            QMessageBox.warning(self, "Protonation Lab", f"Could not parse structure:\n{exc}")
            return
        if not structure.atoms:
            QMessageBox.warning(self, "Protonation Lab", "No atoms were read from the file.")
            return
        self.structure = structure
        self.result = None
        self.structure_path.setText(str(path))
        chains = sorted({residue.chain for residue in structure.residues})
        metals = sorted({atom.element for atom in structure.atoms if atom.hetero and atom.element in core.METAL_CHARGE})
        info = [
            f"File      : {path}",
            f"Format    : {structure.format}",
            f"Atoms     : {len(structure.atoms)}",
            f"Residues  : {len(structure.residues)}",
            f"Chains    : {', '.join(chains) or '(none)'}",
            f"Metals    : {', '.join(metals) or '(none)'}",
            f"Waters    : {sum(1 for r in structure.residues if r.name.upper() in core.WATER)}",
        ]
        self.structure_info.setPlainText("\n".join(info))
        self.structure_warnings.setPlainText(
            "\n".join(structure.warnings) if structure.warnings else "No parser warnings."
        )
        self.site_table.setRowCount(0)
        self.site_combo.clear()
        self.report.clear()
        self.summary_label.setText("Run the analysis to see titration curves.")
        if MATPLOTLIB_OK and hasattr(self.canvas, "figure"):
            self.canvas.figure.clear()
            self.canvas.draw_idle()
        self.run_status.setText("Structure loaded. Set pH and press Run.")
        self.status.setText(f"Loaded {len(structure.atoms)} atoms from {Path(path).name}")

    # -- run --------------------------------------------------------------
    def _run(self) -> None:
        if self.structure is None:
            QMessageBox.information(self, "Protonation Lab", "Load a structure first.")
            return
        if self.worker is not None and self.worker.isRunning():
            QMessageBox.information(self, "Protonation Lab", "An analysis is already running.")
            return
        self.run_btn.setEnabled(False)
        self.run_status.setText("Running mean-field titration and Monte Carlo sampling…")
        self.status.setText("Running protonation analysis…")
        worker = AnalyzeWorker(self.structure, {
            "ph": self.ph.value(),
            "ionic_strength": self.ionic.value(),
            "temperature": self.temperature.value(),
            "seed": self.seed.value(),
            "mc_moves": self.mc_moves.value(),
        }, self)
        self.worker = worker
        worker.done.connect(self._done)
        worker.failed.connect(self._failed)
        worker.finished.connect(self._finished)
        worker.start()

    def _done(self, result: Dict[str, Any]) -> None:
        self.result = result
        self._populate_sites()
        self._populate_combo()
        self._update_report()
        self._plot()
        summary = core.summarize(result)
        self.run_status.setText(
            f"{summary['sites']} sites · pI {summary['pI']:.2f} · "
            f"{summary['near_ph']} near pH · {summary['warnings']} warning(s)"
        )
        self.summary_label.setText(
            f"pH {result['ph']:.2f} | I {result['ionic_strength']:.3f} M | "
            f"pI {result['pI']:.2f} | {len(result['sites'])} sites | "
            f"{result['model']}"
        )
        self.status.setText("Protonation analysis complete.")
        self.tabs.setCurrentIndex(1)

    def _failed(self, message: str) -> None:
        QMessageBox.warning(self, "Protonation Lab", message)
        self.run_status.setText("Analysis failed.")
        self.status.setText("Analysis failed.")

    def _finished(self) -> None:
        self.worker = None
        self.run_btn.setEnabled(True)

    def _populate_sites(self) -> None:
        self.site_table.setRowCount(0)
        if not self.result:
            return
        for index, site in enumerate(self.result["sites"]):
            row = self.site_table.rowCount()
            self.site_table.insertRow(row)
            residue = site["residue"]
            values = (
                residue.chain,
                residue.name,
                f"{residue.resseq}{residue.icode}",
                site["ref_name"],
                f"{site['pka_int']:.2f}",
                f"{site['pka_app']:.2f}" if site["pka_app"] == site["pka_app"] else "—",
                f"{site['protonation']:.2f}",
                f"{site.get('mc_protonation', 0):.2f}",
                site.get("state", ""),
                site.get("flag", ""),
            )
            for col, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setData(Qt.ItemDataRole.UserRole, index)
                self.site_table.setItem(row, col, item)
        self.site_table.resizeColumnsToContents()

    def _populate_combo(self) -> None:
        self.site_combo.blockSignals(True)
        self.site_combo.clear()
        if self.result:
            for index, site in enumerate(self.result["sites"]):
                residue = site["residue"]
                self.site_combo.addItem(
                    f"{residue.chain}:{residue.name}{residue.resseq}{residue.icode} "
                    f"{site['ref_name']}", index,
                )
            if self.result["sites"]:
                self.site_combo.setCurrentIndex(0)
        self.site_combo.blockSignals(False)

    def _selection_changed(self) -> None:
        rows = self.site_table.selectionModel().selectedRows()
        if not rows:
            return
        item = self.site_table.item(rows[0].row(), 0)
        if item is None:
            return
        index = item.data(Qt.ItemDataRole.UserRole)
        if index is not None:
            combo_index = self.site_combo.findData(index)
            if combo_index >= 0:
                self.site_combo.setCurrentIndex(combo_index)

    def _plot(self) -> None:
        if not MATPLOTLIB_OK or not hasattr(self.canvas, "figure") or not self.result:
            return
        fig = self.canvas.figure
        fig.clear()
        ax1 = fig.add_subplot(121)
        ax2 = fig.add_subplot(122)
        ph = self.result["ph_values"]
        net = self.result["net_charge"]
        ax1.plot(ph, net, color="#2563eb")
        ax1.axhline(0, color="#9ca3af", lw=0.8)
        ax1.set_title("Net charge")
        ax1.set_xlabel("pH")
        ax1.set_ylabel("charge (e)")
        index = self.site_combo.currentData()
        if index is not None and 0 <= index < len(self.result["sites"]):
            site = self.result["sites"][index]
            curve = self.result["curves"][index]
            ax2.plot(ph, curve, color="#0f766e")
            ax2.axhline(0.5, color="#9ca3af", lw=0.8)
            ax2.set_title(f"{site['residue'].label} {site['ref_name']}")
            ax2.set_xlabel("pH")
            ax2.set_ylabel("protonated fraction")
        else:
            ax2.text(0.5, 0.5, "No site selected", ha="center", va="center")
            ax2.axis("off")
        fig.tight_layout()
        self.canvas.draw_idle()

    def _update_report(self) -> None:
        if not self.result:
            self.report.setPlainText("No result.")
            return
        summary = core.summarize(self.result)
        lines = [
            "Protonation Lab result",
            "=======================",
            f"Structure        : {self.result['structure']}",
            f"pH               : {self.result['ph']:.2f}",
            f"Ionic strength   : {self.result['ionic_strength']:.3f} M",
            f"Temperature      : {self.result['temperature']:.2f} K",
            f"Seed             : {self.result['seed']}",
            f"Titratable sites : {summary['sites']}",
            f"Acidic/basic     : {summary['acidic']} / {summary['basic']}",
            f"Buried (>0.75)   : {summary['buried']}",
            f"Near pH          : {summary['near_ph']}",
            f"pI               : {summary['pI']:.2f}",
            f"Model            : {self.result['model']}",
            "",
            "Warnings",
            "--------",
        ]
        warnings = list(self.result.get("warnings") or [])
        lines += [f"- {item}" for item in warnings] if warnings else ["(none)"]
        lines += [
            "",
            "The exported protonated PDB preserves coordinates and existing "
            "hydrogens; it adds state REMARKs and His state names. It does not "
            "rebuild missing hydrogens.",
        ]
        self.report.setPlainText("\n".join(lines))

    # -- export -----------------------------------------------------------
    def _default_export(self, suffix: str) -> Optional[Path]:
        if not self.result or self.structure is None:
            QMessageBox.information(self, "Protonation Lab", "Run the analysis first.")
            return None
        base = Path(self.result["structure"])
        path, _ = QFileDialog.getSaveFileName(
            self, "Export", str(base.with_name(base.stem + suffix)),
            "CSV (*.csv);;JSON (*.json);;PDB (*.pdb);;All files (*)",
        )
        return Path(path) if path else None

    def _export_csv(self) -> None:
        path = self._default_export("_protonation.csv")
        if path is None:
            return
        try:
            core.export_csv(self.result, path)
            self.status.setText(f"CSV exported: {path}")
        except Exception as exc:
            QMessageBox.warning(self, "Protonation Lab", str(exc))

    def _export_json(self) -> None:
        path = self._default_export("_protonation.json")
        if path is None:
            return
        try:
            core.export_json(self.result, path)
            self.status.setText(f"JSON exported: {path}")
        except Exception as exc:
            QMessageBox.warning(self, "Protonation Lab", str(exc))

    def _export_pdb(self) -> None:
        path = self._default_export("_protonated.pdb")
        if path is None:
            return
        try:
            core.export_protonated_pdb(self.structure, self.result, path)
            self.status.setText(f"Protonated PDB exported: {path}")
        except Exception as exc:
            QMessageBox.warning(self, "Protonation Lab", str(exc))
