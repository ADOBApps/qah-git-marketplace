# Protein Protonation States at Defined pH: Continuum Electrostatics and Monte Carlo Titration

### Method and Software Specification

**Author:** Acxel Orozco  
**Version:** 0.1 — scientific review draft  
**Date:** 2026-11-09  
**Document type:** method and software specification  
**Keywords:** protein pKa; protonation states; Poisson–Boltzmann; Monte Carlo titration; metalloprotein; laccase  
**Status:** specification; no performance or accuracy claim is made until the validation plan is complete.

---

## Abstract

This document specifies a structure-based method for predicting the protonation states, pKa values and pH-dependent charge of proteins at a user-defined pH. The method combines a finite-difference Poisson–Boltzmann (PB) electrostatic model with Monte Carlo (MC) sampling of protonation and tautomeric microstates. It is intended for static structures and structural ensembles, not for replacing molecular dynamics. The output is a set of residue-level pKa values, protonation probabilities, dominant microstates, titration curves, and a protonated structure suitable for subsequent simulation or mechanistic study. The specification defines the physical model, numerical defaults, residue and cofactor states, validation criteria and reproducibility requirements. A multicopper oxidase (laccase) is used as a demanding application case because it combines buried ionizable residues, four copper centres, coupled protonation and pH-dependent activity.

---

## 1. Scope

### 1.1 In scope

- Proteins, protein–ligand complexes and metalloproteins with a known three-dimensional structure.
- Standard ionizable residues: Asp, Glu, His, Lys, Cys, Tyr, Arg, N- and C-termini.
- Histidine tautomers and alternative side-chain conformers.
- Metal-bound water/hydroxide states and user-defined cofactor states.
- pH range 0–14, ionic strength 0–1 M, temperature 273–350 K.
- Prediction of:
  - residue pKa values;
  - protonation probabilities at a specified pH;
  - dominant protonation microstates;
  - net charge and isoelectric point;
  - protonated coordinate files.

### 1.2 Out of scope

- Explicit solvent molecular dynamics, pressure control, or conformational dynamics.
- Direct simulation of chemical reactions or electron transfer.
- Prediction of pH-dependent kinetics without a separate kinetic or QM/MM model.
- Blind prediction for structures with unresolved catalytic residues, metals or cofactors without user-provided states.
- Treatment of non-equilibrium proton transport.

The method is a **protonation-state model**, not a molecular dynamics engine. Constant-pH MD, QM/MM and free-energy methods are complementary, not replaced by this specification.

---

## 2. Scientific model

### 2.1 Protonation equilibrium

For a single ionizable site:

\[
\mathrm{pH} = \mathrm{p}K_a + \log_{10}\frac{[\mathrm{A^-}]}{[\mathrm{HA}]}
\]

and the protonated fraction is

\[
f_{\mathrm{HA}} = \frac{1}{1 + 10^{\mathrm{pH}-\mathrm{p}K_a}}.
\]

In a protein, the apparent pKa of a site is shifted from its model-compound value by desolvation, hydrogen bonding, charge–charge interactions and conformational strain.

### 2.2 Continuum electrostatics

The electrostatic potential \(\phi(\mathbf r)\) is obtained from the nonlinear Poisson–Boltzmann equation

\[
\nabla\cdot\left[\varepsilon(\mathbf r)\nabla\phi(\mathbf r)\right]
- \bar{\kappa}^2(\mathbf r)\sinh\phi(\mathbf r)
= -4\pi\rho_f(\mathbf r),
\]

where \(\varepsilon(\mathbf r)\) is the dielectric permittivity, \(\rho_f\) is the fixed charge density and \(\bar{\kappa}\) is the ionic screening parameter. The linearized form is used for the default solver; the nonlinear form is available for highly charged systems.

The protein interior is treated as a low-dielectric region, the solvent as a high-dielectric continuum, and mobile ions as a Debye–Hückel atmosphere outside the molecular surface. The numerical solution uses a finite-difference grid with dielectric and ion-accessibility maps, successive over-relaxation or an incomplete-Cholesky conjugate-gradient solver, and focusing boundaries.

### 2.3 Site-energy model

Each titratable site \(i\) has a set of allowed states \(x_i\): protonated/deprotonated, neutral/anionic/cationic, or tautomeric alternatives. For a microstate \(x\),

\[
G(x) = \sum_i x_i G_i^0
+ \frac{1}{2}\sum_{i\neq j} W_{ij}x_i x_j
+ G_{\mathrm{conf}}(x),
\]

where:

- \(G_i^0\) contains the intrinsic protonation free energy, including the model-compound pKa and the site’s desolvation/background electrostatics;
- \(W_{ij}\) is the pairwise electrostatic interaction between sites;
- \(G_{\mathrm{conf}}\) accounts for side-chain rotamer or tautomer strain.

The pH enters through the proton chemical potential:

\[
G_i^0(\mathrm{pH}) = G_i^{0,\mathrm{ref}}
+ k_BT\ln 10\,(\mathrm{pH}-\mathrm{p}K_{a,i}^{\mathrm{ref}}).
\]

The probability of a microstate is

\[
P(x) = \frac{e^{-\beta G(x)}}{Z},
\qquad
Z = \sum_x e^{-\beta G(x)}.
\]

For systems with many sites, the sum is evaluated by Monte Carlo rather than exact enumeration.

### 2.4 Monte Carlo titration

The default sampler uses Metropolis Monte Carlo over protonation, tautomer and rotamer states:

1. Choose a titratable site or coupled group.
2. Propose a state change.
3. Compute the energy change \(\Delta G\).
4. Accept with probability \(\min(1,e^{-\beta\Delta G})\).

Move classes:

- single-site protonation/deprotonation;
- histidine tautomer exchange;
- coupled group moves for metal-bound waters/hydroxides;
- optional side-chain rotamer moves.

Sampling is performed at each requested pH. Equilibration and production phases are separated. Convergence is assessed by block averaging, independent-seed reproducibility and stability of the titration curve.

### 2.5 Macroscopic observables

From the sampled microstates:

- site protonation probability \(f_i(\mathrm{pH})\);
- apparent pKa from a Henderson–Hasselbalch fit to \(f_i(\mathrm{pH})\);
- net protein charge

\[
Q(\mathrm{pH}) = \sum_i q_i f_i(\mathrm{pH});
\]

- isoelectric point from \(Q(\mathrm{pH})=0\);
- dominant microstates and their populations;
- pairwise coupling and correlated protonation.

---

## 3. Structure and state definitions

### 3.1 Input requirements

- PDB or mmCIF coordinate file.
- All catalytic metals and cofactors explicitly present.
- Crystallographic or modelled waters retained when they are part of a protonation network.
- Alternate locations resolved explicitly or by occupancy.
- Missing atoms completed and reported; no silent rebuilding.
- Disulfides and terminal states assigned before titration.

### 3.2 Standard residue states

| Residue | States modelled |
|---|---|
| Asp | neutral COOH / anionic COO⁻ |
| Glu | neutral COOH / anionic COO⁻ |
| His | HID, HIE, HIP (two tautomers and cationic) |
| Lys | neutral NH₂ / cationic NH₃⁺ |
| Cys | neutral SH / anionic S⁻ |
| Tyr | neutral OH / anionic O⁻ |
| Arg | cationic guanidinium (fixed by default) |
| N-terminus | neutral / cationic |
| C-terminus | neutral / anionic |

Reference model-compound pKa values are parameters, not constants. They must be documented in the parameter file and may be recalibrated.

### 3.3 Metals and cofactors

Metals are represented as explicit charge/radius sites with user-defined oxidation and ligand states. A metal-bound water may be modelled as:

- aqua, \(\mathrm{Cu(II)-OH_2}\);
- hydroxo, \(\mathrm{Cu(II)-OH^-}\);
- optionally coupled to a nearby acid/base residue.

Cofactor states are declared explicitly. The model does not infer redox potentials or protonation–redox coupling unless the user supplies the state energies.

---

## 4. Numerical protocol

### 4.1 Default parameters

| Parameter | Default | Notes |
|---|---:|---|
| Temperature | 298.15 K | configurable |
| Ionic strength | 0.15 M | configurable, 0–1 M |
| Protein dielectric | 4.0 | sensitivity range 2–6 |
| Solvent dielectric | 78.5 | 298 K |
| Grid spacing | 0.5 Å | 1.0 Å allowed for screening |
| Box padding | 20 Å | minimum 15 Å |
| Molecular surface probe | 1.4 Å | solvent-accessible surface |
| PB convergence | \(10^{-4}\,k_BT/e\) | stricter for publication |
| pH grid | 0–14, step 0.1 | adaptive refinement near transitions |
| MC equilibration | 20% of moves | minimum \(10^5\) moves |
| MC production | \(10^6\) moves | per pH and seed |
| Random seed | recorded | required for reproducibility |

All values are configurable and must be reported with published results.

### 4.2 Electrostatic workflow

1. Parse and validate the structure.
2. Assign residue, metal and cofactor templates.
3. Build the dielectric and ion-accessibility maps.
4. Solve the PB equation for reference states.
5. Compute intrinsic pKa values and the pairwise interaction matrix.
6. Run MC at each pH.
7. Fit titration curves and extract observables.
8. Write protonated coordinates and reports.

Caching: PB solutions for unchanged conformers and interaction matrices are cached across pH points.

### 4.3 Performance targets

For a laccase-sized system (approximately 5,000 atoms, four Cu centres, around 100 titratable sites):

- structure parsing < 1 s;
- one PB solve < 60 s on a four-core laptop at 1.0 Å screening resolution;
- full pH curve < 10 min with caching and multiprocessing;
- optional native acceleration only if profiling exceeds these targets.

These are design targets, not guarantees. They must be measured on named reference hardware.

---

## 5. Outputs

### 5.1 Tables

- residue, chain, residue number, state, model pKa, apparent pKa, protonation at target pH, confidence/flag;
- metal/cofactor states and coupled groups;
- microstate populations;
- net charge and pI.

### 5.2 Structures

- protonated PDB/mmCIF at the requested pH;
- optional alternate-state structures for the dominant microstates;
- a machine-readable state map.

### 5.3 Plots and reports

- per-residue titration curves;
- total charge vs pH;
- microstate population vs pH;
- warnings for:
  - residues near the target pH;
  - buried charges;
  - unsatisfied hydrogen bonds;
  - metal centres with incomplete coordination;
  - missing or ambiguous atoms.

---

## 6. Validation and acceptance criteria

### 6.1 Analytical tests

- Single ionizable group reproduces Henderson–Hasselbalch.
- Two coupled sites reproduce the exact two-site partition function.
- Born-ion solvation free energy reproduces the analytical result.
- Net charge is zero at the computed pI within numerical tolerance.

### 6.2 Numerical tests

- Grid-spacing convergence: pKa change < 0.2 units between 0.5 and 1.0 Å for solvent-exposed sites.
- Box-size convergence: pKa change < 0.1 units with 15 vs 25 Å padding.
- Dielectric sensitivity reported for \(\varepsilon_p = 2, 4, 6\).
- Independent-seed reproducibility: pKa standard deviation < 0.1 units.
- MC convergence: block averages stable within 0.1 pKa units.

### 6.3 Experimental benchmarks

- PKAD or PKAD-2 experimental pKa set.
- Staphylococcal nuclease variants, lysozyme and RNase A as established test systems.
- Laccase pH–activity and available residue pKa data.

### 6.4 Acceptance criteria

For a method paper, report at minimum:

- overall RMSE and mean error against the benchmark;
- performance for solvent-exposed, buried and coupled sites separately;
- titration-curve RMSE;
- pI error;
- comparison with at least two established methods (for example PROPKA3, H++, PypKa, DelPhiPKa or MCCE);
- laccase case study showing pH-dependent T2/T3 states and qualitative agreement with the experimental pH–activity trend.

A target of approximately 1 pKa unit RMSE for solvent-exposed residues is realistic; buried, coupled and metal-bound sites require explicit discussion and should not be presented as uniformly accurate.

---

## 7. Limitations

- The method assumes a fixed structure or a supplied conformational ensemble; it does not sample protein conformational change.
- Continuum electrostatics with a single protein dielectric is an approximation; results depend on dielectric, radii and charges.
- Metal centres and cofactors require careful user-defined states; automatic assignment is not assumed to be correct.
- Protonation–redox coupling is not predicted unless state energies are supplied.
- pKa values near the target pH and in buried sites carry larger uncertainty.
- The model does not replace experimental measurement, constant-pH MD or QM/MM for mechanism.

---

## 8. Software requirements

- Pure Python and NumPy/SciPy implementation, with no mandatory compiled extension.
- Deterministic execution with recorded seed.
- Modular separation of:
  - structure I/O and validation;
  - residue/cofactor templates;
  - electrostatics;
  - Monte Carlo titration;
  - analysis and reporting;
  - user interface.
- Versioned parameter files and machine-readable output.
- All numerical defaults recorded in the output report.
- Optional native acceleration must preserve identical results within a defined tolerance and remain optional.

---

## 9. Reproducibility and publication checklist

- Archive input structures, protonation states, parameter files and random seeds.
- Report software version, grid, dielectric, ionic strength, temperature and MC settings.
- Provide the pKa table and titration curves as supplementary data.
- Provide the laccase input and output as a worked example.
- State limitations and failure modes explicitly.
- Include a conflict-of-interest and data-availability statement in any publication.

---

## References

1. Honig B, Nicholls A. Classical electrostatics in biology and chemistry. *Science*. 1995;268(5214):1144–1149. doi:10.1126/science.7761829.
2. Nicholls A, Honig B. A rapid finite difference algorithm, utilizing successive over-relaxation to solve the Poisson–Boltzmann equation. *J Comput Chem*. 1991;12(4):435–445. doi:10.1002/jcc.540120405.
3. Bashford D, Karplus M. pKa's of ionizable groups in proteins: atomic detail from a continuum electrostatic model. *Biochemistry*. 1990;29(44):10219–10225. doi:10.1021/bi00496a010.
4. Alexov EG, Gunner MR. Incorporating protein conformational flexibility into the calculation of pH-dependent protein properties. *Biophys J*. 1997;72(5):2075–2093. doi:10.1016/S0006-3495(97)78851-9.
5. Georgescu RE, Alexov EG, Gunner MR. Combining conformational flexibility and continuum electrostatics for calculating pKa's in proteins. *Biophys J*. 2002;83(4):1731–1748. doi:10.1016/S0006-3495(02)73940-4.
6. Olsson MHM, Søndergaard CR, Rostkowski M, Jensen JH. PROPKA3: consistent treatment of internal and surface residues in empirical pKa predictions. *J Chem Theory Comput*. 2011;7(2):525–537. doi:10.1021/ct100578z.
7. Anandakrishnan R, Aguilar B, Onufriev AV. H++ 3.0: automating pK prediction and the preparation of biomolecular structures for atomistic molecular modeling and simulations. *Nucleic Acids Res*. 2012;40(W1):W537–W541. doi:10.1093/nar/gks375.
8. Wang L, Zhang M, Alexov E. DelPhiPKa web server: predicting pKa of proteins, RNAs and DNAs. *Bioinformatics*. 2016;32(4):614–615. doi:10.1093/bioinformatics/btv607.
9. Reis PBPS, Vila-Viçosa D, Rocchia W, Machuqueiro M. PypKa: a flexible Python module for Poisson–Boltzmann-based pKa calculations. *J Chem Inf Model*. 2020;60(10):4442–4448. doi:10.1021/acs.jcim.0c00718.
10. Wei W, Hogues H, Sulea T. Comparative performance of high-throughput methods for protein pKa predictions. *J Chem Inf Model*. 2023;63(16):5169–5181. doi:10.1021/acs.jcim.3c00165.
11. Pahari S, Sun L, Alexov E. PKAD: a database of experimentally measured pKa values of ionizable groups in proteins. *Database (Oxford)*. 2019;2019:baz024. doi:10.1093/database/baz024.
12. Schutz CN, Warshel A. What are the dielectric “constants” of proteins and how to validate electrostatic models? *Proteins*. 2001;44(4):400–417. doi:10.1002/prot.1106.
13. Sitkoff D, Sharp KA, Honig B. Accurate calculation of hydration free energies using macroscopic solvent models. *J Phys Chem*. 1994;98(7):1978–1988. doi:10.1021/j100058a043.
14. Mongan J, Case DA, McCammon JA. Constant pH molecular dynamics in generalized Born implicit solvent. *J Comput Chem*. 2004;25(16):2038–2048. doi:10.1002/jcc.20139.
15. Khandogin J, Brooks CL III. Constant pH molecular dynamics with proton tautomerism. *Biophys J*. 2005;89(1):141–157. doi:10.1529/biophysj.105.061341.
16. Wallace JA, Shen JK. Continuous constant pH molecular dynamics in explicit solvent with pH-based replica exchange. *J Chem Theory Comput*. 2011;7(8):2617–2629. doi:10.1021/ct200146j.
17. Swails JM, York DM, Roitberg AE. Constant pH replica exchange molecular dynamics in explicit solvent using discrete protonation states: implementation, testing, and validation. *J Chem Theory Comput*. 2014;10(3):1341–1352. doi:10.1021/ct401042b.
18. Martins de Oliveira V, Liu R, Shen J. Constant pH molecular dynamics simulations: current status and recent applications. *Curr Opin Struct Biol*. 2022;77:102498. doi:10.1016/j.sbi.2022.102498.
19. Piontek K, Antorini M, Choinowski T. Crystal structure of a laccase from the fungus *Trametes versicolor* at 1.90-Å resolution containing a full complement of coppers. *J Biol Chem*. 2002;277(40):37663–37669. doi:10.1074/jbc.M204571200.
20. Solomon EI, Sundaram UM, Machonkin TE. Multicopper oxidases and oxygenases. *Chem Rev*. 1996;96(7):2563–2606. doi:10.1021/cr950046o.
21. Jones SM, Solomon EI. Electron transfer and reaction mechanism of laccases. *Cell Mol Life Sci*. 2015;72(5):869–883. doi:10.1007/s00018-014-1826-6.
22. Xu F. Effects of redox potential and hydroxide inhibition on the pH activity profile of fungal laccases. *J Biol Chem*. 1997;272(2):924–928. doi:10.1074/jbc.272.2.924.
23. Janusz G, Pawlik A, Świderska-Burek U, et al. Laccase properties, physiological functions, and evolution. *Int J Mol Sci*. 2020;21(3):966. doi:10.3390/ijms21030966.
