"""Core protonation-state model for Protonation Lab.

Pure-Python structure parsing, solvent accessibility, screened continuum
electrostatics, mean-field titration and Monte Carlo microstate sampling.

This v0.1 implementation uses an analytic screened-Coulomb/distance-dependent
dielectric model. A finite-difference Poisson-Boltzmann grid solver is the next
refinement described in the specification.

GPL-3.0-or-later.
"""

from __future__ import annotations

import csv
import json
import math
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None  # type: ignore

try:
    from scipy.spatial import cKDTree
except Exception:  # pragma: no cover
    cKDTree = None  # type: ignore

# model-compound reference pKa values (parameters, not universal constants)
REFERENCE_PKA = {
    "ASP": 3.9,
    "GLU": 4.3,
    "HIS": 6.0,
    "LYS": 10.5,
    "CYS": 8.3,
    "TYR": 10.1,
    "ARG": 12.5,
    "NTERM": 8.0,
    "CTERM": 3.1,
}

STANDARD = {
    "ALA", "ARG", "ASN", "ASP", "CYS", "GLN", "GLU", "GLY", "HIS", "ILE",
    "LEU", "LYS", "MET", "PHE", "PRO", "SER", "THR", "TRP", "TYR", "VAL",
    "ASH", "GLH", "HID", "HIE", "HIP", "CYX", "CYM", "LYN",
}
WATER = {"HOH", "WAT", "H2O", "DOD"}
BACKBONE = {"N", "CA", "C", "O", "OXT", "H", "HA", "H1", "H2", "H3"}
VDW = {
    "H": 1.20, "C": 1.70, "N": 1.55, "O": 1.52, "F": 1.47, "P": 1.80,
    "S": 1.80, "CL": 1.75, "BR": 1.85, "I": 1.98, "B": 1.92, "SI": 2.10,
    "NA": 2.27, "K": 2.75, "MG": 1.73, "CA": 2.31, "ZN": 1.39, "FE": 1.80,
    "CU": 1.40, "MN": 1.79, "NI": 1.63, "CO": 1.67,
}
METAL_CHARGE = {
    "CU": 2.0, "ZN": 2.0, "FE": 2.0, "MN": 2.0, "MG": 2.0, "CA": 2.0,
    "NI": 2.0, "CO": 2.0, "NA": 1.0, "K": 1.0, "CL": -1.0,
}
RT_KCAL = 0.592  # kcal/mol at 298.15 K
COULOMB = 332.0637  # kcal A / mol / e^2
PROBE = 1.4
SPHERE_POINTS = 92


@dataclass
class Atom:
    name: str
    resname: str
    chain: str
    resseq: int
    icode: str
    x: float
    y: float
    z: float
    occupancy: float
    element: str
    hetero: bool = False

    @property
    def pos(self):
        return np.array([self.x, self.y, self.z], dtype=float)


@dataclass
class Residue:
    name: str
    chain: str
    resseq: int
    icode: str
    atoms: Dict[str, Atom] = field(default_factory=dict)
    hetero: bool = False

    @property
    def key(self) -> Tuple[str, int, str]:
        return (self.chain, self.resseq, self.icode)

    @property
    def label(self) -> str:
        return f"{self.chain}:{self.name}{self.resseq}{self.icode}"


@dataclass
class Structure:
    path: Path
    atoms: List[Atom] = field(default_factory=list)
    residues: List[Residue] = field(default_factory=list)
    raw_lines: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    format: str = "pdb"

    def residue_map(self) -> Dict[Tuple[str, int, str], Residue]:
        return {residue.key: residue for residue in self.residues}


def _element_from_name(name: str) -> str:
    clean = "".join(ch for ch in name if ch.isalpha())
    if not clean:
        return "C"
    # In PDB files the element column is normally present. When it is absent,
    # atom names such as CA/CB/CG are carbons, not calcium.
    return clean[0].upper()


def _sanitize_element(value: str, name: str) -> str:
    value = (value or "").strip().upper()
    if value in VDW:
        return value
    return _element_from_name(name)


def _new_atom(serial, name, altloc, resname, chain, resseq, icode,
              x, y, z, occupancy, element, hetero) -> Atom:
    chain_value = (chain or "").strip()
    if chain_value in ("?", "."):
        chain_value = "_"
    icode_value = (icode or "").strip()
    if icode_value in ("?", "."):
        icode_value = ""
    return Atom(
        name=name.strip(), resname=resname.strip().upper(), chain=chain_value or "_",
        resseq=int(resseq or 0), icode=icode_value,
        x=float(x), y=float(y), z=float(z),
        occupancy=float(occupancy or 1.0),
        element=_sanitize_element(element, name), hetero=hetero,
    )


def parse_pdb(path: Path) -> Structure:
    path = Path(path)
    text = path.read_text(encoding="utf-8", errors="replace")
    structure = Structure(path=path, raw_lines=text.splitlines())
    residues: Dict[Tuple[str, int, str], Residue] = {}
    model_seen = False
    for line in text.splitlines():
        record = line[:6].strip().upper()
        if record == "MODEL":
            if model_seen:
                break
            model_seen = True
            continue
        if record == "ENDMDL" and model_seen:
            break
        if record not in ("ATOM", "HETATM"):
            continue
        try:
            serial = int(line[6:11] or 0)
            name = line[12:16]
            altloc = line[16:17].strip()
            resname = line[17:20]
            chain = line[21:22]
            resseq = line[22:26]
            icode = line[26:27]
            x = float(line[30:38])
            y = float(line[38:46])
            z = float(line[46:54])
            occupancy = float(line[54:60] or 1.0)
            element = line[76:78] if len(line) >= 78 else ""
        except (ValueError, IndexError):
            continue
        hetero = record == "HETATM"
        atom = _new_atom(serial, name, altloc, resname, chain, resseq, icode,
                         x, y, z, occupancy, element, hetero)
        key = (atom.chain, atom.resseq, atom.icode)
        residue = residues.get(key)
        if residue is None:
            residue = Residue(atom.resname, atom.chain, atom.resseq, atom.icode, hetero=hetero)
            residues[key] = residue
            structure.residues.append(residue)
        existing = residue.atoms.get(atom.name)
        if existing is None or atom.occupancy >= existing.occupancy:
            residue.atoms[atom.name] = atom
    structure.atoms = [atom for residue in structure.residues for atom in residue.atoms.values()]
    return structure


def parse_mmcif(path: Path) -> Structure:
    """Minimal mmCIF atom_site parser (single model, first block)."""
    path = Path(path)
    text = path.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    structure = Structure(path=path, raw_lines=lines, format="mmcif")
    tags: List[str] = []
    start = None
    for index, line in enumerate(lines):
        if line.strip().lower() == "loop_":
            tags = []
            j = index + 1
            while j < len(lines) and lines[j].strip().startswith("_"):
                tags.append(lines[j].strip())
                j += 1
            if any(tag.startswith("_atom_site.") for tag in tags):
                start = j
                break
    if start is None:
        raise ValueError("No _atom_site loop found in mmCIF.")
    names = [tag.split(".", 1)[1] for tag in tags]

    def value(row, *keys):
        for key in keys:
            if key in names:
                idx = names.index(key)
                return row[idx] if idx < len(row) else ""
        return ""

    residues: Dict[Tuple[str, int, str], Residue] = {}
    for line in lines[start:]:
        stripped = line.strip()
        if not stripped or stripped == "#" or stripped.lower() == "loop_" or stripped.startswith("_"):
            break
        try:
            import shlex
            row = shlex.split(stripped)
        except Exception:
            row = stripped.split()
        if not row:
            continue
        group = value(row, "group_PDB").upper()
        if group not in ("ATOM", "HETATM"):
            continue
        try:
            atom = _new_atom(
                0, value(row, "label_atom_id", "auth_atom_id"),
                value(row, "label_alt_id"), value(row, "label_comp_id", "auth_comp_id"),
                value(row, "auth_asym_id", "label_asym_id"),
                value(row, "auth_seq_id", "label_seq_id"),
                value(row, "pdbx_PDB_ins_code"),
                float(value(row, "Cartn_x")), float(value(row, "Cartn_y")),
                float(value(row, "Cartn_z")), float(value(row, "occupancy") or 1.0),
                value(row, "type_symbol"), group == "HETATM",
            )
        except Exception:
            continue
        key = (atom.chain, atom.resseq, atom.icode)
        residue = residues.get(key)
        if residue is None:
            residue = Residue(atom.resname, atom.chain, atom.resseq, atom.icode, hetero=atom.hetero)
            residues[key] = residue
            structure.residues.append(residue)
        existing = residue.atoms.get(atom.name)
        if existing is None or atom.occupancy >= existing.occupancy:
            residue.atoms[atom.name] = atom
    structure.atoms = [atom for residue in structure.residues for atom in residue.atoms.values()]
    return structure


def parse_structure(path: Path) -> Structure:
    suffix = Path(path).suffix.lower()
    if suffix in (".cif", ".mmcif"):
        return parse_mmcif(path)
    return parse_pdb(path)


def _sidechain_atoms(residue: Residue) -> Dict[str, Atom]:
    atoms = {name: atom for name, atom in residue.atoms.items() if name not in BACKBONE}
    return atoms or dict(residue.atoms)


def _center(residue: Residue, names: Sequence[str]) -> Optional[Any]:
    coords = [residue.atoms[name].pos for name in names if name in residue.atoms]
    if not coords:
        return None
    return np.mean(np.array(coords), axis=0)


def _sphere_points(count: int = SPHERE_POINTS) -> Any:
    indices = np.arange(count, dtype=float) + 0.5
    phi = np.arccos(1.0 - 2.0 * indices / count)
    theta = np.pi * (1.0 + 5.0 ** 0.5) * indices
    return np.column_stack((
        np.cos(theta) * np.sin(phi),
        np.sin(theta) * np.sin(phi),
        np.cos(phi),
    ))


def sasa_atom_fractions(structure: Structure) -> Dict[str, float]:
    """Shrake-Rupley accessible fraction per atom (0..1)."""
    if np is None:
        return {}
    heavy = [
        atom for atom in structure.atoms
        if atom.element != "H" and atom.resname not in WATER
    ]
    if not heavy:
        return {}
    coords = np.array([atom.pos for atom in heavy])
    radii = np.array([VDW.get(atom.element, 1.70) for atom in heavy])
    if cKDTree is not None:
        tree = cKDTree(coords)
        neighbours = tree.query_ball_point(coords, radii + PROBE + max(VDW.values()))
    else:
        neighbours = []
        for i in range(len(coords)):
            distances = np.linalg.norm(coords - coords[i], axis=1)
            neighbours.append(np.where(distances <= radii[i] + PROBE + max(VDW.values()))[0])
    points = _sphere_points()
    fractions: Dict[str, float] = {}
    for i, atom in enumerate(heavy):
        ids = list(neighbours[i]) if len(neighbours[i]) else []
        ids = [j for j in ids if j != i]
        if not ids:
            fractions[f"{atom.chain}:{atom.resseq}:{atom.icode}:{atom.name}"] = 1.0
            continue
        sample = coords[i] + (radii[i] + PROBE) * points
        other = coords[ids]
        other_r = radii[ids] + PROBE
        distances = np.linalg.norm(sample[:, None, :] - other[None, :, :], axis=2)
        accessible = ~np.any(distances < other_r[None, :], axis=1)
        fractions[f"{atom.chain}:{atom.resseq}:{atom.icode}:{atom.name}"] = float(accessible.mean())
    return fractions


def _burial_for_residue(residue: Residue, fractions: Dict[str, float]) -> float:
    atoms = _sidechain_atoms(residue)
    values = [
        fractions.get(f"{residue.chain}:{residue.resseq}:{residue.icode}:{name}", 1.0)
        for name in atoms
    ]
    if not values:
        return 0.0
    return max(0.0, min(1.0, 1.0 - float(np.mean(values))))


def _kappa(ionic_strength: float) -> float:
    return 0.329 * math.sqrt(max(0.0, float(ionic_strength)))


def _epsilon_eff(distance: float) -> float:
    distance = max(1.5, float(distance))
    return 20.0 + 58.0 * (1.0 - math.exp(-distance / 10.0))


def _coulomb_kT(q1: float, q2: float, distance: float, kappa: float,
                rt: float = RT_KCAL) -> float:
    distance = max(1.5, float(distance))
    value = COULOMB * q1 * q2 / (_epsilon_eff(distance) * distance)
    if kappa > 0:
        value *= math.exp(-kappa * distance)
    return value / max(1e-6, rt)


def _coulomb_pka(q: float, distance: float, kappa: float,
                 rt: float = RT_KCAL) -> float:
    return _coulomb_kT(1.0, q, distance, kappa, rt) / math.log(10.0)


def _his_state(residue: Residue) -> str:
    if "HD1" in residue.atoms and "HE2" not in residue.atoms:
        return "HID"
    if "HE2" in residue.atoms and "HD1" not in residue.atoms:
        return "HIE"
    return "HIE"


def _disulfides(structure: Structure) -> set:
    cysteines = [r for r in structure.residues if r.name.upper() in ("CYS", "CYX", "CYM")]
    result = set()
    for i, a in enumerate(cysteines):
        if "SG" not in a.atoms:
            continue
        for b in cysteines[i + 1:]:
            if "SG" not in b.atoms:
                continue
            if np.linalg.norm(a.atoms["SG"].pos - b.atoms["SG"].pos) < 2.5:
                result.add(a.key)
                result.add(b.key)
    return result


def build_sites(structure: Structure) -> Tuple[List[Dict[str, Any]], List[str]]:
    warnings: List[str] = []
    sites: List[Dict[str, Any]] = []
    disulfides = _disulfides(structure)

    def add_site(residue: Residue, kind: str, names: Sequence[str], ref_name: str,
                 state_name: str = "", atom_label: str = "") -> None:
        center = _center(residue, names)
        if center is None:
            warnings.append(f"{residue.label}: missing atoms for {ref_name}; skipped")
            return
        ref = REFERENCE_PKA[ref_name]
        sign = 1 if kind == "acid" else -1
        q_dep = -1.0 if kind == "acid" else 0.0
        if ref_name in ("HIS", "LYS", "ARG", "NTERM"):
            q_dep = 0.0
        sites.append({
            "id": f"{residue.chain}:{residue.resseq}{residue.icode}:{ref_name}",
            "kind": kind,
            "ref_name": ref_name,
            "ref": ref,
            "sign": sign,
            "q_dep": q_dep,
            "center": center,
            "residue": residue,
            "residue_key": residue.key,
            "state_name": state_name,
            "atom_label": atom_label or ",".join(names),
            "burial": 0.0,
            "pka_int": ref,
            "pka_app": float("nan"),
            "protonation": 0.5,
            "flag": "",
        })

    for residue in structure.residues:
        name = residue.name.upper()
        if name.startswith("HIS") or name in ("HID", "HIE", "HIP"):
            add_site(residue, "base", ("ND1", "NE2"), "HIS", _his_state(residue), "ND1/NE2")
            continue
        if name in ("ASP", "ASH"):
            add_site(residue, "acid", ("OD1", "OD2"), "ASP", name, "OD1/OD2")
        elif name in ("GLU", "GLH"):
            add_site(residue, "acid", ("OE1", "OE2"), "GLU", name, "OE1/OE2")
        elif name in ("LYS", "LYN"):
            add_site(residue, "base", ("NZ",), "LYS", name, "NZ")
        elif name in ("CYS", "CYX", "CYM"):
            if residue.key in disulfides or name == "CYX":
                warnings.append(f"{residue.label}: disulfide-bridged cysteine excluded from titration")
                continue
            add_site(residue, "acid", ("SG",), "CYS", name, "SG")
        elif name == "TYR":
            add_site(residue, "acid", ("OH",), "TYR", name, "OH")
        elif name == "ARG":
            add_site(residue, "base", ("CZ", "NH1", "NH2", "NE"), "ARG", name, "CZ/NH1/NH2")
        elif name in STANDARD or name in ("PRO",):
            continue

    # chain termini
    by_chain: Dict[str, List[Residue]] = {}
    for residue in structure.residues:
        if residue.hetero or residue.name.upper() in WATER:
            continue
        if residue.name.upper() in STANDARD:
            by_chain.setdefault(residue.chain, []).append(residue)
    for chain, residues in by_chain.items():
        if not residues:
            continue
        first = residues[0]
        if "N" in first.atoms:
            site = {
                "id": f"{chain}:{first.resseq}:NTERM", "kind": "base",
                "ref_name": "NTERM", "ref": REFERENCE_PKA["NTERM"], "sign": -1,
                "q_dep": 0.0, "center": first.atoms["N"].pos, "residue": first,
                "residue_key": first.key, "state_name": "NTERM",
                "atom_label": "N", "burial": 0.0,
                "pka_int": REFERENCE_PKA["NTERM"], "pka_app": float("nan"),
                "protonation": 0.5, "flag": "",
            }
            sites.append(site)
        last = residues[-1]
        if "C" in last.atoms:
            site = {
                "id": f"{chain}:{last.resseq}:CTERM", "kind": "acid",
                "ref_name": "CTERM", "ref": REFERENCE_PKA["CTERM"], "sign": 1,
                "q_dep": -1.0, "center": last.atoms["C"].pos, "residue": last,
                "residue_key": last.key, "state_name": "CTERM",
                "atom_label": "C", "burial": 0.0,
                "pka_int": REFERENCE_PKA["CTERM"], "pka_app": float("nan"),
                "protonation": 0.5, "flag": "",
            }
            sites.append(site)
    return sites, warnings


def _fixed_charges(structure: Structure, sites: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    charges: List[Dict[str, Any]] = []
    site_ids = {site["id"] for site in sites}
    for residue in structure.residues:
        if residue.hetero and residue.name.upper() not in STANDARD:
            element = ""
            for atom in residue.atoms.values():
                if atom.element in METAL_CHARGE:
                    element = atom.element
                    break
            if element:
                center = _center(residue, list(residue.atoms))
                if center is not None:
                    charges.append({"q": METAL_CHARGE[element], "pos": center,
                                    "label": residue.label, "site": ""})
    # Deprotonated reference charge of every titratable site plus fixed Arg
    for site in sites:
        charges.append({
            "q": float(site["q_dep"]),
            "pos": site["center"],
            "label": site["id"],
            "site": site["id"],
        })
    return charges


def _interaction_matrix(sites: Sequence[Dict[str, Any]], kappa: float,
                        rt: float = RT_KCAL) -> Any:
    n = len(sites)
    matrix = np.zeros((n, n), dtype=float)
    for i in range(n):
        for j in range(i + 1, n):
            distance = float(np.linalg.norm(sites[i]["center"] - sites[j]["center"]))
            value = _coulomb_kT(1.0, 1.0, distance, kappa, rt)
            matrix[i, j] = matrix[j, i] = value
    return matrix


def _intrinsic_pka(structure: Structure, sites: List[Dict[str, Any]],
                   fractions: Dict[str, float], ionic: float,
                   dielectric_scale: float = 1.0,
                   rt: float = RT_KCAL) -> None:
    kappa = _kappa(ionic)
    charges = _fixed_charges(structure, sites)
    for site in sites:
        residue = site["residue"]
        names = [name for name in site["atom_label"].split(",") if name in residue.atoms]
        if names:
            values = [
                fractions.get(f"{residue.chain}:{residue.resseq}:{residue.icode}:{name}", 1.0)
                for name in names
            ]
            burial = max(0.0, min(1.0, 1.0 - float(np.mean(values))))
        else:
            burial = 0.0
        site["burial"] = burial
        psi = 0.0
        for charge in charges:
            if charge.get("site") == site["id"]:
                continue
            distance = float(np.linalg.norm(site["center"] - charge["pos"]))
            psi += _coulomb_pka(charge["q"], distance, kappa, rt)
        # burial stabilizes the neutral form of acids and destabilizes the
        # charged form of bases; both increase with burial in opposite directions
        shift = site["sign"] * 1.6 * burial - psi
        site["pka_int"] = float(site["ref"] + shift)
        if site["pka_int"] < -2 or site["pka_int"] > 16:
            site["flag"] = "extreme pKa"


def _mean_field_curves(sites: Sequence[Dict[str, Any]], matrix: Any,
                       ph_values: Sequence[float]) -> Any:
    pka = np.array([site["pka_int"] for site in sites], dtype=float)
    n = len(sites)
    curves = np.zeros((n, len(ph_values)), dtype=float)
    previous = 1.0 / (1.0 + np.power(10.0, np.asarray(ph_values)[0] - pka))
    for col, ph in enumerate(ph_values):
        f = previous.copy()
        for _ in range(200):
            delta = math.log(10.0) * (ph - pka) + matrix @ f
            new = 1.0 / (1.0 + np.exp(np.clip(delta, -60.0, 60.0)))
            if np.max(np.abs(new - f)) < 1e-8:
                f = new
                break
            f = new
        curves[:, col] = f
        previous = f
    return curves


def _apparent_pka(curve: Any, ph_values: Sequence[float]) -> float:
    values = np.asarray(curve)
    ph = np.asarray(ph_values)
    for i in range(len(ph) - 1):
        a = values[i] - 0.5
        b = values[i + 1] - 0.5
        if a == 0:
            return float(ph[i])
        if a * b <= 0 and values[i] != values[i + 1]:
            fraction = abs(a) / (abs(a) + abs(b))
            return float(ph[i] + fraction * (ph[i + 1] - ph[i]))
    return float("nan")


def _net_charge(sites: Sequence[Dict[str, Any]], fractions: Any) -> Any:
    q_dep = np.array([site["q_dep"] for site in sites])
    return q_dep[:, None] + fractions


def _pI(sites: Sequence[Dict[str, Any]], curves: Any, ph_values: Sequence[float]) -> float:
    if len(sites) == 0:
        return float("nan")
    charge = np.sum(_net_charge(sites, curves), axis=0)
    ph = np.asarray(ph_values)
    for i in range(len(ph) - 1):
        if charge[i] == 0:
            return float(ph[i])
        if charge[i] * charge[i + 1] < 0:
            fraction = abs(charge[i]) / (abs(charge[i]) + abs(charge[i + 1]))
            return float(ph[i] + fraction * (ph[i + 1] - ph[i]))
    return float("nan")


def _monte_carlo(sites: Sequence[Dict[str, Any]], matrix: Any, ph: float,
                 seed: int, moves: Optional[int] = None) -> Tuple[Any, int]:
    n = len(sites)
    rng = np.random.default_rng(seed)
    pka = np.array([site["pka_int"] for site in sites], dtype=float)
    x = (rng.random(n) < 1.0 / (1.0 + np.power(10.0, ph - pka))).astype(np.int8)
    total = max(20000, int(moves or n * 200))
    burn = max(2000, total // 5)
    counts = np.zeros(n, dtype=float)
    accepted = 0
    log10 = math.log(10.0)
    for step in range(total):
        i = int(rng.integers(n))
        derivative = log10 * (ph - pka[i]) + float(matrix[i] @ x)
        delta = (1 - 2 * int(x[i])) * derivative
        if delta <= 0.0 or rng.random() < math.exp(-min(delta, 700.0)):
            x[i] = 1 - x[i]
            accepted += 1
        if step >= burn:
            counts += x
    fractions = counts / max(1, total - burn)
    return fractions, accepted


def analyze(structure: Structure, ph: float = 7.0, ionic_strength: float = 0.15,
            temperature: float = 298.15, seed: int = 20261109,
            mc_moves: Optional[int] = None) -> Dict[str, Any]:
    if np is None:
        raise RuntimeError("NumPy is required for Protonation Lab.")
    sites, warnings = build_sites(structure)
    if not sites:
        return {"sites": [], "curves": {}, "warnings": warnings + ["No titratable sites found."]}

    fractions = sasa_atom_fractions(structure)
    rt = 1.98720425864083e-3 * float(temperature)
    _intrinsic_pka(structure, sites, fractions, ionic_strength, rt=rt)
    matrix = _interaction_matrix(sites, _kappa(ionic_strength), rt)
    ph_values = [round(x * 0.1, 2) for x in range(0, 141)]  # 0.0 .. 14.0
    curves = _mean_field_curves(sites, matrix, ph_values)
    mc, accepted = _monte_carlo(sites, matrix, ph, seed, mc_moves)
    net = np.sum(_net_charge(sites, curves), axis=0)
    pI = _pI(sites, curves, ph_values)

    for index, site in enumerate(sites):
        site["pka_app"] = _apparent_pka(curves[index], ph_values)
        site["protonation"] = float(np.interp(ph, ph_values, curves[index]))
        site["mc_protonation"] = float(mc[index])
        if site["ref_name"] == "HIS":
            site["state"] = "HIP" if site["protonation"] > 0.5 else site["state_name"]
        elif site["protonation"] >= 0.5:
            site["state"] = "protonated"
        else:
            site["state"] = "deprotonated"
        if abs(site["protonation"] - 0.5) < 0.15:
            site["flag"] = (site["flag"] + "; near pH").strip("; ")
        if site["burial"] > 0.75:
            site["flag"] = (site["flag"] + "; buried").strip("; ")

    return {
        "format": "qah-protonation-result",
        "schema": 1,
        "structure": str(structure.path),
        "ph": float(ph),
        "ionic_strength": float(ionic_strength),
        "temperature": float(temperature),
        "seed": int(seed),
        "sites": sites,
        "ph_values": ph_values,
        "curves": curves,
        "net_charge": net,
        "pI": float(pI),
        "mc_moves": max(20000, int(mc_moves or len(sites) * 200)),
        "mc_accepted": accepted,
        "warnings": warnings,
        "model": "screened Coulomb / distance-dependent dielectric + SASA burial + mean-field/MC",
    }


def export_csv(result: Dict[str, Any], path: Path) -> None:
    path = Path(path)
    with open(path, "w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "chain", "residue_number", "insertion_code", "residue", "site",
            "pKa_intrinsic", "pKa_apparent", "protonation_at_pH", "mc_protonation",
            "state", "burial", "flag",
        ])
        for site in result["sites"]:
            residue = site["residue"]
            writer.writerow([
                residue.chain, residue.resseq, residue.icode, residue.name,
                site["ref_name"], f"{site['pka_int']:.3f}",
                f"{site['pka_app']:.3f}" if site["pka_app"] == site["pka_app"] else "",
                f"{site['protonation']:.5f}", f"{site.get('mc_protonation', 0):.5f}",
                site.get("state", ""), f"{site['burial']:.4f}", site.get("flag", ""),
            ])


def export_json(result: Dict[str, Any], path: Path) -> None:
    payload = dict(result)
    payload["sites"] = [
        {
            "id": site["id"],
            "kind": site["kind"],
            "residue": site["residue"].label,
            "chain": site["residue"].chain,
            "residue_number": site["residue"].resseq,
            "insertion_code": site["residue"].icode,
            "residue_name": site["residue"].name,
            "pka_intrinsic": site["pka_int"],
            "pka_apparent": (
                site["pka_app"] if site["pka_app"] == site["pka_app"] else None
            ),
            "protonation": site["protonation"],
            "mc_protonation": site.get("mc_protonation", 0.0),
            "state": site.get("state", ""),
            "burial": site["burial"],
            "flag": site.get("flag", ""),
        }
        for site in result["sites"]
    ]
    payload["net_charge"] = [float(v) for v in result["net_charge"]]
    payload["curves"] = {
        "ph": list(result["ph_values"]),
        "net_charge": [float(v) for v in result["net_charge"]],
    }
    payload["pI"] = float(result["pI"]) if result["pI"] == result["pI"] else None
    Path(path).write_text(json.dumps(payload, indent=2), encoding="utf-8")


def export_protonated_pdb(structure: Structure, result: Dict[str, Any], path: Path) -> None:
    """Write a coordinate copy with Protonation Lab REMARKs and His state names.

    This v0.1 exporter preserves existing coordinates and hydrogens; it does not
    rebuild missing hydrogens.
    """
    states = {(site["residue"].chain, site["residue"].resseq, site["residue"].icode): site
              for site in result["sites"]}
    lines = [
        f"REMARK 900 PROTONATION LAB pH={result['ph']:.2f} "
        f"I={result['ionic_strength']:.3f} T={result['temperature']:.2f}",
        "REMARK 900 state mapping; no hydrogens rebuilt",
    ]
    for key, site in states.items():
        lines.append(
            f"REMARK 900 {key[0]} {key[1]}{key[2]} {site['residue'].name} "
            f"pKa={site['pka_int']:.2f} prot={site['protonation']:.3f} "
            f"state={site.get('state', '')}"
        )
    for raw in structure.raw_lines:
        line = raw
        if line.startswith(("ATOM  ", "HETATM")) and len(line) >= 20:
            try:
                chain, resseq, icode = line[21], int(line[22:26]), line[26]
            except ValueError:
                chain, resseq, icode = "", 0, ""
            site = states.get((chain or "_", resseq, icode))
            if site and site["ref_name"] == "HIS":
                name = "HIP" if site["protonation"] > 0.5 else (site["state_name"] if site["state_name"] in ("HID", "HIE") else "HIE")
                line = line[:17] + f"{name:>3}" + line[20:]
        lines.append(line)
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")


def summarize(result: Dict[str, Any]) -> Dict[str, Any]:
    sites = result.get("sites") or []
    return {
        "sites": len(sites),
        "acidic": sum(1 for site in sites if site["kind"] == "acid"),
        "basic": sum(1 for site in sites if site["kind"] == "base"),
        "buried": sum(1 for site in sites if site["burial"] > 0.75),
        "near_ph": sum(1 for site in sites if abs(site["protonation"] - 0.5) < 0.15),
        "pI": result.get("pI"),
        "warnings": len(result.get("warnings") or []),
    }
