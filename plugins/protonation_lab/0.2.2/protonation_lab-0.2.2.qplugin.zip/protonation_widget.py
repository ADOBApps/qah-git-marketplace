"""Protonation Lab UI.

GPL-3.0-or-later.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSpinBox,
    QSplitter,
    QStackedWidget,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from . import protonation_core as core
from .structure_view_qt import Structure3DView

try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None  # type: ignore

try:
    from matplotlib import cm
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg, NavigationToolbar2QT
    from matplotlib.figure import Figure

    MATPLOTLIB_OK = True
except Exception:
    FigureCanvasQTAgg = None  # type: ignore
    NavigationToolbar2QT = None  # type: ignore
    Figure = None  # type: ignore
    cm = None  # type: ignore
    MATPLOTLIB_OK = False

ELEMENT_COLORS = {
    "H": "#e5e7eb", "C": "#6b7280", "N": "#2563eb", "O": "#dc2626",
    "S": "#eab308", "P": "#f97316", "CU": "#b45309", "ZN": "#7c3aed",
    "FE": "#b91c1c", "MN": "#a21caf", "MG": "#16a34a", "CA": "#0f766e",
    "NI": "#0e7490", "CO": "#1d4ed8", "NA": "#f59e0b", "K": "#f59e0b",
    "CL": "#22c55e",
}
SITE_COLORS = {
    "ASP": "#dc2626", "GLU": "#ef4444", "HIS": "#7c3aed", "LYS": "#2563eb",
    "ARG": "#1d4ed8", "CYS": "#eab308", "TYR": "#0f766e",
    "NTERM": "#0891b2", "CTERM": "#f97316",
}


class AnalyzeWorker(QThread):
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, structure, parameters: Dict[str, Any], parent=None):
        super().__init__(parent)
        self.structure = structure
        self.parameters = parameters

    def run(self) -> None:
        try:
            self.done.emit(core.analyze(self.structure, **self.parameters))
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class ProtonationLabWidget(QWidget):
    def __init__(self, plugin=None, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.structure: Optional[core.Structure] = None
        self.result: Optional[Dict[str, Any]] = None
        self.worker: Optional[AnalyzeWorker] = None
        self._build_ui()

    # -- construction -----------------------------------------------------
    def _build_ui(self) -> None:
        outer_layout = QVBoxLayout(self)
        outer_layout.setContentsMargins(0, 0, 0, 0)
        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(8, 8, 8, 8)
        header = QHBoxLayout()
        title = QLabel("<b>Protonation Lab</b>")
        title.setFont(QFont("Segoe UI", 15, QFont.Weight.Bold))
        header.addWidget(title)
        subtitle = QLabel("pH-dependent protonation states, pKa and titration")
        subtitle.setStyleSheet("color:#6b7280;")
        header.addWidget(subtitle, 1)
        self.status = QLabel("Load a PDB or mmCIF file.")
        self.status.setStyleSheet("color:#6b7280;")
        self.status.setWordWrap(True)
        header.addWidget(self.status)
        layout.addLayout(header)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._scroll_page(self._build_structure_tab(), 480), "Structure")
        self.tabs.addTab(self._scroll_page(self._build_viewer_tab(), 560), "Viewer")
        self.tabs.addTab(self._scroll_page(self._build_protonation_tab(), 620), "Protonation")
        self.tabs.addTab(self._scroll_page(self._build_titration_tab(), 520), "Titration")
        self.tabs.addTab(self._scroll_page(self._build_report_tab(), 420), "Report")
        self.tabs.addTab(self._scroll_page(self._build_help_tab(), 420), "Help")
        layout.addWidget(self.tabs, 1)

        content.setMinimumSize(900, 620)
        outer = QScrollArea()
        outer.setWidgetResizable(True)
        outer.setFrameShape(QFrame.Shape.NoFrame)
        outer.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        outer.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        outer.setWidget(content)
        outer_layout.addWidget(outer, 1)

    def _scroll_page(self, page: QWidget, min_height: int = 420) -> QScrollArea:
        if page.layout() is not None:
            page.layout().activate()
        page.setMinimumWidth(0)
        hint = page.sizeHint()
        page.setMinimumHeight(max(min_height, min(950, int(hint.height()))))
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setWidget(page)
        return scroll

    def _text_pane(self, widget: QPlainTextEdit) -> QPlainTextEdit:
        widget.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        widget.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        return widget

    def _build_structure_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        box = QGroupBox("Structure")
        box_layout = QVBoxLayout(box)
        row = QHBoxLayout()
        load = QPushButton("Load PDB / mmCIF…")
        load.clicked.connect(self._load_structure)
        row.addWidget(load)
        self.structure_path = QLabel("No structure loaded.")
        self.structure_path.setWordWrap(True)
        row.addWidget(self.structure_path, 1)
        box_layout.addLayout(row)
        self.structure_info = self._text_pane(QPlainTextEdit())
        self.structure_info.setReadOnly(True)
        self.structure_info.setFont(QFont("Consolas", 9))
        self.structure_info.setMaximumHeight(150)
        box_layout.addWidget(self.structure_info)
        layout.addWidget(box)

        box = QGroupBox("Input warnings")
        box_layout = QVBoxLayout(box)
        self.structure_warnings = self._text_pane(QPlainTextEdit())
        self.structure_warnings.setReadOnly(True)
        self.structure_warnings.setFont(QFont("Consolas", 9))
        box_layout.addWidget(self.structure_warnings)
        layout.addWidget(box, 1)
        return page

    def _build_viewer_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)

        controls = QGridLayout()
        controls.setHorizontalSpacing(6)
        controls.setVerticalSpacing(4)
        controls.addWidget(QLabel("Display:"), 0, 0)
        self.viewer_style = QComboBox()
        self.viewer_style.addItems([
            "Cα trace + sites", "All heavy atoms + sites", "Titratable sites only",
        ])
        self.viewer_style.currentIndexChanged.connect(self._draw_viewer)
        self.viewer_style.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        controls.addWidget(self.viewer_style, 0, 1)
        controls.addWidget(QLabel("Color:"), 0, 2)
        self.viewer_color = QComboBox()
        self.viewer_color.addItems(["Protonation", "pKa", "Burial", "Site type"])
        self.viewer_color.currentIndexChanged.connect(self._draw_viewer)
        self.viewer_color.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        controls.addWidget(self.viewer_color, 0, 3)
        controls.addWidget(QLabel("Projection:"), 0, 4)
        self.viewer_projection = QComboBox()
        self.viewer_projection.addItems(["PCA plane", "XY", "XZ", "YZ", "3D (pure Qt)"])
        self.viewer_projection.currentIndexChanged.connect(self._draw_viewer)
        self.viewer_projection.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        controls.addWidget(self.viewer_projection, 0, 5)
        controls.addWidget(QLabel("Highlight:"), 1, 0)
        self.viewer_site = QComboBox()
        self.viewer_site.setMinimumWidth(0)
        self.viewer_site.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.viewer_site.currentIndexChanged.connect(self._draw_viewer)
        controls.addWidget(self.viewer_site, 1, 1, 1, 3)
        reset = QPushButton("Reset")
        reset.clicked.connect(self._reset_viewer)
        controls.addWidget(reset, 1, 4)
        export = QPushButton("Export PNG…")
        export.clicked.connect(self._export_viewer_png)
        controls.addWidget(export, 1, 5)
        controls.setColumnStretch(1, 1)
        controls.setColumnStretch(3, 1)
        layout.addLayout(controls)

        self.viewer_label = QLabel(
            "Load a structure to see the Cα trace. After a run, titratable sites "
            "are coloured by the selected property."
        )
        self.viewer_label.setWordWrap(True)
        self.viewer_label.setStyleSheet("color:#6b7280;")
        layout.addWidget(self.viewer_label)

        self.viewer_stack = QStackedWidget()
        self.viewer_2d_page = QWidget()
        page_layout = QVBoxLayout(self.viewer_2d_page)
        page_layout.setContentsMargins(0, 0, 0, 0)
        if MATPLOTLIB_OK:
            self.viewer_canvas = FigureCanvasQTAgg(
                Figure(figsize=(6, 4), dpi=100, tight_layout=True)
            )
            self.viewer_canvas.setMinimumWidth(0)
            self.viewer_canvas.setMinimumHeight(340)
            self.viewer_canvas.setSizePolicy(
                QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding
            )
            page_layout.addWidget(self.viewer_canvas, 1)
            if NavigationToolbar2QT is not None:
                self.viewer_toolbar = NavigationToolbar2QT(self.viewer_canvas, self)
                page_layout.addWidget(self.viewer_toolbar)
        else:
            self.viewer_canvas = QLabel("matplotlib is not available; 2D projections are disabled.")
            page_layout.addWidget(self.viewer_canvas, 1)
        self.viewer_stack.addWidget(self.viewer_2d_page)
        self.viewer_3d = Structure3DView(self)
        self.viewer_3d.setMinimumHeight(340)
        self.viewer_stack.addWidget(self.viewer_3d)
        layout.addWidget(self.viewer_stack, 1)
        return page

    def _build_protonation_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        box = QGroupBox("Run")
        form = QFormLayout(box)
        form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.ph = QDoubleSpinBox()
        self.ph.setRange(0.0, 14.0)
        self.ph.setDecimals(2)
        self.ph.setSingleStep(0.1)
        self.ph.setValue(7.0)
        form.addRow("pH:", self.ph)
        self.ionic = QDoubleSpinBox()
        self.ionic.setRange(0.0, 1.0)
        self.ionic.setDecimals(3)
        self.ionic.setSingleStep(0.05)
        self.ionic.setValue(0.15)
        form.addRow("Ionic strength (M):", self.ionic)
        self.temperature = QDoubleSpinBox()
        self.temperature.setRange(273.15, 350.0)
        self.temperature.setDecimals(2)
        self.temperature.setValue(298.15)
        self.temperature.setSuffix(" K")
        form.addRow("Temperature:", self.temperature)
        self.mc_moves = QSpinBox()
        self.mc_moves.setRange(5000, 200000)
        self.mc_moves.setSingleStep(5000)
        self.mc_moves.setValue(20000)
        form.addRow("MC moves:", self.mc_moves)
        self.seed = QSpinBox()
        self.seed.setRange(0, 2147483647)
        self.seed.setValue(20261109)
        form.addRow("Random seed:", self.seed)
        row = QHBoxLayout()
        self.run_btn = QPushButton("Run protonation")
        self.run_btn.clicked.connect(self._run)
        row.addWidget(self.run_btn)
        self.run_status = QLabel("No analysis yet.")
        self.run_status.setStyleSheet("color:#6b7280;")
        self.run_status.setWordWrap(True)
        row.addWidget(self.run_status, 1)
        form.addRow("", row)
        layout.addWidget(box)

        self.site_table = QTableWidget(0, 10)
        self.site_table.setHorizontalHeaderLabels([
            "Chain", "Residue", "Number", "Site", "pKa int", "pKa app",
            "Prot @ pH", "MC", "State", "Flag",
        ])
        self.site_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.site_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.site_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.site_table.verticalHeader().setVisible(False)
        self.site_table.setWordWrap(True)
        self.site_table.itemSelectionChanged.connect(self._selection_changed)
        layout.addWidget(self.site_table, 1)
        return page

    def _build_titration_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        row = QHBoxLayout()
        row.addWidget(QLabel("Site curve:"))
        self.site_combo = QComboBox()
        self.site_combo.setMinimumWidth(280)
        self.site_combo.currentIndexChanged.connect(self._plot)
        row.addWidget(self.site_combo, 1)
        row.addStretch(1)
        layout.addLayout(row)
        self.summary_label = QLabel("Run the analysis to see titration curves.")
        self.summary_label.setWordWrap(True)
        layout.addWidget(self.summary_label)
        if MATPLOTLIB_OK:
            self.canvas = FigureCanvasQTAgg(Figure(figsize=(8, 5), tight_layout=True))
            self.canvas.setMinimumHeight(360)
        else:
            self.canvas = QLabel("matplotlib is not available; titration plots are disabled.")
        layout.addWidget(self.canvas, 1)
        return page

    def _build_report_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        row = QHBoxLayout()
        export_csv = QPushButton("Export CSV…")
        export_csv.clicked.connect(self._export_csv)
        export_json = QPushButton("Export JSON…")
        export_json.clicked.connect(self._export_json)
        export_pdb = QPushButton("Export protonated PDB…")
        export_pdb.clicked.connect(self._export_pdb)
        for button in (export_csv, export_json, export_pdb):
            row.addWidget(button)
        row.addStretch(1)
        layout.addLayout(row)
        self.report = self._text_pane(QPlainTextEdit())
        self.report.setReadOnly(True)
        self.report.setFont(QFont("Consolas", 9))
        layout.addWidget(self.report, 1)
        return page

    def _build_help_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        browser = QTextBrowser()
        browser.setOpenExternalLinks(True)
        browser.setHtml(
            "<h2>Protonation Lab</h2>"
            "<p>Structure-based pH-dependent protonation and pKa analysis for "
            "proteins and metalloproteins.</p>"
            "<h3>Workflow</h3>"
            "<ol>"
            "<li>Load a PDB or mmCIF structure.</li>"
            "<li>Set pH, ionic strength and temperature.</li>"
            "<li>Press <b>Run protonation</b>.</li>"
            "<li>Inspect the site table, <b>Viewer</b> and titration curves.</li>"
            "<li>Export CSV/JSON and a protonated coordinate copy.</li>"
            "</ol>"
            "<h3>Viewer</h3>"
            "<p>The <b>Viewer</b> tab shows a Cα trace or all heavy atoms, with "
            "titratable sites coloured by protonation, apparent pKa, burial or "
            "site type. Metal centres are shown as diamonds; the selected site "
            "has a ring. Choose a 2D projection or <b>3D (pure Qt)</b>; in 3D, "
            "drag to rotate, right-drag to pan, wheel to zoom and double-click "
            "to reset. <b>Export</b> saves the active view; 3D exports PNG, "
            "2D also supports SVG/PDF.</p>"
            "<h3>Model</h3>"
            "<p>v0.2.2 uses solvent-accessible-surface burial, screened Coulomb "
            "electrostatics with a distance-dependent dielectric, Debye-Hückel "
            "ionic screening, mean-field titration and Monte Carlo microstate "
            "sampling. A finite-difference Poisson-Boltzmann grid solver is the "
            "next planned refinement.</p>"
            "<h3>Limitations</h3>"
            "<ul>"
            "<li>The current model is an analytic continuum approximation, not a "
            "full finite-difference PB calculation.</li>"
            "<li>No missing hydrogens or atoms are rebuilt. The exported PDB "
            "contains state REMARKs and histidine state names.</li>"
            "<li>Histidine is represented by one neutral tautomer plus the "
            "cationic state; both tautomers and rotamers are not fully sampled.</li>"
            "<li>Metal ions are fixed charges; protonation-redox coupling is not "
            "predicted. Sites within 3.5 Å of a metal are flagged as metal sites.</li>"
            "<li>Modified/oxidized residues such as OHI are reported as warnings "
            "and are not titrated.</li>"
            "<li>Results near the target pH, in buried sites, and at metal centres "
            "carry the largest uncertainty. Sites with pKa outside 0–14 are shown "
            "as &lt;0 or &gt;14 in the table.</li>"
            "</ul>"
            "<h3>Export</h3>"
            "<p>The CSV contains pKa, protonation and state per site. The JSON "
            "contains the full result. The protonated PDB preserves coordinates "
            "and adds state REMARKs; it does not add hydrogens.</p>"
        )
        layout.addWidget(browser)
        return page

    # -- structure --------------------------------------------------------
    def _load_structure(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Load structure", str(Path.home()),
            "Structures (*.pdb *.ent *.cif *.mmcif);;All files (*)",
        )
        if not path:
            return
        try:
            structure = core.parse_structure(Path(path))
        except Exception as exc:
            QMessageBox.warning(self, "Protonation Lab", f"Could not parse structure:\n{exc}")
            return
        if not structure.atoms:
            QMessageBox.warning(self, "Protonation Lab", "No atoms were read from the file.")
            return
        self.structure = structure
        self.result = None
        self.structure_path.setText(str(path))
        chains = sorted({residue.chain for residue in structure.residues})
        metals = sorted({atom.element for atom in structure.atoms if atom.hetero and atom.element in core.METAL_CHARGE})
        info = [
            f"File      : {path}",
            f"Format    : {structure.format}",
            f"Atoms     : {len(structure.atoms)}",
            f"Residues  : {len(structure.residues)}",
            f"Chains    : {', '.join(chains) or '(none)'}",
            f"Metals    : {', '.join(metals) or '(none)'}",
            f"Waters    : {sum(1 for r in structure.residues if r.name.upper() in core.WATER)}",
        ]
        self.structure_info.setPlainText("\n".join(info))
        self.structure_warnings.setPlainText(
            "\n".join(structure.warnings) if structure.warnings else "No parser warnings."
        )
        self.site_table.setRowCount(0)
        self.site_combo.clear()
        self.viewer_site.clear()
        self.report.clear()
        self.summary_label.setText("Run the analysis to see titration curves.")
        if MATPLOTLIB_OK and hasattr(self.canvas, "figure"):
            self.canvas.figure.clear()
            self.canvas.draw_idle()
        self._draw_viewer()
        self.run_status.setText("Structure loaded. Set pH and press Run.")
        self.status.setText(f"Loaded {len(structure.atoms)} atoms from {Path(path).name}")

    # -- run --------------------------------------------------------------
    def _run(self) -> None:
        if self.structure is None:
            QMessageBox.information(self, "Protonation Lab", "Load a structure first.")
            return
        if self.worker is not None and self.worker.isRunning():
            QMessageBox.information(self, "Protonation Lab", "An analysis is already running.")
            return
        self.run_btn.setEnabled(False)
        self.run_status.setText("Running mean-field titration and Monte Carlo sampling…")
        self.status.setText("Running protonation analysis…")
        worker = AnalyzeWorker(self.structure, {
            "ph": self.ph.value(),
            "ionic_strength": self.ionic.value(),
            "temperature": self.temperature.value(),
            "seed": self.seed.value(),
            "mc_moves": self.mc_moves.value(),
        }, self)
        self.worker = worker
        worker.done.connect(self._done)
        worker.failed.connect(self._failed)
        worker.finished.connect(self._finished)
        worker.start()

    def _done(self, result: Dict[str, Any]) -> None:
        self.result = result
        self._populate_sites()
        self._populate_combo()
        self._update_report()
        self._plot()
        self._draw_viewer()
        summary = core.summarize(result)
        self.run_status.setText(
            f"{summary['sites']} sites · pI {summary['pI']:.2f} · "
            f"{summary['near_ph']} near pH · {summary.get('metal_sites', 0)} metal · "
            f"{summary['warnings']} warning(s)"
        )
        self.summary_label.setText(
            f"pH {result['ph']:.2f} | I {result['ionic_strength']:.3f} M | "
            f"pI {result['pI']:.2f} | {len(result['sites'])} sites | "
            f"{result['model']}"
        )
        warnings = list(self.structure.warnings if self.structure else [])
        warnings += list(result.get("warnings") or [])
        self.structure_warnings.setPlainText(
            "\n".join(dict.fromkeys(warnings)) if warnings else "No warnings."
        )
        self.status.setText("Protonation analysis complete.")
        self.tabs.setCurrentIndex(2)

    def _failed(self, message: str) -> None:
        QMessageBox.warning(self, "Protonation Lab", message)
        self.run_status.setText("Analysis failed.")
        self.status.setText("Analysis failed.")

    def _finished(self) -> None:
        self.worker = None
        self.run_btn.setEnabled(True)

    def _populate_sites(self) -> None:
        self.site_table.setRowCount(0)
        if not self.result:
            return
        for index, site in enumerate(self.result["sites"]):
            row = self.site_table.rowCount()
            self.site_table.insertRow(row)
            residue = site["residue"]
            values = (
                residue.chain,
                residue.name,
                f"{residue.resseq}{residue.icode}",
                site["ref_name"],
                f"{site['pka_int']:.2f}",
                (
                    f"{site['pka_app']:.2f}"
                    if site["pka_app"] == site["pka_app"]
                    else (
                        "— (<0)" if "< 0" in (site.get("pka_app_note") or "")
                        else "— (>14)" if "> 14" in (site.get("pka_app_note") or "")
                        else "—"
                    )
                ),
                f"{site['protonation']:.2f}",
                f"{site.get('mc_protonation', 0):.2f}",
                site.get("state", ""),
                site.get("flag", ""),
            )
            for col, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setData(Qt.ItemDataRole.UserRole, index)
                self.site_table.setItem(row, col, item)
        self.site_table.resizeColumnsToContents()

    def _populate_combo(self) -> None:
        self.site_combo.blockSignals(True)
        self.viewer_site.blockSignals(True)
        self.site_combo.clear()
        self.viewer_site.clear()
        if self.result:
            for index, site in enumerate(self.result["sites"]):
                residue = site["residue"]
                label = (
                    f"{residue.chain}:{residue.name}{residue.resseq}{residue.icode} "
                    f"{site['ref_name']}"
                )
                self.site_combo.addItem(label, index)
                self.viewer_site.addItem(label, index)
            if self.result["sites"]:
                self.site_combo.setCurrentIndex(0)
                self.viewer_site.setCurrentIndex(0)
        self.site_combo.blockSignals(False)
        self.viewer_site.blockSignals(False)

    def _selection_changed(self) -> None:
        rows = self.site_table.selectionModel().selectedRows()
        if not rows:
            return
        item = self.site_table.item(rows[0].row(), 0)
        if item is None:
            return
        index = item.data(Qt.ItemDataRole.UserRole)
        if index is not None:
            for combo in (self.site_combo, self.viewer_site):
                combo_index = combo.findData(index)
                if combo_index >= 0:
                    combo.setCurrentIndex(combo_index)

    def _plot(self) -> None:
        if not MATPLOTLIB_OK or not hasattr(self.canvas, "figure") or not self.result:
            return
        fig = self.canvas.figure
        fig.clear()
        ax1 = fig.add_subplot(121)
        ax2 = fig.add_subplot(122)
        ph = self.result["ph_values"]
        net = self.result["net_charge"]
        ax1.plot(ph, net, color="#2563eb")
        ax1.axhline(0, color="#9ca3af", lw=0.8)
        ax1.set_title("Net charge")
        ax1.set_xlabel("pH")
        ax1.set_ylabel("charge (e)")
        index = self.site_combo.currentData()
        if index is not None and 0 <= index < len(self.result["sites"]):
            site = self.result["sites"][index]
            curve = self.result["curves"][index]
            ax2.plot(ph, curve, color="#0f766e")
            ax2.axhline(0.5, color="#9ca3af", lw=0.8)
            ax2.set_title(f"{site['residue'].label} {site['ref_name']}")
            ax2.set_xlabel("pH")
            ax2.set_ylabel("protonated fraction")
        else:
            ax2.text(0.5, 0.5, "No site selected", ha="center", va="center")
            ax2.axis("off")
        fig.tight_layout()
        self.canvas.draw_idle()

    # -- viewer -----------------------------------------------------------
    def _viewer_basis(self, coords):
        center = coords.mean(axis=0)
        centered = coords - center
        mode = self.viewer_projection.currentText()
        if mode == "XY":
            axes = np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]])
        elif mode == "XZ":
            axes = np.array([[1.0, 0.0, 0.0], [0.0, 0.0, 1.0]])
        elif mode == "YZ":
            axes = np.array([[0.0, 1.0, 0.0], [0.0, 0.0, 1.0]])
        elif len(coords) >= 3:
            _, _, vt = np.linalg.svd(centered, full_matrices=False)
            axes = vt[:2]
        else:
            axes = np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]])
        return center, axes

    def _project(self, points, center, axes):
        return (points - center) @ axes.T

    def _viewer_site_color(self, site):
        mode = self.viewer_color.currentText()
        if mode == "Protonation":
            value = site["protonation"]
            if value >= 0.6:
                return "#2563eb"
            if value <= 0.4:
                return "#dc2626"
            return "#9ca3af"
        if mode == "pKa":
            value = site["pka_app"]
            if value != value or cm is None:
                return "#9ca3af"
            return cm.coolwarm(max(0.0, min(14.0, float(value))) / 14.0)
        if mode == "Burial":
            if cm is None:
                return "#6b7280"
            return cm.viridis(max(0.0, min(1.0, float(site["burial"]))))
        return SITE_COLORS.get(site["ref_name"], "#a855f7")

    def _viewer_legend(self) -> str:
        prefix = ""
        if self.viewer_projection.currentText() == "3D (pure Qt)":
            prefix = ("3D orthographic · drag to rotate · right-drag to pan · "
                      "wheel to zoom · double-click to reset. ")
        mode = self.viewer_color.currentText()
        if mode == "Protonation":
            return prefix + ("Blue = protonated (>0.6), red = deprotonated (<0.4), "
                             "grey = mixed; marker size increases with burial. "
                             "Orange diamonds = metal centres. Selected site has a ring.")
        if mode == "pKa":
            return prefix + ("Apparent pKa colour scale (blue low, red high, pH 0–14); "
                             "grey = pKa outside 0–14. Marker size increases with burial.")
        if mode == "Burial":
            return prefix + ("Burial colour scale (dark low, yellow high). "
                             "Marker size also increases with burial.")
        return prefix + "Site colours: Asp/Glu red, His purple, Lys/Arg blue, Cys yellow, Tyr teal."

    def _reset_viewer(self) -> None:
        if self.viewer_projection.currentText() == "3D (pure Qt)":
            self.viewer_3d.reset_view()
        else:
            self._draw_viewer()

    def _draw_viewer(self) -> None:
        mode = self.viewer_projection.currentText()
        if mode == "3D (pure Qt)":
            selected = self.viewer_site.currentData() if self.result else None
            self.viewer_stack.setCurrentWidget(self.viewer_3d)
            self.viewer_3d.set_scene(
                self.structure, self.result, self.viewer_style.currentText(),
                self.viewer_color.currentText(), selected,
            )
            self.viewer_label.setText(self._viewer_legend())
            return
        if not MATPLOTLIB_OK or not hasattr(self.viewer_canvas, "figure"):
            return
        self.viewer_stack.setCurrentWidget(self.viewer_2d_page)
        figure = self.viewer_canvas.figure
        figure.clear()
        axis = figure.add_subplot(111)
        if self.structure is None or np is None:
            axis.text(0.5, 0.5, "Load a structure to see the viewer.",
                      ha="center", va="center")
            axis.axis("off")
            figure.tight_layout()
            self.viewer_canvas.draw_idle()
            return

        style = self.viewer_style.currentText()
        heavy = [
            atom for atom in self.structure.atoms
            if atom.element != "H" and atom.resname.upper() not in core.WATER
        ]
        ca_atoms = [atom for atom in heavy if atom.name == "CA"]
        base = heavy if heavy else ca_atoms
        if not base:
            axis.text(0.5, 0.5, "No heavy atoms found.", ha="center", va="center")
            axis.axis("off")
            figure.tight_layout()
            self.viewer_canvas.draw_idle()
            return
        center, axes = self._viewer_basis(np.array([atom.pos for atom in base]))

        if style == "All heavy atoms + sites":
            coords = np.array([atom.pos for atom in heavy])
            xy = self._project(coords, center, axes)
            colors = [ELEMENT_COLORS.get(atom.element, "#a855f7") for atom in heavy]
            axis.scatter(
                xy[:, 0], xy[:, 1], s=5, c=colors, alpha=0.35,
                linewidths=0, rasterized=True,
            )
        elif style == "Cα trace + sites" and ca_atoms:
            by_chain: Dict[str, list] = {}
            for atom in ca_atoms:
                by_chain.setdefault(atom.chain, []).append(atom)
            for chain, atoms in by_chain.items():
                atoms.sort(key=lambda item: (item.resseq, item.icode))
                segment = []
                for atom in atoms:
                    if segment and float(np.linalg.norm(atom.pos - segment[-1].pos)) > 5.0:
                        if len(segment) > 1:
                            xy = self._project(np.array([a.pos for a in segment]), center, axes)
                            axis.plot(xy[:, 0], xy[:, 1], color="#94a3b8", linewidth=0.9, zorder=1)
                        segment = []
                    segment.append(atom)
                if len(segment) > 1:
                    xy = self._project(np.array([a.pos for a in segment]), center, axes)
                    axis.plot(xy[:, 0], xy[:, 1], color="#94a3b8", linewidth=0.9, zorder=1)
            xy = self._project(np.array([atom.pos for atom in ca_atoms]), center, axes)
            axis.scatter(xy[:, 0], xy[:, 1], s=8, c="#6b7280", alpha=0.55, linewidths=0, zorder=2)

        selected_index = self.viewer_site.currentData() if self.result else None
        if self.result:
            for index, site in enumerate(self.result["sites"]):
                point = self._project(np.array([site["center"]]), center, axes)[0]
                size = 26.0 + 110.0 * float(site["burial"])
                axis.scatter(
                    [point[0]], [point[1]], s=size,
                    c=[self._viewer_site_color(site)],
                    edgecolors="#111827", linewidths=0.35, alpha=0.92, zorder=3,
                )
            if selected_index is not None and 0 <= selected_index < len(self.result["sites"]):
                site = self.result["sites"][selected_index]
                point = self._project(np.array([site["center"]]), center, axes)[0]
                size = 26.0 + 110.0 * float(site["burial"])
                axis.scatter(
                    [point[0]], [point[1]], s=size + 190,
                    facecolors="none", edgecolors="#111827",
                    linewidths=2.0, zorder=4,
                )
                axis.annotate(
                    f"{site['residue'].label} {site['ref_name']}",
                    (point[0], point[1]), xytext=(7, 7),
                    textcoords="offset points", fontsize=8, color="#111827",
                    zorder=5,
                )

        for metal in (self.result or {}).get("metals", []):
            point = self._project(np.array([metal["position"]]), center, axes)[0]
            axis.scatter(
                [point[0]], [point[1]], marker="D", s=85,
                c=[ELEMENT_COLORS.get(metal["element"], "#b45309")],
                edgecolors="#111827", linewidths=0.8, zorder=5,
            )

        axis.set_aspect("equal")
        axis.axis("off")
        title = Path(self.structure.path).name if self.structure.path else "structure"
        axis.set_title(f"{title} · {style}")
        figure.tight_layout()
        self.viewer_canvas.draw_idle()
        self.viewer_label.setText(self._viewer_legend())

    def _export_viewer_png(self) -> None:
        if self.structure is None:
            QMessageBox.information(self, "Protonation Lab", "Load a structure first.")
            return
        is_3d = self.viewer_projection.currentText() == "3D (pure Qt)"
        if not is_3d and (not MATPLOTLIB_OK or not hasattr(self.viewer_canvas, "figure")):
            QMessageBox.information(self, "Protonation Lab", "The viewer is not available.")
            return
        base = Path(self.structure.path) if self.structure.path else Path.home() / "structure.pdb"
        filters = "PNG (*.png)" if is_3d else (
            "PNG (*.png);;SVG (*.svg);;PDF (*.pdf);;All files (*)"
        )
        path, _ = QFileDialog.getSaveFileName(
            self, "Export viewer", str(base.with_name(base.stem + "_viewer.png")),
            filters,
        )
        if not path:
            return
        try:
            if is_3d:
                if Path(path).suffix.lower() != ".png":
                    QMessageBox.information(
                        self, "Protonation Lab",
                        "The pure-Qt 3D view exports PNG. Use a .png path.",
                    )
                    return
                if not self.viewer_3d.grab().save(path):
                    raise RuntimeError("Could not save PNG.")
            else:
                self.viewer_canvas.figure.savefig(path, dpi=220)
            self.status.setText(f"Viewer exported: {path}")
        except Exception as exc:
            QMessageBox.warning(self, "Protonation Lab", str(exc))

    def _update_report(self) -> None:
        if not self.result:
            self.report.setPlainText("No result.")
            return
        summary = core.summarize(self.result)
        lines = [
            "Protonation Lab result",
            "=======================",
            f"Structure        : {self.result['structure']}",
            f"pH               : {self.result['ph']:.2f}",
            f"Ionic strength   : {self.result['ionic_strength']:.3f} M",
            f"Temperature      : {self.result['temperature']:.2f} K",
            f"Seed             : {self.result['seed']}",
            f"Titratable sites : {summary['sites']}",
            f"Acidic/basic     : {summary['acidic']} / {summary['basic']}",
            f"Buried (>0.75)   : {summary['buried']}",
            f"Metal sites      : {summary.get('metal_sites', 0)}",
            f"Metals           : {', '.join(sorted({m['element'] for m in (self.result.get('metals') or [])})) or '(none)'}",
            f"Near pH          : {summary['near_ph']}",
            f"pI               : {summary['pI']:.2f}",
            f"Model            : {self.result['model']}",
            "",
            "Warnings",
            "--------",
        ]
        warnings = list(self.result.get("warnings") or [])
        lines += [f"- {item}" for item in warnings] if warnings else ["(none)"]
        lines += [
            "",
            "The exported protonated PDB preserves coordinates and existing "
            "hydrogens; it adds state REMARKs and His state names. It does not "
            "rebuild missing hydrogens.",
        ]
        self.report.setPlainText("\n".join(lines))

    # -- export -----------------------------------------------------------
    def _default_export(self, suffix: str) -> Optional[Path]:
        if not self.result or self.structure is None:
            QMessageBox.information(self, "Protonation Lab", "Run the analysis first.")
            return None
        base = Path(self.result["structure"])
        path, _ = QFileDialog.getSaveFileName(
            self, "Export", str(base.with_name(base.stem + suffix)),
            "CSV (*.csv);;JSON (*.json);;PDB (*.pdb);;All files (*)",
        )
        return Path(path) if path else None

    def _export_csv(self) -> None:
        path = self._default_export("_protonation.csv")
        if path is None:
            return
        try:
            core.export_csv(self.result, path)
            self.status.setText(f"CSV exported: {path}")
        except Exception as exc:
            QMessageBox.warning(self, "Protonation Lab", str(exc))

    def _export_json(self) -> None:
        path = self._default_export("_protonation.json")
        if path is None:
            return
        try:
            core.export_json(self.result, path)
            self.status.setText(f"JSON exported: {path}")
        except Exception as exc:
            QMessageBox.warning(self, "Protonation Lab", str(exc))

    def _export_pdb(self) -> None:
        path = self._default_export("_protonated.pdb")
        if path is None:
            return
        try:
            core.export_protonated_pdb(self.structure, self.result, path)
            self.status.setText(f"Protonated PDB exported: {path}")
        except Exception as exc:
            QMessageBox.warning(self, "Protonation Lab", str(exc))
