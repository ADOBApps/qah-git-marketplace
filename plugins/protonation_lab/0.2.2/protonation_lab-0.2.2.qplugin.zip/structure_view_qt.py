"""Pure-Qt orthographic 3D structure view for Protonation Lab.

No matplotlib 3D. Atom positions stay in 3D; an orthographic orbit camera
projects them to the widget. This is deliberately lightweight so it remains
usable on small screens and large proteins.
"""

from __future__ import annotations

import math
from typing import Any, Dict, List, Optional

import numpy as np
from PySide6.QtCore import QPointF, QRectF, QSize, Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPen, QPolygonF
from PySide6.QtWidgets import QWidget

ELEMENT_COLORS = {
    "H": "#d1d5db", "C": "#6b7280", "N": "#2563eb", "O": "#dc2626",
    "S": "#eab308", "P": "#f97316", "CU": "#b45309", "ZN": "#7c3aed",
    "FE": "#b91c1c", "MN": "#a21caf", "MG": "#16a34a", "CA": "#0f766e",
    "NI": "#0e7490", "CO": "#1d4ed8", "NA": "#f59e0b", "K": "#f59e0b",
    "CL": "#22c55e",
}
SITE_COLORS = {
    "ASP": "#dc2626", "GLU": "#ef4444", "HIS": "#7c3aed", "LYS": "#2563eb",
    "ARG": "#1d4ed8", "CYS": "#eab308", "TYR": "#0f766e",
    "NTERM": "#0891b2", "CTERM": "#f97316",
}


class Structure3DView(QWidget):
    """Orthographic, rotatable Cα/heavy-atom view with titratable sites."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(280, 260)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setToolTip("Drag to rotate · right-drag to pan · wheel to zoom · double-click to reset")
        self.structure = None
        self.result: Optional[Dict[str, Any]] = None
        self.style = "Cα trace + sites"
        self.color_mode = "Protonation"
        self.selected_index: Optional[int] = None
        self.rot_x = 20.0
        self.rot_y = -35.0
        self.rot_z = 0.0
        self.pan_x = 0.0
        self.pan_y = 0.0
        self.zoom = 1.0
        self._center = np.zeros(3)
        self._span = 1.0
        self._heavy = []
        self._ca = []
        self._heavy_coords = np.zeros((0, 3))
        self._ca_coords = np.zeros((0, 3))
        self._mouse = None
        self._mode = None

    # -- data -----------------------------------------------------------
    def set_scene(self, structure, result, style: str, color_mode: str,
                  selected_index: Optional[int]) -> None:
        new_structure = structure is not self.structure
        self.structure = structure
        self.result = result
        self.style = style
        self.color_mode = color_mode
        self.selected_index = selected_index
        if structure is None:
            self._heavy = []
            self._ca = []
            self._heavy_coords = np.zeros((0, 3))
            self._ca_coords = np.zeros((0, 3))
            self.update()
            return
        self._heavy = [
            atom for atom in structure.atoms
            if atom.element != "H" and atom.resname.upper() not in {"HOH", "WAT", "H2O", "DOD"}
        ]
        self._ca = [atom for atom in self._heavy if atom.name == "CA"]
        coords = np.array([atom.pos for atom in self._heavy], dtype=float)
        if len(coords) == 0:
            coords = np.array([atom.pos for atom in structure.atoms], dtype=float)
        if len(coords):
            self._center = coords.mean(axis=0)
            self._span = max(1.0, float(np.max(np.ptp(coords, axis=0))))
        else:
            self._center = np.zeros(3)
            self._span = 1.0
        self._heavy_coords = coords
        self._ca_coords = np.array([atom.pos for atom in self._ca], dtype=float)
        if new_structure:
            self.reset_view()
        else:
            self.update()

    def reset_view(self) -> None:
        self.rot_x = 20.0
        self.rot_y = -35.0
        self.rot_z = 0.0
        self.pan_x = 0.0
        self.pan_y = 0.0
        self.zoom = 1.0
        self.update()

    # -- projection -----------------------------------------------------
    def _rotation(self) -> np.ndarray:
        rx, ry, rz = map(math.radians, (self.rot_x, self.rot_y, self.rot_z))
        cx, sx = math.cos(rx), math.sin(rx)
        cy, sy = math.cos(ry), math.sin(ry)
        cz, sz = math.cos(rz), math.sin(rz)
        Rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
        Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
        Rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
        return Rz @ Ry @ Rx

    def _project(self, points: np.ndarray):
        if len(points) == 0:
            return np.zeros((0, 2)), np.zeros(0)
        rotation = self._rotation()
        rotated = (points - self._center) @ rotation.T
        width = max(1, self.width())
        height = max(1, self.height())
        scale = 0.82 * min(width, height) / self._span * self.zoom
        xy = rotated[:, :2] * scale
        xy[:, 0] += width * 0.5 + self.pan_x
        xy[:, 1] = height * 0.5 - xy[:, 1] + self.pan_y
        return xy, rotated[:, 2]

    def _site_color(self, site) -> QColor:
        mode = self.color_mode
        if mode == "Protonation":
            value = float(site["protonation"])
            if value >= 0.6:
                return QColor("#2563eb")
            if value <= 0.4:
                return QColor("#dc2626")
            return QColor("#9ca3af")
        if mode == "pKa":
            value = site["pka_app"]
            if value != value:
                return QColor("#9ca3af")
            t = max(0.0, min(1.0, float(value) / 14.0))
            return QColor.fromHsvF(0.66 * (1.0 - t), 0.82, 0.92)
        if mode == "Burial":
            t = max(0.0, min(1.0, float(site["burial"])))
            # dark slate -> yellow
            r = int(17 + (234 - 17) * t)
            g = int(24 + (179 - 24) * t)
            b = int(39 + (8 - 39) * t)
            return QColor(r, g, b)
        return QColor(SITE_COLORS.get(site["ref_name"], "#a855f7"))

    # -- painting -------------------------------------------------------
    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.fillRect(self.rect(), QColor("#ffffff"))
        if self.structure is None or len(self._heavy_coords) == 0:
            painter.setPen(QColor("#6b7280"))
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter,
                             "Load a structure to see the 3D viewer.")
            return

        if self.style == "All heavy atoms + sites":
            xy, z = self._project(self._heavy_coords)
            order = np.argsort(z)
            painter.setPen(Qt.PenStyle.NoPen)
            for index in order:
                atom = self._heavy[int(index)]
                painter.setBrush(QColor(ELEMENT_COLORS.get(atom.element, "#a855f7")))
                painter.drawEllipse(QPointF(xy[index, 0], xy[index, 1]), 1.8, 1.8)
        elif self.style == "Cα trace + sites" and len(self._ca_coords):
            xy, _ = self._project(self._ca_coords)
            by_chain: Dict[str, List[int]] = {}
            for index, atom in enumerate(self._ca):
                by_chain.setdefault(atom.chain, []).append(index)
            painter.setPen(QPen(QColor("#94a3b8"), 0.9))
            for indices in by_chain.values():
                segment = []
                for index in indices:
                    if segment:
                        previous = self._ca[segment[-1]]
                        current = self._ca[index]
                        if float(np.linalg.norm(current.pos - previous.pos)) > 5.0:
                            if len(segment) > 1:
                                for a, b in zip(segment[:-1], segment[1:]):
                                    painter.drawLine(QPointF(xy[a, 0], xy[a, 1]),
                                                     QPointF(xy[b, 0], xy[b, 1]))
                            segment = []
                    segment.append(index)
                if len(segment) > 1:
                    for a, b in zip(segment[:-1], segment[1:]):
                        painter.drawLine(QPointF(xy[a, 0], xy[a, 1]),
                                         QPointF(xy[b, 0], xy[b, 1]))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor("#6b7280"))
            for x, y in xy:
                painter.drawEllipse(QPointF(x, y), 1.2, 1.2)

        # Sites + metals sorted by depth.
        drawables = []
        if self.result:
            for index, site in enumerate(self.result["sites"]):
                point, z = self._project(np.array([site["center"]]))
                drawables.append((float(z[0]), "site", index, point[0]))
        for metal in (self.result or {}).get("metals", []):
            point, z = self._project(np.array([metal["position"]]))
            drawables.append((float(z[0]), "metal", metal, point[0]))
        drawables.sort(key=lambda item: item[0])

        font = QFont("Arial", 9)
        painter.setFont(font)
        for _, kind, data, point in drawables:
            x, y = float(point[0]), float(point[1])
            if kind == "metal":
                radius = 5.0
                diamond = QPolygonF([
                    QPointF(x, y - radius), QPointF(x + radius, y),
                    QPointF(x, y + radius), QPointF(x - radius, y),
                ])
                painter.setBrush(QColor(ELEMENT_COLORS.get(data["element"], "#b45309")))
                painter.setPen(QPen(QColor("#111827"), 0.8))
                painter.drawPolygon(diamond)
                continue
            site = self.result["sites"][data]
            radius = 4.0 + 7.0 * float(site["burial"])
            painter.setBrush(self._site_color(site))
            painter.setPen(QPen(QColor("#111827"), 0.7))
            painter.drawEllipse(QPointF(x, y), radius, radius)
            if data == self.selected_index:
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.setPen(QPen(QColor("#111827"), 2.0))
                painter.drawEllipse(QPointF(x, y), radius + 5.0, radius + 5.0)
                label = f"{site['residue'].label} {site['ref_name']}"
                painter.setPen(QColor("#111827"))
                painter.drawText(QPointF(x + radius + 7, y - radius - 4), label)

        self._draw_axes(painter)

    def _draw_axes(self, painter: QPainter) -> None:
        rotation = self._rotation()
        origin = QPointF(24.0, self.height() - 24.0)
        length = 20.0
        axes = (
            ("X", np.array([1.0, 0.0, 0.0]), QColor("#dc2626")),
            ("Y", np.array([0.0, 1.0, 0.0]), QColor("#16a34a")),
            ("Z", np.array([0.0, 0.0, 1.0]), QColor("#2563eb")),
        )
        painter.setFont(QFont("Arial", 8))
        for label, vector, color in axes:
            rotated = rotation @ vector
            end = QPointF(origin.x() + rotated[0] * length,
                          origin.y() - rotated[1] * length)
            painter.setPen(QPen(color, 1.4))
            painter.drawLine(origin, end)
            painter.drawText(QPointF(end.x() + 2, end.y() - 1), label)

    # -- interaction ----------------------------------------------------
    def mousePressEvent(self, event) -> None:
        self._mouse = event.position()
        if event.button() == Qt.MouseButton.LeftButton:
            self._mode = "rotate"
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
        elif event.button() in (Qt.MouseButton.RightButton, Qt.MouseButton.MiddleButton):
            self._mode = "pan"
            self.setCursor(Qt.CursorShape.SizeAllCursor)
        event.accept()

    def mouseMoveEvent(self, event) -> None:
        if self._mouse is None or self._mode is None:
            return event.accept()
        delta = event.position() - self._mouse
        if self._mode == "rotate":
            self.rot_y += delta.x() * 0.5
            self.rot_x += delta.y() * 0.5
        else:
            self.pan_x += delta.x()
            self.pan_y += delta.y()
        self._mouse = event.position()
        self.update()
        event.accept()

    def mouseReleaseEvent(self, event) -> None:
        self._mode = None
        self._mouse = None
        self.setCursor(Qt.CursorShape.ArrowCursor)
        event.accept()

    def mouseDoubleClickEvent(self, event) -> None:
        self.reset_view()
        event.accept()

    def wheelEvent(self, event) -> None:
        factor = 1.15 if event.angleDelta().y() > 0 else 1.0 / 1.15
        self.zoom = max(0.1, min(20.0, self.zoom * factor))
        self.update()
        event.accept()
