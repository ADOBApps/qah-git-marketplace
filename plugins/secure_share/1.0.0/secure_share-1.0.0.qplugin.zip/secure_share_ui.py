# secure_share/secure_share_ui.py
"""PySide6 UI for Secure Share."""

from __future__ import annotations

import html
import hashlib
import importlib
import importlib.util
import sys
import traceback
from datetime import datetime
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QObject, QThread, QTimer, Qt, QUrl, Signal
from PySide6.QtGui import QDesktopServices, QFont, QFontDatabase
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSpinBox,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)


def _load_sibling(name: str):
    try:
        return importlib.import_module(f"{__name__}.{name}")
    except ImportError:
        path = Path(__file__).with_name(f"{name}.py")
        spec = importlib.util.spec_from_file_location(f"_secure_share_{name}", path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        return module


core = _load_sibling("secure_share_core")


class _Bridge(QObject):
    received = Signal(object)
    peers = Signal(object)
    log = Signal(str)


class _Task(QThread):
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, function, parent=None):
        super().__init__(parent)
        self._function = function

    def run(self):
        try:
            self.done.emit(self._function())
        except Exception:
            self.failed.emit(traceback.format_exc())


class PairingDialog(QDialog):
    def __init__(self, parent, service):
        super().__init__(parent)
        self.service = service
        self.setWindowTitle("Pair a device")
        self.setMinimumSize(620, 460)
        layout = QVBoxLayout(self)
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, 1)

        self._build_create_tab()
        self._build_import_tab()

        buttons = QDialogButtonBox(QDialogButtonBox.Close)
        buttons.button(QDialogButtonBox.Close).clicked.connect(self.accept)
        layout.addWidget(buttons)

    def _build_create_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        intro = QLabel(
            "Send this invite to the other computer through a trusted channel "
            "(password manager, USB, in person). It contains a one-time secret "
            "and expires after one hour."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        self.invite_fingerprint = QLabel("")
        self.invite_fingerprint.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(self.invite_fingerprint)

        self.invite_text = QPlainTextEdit()
        self.invite_text.setReadOnly(True)
        self.invite_text.setFont(_mono_font())
        layout.addWidget(self.invite_text, 1)

        row = QHBoxLayout()
        generate = QPushButton("Generate invite")
        generate.clicked.connect(self._generate)
        row.addWidget(generate)
        copy = QPushButton("Copy")
        copy.clicked.connect(self._copy_invite)
        row.addWidget(copy)
        save = QPushButton("Save as .txt...")
        save.clicked.connect(self._save_invite)
        row.addWidget(save)
        row.addStretch(1)
        layout.addLayout(row)
        self.tabs.addTab(tab, "Create invite")
        self._generate()

    def _build_import_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        intro = QLabel(
            "Paste the invite generated on the other computer. The handshake is "
            "sent back over the LAN if reachable, otherwise through the Git relay."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)
        self.import_text = QPlainTextEdit()
        self.import_text.setFont(_mono_font())
        self.import_text.setPlaceholderText("QAHPAIR1:...")
        layout.addWidget(self.import_text, 1)
        row = QHBoxLayout()
        paste = QPushButton("Paste from clipboard")
        paste.clicked.connect(self._paste_import)
        row.addWidget(paste)
        import_button = QPushButton("Import and pair")
        import_button.clicked.connect(self._import)
        row.addWidget(import_button)
        row.addStretch(1)
        layout.addLayout(row)
        self.tabs.addTab(tab, "Import invite")

    def _generate(self):
        invite = self.service.create_invite()
        self.invite_text.setPlainText(invite["code"])
        self.invite_fingerprint.setText(
            f"Your device fingerprint: {invite['fingerprint']} "
            f"(expires in one hour)"
        )

    def _copy_invite(self):
        text = self.invite_text.toPlainText().strip()
        if text:
            QApplication.clipboard().setText(text)
            QMessageBox.information(self, "Copied", "Pairing invite copied.")

    def _save_invite(self):
        text = self.invite_text.toPlainText().strip()
        if not text:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save pairing invite", str(Path.home() / "secure-share-invite.txt"),
            "Text files (*.txt);;All files (*)",
        )
        if path:
            Path(path).write_text(text + "\n", encoding="utf-8")
            QMessageBox.information(self, "Saved", f"Invite saved to:\n{path}")

    def _paste_import(self):
        self.import_text.setPlainText(QApplication.clipboard().text())

    def _import(self):
        code = self.import_text.toPlainText().strip()
        if not code:
            QMessageBox.warning(self, "No invite", "Paste a pairing invite first.")
            return
        try:
            result = self.service.import_invite(code)
        except Exception as exc:
            QMessageBox.critical(self, "Pairing failed", str(exc))
            return

        peer = result["peer"]
        delivered = False
        lan_error = ""
        lan = result.get("lan") or {}
        host, port = lan.get("host"), lan.get("port")
        if host and port:
            try:
                self.service.send_lan(result["handshake"], host, int(port))
                delivered = True
            except Exception as exc:
                lan_error = str(exc)
        if not delivered and self.service.settings.relay.enabled:
            try:
                self.service.send_relay(result["handshake"])
                delivered = True
            except Exception as exc:
                lan_error = f"{lan_error}; relay: {exc}".strip("; ")

        message = f"Paired with {peer.get('name', peer['id'])}."
        if delivered:
            message += "\nThe handshake was delivered."
        else:
            message += (
                "\nThe handshake could not be delivered. Make sure the other "
                "computer is online on the LAN, or enable the Git relay."
            )
            if lan_error:
                message += f"\n\nDetails: {lan_error}"
        QMessageBox.information(self, "Pairing", message)
        self.accept()


class SecureShareWidget(QWidget):
    def __init__(self, plugin):
        super().__init__()
        self.plugin = plugin
        self.service = plugin.service
        self._task: Optional[_Task] = None
        self._relay_timer = QTimer(self)
        self._relay_timer.setSingleShot(False)
        self._relay_timer.timeout.connect(self._timer_poll)

        self.bridge = _Bridge(self)
        self.bridge.received.connect(self._on_received)
        self.bridge.peers.connect(self._on_peers)
        self.bridge.log.connect(self._log)
        self.service.on_received = lambda item: self.bridge.received.emit(item)
        self.service.on_peers = lambda peers: self.bridge.peers.emit(peers)
        self.service.on_log = lambda text: self.bridge.log.emit(text)

        self._build_ui()
        self._refresh_identity()
        self._refresh_peers()
        self._refresh_history()
        self._configure_relay_timer()
        QTimer.singleShot(200, self._start_lan)

    # -- UI -------------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        header = QHBoxLayout()
        self.title = QLabel("<b>Secure Share</b>")
        self.title.setFont(QFont("Arial", 14))
        header.addWidget(self.title)
        self.identity_label = QLabel("")
        self.identity_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.identity_label.setStyleSheet("color: #6c757d;")
        header.addWidget(self.identity_label, 1)
        self.status_label = QLabel("Starting...")
        self.status_label.setStyleSheet("color: #6c757d;")
        header.addWidget(self.status_label)
        layout.addLayout(header)

        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, 1)
        self._build_send_tab()
        self._build_peers_tab()
        self._build_inbox_tab()
        self._build_relay_tab()
        self._build_settings_tab()

        self.activity = QPlainTextEdit()
        self.activity.setReadOnly(True)
        self.activity.setMaximumHeight(130)
        self.activity.setFont(_mono_font())
        layout.addWidget(self.activity)
        self._log("Secure Share ready.")

    def _build_send_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        row = QHBoxLayout()
        row.addWidget(QLabel("Peer:"))
        self.peer_combo = QComboBox()
        row.addWidget(self.peer_combo, 1)
        refresh = QPushButton("Refresh peers")
        refresh.clicked.connect(self._refresh_peers)
        row.addWidget(refresh)
        layout.addLayout(row)

        layout.addWidget(QLabel("Text:"))
        self.text_edit = QTextEdit()
        self.text_edit.setAcceptRichText(False)
        self.text_edit.setPlaceholderText("Type text to send...")
        layout.addWidget(self.text_edit, 1)

        buttons = QHBoxLayout()
        send_text = QPushButton("Send text")
        send_text.clicked.connect(self._send_text)
        buttons.addWidget(send_text)
        paste = QPushButton("Paste clipboard")
        paste.clicked.connect(
            lambda: self.text_edit.setPlainText(QApplication.clipboard().text())
        )
        buttons.addWidget(paste)
        send_files = QPushButton("Send file(s)...")
        send_files.clicked.connect(self._send_files)
        buttons.addWidget(send_files)
        send_folder = QPushButton("Send folder...")
        send_folder.clicked.connect(self._send_folder)
        buttons.addWidget(send_folder)
        buttons.addStretch(1)
        layout.addLayout(buttons)
        self.tabs.addTab(tab, "Send")

    def _build_peers_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.addWidget(
            QLabel(
                "Paired devices only. A device is paired after importing a "
                "one-time invite and delivering the encrypted handshake."
            )
        )
        self.peer_list = QListWidget()
        self.peer_list.setAlternatingRowColors(True)
        layout.addWidget(self.peer_list, 1)
        row = QHBoxLayout()
        pair = QPushButton("Pair a device...")
        pair.clicked.connect(self._pair)
        row.addWidget(pair)
        remove = QPushButton("Remove selected")
        remove.clicked.connect(self._remove_peer)
        row.addWidget(remove)
        refresh = QPushButton("Refresh")
        refresh.clicked.connect(self._refresh_peers)
        row.addWidget(refresh)
        row.addStretch(1)
        layout.addLayout(row)
        self.tabs.addTab(tab, "Peers")

    def _build_inbox_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.addWidget(
            QLabel(
                "Received items are saved in the inbox folder. Text is also "
                "kept in the local history."
            )
        )
        self.inbox_list = QListWidget()
        self.inbox_list.setAlternatingRowColors(True)
        self.inbox_list.itemDoubleClicked.connect(lambda _item: self._open_inbox())
        layout.addWidget(self.inbox_list, 1)
        row = QHBoxLayout()
        open_button = QPushButton("Open")
        open_button.clicked.connect(self._open_inbox)
        row.addWidget(open_button)
        copy = QPushButton("Copy text")
        copy.clicked.connect(self._copy_inbox_text)
        row.addWidget(copy)
        clear = QPushButton("Clear history")
        clear.clicked.connect(self._clear_history)
        row.addWidget(clear)
        row.addStretch(1)
        layout.addLayout(row)
        self.tabs.addTab(tab, "Inbox")

    def _build_relay_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        intro = QLabel(
            "Optional asynchronous transport for devices that are not on the "
            "same LAN. Envelopes are encrypted before they are committed to a "
            "private GitHub repository."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)
        form = QFormLayout()
        self.relay_enabled = QCheckBox("Enable Git relay")
        form.addRow("", self.relay_enabled)
        self.relay_owner = QLineEdit()
        self.relay_owner.setPlaceholderText("GitHub user or organisation")
        self.relay_repo = QLineEdit()
        self.relay_repo.setPlaceholderText("private repository")
        self.relay_branch = QLineEdit()
        self.relay_branch.setPlaceholderText("main")
        self.relay_token = QLineEdit()
        self.relay_token.setEchoMode(QLineEdit.Password)
        self.relay_token.setPlaceholderText(
            "token with contents: write (or GITHUB_TOKEN / QAH_SECURE_SHARE_TOKEN)"
        )
        self.relay_prefix = QLineEdit()
        self.relay_prefix.setPlaceholderText("secure_share")
        self.relay_poll = QSpinBox()
        self.relay_poll.setRange(5, 3600)
        self.relay_poll.setSuffix(" s")
        form.addRow("Owner:", self.relay_owner)
        form.addRow("Repository:", self.relay_repo)
        form.addRow("Branch:", self.relay_branch)
        form.addRow("Token:", self.relay_token)
        form.addRow("Path prefix:", self.relay_prefix)
        form.addRow("Poll:", self.relay_poll)
        layout.addLayout(form)
        row = QHBoxLayout()
        save = QPushButton("Save relay settings")
        save.clicked.connect(self._save_relay)
        row.addWidget(save)
        test = QPushButton("Test connection")
        test.clicked.connect(self._test_relay)
        row.addWidget(test)
        check = QPushButton("Check now")
        check.clicked.connect(self._poll_relay)
        row.addWidget(check)
        row.addStretch(1)
        layout.addLayout(row)
        self.relay_status = QLabel("")
        self.relay_status.setWordWrap(True)
        layout.addWidget(self.relay_status)
        layout.addStretch(1)
        self._load_relay_fields()
        self.tabs.addTab(tab, "Git relay")

    def _build_settings_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        form = QFormLayout()
        self.device_name = QLineEdit()
        self.lan_enabled = QCheckBox("Enable LAN discovery and server")
        self.lan_port = QSpinBox()
        self.lan_port.setRange(1024, 65535)
        self.discovery_port = QSpinBox()
        self.discovery_port.setRange(1024, 65535)
        self.auto_copy = QCheckBox("Copy received text to the clipboard")
        inbox_row = QHBoxLayout()
        self.inbox_dir = QLineEdit()
        self.inbox_dir.setPlaceholderText("default: <QAH>/secure_share/inbox")
        inbox_row.addWidget(self.inbox_dir, 1)
        browse = QPushButton("Browse...")
        browse.clicked.connect(self._browse_inbox)
        inbox_row.addWidget(browse)
        form.addRow("Device name:", self.device_name)
        form.addRow("", self.lan_enabled)
        form.addRow("LAN port:", self.lan_port)
        form.addRow("Discovery port:", self.discovery_port)
        form.addRow("", self.auto_copy)
        form.addRow("Inbox folder:", inbox_row)
        layout.addLayout(form)
        row = QHBoxLayout()
        save = QPushButton("Save settings")
        save.clicked.connect(self._save_settings)
        row.addWidget(save)
        restart = QPushButton("Restart LAN")
        restart.clicked.connect(self._restart_lan)
        row.addWidget(restart)
        row.addStretch(1)
        layout.addLayout(row)
        self.identity_details = QLabel("")
        self.identity_details.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.identity_details.setWordWrap(True)
        layout.addWidget(self.identity_details)
        layout.addStretch(1)
        self._load_settings_fields()
        self.tabs.addTab(tab, "Settings")

    # -- settings -------------------------------------------------------
    def _load_settings_fields(self):
        s = self.service.settings
        self.device_name.setText(s.device_name)
        self.lan_enabled.setChecked(s.lan_enabled)
        self.lan_port.setValue(int(s.lan_port))
        self.discovery_port.setValue(int(s.discovery_port))
        self.auto_copy.setChecked(s.auto_copy)
        self.inbox_dir.setText(s.inbox_dir)

    def _load_relay_fields(self):
        relay = self.service.settings.relay
        self.relay_enabled.setChecked(relay.enabled)
        self.relay_owner.setText(relay.owner)
        self.relay_repo.setText(relay.repo)
        self.relay_branch.setText(relay.branch)
        self.relay_token.setText(relay.token)
        self.relay_prefix.setText(relay.prefix)
        self.relay_poll.setValue(int(relay.poll_seconds))

    def _save_settings(self):
        s = self.service.settings
        s.device_name = self.device_name.text().strip() or s.device_name
        s.lan_enabled = self.lan_enabled.isChecked()
        s.lan_port = int(self.lan_port.value())
        s.discovery_port = int(self.discovery_port.value())
        s.auto_copy = self.auto_copy.isChecked()
        s.inbox_dir = self.inbox_dir.text().strip()
        self.service.save_settings()
        self._load_settings_fields()
        self._refresh_identity()
        self._log("Settings saved.")
        self._restart_lan()

    def _save_relay(self):
        relay = self.service.settings.relay
        relay.enabled = self.relay_enabled.isChecked()
        relay.owner = self.relay_owner.text().strip()
        relay.repo = self.relay_repo.text().strip()
        relay.branch = self.relay_branch.text().strip() or "main"
        relay.token = self.relay_token.text().strip()
        relay.prefix = self.relay_prefix.text().strip() or "secure_share"
        relay.poll_seconds = int(self.relay_poll.value())
        self.service.save_settings()
        self._configure_relay_timer()
        self._log("Git relay settings saved.")
        self._update_status()

    def _browse_inbox(self):
        folder = QFileDialog.getExistingDirectory(
            self, "Select inbox folder", str(Path.home())
        )
        if folder:
            self.inbox_dir.setText(folder)

    # -- identity / peers ----------------------------------------------
    def _refresh_identity(self):
        ident = self.service.identity
        fp = ident.public_dict()["fingerprint"]
        self.identity_label.setText(
            f"{html.escape(ident.name)}  ·  {ident.device_id[:8]}  ·  fp {fp}"
        )
        self.identity_details.setText(
            f"<b>Device id:</b> {html.escape(ident.device_id)}<br>"
            f"<b>Fingerprint:</b> {fp}<br>"
            f"<b>Data folder:</b> {html.escape(str(self.service.root))}<br>"
            f"<b>Inbox:</b> {html.escape(str(self.service._inbox_root()))}"
        )
        self._update_status()

    def _refresh_peers(self):
        current = self.peer_combo.currentData()
        self.peer_combo.clear()
        peers = self.service.paired_peers()
        for peer in peers:
            label = f"{peer.get('name', peer['id'])}"
            if peer.get("online"):
                label += "  ● online"
            else:
                label += "  ○ offline"
            self.peer_combo.addItem(label, peer["id"])
        if current:
            index = self.peer_combo.findData(current)
            if index >= 0:
                self.peer_combo.setCurrentIndex(index)

        self.peer_list.clear()
        for peer in peers:
            label = (
                f"{peer.get('name', peer['id'])}  "
                f"[{peer['id'][:8]}]  "
                f"{'online' if peer.get('online') else 'offline'}"
            )
            item = QListWidgetItem(label)
            item.setData(Qt.UserRole, peer)
            item.setToolTip(
                f"id: {peer['id']}\n"
                f"paired: {peer.get('paired_at', '')}\n"
                f"fingerprint: {_peer_fingerprint(peer)}"
            )
            self.peer_list.addItem(item)
        self._update_status()

    def _on_peers(self, _peers):
        self._refresh_peers()

    def _pair(self):
        dialog = PairingDialog(self, self.service)
        dialog.exec()
        self._refresh_peers()

    def _remove_peer(self):
        item = self.peer_list.currentItem()
        if item is None:
            QMessageBox.information(self, "No peer", "Select a peer first.")
            return
        peer = item.data(Qt.UserRole)
        answer = QMessageBox.question(
            self,
            "Remove peer",
            f"Remove {peer.get('name', peer['id'])}?\n\n"
            "You will need a new invite to pair again.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer == QMessageBox.Yes:
            self.service.remove_peer(peer["id"])
            self._refresh_peers()
            self._log(f"Removed peer {peer.get('name', peer['id'])}.")

    # -- sending --------------------------------------------------------
    def _selected_peer(self):
        peer_id = self.peer_combo.currentData()
        if not peer_id:
            return None
        return self.service.peers.get(peer_id)

    def _deliver(self, envelope, peer):
        last_error = ""
        if self.service.lan is not None and self.service.lan.running:
            try:
                self.service.send_via_peer(envelope, peer)
                return "LAN"
            except Exception as exc:
                last_error = str(exc)
        if self.service.settings.relay.enabled:
            self.service.send_relay(envelope)
            return "Git relay"
        if last_error:
            raise core.SecureShareError(
                f"{peer.get('name', peer['id'])} is not reachable: {last_error}"
            )
        raise core.SecureShareError(
            f"{peer.get('name', peer['id'])} is offline and the Git relay is "
            "disabled."
        )

    def _send_text(self):
        peer = self._selected_peer()
        if peer is None:
            QMessageBox.information(self, "No peer", "Pair a device first.")
            return
        text = self.text_edit.toPlainText()
        if not text:
            QMessageBox.information(self, "Empty", "Type some text first.")
            return

        def operation():
            envelope = self.service.send_text(peer["id"], text)
            return self._deliver(envelope, peer)

        def done(via):
            self._log(f"Sent text to {peer.get('name', peer['id'])} via {via}.")
            self.text_edit.clear()
            self.status_label.setText(f"Text sent via {via}")

        self._start("Sending text...", operation, done)

    def _send_files(self):
        peer = self._selected_peer()
        if peer is None:
            QMessageBox.information(self, "No peer", "Pair a device first.")
            return
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Select file(s) to send", str(Path.home()), "All files (*)"
        )
        if not paths:
            return

        def operation():
            sent = 0
            for path in paths:
                envelope = self.service.send_file(peer["id"], path)
                self._deliver(envelope, peer)
                sent += 1
            return sent

        def done(count):
            self._log(f"Sent {count} file(s) to {peer.get('name', peer['id'])}.")
            self.status_label.setText(f"Sent {count} file(s)")

        self._start(f"Sending {len(paths)} file(s)...", operation, done)

    def _send_folder(self):
        peer = self._selected_peer()
        if peer is None:
            QMessageBox.information(self, "No peer", "Pair a device first.")
            return
        folder = QFileDialog.getExistingDirectory(
            self, "Select folder to send", str(Path.home())
        )
        if not folder:
            return

        def operation():
            envelope = self.service.send_folder(peer["id"], folder)
            return self._deliver(envelope, peer)

        def done(via):
            self._log(
                f"Sent folder {Path(folder).name} to "
                f"{peer.get('name', peer['id'])} via {via}."
            )
            self.status_label.setText(f"Folder sent via {via}")

        self._start(f"Sending {Path(folder).name}...", operation, done)

    # -- receiving ------------------------------------------------------
    def _on_received(self, item):
        if item.get("kind") == "handshake":
            self._log(
                f"Paired with {item.get('peer', {}).get('name', 'a device')}."
            )
            self._refresh_peers()
            self.status_label.setText("Device paired")
            return
        self._log(
            f"Received {item.get('kind')} from {item.get('from_name', item.get('from'))}."
        )
        if item.get("kind") == "text" and self.service.settings.auto_copy:
            QApplication.clipboard().setText(str(item.get("text", "")))
            self._log("Text copied to the clipboard.")
        self._refresh_history()
        self.status_label.setText(f"Received {item.get('kind')}")

    def _refresh_history(self):
        self.inbox_list.clear()
        for item in reversed(self.service.history[-500:]):
            stamp = datetime.fromtimestamp(int(item.get("ts", 0))).strftime(
                "%Y-%m-%d %H:%M"
            )
            source = item.get("from_name") or item.get("from", "")[:8]
            if item.get("kind") == "text":
                preview = str(item.get("text", "")).replace("\n", " ")[:80]
                label = f"[{stamp}] {source}: {preview}"
            else:
                label = (
                    f"[{stamp}] {source}: {item.get('kind')} "
                    f"{item.get('name', '')}"
                )
            entry = QListWidgetItem(label)
            entry.setData(Qt.UserRole, item)
            self.inbox_list.addItem(entry)

    def _open_inbox(self):
        item = self.inbox_list.currentItem()
        if item is None:
            return
        data = item.data(Qt.UserRole)
        path = data.get("path")
        if path and Path(path).exists():
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
        elif data.get("kind") == "text":
            self._copy_inbox_text()

    def _copy_inbox_text(self):
        item = self.inbox_list.currentItem()
        if item is None:
            return
        data = item.data(Qt.UserRole)
        if data.get("kind") == "text":
            QApplication.clipboard().setText(str(data.get("text", "")))
            self._log("Received text copied to the clipboard.")

    def _clear_history(self):
        answer = QMessageBox.question(
            self,
            "Clear history",
            "Clear the local received-item history? Files in the inbox are not deleted.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer == QMessageBox.Yes:
            self.service.clear_history()
            self._refresh_history()

    # -- relay ----------------------------------------------------------
    def _configure_relay_timer(self):
        relay = self.service.settings.relay
        if relay.enabled:
            self._relay_timer.start(max(5, int(relay.poll_seconds)) * 1000)
        else:
            self._relay_timer.stop()
        self._update_status()

    def _timer_poll(self):
        if self._task is not None and self._task.isRunning():
            return
        self._poll_relay(silent=True)

    def _poll_relay(self, silent: bool = False):
        if not self.service.settings.relay.enabled:
            if not silent:
                QMessageBox.information(self, "Relay off", "Enable the Git relay first.")
            return

        def operation():
            return self.service.poll_relay()

        def done(items):
            if items:
                self._log(f"Relay delivered {len(items)} item(s).")
                self._refresh_history()
            elif not silent:
                self._log("Relay checked; nothing new.")
            self._refresh_peers()

        self._start("Checking Git relay...", operation, done, quiet=silent)

    def _test_relay(self):
        relay = core.RelaySettings(
            enabled=True,
            owner=self.relay_owner.text().strip(),
            repo=self.relay_repo.text().strip(),
            branch=self.relay_branch.text().strip() or "main",
            token=self.relay_token.text().strip(),
            prefix=self.relay_prefix.text().strip() or "secure_share",
            poll_seconds=int(self.relay_poll.value()),
        )

        def operation():
            return core.RelayClient(relay).test()

        def done(info):
            self.relay_status.setText(
                f"Connected to {info['slug']} "
                f"({'private' if info['private'] else 'public'}); "
                f"branch {info['branch']} "
                f"{'exists' if info['branch_exists'] else 'missing'}"
            )

        self._start("Testing Git relay...", operation, done)

    # -- LAN / status ---------------------------------------------------
    def _start_lan(self):
        if not self.service.settings.lan_enabled:
            self.status_label.setText("LAN disabled")
            return
        try:
            port = self.service.start_lan()
            self._log(f"LAN server on port {port}.")
            self.status_label.setText(f"LAN port {port}")
        except Exception as exc:
            self._log(f"LAN start failed: {exc}")
            self.status_label.setText("LAN unavailable")
        self._update_status()

    def _restart_lan(self):
        self.service.stop_lan()
        self._start_lan()

    def _update_status(self):
        parts = [f"LAN {'on' if self.service.lan and self.service.lan.running else 'off'}"]
        relay = self.service.settings.relay
        if relay.enabled:
            parts.append(f"relay {relay.slug or 'not configured'}")
        else:
            parts.append("relay off")
        parts.append(f"{len(self.service.peers)} peer(s)")
        self.status_label.setText(" · ".join(parts))

    # -- threading / log ------------------------------------------------
    def _start(self, label, function, on_done, *, quiet: bool = False):
        if self._task is not None and self._task.isRunning():
            if not quiet:
                QMessageBox.information(self, "Busy", "Another operation is running.")
            return
        if not quiet:
            self._log(label)
        task = _Task(function, self)
        task.done.connect(on_done)
        task.failed.connect(lambda text: self._on_failed(text, quiet=quiet))
        task.finished.connect(self._on_finished)
        self._task = task
        task.start()

    def _on_finished(self):
        if self._task is not None:
            self._task.deleteLater()
            self._task = None

    def _on_failed(self, text, *, quiet: bool = False):
        self._log("[Error] " + text)
        if not quiet:
            QMessageBox.critical(
                self, "Secure Share", "See the activity log for the error."
            )

    def _log(self, text):
        stamp = datetime.now().strftime("%H:%M:%S")
        for index, line in enumerate(str(text).splitlines() or [""]):
            prefix = f"[{stamp}] " if index == 0 else "           "
            self.activity.appendPlainText(prefix + line)
        bar = self.activity.verticalScrollBar()
        bar.setValue(bar.maximum())

    def cleanup(self):
        self._relay_timer.stop()
        self.service.stop_lan()
        task = self._task
        if task is not None and task.isRunning():
            task.setParent(None)
            task.finished.connect(task.deleteLater)
            self._task = None


def _mono_font() -> QFont:
    try:
        font = QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont)
    except Exception:
        font = QFontDatabase.systemFont(QFontDatabase.FixedFont)
    font.setPointSize(10)
    return font


def _peer_fingerprint(peer):
    raw = peer.get("ed25519_pub", "")
    try:
        data = core._unb64(raw)
        return hashlib.sha256(data).hexdigest()[:16]
    except Exception:
        return ""
