# secure_share/secure_share_core.py
"""
Author: Acxel Orozco
Secure Share - Qt-free core for encrypted QAH data exchange.

Two transports:

  * LAN       - UDP discovery + encrypted TCP frames (text, files, folders)
  * Git relay - encrypted envelopes committed to a private GitHub repository

Trust model: every installation owns an X25519 identity. A one-time, high-entropy
pairing invite is transferred out of band (copy/paste or file); the other device
imports it, derives a pairwise AES-256-GCM key, and sends an encrypted handshake.
No plaintext ever leaves the machine on either transport.

Requires `cryptography` (bundled with QAH).

This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

from __future__ import annotations

import base64
import hashlib
import io
import json
import os
import platform
import re
import secrets
import shutil
import socket
import stat
import threading
import time
import uuid
import zipfile
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple

try:
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric.x25519 import (
        X25519PrivateKey,
        X25519PublicKey,
    )
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
except Exception as exc:  # pragma: no cover - QAH ships cryptography
    raise ImportError(
        "Secure Share needs the 'cryptography' package, which is part of the "
        "QAH runtime. Run the plugin inside QAH."
    ) from exc

APP_TAG = "qah-secure-share"
PROTOCOL_VERSION = 1
INVITE_PREFIX = "QAHPAIR1:"
ENVELOPE_PREFIX = "QAHSHARE1:"
DEFAULT_LAN_PORT = 45873
DEFAULT_DISCOVERY_PORT = 45872
MAX_FILE_BYTES = 100 * 1024 * 1024
MAX_FOLDER_BYTES = 200 * 1024 * 1024
MAX_WIRE_BYTES = 400 * 1024 * 1024
MAX_HISTORY = 2000
PAIRING_TTL = 3600
REPLAY_RETENTION = 7 * 24 * 3600
ENV_HOME = "QAH_SECURE_SHARE_HOME"
ENV_TOKEN = "QAH_SECURE_SHARE_TOKEN"


class SecureShareError(RuntimeError):
    """Base error for Secure Share."""


class PairingError(SecureShareError):
    """Invite or handshake is invalid/expired."""


class DecryptError(SecureShareError):
    """Envelope authentication or decryption failed."""


class ReplayError(SecureShareError):
    """The envelope was already processed."""


class SizeLimitError(SecureShareError):
    """Payload exceeds the configured limit."""


# ---------------------------------------------------------------------------
# Paths and settings
# ---------------------------------------------------------------------------


def qah_home() -> Path:
    override = os.environ.get("QAH_HOME")
    if override:
        return Path(override).expanduser()
    return Path.home() / "QAH"


def default_root() -> Path:
    override = os.environ.get(ENV_HOME)
    if override:
        return Path(override).expanduser()
    return qah_home() / "secure_share"


@dataclass
class RelaySettings:
    enabled: bool = False
    owner: str = ""
    repo: str = ""
    branch: str = "main"
    token: str = ""
    prefix: str = "secure_share"
    poll_seconds: int = 30

    @property
    def slug(self) -> str:
        return f"{self.owner}/{self.repo}".strip("/")

    def to_dict(self) -> Dict[str, Any]:
        return {
            "enabled": bool(self.enabled),
            "owner": self.owner,
            "repo": self.repo,
            "branch": self.branch,
            "token": self.token,
            "prefix": self.prefix,
            "poll_seconds": int(self.poll_seconds),
        }

    @classmethod
    def from_dict(cls, data: Optional[Dict[str, Any]]) -> "RelaySettings":
        data = dict(data or {})
        return cls(
            enabled=bool(data.get("enabled", False)),
            owner=str(data.get("owner", "")).strip(),
            repo=str(data.get("repo", "")).strip(),
            branch=str(data.get("branch", "main")).strip() or "main",
            token=str(data.get("token", "")).strip(),
            prefix=str(data.get("prefix", "secure_share")).strip() or "secure_share",
            poll_seconds=max(5, int(data.get("poll_seconds", 30) or 30)),
        )


@dataclass
class Settings:
    device_name: str = ""
    lan_enabled: bool = True
    lan_port: int = DEFAULT_LAN_PORT
    discovery_port: int = DEFAULT_DISCOVERY_PORT
    auto_copy: bool = True
    inbox_dir: str = ""
    relay: RelaySettings = field(default_factory=RelaySettings)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "device_name": self.device_name,
            "lan_enabled": bool(self.lan_enabled),
            "lan_port": int(self.lan_port),
            "discovery_port": int(self.discovery_port),
            "auto_copy": bool(self.auto_copy),
            "inbox_dir": self.inbox_dir,
            "relay": self.relay.to_dict(),
        }

    @classmethod
    def from_dict(cls, data: Optional[Dict[str, Any]]) -> "Settings":
        data = dict(data or {})
        return cls(
            device_name=str(data.get("device_name", "")).strip(),
            lan_enabled=bool(data.get("lan_enabled", True)),
            lan_port=int(data.get("lan_port", DEFAULT_LAN_PORT) or DEFAULT_LAN_PORT),
            discovery_port=int(
                data.get("discovery_port", DEFAULT_DISCOVERY_PORT)
                or DEFAULT_DISCOVERY_PORT
            ),
            auto_copy=bool(data.get("auto_copy", True)),
            inbox_dir=str(data.get("inbox_dir", "")),
            relay=RelaySettings.from_dict(data.get("relay")),
        )


def _write_private(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)
    if os.name != "nt":
        try:
            path.chmod(0o600)
        except OSError:
            pass


def _read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def _unb64(text: str) -> bytes:
    return base64.b64decode(str(text).encode("ascii"))


def _canonical(data: Dict[str, Any]) -> bytes:
    return json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _fingerprint(public_bytes: bytes) -> str:
    return hashlib.sha256(public_bytes).hexdigest()[:16]


def local_ip() -> str:
    """Best-effort LAN address (no packets are sent)."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("8.8.8.8", 80))
        return sock.getsockname()[0]
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return "127.0.0.1"
    finally:
        sock.close()


# ---------------------------------------------------------------------------
# Identity
# ---------------------------------------------------------------------------


@dataclass
class Identity:
    device_id: str
    name: str
    x25519_private: bytes
    x25519_public: bytes
    ed25519_private: bytes
    ed25519_public: bytes

    @classmethod
    def generate(cls, name: str) -> "Identity":
        x_private = X25519PrivateKey.generate()
        e_private = Ed25519PrivateKey.generate()
        return cls(
            device_id=uuid.uuid4().hex,
            name=name,
            x25519_private=x_private.private_bytes(
                serialization.Encoding.Raw,
                serialization.PrivateFormat.Raw,
                serialization.NoEncryption(),
            ),
            x25519_public=x_private.public_key().public_bytes(
                serialization.Encoding.Raw, serialization.PublicFormat.Raw
            ),
            ed25519_private=e_private.private_bytes(
                serialization.Encoding.Raw,
                serialization.PrivateFormat.Raw,
                serialization.NoEncryption(),
            ),
            ed25519_public=e_private.public_key().public_bytes(
                serialization.Encoding.Raw, serialization.PublicFormat.Raw
            ),
        )

    @classmethod
    def load_or_create(cls, path: Path, name: str) -> "Identity":
        data = _read_json(path, None)
        if isinstance(data, dict) and data.get("x25519_private"):
            try:
                return cls(
                    device_id=str(data["device_id"]),
                    name=str(data.get("name") or name),
                    x25519_private=_unb64(data["x25519_private"]),
                    x25519_public=_unb64(data["x25519_public"]),
                    ed25519_private=_unb64(data["ed25519_private"]),
                    ed25519_public=_unb64(data["ed25519_public"]),
                )
            except Exception:
                pass
        identity = cls.generate(name)
        identity.save(path)
        return identity

    def save(self, path: Path) -> None:
        _write_private(
            path,
            json.dumps(
                {
                    "app": APP_TAG,
                    "v": PROTOCOL_VERSION,
                    "device_id": self.device_id,
                    "name": self.name,
                    "x25519_private": _b64(self.x25519_private),
                    "x25519_public": _b64(self.x25519_public),
                    "ed25519_private": _b64(self.ed25519_private),
                    "ed25519_public": _b64(self.ed25519_public),
                },
                indent=2,
            ),
        )

    def public_dict(self) -> Dict[str, str]:
        return {
            "id": self.device_id,
            "name": self.name,
            "x25519_pub": _b64(self.x25519_public),
            "ed25519_pub": _b64(self.ed25519_public),
            "fingerprint": _fingerprint(self.ed25519_public),
        }

    def rename(self, name: str, path: Path) -> None:
        self.name = name
        self.save(path)


# ---------------------------------------------------------------------------
# Crypto helpers
# ---------------------------------------------------------------------------


def derive_pair_key(
    private_bytes: bytes, peer_public_bytes: bytes, secret: bytes
) -> bytes:
    private = X25519PrivateKey.from_private_bytes(private_bytes)
    peer = X25519PublicKey.from_public_bytes(peer_public_bytes)
    shared = private.exchange(peer)
    return HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=secret,
        info=b"qah-secure-share/pair/v1",
    ).derive(shared)


def _seal(key: bytes, payload: Dict[str, Any], aad: Dict[str, Any]) -> Tuple[str, str]:
    nonce = os.urandom(12)
    plaintext = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    ciphertext = AESGCM(key).encrypt(nonce, plaintext, _canonical(aad))
    return _b64(nonce), _b64(ciphertext)


def _open(key: bytes, envelope: Dict[str, Any]) -> Dict[str, Any]:
    aad = {
        "v": envelope.get("v"),
        "type": envelope.get("type"),
        "from": envelope.get("from"),
        "to": envelope.get("to"),
        "id": envelope.get("id"),
        "ts": envelope.get("ts"),
    }
    if envelope.get("device") is not None:
        aad["device"] = envelope["device"]
    try:
        plaintext = AESGCM(key).decrypt(
            _unb64(envelope["nonce"]),
            _unb64(envelope["ciphertext"]),
            _canonical(aad),
        )
    except Exception as exc:
        raise DecryptError(
            "Could not decrypt the envelope: wrong key, tampered data or an "
            "incompatible version."
        ) from exc
    try:
        payload = json.loads(plaintext.decode("utf-8"))
    except Exception as exc:
        raise DecryptError("Decrypted payload is not valid JSON.") from exc
    if not isinstance(payload, dict):
        raise DecryptError("Decrypted payload is not an object.")
    return payload


# ---------------------------------------------------------------------------
# Invite encoding
# ---------------------------------------------------------------------------


def encode_invite(invite: Dict[str, Any]) -> str:
    raw = json.dumps(invite, separators=(",", ":")).encode("utf-8")
    return INVITE_PREFIX + base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def decode_invite(code: str) -> Dict[str, Any]:
    text = "".join(str(code).split())
    if not text.startswith(INVITE_PREFIX):
        raise PairingError("This is not a Secure Share pairing invite.")
    body = text[len(INVITE_PREFIX) :]
    body += "=" * (-len(body) % 4)
    try:
        data = json.loads(base64.urlsafe_b64decode(body.encode("ascii")))
    except Exception as exc:
        raise PairingError("The pairing invite is corrupt.") from exc
    if not isinstance(data, dict) or data.get("app") != APP_TAG:
        raise PairingError("The pairing invite belongs to another application.")
    if int(data.get("v", 0)) != PROTOCOL_VERSION:
        raise PairingError("Unsupported pairing invite version.")
    if data.get("kind") != "invite":
        raise PairingError("The pairing value is not an invite.")
    if int(data.get("expires", 0)) < int(time.time()):
        raise PairingError("The pairing invite has expired.")
    device = data.get("device") or {}
    for key in ("id", "x25519_pub", "ed25519_pub"):
        if not device.get(key):
            raise PairingError(f"The pairing invite is missing {key!r}.")
    if not re.fullmatch(r"[A-Za-z0-9_-]{8,64}", str(device["id"])):
        raise PairingError("The pairing invite has an invalid device id.")
    return data


# ---------------------------------------------------------------------------
# LAN node
# ---------------------------------------------------------------------------


class LanNode:
    """UDP discovery plus encrypted TCP envelope exchange."""

    def __init__(
        self,
        identity: Identity,
        *,
        tcp_port: int,
        discovery_port: int,
        on_envelope: Callable[[Dict[str, Any], Tuple[str, int]], Dict[str, Any]],
        on_peers: Callable[[Dict[str, Dict[str, Any]]], None],
        on_log: Callable[[str], None],
    ):
        self.identity = identity
        self.requested_port = int(tcp_port)
        self.discovery_port = int(discovery_port)
        self.on_envelope = on_envelope
        self.on_peers = on_peers
        self.on_log = on_log
        self.port = int(tcp_port)
        self._stop = threading.Event()
        self._server: Optional[socket.socket] = None
        self._udp: Optional[socket.socket] = None
        self._threads: List[threading.Thread] = []
        self._seen: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.RLock()

    @property
    def running(self) -> bool:
        return self._server is not None

    def start(self) -> int:
        if self._server is not None:
            return self.port
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        last_error: Optional[Exception] = None
        for offset in range(0, 10):
            try:
                server.bind(("", self.requested_port + offset))
                self.port = self.requested_port + offset
                break
            except OSError as exc:
                last_error = exc
        else:
            server.close()
            raise SecureShareError(
                f"Could not bind the LAN port {self.requested_port}-"
                f"{self.requested_port + 9}: {last_error}"
            )
        server.listen(8)
        self._server = server
        self.port = int(server.getsockname()[1])
        self._stop.clear()
        self._threads = [
            threading.Thread(target=self._accept_loop, daemon=True),
            threading.Thread(target=self._discovery_loop, daemon=True),
        ]
        for thread in self._threads:
            thread.start()
        self.on_log(
            f"LAN listening on {local_ip()}:{self.port} "
            f"(discovery UDP {self.discovery_port})"
        )
        return self.port

    def stop(self) -> None:
        self._stop.set()
        for sock in (self._server, self._udp):
            if sock is not None:
                try:
                    sock.close()
                except OSError:
                    pass
        self._server = None
        self._udp = None
        for thread in self._threads:
            thread.join(timeout=1.5)
        self._threads = []
    def peers(self) -> Dict[str, Dict[str, Any]]:
        with self._lock:
            now = time.time()
            return {
                key: dict(value)
                for key, value in self._seen.items()
                if now - float(value.get("last_seen", 0)) <= 12
            }

    # -- discovery -------------------------------------------------------
    def _discovery_loop(self) -> None:
        if self.discovery_port <= 0:
            return
        udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        udp.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            udp.bind(("", self.discovery_port))
        except OSError as exc:
            self.on_log(
                f"Discovery port {self.discovery_port} unavailable ({exc}); "
                "use a manual address instead."
            )
            udp.close()
            return
        udp.settimeout(1.0)
        self._udp = udp
        packet = json.dumps(
            {
                "app": APP_TAG,
                "v": PROTOCOL_VERSION,
                "id": self.identity.device_id,
                "name": self.identity.name,
                "port": self.port,
                "ts": int(time.time()),
            },
            separators=(",", ":"),
        ).encode("utf-8")
        last_beacon = 0.0
        last_emit = 0.0
        while not self._stop.is_set():
            now = time.time()
            if now - last_beacon >= 2.0:
                try:
                    udp.sendto(packet, ("255.255.255.255", self.discovery_port))
                except OSError:
                    pass
                last_beacon = now
            try:
                data, address = udp.recvfrom(4096)
            except socket.timeout:
                data, address = b"", ("", 0)
            except OSError:
                break
            if data:
                try:
                    info = json.loads(data.decode("utf-8"))
                except Exception:
                    info = None
                if (
                    isinstance(info, dict)
                    and info.get("app") == APP_TAG
                    and info.get("id")
                    and info.get("id") != self.identity.device_id
                ):
                    with self._lock:
                        self._seen[str(info["id"])] = {
                            "id": str(info["id"]),
                            "name": str(info.get("name", "")),
                            "host": address[0],
                            "port": int(info.get("port", self.requested_port)),
                            "last_seen": now,
                        }
            if now - last_emit >= 2.0:
                last_emit = now
                self.on_peers(self.peers())

    # -- TCP -------------------------------------------------------------
    def _accept_loop(self) -> None:
        server = self._server
        if server is None:
            return
        while not self._stop.is_set():
            try:
                connection, address = server.accept()
            except OSError:
                break
            threading.Thread(
                target=self._handle_connection,
                args=(connection, address),
                daemon=True,
            ).start()

    def _recv_exact(self, connection: socket.socket, size: int) -> bytes:
        chunks = []
        remaining = size
        while remaining > 0:
            chunk = connection.recv(min(remaining, 1024 * 1024))
            if not chunk:
                raise ConnectionError("Connection closed while receiving.")
            chunks.append(chunk)
            remaining -= len(chunk)
        return b"".join(chunks)

    def _handle_connection(
        self, connection: socket.socket, address: Tuple[str, int]
    ) -> None:
        try:
            connection.settimeout(120)
            header = self._recv_exact(connection, 4)
            length = int.from_bytes(header, "big")
            if length <= 0 or length > MAX_WIRE_BYTES:
                raise SecureShareError("Invalid frame length.")
            raw = self._recv_exact(connection, length)
            envelope = json.loads(raw.decode("utf-8"))
            response = self.on_envelope(envelope, address)
            if not isinstance(response, dict):
                response = {"ok": True}
        except Exception as exc:
            response = {"ok": False, "error": str(exc)}
        try:
            body = json.dumps(response, separators=(",", ":")).encode("utf-8")
            connection.sendall(len(body).to_bytes(4, "big") + body)
        except OSError:
            pass
        finally:
            try:
                connection.close()
            except OSError:
                pass

    def send(
        self,
        envelope: Dict[str, Any],
        host: str,
        port: int,
        timeout: float = 120.0,
    ) -> Dict[str, Any]:
        body = json.dumps(envelope, separators=(",", ":")).encode("utf-8")
        if len(body) > MAX_WIRE_BYTES:
            raise SizeLimitError("The encrypted envelope is too large for LAN.")
        with socket.create_connection((host, int(port)), timeout=timeout) as connection:
            connection.settimeout(timeout)
            connection.sendall(len(body).to_bytes(4, "big") + body)
            header = self._recv_exact(connection, 4)
            length = int.from_bytes(header, "big")
            if length > 1024 * 1024:
                raise SecureShareError("Invalid response length.")
            raw = self._recv_exact(connection, length)
            return json.loads(raw.decode("utf-8"))


# ---------------------------------------------------------------------------
# Git relay
# ---------------------------------------------------------------------------


class RelayClient:
    """Minimal GitHub Contents API client for encrypted envelopes."""

    def __init__(self, settings: RelaySettings):
        self.settings = settings
        self.api = "https://api.github.com"
        self.token = (
            settings.token
            or os.environ.get(ENV_TOKEN, "")
            or os.environ.get("GITHUB_TOKEN", "")
            or os.environ.get("GH_TOKEN", "")
        ).strip()

    @property
    def slug(self) -> str:
        return self.settings.slug

    def _request(
        self,
        method: str,
        path: str,
        *,
        data: Optional[Dict[str, Any]] = None,
        raw: bool = False,
        allow_404: bool = False,
    ) -> Any:
        if not self.settings.owner or not self.settings.repo:
            raise SecureShareError(
                "The Git relay is not configured (owner/repository)."
            )
        if not self.token:
            raise SecureShareError(
                "The Git relay needs a GitHub token with repository access."
            )
        headers = {
            "Accept": "application/vnd.github.raw+json"
            if raw
            else "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "QAH-Secure-Share/1.0",
            "Authorization": f"Bearer {self.token}",
        }
        body = None
        if data is not None:
            body = json.dumps(data).encode("utf-8")
            headers["Content-Type"] = "application/json"
        url = self.api + path
        try:
            import requests  # type: ignore

            response = requests.request(
                method, url, headers=headers, data=body, timeout=60
            )
            status, content = response.status_code, response.content
        except ImportError:
            import urllib.error
            import urllib.request

            request = urllib.request.Request(url, data=body, headers=headers, method=method)
            try:
                with urllib.request.urlopen(request, timeout=60) as response:
                    status, content = response.status, response.read()
            except urllib.error.HTTPError as exc:
                status, content = exc.code, exc.read()
        if status == 404 and allow_404:
            return None
        if status == 401:
            raise SecureShareError("GitHub rejected the relay token (401).")
        if status == 403:
            raise SecureShareError(
                "GitHub refused the relay request (403): token permissions or "
                "rate limit."
            )
        if status >= 400:
            message = ""
            try:
                message = json.loads(content.decode("utf-8")).get("message", "")
            except Exception:
                message = content.decode("utf-8", "replace")[:300]
            raise SecureShareError(f"GitHub API {status}: {message}")
        if raw:
            return content
        if not content:
            return None
        return json.loads(content.decode("utf-8"))

    def _ref(self) -> str:
        return ""

    def _contents(self, path: str) -> str:
        import urllib.parse

        return (
            f"/repos/{self.slug}/contents/"
            f"{urllib.parse.quote(path, safe='/')}"
            f"?ref={urllib.parse.quote(self.settings.branch, safe='')}"
        )

    def send(self, envelope: Dict[str, Any]) -> str:
        import urllib.parse

        recipient = str(envelope.get("to") or "").strip()
        if not recipient:
            raise SecureShareError("Envelope has no recipient.")
        path = (
            f"{self.settings.prefix}/{recipient}/"
            f"{int(envelope.get('ts', time.time()))}-{envelope.get('id')}.json"
        )
        raw = json.dumps(envelope, separators=(",", ":")).encode("utf-8")
        if len(raw) > 90 * 1024 * 1024:
            raise SizeLimitError(
                "This envelope is larger than the Git relay limit (~90 MB "
                "before base64). Use the LAN transport or a smaller file."
            )
        payload = {
            "message": f"Secure Share {envelope.get('id')}",
            "content": base64.b64encode(raw).decode("ascii"),
            "branch": self.settings.branch,
        }
        self._request(
            "PUT",
            f"/repos/{self.slug}/contents/{urllib.parse.quote(path, safe='/')}",
            data=payload,
        )
        return path

    def list_messages(self, device_id: str) -> List[Dict[str, Any]]:
        directory = f"{self.settings.prefix}/{device_id}"
        payload = self._request(
            "GET", self._contents(directory), allow_404=True
        )
        if not payload:
            return []
        messages = []
        for item in payload:
            if not isinstance(item, dict) or not item.get("name", "").endswith(".json"):
                continue
            path = str(item.get("path") or "")
            sha = str(item.get("sha") or "")
            raw = self._request("GET", self._contents(path), raw=True, allow_404=True)
            if raw is None:
                continue
            try:
                envelope = json.loads(raw.decode("utf-8"))
            except Exception:
                continue
            messages.append({"path": path, "sha": sha, "envelope": envelope})
        return messages

    def delete(self, path: str, sha: str) -> None:
        import urllib.parse

        self._request(
            "DELETE",
            f"/repos/{self.slug}/contents/{urllib.parse.quote(path, safe='/')}",
            data={
                "message": "Secure Share: delivered",
                "sha": sha,
                "branch": self.settings.branch,
            },
        )

    def test(self) -> Dict[str, Any]:
        repo = self._request("GET", f"/repos/{self.slug}")
        branch = self._request(
            "GET",
            f"/repos/{self.slug}/branches/"
            f"{__import__('urllib.parse', fromlist=['quote']).quote(self.settings.branch, safe='')}",
            allow_404=True,
        )
        return {
            "slug": repo.get("full_name", self.slug),
            "private": bool(repo.get("private")),
            "branch": self.settings.branch,
            "branch_exists": branch is not None,
        }


# ---------------------------------------------------------------------------
# Service
# ---------------------------------------------------------------------------


class SecureShareService:
    """Identity, peers, pairing, envelopes, LAN node and relay orchestration."""

    def __init__(
        self,
        root: Optional[os.PathLike | str] = None,
        *,
        settings: Optional[Settings] = None,
    ):
        self.root = Path(root).expanduser() if root else default_root()
        self.root.mkdir(parents=True, exist_ok=True)
        self.identity_path = self.root / "identity.json"
        self.settings_path = self.root / "settings.json"
        self.peers_path = self.root / "peers.json"
        self.pending_path = self.root / "pending.json"
        self.seen_path = self.root / "seen.json"
        self.history_path = self.root / "history.json"

        self.settings = settings or Settings.from_dict(_read_json(self.settings_path, {}))
        if not self.settings.device_name:
            self.settings.device_name = platform.node() or "QAH device"
        self.identity = Identity.load_or_create(
            self.identity_path, self.settings.device_name
        )
        if self.identity.name != self.settings.device_name:
            self.identity.rename(self.settings.device_name, self.identity_path)

        self.peers: Dict[str, Dict[str, Any]] = _read_json(self.peers_path, {})
        self.pending: List[Dict[str, Any]] = _read_json(self.pending_path, [])
        self.seen: Dict[str, float] = _read_json(self.seen_path, {})
        self.history: List[Dict[str, Any]] = _read_json(self.history_path, [])
        self._lock = threading.RLock()
        self.lan: Optional[LanNode] = None
        self.on_received: Optional[Callable[[Dict[str, Any]], None]] = None
        self.on_peers: Optional[Callable[[Dict[str, Dict[str, Any]]], None]] = None
        self.on_log: Optional[Callable[[str], None]] = None
        self._prune_pending()
        self._prune_seen()

    # -- callbacks ------------------------------------------------------
    def _log(self, message: str) -> None:
        if self.on_log:
            try:
                self.on_log(message)
            except Exception:
                pass

    def _emit_received(self, item: Dict[str, Any]) -> None:
        if self.on_received:
            try:
                self.on_received(item)
            except Exception:
                pass

    def _emit_peers(self, peers: Dict[str, Dict[str, Any]]) -> None:
        if self.on_peers:
            try:
                self.on_peers(peers)
            except Exception:
                pass

    # -- persistence ----------------------------------------------------
    def save_settings(self) -> None:
        _write_private(self.settings_path, json.dumps(self.settings.to_dict(), indent=2))
        if self.identity.name != self.settings.device_name:
            self.identity.rename(self.settings.device_name, self.identity_path)

    def _save_peers(self) -> None:
        _write_private(self.peers_path, json.dumps(self.peers, indent=2))

    def _save_pending(self) -> None:
        _write_private(self.pending_path, json.dumps(self.pending, indent=2))

    def _save_seen(self) -> None:
        _write_private(self.seen_path, json.dumps(self.seen, indent=2))

    def _save_history(self) -> None:
        self.history = self.history[-MAX_HISTORY:]
        _write_private(self.history_path, json.dumps(self.history, indent=2))

    def _prune_pending(self) -> None:
        now = int(time.time())
        self.pending = [
            item
            for item in self.pending
            if int(item.get("expires", 0)) > now
        ][-20:]
        self._save_pending()

    def _prune_seen(self) -> None:
        now = time.time()
        cleaned: Dict[str, float] = {}
        for key, value in self.seen.items():
            try:
                timestamp = float(value)
            except (TypeError, ValueError):
                continue
            if now - timestamp <= REPLAY_RETENTION:
                cleaned[key] = timestamp
        if len(cleaned) > 10000:
            newest = sorted(
                cleaned.items(), key=lambda item: item[1], reverse=True
            )[:10000]
            cleaned = dict(newest)
        self.seen = cleaned
        self._save_seen()

    # -- peers / identity ----------------------------------------------
    def public_identity(self) -> Dict[str, Any]:
        return {
            **self.identity.public_dict(),
            "root": str(self.root),
        }

    def paired_peers(self) -> List[Dict[str, Any]]:
        online = self.lan.peers() if self.lan else {}
        result = []
        for peer in self.peers.values():
            item = dict(peer)
            item["online"] = peer.get("id") in online
            if item["online"]:
                item["host"] = online[peer["id"]]["host"]
                item["port"] = online[peer["id"]]["port"]
            result.append(item)
        result.sort(key=lambda item: str(item.get("name", "")).lower())
        return result

    def remove_peer(self, peer_id: str) -> bool:
        with self._lock:
            if peer_id in self.peers:
                del self.peers[peer_id]
                self._save_peers()
                return True
        return False

    # -- pairing --------------------------------------------------------
    def create_invite(self, expires_in: int = PAIRING_TTL) -> Dict[str, Any]:
        secret = secrets.token_bytes(32)
        expires = int(time.time()) + max(60, int(expires_in))
        invite = {
            "app": APP_TAG,
            "v": PROTOCOL_VERSION,
            "kind": "invite",
            "device": self.identity.public_dict(),
            "secret": _b64(secret),
            "expires": expires,
            "lan": {
                "host": local_ip(),
                "port": self.lan.port if self.lan and self.lan.running else self.settings.lan_port,
            },
        }
        with self._lock:
            self.pending.append(
                {
                    "secret": _b64(secret),
                    "expires": expires,
                    "created": int(time.time()),
                }
            )
            self._prune_pending()
        code = encode_invite(invite)
        return {
            "code": code,
            "invite": invite,
            "expires": expires,
            "fingerprint": self.identity.public_dict()["fingerprint"],
        }

    def import_invite(self, code: str) -> Dict[str, Any]:
        invite = decode_invite(code)
        device = invite["device"]
        peer_id = str(device["id"])
        if peer_id == self.identity.device_id:
            raise PairingError("You cannot pair a device with itself.")
        peer_public = _unb64(device["x25519_pub"])
        secret = _unb64(invite["secret"])
        key = derive_pair_key(self.identity.x25519_private, peer_public, secret)
        with self._lock:
            self.peers[peer_id] = {
                "id": peer_id,
                "name": str(device.get("name", peer_id)),
                "x25519_pub": device["x25519_pub"],
                "ed25519_pub": device["ed25519_pub"],
                "key": _b64(key),
                "paired_at": int(time.time()),
                "last_seen": int(time.time()),
                "direction": "imported",
            }
            self._save_peers()
        handshake = self._build_handshake(peer_id, key)
        return {
            "peer": dict(self.peers[peer_id]),
            "handshake": handshake,
            "lan": invite.get("lan") or {},
        }

    def _build_handshake(self, peer_id: str, key: bytes) -> Dict[str, Any]:
        device = self.identity.public_dict()
        message_id = uuid.uuid4().hex
        timestamp = int(time.time())
        aad = {
            "v": PROTOCOL_VERSION,
            "type": "handshake",
            "from": self.identity.device_id,
            "to": peer_id,
            "id": message_id,
            "ts": timestamp,
            "device": device,
        }
        nonce, ciphertext = _seal(
            key, {"kind": "handshake", "name": self.identity.name}, aad
        )
        return {
            "v": PROTOCOL_VERSION,
            "type": "handshake",
            "from": self.identity.device_id,
            "to": peer_id,
            "id": message_id,
            "ts": timestamp,
            "device": device,
            "nonce": nonce,
            "ciphertext": ciphertext,
        }

    def accept_handshake(self, envelope: Dict[str, Any]) -> Dict[str, Any]:
        self._validate_envelope(envelope, allow_handshake=True)
        peer_id = str(envelope["from"])
        device = envelope.get("device") or {}
        if str(device.get("id") or "") != peer_id:
            raise PairingError("Handshake device id does not match its sender.")
        if not re.fullmatch(r"[A-Za-z0-9_-]{8,64}", peer_id):
            raise PairingError("Handshake has an invalid device id.")
        with self._lock:
            existing = self.peers.get(peer_id)
        if existing:
            return existing
        for item in list(self.pending):
            if int(item.get("expires", 0)) < int(time.time()):
                continue
            try:
                secret = _unb64(item["secret"])
                key = derive_pair_key(
                    self.identity.x25519_private,
                    _unb64(device["x25519_pub"]),
                    secret,
                )
                payload = _open(key, envelope)
                if payload.get("kind") != "handshake":
                    continue
            except Exception:
                continue
            peer = {
                "id": peer_id,
                "name": str(device.get("name", peer_id)),
                "x25519_pub": device["x25519_pub"],
                "ed25519_pub": device["ed25519_pub"],
                "key": _b64(key),
                "paired_at": int(time.time()),
                "last_seen": int(time.time()),
                "direction": "created",
            }
            with self._lock:
                self.peers[peer_id] = peer
                self.pending = [
                    entry for entry in self.pending if entry is not item
                ]
                self._save_peers()
                self._save_pending()
            self._log(f"Paired with {peer['name']} ({peer_id[:8]}).")
            return peer
        raise PairingError(
            "No pending invite matches this handshake, or the invite expired."
        )

    # -- envelopes ------------------------------------------------------
    def _validate_envelope(
        self, envelope: Dict[str, Any], *, allow_handshake: bool = False
    ) -> None:
        if not isinstance(envelope, dict):
            raise SecureShareError("Envelope is not an object.")
        if int(envelope.get("v", 0)) != PROTOCOL_VERSION:
            raise SecureShareError("Unsupported envelope version.")
        if envelope.get("to") != self.identity.device_id:
            raise SecureShareError("Envelope is addressed to another device.")
        kind = envelope.get("type")
        if kind == "handshake" and not allow_handshake:
            raise SecureShareError("Unexpected handshake.")
        if not kind or not envelope.get("from") or not envelope.get("id"):
            raise SecureShareError("Envelope is missing fields.")
        if not envelope.get("nonce") or not envelope.get("ciphertext"):
            raise SecureShareError("Envelope has no encrypted payload.")

    def _new_envelope(
        self, peer: Dict[str, Any], kind: str, payload: Dict[str, Any]
    ) -> Dict[str, Any]:
        key = _unb64(peer["key"])
        message_id = uuid.uuid4().hex
        timestamp = int(time.time())
        base = {
            "v": PROTOCOL_VERSION,
            "type": kind,
            "from": self.identity.device_id,
            "to": peer["id"],
            "id": message_id,
            "ts": timestamp,
        }
        nonce, ciphertext = _seal(key, payload, base)
        return {**base, "nonce": nonce, "ciphertext": ciphertext}

    def send_text(self, peer_id: str, text: str) -> Dict[str, Any]:
        peer = self._require_peer(peer_id)
        if not text:
            raise SecureShareError("Text is empty.")
        return self._new_envelope(peer, "text", {"kind": "text", "text": text})

    def send_file(self, peer_id: str, path: os.PathLike | str) -> Dict[str, Any]:
        peer = self._require_peer(peer_id)
        file_path = Path(path)
        if not file_path.is_file():
            raise SecureShareError(f"File not found: {file_path}")
        size = file_path.stat().st_size
        if size > MAX_FILE_BYTES:
            raise SizeLimitError(
                f"{file_path.name} is larger than the {MAX_FILE_BYTES // (1024*1024)} MB limit."
            )
        data = file_path.read_bytes()
        payload = {
            "kind": "file",
            "name": file_path.name,
            "size": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
            "data": _b64(data),
        }
        return self._new_envelope(peer, "file", payload)

    def send_folder(self, peer_id: str, folder: os.PathLike | str) -> Dict[str, Any]:
        peer = self._require_peer(peer_id)
        folder_path = Path(folder)
        if not folder_path.is_dir():
            raise SecureShareError(f"Folder not found: {folder_path}")
        buffer = io.BytesIO()
        total = 0
        with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(folder_path.rglob("*")):
                if path.is_symlink() or not path.is_file():
                    continue
                total += path.stat().st_size
                if total > MAX_FOLDER_BYTES:
                    raise SizeLimitError(
                        f"Folder exceeds the {MAX_FOLDER_BYTES // (1024*1024)} MB limit."
                    )
                archive.write(path, path.relative_to(folder_path).as_posix())
        data = buffer.getvalue()
        payload = {
            "kind": "folder",
            "name": folder_path.name,
            "size": total,
            "sha256": hashlib.sha256(data).hexdigest(),
            "data": _b64(data),
        }
        return self._new_envelope(peer, "folder", payload)

    def process_envelope(
        self, envelope: Dict[str, Any], *, save: bool = True
    ) -> Optional[Dict[str, Any]]:
        self._validate_envelope(envelope, allow_handshake=True)
        if envelope.get("type") == "handshake":
            peer = self.accept_handshake(envelope)
            item = {"kind": "handshake", "peer": peer}
            self._emit_received(item)
            return item
        peer_id = str(envelope["from"])
        peer = self.peers.get(peer_id)
        if peer is None:
            raise SecureShareError(
                f"Message from unpaired device {peer_id[:8]}…; pair it first."
            )
        payload = _open(_unb64(peer["key"]), envelope)
        message_id = str(envelope["id"])
        with self._lock:
            if message_id in self.seen:
                raise ReplayError("This message was already processed.")
        kind = str(payload.get("kind") or envelope.get("type"))
        if kind == "text":
            item = {
                "kind": "text",
                "id": message_id,
                "from": peer_id,
                "from_name": peer.get("name", peer_id),
                "ts": int(envelope.get("ts", time.time())),
                "text": str(payload.get("text", "")),
            }
        elif kind in ("file", "folder"):
            if not save:
                item = {
                    "kind": kind,
                    "id": message_id,
                    "from": peer_id,
                    "from_name": peer.get("name", peer_id),
                    "ts": int(envelope.get("ts", time.time())),
                    "name": str(payload.get("name", "data")),
                }
            else:
                item = self._save_payload(peer, envelope, payload)
        else:
            raise SecureShareError(f"Unknown payload kind: {kind!r}")

        with self._lock:
            self.seen[message_id] = time.time()
            self._save_seen()
            self.history.append(item)
            self._save_history()
            self.peers[peer_id]["last_seen"] = int(time.time())
            self._save_peers()
        self._emit_received(item)
        return item

    def _inbox_root(self) -> Path:
        if self.settings.inbox_dir:
            return Path(self.settings.inbox_dir).expanduser()
        return self.root / "inbox"

    def _save_payload(
        self,
        peer: Dict[str, Any],
        envelope: Dict[str, Any],
        payload: Dict[str, Any],
    ) -> Dict[str, Any]:
        kind = str(payload.get("kind"))
        name = _safe_name(str(payload.get("name") or ("received" if kind == "folder" else "file.bin")))
        data = _unb64(payload.get("data", ""))
        expected = str(payload.get("sha256") or "")
        if expected and hashlib.sha256(data).hexdigest() != expected:
            raise SecureShareError("Received payload failed its SHA256 check.")
        destination = self._inbox_root() / str(peer["id"])
        destination.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y%m%d-%H%M%S", time.localtime(int(envelope.get("ts", time.time()))))
        if kind == "file":
            target = _unique_path(destination / f"{stamp}-{name}")
            target.write_bytes(data)
            item = {
                "kind": "file",
                "id": str(envelope["id"]),
                "from": str(peer["id"]),
                "from_name": peer.get("name", peer["id"]),
                "ts": int(envelope.get("ts", time.time())),
                "name": name,
                "path": str(target),
                "size": len(data),
            }
        else:
            target = _unique_path(destination / f"{stamp}-{name}")
            target.mkdir(parents=True, exist_ok=True)
            _extract_zip_safe(data, target)
            item = {
                "kind": "folder",
                "id": str(envelope["id"]),
                "from": str(peer["id"]),
                "from_name": peer.get("name", peer["id"]),
                "ts": int(envelope.get("ts", time.time())),
                "name": name,
                "path": str(target),
                "size": len(data),
            }
        return item

    def _require_peer(self, peer_id: str) -> Dict[str, Any]:
        peer = self.peers.get(peer_id)
        if peer is None:
            raise SecureShareError("Unknown peer; pair the device first.")
        return peer

    # -- LAN ------------------------------------------------------------
    def start_lan(self) -> int:
        if self.lan is not None and self.lan.running:
            return self.lan.port
        self.lan = LanNode(
            self.identity,
            tcp_port=self.settings.lan_port,
            discovery_port=self.settings.discovery_port,
            on_envelope=self._lan_envelope,
            on_peers=self._emit_peers,
            on_log=self._log,
        )
        return self.lan.start()

    def stop_lan(self) -> None:
        if self.lan is not None:
            self.lan.stop()
            self.lan = None

    def _lan_envelope(
        self, envelope: Dict[str, Any], address: Tuple[str, int]
    ) -> Dict[str, Any]:
        try:
            self.process_envelope(envelope, save=True)
            return {"ok": True}
        except ReplayError as exc:
            return {"ok": True, "duplicate": True, "error": str(exc)}
        except Exception as exc:
            self._log(f"Rejected LAN envelope from {address[0]}: {exc}")
            return {"ok": False, "error": str(exc)}

    def send_lan(
        self, envelope: Dict[str, Any], host: str, port: int
    ) -> Dict[str, Any]:
        if self.lan is None or not self.lan.running:
            raise SecureShareError("LAN service is not running.")
        return self.lan.send(envelope, host, int(port))

    def send_via_peer(
        self, envelope: Dict[str, Any], peer: Dict[str, Any]
    ) -> Dict[str, Any]:
        online = self.lan.peers() if self.lan else {}
        info = online.get(peer["id"])
        if not info:
            raise SecureShareError(
                f"{peer.get('name', peer['id'])} is not visible on the LAN. "
                "Use the Git relay or a manual address."
            )
        return self.send_lan(envelope, info["host"], info["port"])

    # -- relay ----------------------------------------------------------
    def relay_client(self) -> RelayClient:
        return RelayClient(self.settings.relay)

    def send_relay(self, envelope: Dict[str, Any]) -> str:
        if not self.settings.relay.enabled:
            raise SecureShareError("The Git relay is disabled in Settings.")
        return self.relay_client().send(envelope)

    def poll_relay(self) -> List[Dict[str, Any]]:
        if not self.settings.relay.enabled:
            return []
        client = self.relay_client()
        received: List[Dict[str, Any]] = []
        for message in client.list_messages(self.identity.device_id):
            try:
                item = self.process_envelope(message["envelope"], save=True)
                if item is not None:
                    received.append(item)
                client.delete(message["path"], message["sha"])
            except ReplayError:
                client.delete(message["path"], message["sha"])
            except Exception as exc:
                self._log(f"Relay message rejected: {exc}")
        return received

    # -- history --------------------------------------------------------
    def clear_history(self) -> None:
        with self._lock:
            self.history = []
            self._save_history()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _safe_name(name: str) -> str:
    base = Path(str(name).replace("\\", "/")).name
    base = re.sub(r"[<>:\"/\\|?*\x00-\x1f]", "_", base).strip(" .")
    return base[:150] or "received"


def _unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    stem, suffix = path.stem, path.suffix
    for index in range(1, 1000):
        candidate = path.with_name(f"{stem}-{index}{suffix}")
        if not candidate.exists():
            return candidate
    return path.with_name(f"{stem}-{uuid.uuid4().hex[:8]}{suffix}")


def _extract_zip_safe(data: bytes, destination: Path) -> None:
    destination = destination.resolve()
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        total = 0
        for info in archive.infolist():
            name = info.filename.replace("\\", "/")
            path = PurePosixPath(name)
            if not name or name.startswith("__MACOSX/"):
                continue
            if path.is_absolute() or ".." in path.parts:
                raise SecureShareError(f"Unsafe path in folder archive: {name!r}")
            mode = (info.external_attr >> 16) & 0o170000
            if stat.S_ISLNK(mode):
                raise SecureShareError(f"Symlink in folder archive: {name!r}")
            total += int(info.file_size)
            if total > MAX_FOLDER_BYTES:
                raise SizeLimitError("Extracted folder exceeds the size limit.")
            target = (destination.joinpath(*path.parts)).resolve()
            if destination not in target.parents and target != destination:
                raise SecureShareError(f"Unsafe path in folder archive: {name!r}")
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info) as source, open(target, "wb") as output:
                shutil.copyfileobj(source, output)
