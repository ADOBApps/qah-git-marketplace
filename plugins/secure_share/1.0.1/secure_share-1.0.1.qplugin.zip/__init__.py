# secure_share/__init__.py
"""
Author: Acxel Orozco
Secure Share - encrypted text, file and folder exchange between QAH computers.

Two transports: LAN peer-to-peer (UDP discovery + encrypted TCP) and an
encrypted asynchronous Git relay.

This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

from __future__ import annotations

import importlib
import importlib.util
import logging
import sys
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QObject
from PySide6.QtGui import QAction, QIcon
from PySide6.QtWidgets import QWidget

try:
    from plugins.libs.plugin_manager import PluginInfo
except Exception:
    PluginInfo = object  # type: ignore

_PLUGIN_ID = "secure_share"


def _load_sibling(name: str):
    try:
        return importlib.import_module(f"{__name__}.{name}")
    except ImportError:
        path = Path(__file__).with_name(f"{name}.py")
        spec = importlib.util.spec_from_file_location(f"{__name__}_{name}", path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        return module


_core = _load_sibling("secure_share_core")


class SecureSharePlugin(QObject):
    def __init__(self, plugin_info: PluginInfo):
        super().__init__()
        self.plugin_info = plugin_info
        self.ui_widget: Optional[QWidget] = None
        self.icon: Optional[QIcon] = None
        self.service = None
        try:
            self.service = _core.SecureShareService()
        except Exception as exc:
            logging.error("Secure Share core could not start: %s", exc)
        icon_path = Path(__file__).parent / "icon.svg"
        if icon_path.is_file():
            self.icon = QIcon(str(icon_path))

    def initialize(self) -> bool:
        try:
            logging.info("Initializing Secure Share v%s", self.plugin_info.version)
            return self.service is not None
        except Exception as exc:
            logging.error("Secure Share initialization failed: %s", exc)
            return False

    def get_widget(self) -> Optional[QWidget]:
        if self.ui_widget is None:
            if self.service is None:
                return None
            try:
                ui = _load_sibling("secure_share_ui")
                self.ui_widget = ui.SecureShareWidget(self)
            except Exception as exc:
                logging.error("Could not build Secure Share UI: %s", exc)
                logging.debug("Traceback", exc_info=True)
                return None
        return self.ui_widget

    def get_menu_actions(self):
        action = QAction("Secure Share", self)
        if self.icon is not None:
            action.setIcon(self.icon)
        action.setToolTip("Encrypted text, file and folder exchange between QAH computers")
        return [action]

    def cleanup(self):
        if self.service is not None:
            try:
                self.service.stop_lan()
            except Exception:
                pass
        if self.ui_widget is not None:
            try:
                if hasattr(self.ui_widget, "cleanup"):
                    self.ui_widget.cleanup()
            finally:
                self.ui_widget.deleteLater()
                self.ui_widget = None


Plugin = SecureSharePlugin
