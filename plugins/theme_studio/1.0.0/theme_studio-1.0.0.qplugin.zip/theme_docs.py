"""Documentation HTML for Theme Studio."""

from __future__ import annotations

DOCS_HTML = """
<html><head><style>
body{font-family:'Segoe UI',Arial,sans-serif;font-size:10pt;color:#1f2937}
h1{font-size:17pt;color:#0f172a}h2{font-size:12.5pt;color:#1d4ed8;margin-top:16px}
h3{font-size:11pt;color:#111827;margin-top:12px}
code{background:#f3f4f6;padding:1px 3px}pre{background:#f3f4f6;padding:8px;border:1px solid #e5e7eb}
.muted{color:#6b7280}
</style></head><body>
<h1>Theme Studio</h1>
<p class="muted">Visual QAH theme builder with legacy compatibility.</p>

<h2>1. Backward compatibility</h2>
<p>Every exported theme still contains the original Theme Manager contract:</p>
<pre>theme.json
{
  "name": "My Theme",
  "author": "...",
  "version": "1.0.0",
  "description": "...",
  "css_file": "theme.css",
  "preview_color": "#1a1a2e"
}
theme.css</pre>
<p>Extended keys such as <code>id</code>, <code>tokens</code>, <code>font_family</code>
and <code>radius</code> are ignored by old Theme Manager versions. Existing
themes can be imported and re-exported without breaking.</p>

<h2>2. Design tab</h2>
<ul>
<li>Theme id, name, author, version and description.</li>
<li>Color tokens: background, surface, text, accent, border, hover, selection,
error, warning, success and code background.</li>
<li>Font family, font size and corner radius.</li>
<li>Import an existing <code>theme.json</code>.</li>
</ul>

<h2>3. Advanced CSS</h2>
<p>Edit the generated QSS directly. Custom CSS is preserved on export. Click
<b>Regenerate from tokens</b> to discard custom CSS and rebuild from colors and
typography.</p>

<h2>4. Preview</h2>
<p>A sample form, buttons, table and tabs are styled live with the generated
stylesheet. This is the same QSS written to <code>theme.css</code>.</p>

<h2>5. Export and publish</h2>
<ul>
<li><b>Export theme folder</b> — writes <code>theme.json</code>,
<code>theme.css</code>, <code>preview.svg</code> and <code>README.md</code>.</li>
<li><b>Export .qtheme.zip</b> — packaged theme for Git Marketplace.</li>
<li><b>Publish to Git Marketplace</b> — uses the configured Git Marketplace
repository and token; it publishes the theme under the catalog
<code>themes</code> section.</li>
</ul>

<h2>6. Installation in QAH</h2>
<p>Git Plugin Marketplace themes install flat into:</p>
<pre>%USERPROFILE%\\QAH\\themes\\
  &lt;theme_id&gt;.json
  &lt;theme_id&gt;.css</pre>
<p>Theme Manager reads <code>*.json</code> directly from that folder. The
marketplace installer writes the canonical filenames and refreshes Theme Manager
after installation; no QAH restart is required.</p>

<h2>7. Existing themes</h2>
<p>Old themes remain compatible. The marketplace also accepts a
<code>.qtheme.zip</code> whose root contains <code>theme.json</code> and the CSS
file named by <code>css_file</code>.</p>

</body></html>
"""
