"""PySide6 Theme Studio editor."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QColorDialog,
    QFileDialog,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSpinBox,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from . import theme_core as core
from .theme_docs import DOCS_HTML


class ThemeStudioWidget(QWidget):
    def __init__(self, plugin=None, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.spec = core.new_theme()
        self.custom_css = ""
        self._loading_css = False
        self._build_ui()
        self._populate(self.spec)
        self._refresh_preview()

    # -- UI --------------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        header = QHBoxLayout()
        title = QLabel("<b>Theme Studio</b>")
        title.setFont(QFont("Segoe UI", 15, QFont.Weight.Bold))
        header.addWidget(title)
        subtitle = QLabel("Legacy-compatible theme.json + theme.css · tokens · live preview · marketplace publishing")
        subtitle.setStyleSheet("color:#6b7280;")
        header.addWidget(subtitle, 1)
        self.status = QLabel("Ready")
        self.status.setStyleSheet("color:#6b7280;")
        header.addWidget(self.status)
        layout.addLayout(header)

        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, 1)
        self._build_design_tab()
        self._build_css_tab()
        self._build_preview_tab()
        self._build_export_tab()
        self._build_docs_tab()

    def _build_design_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        meta_box = QGroupBox("Theme metadata")
        form = QFormLayout(meta_box)
        self.id_edit = QLineEdit()
        self.name_edit = QLineEdit()
        self.author_edit = QLineEdit()
        self.version_edit = QLineEdit()
        self.description_edit = QLineEdit()
        form.addRow("Theme id:", self.id_edit)
        form.addRow("Name:", self.name_edit)
        form.addRow("Author:", self.author_edit)
        form.addRow("Version:", self.version_edit)
        form.addRow("Description:", self.description_edit)
        layout.addWidget(meta_box)

        color_box = QGroupBox("Color tokens")
        grid = QGridLayout(color_box)
        self.token_edits = {}
        self.token_buttons = {}
        for index, (key, label) in enumerate(core.TOKEN_LABELS.items()):
            row, col = divmod(index, 2)
            grid.addWidget(QLabel(label + ":"), row, col * 3)
            edit = QLineEdit()
            edit.setMaximumWidth(110)
            edit.textChanged.connect(lambda _text: self._design_changed())
            button = QPushButton()
            button.setFixedWidth(34)
            button.setToolTip("Pick color")
            button.clicked.connect(lambda _checked=False, k=key: self._pick_color(k))
            grid.addWidget(edit, row, col * 3 + 1)
            grid.addWidget(button, row, col * 3 + 2)
            self.token_edits[key] = edit
            self.token_buttons[key] = button
        layout.addWidget(color_box)

        style_box = QGroupBox("Typography and shape")
        style_form = QFormLayout(style_box)
        self.font_edit = QLineEdit()
        self.font_size = QSpinBox()
        self.font_size.setRange(6, 36)
        self.font_size.setSuffix(" pt")
        self.radius_spin = QSpinBox()
        self.radius_spin.setRange(0, 30)
        self.radius_spin.setSuffix(" px")
        for widget in (self.font_edit, self.font_size, self.radius_spin):
            try:
                widget.textChanged.connect(lambda _text: self._design_changed())
            except AttributeError:
                widget.valueChanged.connect(lambda _value: self._design_changed())
        style_form.addRow("Font family:", self.font_edit)
        style_form.addRow("Font size:", self.font_size)
        style_form.addRow("Corner radius:", self.radius_spin)
        layout.addWidget(style_box)

        row = QHBoxLayout()
        import_btn = QPushButton("Import theme…")
        import_btn.clicked.connect(self.import_theme)
        row.addWidget(import_btn)
        regenerate = QPushButton("Regenerate CSS from tokens")
        regenerate.clicked.connect(self.regenerate_css)
        row.addWidget(regenerate)
        row.addStretch(1)
        layout.addLayout(row)
        layout.addStretch(1)
        self.tabs.addTab(tab, "Design")

    def _build_css_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        note = QLabel(
            "Advanced QSS overrides. Editing this disables token regeneration until "
            "you click 'Regenerate from tokens'."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color:#6b7280;")
        layout.addWidget(note)
        self.css_edit = QPlainTextEdit()
        self.css_edit.setFont(QFont("Consolas", 9))
        self.css_edit.textChanged.connect(self._css_changed)
        layout.addWidget(self.css_edit, 1)
        row = QHBoxLayout()
        apply = QPushButton("Apply custom CSS")
        apply.clicked.connect(self.apply_custom_css)
        row.addWidget(apply)
        regenerate = QPushButton("Regenerate from tokens")
        regenerate.clicked.connect(self.regenerate_css)
        row.addWidget(regenerate)
        row.addStretch(1)
        layout.addLayout(row)
        self.tabs.addTab(tab, "Advanced CSS")

    def _build_preview_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        self.preview = QWidget()
        preview_layout = QVBoxLayout(self.preview)
        title = QLabel("Theme preview")
        title.setFont(QFont("Segoe UI", 14, QFont.Weight.Bold))
        preview_layout.addWidget(title)
        preview_layout.addWidget(QLabel("This is how labels, inputs, buttons and tables will look."))
        form = QHBoxLayout()
        form.addWidget(QLabel("Host:"))
        form.addWidget(QLineEdit("cluster.example.org"))
        form.addWidget(QLabel("User:"))
        form.addWidget(QLineEdit("alice"))
        preview_layout.addLayout(form)
        buttons = QHBoxLayout()
        buttons.addWidget(QPushButton("Connect"))
        buttons.addWidget(QPushButton("Cancel"))
        buttons.addWidget(QCheckBox("Remember me"))
        buttons.addStretch(1)
        preview_layout.addLayout(buttons)
        table = QTableWidget(3, 3)
        table.setHorizontalHeaderLabels(["Job", "State", "Time"])
        for row, values in enumerate((("run-01", "DONE", "00:12"), ("run-02", "RUN", "04:51"), ("run-03", "QUEUED", "--"))):
            for col, value in enumerate(values):
                table.setItem(row, col, QTableWidgetItem(value))
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        table.verticalHeader().setVisible(False)
        table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        preview_layout.addWidget(table, 1)
        tabs = QTabWidget()
        tabs.addTab(QLabel("First tab content"), "First")
        tabs.addTab(QLabel("Second tab content"), "Second")
        preview_layout.addWidget(tabs)
        layout.addWidget(self.preview, 1)
        self.tabs.addTab(tab, "Preview")

    def _build_export_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        intro = QLabel(
            "Export a legacy-compatible theme (theme.json + theme.css) or a "
            ".qtheme.zip for the marketplace. Existing Theme Manager reads both."
        )
        intro.setWordWrap(True)
        intro.setStyleSheet("color:#6b7280;")
        layout.addWidget(intro)
        row = QHBoxLayout()
        export_dir = QPushButton("Export theme folder…")
        export_dir.clicked.connect(self.export_folder)
        row.addWidget(export_dir)
        export_zip = QPushButton("Export .qtheme.zip…")
        export_zip.clicked.connect(self.export_zip)
        row.addWidget(export_zip)
        publish = QPushButton("Publish to Git Marketplace")
        publish.clicked.connect(self.publish_theme)
        row.addWidget(publish)
        row.addStretch(1)
        layout.addLayout(row)
        self.export_log = QPlainTextEdit()
        self.export_log.setReadOnly(True)
        self.export_log.setFont(QFont("Consolas", 9))
        layout.addWidget(self.export_log, 1)
        self.tabs.addTab(tab, "Export & Publish")

    def _build_docs_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        browser = QTextBrowser()
        browser.setHtml(DOCS_HTML)
        layout.addWidget(browser, 1)
        self.tabs.addTab(tab, "Documentation")

    # -- populate / spec -------------------------------------------------
    def _populate(self, spec):
        self.spec = spec
        self.id_edit.setText(spec.id)
        self.name_edit.setText(spec.name)
        self.author_edit.setText(spec.author)
        self.version_edit.setText(spec.version)
        self.description_edit.setText(spec.description)
        self.font_edit.setText(spec.font_family)
        self.font_size.setValue(spec.font_size)
        self.radius_spin.setValue(spec.radius)
        for key, edit in self.token_edits.items():
            edit.setText(spec.tokens.get(key, core.DEFAULT_TOKENS.get(key, "")))
            self._update_swatch(key)
        self._loading_css = True
        self.css_edit.setPlainText(spec.custom_css or core.generate_css(spec))
        self._loading_css = False
        self.custom_css = spec.custom_css

    def _spec_from_ui(self):
        spec = core.ThemeSpec(
            id=self.id_edit.text().strip() or "my_theme",
            name=self.name_edit.text().strip() or "My Theme",
            author=self.author_edit.text().strip(),
            version=self.version_edit.text().strip() or "1.0.0",
            description=self.description_edit.text().strip(),
            font_family=self.font_edit.text().strip() or "Segoe UI, Arial, sans-serif",
            font_size=int(self.font_size.value()),
            radius=int(self.radius_spin.value()),
            tokens={key: edit.text().strip() or core.DEFAULT_TOKENS[key] for key, edit in self.token_edits.items()},
            custom_css=self.custom_css,
        )
        spec.preview_color = spec.tokens.get("background", "#1a1a2e")
        return spec

    def _design_changed(self):
        self.custom_css = ""
        self._spec_from_ui()
        self._refresh_preview()
        self._update_swatches()

    def _update_swatches(self):
        for key in self.token_edits:
            self._update_swatch(key)

    def _update_swatch(self, key):
        value = self.token_edits[key].text().strip()
        color = QColor(value)
        if color.isValid():
            self.token_buttons[key].setStyleSheet(
                f"background-color: {value}; border: 1px solid #6b7280; border-radius: 4px;"
            )

    def _pick_color(self, key):
        current = QColor(self.token_edits[key].text().strip())
        color = QColorDialog.getColor(current if current.isValid() else QColor("#000000"), self)
        if color.isValid():
            self.token_edits[key].setText(color.name())

    def _css_changed(self):
        if self._loading_css:
            return
        self.custom_css = self.css_edit.toPlainText()
        self.spec = self._spec_from_ui()
        self.preview.setStyleSheet(self.custom_css)

    def apply_custom_css(self):
        self.custom_css = self.css_edit.toPlainText()
        self._refresh_preview()
        self.status.setText("Custom CSS applied")

    def regenerate_css(self):
        self.custom_css = ""
        self.spec = self._spec_from_ui()
        css = core.generate_css(self.spec)
        self._loading_css = True
        self.css_edit.setPlainText(css)
        self._loading_css = False
        self.preview.setStyleSheet(css)
        self.status.setText("CSS regenerated from tokens")

    def _refresh_preview(self):
        self.spec = self._spec_from_ui()
        css = self.custom_css or core.generate_css(self.spec)
        self.preview.setStyleSheet(css)
        if not self.custom_css:
            self._loading_css = True
            self.css_edit.setPlainText(css)
            self._loading_css = False
        self._update_swatches()

    # -- import / export -------------------------------------------------
    def import_theme(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Import theme", str(Path.home()), "Theme JSON (*.json);;All files (*)"
        )
        if not path:
            return
        try:
            spec = core.load_theme(Path(path))
        except Exception as exc:
            QMessageBox.critical(self, "Theme Studio", f"Could not load theme:\n{exc}")
            return
        self._populate(spec)
        self._refresh_preview()
        self.status.setText(f"Imported {path}")

    def _current_spec(self):
        self.spec = self._spec_from_ui()
        return self.spec

    def export_folder(self):
        directory = QFileDialog.getExistingDirectory(self, "Export theme folder")
        if not directory:
            return
        try:
            core.export_theme(self._current_spec(), Path(directory))
        except Exception as exc:
            QMessageBox.critical(self, "Theme Studio", f"Could not export:\n{exc}")
            return
        self._log(f"Theme folder written to {directory}")
        self.status.setText("Theme folder exported")

    def export_zip(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Export .qtheme.zip",
            str(Path.home() / f"{self._current_spec().id}-{self.spec.version}.qtheme.zip"),
            "QAH theme (*.qtheme.zip *.zip);;All files (*)",
        )
        if not path:
            return
        try:
            core.export_zip(self._current_spec(), Path(path))
        except Exception as exc:
            QMessageBox.critical(self, "Theme Studio", f"Could not export:\n{exc}")
            return
        self._log(f"Theme ZIP written to {path}")
        self.status.setText("Theme ZIP exported")

    def publish_theme(self):
        spec = self._current_spec()
        if not spec.id or not spec.version:
            QMessageBox.warning(self, "Theme Studio", "Theme id and version are required.")
            return
        try:
            with tempfile.TemporaryDirectory(prefix="theme-studio-") as temp:
                folder = Path(temp)
                core.export_theme(spec, folder)
                result = core.publish_theme_folder(folder, version=spec.version, changelog="Published from Theme Studio")
        except Exception as exc:
            QMessageBox.critical(self, "Theme Studio", f"Publish failed:\n{exc}")
            return
        self._log(json.dumps(result, indent=2, default=str))
        self.status.setText("Theme published")

    def _log(self, text):
        self.export_log.appendPlainText(str(text))
        bar = self.export_log.verticalScrollBar()
        bar.setValue(bar.maximum())

    def cleanup(self):
        pass
