#!/usr/bin/env python3
# wheel_plugin_manager/qah_wheel_cli.py
"""
Author: Acxel Orozco
Standalone terminal front-end for the QAH Wheel Plugin Manager.

This script does not import PySide6 or QAH. It can run with any Python 3 on the
machine (`py -3` on Windows) and installs a wheel into
``<QAH home>/plugins/wheels/<dist>`` by unpacking it, so it works even when the
Briefcase bundle has no ``python.exe``.

Examples
--------
    py -3 qah_wheel_cli.py doctor
    py -3 qah_wheel_cli.py list
    py -3 qah_wheel_cli.py install "C:\\path\\plugin-1.0.0-cp310-abi3-win_amd64.whl" --force
    py -3 qah_wheel_cli.py validate "C:\\path\\plugin-1.0.0-cp310-abi3-win_amd64.whl"
    py -3 qah_wheel_cli.py fix      "C:\\path\\test_wheel_plugin" --install
    py -3 qah_wheel_cli.py test     "C:\\path\\plugin-1.0.0-cp310-abi3-win_amd64.whl"
    py -3 qah_wheel_cli.py uninstall plugin_name
    py -3 qah_wheel_cli.py build   "C:\\path\\test_wheel_plugin"

This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

# The script directory is sys.path[0] when run directly; keep an explicit
# fallback for `python -c` / unusual wrappers.
_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

import installer_core as core  # noqa: E402


def _print_header(title: str) -> None:
    print()
    print(title)
    print("=" * len(title))


def _cmd_doctor(_args) -> int:
    print(core.doctor())
    return 0


def _cmd_paths(_args) -> int:
    print(core.paths_report())
    return 0


def _cmd_list(_args) -> int:
    print(core.format_installed_table())
    return 0


def _cmd_tags(args) -> int:
    tags = core.current_tags(limit=args.limit)
    for tag in tags:
        print(tag)
    return 0


def _cmd_info(args) -> int:
    target = Path(args.target).expanduser()
    if target.suffix.lower() == ".whl" or target.is_file():
        try:
            info = core.inspect_wheel(target)
        except Exception as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 1
        print(core.format_wheel_info(info))
        return 0

    installed = core.resolve_installed(args.target)
    if installed is None:
        print(f"error: not installed and not a wheel file: {args.target}", file=sys.stderr)
        return 1
    info = core.inspect_installed(installed)
    print(f"Path          : {info['path']}")
    print(f"Distribution  : {info.get('name')} {info.get('version')}")
    print(f"Summary       : {info.get('summary', '')}")
    print(f"Entry points  : {', '.join(info.get('plugin_ids') or []) or 'NONE'}")
    print(f"Native modules: {len(info.get('native_modules') or [])}")
    print(f"Broken        : {info.get('broken')}")
    print(f"Size          : {info.get('size')} bytes")
    for native in (info.get("native_modules") or [])[:20]:
        print(f"  native      : {native}")
    return 0


def _cmd_install(args) -> int:
    wheel = Path(args.wheel).expanduser()
    mode = "pip" if args.pip else "unpack"
    if args.deps:
        mode = "pip"
    try:
        result = core.install_wheel(
            wheel,
            target=Path(args.target).expanduser() if args.target else None,
            mode=mode,
            with_dependencies=args.deps,
            force=args.force,
            allow_broken=args.allow_broken,
            progress=print,
        )
    except Exception as exc:
        print(f"\nerror: {exc}", file=sys.stderr)
        return 1

    _print_header("Installed")
    print(result.to_text())
    core.activate_installed_wheels()
    print()
    print("Next: restart QAH, then Plugins -> Scan for new or removed plugins.")
    if not result.plugin_ids:
        print("Warning: no qah.plugins entry point was found; QAH will not list it.")
    return 0


def _cmd_test(args) -> int:
    wheel = Path(args.wheel).expanduser()
    report = core.verify_wheel(wheel, instantiate=args.instantiate)
    print(report.to_text())
    return 0 if report.success else 1


def _cmd_uninstall(args) -> int:
    ok, message = core.uninstall_wheel(args.target)
    print(message)
    if ok:
        print("Restart QAH to refresh the plugin list.")
    return 0 if ok else 1


def _cmd_inject(args) -> int:
    requirement = " ".join(args.requirements)
    try:
        result = core.inject_dependencies(
            requirement,
            target=args.target,
            no_deps=args.no_deps,
            progress=print,
        )
    except Exception as exc:
        print(f"\nerror: {exc}", file=sys.stderr)
        return 1
    _print_header("Injected")
    print(result.to_text())
    print()
    print(f"Activated: {core.activate_dependency_paths(args.target)}")
    if not args.no_verify:
        module = args.module or args.requirements[0].split("=")[0].split(">")[0].split("<")[0].replace("-", "_")
        check = core.verify_dependency(args.target, module)
        print()
        if check.get("ok"):
            print(
                f"Verified import: {module} "
                f"{check.get('version', '')} ({check.get('file', '')})"
            )
        else:
            print(f"Import check failed: {check.get('error', '')}", file=sys.stderr)
            return 1
    print()
    print("Restart QAH or reopen the plugin; dependency paths are added at startup.")
    return 0


def _cmd_deps(args) -> int:
    print(core.format_dependencies_table())
    return 0


def _cmd_deps_remove(args) -> int:
    try:
        print(core.remove_dependency(args.target, args.package or ""))
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    return 0


def _cmd_deps_verify(args) -> int:
    try:
        result = core.verify_dependency(args.target, args.module)
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, indent=2))
    return 0 if result.get("ok") else 1


def _cmd_deps_path(_args) -> int:
    print(core.dependencies_root())
    print(core.frozen_target_text())
    return 0


def _cmd_build(args) -> int:
    try:
        built = core.build_wheel(
            Path(args.project).expanduser(),
            out_dir=Path(args.out).expanduser() if args.out else None,
            progress=print,
        )
    except Exception as exc:
        print(f"\nerror: {exc}", file=sys.stderr)
        return 1
    _print_header("Built")
    print(built)
    try:
        info = core.inspect_wheel(built)
        print(core.format_wheel_info(info))
    except Exception:
        pass
    return 0


def _cmd_clean(args) -> int:
    root = core.wheels_dir(create=False)
    removed = 0
    if root.is_dir():
        for child in root.iterdir():
            if child.is_dir() and child.name.endswith(".staging"):
                if core._force_rmtree(child):
                    removed += 1
                    print(f"removed {child}")
    print(f"{removed} staging directorie(s) removed.")
    if getattr(args, "broken", False):
        broken = core.remove_broken_wheels()
        for path in broken:
            print(f"removed broken {path}")
        print(f"{len(broken)} broken wheel directorie(s) removed.")
    return 0


def _cmd_validate(args) -> int:
    wheel = Path(args.wheel).expanduser()
    try:
        info = core.inspect_wheel(wheel)
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    print(core.format_wheel_info(info))
    blocking = core.blocking_layout_problems(info)
    if blocking:
        print()
        print("INVALID: this wheel would install, but QAH could not import it.")
        return 1
    print()
    print("VALID: the entry point resolves to a package inside the wheel.")
    return 0


def _cmd_fix(args) -> int:
    target = Path(args.target).expanduser()
    wheel: Path | None = None
    project: Path | None = None
    try:
        if target.is_dir():
            project = target
        elif target.is_file():
            wheel = target
            print(core.format_wheel_info(core.inspect_wheel(wheel)))
            project = core.find_project_for_wheel(wheel)
            if project is None:
                print(
                    f"error: could not find pyproject.toml/Cargo.toml above {wheel}",
                    file=sys.stderr,
                )
                return 1
        else:
            print(f"error: not a wheel or project directory: {target}", file=sys.stderr)
            return 1

        print()
        print(f"Repairing and rebuilding {project}")
        built = core.build_wheel(
            project,
            out_dir=Path(args.out).expanduser() if args.out else None,
            repair=True,
            progress=print,
        )
    except Exception as exc:
        print(f"\nerror: {exc}", file=sys.stderr)
        return 1

    _print_header("Rebuilt")
    try:
        info = core.inspect_wheel(built)
        print(core.format_wheel_info(info))
        blocking = core.blocking_layout_problems(info)
    except Exception as exc:
        print(f"error: built wheel cannot be read: {exc}", file=sys.stderr)
        return 1
    if blocking:
        print("\nerror: the rebuilt wheel is still invalid.", file=sys.stderr)
        return 1

    if args.install:
        try:
            result = core.install_wheel(built, force=args.force, progress=print)
        except Exception as exc:
            print(f"\nerror: rebuild succeeded but install failed: {exc}", file=sys.stderr)
            return 1
        _print_header("Installed")
        print(result.to_text())
        core.activate_installed_wheels()
        print()
        print("Next: restart QAH, then Plugins -> Scan for new or removed plugins.")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="qah_wheel_cli.py",
        description="Install QAH wheel plugins without pip or python.exe (Windows-safe).",
    )
    parser.add_argument(
        "--qah-home",
        help="Override QAH's data root (default: %%USERPROFILE%%\\QAH or ~/QAH).",
    )
    parser.add_argument(
        "--wheels-dir",
        help="Override the wheel plugin directory (default: <QAH home>/plugins/wheels).",
    )
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("doctor", help="Diagnose the environment and installed wheels.")
    p.set_defaults(func=_cmd_doctor)

    p = sub.add_parser("paths", help="Show QAH and plugin directories.")
    p.set_defaults(func=_cmd_paths)

    p = sub.add_parser("list", help="List installed wheel plugins.")
    p.set_defaults(func=_cmd_list)

    p = sub.add_parser("tags", help="Show compatible platform tags for this Python.")
    p.add_argument("--limit", type=int, default=80)
    p.set_defaults(func=_cmd_tags)

    p = sub.add_parser("info", help="Show metadata for a .whl or an installed plugin.")
    p.add_argument("target")
    p.set_defaults(func=_cmd_info)

    p = sub.add_parser("install", help="Install a .whl into QAH (default: unpack, no pip).")
    p.add_argument("wheel")
    p.add_argument("--target", help="Install into this directory instead of wheels/<dist>.")
    p.add_argument("--deps", action="store_true", help="Also install dependencies (uses pip).")
    p.add_argument("--pip", action="store_true", help="Use pip instead of direct unpacking.")
    p.add_argument("--force", action="store_true", help="Install even if the wheel tag does not match.")
    p.add_argument(
        "--allow-broken",
        action="store_true",
        help="Install even if the entry-point module is missing from the wheel.",
    )
    p.set_defaults(func=_cmd_install)

    p = sub.add_parser(
        "validate", help="Check the wheel structure and entry-point target."
    )
    p.add_argument("wheel")
    p.set_defaults(func=_cmd_validate)

    p = sub.add_parser("test", help="Install into a temporary sandbox and import the plugin.")
    p.add_argument("wheel")
    p.add_argument("--instantiate", action="store_true", help="Also instantiate the plugin class.")
    p.set_defaults(func=_cmd_test)

    p = sub.add_parser("uninstall", help="Remove an installed wheel plugin.")
    p.add_argument("target", help="Distribution name, plugin id or directory.")
    p.set_defaults(func=_cmd_uninstall)

    p = sub.add_parser(
        "inject",
        help="Resolve and inject dependency wheels for QAH's frozen Python.",
    )
    p.add_argument(
        "requirements",
        nargs="+",
        help="One or more packages, e.g. psutil or 'pydft pyqint pylebedev'.",
    )
    p.add_argument(
        "--target",
        default="global",
        help="Dependency set name (default: global). Use a plugin id for a private set.",
    )
    p.add_argument(
        "--no-deps",
        action="store_true",
        help="Download only the named wheels and reuse QAH host packages.",
    )
    p.add_argument("--module", help="Module name to verify after injection.")
    p.add_argument("--no-verify", action="store_true", help="Skip the import check.")
    p.set_defaults(func=_cmd_inject)

    p = sub.add_parser("deps", help="List injected dependency sets.")
    p.set_defaults(func=_cmd_deps)

    p = sub.add_parser("deps-path", help="Show the dependency root and QAH target.")
    p.set_defaults(func=_cmd_deps_path)

    p = sub.add_parser("deps-remove", help="Remove an injected dependency set or package.")
    p.add_argument("target", help="Dependency set name, e.g. global or a plugin id.")
    p.add_argument("--package", help="Remove one package instead of the whole set.")
    p.set_defaults(func=_cmd_deps_remove)

    p = sub.add_parser("deps-verify", help="Verify that a module imports from a dependency set.")
    p.add_argument("target", help="Dependency set name.")
    p.add_argument("module", help="Module to import, e.g. psutil.")
    p.set_defaults(func=_cmd_deps_verify)

    p = sub.add_parser("build", help="Build a wheel from a plugin project (maturin/build/pip).")
    p.add_argument("project")
    p.add_argument("--out", help="Output directory (default: <project>/dist).")
    p.set_defaults(func=_cmd_build)

    p = sub.add_parser(
        "fix",
        help="Repair the maturin config, rebuild a project/wheel and optionally install it.",
    )
    p.add_argument("target", help="Plugin project directory or a .whl inside <project>/dist.")
    p.add_argument("--out", help="Output directory (default: <project>/dist).")
    p.add_argument("--install", action="store_true", help="Install the rebuilt wheel.")
    p.add_argument("--force", action="store_true", help="Force installation (tag mismatch).")
    p.set_defaults(func=_cmd_fix)

    p = sub.add_parser("clean", help="Remove leftover .staging directories.")
    p.add_argument(
        "--broken",
        action="store_true",
        help="Also remove installed wheel directories that cannot provide a plugin.",
    )
    p.set_defaults(func=_cmd_clean)

    return parser


def main(argv=None) -> int:
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

    parser = build_parser()
    args = parser.parse_args(argv)
    if getattr(args, "qah_home", None):
        os.environ["QAH_HOME"] = args.qah_home
    if getattr(args, "wheels_dir", None):
        os.environ["QAH_WHEELS_DIR"] = args.wheels_dir

    if not getattr(args, "func", None):
        parser.print_help()
        return 0
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
