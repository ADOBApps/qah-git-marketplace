# wheel_plugin_manager/installer_core.py
"""
Author: Acxel Orozco
Wheel Plugin Manager - Qt-free installation core for QAH wheel plugins.

This module is deliberately independent of QAH and of PySide6. It can be used
from the QAH plugin widget, from a plain terminal (`qah_wheel_cli.py`) and from
diagnostic scripts.

Why this exists
---------------
A Briefcase Windows bundle built without ``allow_subprocesses = true`` does not
ship ``python.exe``/``pythonw.exe``. QAH's built-in installer then falls back to
the GUI launcher, which is not an interpreter: ``pip install --target`` starts
another copy of the GUI (or exits 0 doing nothing), the staging directory stays
empty, and the plugin never appears.

The default install mode here does not call pip or any interpreter at all: a
wheel is a ZIP file, so it is validated, unpacked into a staging directory and
promoted atomically into ``<QAH home>/plugins/wheels/<dist>``. That works on
Windows, Linux and macOS without a compiler or ``python.exe``.

This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

QAH is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

from __future__ import annotations

import contextlib
import csv
import hashlib
import importlib
import io
import json
import os
import platform
import re
import shutil
import stat
import subprocess
import sys
import sysconfig
import tempfile
import time
import traceback
import zipfile
from dataclasses import dataclass, field
from email.parser import Parser
from pathlib import Path, PurePosixPath
from types import SimpleNamespace
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

APP_NAME = "QAH"
ENTRY_POINT_GROUP = "qah.plugins"
INSTALL_TIMEOUT = 900
BUILD_TIMEOUT = 1800
PROBE_MARKER = "@@QAH-WHEEL@@"
_STAGING_SUFFIX = ".staging"
_SKIP_DIRS = frozenset(
    {
        "__pycache__",
        ".git",
        ".hg",
        ".svn",
        "app_packages",
        "site-packages",
        "node_modules",
        "build",
        "dist",
        "target",
        ".venv",
        "venv",
        "include",
        "headers",
        "tests",
        "test",
        "docs",
        "documentation",
    }
)


class WheelError(RuntimeError):
    """Raised when a wheel cannot be validated, installed or removed."""


# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------


def qah_home() -> Path:
    """Return QAH's persistent data root.

    QAH 2.0.8 uses ``Path.home() / "QAH"`` on every packaging format. An
    explicit ``QAH_HOME`` (or ``QAH_WHEELS_DIR``) override is useful for tests
    and for unusual Windows builds.
    """
    override = os.environ.get("QAH_HOME")
    if override:
        return Path(override).expanduser().resolve()
    return Path.home() / APP_NAME


def plugins_root() -> Path:
    return qah_home() / "plugins"


def classic_plugins_dir(create: bool = True) -> Path:
    path = plugins_root() / "python_plugins"
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def wheels_dir(create: bool = True) -> Path:
    override = os.environ.get("QAH_WHEELS_DIR")
    path = Path(override).expanduser().resolve() if override else plugins_root() / "wheels"
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def paths_report() -> str:
    lines = [
        f"QAH home       : {qah_home()}",
        f"Plugins root   : {plugins_root()}",
        f"Classic plugins: {classic_plugins_dir(create=False)}",
        f"Wheel plugins  : {wheels_dir(create=False)}",
        f"Running Python : {sys.executable}",
        f"Python version : {sys.version.split()[0]}",
        f"Platform       : {sysconfig.get_platform()} ({platform.machine()})",
    ]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Wheel filename / tag handling
# ---------------------------------------------------------------------------


def canonicalize_name(name: str) -> str:
    """PEP 503-style canonical distribution name."""
    return re.sub(r"[-_.]+", "_", name).lower()


def parse_wheel_filename(wheel: os.PathLike | str) -> Dict[str, str]:
    """Split ``name-version(-build)?-py-abi-platform.whl``.

    The distribution name may contain hyphens, so the last three fields are
    taken as Python/ABI/platform and the remaining fields as name + version.
    """
    filename = Path(wheel).name
    if not filename.lower().endswith(".whl"):
        raise WheelError(
            f"'{filename}' is not a wheel. Only pre-built .whl files are accepted; "
            "QAH never compiles plugins on the user machine."
        )

    parts = filename[:-4].split("-")
    if len(parts) < 5:
        raise WheelError(f"Cannot parse wheel filename: {filename}")

    python_tag, abi_tag, platform_tag = parts[-3], parts[-2], parts[-1]
    rest = parts[:-3]

    build = ""
    if len(rest) >= 3 and re.match(r"^\d", rest[-1]):
        build = rest.pop()

    if len(rest) != 2:
        raise WheelError(
            f"Cannot parse wheel filename: {filename}\n"
            "Expected <distribution>-<version>[-<build>]-<python>-<abi>-<platform>.whl"
        )

    distribution, version = rest
    return {
        "distribution": distribution,
        "canonical": canonicalize_name(distribution),
        "version": version,
        "build": build,
        "python": python_tag,
        "abi": abi_tag,
        "platform": platform_tag,
        "filename": filename,
    }


def _expand_tag_field(field_value: str) -> List[str]:
    return [part for part in field_value.split(".") if part]


def wheel_tag_set(info: Dict[str, str]) -> List[Tuple[str, str, str]]:
    return [
        (py, abi, plat)
        for py in _expand_tag_field(info["python"])
        for abi in _expand_tag_field(info["abi"])
        for plat in _expand_tag_field(info["platform"])
    ]


def _packaging_tag_set() -> Optional[set]:
    try:
        from packaging.tags import sys_tags

        return {str(tag) for tag in sys_tags()}
    except Exception:
        return None


def _manual_platform_ok(tag: str) -> bool:
    if tag in ("any", "none"):
        return True

    current = sysconfig.get_platform().lower().replace("-", "_").replace(".", "_")
    machine = platform.machine().lower()
    if machine in ("amd64", "x86_64"):
        machine = "x86_64"
    elif machine in ("aarch64", "arm64"):
        machine = "arm64"

    tag = tag.lower()
    if sys.platform.startswith("win"):
        expected = {
            "x86_64": "win_amd64",
            "arm64": "win_arm64",
            "x86": "win32",
        }.get(machine, current)
        return tag in {expected, "win_amd64" if machine == "x86_64" else expected}

    if sys.platform == "darwin":
        if not tag.startswith("macosx_"):
            return False
        parts = tag.split("_")
        try:
            wanted = (int(parts[1]), int(parts[2]))
        except (IndexError, ValueError):
            return False
        release = platform.mac_ver()[0]
        try:
            current_version = tuple(int(x) for x in release.split(".")[:2])
        except ValueError:
            return True
        arch_ok = tag.endswith("_x86_64") and machine == "x86_64" or tag.endswith("_arm64") and machine == "arm64"
        return arch_ok and current_version >= wanted

    if sys.platform.startswith("linux"):
        if tag.startswith("manylinux") or tag.startswith("musllinux"):
            suffix = "x86_64" if machine == "x86_64" else machine
            return tag.endswith("_" + suffix)
        if tag.startswith("linux_"):
            return tag.endswith("_" + machine)
        return False

    return False


def _manual_python_ok(
    info: Dict[str, str], py_tag: str, abi_tag: str, target: Tuple[int, int]
) -> bool:
    if py_tag in ("py3", "py2.py3"):
        return True
    if py_tag.startswith("py") and py_tag[2:].isdigit():
        return int(py_tag[2:]) == target[0]

    match = re.match(r"^cp(\d)(\d+)$", py_tag)
    if match:
        wanted = (int(match.group(1)), int(match.group(2)))
        if wanted == target:
            return True
        # abi3 wheels are forward-compatible with newer CPython versions.
        return abi_tag == "abi3" and wanted <= target

    return False


_TARGET_PYTHON_CACHE: Optional[Tuple[int, int]] = None


def target_python_version() -> Tuple[int, int]:
    """Python version of the QAH bundle, not necessarily of this CLI process.

    On Windows the user may run `py -3` (for example 3.13) while QAH itself
    uses CPython 3.12. Wheel compatibility must be checked against the bundle,
    otherwise a valid `cp312` wheel is rejected by the CLI.
    """
    global _TARGET_PYTHON_CACHE
    if _TARGET_PYTHON_CACHE is not None:
        return _TARGET_PYTHON_CACHE

    override = os.environ.get("QAH_PYTHON_VERSION", "").strip()
    if override:
        match = re.match(r"^(\d+)\.(\d+)", override)
        if match:
            _TARGET_PYTHON_CACHE = (int(match.group(1)), int(match.group(2)))
            return _TARGET_PYTHON_CACHE

    candidates: List[str] = []
    roots = _dedupe_paths(_app_search_roots())
    running_real_python = Path(sys.executable).name.lower().startswith("python")
    try:
        running_parent = Path(sys.executable).resolve().parent
    except OSError:
        running_parent = None

    preferred = [
        root
        for root in roots
        if re.search(r"quantum|qah", str(root), re.I)
        or root.name in ("app", "QuantumHelper")
    ]
    rest = [
        root
        for root in roots
        if root not in preferred and (not running_real_python or running_parent is None or root.resolve() != running_parent)
    ]
    for base in preferred + rest:
        try:
            candidates.extend(p.name for p in base.glob("python3*.dll"))
            candidates.extend(p.name for p in base.glob("python3.*"))
            candidates.extend(p.name for p in base.glob("bin/python3.*"))
            candidates.extend(p.name for p in base.glob("*/python3*.dll"))
            # Linux / macOS bundles
            candidates.extend(p.name for p in base.glob("libpython3*"))
            candidates.extend(p.name for p in base.glob("lib/libpython3*"))
            candidates.extend(
                p.name
                for p in base.glob(
                    "Contents/Frameworks/Python.framework/Versions/3.*"
                )
            )
            candidates.extend(p.name for p in base.glob("Versions/3.*"))
        except OSError:
            continue
    for name in candidates:
        match = re.search(r"python(\d)(?:\.)?(\d+)", name, re.I) or re.search(
            r"^(\d)\.(\d+)$", name
        )
        if match:
            _TARGET_PYTHON_CACHE = (int(match.group(1)), int(match.group(2)))
            return _TARGET_PYTHON_CACHE

    _TARGET_PYTHON_CACHE = (sys.version_info.major, sys.version_info.minor)
    return _TARGET_PYTHON_CACHE


def check_compatibility(info: Dict[str, str]) -> Tuple[bool, str]:
    """Return ``(compatible, human_reason)`` for the QAH interpreter."""
    tags = wheel_tag_set(info)
    target = target_python_version()
    packaging_tags = _packaging_tag_set()
    if packaging_tags is not None and target == (sys.version_info.major, sys.version_info.minor):
        for py, abi, plat in tags:
            if f"{py}-{abi}-{plat}" in packaging_tags:
                return True, "compatible"
        wanted = ", ".join(f"{py}-{abi}-{plat}" for py, abi, plat in tags)
        return (
            False,
            f"'{info['filename']}' targets [{wanted}], but this Python is "
            f"{sys.implementation.name} {sys.version.split()[0]} on "
            f"{sysconfig.get_platform()}.",
        )

    for py, abi, plat in tags:
        if _manual_python_ok(info, py, abi, target) and _manual_platform_ok(plat):
            return True, (
                "compatible (target Python "
                f"{target[0]}.{target[1]}, manual tag check)"
            )
    wanted = ", ".join(f"{py}-{abi}-{plat}" for py, abi, plat in tags)
    return (
        False,
        f"'{info['filename']}' targets [{wanted}], but QAH uses Python "
        f"{target[0]}.{target[1]} on {sysconfig.get_platform()}.",
    )


def current_tags(limit: int = 80) -> List[str]:
    tags = _packaging_tag_set()
    if tags is None:
        return ["(packaging is not installed; manual tag checks are used)"]
    ordered = list(tags)
    return ordered[:limit]


# ---------------------------------------------------------------------------
# Wheel inspection
# ---------------------------------------------------------------------------


def _read_metadata_from_zip(zf: zipfile.ZipFile, names: Sequence[str]) -> Dict[str, Any]:
    metadata_name = next((n for n in names if n.endswith(".dist-info/METADATA")), None)
    if metadata_name is None:
        return {}
    raw = zf.read(metadata_name).decode("utf-8", "replace")
    message = Parser().parsestr(raw)
    return {
        "name": message.get("Name", ""),
        "version": message.get("Version", ""),
        "summary": message.get("Summary", ""),
        "author": message.get("Author", "") or message.get("Author-email", ""),
        "requires_python": message.get("Requires-Python", ""),
        "license": message.get("License", ""),
        "requires": message.get_all("Requires-Dist") or [],
        "raw": raw,
    }


def _parse_entry_points_text(raw: str) -> Dict[str, List[Dict[str, str]]]:
    groups: Dict[str, List[Dict[str, str]]] = {}
    current: Optional[str] = None
    for line in raw.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or stripped.startswith(";"):
            continue
        if stripped.startswith("[") and stripped.endswith("]"):
            current = stripped[1:-1].strip()
            groups.setdefault(current, [])
            continue
        if current and "=" in stripped:
            name, value = stripped.split("=", 1)
            groups[current].append({"name": name.strip(), "value": value.strip()})
    return groups


def _read_entry_points_from_zip(zf: zipfile.ZipFile, names: Sequence[str]) -> Dict[str, List[Dict[str, str]]]:
    entry_name = next((n for n in names if n.endswith(".dist-info/entry_points.txt")), None)
    if entry_name is None:
        return {}
    return _parse_entry_points_text(zf.read(entry_name).decode("utf-8", "replace"))


def _read_manifest_from_zip(zf: zipfile.ZipFile, names: Sequence[str]) -> Dict[str, Any]:
    candidates = [n for n in names if n.endswith("/manifest.json")] or [n for n in names if n == "manifest.json"]
    # Prefer the shallowest manifest inside the plugin package.
    candidates.sort(key=lambda n: (n.count("/"), len(n)))
    for name in candidates:
        try:
            data = json.loads(zf.read(name).decode("utf-8", "replace"))
            if isinstance(data, dict):
                return data
        except Exception:
            continue
    return {}


_MATURIN_REBUILD_HINT = (
    "Rebuild it from its project with 'qah_wheel_cli.py fix <project>' (or the "
    "GUI 'Repair build...' button). The builder adds the maturin "
    "[tool.maturin] python-source/module-name settings that mixed Rust/Python "
    "projects need."
)


def entry_point_modules(info: Dict[str, Any]) -> List[Tuple[str, str]]:
    """Return ``(entry point name, top-level module)`` for every plugin entry."""
    modules: List[Tuple[str, str]] = []
    groups = info.get("entry_points") or {}
    for entry in groups.get(ENTRY_POINT_GROUP, []):
        value = str(entry.get("value", ""))
        module = value.split(":", 1)[0].strip()
        if not module:
            continue
        modules.append((str(entry.get("name", "")), module.split(".")[0]))
    return modules


def _wheel_has_module(members: Sequence[str], top: str) -> bool:
    """True if the wheel ships a top-level package directory or module."""
    prefix = top + "/"
    return any(
        member == prefix + "__init__.py"
        or member == top + ".py"
        or (
            member.startswith(prefix)
            and member.lower().endswith((".pyd", ".so", ".dylib"))
        )
        for member in members
    )


def wheel_layout_problems(info: Dict[str, Any]) -> List[Dict[str, str]]:
    """Structural checks that QAH's entry-point loader would trip over."""
    problems: List[Dict[str, str]] = []
    members = [str(m) for m in (info.get("members") or [])]
    modules = entry_point_modules(info)
    if not modules:
        problems.append(
            {
                "code": "no-entry-point",
                "message": (
                    f"no '{ENTRY_POINT_GROUP}' entry point; QAH will not list "
                    "this wheel"
                ),
                "hint": (
                    'Add [project.entry-points."qah.plugins"] to pyproject.toml.'
                ),
            }
        )
        return problems

    missing = [
        (name, module)
        for name, module in modules
        if not _wheel_has_module(members, module)
    ]
    for name, module in missing:
        problems.append(
            {
                "code": "missing-entry-module",
                "message": (
                    f"entry point '{name}' targets '{module}', but the wheel "
                    f"has no '{module}/' package or '{module}.py' module"
                ),
                "hint": _MATURIN_REBUILD_HINT,
            }
        )

    packages = [str(p) for p in (info.get("packages") or [])]
    if missing and "_core" in packages and not any(
        _wheel_has_module(members, module) for _, module in modules
    ):
        problems.append(
            {
                "code": "maturin-mixed-layout",
                "message": (
                    "the native extension is at the wheel root ('_core/') "
                    "instead of inside the plugin package; this is maturin's "
                    "default when [tool.maturin] python-source/module-name is "
                    "missing"
                ),
                "hint": _MATURIN_REBUILD_HINT,
            }
        )

    if not info.get("manifest"):
        problems.append(
            {
                "code": "missing-manifest",
                "message": "no manifest.json inside the wheel",
                "hint": (
                    "QAH still loads entry-point plugins, but a manifest "
                    "provides the display name and category."
                ),
            }
        )
    return problems


def blocking_layout_problems(info: Dict[str, Any]) -> List[Dict[str, str]]:
    """Problems that make the plugin impossible to import after installation."""
    return [
        problem
        for problem in (info.get("layout_problems") or [])
        if problem.get("code") == "missing-entry-module"
    ]


def validate_wheel(wheel: os.PathLike | str) -> Tuple[Dict[str, Any], List[Dict[str, str]]]:
    """Inspect *wheel* and return ``(info, layout problems)``."""
    info = inspect_wheel(wheel)
    return info, list(info.get("layout_problems") or [])


def inspect_wheel(wheel: os.PathLike | str) -> Dict[str, Any]:
    """Read metadata, entry points, manifest and native modules from a wheel."""
    wheel = Path(wheel)
    if not wheel.is_file():
        raise WheelError(f"File not found: {wheel}")

    info = parse_wheel_filename(wheel)
    try:
        with zipfile.ZipFile(wheel) as zf:
            bad = zf.testzip()
            if bad is not None:
                raise WheelError(f"Wheel archive is corrupt (first bad member: {bad})")
            names = zf.namelist()
            metadata = _read_metadata_from_zip(zf, names)
            entry_points = _read_entry_points_from_zip(zf, names)
            manifest = _read_manifest_from_zip(zf, names)
    except zipfile.BadZipFile as exc:
        raise WheelError(f"Wheel archive is corrupt: {exc}") from exc

    native = [
        n
        for n in names
        if n.lower().endswith((".pyd", ".so", ".dylib"))
        and not n.endswith((".dist-info/RECORD",))
    ]
    packages = sorted(
        {
            n.split("/", 1)[0]
            for n in names
            if "/" in n and not n.startswith(".") and not n.split("/", 1)[0].endswith(".dist-info")
        }
    )

    info.update(
        {
            "path": str(wheel),
            "size": wheel.stat().st_size,
            "metadata": metadata,
            "name": metadata.get("name") or info["distribution"],
            "summary": metadata.get("summary", ""),
            "author": metadata.get("author", ""),
            "requires": metadata.get("requires", []),
            "entry_points": entry_points,
            "plugin_ids": [e["name"] for e in entry_points.get(ENTRY_POINT_GROUP, [])],
            "manifest": manifest,
            "native_modules": native,
            "packages": packages,
            "has_entry_points": bool(entry_points.get(ENTRY_POINT_GROUP)),
            "members": names,
        }
    )
    compatible, reason = check_compatibility(info)
    info["compatible"] = compatible
    info["compatibility_reason"] = reason
    info["layout_problems"] = wheel_layout_problems(info)
    info["layout_ok"] = not blocking_layout_problems(info)
    return info


def _read_metadata_dir(directory: Path) -> Dict[str, Any]:
    dist_infos = sorted(directory.glob("*.dist-info"))
    if not dist_infos:
        return {}
    path = dist_infos[0]
    result: Dict[str, Any] = {"dist_info": str(path)}
    meta_path = path / "METADATA"
    if meta_path.is_file():
        try:
            message = Parser().parsestr(meta_path.read_text(encoding="utf-8", errors="replace"))
            result.update(
                {
                    "name": message.get("Name", ""),
                    "version": message.get("Version", ""),
                    "summary": message.get("Summary", ""),
                    "author": message.get("Author", "") or message.get("Author-email", ""),
                    "requires": message.get_all("Requires-Dist") or [],
                }
            )
        except Exception:
            pass
    ep_path = path / "entry_points.txt"
    if ep_path.is_file():
        try:
            result["entry_points"] = _parse_entry_points_text(
                ep_path.read_text(encoding="utf-8", errors="replace")
            )
        except Exception:
            result["entry_points"] = {}
    installer = path / "INSTALLER"
    if installer.is_file():
        result["installer"] = installer.read_text(encoding="utf-8", errors="replace").strip()
    return result


def _read_installed_manifest(directory: Path) -> Dict[str, Any]:
    candidates = list(directory.glob("*/manifest.json")) + [directory / "manifest.json"]
    candidates.sort(key=lambda p: (len(p.parts), str(p)))
    for candidate in candidates:
        if candidate.is_file():
            try:
                data = json.loads(candidate.read_text(encoding="utf-8", errors="replace"))
                if isinstance(data, dict):
                    return data
            except Exception:
                continue
    return {}


def inspect_installed(directory: os.PathLike | str) -> Dict[str, Any]:
    """Describe an already-installed wheel plugin directory."""
    directory = Path(directory)
    result: Dict[str, Any] = {
        "path": str(directory),
        "folder": directory.name,
        "name": directory.name,
        "version": "",
        "summary": "",
        "author": "",
        "entry_points": {},
        "plugin_ids": [],
        "native_modules": [],
        "broken": True,
        "size": 0,
        "modified": 0.0,
    }
    if not directory.is_dir():
        return result

    metadata = _read_metadata_dir(directory)
    manifest = _read_installed_manifest(directory)
    result.update({k: v for k, v in metadata.items() if k != "raw"})
    result["manifest"] = manifest
    result["name"] = metadata.get("name") or manifest.get("name") or directory.name
    result["version"] = metadata.get("version") or manifest.get("version", "")
    result["summary"] = metadata.get("summary") or manifest.get("description", "")
    result["author"] = metadata.get("author") or manifest.get("author", "")
    result["entry_points"] = metadata.get("entry_points", {})
    result["plugin_ids"] = [e["name"] for e in result["entry_points"].get(ENTRY_POINT_GROUP, [])]
    result["layout_problems"] = []
    for entry_name, module in entry_point_modules(result):
        if not (
            (directory / module / "__init__.py").is_file()
            or (directory / f"{module}.py").is_file()
        ):
            result["layout_problems"].append(
                {
                    "code": "missing-entry-module",
                    "message": (
                        f"entry point '{entry_name}' targets '{module}', but "
                        f"{directory} has no '{module}/' package or "
                        f"'{module}.py' module"
                    ),
                    "hint": _MATURIN_REBUILD_HINT,
                }
            )
    result["native_modules"] = [
        str(p.relative_to(directory))
        for p in directory.rglob("*")
        if p.is_file() and p.suffix.lower() in (".pyd", ".so", ".dylib")
    ]
    result["broken"] = (
        not bool(metadata.get("dist_info"))
        or not bool(result["plugin_ids"])
        or bool(result["layout_problems"])
    )

    total = 0
    newest = 0.0
    for path in directory.rglob("*"):
        try:
            if path.is_file():
                stat_result = path.stat()
                total += stat_result.st_size
                newest = max(newest, stat_result.st_mtime)
        except OSError:
            continue
    result["size"] = total
    result["modified"] = newest
    return result


def installed_wheels() -> List[Dict[str, Any]]:
    root = wheels_dir(create=False)
    if not root.is_dir():
        return []
    result = []
    for child in sorted(root.iterdir()):
        if not child.is_dir():
            continue
        if child.name.startswith(".") or child.name.endswith(_STAGING_SUFFIX):
            continue
        result.append(inspect_installed(child))
    return result


def remove_broken_wheels() -> List[str]:
    """Delete installed wheel directories that cannot provide a plugin."""
    removed: List[str] = []
    root = wheels_dir(create=False)
    if not root.is_dir():
        return removed
    for child in sorted(root.iterdir()):
        if not child.is_dir() or child.name.endswith(_STAGING_SUFFIX):
            continue
        info = inspect_installed(child)
        if info.get("broken") and _force_rmtree(child):
            removed.append(str(child))
    return removed


def resolve_installed(value: os.PathLike | str) -> Optional[Path]:
    """Find an installed wheel directory by path, distribution name or plugin id."""
    raw = str(value).strip().strip('"').strip("'")
    if not raw:
        return None
    root = wheels_dir(create=False)
    candidate = Path(raw).expanduser()
    if candidate.is_dir() and candidate.parent.resolve() == root.resolve():
        return candidate
    direct = root / raw
    if direct.is_dir():
        return direct
    wanted = canonicalize_name(raw)
    for child in root.iterdir() if root.is_dir() else []:
        if not child.is_dir() or child.name.endswith(_STAGING_SUFFIX):
            continue
        if canonicalize_name(child.name) == wanted:
            return child
        info = inspect_installed(child)
        if canonicalize_name(info.get("name", "")) == wanted:
            return child
        if wanted in {canonicalize_name(pid) for pid in info.get("plugin_ids", [])}:
            return child
    return None


# ---------------------------------------------------------------------------
# Removal helpers
# ---------------------------------------------------------------------------


def _force_rmtree(path: Path, attempts: int = 3) -> bool:
    """Remove a directory, coping with Windows read-only files and short locks."""
    path = Path(path)
    if not path.exists():
        return True

    def handler(func, target, exc):
        try:
            os.chmod(target, stat.S_IWRITE | stat.S_IREAD | stat.S_IEXEC)
        except OSError:
            pass
        try:
            func(target)
        except OSError:
            pass

    for attempt in range(attempts):
        try:
            try:
                shutil.rmtree(path, onexc=handler)
            except TypeError:  # Python < 3.12
                shutil.rmtree(path, onerror=handler)
        except Exception:
            pass
        if not path.exists():
            return True
        time.sleep(0.25 * (attempt + 1))
    return not path.exists()


# ---------------------------------------------------------------------------
# Interpreter discovery (only needed for pip/deps/build; never for unpack)
# ---------------------------------------------------------------------------


def _dedupe_commands(commands: Iterable[Sequence[str]]) -> List[Tuple[str, ...]]:
    seen = set()
    result: List[Tuple[str, ...]] = []
    for command in commands:
        command = tuple(str(part) for part in command if str(part))
        if not command:
            continue
        key = os.path.normcase(" ".join(command))
        if key not in seen:
            seen.add(key)
            result.append(command)
    return result


def _registry_qah_locations() -> List[Path]:
    if os.name != "nt":
        return []
    try:
        import winreg
    except Exception:
        return []

    locations: List[Path] = []
    roots = [
        (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
    ]
    for hive, subkey in roots:
        try:
            with winreg.OpenKey(hive, subkey) as key:
                count = winreg.QueryInfoKey(key)[0]
                for index in range(count):
                    try:
                        child_name = winreg.EnumKey(key, index)
                        with winreg.OpenKey(key, child_name) as child:
                            try:
                                display = winreg.QueryValueEx(child, "DisplayName")[0]
                            except OSError:
                                continue
                            if not re.search(r"quantum|qah", str(display), re.I):
                                continue
                            try:
                                location = winreg.QueryValueEx(child, "InstallLocation")[0]
                            except OSError:
                                location = ""
                            if location:
                                locations.append(Path(location))
                    except OSError:
                        continue
        except OSError:
            continue
    return locations


def _registered_python_locations() -> List[Path]:
    if os.name != "nt":
        return []
    try:
        import winreg
    except Exception:
        return []

    locations: List[Path] = []
    roots = [
        (winreg.HKEY_CURRENT_USER, r"Software\Python\PythonCore"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\Python\PythonCore"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\WOW6432Node\Python\PythonCore"),
    ]
    for hive, subkey in roots:
        try:
            with winreg.OpenKey(hive, subkey) as key:
                count = winreg.QueryInfoKey(key)[0]
                for index in range(count):
                    try:
                        version = winreg.EnumKey(key, index)
                        with winreg.OpenKey(hive, subkey + "\\" + version + r"\InstallPath") as install:
                            try:
                                value = winreg.QueryValueEx(install, "ExecutablePath")[0]
                            except OSError:
                                value = winreg.QueryValueEx(install, "")[0]
                            if value:
                                locations.append(Path(value))
                    except OSError:
                        continue
        except OSError:
            continue
    return locations


def _app_search_roots() -> List[Path]:
    roots: List[Path] = []
    if sys.executable:
        # Only the launcher's own directory. Broad recursive walks (C:\, /usr)
        # are slow and can match unrelated files called "python3".
        roots.append(Path(sys.executable).resolve().parent)

    if os.name == "nt":
        roots.extend(_registry_qah_locations())
        for env_name in ("LOCALAPPDATA", "PROGRAMFILES", "PROGRAMFILES(X86)"):
            base = os.environ.get(env_name)
            if not base:
                continue
            base_path = Path(base)
            roots.append(base_path)
            for pattern in ("Programs/*Quantum*", "*Quantum*", "Programs/*QAH*", "*QAH*"):
                try:
                    roots.extend(base_path.glob(pattern))
                except OSError:
                    pass
            # MSI/Briefcase installs are often nested one level deeper under an
            # author/vendor folder, e.g.
            # %LOCALAPPDATA%\Programs\<author>\Quantum Analysis Helper
            try:
                for vendor in base_path.glob("Programs/*"):
                    if not vendor.is_dir():
                        continue
                    roots.extend(vendor.glob("*Quantum*"))
                    roots.extend(vendor.glob("*QAH*"))
            except OSError:
                pass
        local_programs = Path(os.environ.get("LOCALAPPDATA", "")) / "Programs"
        if local_programs.is_dir():
            try:
                roots.extend(
                    child
                    for child in local_programs.iterdir()
                    if child.is_dir() and re.search(r"quantum|qah", child.name, re.I)
                )
            except OSError:
                pass
    elif sys.platform == "darwin":
        for base in (Path("/Applications"), Path.home() / "Applications"):
            try:
                roots.extend(base.glob("Quantum*.app"))
                roots.extend(base.glob("QAH*.app"))
            except OSError:
                pass
    else:
        for path in (
            Path("/usr/lib/QuantumHelper"),
            Path("/usr/lib/quantumhelper"),
            Path("/opt/QuantumHelper"),
            Path("/opt/quantumhelper"),
            Path("/app"),
        ):
            if path.is_dir():
                roots.append(path)
        home = Path.home()
        for pattern in (
            "Applications/*Quantum*",
            "Applications/*QAH*",
            "opt/*Quantum*",
            ".local/opt/*Quantum*",
            ".local/opt/*QAH*",
            ".local/share/*Quantum*",
            ".local/share/*QAH*",
        ):
            try:
                roots.extend(home.glob(pattern))
            except OSError:
                pass
        appdir = os.environ.get("APPDIR")
        if appdir:
            roots.append(Path(appdir))
    return roots


def _find_python_files(root: Path, max_depth: int = 4, limit: int = 60) -> List[Path]:
    """Bounded search for an interpreter, pruning huge package directories."""
    root = Path(root)
    if not root.is_dir():
        return []
    names = {"python.exe", "python3.exe"} if os.name == "nt" else {"python3", "python"}
    found: List[Path] = []
    root_depth = len(root.parts)
    try:
        for dirpath, dirnames, filenames in os.walk(root):
            current = Path(dirpath)
            depth = len(current.parts) - root_depth
            dirnames[:] = [
                d
                for d in dirnames
                if d.lower() not in _SKIP_DIRS and not d.startswith(".")
            ]
            if depth >= max_depth:
                dirnames[:] = []
            for filename in filenames:
                if filename.lower() in names:
                    candidate = current / filename
                    if candidate.is_file() and os.access(candidate, os.X_OK):
                        found.append(candidate)
                        if len(found) >= limit:
                            return found
    except OSError:
        pass
    return found


def _find_named_file(root: Path, filename: str, max_depth: int = 6, limit: int = 10) -> List[Path]:
    """Bounded search for a specific file, pruning package/build directories."""
    root = Path(root)
    if not root.is_dir():
        return []
    found: List[Path] = []
    root_depth = len(root.parts)
    try:
        for dirpath, dirnames, filenames in os.walk(root):
            current = Path(dirpath)
            depth = len(current.parts) - root_depth
            dirnames[:] = [
                d
                for d in dirnames
                if d.lower() not in _SKIP_DIRS and not d.startswith(".")
            ]
            if depth >= max_depth:
                dirnames[:] = []
            if filename in filenames:
                candidate = current / filename
                if candidate.is_file():
                    found.append(candidate)
                    if len(found) >= limit:
                        return found
    except OSError:
        pass
    return found


def qah_runtime_roots() -> List[str]:
    """Paths that make ``import plugins`` and the QAH stack work in a child/test.

    Inside QAH ``plugins`` is already importable, so this is mostly for the
    standalone CLI's ``test`` command. It also adds ``app_packages`` so PySide6
    can be imported by a system Python that runs the CLI on Windows.
    """
    roots: List[str] = []
    seen = set()

    def add(path: Path) -> None:
        try:
            if not path or not path.is_dir():
                return
            key = os.path.normcase(str(path.resolve()))
        except OSError:
            return
        if key not in seen:
            seen.add(key)
            roots.append(str(path))

    for entry in sys.path:
        if not entry:
            continue
        path = Path(entry)
        if (path / "plugins" / "libs" / "plugin_manager.py").is_file():
            add(path)

    for env_name in ("QAH_SOURCE", "QAH_SOURCE_ROOT", "QAH_APP_DIR", "QAH_RUNTIME"):
        value = os.environ.get(env_name)
        if not value:
            continue
        path = Path(value)
        for candidate in (path, path / "src" / "QuantumHelper", path / "app", path / "app" / "QuantumHelper"):
            if (candidate / "plugins" / "libs" / "plugin_manager.py").is_file():
                add(candidate)
            if (candidate / "QuantumHelper" / "plugins" / "libs" / "plugin_manager.py").is_file():
                add(candidate / "QuantumHelper")

    for base in _dedupe_paths(_app_search_roots()):
        candidates = [
            base,
            base / "app",
            base / "app" / "QuantumHelper",
            base / "QuantumHelper",
            base / "src" / "QuantumHelper",
            # macOS Briefcase .app bundle
            base / "Contents" / "Resources",
            base / "Contents" / "Resources" / "app",
            base / "Contents" / "Resources" / "app" / "QuantumHelper",
            base / "Contents" / "MacOS",
        ]
        for candidate in candidates:
            if (candidate / "plugins" / "libs" / "plugin_manager.py").is_file():
                add(candidate)
            if (candidate / "QuantumHelper" / "plugins" / "libs" / "plugin_manager.py").is_file():
                add(candidate / "QuantumHelper")
        for app_packages in (
            base / "app_packages",
            base / "app" / "app_packages",
            base / "Contents" / "Resources" / "app_packages",
            base / "Contents" / "Resources" / "app" / "app_packages",
        ):
            if app_packages.is_dir():
                add(app_packages)
        try:
            for child in base.glob("*/app_packages"):
                add(child)
        except OSError:
            pass

    # Last resort: locate plugins/libs/plugin_manager.py in likely app roots.
    for base in _dedupe_paths(_app_search_roots()):
        for manager in _find_named_file(base, "plugin_manager.py", max_depth=6, limit=6):
            if manager.parent.name == "libs" and manager.parent.parent.name == "plugins":
                add(manager.parent.parent.parent)

    return roots


_UNRELATED_PYTHON_MARKERS = (
    "\\libreoffice\\",
    "\\openoffice\\",
    "\\blender\\",
    "\\qgis\\",
    "\\app_packages\\",
    "\\site-packages\\",
    "\\node_modules\\",
    "\\windowsapps\\",
    "\\cygwin64\\",
    "\\msys64\\",
    "\\git\\usr\\",
    "\\common files\\",
)


def _is_unrelated_python(path: os.PathLike | str) -> bool:
    """True for Python interpreters bundled inside unrelated applications."""
    text = os.path.normcase(str(path)).replace("/", "\\")
    return any(marker in text for marker in _UNRELATED_PYTHON_MARKERS)


def candidate_commands() -> List[Tuple[str, ...]]:
    """Ordered interpreter command prefixes, including external build Pythons."""
    commands: List[Tuple[str, ...]] = []

    override = os.environ.get("QAH_PYTHON")
    if override:
        commands.append((override,))

    if sys.executable and Path(sys.executable).name.lower().startswith("python"):
        commands.append((sys.executable,))
    base_executable = getattr(sys, "_base_executable", None)
    if base_executable and Path(base_executable).name.lower().startswith("python"):
        commands.append((base_executable,))

    directories: List[Path] = []
    for value in (sys.executable, sys.prefix, getattr(sys, "base_prefix", None)):
        if not value:
            continue
        path = Path(value)
        directories.append(path if path.is_dir() else path.parent)
        if path.is_dir():
            directories.append(path / ("Scripts" if os.name == "nt" else "bin"))

    if os.name == "nt":
        for env_name in ("LOCALAPPDATA", "PROGRAMFILES", "PROGRAMFILES(X86)"):
            base = os.environ.get(env_name)
            if not base:
                continue
            base_path = Path(base)
            try:
                directories.extend(base_path.glob("Python*/"))
                directories.extend(base_path.glob("Programs/Python/Python*/"))
            except OSError:
                pass
    else:
        directories.extend(
            Path(p)
            for p in (
                "/usr/bin",
                "/usr/local/bin",
                "/opt/homebrew/bin",
                "/run/host/usr/bin",
                "/run/host/usr/local/bin",
            )
        )
        home = Path.home()
        for root in (
            home / "anaconda3",
            home / "miniconda3",
            home / "miniforge3",
            home / ".local",
        ):
            directories.append(root)
            directories.append(root / "bin")
        for envs in (home / "anaconda3" / "envs", home / "miniconda3" / "envs"):
            if envs.is_dir():
                try:
                    for child in sorted(envs.iterdir()):
                        if not child.is_dir():
                            continue
                        directories.append(child)
                        directories.append(child / ("Scripts" if os.name == "nt" else "bin"))
                except OSError:
                    pass

    names = ("python.exe", "python3.exe") if os.name == "nt" else ("python3", "python")
    for directory in _dedupe_paths(directories):
        for name in names:
            candidate = directory / name
            if (
                candidate.is_file()
                and os.access(candidate, os.X_OK)
                and not _is_unrelated_python(candidate)
            ):
                commands.append((str(candidate),))

    if os.name == "nt":
        for registered in _registered_python_locations():
            if registered.is_file() and os.access(registered, os.X_OK):
                if not _is_unrelated_python(registered):
                    commands.append((str(registered),))
            elif registered.is_dir():
                for name in names:
                    candidate = registered / name
                    if (
                        candidate.is_file()
                        and os.access(candidate, os.X_OK)
                        and not _is_unrelated_python(candidate)
                    ):
                        commands.append((str(candidate),))

        py_launcher = shutil.which("py")
        if py_launcher:
            commands.append((py_launcher, "-3.12"))
            commands.append((py_launcher, "-3"))

    for directory in os.environ.get("PATH", "").split(os.pathsep):
        if not directory:
            continue
        for name in names:
            candidate = Path(directory) / name
            if (
                candidate.is_file()
                and os.access(candidate, os.X_OK)
                and not _is_unrelated_python(candidate)
            ):
                commands.append((str(candidate),))

    # Application-bundled interpreters are a last resort, and never a known
    # unrelated one such as LibreOffice's python-core.
    for root in _dedupe_paths(_app_search_roots()):
        for candidate in _find_python_files(root):
            if not _is_unrelated_python(candidate):
                commands.append((str(candidate),))

    return _dedupe_commands(commands)


def _dedupe_paths(paths: Iterable[Path]) -> List[Path]:
    seen = set()
    result = []
    for path in paths:
        try:
            key = os.path.normcase(str(Path(path).resolve()))
        except OSError:
            key = os.path.normcase(str(path))
        if key not in seen:
            seen.add(key)
            result.append(Path(path))
    return result


def probe_command(command: Sequence[str], *, timeout: int = 15, require_module: Optional[str] = None) -> Dict[str, Any]:
    """Run a candidate and prove it is a real interpreter, not the GUI launcher."""
    extra = ""
    if require_module:
        extra = f"\ntry:\n import {require_module}; _mod=True\nexcept Exception:\n _mod=False\n"
    code = f"""
import json, platform, sys, sysconfig
try:
    import pip
    _pip = getattr(pip, "__version__", "")
except Exception:
    _pip = ""
{extra}
info = {{
    "executable": sys.executable,
    "version": sys.version.split()[0],
    "prefix": sys.prefix,
    "base_prefix": getattr(sys, "base_prefix", ""),
    "platform": sysconfig.get_platform(),
    "machine": platform.machine(),
    "pip": _pip,
}}
if {bool(require_module)!r}:
    info["has_module"] = _mod
print({PROBE_MARKER!r} + json.dumps(info))
"""
    kwargs: Dict[str, Any] = {}
    if os.name == "nt":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
    try:
        completed = subprocess.run(
            list(command) + ["-c", code],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            **kwargs,
        )
    except Exception as exc:
        return {"ok": False, "command": list(command), "error": str(exc)}
    stdout = completed.stdout or ""
    if completed.returncode != 0 or PROBE_MARKER not in stdout:
        detail = (completed.stderr or stdout or "").strip()
        return {
            "ok": False,
            "command": list(command),
            "error": f"exit {completed.returncode}: {detail[-500:]}",
        }
    raw = stdout.split(PROBE_MARKER, 1)[1].strip()
    try:
        info = json.loads(raw)
    except Exception as exc:
        return {"ok": False, "command": list(command), "error": f"bad probe output: {exc}"}
    return {"ok": True, "command": list(command), "info": info}


_PROBE_CACHE: Dict[Tuple[bool, Optional[str], Optional[Tuple[int, int]]], Tuple[Optional[Tuple[str, ...]], Dict[str, Any]]] = {}


def find_python(
    *,
    require_pip: bool = False,
    require_module: Optional[str] = None,
    max_candidates: int = 25,
    prefer_version: Optional[Tuple[int, int]] = None,
) -> Tuple[Optional[Tuple[str, ...]], Dict[str, Any]]:
    """Return the first working interpreter command, or ``(None, {})``.

    When *prefer_version* is given, a candidate with that exact major.minor is
    preferred; the first other working candidate is used only as a fallback.
    This keeps wheel builds/installs aligned with the QAH bundle's Python.
    """
    key = (require_pip, require_module, prefer_version)
    if key in _PROBE_CACHE:
        return _PROBE_CACHE[key]

    fallback: Optional[Tuple[Optional[Tuple[str, ...]], Dict[str, Any]]] = None
    for command in candidate_commands()[:max_candidates]:
        probe = probe_command(command, require_module=require_module)
        if not probe.get("ok"):
            continue
        info = probe["info"]
        if require_pip and not info.get("pip"):
            continue
        if require_module and not info.get("has_module"):
            continue
        result = (command, info)
        if prefer_version is not None:
            version = str(info.get("version", ""))
            prefix = f"{prefer_version[0]}.{prefer_version[1]}."
            if not version.startswith(prefix):
                if fallback is None:
                    fallback = result
                continue
        _PROBE_CACHE[key] = result
        return result

    result = fallback or (None, {})
    _PROBE_CACHE[key] = result
    return result


def python_executable() -> Optional[str]:
    command, _info = find_python()
    return command[0] if command else None


def describe_runtime() -> str:
    launcher = Path(sys.executable)
    is_launcher = not launcher.name.lower().startswith("python")
    lines = [
        f"Python         : {sys.version.split()[0]} ({sys.implementation.name})",
        f"sys.executable : {sys.executable}",
        f"launcher       : {'yes (Briefcase stub)' if is_launcher else 'no'}",
        f"sys.prefix     : {sys.prefix}",
        f"base_prefix    : {getattr(sys, 'base_prefix', '')}",
        f"platform tag   : {sysconfig.get_platform()}",
        f"machine        : {platform.machine()}",
    ]
    if os.name == "nt" and is_launcher:
        sibling = launcher.parent / "python.exe"
        lines.append(f"python.exe     : {'present' if sibling.is_file() else 'MISSING (expected for allow_subprocesses=false)'}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Install / uninstall
# ---------------------------------------------------------------------------


@dataclass
class InstallResult:
    success: bool
    distribution: str
    version: str
    target: str
    mode: str
    plugin_ids: List[str] = field(default_factory=list)
    messages: List[str] = field(default_factory=list)

    def to_text(self) -> str:
        lines = [
            f"Installed {self.distribution} {self.version}",
            f"  target : {self.target}",
            f"  mode   : {self.mode}",
        ]
        if self.plugin_ids:
            lines.append(f"  plugin : {', '.join(self.plugin_ids)}")
        for message in self.messages:
            lines.append(f"  {message}")
        return "\n".join(lines)


def _wheel_member_parts(name: str) -> Tuple[str, ...]:
    """Map a wheel member path to its install path, including ``.data`` dirs."""
    parts = PurePosixPath(name).parts
    cleaned: List[str] = []
    for part in parts:
        if part in ("", "."):
            continue
        if part == ".." or part.startswith("/") or ":" in part:
            raise WheelError(f"Unsafe path in wheel: {name!r}")
        cleaned.append(part)

    if len(cleaned) >= 3 and cleaned[0].endswith(".data"):
        kind = cleaned[1].lower()
        rest = cleaned[2:]
        if kind in ("purelib", "platlib"):
            return tuple(rest)
        if kind == "scripts":
            return (("Scripts" if os.name == "nt" else "bin"),) + tuple(rest)
        if kind == "headers":
            return ("include",) + tuple(rest)
        if kind == "data":
            return tuple(rest)
    return tuple(cleaned)


def _unpack_wheel(wheel: Path, destination: Path, progress=None) -> int:
    destination = destination.resolve()
    count = 0
    with zipfile.ZipFile(wheel) as zf:
        members = zf.infolist()
        total = len(members)
        for index, member in enumerate(members, 1):
            relative = _wheel_member_parts(member.filename)
            if not relative:
                continue
            target = (destination.joinpath(*relative)).resolve()
            if target != destination and destination not in target.parents:
                raise WheelError(f"Unsafe path in wheel: {member.filename!r}")
            if member.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(member) as source, open(target, "wb") as output:
                shutil.copyfileobj(source, output)
            count += 1
            if progress and (index == total or index % 50 == 0):
                progress(f"  extracted {index}/{total} files")
    return count


def _pip_args(wheel: Path, target: Path, with_dependencies: bool) -> List[str]:
    args = [
        "install",
        "--target",
        str(target),
        "--only-binary=:all:",
        "--no-warn-script-location",
        "--disable-pip-version-check",
        "--no-input",
    ]
    if not with_dependencies:
        args.append("--no-deps")
    args.append(str(wheel.resolve()))
    return args


def _pip_install(wheel: Path, target: Path, *, with_dependencies: bool, progress=None) -> str:
    args = _pip_args(wheel, target, with_dependencies)
    command, info = find_python(require_pip=True, prefer_version=target_python_version())
    if command:
        if progress:
            progress(f"  pip via {info.get('executable', command[0])}")
        kwargs: Dict[str, Any] = {}
        if os.name == "nt":
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
        try:
            completed = subprocess.run(
                list(command) + ["-m", "pip"] + args,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=INSTALL_TIMEOUT,
                **kwargs,
            )
        except subprocess.TimeoutExpired as exc:
            raise WheelError(f"pip timed out after {INSTALL_TIMEOUT}s.") from exc
        if completed.returncode != 0:
            detail = (completed.stderr or completed.stdout or "").strip()
            raise WheelError(f"pip could not install '{wheel.name}':\n\n{detail[-3000:]}")
        return "pip (subprocess)"

    # No real interpreter exists (the Windows allow_subprocesses=false case).
    # pip is pure Python, so run it in this process. It only writes to --target.
    try:
        from pip._internal.cli.main import main as pip_main
    except Exception as exc:
        raise WheelError(
            "pip is not available in this QAH bundle and no external Python was "
            "found. Install the wheel with the default unpack mode instead "
            "(remove --deps / disable 'install dependencies')."
        ) from exc

    if progress:
        progress("  pip in-process (no python.exe in this bundle)")
    output = io.StringIO()
    saved_argv = list(sys.argv)
    saved_path = list(sys.path)
    try:
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
            try:
                code = pip_main(args)
            except SystemExit as exc:
                code = exc.code if isinstance(exc.code, int) else 1
    finally:
        sys.argv = saved_argv
        sys.path[:] = saved_path
    if code != 0:
        raise WheelError(f"pip could not install '{wheel.name}':\n\n{output.getvalue()[-3000:]}")
    return "pip (in-process)"


def _write_installer_marker(staging: Path) -> None:
    for dist_info in staging.glob("*.dist-info"):
        try:
            (dist_info / "INSTALLER").write_text(
                "qah-wheel-plugin-manager\n", encoding="utf-8"
            )
        except OSError:
            pass
        break


def install_wheel(
    wheel: os.PathLike | str,
    target: Optional[os.PathLike | str] = None,
    *,
    mode: str = "unpack",
    with_dependencies: bool = False,
    force: bool = False,
    allow_broken: bool = False,
    progress=None,
) -> InstallResult:
    """Install *wheel* into ``wheels/<dist>``.

    :param mode: ``"unpack"`` (default, no pip, Windows-safe) or ``"pip"``.
    :param with_dependencies: imply pip and resolve dependencies as wheels.
    :param force: install even when the wheel tag does not match this Python.
    :param allow_broken: install even if the entry-point module is missing.
    """
    wheel = Path(wheel).expanduser()
    info = inspect_wheel(wheel)
    if not info["compatible"] and not force:
        raise WheelError(
            info["compatibility_reason"]
            + "\n\nRebuild the wheel for this platform/Python, or pass --force only "
            "if you are certain it is compatible."
        )

    blocking = blocking_layout_problems(info)
    if blocking and not allow_broken:
        details = "\n".join(f"  - {p['message']}" for p in blocking)
        raise WheelError(
            "The wheel is structurally invalid and would install as a plugin "
            "that QAH cannot import:\n"
            f"{details}\n\n{_MATURIN_REBUILD_HINT}\n\n"
            "Pass --allow-broken only if you know the entry point resolves "
            "another way."
        )
    if progress:
        for problem in info.get("layout_problems") or []:
            if problem.get("code") != "missing-entry-module":
                progress(f"  warning: {problem['message']}")

    distribution = info["canonical"]
    if target is None:
        target = wheels_dir() / distribution
    target = Path(target)
    staging = target.with_name(target.name + _STAGING_SUFFIX)
    _force_rmtree(staging)
    staging.mkdir(parents=True, exist_ok=True)

    if with_dependencies:
        mode = "pip"
    mode = (mode or "unpack").lower()
    if mode not in ("unpack", "pip"):
        raise WheelError(f"Unknown install mode: {mode!r}")

    if progress:
        progress(f"Installing {info['filename']} ({info['name']} {info['version']})")
        if info["plugin_ids"]:
            progress(f"  entry point(s): {', '.join(info['plugin_ids'])}")
        else:
            progress("  warning: no 'qah.plugins' entry point; QAH will not discover it")

    try:
        if mode == "pip":
            used_mode = _pip_install(
                wheel, staging, with_dependencies=with_dependencies, progress=progress
            )
        else:
            if progress:
                progress("  unpacking wheel (no pip, no interpreter)")
            _unpack_wheel(wheel, staging, progress=progress)
            used_mode = "unpack"

        if not list(staging.glob("*.dist-info")):
            raise WheelError(
                "The wheel did not produce a .dist-info directory; the installation "
                "is incomplete."
            )
        _write_installer_marker(staging)

        _force_rmtree(target)
        target.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.replace(str(staging), str(target))
        except OSError as exc:
            raise WheelError(
                f"Could not promote the staging directory to {target}: {exc}\n"
                "Close QAH or any program using the plugin files and try again."
            ) from exc
    except Exception:
        _force_rmtree(staging)
        raise

    if progress:
        progress(f"Installed into {target}")
    return InstallResult(
        success=True,
        distribution=distribution,
        version=info["version"],
        target=str(target),
        mode=used_mode,
        plugin_ids=info["plugin_ids"],
    )


def uninstall_wheel(value: os.PathLike | str) -> Tuple[bool, str]:
    target = resolve_installed(value)
    if target is None:
        return False, f"Not installed: {value}"
    root = wheels_dir(create=False).resolve()
    try:
        if target.resolve().parent != root:
            return False, f"Refusing to remove a directory outside {root}: {target}"
    except OSError:
        return False, f"Could not resolve {target}"
    if _force_rmtree(target):
        return True, f"Removed {target}"
    return False, (
        f"Could not remove {target}. Close QAH first; a loaded .pyd/.so file is "
        "locked on Windows until the process exits."
    )


def activate_installed_wheels() -> List[str]:
    """Put every installed wheel directory on ``sys.path``."""
    added: List[str] = []
    for info in installed_wheels():
        path = info["path"]
        if path not in sys.path:
            sys.path.insert(0, path)
            added.append(path)
    if added:
        importlib.invalidate_caches()
    return added


# ---------------------------------------------------------------------------
# Dependency injection for the frozen QAH runtime
# ---------------------------------------------------------------------------

DEPENDENCY_MANIFEST = "qah_dependencies.json"
DEPENDENCY_ROOT_NAME = "vendor"


def dependencies_root(create: bool = True) -> Path:
    """Directory holding injected dependency sets for the QAH process."""
    path = plugins_root() / DEPENDENCY_ROOT_NAME
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def dependency_target_dir(target: str = "global", create: bool = True) -> Path:
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", str(target or "global")).strip("._")
    if name in ("", ".", ".."):
        name = "global"
    path = dependencies_root(create=create) / name
    return path


def frozen_platform_tag() -> str:
    """Wheel platform tag for the QAH bundle on this OS/CPU."""
    machine = platform.machine().lower()
    if os.name == "nt":
        return {
            "amd64": "win_amd64",
            "x86_64": "win_amd64",
            "arm64": "win_arm64",
            "aarch64": "win_arm64",
            "x86": "win32",
            "i386": "win32",
            "i686": "win32",
        }.get(machine, "win_amd64")
    if sys.platform == "darwin":
        return sysconfig.get_platform().replace("-", "_").replace(".", "_")
    if sys.platform.startswith("linux"):
        return {
            "x86_64": "linux_x86_64",
            "amd64": "linux_x86_64",
            "aarch64": "linux_aarch64",
            "arm64": "linux_aarch64",
            "armv7l": "linux_armv7l",
        }.get(machine, sysconfig.get_platform().replace("-", "_").replace(".", "_"))
    return sysconfig.get_platform().replace("-", "_").replace(".", "_")


def frozen_abi_tags() -> List[str]:
    major, minor = target_python_version()
    return [f"cp{major}{minor}", "abi3", "none"]


def frozen_target_text() -> str:
    major, minor = target_python_version()
    return (
        f"CPython {major}.{minor} / {frozen_platform_tag()} "
        f"(system Python {sys.version.split()[0]})"
    )


def _dependency_python(*, require_pip: bool) -> Tuple[Optional[Tuple[str, ...]], Dict[str, Any]]:
    command, info = find_python(
        require_pip=require_pip,
        prefer_version=target_python_version(),
    )
    if command is None:
        raise WheelError(
            "No real system Python was found. Dependency injection needs a "
            "system Python with pip to download wheels for QAH's frozen runtime."
        )
    if require_pip and not info.get("pip"):
        raise WheelError(
            f"The selected system Python ({info.get('executable')}) has no pip. "
            "Install pip or select another Python."
        )
    return command, info


def _same_target_runtime() -> bool:
    target = target_python_version()
    return target == (sys.version_info.major, sys.version_info.minor)


def _pip_download(requirement: str, cache: Path, progress=None) -> List[Path]:
    command, info = _dependency_python(require_pip=True)
    args = [
        "-m",
        "pip",
        "download",
        "--dest",
        str(cache),
        "--only-binary=:all:",
        "--prefer-binary",
        "--no-cache-dir",
        "--disable-pip-version-check",
        "--no-input",
        "--progress-bar",
        "off",
    ]
    if not _same_target_runtime():
        major, minor = target_python_version()
        args += [
            "--python-version",
            f"{major}.{minor}",
            "--implementation",
            "cp",
        ]
        for abi in frozen_abi_tags():
            args += ["--abi", abi]
        args += ["--platform", frozen_platform_tag()]
    args.append(requirement)

    if progress:
        progress(f"Resolving {requirement} for {frozen_target_text()}")
        progress(f"  pip via {info.get('executable', command[0] if command else '')}")
    kwargs: Dict[str, Any] = {}
    if os.name == "nt":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
    try:
        completed = subprocess.run(
            list(command) + args,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=INSTALL_TIMEOUT,
            **kwargs,
        )
    except subprocess.TimeoutExpired as exc:
        raise WheelError(f"pip download timed out after {INSTALL_TIMEOUT}s.") from exc
    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout or "").strip()
        raise WheelError(
            f"Could not resolve wheels for {requirement!r} targeting "
            f"{frozen_target_text()}:\n\n{detail[-4000:]}"
        )
    wheels = sorted(cache.glob("*.whl"))
    if not wheels:
        detail = (completed.stdout or completed.stderr or "").strip()
        raise WheelError(
            "pip did not download any wheel. A source distribution may be the "
            "only option; this feature only injects pre-built wheels.\n\n"
            + detail[-2000:]
        )
    return wheels


def _dist_info_name(path: Path) -> str:
    meta = path / "METADATA"
    if not meta.is_file():
        return ""
    try:
        message = Parser().parsestr(meta.read_text(encoding="utf-8", errors="replace"))
        return canonicalize_name(message.get("Name", ""))
    except Exception:
        return ""


def _remove_existing_distributions(directory: Path, incoming: set) -> None:
    """Remove old versions of incoming distributions, including RECORD files."""
    root = directory.resolve()
    for dist_info in list(directory.glob("*.dist-info")):
        name = _dist_info_name(dist_info)
        if not name or name not in incoming:
            continue
        record = dist_info / "RECORD"
        if record.is_file():
            try:
                with open(record, "r", encoding="utf-8", errors="replace", newline="") as handle:
                    for row in csv.reader(handle):
                        if not row:
                            continue
                        relative = row[0].replace("\\", "/")
                        if not relative or relative.startswith("/"):
                            continue
                        if ".." in PurePosixPath(relative).parts:
                            continue
                        file_path = (directory / relative).resolve()
                        try:
                            if file_path.is_file() and root in file_path.parents:
                                file_path.unlink()
                        except OSError:
                            pass
            except OSError:
                pass
        shutil.rmtree(dist_info, ignore_errors=True)


def _staging_packages(staging: Path) -> List[Dict[str, str]]:
    packages = []
    for dist_info in sorted(staging.glob("*.dist-info")):
        meta = dist_info / "METADATA"
        if not meta.is_file():
            continue
        try:
            message = Parser().parsestr(meta.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            continue
        name = message.get("Name", "")
        if not name:
            continue
        packages.append({
            "name": name,
            "canonical": canonicalize_name(name),
            "version": message.get("Version", ""),
            "summary": message.get("Summary", ""),
        })
    packages.sort(key=lambda item: item["canonical"])
    return packages


def _wheel_sha256(path: Path) -> str:
    hasher = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


@dataclass
class DependencyResult:
    success: bool
    target: str
    path: str
    packages: List[Dict[str, str]] = field(default_factory=list)
    wheels: List[Dict[str, Any]] = field(default_factory=list)
    mode: str = "system pip wheels"

    def to_text(self) -> str:
        lines = [
            f"Injected dependency set for {self.target}",
            f"  target : {self.path}",
            f"  mode   : {self.mode}",
        ]
        for package in self.packages:
            lines.append(
                f"  package: {package.get('name')} {package.get('version')}"
            )
        for wheel in self.wheels:
            lines.append(
                f"  wheel  : {wheel.get('filename')} "
                f"({wheel.get('sha256', '')[:16]}...)"
            )
        return "\n".join(lines)


def inject_dependencies(
    requirement: str,
    target: str = "global",
    *,
    progress=None,
    activate: bool = True,
) -> DependencyResult:
    """Resolve wheels with system pip for QAH's frozen Python and inject them.

    Wheels are downloaded with ``pip download --only-binary=:all:`` using the
    QAH target Python/platform tags, verified, and unpacked into
    ``<QAH home>/plugins/vendor/<target>``. No QAH rebuild and no modification
    of the installed application directory is performed.
    """
    requirement = str(requirement or "").strip()
    if not requirement:
        raise WheelError("Specify a package or requirement, for example: psutil")
    target_dir = dependency_target_dir(target, create=False)
    target_dir.parent.mkdir(parents=True, exist_ok=True)
    staging = target_dir.with_name(
        f".{target_dir.name}.staging-{int(time.time())}"
    )
    _force_rmtree(staging)
    cache = Path(tempfile.mkdtemp(prefix="qah-dependency-wheels-"))
    try:
        if target_dir.is_dir():
            shutil.copytree(target_dir, staging)
        else:
            staging.mkdir(parents=True, exist_ok=True)

        wheels = _pip_download(requirement, cache, progress=progress)
        incoming: set = set()
        wheel_records: List[Dict[str, Any]] = []
        for wheel in wheels:
            info = inspect_wheel(wheel)
            if not info["compatible"]:
                raise WheelError(
                    f"{wheel.name}: {info['compatibility_reason']}\n"
                    f"QAH target is {frozen_target_text()}."
                )
            incoming.add(canonicalize_name(info["name"]))
            wheel_records.append({
                "filename": wheel.name,
                "name": info["name"],
                "version": info["version"],
                "sha256": _wheel_sha256(wheel),
                "size": wheel.stat().st_size,
            })
            if progress:
                progress(
                    f"Installing {wheel.name} "
                    f"({info['name']} {info['version']})"
                )

        _remove_existing_distributions(staging, incoming)
        for wheel in wheels:
            _unpack_wheel(wheel, staging, progress=progress)

        packages = _staging_packages(staging)
        manifest_path = staging / DEPENDENCY_MANIFEST
        old_manifest: Dict[str, Any] = {}
        if manifest_path.is_file():
            try:
                old_manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            except Exception:
                old_manifest = {}
        old_by_name = {
            str(item.get("canonical") or canonicalize_name(item.get("name", ""))): item
            for item in (old_manifest.get("packages") or [])
            if isinstance(item, dict)
        }
        merged = dict(old_by_name)
        for package in packages:
            merged[package["canonical"]] = package
        manifest = {
            "format": 1,
            "target": target,
            "requirement": requirement,
            "python": f"{target_python_version()[0]}.{target_python_version()[1]}",
            "platform": frozen_platform_tag(),
            "updated": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "wheels": wheel_records,
            "packages": sorted(merged.values(), key=lambda item: item["canonical"]),
        }
        manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

        backup: Optional[Path] = None
        if target_dir.exists():
            backup = target_dir.with_name(
                f".{target_dir.name}.backup-{int(time.time())}"
            )
            _force_rmtree(backup)
            os.replace(target_dir, backup)
        try:
            os.replace(staging, target_dir)
        except OSError as exc:
            if backup and backup.exists() and not target_dir.exists():
                os.replace(backup, target_dir)
            raise WheelError(
                f"Could not activate dependency set at {target_dir}: {exc}"
            ) from exc
        if backup and backup.exists():
            _force_rmtree(backup)
        if activate:
            activate_dependency_paths(target)
        if progress:
            progress(f"Dependency set ready: {target_dir}")
        return DependencyResult(
            success=True,
            target=target,
            path=str(target_dir),
            packages=packages,
            wheels=wheel_records,
        )
    except Exception:
        _force_rmtree(staging)
        raise
    finally:
        _force_rmtree(cache)


def installed_dependencies(target: Optional[str] = None) -> List[Dict[str, Any]]:
    root = dependencies_root(create=False)
    if not root.is_dir():
        return []
    if target:
        candidates = [dependency_target_dir(target, create=False)]
    else:
        candidates = sorted(child for child in root.iterdir() if child.is_dir())
    result = []
    for path in candidates:
        manifest = path / DEPENDENCY_MANIFEST
        if not manifest.is_file():
            continue
        try:
            data = json.loads(manifest.read_text(encoding="utf-8"))
        except Exception:
            continue
        data["path"] = str(path)
        data["target"] = data.get("target") or path.name
        result.append(data)
    return result


def activate_dependency_paths(target: Optional[str] = None) -> List[str]:
    """Put injected dependency directories on ``sys.path`` for this process."""
    added: List[str] = []
    paths = [dependency_target_dir(target, create=False)] if target else [
        Path(item["path"]) for item in installed_dependencies()
    ]
    for path in paths:
        text = str(path)
        if path.is_dir() and text not in sys.path:
            sys.path.insert(0, text)
            added.append(text)
    if added:
        importlib.invalidate_caches()
    return added


def remove_dependency(target: str = "global", package: str = "") -> str:
    path = dependency_target_dir(target, create=False)
    root = dependencies_root(create=False).resolve()
    if not path.is_dir():
        raise WheelError(f"No dependency set for target {target!r}.")
    try:
        if path.resolve().parent != root:
            raise WheelError(f"Refusing to remove outside {root}: {path}")
    except OSError as exc:
        raise WheelError(f"Cannot resolve {path}: {exc}") from exc
    canonical = canonicalize_name(package)
    if package:
        removed = False
        for dist_info in list(path.glob("*.dist-info")):
            if _dist_info_name(dist_info) != canonical:
                continue
            record = dist_info / "RECORD"
            if record.is_file():
                with open(record, "r", encoding="utf-8", errors="replace", newline="") as handle:
                    for row in csv.reader(handle):
                        if not row:
                            continue
                        relative = row[0].replace("\\", "/")
                        if not relative or relative.startswith("/") or ".." in PurePosixPath(relative).parts:
                            continue
                        file_path = (path / relative).resolve()
                        try:
                            if file_path.is_file() and path.resolve() in file_path.parents:
                                file_path.unlink()
                        except OSError:
                            pass
            shutil.rmtree(dist_info, ignore_errors=True)
            removed = True
        if not removed:
            raise WheelError(f"{package!r} is not installed in {path}.")
        manifest = path / DEPENDENCY_MANIFEST
        if manifest.is_file():
            try:
                data = json.loads(manifest.read_text(encoding="utf-8"))
                data["packages"] = [
                    item for item in (data.get("packages") or [])
                    if canonicalize_name(item.get("name", "")) != canonical
                ]
                manifest.write_text(json.dumps(data, indent=2), encoding="utf-8")
            except Exception:
                pass
        for directory in sorted(
            (item for item in path.rglob("*") if item.is_dir()),
            key=lambda item: len(item.parts),
            reverse=True,
        ):
            try:
                directory.rmdir()
            except OSError:
                pass
        return f"Removed {package} from {path}"
    _force_rmtree(path)
    return f"Removed dependency set {path}"


def format_dependencies_table() -> str:
    items = installed_dependencies()
    if not items:
        return "No injected dependency sets."
    lines = [
        f"Injected dependency sets (QAH target: {frozen_target_text()})",
        "",
    ]
    for item in items:
        lines.append(f"[{item.get('target')}] {item.get('path')}")
        lines.append(
            f"  Python {item.get('python', '?')} / {item.get('platform', '?')}"
        )
        for package in item.get("packages") or []:
            lines.append(
                f"  - {package.get('name')} {package.get('version')}"
            )
    return "\n".join(lines)


def verify_dependency(target: str, module: str) -> Dict[str, Any]:
    path = dependency_target_dir(target, create=False)
    if not path.is_dir():
        raise WheelError(f"No dependency set for target {target!r}.")
    command, info = _dependency_python(require_pip=False)
    code = f"""
import json, sys
sys.path.insert(0, {str(path)!r})
try:
    import {module} as _module
    result = {{
        "ok": True,
        "module": {module!r},
        "version": getattr(_module, "__version__", ""),
        "file": getattr(_module, "__file__", ""),
    }}
except Exception as exc:
    result = {{
        "ok": False,
        "module": {module!r},
        "error": type(exc).__name__ + ": " + str(exc),
    }}
print("@@QAH-DEPENDENCY@@" + json.dumps(result))
"""
    kwargs: Dict[str, Any] = {}
    if os.name == "nt":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
    try:
        completed = subprocess.run(
            list(command) + ["-c", code],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=60,
            **kwargs,
        )
    except Exception as exc:
        return {"ok": False, "error": str(exc), "path": str(path)}
    marker = "@@QAH-DEPENDENCY@@"
    for line in (completed.stdout or "").splitlines():
        if line.startswith(marker):
            try:
                result = json.loads(line[len(marker):])
                result["path"] = str(path)
                result["python"] = info.get("executable", "")
                return result
            except Exception:
                break
    return {
        "ok": False,
        "error": (completed.stderr or completed.stdout or "import failed").strip()[-2000:],
        "path": str(path),
        "python": info.get("executable", ""),
    }


# ---------------------------------------------------------------------------
# Verification
# ---------------------------------------------------------------------------


@dataclass
class VerifyReport:
    wheel: str
    success: bool = True
    metadata: Dict[str, Any] = field(default_factory=dict)
    steps: List[Tuple[str, str]] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)

    def ok(self, message: str) -> None:
        self.steps.append(("ok", message))

    def skip(self, message: str) -> None:
        self.steps.append(("skip", message))

    def fail(self, message: str, detail: str = "") -> None:
        self.steps.append(("error", message))
        self.success = False
        self.errors.append(message if not detail else f"{message}\n{detail.strip()}")

    def to_text(self) -> str:
        lines = [f"Wheel: {Path(self.wheel).name}", "=" * 64]
        info = self.metadata
        for key in ("name", "version", "summary", "compatible", "native_modules", "plugin_ids"):
            value = info.get(key)
            if value:
                if isinstance(value, list):
                    value = ", ".join(str(v) for v in value)
                lines.append(f"  {key:<12}: {value}")
        lines.append("-" * 64)
        for status, message in self.steps:
            marker = {"ok": "[Ok]   ", "skip": "[Skip] ", "error": "[Error]"}.get(status, "[?]    ")
            lines.append(marker + " " + message)
        for error in self.errors:
            lines.extend(["", error])
        lines.append("-" * 64)
        lines.append("RESULT: PASSED" if self.success else "RESULT: FAILED")
        return "\n".join(lines)


def _remove_modules_under(root: Path) -> None:
    root_str = str(root.resolve())
    for name, module in list(sys.modules.items()):
        origin = getattr(module, "__file__", None)
        if origin and str(Path(origin).resolve()).startswith(root_str):
            sys.modules.pop(name, None)


def _missing_runtime_reason(traceback_text: str) -> str:
    """Explain an import failure caused by the test Python lacking QAH's stack."""
    match = re.search(r"ModuleNotFoundError: No module named '([^']+)'", traceback_text)
    if not match:
        return ""
    top = match.group(1).split(".")[0]
    if top in ("plugins", "PySide6", "shiboken6", "matplotlib", "numpy", "scipy", "pandas"):
        return (
            f"the QAH runtime module '{top}' is not importable from this Python. "
            "Installation is still valid; run 'test' from inside QAH (or use the "
            "plugin's Test button) for a full import check."
        )
    return ""


def verify_installed(
    target: os.PathLike | str,
    *,
    wheel: str = "",
    instantiate: bool = False,
    report: Optional[VerifyReport] = None,
) -> VerifyReport:
    target = Path(target)
    report = report or VerifyReport(wheel=str(wheel or target))
    added_paths: List[str] = []
    for root in reversed(qah_runtime_roots()):
        if root not in sys.path:
            sys.path.insert(0, root)
            added_paths.append(root)
    if str(target) not in sys.path:
        sys.path.insert(0, str(target))
        added_paths.append(str(target))
    importlib.invalidate_caches()
    try:
        try:
            from importlib.metadata import distributions

            installed = list(distributions(path=[str(target)]))
        except Exception as exc:
            report.fail("Could not read distribution metadata", str(exc))
            return report

        if not installed:
            report.fail(
                "No distribution found after install",
                f"Checked {target}",
            )
            return report

        entry_points = []
        for dist in installed:
            report.ok(f"Distribution: {dist.metadata.get('Name', '?')} {dist.version}")
            entry_points.extend(
                ep for ep in dist.entry_points if ep.group == ENTRY_POINT_GROUP
            )
        if not entry_points:
            report.fail(
                f"No '{ENTRY_POINT_GROUP}' entry point",
                "QAH discovers wheel plugins through that group.",
            )
            return report

        for entry_point in entry_points:
            report.ok(f"Entry point: {entry_point.name} -> {entry_point.value}")
            try:
                plugin_class = entry_point.load()
            except Exception:
                detail = traceback.format_exc(limit=12)
                reason = _missing_runtime_reason(detail)
                if reason:
                    report.skip(f"Could not import '{entry_point.name}': {reason}")
                else:
                    report.fail(f"Could not import '{entry_point.name}'", detail)
                continue
            report.ok(f"Imported class: {plugin_class!r}")
            if instantiate:
                try:
                    plugin_info = SimpleNamespace(
                        id=entry_point.name,
                        name=entry_point.name,
                        version="0.0.0",
                        author="",
                        description="",
                        plugin_type=SimpleNamespace(value="python"),
                        main_file="__init__.py",
                        icon=None,
                        category="",
                        dependencies=[],
                        config={},
                    )
                    instance = plugin_class(plugin_info)
                    if hasattr(instance, "initialize"):
                        instance.initialize()
                    report.ok("Instantiated plugin class and called initialize()")
                except Exception:
                    detail = traceback.format_exc(limit=12)
                    reason = _missing_runtime_reason(detail)
                    if reason:
                        report.skip(f"Could not instantiate '{entry_point.name}': {reason}")
                    else:
                        report.fail(
                            f"Could not instantiate '{entry_point.name}'", detail
                        )
        return report
    finally:
        for path in reversed(added_paths):
            try:
                sys.path.remove(path)
            except ValueError:
                pass
        _remove_modules_under(target)
        importlib.invalidate_caches()


def verify_wheel(
    wheel: os.PathLike | str, *, instantiate: bool = False
) -> VerifyReport:
    wheel = Path(wheel).expanduser()
    report = VerifyReport(wheel=str(wheel))
    try:
        info = inspect_wheel(wheel)
    except Exception as exc:
        report.fail("Wheel validation failed", str(exc))
        return report

    report.metadata = info
    if info["compatible"]:
        report.ok(f"Wheel is compatible ({info['name']} {info['version']})")
    else:
        report.fail("Wheel is not compatible with this Python", info["compatibility_reason"])

    if info["plugin_ids"]:
        report.ok(f"Declares entry point(s): {', '.join(info['plugin_ids'])}")
    else:
        report.fail(
            f"No '{ENTRY_POINT_GROUP}' entry point found",
            "QAH discovers plugins through that entry-point group.",
        )
        return report

    blocking = blocking_layout_problems(info)
    for problem in info.get("layout_problems") or []:
        if problem.get("code") == "missing-entry-module":
            report.fail(problem["message"], problem.get("hint", ""))
        else:
            report.skip(problem["message"])
    if blocking:
        return report

    sandbox = Path(tempfile.mkdtemp(prefix="qah-wheel-test-"))
    try:
        target = sandbox / info["canonical"]
        try:
            install_wheel(wheel, target=target, force=True)
            report.ok(f"Unpacked into isolated sandbox: {target}")
        except Exception as exc:
            report.fail("Install into sandbox failed", str(exc))
            return report
        return verify_installed(target, wheel=str(wheel), instantiate=instantiate, report=report)
    finally:
        _force_rmtree(sandbox)


# ---------------------------------------------------------------------------
# Building (optional; uses a real external Python/maturin)
# ---------------------------------------------------------------------------


def _toml_section(text: str, section: str) -> str:
    """Return the raw body of ``[section]`` from a TOML document."""
    pattern = re.compile(
        r"(?ms)^\[" + re.escape(section) + r"\]\s*$(.*?)(?=^\[|\Z)"
    )
    match = pattern.search(text)
    return match.group(1) if match else ""


def _toml_string(text: str, section: str, key: str) -> str:
    block = _toml_section(text, section)
    if not block:
        return ""
    match = re.search(
        r'(?m)^\s*' + re.escape(key) + r'\s*=\s*"([^"]*)"', block
    )
    return match.group(1).strip() if match else ""


def _detect_mixed_python_source(project: Path, pyproject_text: str) -> Tuple[str, str]:
    """Guess ``(python-source, package)`` for a maturin mixed project."""
    python_dir = project / "python"
    if python_dir.is_dir():
        preferred = canonicalize_name(
            _toml_string(pyproject_text, "project", "name")
        )
        candidates = sorted(
            child
            for child in python_dir.iterdir()
            if child.is_dir()
            and (child / "__init__.py").is_file()
            and not child.name.startswith((".", "_"))
        )
        for candidate in candidates:
            if canonicalize_name(candidate.name) == preferred:
                return "python", candidate.name
        if len(candidates) == 1:
            return "python", candidates[0].name
        return "python", ""
    if (project / "__init__.py").is_file():
        return ".", project.name
    return "", ""


def prepare_maturin_config(project: os.PathLike | str, *, progress=None) -> List[str]:
    """Add the ``[tool.maturin]`` settings a mixed Rust/Python project needs.

    Without ``python-source``/``module-name`` maturin builds a pure-Rust wheel:
    the extension lands at the wheel root as ``_core/`` and the ``qah.plugins``
    entry point cannot be imported. Returns the list of changes; the original
    ``pyproject.toml`` is backed up once as ``pyproject.toml.qah-bak``.
    """
    project = Path(project).expanduser()
    pyproject = project / "pyproject.toml"
    cargo = project / "Cargo.toml"
    if not (pyproject.is_file() and cargo.is_file()):
        return []

    text = pyproject.read_text(encoding="utf-8", errors="replace")
    cargo_text = cargo.read_text(encoding="utf-8", errors="replace")
    python_source, package = _detect_mixed_python_source(project, text)
    lib_name = _toml_string(cargo_text, "lib", "name") or _toml_string(
        cargo_text, "package", "name"
    ).replace("-", "_")
    if not package or not lib_name:
        return []
    if "." in lib_name:
        lib_name = lib_name.rsplit(".", 1)[-1]
    module_name = f"{package}.{lib_name}"

    header = re.search(r"(?m)^\[tool\.maturin\]\s*$", text)
    if header is None:
        block = ["[tool.maturin]"]
        if python_source and python_source != ".":
            block.append(f'python-source = "{python_source}"')
        block.append(f'module-name = "{module_name}"')
        block.append('features = ["pyo3/extension-module"]')
        new_text = text.rstrip() + "\n\n" + "\n".join(block) + "\n"
        changes = [f"added [tool.maturin] module-name = {module_name}"]
        if python_source and python_source != ".":
            changes.insert(0, f"added [tool.maturin] python-source = {python_source}")
    else:
        remaining = text[header.end():]
        end = re.search(r"(?m)^\[", remaining)
        section_end = header.end() + (end.start() if end else len(remaining))
        body = text[header.end():section_end]
        missing: List[str] = []
        if python_source and python_source != "." and "python-source" not in body:
            missing.append(f'python-source = "{python_source}"')
        if "module-name" not in body:
            missing.append(f'module-name = "{module_name}"')
        if "features" not in body:
            missing.append('features = ["pyo3/extension-module"]')
        if not missing:
            return []
        new_text = text[: header.end()] + "\n" + "\n".join(missing) + text[header.end():]
        changes = [f"added [tool.maturin] {line}" for line in missing]

    backup = pyproject.with_name(pyproject.name + ".qah-bak")
    try:
        if not backup.exists():
            shutil.copy2(pyproject, backup)
        pyproject.write_text(new_text, encoding="utf-8")
    except OSError as exc:
        raise WheelError(f"Could not update {pyproject}: {exc}") from exc
    if progress:
        for change in changes:
            progress("  " + change)
        progress(f"  backup: {backup.name}")
    return changes


def find_project_for_wheel(wheel: os.PathLike | str) -> Optional[Path]:
    """Walk up from a wheel (usually in ``<project>/dist``) to its project."""
    wheel = Path(wheel).expanduser().resolve()
    for directory in (wheel.parent, *wheel.parent.parents):
        if (directory / "pyproject.toml").is_file() or (
            directory / "Cargo.toml"
        ).is_file():
            return directory
        if directory.parent == directory:
            break
    return None


def _build_env() -> Dict[str, str]:
    env = os.environ.copy()
    extra = [
        Path.home() / ".cargo" / "bin",
        Path.home() / ".local" / "bin",
    ]
    if os.name == "nt":
        extra.append(Path(os.environ.get("USERPROFILE", str(Path.home()))) / ".cargo" / "bin")
    existing = env.get("PATH", "")
    env["PATH"] = os.pathsep.join(str(p) for p in extra) + os.pathsep + existing
    return env


def build_wheel(
    project: os.PathLike | str,
    out_dir: Optional[os.PathLike | str] = None,
    *,
    repair: bool = True,
    progress=None,
) -> Path:
    """Build a wheel with maturin/build/pip using an external Python.

    When *repair* is true, a mixed Rust/Python project that lacks
    ``[tool.maturin]`` settings is patched first (with a backup), and every
    produced wheel is validated; a malformed wheel is rejected and the next
    available build tool is tried.
    """
    project = Path(project).expanduser().resolve()
    if not project.is_dir():
        raise WheelError(f"Project directory not found: {project}")
    has_pyproject = (project / "pyproject.toml").is_file()
    has_cargo = (project / "Cargo.toml").is_file()
    if not has_pyproject and not has_cargo:
        raise WheelError(
            f"{project} has neither pyproject.toml nor Cargo.toml; not a plugin project."
        )

    if repair:
        prepare_maturin_config(project, progress=progress)

    output = Path(out_dir).expanduser().resolve() if out_dir else project / "dist"
    output.mkdir(parents=True, exist_ok=True)

    attempts: List[Tuple[str, List[str]]] = []

    # Prefer `python -m maturin` from a Python matching the QAH bundle. A bare
    # `maturin` executable may pick a different default Python and emit a
    # cp313 wheel for a cp312 QAH.
    build_python, build_info = find_python(
        require_module="maturin", prefer_version=target_python_version()
    )
    if build_python:
        attempts.append(
            (
                "python -m maturin",
                list(build_python)
                + ["-m", "maturin", "build", "--release", "--out", str(output)],
            )
        )

    maturin_candidates = [
        shutil.which("maturin"),
        str(Path.home() / ".cargo" / "bin" / "maturin"),
        str(Path.home() / ".cargo" / "bin" / "maturin.exe"),
    ]
    maturin_exe = next(
        (candidate for candidate in maturin_candidates if candidate and Path(candidate).is_file()),
        None,
    )
    if maturin_exe:
        attempts.append(("maturin", [maturin_exe, "build", "--release", "--out", str(output)]))

    py_build, _ = find_python(
        require_module="build", prefer_version=target_python_version()
    )
    if py_build:
        attempts.append(
            (
                "python -m build",
                list(py_build) + ["-m", "build", "--wheel", "--outdir", str(output)],
            )
        )

    py_pip, _ = find_python(
        require_pip=True, prefer_version=target_python_version()
    )
    if py_pip:
        attempts.append(
            (
                "python -m pip wheel",
                list(py_pip)
                + ["-m", "pip", "wheel", "--no-deps", "--wheel-dir", str(output), str(project)],
            )
        )

    if not attempts:
        raise WheelError(
            "No build tool found. Install maturin in a real Python "
            "(`py -3.12 -m pip install maturin`) or put maturin on PATH."
        )

    failures: List[str] = []
    kwargs: Dict[str, Any] = {}
    if os.name == "nt":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)

    for label, command in attempts:
        if progress:
            progress(f"Trying {label}: {' '.join(command)}")
        before_state = {
            path.resolve(): (path.stat().st_mtime_ns, path.stat().st_size)
            for path in output.glob("*.whl")
        }
        try:
            completed = subprocess.run(
                command,
                cwd=str(project),
                env=_build_env(),
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=BUILD_TIMEOUT,
                **kwargs,
            )
        except Exception as exc:
            failures.append(f"{label}: {exc}")
            continue

        # A rebuild often overwrites the previous wheel with the same name, so
        # compare each file's state instead of just looking for new names.
        candidates = [
            path
            for path in output.glob("*.whl")
            if before_state.get(path.resolve())
            != (path.stat().st_mtime_ns, path.stat().st_size)
        ]
        candidates.sort(key=lambda path: path.stat().st_mtime_ns)
        detail = (completed.stderr or completed.stdout or "").strip()

        if completed.returncode != 0:
            failures.append(
                f"{label}: exit {completed.returncode}; "
                + ("no new .whl produced; " if not candidates else "")
                + detail[-1200:]
            )
            continue
        if not candidates:
            failures.append(
                f"{label}: exit 0 but no new .whl was produced; " + detail[-800:]
            )
            continue

        built = Path(candidates[-1])
        try:
            built_info = inspect_wheel(built)
        except Exception as exc:
            failures.append(
                f"{label}: built {built.name}, but it cannot be read: {exc}"
            )
            continue

        blocking = blocking_layout_problems(built_info)
        if blocking:
            failures.append(
                f"{label}: built {built.name}, but the wheel is malformed:\n  "
                + "\n  ".join(problem["message"] for problem in blocking)
            )
            continue

        if progress:
            for problem in built_info.get("layout_problems") or []:
                progress(f"  warning: {problem['message']}")
            progress(f"Built {built.name}")
        return built

    raise WheelError(
        "Build failed:\n\n"
        + "\n\n".join(failures)
        + "\n\nIf a wheel was produced but rejected, the project layout is still "
        "wrong; check the [tool.maturin] section of pyproject.toml and the "
        "entry point in [project.entry-points.\"qah.plugins\"]."
    )


# ---------------------------------------------------------------------------
# Doctor
# ---------------------------------------------------------------------------


def doctor() -> str:
    lines: List[str] = []
    add = lines.append

    add("QAH Wheel Plugin Manager - doctor")
    add("=" * 64)
    add("")

    add("Runtime")
    add("-" * 64)
    for line in describe_runtime().splitlines():
        add("  " + line)
    add(f"  pip module    : {_module_version('pip')}")
    add(f"  packaging     : {_module_version('packaging')}")
    target = target_python_version()
    add(
        "  QAH target    : Python "
        f"{target[0]}.{target[1]} (detected from the QAH bundle; "
        "override with QAH_PYTHON_VERSION)"
    )
    add("")

    add("QAH paths")
    add("-" * 64)
    for line in paths_report().splitlines():
        add("  " + line)
    add(f"  writable      : {_is_writable(qah_home())}")
    add("")

    add("Interpreter candidates (first 12)")
    add("-" * 64)
    candidates = candidate_commands()
    if not candidates:
        add("  none found")
    for command in candidates[:12]:
        probe = probe_command(command, timeout=10)
        label = " ".join(command)
        if probe.get("ok"):
            info = probe["info"]
            add(
                f"  [Ok]   {label}\n"
                f"         version={info.get('version')} pip={info.get('pip') or 'no'} "
                f"exe={info.get('executable')}"
            )
        else:
            add(f"  [fail] {label}\n         {probe.get('error')}")

    real_command, real_info = find_python(require_pip=False)
    add("")
    add(f"Real interpreter: {' '.join(real_command) if real_command else 'NONE'}")
    if real_info:
        add(f"  version={real_info.get('version')} pip={real_info.get('pip') or 'no'}")
    add("")

    add("Windows-specific diagnosis")
    add("-" * 64)
    if os.name == "nt":
        launcher = Path(sys.executable)
        is_launcher = not launcher.name.lower().startswith("python")
        sibling = launcher.parent / "python.exe"
        add(f"  launcher detected        : {is_launcher}")
        add(f"  python.exe next to it    : {sibling.is_file()}")
        if is_launcher and not sibling.is_file():
            add("  -> This Briefcase bundle was built without allow_subprocesses=true,")
            add("     so python.exe/pythonw.exe are absent. QAH's built-in pip installer")
            add("     cannot work here. This plugin's default 'unpack' mode does not")
            add("     need them; use `install --force` (no --deps) and restart QAH.")
        elif is_launcher and sibling.is_file():
            add("  -> python.exe is present; pip mode can be used as a fallback.")
        else:
            add("  -> Running under a real Python; pip mode is available.")
    else:
        add("  not Windows; the default unpack mode works here too.")
    add("")

    add("Installed wheel plugins")
    add("-" * 64)
    wheels = installed_wheels()
    if not wheels:
        add("  none")
    for info in wheels:
        state = "BROKEN" if info.get("broken") else "ok"
        add(
            f"  [{state}] {info.get('name')} {info.get('version')}\n"
            f"         dir={info.get('path')}\n"
            f"         plugin_ids={info.get('plugin_ids') or 'NONE'} "
            f"native={len(info.get('native_modules') or [])}"
        )
        for problem in info.get("layout_problems") or []:
            add(f"         issue: {problem.get('message', '')}")
        if info.get("broken"):
            add("         fix: reinstall a valid wheel, or 'clean --broken' to remove it")
    add("")

    add("Build tools (optional)")
    add("-" * 64)
    add(f"  maturin on PATH : {shutil.which('maturin') or 'no'}")
    maturin_python, maturin_info = find_python(require_module="maturin")
    add(
        "  python + maturin: "
        + (" ".join(maturin_python) if maturin_python else "no")
        + (f" ({maturin_info.get('version')})" if maturin_info else "")
    )
    add("")

    add("Recommendation")
    add("-" * 64)
    add("  1. Use: qah_wheel_cli.py install <wheel.whl> --force")
    add("  2. Restart QAH, then Plugins -> Scan for new or removed plugins.")
    add("  3. If a wheel is rejected as structurally invalid, rebuild it:")
    add("     qah_wheel_cli.py fix <project-or-wheel> --install")
    add("  4. If the wheel targets another OS/architecture, rebuild it here:")
    if os.name == "nt":
        add("     py -3 -m maturin build --release --out dist")
    else:
        add("     python3 -m maturin build --release --out dist")
    return "\n".join(lines)


def _module_version(name: str) -> str:
    try:
        module = importlib.import_module(name)
        return getattr(module, "__version__", "present")
    except Exception:
        return "missing"


def _is_writable(path: Path) -> bool:
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / ".qah_write_test"
        probe.write_text("x", encoding="utf-8")
        probe.unlink()
        return True
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------


def format_installed_table() -> str:
    wheels = installed_wheels()
    if not wheels:
        return "No wheel plugins installed."
    lines = [
        f"{'DISTRIBUTION':<28} {'VERSION':<12} {'PLUGIN IDS':<28} STATE",
        "-" * 84,
    ]
    for info in wheels:
        lines.append(
            f"{str(info.get('name'))[:28]:<28} "
            f"{str(info.get('version'))[:12]:<12} "
            f"{','.join(info.get('plugin_ids') or [])[:28]:<28} "
            f"{'BROKEN' if info.get('broken') else 'ok'}"
        )
    return "\n".join(lines)


def format_wheel_info(info: Dict[str, Any]) -> str:
    lines = [
        f"File          : {info.get('filename', info.get('path', ''))}",
        f"Distribution  : {info.get('name')} {info.get('version')}",
        f"Canonical     : {info.get('canonical', canonicalize_name(str(info.get('name', ''))))}",
        f"Summary       : {info.get('summary', '')}",
        f"Author        : {info.get('author', '')}",
        f"Compatible    : {info.get('compatible')} ({info.get('compatibility_reason')})",
        f"Entry points  : {', '.join(info.get('plugin_ids') or []) or 'NONE'}",
        f"Native modules: {len(info.get('native_modules') or [])}",
        f"Requires      : {', '.join(info.get('requires') or []) or 'none'}",
    ]
    problems = info.get("layout_problems") or []
    if problems:
        blocking = blocking_layout_problems(info)
        lines.append("Layout        : " + ("INVALID" if blocking else "ok with warnings"))
        for problem in problems:
            lines.append(f"  issue       : {problem.get('message', '')}")
            hint = problem.get("hint")
            if hint:
                lines.append(f"                {hint}")
    else:
        lines.append("Layout        : OK")
    for native in (info.get("native_modules") or [])[:10]:
        lines.append(f"  native      : {native}")
    manifest = info.get("manifest") or {}
    if manifest.get("id"):
        lines.append(f"Manifest id   : {manifest.get('id')}")
    return "\n".join(lines)
