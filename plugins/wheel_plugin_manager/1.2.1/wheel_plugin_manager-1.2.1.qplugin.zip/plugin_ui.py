# wheel_plugin_manager/plugin_ui.py
"""
Author: Acxel Orozco
PySide6 user interface for the QAH Wheel Plugin Manager.

The widget is a small terminal: a wheel list, a log console, buttons and a
command line. Installation runs off the GUI thread because pip/dependency
installs can be slow; the default unpack mode is fast.

This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

from __future__ import annotations

import html
import importlib.util
import shlex
import sys
import traceback
from datetime import datetime
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QThread, QUrl, Qt, Signal
from PySide6.QtGui import QDesktopServices, QFontDatabase
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFileDialog,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSplitter,
    QVBoxLayout,
    QWidget,
)


def _load_core():
    """Import installer_core in package or standalone-plugin mode."""
    try:
        from . import installer_core as core  # type: ignore

        return core
    except Exception:
        path = Path(__file__).with_name("installer_core.py")
        spec = importlib.util.spec_from_file_location("wheel_plugin_manager_core", path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        return module


core = _load_core()


class _Task(QThread):
    log = Signal(str)
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, function, parent=None):
        super().__init__(parent)
        self._function = function

    def run(self):
        try:
            result = self._function(self.log.emit)
        except Exception:
            self.failed.emit(traceback.format_exc())
            return
        self.done.emit(result)


class _CommandLine(QLineEdit):
    history_up = Signal()
    history_down = Signal()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Up:
            self.history_up.emit()
            return
        if event.key() == Qt.Key_Down:
            self.history_down.emit()
            return
        super().keyPressEvent(event)


def _split_args(text: str):
    """Split a command line while preserving Windows backslashes."""
    try:
        tokens = shlex.split(text, posix=False)
    except ValueError:
        tokens = text.split()
    cleaned = []
    for token in tokens:
        if len(token) >= 2 and token[0] == token[-1] and token[0] in "\"'":
            token = token[1:-1]
        cleaned.append(token)
    return cleaned


class WheelManagerWidget(QWidget):
    """Main UI shown in a QAH tab."""

    def __init__(self, plugin=None, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self._task: Optional[_Task] = None
        self._history = []
        self._history_index = 0
        self.setAcceptDrops(True)
        self.setMinimumSize(860, 560)
        self._build_ui()
        self._refresh_header()
        self.refresh_list()
        self._log("Wheel Plugin Manager ready.")
        self._log("Type 'help' for commands, or use the buttons above.")

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        self.header = QLabel()
        self.header.setTextFormat(Qt.RichText)
        self.header.setWordWrap(True)
        self.header.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(self.header)

        path_row = QHBoxLayout()
        path_row.addWidget(QLabel("Wheel:"))
        self.path_edit = QLineEdit()
        self.path_edit.setPlaceholderText(
            "Path to a .whl built for this QAH (Windows: ...-cp310-abi3-win_amd64.whl)"
        )
        path_row.addWidget(self.path_edit, 1)
        browse = QPushButton("Browse...")
        browse.clicked.connect(self._browse_wheel)
        path_row.addWidget(browse)
        layout.addLayout(path_row)

        options_row = QHBoxLayout()
        self.deps_check = QCheckBox("Also install dependencies (uses pip)")
        self.deps_check.setToolTip(
            "Off by default. QAH plugins should rely on the host libraries "
            "(PySide6, numpy, ...). Enabling this requires pip and a real interpreter."
        )
        options_row.addWidget(self.deps_check)

        options_row.addWidget(QLabel("Mode:"))
        self.mode_combo = QComboBox()
        self.mode_combo.addItem("unpack (recommended, no pip/python.exe)", "unpack")
        self.mode_combo.addItem("pip (needs a real interpreter or in-process pip)", "pip")
        options_row.addWidget(self.mode_combo)
        options_row.addStretch(1)

        self.install_button = QPushButton("Install .whl...")
        self.install_button.clicked.connect(lambda: self._install())
        options_row.addWidget(self.install_button)

        self.test_button = QPushButton("Test .whl...")
        self.test_button.clicked.connect(lambda: self._test())
        options_row.addWidget(self.test_button)

        self.build_button = QPushButton("Build from project...")
        self.build_button.clicked.connect(lambda: self._build())
        options_row.addWidget(self.build_button)

        self.repair_button = QPushButton("Repair build...")
        self.repair_button.setToolTip(
            "Validate a wheel or project, add missing maturin mixed-project "
            "settings, rebuild and optionally install. Fixes the '_core/ at the "
            "wheel root' layout that makes an entry point unimportable."
        )
        self.repair_button.clicked.connect(lambda: self._fix())
        options_row.addWidget(self.repair_button)
        layout.addLayout(options_row)

        dep_box = QGroupBox("Dependency injection into QAH's frozen Python")
        dep_layout = QVBoxLayout(dep_box)
        dep_row = QHBoxLayout()
        dep_row.addWidget(QLabel("Package:"))
        self.dep_package = QLineEdit()
        self.dep_package.setPlaceholderText("psutil or 'psutil>=5.9'")
        dep_row.addWidget(self.dep_package, 1)
        dep_row.addWidget(QLabel("Target:"))
        self.dep_target = QLineEdit("global")
        self.dep_target.setToolTip(
            "Dependency set name. 'global' is activated for QAH at startup; a "
            "plugin id keeps a private vendor set."
        )
        self.dep_target.setMaximumWidth(140)
        dep_row.addWidget(self.dep_target)
        self.dep_inject_button = QPushButton("Inject")
        self.dep_inject_button.setToolTip(
            "Resolve pre-built wheels with system pip for QAH's Python/ABI and "
            "unpack them under <QAH home>/plugins/vendor. No QAH rebuild."
        )
        self.dep_inject_button.clicked.connect(self._inject_dependency)
        dep_row.addWidget(self.dep_inject_button)
        self.dep_list_button = QPushButton("List sets")
        self.dep_list_button.clicked.connect(self._list_dependencies)
        dep_row.addWidget(self.dep_list_button)
        dep_layout.addLayout(dep_row)

        dep_actions = QHBoxLayout()
        self.dep_info = QLabel(core.frozen_target_text())
        self.dep_info.setWordWrap(True)
        self.dep_info.setStyleSheet("color:#6b7280;")
        dep_actions.addWidget(self.dep_info, 1)
        self.dep_verify_button = QPushButton("Verify import")
        self.dep_verify_button.clicked.connect(self._verify_dependency)
        dep_actions.addWidget(self.dep_verify_button)
        self.dep_remove_pkg_button = QPushButton("Remove package")
        self.dep_remove_pkg_button.clicked.connect(lambda: self._remove_dependency(False))
        dep_actions.addWidget(self.dep_remove_pkg_button)
        self.dep_remove_set_button = QPushButton("Remove set")
        self.dep_remove_set_button.clicked.connect(lambda: self._remove_dependency(True))
        dep_actions.addWidget(self.dep_remove_set_button)
        dep_layout.addLayout(dep_actions)
        layout.addWidget(dep_box)

        splitter = QSplitter(Qt.Horizontal)
        layout.addWidget(splitter, 1)

        left = QGroupBox("Installed wheel plugins")
        left_layout = QVBoxLayout(left)
        self.list_widget = QListWidget()
        self.list_widget.setAlternatingRowColors(True)
        self.list_widget.currentItemChanged.connect(self._on_selection_changed)
        left_layout.addWidget(self.list_widget, 1)

        left_buttons = QHBoxLayout()
        refresh = QPushButton("Refresh")
        refresh.clicked.connect(self.refresh_list)
        left_buttons.addWidget(refresh)
        uninstall = QPushButton("Uninstall selected")
        uninstall.clicked.connect(self._uninstall)
        left_buttons.addWidget(uninstall)
        left_layout.addLayout(left_buttons)
        splitter.addWidget(left)

        right = QGroupBox("Console")
        right_layout = QVBoxLayout(right)
        self.console = QPlainTextEdit()
        self.console.setReadOnly(True)
        self.console.setLineWrapMode(QPlainTextEdit.NoWrap)
        try:
            font = QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont)
        except Exception:
            font = QFontDatabase.systemFont(QFontDatabase.FixedFont)
        font.setPointSize(10)
        self.console.setFont(font)
        right_layout.addWidget(self.console, 1)

        command_row = QHBoxLayout()
        command_row.addWidget(QLabel(">"))
        self.command = _CommandLine()
        self.command.setPlaceholderText("help | doctor | list | install <wheel> | test <wheel> | uninstall <name>")
        self.command.returnPressed.connect(self._execute_command)
        self.command.history_up.connect(self._history_previous)
        self.command.history_down.connect(self._history_next)
        self.command.installEventFilter(self)
        command_row.addWidget(self.command, 1)
        run = QPushButton("Run")
        run.clicked.connect(self._execute_command)
        command_row.addWidget(run)
        right_layout.addLayout(command_row)
        splitter.addWidget(right)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)

        bottom = QHBoxLayout()
        doctor = QPushButton("Doctor")
        doctor.clicked.connect(self._doctor)
        bottom.addWidget(doctor)
        open_folder = QPushButton("Open wheels folder")
        open_folder.clicked.connect(self._open_wheels_dir)
        bottom.addWidget(open_folder)
        rescan = QPushButton("Rescan QAH")
        rescan.clicked.connect(lambda: self._rescan())
        bottom.addWidget(rescan)
        clear = QPushButton("Clear console")
        clear.clicked.connect(self.console.clear)
        bottom.addWidget(clear)
        bottom.addStretch(1)
        self.status = QLabel("")
        bottom.addWidget(self.status)
        layout.addLayout(bottom)

    # -------------------------------------------------------------- helpers
    def _refresh_header(self):
        home = core.qah_home()
        wheels = core.wheels_dir(create=False)
        vendor = core.dependencies_root(create=False)
        self.header.setText(
            "<b>Wheel Plugin Manager</b><br>"
            f"QAH home: <code>{html.escape(str(home))}</code><br>"
            f"Wheels&nbsp;&nbsp;: <code>{html.escape(str(wheels))}</code><br>"
            f"Vendor&nbsp;&nbsp;: <code>{html.escape(str(vendor))}</code><br>"
            f"Target&nbsp;&nbsp;: {html.escape(core.frozen_target_text())}<br>"
            f"Runtime&nbsp;: {html.escape(sys.version.split()[0])} &mdash; "
            f"<code>{html.escape(sys.executable)}</code>"
        )

    def _log(self, message=""):
        text = str(message)
        if not text:
            self.console.appendPlainText("")
            return
        stamp = datetime.now().strftime("%H:%M:%S")
        lines = text.splitlines()
        for index, line in enumerate(lines):
            prefix = f"[{stamp}] " if index == 0 else "           "
            self.console.appendPlainText(prefix + line)
        scrollbar = self.console.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def _warn(self, title, message):
        QMessageBox.warning(self, title, message)

    def _selected_path(self) -> Optional[str]:
        item = self.list_widget.currentItem()
        if item is not None:
            return item.data(Qt.UserRole)
        return None

    def _target_from_ui(self) -> Optional[str]:
        text = self.path_edit.text().strip().strip('"').strip("'")
        if text:
            return text
        return self._selected_path()

    def _browse_wheel(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select a QAH plugin wheel", str(Path.home()), "Wheel files (*.whl);;All files (*)"
        )
        if path:
            self.path_edit.setText(path)
            self._log(f"Selected {path}")

    def refresh_list(self):
        self.list_widget.clear()
        try:
            wheels = core.installed_wheels()
        except Exception as exc:
            self._log(f"[Error] Could not list installed wheels: {exc}")
            return
        for info in wheels:
            name = info.get("name") or info.get("folder") or "?"
            version = info.get("version") or ""
            ids = ", ".join(info.get("plugin_ids") or [])
            broken = bool(info.get("broken"))
            label = f"{name} {version}".strip()
            if ids:
                label += f"  [{ids}]"
            if broken:
                label += "  (incomplete)"
            item = QListWidgetItem(label)
            item.setData(Qt.UserRole, info.get("path"))
            item.setToolTip(
                f"{info.get('path')}\n"
                f"entry points: {ids or 'NONE'}\n"
                f"native modules: {len(info.get('native_modules') or [])}\n"
                f"size: {info.get('size', 0)} bytes"
            )
            self.list_widget.addItem(item)
        self.status.setText(f"{len(wheels)} wheel plugin(s)")
        self._refresh_header()

    def _on_selection_changed(self, current, _previous):
        if current is None:
            return
        path = current.data(Qt.UserRole)
        if path:
            self.path_edit.setText(str(path))

    # -------------------------------------------------------- dependencies
    def _dependency_target(self) -> str:
        return self.dep_target.text().strip() or "global"

    def _inject_dependency(self):
        requirement = self.dep_package.text().strip().strip('"').strip("'")
        if not requirement:
            self._warn("No dependency", "Enter a package, for example: psutil")
            return
        target = self._dependency_target()

        def operation(progress):
            return core.inject_dependencies(
                requirement, target=target, progress=progress
            )

        self._start(
            f"Injecting {requirement} for {core.frozen_target_text()}",
            operation,
            self._on_dependencies_changed,
        )

    def _on_dependencies_changed(self, result):
        self._log("")
        self._log(result.to_text())
        self._log(f"Activated: {core.activate_dependency_paths(self._dependency_target())}")
        self._log("Dependency set is activated for this QAH session.")
        self._refresh_header()

    def _list_dependencies(self):
        self._log("")
        self._log(core.format_dependencies_table())

    def _remove_dependency(self, whole_set: bool):
        target = self._dependency_target()
        package = "" if whole_set else self.dep_package.text().strip()
        if not whole_set and not package:
            self._warn("No package", "Enter the package name to remove, or use Remove set.")
            return
        label = f"dependency set '{target}'" if whole_set else f"'{package}' from '{target}'"
        answer = QMessageBox.question(
            self,
            "Remove dependency",
            f"Remove {label}?\n\n"
            "Plugins that import it will fail until it is injected again.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return
        try:
            message = core.remove_dependency(target, package)
        except Exception as exc:
            self._warn("Remove dependency", str(exc))
            return
        self._log(message)
        self._list_dependencies()

    def _verify_dependency(self):
        target = self._dependency_target()
        module = self.dep_package.text().strip().split("=")[0].split(">")[0].split("<")[0]
        module = module.replace("-", "_").strip()
        if not module:
            self._warn("No module", "Enter the package/module name to verify.")
            return

        def operation(_progress):
            return core.verify_dependency(target, module)

        self._start(f"Verifying import of {module}", operation, self._on_dependency_verified)

    def _on_dependency_verified(self, result):
        self._log("")
        if result.get("ok"):
            self._log(
                f"OK: {result.get('module')} {result.get('version', '')}\n"
                f"  file: {result.get('file', '')}\n"
                f"  path: {result.get('path', '')}\n"
                f"  system Python: {result.get('python', '')}\n"
                "  The import check uses the system Python ABI; QAH activation "
                "happens in the running QAH process."
            )
        else:
            self._log(f"FAILED: {result.get('error', '')}")
            self._warn("Import check failed", "See the console for details.")

    # ------------------------------------------------------------- actions
    def _install(self, path=None, deps=None, mode=None, force=False, allow_broken=False):
        wheel = path or self._target_from_ui()
        if not wheel:
            self._warn("No wheel", "Select a .whl file first.")
            return
        if Path(wheel).suffix.lower() != ".whl":
            self._warn("Not a wheel", f"{wheel}\n\nSelect a .whl file, not an installed directory.")
            return
        if deps is None:
            deps = self.deps_check.isChecked()
        if mode is None:
            mode = self.mode_combo.currentData() or "unpack"
        if deps:
            mode = "pip"

        def operation(progress):
            return core.install_wheel(
                Path(wheel),
                mode=mode,
                with_dependencies=bool(deps),
                force=force,
                allow_broken=allow_broken,
                progress=progress,
            )

        self._start(f"Installing {Path(wheel).name}", operation, self._on_installed)

    def _on_installed(self, result):
        self._log("")
        self._log(result.to_text())
        self.refresh_list()
        self._log("")
        self._log("Restart QAH or use 'Rescan QAH' to make it appear in the Plugins menu.")
        self._rescan()

    def _test(self, path=None, instantiate=False):
        wheel = path or self._target_from_ui()
        if not wheel:
            self._warn("No wheel", "Select a .whl file first.")
            return
        if Path(wheel).suffix.lower() != ".whl":
            self._warn("Not a wheel", f"{wheel}\n\nSelect a .whl file to test.")
            return

        def operation(progress):
            progress(f"Testing {wheel} ...")
            return core.verify_wheel(Path(wheel), instantiate=instantiate)

        self._start(f"Testing {Path(wheel).name}", operation, self._on_tested)

    def _on_tested(self, report):
        self._log("")
        self._log(report.to_text())
        if not report.success:
            self._warn("Wheel test failed", "See the console for the detailed traceback.")

    def _build(self, project=None):
        project = project or QFileDialog.getExistingDirectory(
            self, "Select a plugin project (contains pyproject.toml or Cargo.toml)", str(Path.home())
        )
        if not project:
            return

        def operation(progress):
            return core.build_wheel(Path(project), progress=progress)

        self._start(f"Building {project}", operation, self._on_built)

    def _on_built(self, wheel):
        self._log("")
        self._log(f"Built wheel: {wheel}")
        self.path_edit.setText(str(wheel))
        try:
            info = core.inspect_wheel(wheel)
            self._log(core.format_wheel_info(info))
            problems = info.get("layout_problems") or []
            if problems:
                self._warn(
                    "Built wheel has warnings",
                    "The wheel was built but has layout problems:\n\n"
                    + "\n".join(f"- {p.get('message')}" for p in problems),
                )
        except Exception as exc:
            self._log(f"[Warning] Could not inspect the built wheel: {exc}")

    def _fix(self, target=None, install=False):
        target = target or self._target_from_ui()
        if not target:
            target = QFileDialog.getExistingDirectory(
                self,
                "Select the plugin project (or a folder containing its .whl)",
                str(Path.home()),
            )
        if not target:
            return

        def operation(progress):
            path = Path(target).expanduser()
            if path.is_file():
                project = core.find_project_for_wheel(path)
                if project is None:
                    raise core.WheelError(
                        f"Could not find pyproject.toml/Cargo.toml above {path}"
                    )
            elif path.is_dir():
                project = path
            else:
                raise core.WheelError(f"Not a wheel or project directory: {path}")
            progress(f"Repairing and rebuilding {project}")
            built = core.build_wheel(project, repair=True, progress=progress)
            result = None
            if install:
                result = core.install_wheel(built, progress=progress)
            return built, result

        self._start(f"Repairing {target}", operation, self._on_fixed)

    def _on_fixed(self, result):
        built, install_result = result
        self._log("")
        self._log(f"Rebuilt wheel: {built}")
        self.path_edit.setText(str(built))
        try:
            self._log(core.format_wheel_info(core.inspect_wheel(built)))
        except Exception as exc:
            self._log(f"[Warning] Could not inspect the rebuilt wheel: {exc}")
        if install_result is not None:
            self._log("")
            self._log(install_result.to_text())
            self.refresh_list()
            self._rescan()

    def _uninstall(self):
        target = self._target_from_ui()
        if not target:
            self._warn("Nothing selected", "Select an installed wheel plugin first.")
            return
        answer = QMessageBox.question(
            self,
            "Uninstall wheel plugin",
            f"Remove this installed plugin?\n\n{target}\n\n"
            "If QAH has loaded it, close QAH first or the .pyd/.so may be locked.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return

        def operation(progress):
            return core.uninstall_wheel(target)

        self._start(f"Removing {target}", operation, self._on_uninstalled)

    def _on_uninstalled(self, result):
        ok, message = result
        self._log(("" if ok else "[Error] ") + message)
        if ok:
            self.refresh_list()
            self._rescan()
        else:
            self._warn("Uninstall failed", message)

    def _doctor(self):
        self._start("Running doctor", lambda progress: core.doctor(), self._log)

    def _open_wheels_dir(self):
        path = core.wheels_dir()
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    def _rescan(self):
        added = core.activate_installed_wheels()
        if added:
            self._log(f"Added {len(added)} wheel directorie(s) to sys.path.")
        try:
            from plugins.libs import wheel_installer  # type: ignore

            wheel_installer.add_wheels_to_sys_path()
        except Exception:
            pass

        try:
            from PySide6.QtWidgets import QApplication

            for widget in QApplication.topLevelWidgets():
                manager = getattr(widget, "plugin_manager", None)
                if manager is None:
                    continue
                try:
                    if hasattr(widget, "_scan_plugins"):
                        widget._scan_plugins()
                    else:
                        manager.scan_plugins()
                    self._log("QAH plugin list rescanned.")
                    return True
                except Exception as exc:
                    self._log(f"[Warning] QAH rescan failed: {exc}")
        except Exception:
            pass

        self._log("Could not find the QAH main window; restart QAH to load the new plugin.")
        return False

    # ------------------------------------------------------------- threading
    def _start(self, label, operation, on_done):
        if self._task is not None and self._task.isRunning():
            self._warn("Busy", "Another operation is still running. Wait for it to finish.")
            return
        self._log("")
        self._log(label)
        task = _Task(operation, self)
        task.log.connect(self._log)
        task.done.connect(on_done)
        task.failed.connect(self._on_task_failed)
        task.finished.connect(self._on_task_finished)
        self._task = task
        self._set_busy(True)
        task.start()

    def _set_busy(self, busy):
        for widget in (
            self.install_button,
            self.test_button,
            self.build_button,
            self.repair_button,
            self.dep_inject_button,
            self.dep_list_button,
            self.dep_verify_button,
            self.dep_remove_pkg_button,
            self.dep_remove_set_button,
            self.list_widget,
        ):
            widget.setEnabled(not busy)

    def _on_task_finished(self):
        self._set_busy(False)
        if self._task is not None:
            self._task.deleteLater()
            self._task = None

    def _on_task_failed(self, traceback_text):
        self._log("[Error] Operation failed:")
        self._log(traceback_text)
        self._warn("Operation failed", "See the console for the full traceback.")

    # -------------------------------------------------------------- commands
    def _execute_command(self):
        text = self.command.text().strip()
        if not text:
            return
        self.command.clear()
        self._history.append(text)
        self._history_index = len(self._history)
        self._log(f"> {text}")
        self._handle_command(text)

    def _history_previous(self):
        if not self._history:
            return
        self._history_index = max(0, self._history_index - 1)
        self.command.setText(self._history[self._history_index])

    def _history_next(self):
        if not self._history:
            return
        self._history_index = min(len(self._history), self._history_index + 1)
        if self._history_index == len(self._history):
            self.command.clear()
        else:
            self.command.setText(self._history[self._history_index])

    def _handle_command(self, text):
        tokens = _split_args(text)
        if not tokens:
            return
        command = tokens[0].lower()
        rest = tokens[1:]

        if command in ("help", "?"):
            self._log(
                "Commands:\n"
                "  doctor                     full environment diagnosis\n"
                "  paths                      QAH and plugin directories\n"
                "  python                     current interpreter details\n"
                "  tags                       compatible wheel tags (first 80)\n"
                "  list                       installed wheel plugins\n"
                "  info <wheel|name>          metadata for a wheel or installed plugin\n"
                "  validate <wheel>           check wheel structure and entry-point target\n"
                "  install <wheel> [--deps] [--pip] [--force] [--allow-broken]\n"
                "  test <wheel> [--instantiate]\n"
                "  uninstall <name|path>\n"
                "  inject <package> [--target NAME] [--module MODULE]\n"
                "                             resolve wheels for QAH's frozen Python\n"
                "  deps                       list injected dependency sets\n"
                "  deps-remove <target> [--package NAME]\n"
                "  deps-verify <target> <module>\n"
                "  deps-path                  dependency root and target details\n"
                "  build <project>            build with maturin/build/pip\n"
                "  fix <project|wheel> [--install]\n"
                "                             repair maturin config, rebuild, validate\n"
                "  clean [--broken]           remove .staging / unusable wheel folders\n"
                "  rescan                     ask the running QAH to rescan plugins\n"
                "  open [path]                open the wheels folder (or a path)\n"
                "  clear                      clear the console"
            )
            return

        if command == "clear":
            self.console.clear()
            return

        if command == "doctor":
            self._doctor()
            return

        if command == "paths":
            self._log(core.paths_report())
            return

        if command == "python":
            self._log(core.describe_runtime())
            return

        if command == "tags":
            self._log("\n".join(core.current_tags(limit=80)))
            return

        if command in ("list", "ls"):
            self.refresh_list()
            self._log(core.format_installed_table())
            return

        if command in ("deps", "deps-list"):
            self._list_dependencies()
            return

        if command == "deps-path":
            self._log(core.frozen_target_text())
            self._log(str(core.dependencies_root(create=False)))
            return

        if command == "inject":
            requirement = ""
            target = "global"
            index = 0
            while index < len(rest):
                token = rest[index]
                if token == "--target" and index + 1 < len(rest):
                    target = rest[index + 1]
                    index += 2
                    continue
                if token == "--module" and index + 1 < len(rest):
                    index += 2
                    continue
                if not requirement:
                    requirement = token
                index += 1
            if not requirement:
                self._log("usage: inject <package> [--target NAME]")
                return
            self.dep_package.setText(requirement)
            self.dep_target.setText(target)
            self._inject_dependency()
            return

        if command == "deps-remove":
            target = "global"
            package = ""
            index = 0
            while index < len(rest):
                token = rest[index]
                if token == "--package" and index + 1 < len(rest):
                    package = rest[index + 1]
                    index += 2
                    continue
                if target == "global" and not token.startswith("-"):
                    target = token
                index += 1
            self.dep_target.setText(target)
            if package:
                self.dep_package.setText(package)
            self._remove_dependency(not package)
            return

        if command == "deps-verify":
            if len(rest) < 2:
                self._log("usage: deps-verify <target> <module>")
                return
            self.dep_target.setText(rest[0])
            self.dep_package.setText(rest[1])
            self._verify_dependency()
            return

        if command == "info":
            target = " ".join(rest).strip().strip('"').strip("'")
            if not target:
                target = self._target_from_ui() or ""
            if not target:
                self._log("usage: info <wheel|installed-name>")
                return
            path = Path(target).expanduser()
            try:
                if path.suffix.lower() == ".whl" or path.is_file():
                    self._log(core.format_wheel_info(core.inspect_wheel(path)))
                else:
                    installed = core.resolve_installed(target)
                    if installed is None:
                        self._log(f"Not installed and not a wheel: {target}")
                        return
                    info = core.inspect_installed(installed)
                    self._log(
                        f"Path: {info['path']}\n"
                        f"Name: {info.get('name')} {info.get('version')}\n"
                        f"Entry points: {', '.join(info.get('plugin_ids') or []) or 'NONE'}\n"
                        f"Native modules: {len(info.get('native_modules') or [])}\n"
                        f"Broken: {info.get('broken')}"
                    )
            except Exception as exc:
                self._log(f"[Error] {exc}")
            return

        if command == "install":
            deps = "--deps" in rest
            pip_mode = "--pip" in rest
            force = "--force" in rest
            allow_broken = "--allow-broken" in rest
            args = [token for token in rest if not token.startswith("--")]
            wheel = " ".join(args).strip().strip('"').strip("'")
            if not wheel:
                wheel = self._target_from_ui() or ""
            if not wheel:
                self._log(
                    "usage: install <wheel.whl> [--deps] [--pip] [--force] "
                    "[--allow-broken]"
                )
                return
            mode = "pip" if pip_mode else (self.mode_combo.currentData() or "unpack")
            self._install(
                wheel,
                deps=deps,
                mode=mode,
                force=force,
                allow_broken=allow_broken,
            )
            return

        if command == "validate":
            target = " ".join(rest).strip().strip('"').strip("'")
            if not target:
                target = self._target_from_ui() or ""
            if not target:
                self._log("usage: validate <wheel.whl>")
                return
            try:
                info = core.inspect_wheel(Path(target).expanduser())
            except Exception as exc:
                self._log(f"[Error] {exc}")
                return
            self._log(core.format_wheel_info(info))
            if core.blocking_layout_problems(info):
                self._log(
                    "INVALID: QAH could not import this wheel. "
                    "Use 'fix <project>' to repair and rebuild it."
                )
            else:
                self._log("VALID: the entry point resolves inside the wheel.")
            return

        if command == "test":
            instantiate = "--instantiate" in rest
            args = [token for token in rest if not token.startswith("--")]
            wheel = " ".join(args).strip().strip('"').strip("'")
            if not wheel:
                wheel = self._target_from_ui() or ""
            if not wheel:
                self._log("usage: test <wheel.whl> [--instantiate]")
                return
            self._test(wheel, instantiate=instantiate)
            return

        if command == "uninstall":
            target = " ".join(rest).strip().strip('"').strip("'")
            if not target:
                target = self._target_from_ui() or ""
            if not target:
                self._log("usage: uninstall <name|path>")
                return
            self._uninstall_target(target)
            return

        if command == "build":
            project = " ".join(rest).strip().strip('"').strip("'")
            if not project:
                self._build()
            else:
                self._build(project)
            return

        if command == "fix":
            install = "--install" in rest
            args = [token for token in rest if not token.startswith("--")]
            target = " ".join(args).strip().strip('"').strip("'")
            if not target:
                target = self._target_from_ui() or ""
            if not target:
                self._log("usage: fix <project|wheel> [--install]")
                return
            self._fix(target, install=install)
            return

        if command == "clean":
            root = core.wheels_dir(create=False)
            removed = 0
            if root.is_dir():
                for child in root.iterdir():
                    if child.is_dir() and child.name.endswith(".staging"):
                        if core._force_rmtree(child):
                            removed += 1
                            self._log(f"removed {child}")
            self._log(f"{removed} staging directorie(s) removed.")
            if "--broken" in rest:
                broken = core.remove_broken_wheels()
                for path in broken:
                    self._log(f"removed broken {path}")
                self._log(f"{len(broken)} broken wheel directorie(s) removed.")
                self.refresh_list()
            return

        if command == "rescan":
            self._rescan()
            return

        if command == "open":
            target = " ".join(rest).strip().strip('"').strip("'")
            path = Path(target).expanduser() if target else core.wheels_dir()
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
            return

        if command == "select":
            target = " ".join(rest).strip().strip('"').strip("'")
            for index in range(self.list_widget.count()):
                item = self.list_widget.item(index)
                if target.lower() in item.text().lower() or target == item.data(Qt.UserRole):
                    self.list_widget.setCurrentItem(item)
                    return
            self._log(f"No match for {target!r}")
            return

        self._log(f"Unknown command: {command}. Type 'help'.")

    def _uninstall_target(self, target):
        answer = QMessageBox.question(
            self,
            "Uninstall wheel plugin",
            f"Remove this installed plugin?\n\n{target}\n\n"
            "If QAH has loaded it, close QAH first or the .pyd/.so may be locked.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return

        def operation(progress):
            return core.uninstall_wheel(target)

        self._start(f"Removing {target}", operation, self._on_uninstalled)

    # ------------------------------------------------------------- drag/drop
    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            for url in event.mimeData().urls():
                if url.isLocalFile() and url.toLocalFile().lower().endswith(".whl"):
                    event.acceptProposedAction()
                    return
        event.ignore()

    def dropEvent(self, event):
        for url in event.mimeData().urls():
            if url.isLocalFile() and url.toLocalFile().lower().endswith(".whl"):
                path = url.toLocalFile()
                self.path_edit.setText(path)
                self._log(f"Dropped {path}")
                event.acceptProposedAction()
                return
        event.ignore()

    # --------------------------------------------------------------- cleanup
    def cleanup(self):
        task = self._task
        if task is not None and task.isRunning():
            try:
                task.wait(2000)
            except Exception:
                pass
        self._task = None
