#!/bin/sh
# QAH Wheel Plugin Manager - POSIX launcher (Linux / macOS).
#
# Usage:
#   ./qah_wheel_cli.sh doctor
#   ./qah_wheel_cli.sh install "/path/plugin-1.0.0-cp310-abi3-manylinux_2_34_x86_64.whl"
#
# Override the interpreter with QAH_CLI_PYTHON=/path/to/python3.
set -u

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PYTHON=${QAH_CLI_PYTHON:-python3}

if ! command -v "$PYTHON" >/dev/null 2>&1; then
    PYTHON=python
fi

exec "$PYTHON" "$SCRIPT_DIR/qah_wheel_cli.py" "$@"
