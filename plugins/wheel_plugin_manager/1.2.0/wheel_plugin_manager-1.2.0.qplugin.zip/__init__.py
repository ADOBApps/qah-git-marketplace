# wheel_plugin_manager/__init__.py
"""
Author: Acxel Orozco
Wheel Plugin Manager - QAH plugin entry point.

Install, test, build and remove QAH wheel plugins from inside QAH without
needing a compiler or a real ``python.exe`` in the bundle. On Windows this
works around Briefcase bundles built without ``allow_subprocesses = true`` by
unpacking wheels directly instead of calling pip.

This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

QAH is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

from __future__ import annotations

import importlib
import importlib.util
import logging
import sys
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QObject
from PySide6.QtGui import QAction, QIcon
from PySide6.QtWidgets import QWidget

try:
    from plugins.libs.plugin_manager import PluginInfo
except Exception:  # some Windows builds use a different module layout
    PluginInfo = object  # type: ignore

_PLUGIN_ID = "wheel_plugin_manager"


def _load_sibling(name: str):
    """Import a helper module in both supported loading modes.

    * wheel install  -> proper package, so ``importlib`` handles it;
    * classic plugin -> QAH loads this ``__init__.py`` as a stand-alone module,
      where relative imports do not work, so load the file by path with a
      unique module name.
    """
    try:
        return importlib.import_module(f"{__name__}.{name}")
    except ImportError:
        path = Path(__file__).parent / f"{name}.py"
        spec = importlib.util.spec_from_file_location(f"{__name__}_{name}", path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        return module


class WheelPluginManager(QObject):
    """Entry point referenced by ``[project.entry-points."qah.plugins"]``."""

    def __init__(self, plugin_info: PluginInfo):
        super().__init__()
        self.plugin_info = plugin_info
        self.ui_widget: Optional[QWidget] = None
        self.icon: Optional[QIcon] = None

        icon_path = Path(__file__).parent / "icon.svg"
        if icon_path.is_file():
            self.icon = QIcon(str(icon_path))

    def initialize(self) -> bool:
        try:
            logging.info(
                "Initializing %s v%s", self.plugin_info.name, self.plugin_info.version
            )
            try:
                core = _load_sibling("installer_core")
                added = core.activate_dependency_paths()
                if added:
                    logging.info(
                        "Activated injected dependencies: %s", ", ".join(added)
                    )
            except Exception as exc:
                logging.warning("Could not activate injected dependencies: %s", exc)
            return True
        except Exception as exc:  # pragma: no cover - defensive
            logging.error("Wheel Plugin Manager initialization failed: %s", exc)
            return False

    def get_widget(self) -> Optional[QWidget]:
        if self.ui_widget is None:
            try:
                ui = _load_sibling("plugin_ui")
                self.ui_widget = ui.WheelManagerWidget(self)
            except Exception as exc:
                logging.error("Could not build Wheel Plugin Manager: %s", exc)
                logging.debug("Traceback", exc_info=True)
                return None
        return self.ui_widget

    def get_menu_actions(self):
        """Optional shortcut; the host also lists the plugin in its menu."""
        action = QAction("Wheel Plugin Manager", self)
        if self.icon is not None:
            action.setIcon(self.icon)
        action.setToolTip("Install, test and remove QAH wheel plugins")
        return [action]

    def cleanup(self):
        if self.ui_widget is not None:
            try:
                if hasattr(self.ui_widget, "cleanup"):
                    self.ui_widget.cleanup()
            finally:
                self.ui_widget.deleteLater()
                self.ui_widget = None


Plugin = WheelPluginManager
