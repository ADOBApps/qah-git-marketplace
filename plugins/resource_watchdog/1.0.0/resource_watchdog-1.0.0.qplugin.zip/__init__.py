# resource_watchdog/__init__.py
"""Resource Watchdog - read-only QAH resource monitor.

QAH plugins run inside one process, so CPU cannot be attributed to a single
plugin. This plugin reports the QAH process and any child processes, lists
loaded heavy modules, warns on thresholds and writes a JSON report. It never
kills or unloads anything.

GPLv3 or later.
"""

from __future__ import annotations

import importlib
import importlib.util
import logging
import sys
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QObject
from PySide6.QtGui import QAction, QIcon
from PySide6.QtWidgets import QWidget

try:
    from plugins.libs.plugin_manager import PluginInfo
except Exception:
    PluginInfo = object  # type: ignore


def _load_sibling(name: str):
    try:
        return importlib.import_module(f"{__name__}.{name}")
    except ImportError:
        path = Path(__file__).parent / f"{name}.py"
        spec = importlib.util.spec_from_file_location(f"{__name__}_{name}", path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        return module


class ResourceWatchdogPlugin(QObject):
    def __init__(self, plugin_info: PluginInfo):
        super().__init__()
        self.plugin_info = plugin_info
        self.ui_widget: Optional[QWidget] = None
        self.icon: Optional[QIcon] = None
        icon_path = Path(__file__).parent / "icon.svg"
        if icon_path.is_file():
            self.icon = QIcon(str(icon_path))

    def initialize(self) -> bool:
        logging.info(
            "Initializing %s v%s",
            getattr(self.plugin_info, "name", "Resource Watchdog"),
            getattr(self.plugin_info, "version", "?"),
        )
        return True

    def get_widget(self) -> Optional[QWidget]:
        if self.ui_widget is None:
            try:
                ui = _load_sibling("resource_watchdog_widget")
                self.ui_widget = ui.ResourceWatchdogWidget(self)
            except Exception as exc:
                logging.error("Could not build Resource Watchdog: %s", exc)
                logging.debug("Traceback", exc_info=True)
                return None
        return self.ui_widget

    def get_menu_actions(self):
        check = QAction("Check resource usage now", self)
        if self.icon is not None:
            check.setIcon(self.icon)
        check.triggered.connect(self._check_now)
        report = QAction("Open resource report", self)
        report.triggered.connect(self._open_report)
        return [check, report]

    def _ensure_widget(self):
        if self.ui_widget is None:
            return self.get_widget()
        return self.ui_widget

    def _check_now(self):
        widget = self._ensure_widget()
        if widget is not None and hasattr(widget, "check_now"):
            widget.check_now()

    def _open_report(self):
        widget = self._ensure_widget()
        if widget is not None and hasattr(widget, "open_report"):
            widget.open_report()

    def cleanup(self):
        if self.ui_widget is not None:
            try:
                if hasattr(self.ui_widget, "cleanup"):
                    self.ui_widget.cleanup()
            finally:
                self.ui_widget.deleteLater()
                self.ui_widget = None


Plugin = ResourceWatchdogPlugin
