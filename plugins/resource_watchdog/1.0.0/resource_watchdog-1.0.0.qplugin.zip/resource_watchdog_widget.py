"""PySide6 runtime resource monitor for QAH."""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from PySide6.QtCore import Qt, QTimer, QUrl
from PySide6.QtGui import QDesktopServices, QFont
from PySide6.QtWidgets import (
    QAbstractItemView,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

HEAVY_MODULES = {
    "pydft": "localized-orbital DFT",
    "pyqint": "C++/OpenMP quantum-chemistry integrals",
    "numba": "JIT and native threads",
    "llvmlite": "LLVM backend",
    "torch": "large ML framework",
    "tensorflow": "large ML framework",
    "jax": "accelerated numerical framework",
    "cupy": "GPU numerical framework",
    "scipy": "large numerical library",
    "matplotlib": "plotting stack",
    "numpy": "numerical array library",
    "pandas": "dataframe library",
    "pyscf": "quantum-chemistry stack",
    "openmm": "molecular-dynamics stack",
    "ase": "atomistic simulation environment",
    "rdkit": "cheminformatics native library",
}

STATE_DIR = Path.home() / "QAH" / "resource_watchdog"
REPORT = STATE_DIR / "report.json"


def _activate_vendor() -> List[str]:
    root = Path.home() / "QAH" / "plugins" / "vendor"
    added = []
    for target in ("resource_watchdog", "global"):
        path = root / target
        if path.is_dir() and str(path) not in sys.path:
            sys.path.insert(0, str(path))
            added.append(str(path))
    if added:
        import importlib

        importlib.invalidate_caches()
    return added


def _load_psutil():
    _activate_vendor()
    try:
        import psutil  # type: ignore

        return psutil
    except Exception:
        return None


class ResourceWatchdogWidget(QWidget):
    def __init__(self, plugin=None, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.psutil = _load_psutil()
        self.timer = QTimer(self)
        self.timer.setInterval(5000)
        self.timer.timeout.connect(self._periodic)
        self._checks = 0
        self._last_alarm = False
        self._process = None
        if self.psutil is not None:
            try:
                self._process = self.psutil.Process(os.getpid())
                self._process.cpu_percent(interval=None)
            except Exception:
                self._process = None
        self._build_ui()
        self.check_now()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        header = QHBoxLayout()
        title = QLabel("<b>Resource Watchdog</b>")
        title.setFont(QFont("Segoe UI", 15, QFont.Weight.Bold))
        header.addWidget(title)
        subtitle = QLabel("Read-only QAH CPU/RAM and heavy-module monitor")
        subtitle.setStyleSheet("color:#6b7280;")
        header.addWidget(subtitle, 1)
        self.badge = QLabel("")
        header.addWidget(self.badge)
        layout.addLayout(header)

        note = QLabel(
            "QAH plugins run inside one process. CPU and RSS are attributed to "
            "QAH, not to a specific plugin. This watchdog never kills or unloads "
            "anything; it reports and warns."
        )
        note.setWordWrap(True)
        note.setStyleSheet(
            "background:#eff6ff; color:#1e3a8a; padding:6px; border:1px solid #bfdbfe;"
        )
        layout.addWidget(note)

        metrics_box = QGroupBox("QAH process")
        metrics = QFormLayout(metrics_box)
        self.pid_label = QLabel("—")
        self.cpu_label = QLabel("—")
        self.mem_label = QLabel("—")
        self.threads_label = QLabel("—")
        self.children_label = QLabel("—")
        self.uptime_label = QLabel("—")
        for label, widget in (
            ("PID:", self.pid_label),
            ("CPU:", self.cpu_label),
            ("Memory (RSS):", self.mem_label),
            ("Threads:", self.threads_label),
            ("Child processes:", self.children_label),
            ("Check time:", self.uptime_label),
        ):
            metrics.addRow(label, widget)
        layout.addWidget(metrics_box)

        heavy_box = QGroupBox("Heavy modules loaded in QAH")
        heavy_layout = QVBoxLayout(heavy_box)
        self.heavy_list = QListWidget()
        self.heavy_list.setMaximumHeight(150)
        self.heavy_list.setSelectionMode(
            QAbstractItemView.SelectionMode.NoSelection
        )
        heavy_layout.addWidget(self.heavy_list)
        self.heavy_note = QLabel("")
        self.heavy_note.setWordWrap(True)
        self.heavy_note.setStyleSheet("color:#6b7280;")
        heavy_layout.addWidget(self.heavy_note)
        layout.addWidget(heavy_box)

        controls_box = QGroupBox("Monitoring")
        controls = QFormLayout(controls_box)
        self.interval_spin = QSpinBox()
        self.interval_spin.setRange(1, 60)
        self.interval_spin.setValue(5)
        self.interval_spin.setSuffix(" s")
        controls.addRow("Interval:", self.interval_spin)
        self.cpu_spin = QSpinBox()
        self.cpu_spin.setRange(10, 100)
        self.cpu_spin.setValue(85)
        self.cpu_spin.setSuffix(" %")
        controls.addRow("CPU warning:", self.cpu_spin)
        self.ram_spin = QSpinBox()
        self.ram_spin.setRange(256, 65536)
        self.ram_spin.setValue(2048)
        self.ram_spin.setSuffix(" MB")
        controls.addRow("RSS warning:", self.ram_spin)
        row = QHBoxLayout()
        self.start_button = QPushButton("Start monitoring")
        self.start_button.clicked.connect(lambda _checked=False: self.start())
        row.addWidget(self.start_button)
        self.stop_button = QPushButton("Stop")
        self.stop_button.clicked.connect(lambda _checked=False: self.stop())
        self.stop_button.setEnabled(False)
        row.addWidget(self.stop_button)
        check = QPushButton("Check now")
        check.clicked.connect(lambda _checked=False: self.check_now())
        row.addWidget(check)
        report = QPushButton("Open report")
        report.clicked.connect(lambda _checked=False: self.open_report())
        row.addWidget(report)
        row.addStretch(1)
        controls.addRow("", row)
        layout.addWidget(controls_box)

        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setFont(QFont("Consolas", 9))
        self.log.setPlaceholderText("Resource checks and warnings appear here.")
        layout.addWidget(self.log, 1)

        self.status = QLabel("Ready. Monitoring is off until you press Start.")
        self.status.setStyleSheet("color:#6b7280;")
        layout.addWidget(self.status)

        if self.psutil is None:
            self.badge.setText("psutil missing")
            self.badge.setStyleSheet("color:#b45309;")
            self.start_button.setEnabled(False)
            self.log.appendPlainText(
                "psutil is not available. Install/inject psutil to enable CPU/RSS "
                "sampling. Heavy-module detection still works."
            )
        else:
            version = getattr(self.psutil, "__version__", "?")
            self.badge.setText(f"psutil {version}")
            self.badge.setStyleSheet("color:#15803d;")

    # -- monitoring ------------------------------------------------------

    def start(self) -> None:
        if self.psutil is None:
            QMessageBox.information(
                self,
                "Resource Watchdog",
                "psutil is required for CPU/RSS sampling.\n\n"
                "Inject psutil with Wheel Plugin Manager into global or "
                "resource_watchdog, then restart QAH.",
            )
            return
        self.timer.setInterval(max(1, self.interval_spin.value()) * 1000)
        self.timer.start()
        self.start_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self.status.setText(
            f"Monitoring every {self.interval_spin.value()} s. No kill action is available."
        )
        self.log.appendPlainText(
            f"Monitoring started at {time.strftime('%H:%M:%S')}; interval "
            f"{self.interval_spin.value()} s."
        )
        self.check_now()

    def stop(self) -> None:
        self.timer.stop()
        self.start_button.setEnabled(self.psutil is not None)
        self.stop_button.setEnabled(False)
        self.status.setText("Monitoring stopped.")

    def _periodic(self) -> None:
        self.check_now(periodic=True)

    def check_now(self, periodic: bool = False) -> Dict[str, Any]:
        self._checks += 1
        data = self._sample()
        self._update_ui(data)
        alarm = bool(data.get("alarm"))
        if alarm or not periodic or self._checks % 12 == 0:
            self._write_report(data)
        if alarm and not self._last_alarm:
            self.log.appendPlainText(
                f"ALARM: {data.get('alarm_reason', 'resource threshold exceeded')}"
            )
        self._last_alarm = alarm
        return data

    def _sample(self) -> Dict[str, Any]:
        heavy = [
            f"{name} — {HEAVY_MODULES[name]}"
            for name in HEAVY_MODULES
            if name in sys.modules
        ]
        data: Dict[str, Any] = {
            "format": "qah-resource-watchdog",
            "pid": os.getpid(),
            "heavy_modules": heavy,
            "checked_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "alarm": False,
            "alarm_reason": "",
            "cpu_percent": None,
            "rss_mb": None,
            "threads": None,
            "children": [],
        }
        if self.psutil is None or self._process is None:
            data["detail"] = "psutil unavailable; live CPU/RSS not sampled"
            return data
        try:
            cpu = float(self._process.cpu_percent(interval=None))
            memory = self._process.memory_info()
            data["cpu_percent"] = round(cpu, 2)
            data["rss_mb"] = round(memory.rss / (1024**2), 1)
            data["threads"] = int(self._process.num_threads())
        except Exception as exc:
            data["detail"] = f"{type(exc).__name__}: {exc}"
            return data
        children = []
        try:
            for child in self._process.children(recursive=True)[:30]:
                try:
                    with child.oneshot():
                        children.append(
                            {
                                "pid": child.pid,
                                "name": child.name(),
                                "cpu_percent": round(child.cpu_percent(interval=None), 2),
                                "rss_mb": round(child.memory_info().rss / (1024**2), 1),
                            }
                        )
                except Exception:
                    continue
        except Exception:
            pass
        data["children"] = children
        cpu_limit = float(self.cpu_spin.value())
        ram_limit = float(self.ram_spin.value())
        reasons = []
        if data["cpu_percent"] is not None and data["cpu_percent"] >= cpu_limit:
            reasons.append(
                f"QAH CPU {data['cpu_percent']:.1f}% >= {cpu_limit:.0f}%"
            )
        if data["rss_mb"] is not None and data["rss_mb"] >= ram_limit:
            reasons.append(f"QAH RSS {data['rss_mb']:.1f} MB >= {ram_limit:.0f} MB")
        if reasons:
            data["alarm"] = True
            data["alarm_reason"] = "; ".join(reasons)
        return data

    def _update_ui(self, data: Dict[str, Any]) -> None:
        self.pid_label.setText(str(data.get("pid", os.getpid())))
        cpu = data.get("cpu_percent")
        rss = data.get("rss_mb")
        self.cpu_label.setText("—" if cpu is None else f"{cpu:.1f} %")
        self.mem_label.setText("—" if rss is None else f"{rss:.1f} MB")
        self.threads_label.setText(
            "—" if data.get("threads") is None else str(data["threads"])
        )
        children = data.get("children") or []
        self.children_label.setText(str(len(children)))
        self.uptime_label.setText(str(data.get("checked_at", "")))
        self.heavy_list.clear()
        for item in data.get("heavy_modules") or []:
            self.heavy_list.addItem(item)
        if data.get("heavy_modules"):
            self.heavy_note.setText(
                "Heavy modules are loaded somewhere in QAH. This does not prove "
                "that a specific plugin is using CPU right now."
            )
        else:
            self.heavy_note.setText("No tracked heavy module is loaded in QAH.")
        if data.get("alarm"):
            self.status.setText(f"ALARM: {data.get('alarm_reason', '')}")
            self.status.setStyleSheet("color:#b91c1c; font-weight:600;")
        elif data.get("detail"):
            self.status.setText(str(data["detail"]))
            self.status.setStyleSheet("color:#b45309;")
        else:
            self.status.setText("Within configured thresholds.")
            self.status.setStyleSheet("color:#15803d;")

    def _write_report(self, data: Dict[str, Any]) -> None:
        try:
            STATE_DIR.mkdir(parents=True, exist_ok=True)
            data = dict(data)
            data["thresholds"] = {
                "cpu_percent": int(self.cpu_spin.value()),
                "rss_mb": int(self.ram_spin.value()),
                "interval_seconds": int(self.interval_spin.value()),
            }
            REPORT.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except OSError as exc:
            self.log.appendPlainText(f"Could not write report: {exc}")

    def open_report(self) -> None:
        if not REPORT.is_file():
            self.check_now()
        if REPORT.is_file():
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(REPORT)))
        else:
            QMessageBox.information(
                self, "Resource Watchdog", f"No report at:\n{REPORT}"
            )

    def cleanup(self) -> None:
        self.timer.stop()
