"""
Author: Acxel Orozco
Date: 20/01/2026 (Started)
Last modification: 01/02/2026
Main UI for SQS Generator Plugin
tool logic file for tools plugins - Quantum Analysis Helper (QAH)

QAH is a python software for plot and analyze Quantum Espresso DOS, 
PDOS and Bands structures with a friendly GUI and extensive plugins.

This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

QAH is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

import os
from pathlib import Path
from typing import Optional
import logging
import time
import numpy as np

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox,
    QLabel, QLineEdit, QPushButton, QComboBox,
    QSpinBox, QDoubleSpinBox, QProgressBar,
    QTextEdit, QFileDialog, QMessageBox, QTabWidget,
    QCheckBox, QGridLayout, QSplitter
)
from PySide6.QtCore import Qt, QThread, Signal, QTimer
from PySide6.QtGui import QFont, QIcon

from .utils.lattice_generator import LatticeGenerator
from .utils.sqs_engine import SQSGenerator
from .io.structure_writer import StructureWriter


class SQSWorker(QThread):
    """Worker thread for SQS generation"""
    
    progress = Signal(int)
    status = Signal(str)
    finished = Signal(object, object, object)  # positions, elements, result
    error = Signal(str)
    
    def __init__(self, lattice_type: str, cell_size: int, lattice_constant: float,
                 element_A: str, element_B: str, composition: float,
                 method: str, n_trials: int, temperature: float):
        super().__init__()
        self.lattice_type = lattice_type
        self.cell_size = cell_size
        self.lattice_constant = lattice_constant
        self.element_A = element_A
        self.element_B = element_B
        self.composition = composition
        self.method = method
        self.n_trials = n_trials
        self.temperature = temperature
        self._is_cancelled = False
    
    def cancel(self):
        self._is_cancelled = True
    
    def run(self):
        try:
            self.status.emit("Generating lattice...")
            self.progress.emit(10)
            
            # Generate lattice
            if self.lattice_type == "FCC":
                lattice_vectors, positions = LatticeGenerator.fcc_lattice(
                    self.cell_size, self.lattice_constant
                )
            elif self.lattice_type == "BCC":
                lattice_vectors, positions = LatticeGenerator.bcc_lattice(
                    self.cell_size, self.lattice_constant
                )
            elif self.lattice_type == "Simple Cubic":
                lattice_vectors, positions = LatticeGenerator.simple_cubic_lattice(
                    self.cell_size, self.lattice_constant
                )
            elif self.lattice_type == "HCP":
                lattice_vectors, positions = LatticeGenerator.hcp_lattice(
                    self.cell_size, (self.lattice_constant, self.lattice_constant * 1.633)
                )
            else:
                raise ValueError(f"Unknown lattice type: {self.lattice_type}")
            
            self.status.emit(f"Generated {len(positions)} atoms")
            self.progress.emit(20)
            
            if self._is_cancelled:
                return
            
            # Initialize SQS generator
            self.status.emit("Initializing SQS generator...")
            generator = SQSGenerator(
                lattice_vectors, positions,
                self.element_A, self.element_B,
                self.composition, seed=int(time.time())
            )
            
            self.progress.emit(30)
            
            if self._is_cancelled:
                return
            
            # Run optimization
            def progress_callback(*args):
                if self._is_cancelled:
                    raise InterruptedError("Cancelled")
            
            self.status.emit(f"Running {self.method} optimization...")
            
            if self.method == "Simulated Annealing":
                result = generator.simulated_annealing(
                    T_start=self.temperature,
                    T_end=self.temperature * 0.01,
                    steps_per_T=500,
                    cooling_rate=0.95,
                    callback=progress_callback
                )
            else:
                result = generator.random_search(
                    n_trials=self.n_trials,
                    callback=progress_callback
                )
            
            self.progress.emit(90)
            
            if self._is_cancelled:
                return
            
            # Get final structure
            positions, elements = generator.get_structures()
            
            self.status.emit("Optimization complete!")
            self.progress.emit(100)
            
            self.finished.emit(positions, elements, result)
            
        except InterruptedError:
            self.status.emit("Cancelled")
        except Exception as e:
            self.error.emit(str(e))


class SQSGeneratorWidget(QWidget):
    """Main widget for SQS Generator"""
    
    def __init__(self, plugin_instance=None):
        super().__init__()
        self.plugin = plugin_instance
        self.worker = None
        self.current_positions = None
        self.current_elements = None
        
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        
        # Title
        title = QLabel("Special Quasirandom Structure (SQS) Generator")
        title.setFont(QFont("Arial", 14, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        # Reference
        ref = QLabel("Based on: Zunger et al. PRL 65, 353 (1990) | van de Walle et al. CALPHAD 42, 13 (2013)")
        ref.setStyleSheet("color: #666; font-size: 10px;")
        ref.setAlignment(Qt.AlignCenter)
        layout.addWidget(ref)
        
        # Main splitter
        splitter = QSplitter(Qt.Horizontal)
        
        # Left panel - Controls
        left_panel = self.create_control_panel()
        splitter.addWidget(left_panel)
        
        # Right panel - Results and preview
        right_panel = self.create_results_panel()
        splitter.addWidget(right_panel)
        
        splitter.setSizes([400, 500])
        layout.addWidget(splitter)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)
        
        # Status label
        self.status_label = QLabel("Ready")
        self.status_label.setStyleSheet("color: #666; padding: 5px;")
        layout.addWidget(self.status_label)
    
    def create_control_panel(self) -> QWidget:
        """Create left control panel"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        
        # Lattice parameters
        lattice_group = QGroupBox("Lattice Parameters")
        lattice_layout = QGridLayout()
        
        lattice_layout.addWidget(QLabel("Lattice Type:"), 0, 0)
        self.lattice_combo = QComboBox()
        self.lattice_combo.addItems(["FCC", "BCC", "Simple Cubic", "HCP"])
        self.lattice_combo.currentTextChanged.connect(self.on_lattice_changed)
        lattice_layout.addWidget(self.lattice_combo, 0, 1)
        
        lattice_layout.addWidget(QLabel("Cell Size (cells per direction):"), 1, 0)
        self.cell_size_spin = QSpinBox()
        self.cell_size_spin.setRange(1, 5)
        self.cell_size_spin.setValue(2)
        lattice_layout.addWidget(self.cell_size_spin, 1, 1)
        
        lattice_layout.addWidget(QLabel("Lattice Constant (Å):"), 2, 0)
        self.lattice_const_spin = QDoubleSpinBox()
        self.lattice_const_spin.setRange(2.0, 10.0)
        self.lattice_const_spin.setValue(4.05)
        self.lattice_const_spin.setSingleStep(0.05)
        lattice_layout.addWidget(self.lattice_const_spin, 2, 1)
        
        lattice_layout.addWidget(QLabel("Number of Atoms:"), 3, 0)
        self.n_atoms_label = QLabel("32")
        lattice_layout.addWidget(self.n_atoms_label, 3, 1)
        
        lattice_group.setLayout(lattice_layout)
        layout.addWidget(lattice_group)
        
        # Composition parameters
        comp_group = QGroupBox("Composition")
        comp_layout = QGridLayout()
        
        comp_layout.addWidget(QLabel("Element A:"), 0, 0)
        self.element_A_edit = QLineEdit("A")
        comp_layout.addWidget(self.element_A_edit, 0, 1)
        
        comp_layout.addWidget(QLabel("Element B:"), 1, 0)
        self.element_B_edit = QLineEdit("B")
        comp_layout.addWidget(self.element_B_edit, 1, 1)
        
        comp_layout.addWidget(QLabel("Composition of B:"), 2, 0)
        self.composition_spin = QDoubleSpinBox()
        self.composition_spin.setRange(0.0, 1.0)
        self.composition_spin.setValue(0.5)
        self.composition_spin.setSingleStep(0.05)
        self.composition_spin.setDecimals(3)
        comp_layout.addWidget(self.composition_spin, 2, 1)
        
        comp_group.setLayout(comp_layout)
        layout.addWidget(comp_group)
        
        # Optimization parameters
        opt_group = QGroupBox("Optimization")
        opt_layout = QGridLayout()
        
        opt_layout.addWidget(QLabel("Method:"), 0, 0)
        self.method_combo = QComboBox()
        self.method_combo.addItems(["Random Search", "Simulated Annealing"])
        opt_layout.addWidget(self.method_combo, 0, 1)
        
        opt_layout.addWidget(QLabel("Number of Trials:"), 1, 0)
        self.trials_spin = QSpinBox()
        self.trials_spin.setRange(100, 50000)
        self.trials_spin.setValue(5000)
        self.trials_spin.setSingleStep(500)
        opt_layout.addWidget(self.trials_spin, 1, 1)
        
        opt_layout.addWidget(QLabel("Temperature (SA only):"), 2, 0)
        self.temp_spin = QDoubleSpinBox()
        self.temp_spin.setRange(0.1, 10.0)
        self.temp_spin.setValue(1.0)
        self.temp_spin.setSingleStep(0.1)
        opt_layout.addWidget(self.temp_spin, 2, 1)
        
        opt_group.setLayout(opt_layout)
        layout.addWidget(opt_group)
        
        # Action buttons
        action_group = QGroupBox("Actions")
        action_layout = QVBoxLayout()
        
        self.generate_btn = QPushButton("Generate SQS")
        self.generate_btn.setStyleSheet("background-color: #4CAF50; color: white; font-weight: bold; padding: 8px;")
        self.generate_btn.clicked.connect(self.generate_sqs)
        action_layout.addWidget(self.generate_btn)
        
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.clicked.connect(self.cancel_generation)
        action_layout.addWidget(self.cancel_btn)
        
        action_group.setLayout(action_layout)
        layout.addWidget(action_group)
        
        # Export buttons
        export_group = QGroupBox("Export")
        export_layout = QVBoxLayout()
        
        self.export_poscar_btn = QPushButton("Export POSCAR")
        self.export_poscar_btn.setEnabled(False)
        self.export_poscar_btn.clicked.connect(lambda: self.export_file("poscar"))
        export_layout.addWidget(self.export_poscar_btn)
        
        self.export_xyz_btn = QPushButton("Export XYZ")
        self.export_xyz_btn.setEnabled(False)
        self.export_xyz_btn.clicked.connect(lambda: self.export_file("xyz"))
        export_layout.addWidget(self.export_xyz_btn)
        
        self.export_cif_btn = QPushButton("Export CIF")
        self.export_cif_btn.setEnabled(False)
        self.export_cif_btn.clicked.connect(lambda: self.export_file("cif"))
        export_layout.addWidget(self.export_cif_btn)
        
        export_group.setLayout(export_layout)
        layout.addWidget(export_group)
        
        layout.addStretch()
        
        return panel
    
    def create_results_panel(self) -> QWidget:
        """Create results display panel"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        
        # Results display
        results_group = QGroupBox("SQS Results")
        results_layout = QVBoxLayout()
        
        self.results_text = QTextEdit()
        self.results_text.setReadOnly(True)
        self.results_text.setFont(QFont("Courier New", 10))
        self.results_text.setMinimumHeight(200)
        results_layout.addWidget(self.results_text)
        
        results_group.setLayout(results_layout)
        layout.addWidget(results_group)
        
        return panel
    
    def on_lattice_changed(self, lattice_type: str):
        """Update atom count when lattice changes"""
        cell_size = self.cell_size_spin.value()
        
        if lattice_type == "FCC":
            n_atoms = 4 * cell_size**3
        elif lattice_type == "BCC":
            n_atoms = 2 * cell_size**3
        elif lattice_type == "Simple Cubic":
            n_atoms = cell_size**3
        elif lattice_type == "HCP":
            n_atoms = 2 * cell_size**3
        else:
            n_atoms = 0
        
        self.n_atoms_label.setText(str(n_atoms))
    
    def generate_sqs(self):
        """Start SQS generation"""
        # Validate inputs
        element_A = self.element_A_edit.text().strip()
        element_B = self.element_B_edit.text().strip()
        
        if not element_A or not element_B:
            QMessageBox.warning(self, "Warning", "Please enter element symbols")
            return
        
        if element_A == element_B:
            QMessageBox.warning(self, "Warning", "Elements must be different")
            return
        
        # Disable UI
        self.generate_btn.setEnabled(False)
        self.cancel_btn.setEnabled(True)
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        
        # Clear previous results
        self.results_text.clear()
        
        # Get parameters
        method = self.method_combo.currentText()
        
        # Create worker
        self.worker = SQSWorker(
            lattice_type=self.lattice_combo.currentText(),
            cell_size=self.cell_size_spin.value(),
            lattice_constant=self.lattice_const_spin.value(),
            element_A=element_A,
            element_B=element_B,
            composition=self.composition_spin.value(),
            method=method,
            n_trials=self.trials_spin.value(),
            temperature=self.temp_spin.value()
        )
        
        self.worker.progress.connect(self.update_progress)
        self.worker.status.connect(self.update_status)
        self.worker.finished.connect(self.on_generation_finished)
        self.worker.error.connect(self.on_generation_error)
        
        self.worker.start()
    
    def update_progress(self, value: int):
        """Update progress bar"""
        self.progress_bar.setValue(value)
    
    def update_status(self, status: str):
        """Update status label"""
        self.status_label.setText(status)
    
    def on_generation_finished(self, positions, elements, result):
        """Handle generation completion"""
        self.current_positions = positions
        self.current_elements = elements
        
        # Display results
        results_text = f"""
SQS Generation Results
======================

Method: {result.method}
Number of atoms: {result.n_atoms}
Composition: {result.composition:.3f} ({self.element_A_edit.text()}: {100*(1-result.composition):.1f}%, {self.element_B_edit.text()}: {100*result.composition:.1f}%)

Objective function value: {result.objective_value:.6f}
Iterations: {result.iterations}
Time: {result.time_seconds:.2f} seconds
Converged: {result.converged}

Correlations (pair):
"""
        for shell, corr in result.correlations['pairs'].items():
            results_text += f"  Shell {shell}: {corr:.6f}\n"
        
        results_text += "\nCorrelations (triplet):\n"
        for shell, corr in result.correlations['triplets'].items():
            results_text += f"  Shell {shell}: {corr:.6f}\n"
        
        self.results_text.setText(results_text)
        
        # Enable export buttons
        self.export_poscar_btn.setEnabled(True)
        self.export_xyz_btn.setEnabled(True)
        self.export_cif_btn.setEnabled(True)
        
        # Re-enable UI
        self.generate_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.progress_bar.setVisible(False)
        self.status_label.setText("Generation complete!")
        
        QMessageBox.information(self, "Success", 
            f"SQS generated successfully!\n\n"
            f"Objective value: {result.objective_value:.6f}\n"
            f"Time: {result.time_seconds:.2f} seconds")
    
    def on_generation_error(self, error: str):
        """Handle generation error"""
        self.generate_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.progress_bar.setVisible(False)
        self.status_label.setText("Error")
        
        QMessageBox.critical(self, "Error", f"Generation failed:\n{error}")
    
    def cancel_generation(self):
        """Cancel generation"""
        if self.worker:
            self.worker.cancel()
            self.worker.wait()
        
        self.generate_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.progress_bar.setVisible(False)
        self.status_label.setText("Cancelled")
    
    def export_file(self, format_type: str):
        """Export structure to file"""
        if self.current_positions is None:
            QMessageBox.warning(self, "Warning", "No structure to export")
            return
        
        # Get default filename
        default_name = f"sqs_{self.element_A_edit.text()}{self.element_B_edit.text()}"
        
        if format_type == "poscar":
            filename, _ = QFileDialog.getSaveFileName(
                self, "Save POSCAR", default_name, "POSCAR Files (POSCAR*);;All Files (*)"
            )
            if filename:
                # Generate lattice vectors from positions
                min_coords = np.min(self.current_positions, axis=0)
                max_coords = np.max(self.current_positions, axis=0)
                lattice_vectors = np.diag(max_coords - min_coords + 5.0)
                
                StructureWriter.write_poscar(
                    lattice_vectors, self.current_positions, self.current_elements,
                    filename, comment="SQS generated structure"
                )
                QMessageBox.information(self, "Success", f"Saved to {filename}")
        
        elif format_type == "xyz":
            filename, _ = QFileDialog.getSaveFileName(
                self, "Save XYZ", f"{default_name}.xyz", "XYZ Files (*.xyz);;All Files (*)"
            )
            if filename:
                StructureWriter.write_xyz(
                    self.current_positions, self.current_elements, filename,
                    comment="SQS generated structure"
                )
                QMessageBox.information(self, "Success", f"Saved to {filename}")
        
        elif format_type == "cif":
            filename, _ = QFileDialog.getSaveFileName(
                self, "Save CIF", f"{default_name}.cif", "CIF Files (*.cif);;All Files (*)"
            )
            if filename:
                StructureWriter.write_cif(
                    self.current_positions, self.current_elements, filename,
                    comment="SQS generated structure"
                )
                QMessageBox.information(self, "Success", f"Saved to {filename}")
    
    def closeEvent(self, event):
        """Handle close event"""
        if self.worker and self.worker.isRunning():
            self.worker.cancel()
            self.worker.wait()
        event.accept()