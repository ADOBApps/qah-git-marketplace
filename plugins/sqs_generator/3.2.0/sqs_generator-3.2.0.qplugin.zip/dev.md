# Dev

The structure do not be rightly generate, better replace currenct generator, at least for TiO2 with ASE

## Include ICET backend

working on: Generation mismatch:
Composition:
  Ti: 768
  Sn: 256

Total atoms: 1024

icet_sqs_engine.random_search() [257-262]
icet_sqs_engine.simulated_annealing() [197-202]

### Source

[Special quasirandom structures](https://icet.materialsmodeling.org/advanced_topics/sqs_generationhtml#generate-sqs-cells-for-a-system-with-sublattices)

[Cluster space](https://icet.materialsmodeling.org/moduleref/cluster_space.html#icet.ClusterSpace)

[The Atoms object](https://ase-lib.org/ase/atoms.html)

## Pending

including utils/icet_sqs_fortran_wrapper.py
