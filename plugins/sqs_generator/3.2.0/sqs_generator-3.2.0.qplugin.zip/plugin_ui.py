"""
SQS Generator - Main UI Widget with POSCAR reading support
Updated for unified Fortran/Lua backends
"""

import os
import time
from pathlib import Path
from typing import Optional, List, Dict
from collections import Counter
import logging

import numpy as np

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QTabWidget,
    QPushButton, QLabel, QFileDialog, QMessageBox, QComboBox,
    QSpinBox, QDoubleSpinBox, QProgressBar, QTextEdit, QSplitter,
    QCheckBox, QGridLayout, QFormLayout, QScrollArea, QFrame,
    QLineEdit
)
from PySide6.QtCore import Qt, QThread, Signal, QTimer
from PySide6.QtGui import QFont

from .io.structure_writer import StructureWriter
from .io.temporal import TempFileManager
from .utils.lattice_generator import LatticeGenerator
from .utils.sqs_engine import (
    SQSGenerator,
    SQSGeneratorMultiSublattice,
    SQSResult,
    SpinConfiguration
)
from .utils.poscar_parser import POSCARParser, POSCARStructure
from .widgets.xyz_widget import XYZVisualizationWidget

# Import unified wrappers
try:
    from .utils.sqs_fortran_wrapper import get_fortran_engine, FortranSQSEngine
    FORTRAN_AVAILABLE = get_fortran_engine() is not None
except ImportError:
    FORTRAN_AVAILABLE = False
    print("[SQS] Fortran wrapper not available")

try:
    from .utils.sqs_lua_wrapper import get_lua_engine, LuaSQSEngine
    LUA_AVAILABLE = True  # Lua always has Python fallback
except ImportError:
    LUA_AVAILABLE = False
    print("[SQS] Lua wrapper not available")

try:
    from .utils.ffi_sqs_wrapper import get_ffi_engine, FFISQSEngine
    LUAFFI_AVAILABLE = True  # Lua always has Python fallback
except ImportError:
    LUAFFI_AVAILABLE = False
    print("[SQS] LuaJIT FFI wrapper not available")

try:
    from .utils.icet_sqs_engine import (
        ICETSQSGenerator,
        ICETSQSGeneratorMultiSublattice,
        ICETSQSResult,
        ICETSpinConfiguration
    )
    HAS_ICET = True
except ImportError as e:
    HAS_ICET = False
    IMPORT_ERROR = str(e)
    print(f"[SQS] ICET not available: {e}")


class SQSWorker(QThread):
    """Worker thread for SQS generation with multiple backends"""
    
    progress = Signal(int)
    status = Signal(str)
    finished = Signal(object, object, object)  # positions, elements, result
    error = Signal(str)
    
    def __init__(self, params: dict):
        super().__init__()
        self.params = params
        self._is_cancelled = False
    
    def cancel(self):
        self._is_cancelled = True
    
    def _run_python_backend(self, lattice_vectors, positions, elements, 
                            cation_indices, composition, element_A, element_B):
        """Run Python backend"""
        if cation_indices is not None and len(cation_indices) > 0:
            generator = SQSGeneratorMultiSublattice(
                lattice_vectors, positions, elements,
                cation_indices, element_A, element_B,
                composition, seed=int(time.time())
            )
        else:
            generator = SQSGenerator(
                lattice_vectors, positions,
                element_A, element_B, composition,
                seed=int(time.time())
            )
        
        method = self.params.get('method', 'Random Search')
        
        if method == "Simulated Annealing":
            result = generator.simulated_annealing(
                T_start=self.params.get('temperature', 1.0),
                T_end=self.params.get('temperature', 1.0) * 0.01,
                steps_per_T=500,
                cooling_rate=0.95,
                convergence_threshold=self.params['convergence_threshold']
            )
        else:
            result = generator.random_search(
                n_trials=self.params.get('n_trials', 5000),
                convergence_threshold=self.params['convergence_threshold']
            )
        
        # Get final structure
        positions_out, elements_out = generator.get_structures()
        
        return positions_out, elements_out, result
    
    def _run_icet_backend(self, lattice_vectors, positions, elements, 
                        cation_indices, composition, element_A, element_B):
        """Run ICET backend"""
        
        # Get supercell size from params
        cell_size = self.params.get('cell_size', 2)
        if isinstance(cell_size, int):
            supercell_size = (cell_size, cell_size, cell_size)
        else:
            supercell_size = cell_size
        
        # Get primitive cell info based on structure type
        primitive_vectors = None
        primitive_positions = None
        primitive_elements = None
        lattice_type = self.params.get('lattice_type', '')
        
        # For known structure types, get primitive cell
        if "Rutile" in lattice_type:
            a = self.params.get('tio2_a', 4.594)
            c = self.params.get('tio2_c', 2.959)
            primitive_vectors, primitive_positions, primitive_elements = LatticeGenerator.rutile_tio2_primitive(a, c)
            print(f"[ICET] Rutile TiO₂: primitive atoms={len(primitive_positions)}, cell_size={cell_size}")
            
        elif "Anatase" in lattice_type:
            a = self.params.get('tio2_a', 3.784)
            c = self.params.get('tio2_c', 9.515)
            primitive_vectors, primitive_positions, primitive_elements = LatticeGenerator.anatase_tio2_primitive(a, c)
            print(f"[ICET] Anatase TiO₂: primitive atoms={len(primitive_positions)}, cell_size={cell_size}")
            
        elif "Brookite" in lattice_type:
            a = self.params.get('tio2_a', 5.456)
            b = self.params.get('tio2_b', 9.182)
            c = self.params.get('tio2_c', 5.143)
            primitive_vectors, primitive_positions, primitive_elements = LatticeGenerator.brookite_tio2_primitive(a, b, c)
            print(f"[ICET] Brookite TiO₂: primitive atoms={len(primitive_positions)}, cell_size={cell_size}")
            
        elif "Binary" in lattice_type:
            # For binary alloys, get the lattice subtype from UI
            if hasattr(self, 'binary_lattice_combo'):
                lattice_subtype = self.binary_lattice_combo.currentText()
            else:
                lattice_subtype = self.params.get('lattice_type', 'FCC')
            
            a = self.params.get('lattice_constant', 4.05)
            
            # Get conventional cell with correct number of atoms
            primitive_vectors, primitive_positions, primitive_elements = \
                LatticeGenerator.binary_alloy_primitive(lattice_subtype, a, cell_size)
            
            print(f"[ICET] Binary alloy: {lattice_subtype}, cell_size={cell_size}")
            print(f"[ICET] Conventional cell atoms: {len(primitive_positions)}")
            print(f"[ICET] Expected total atoms: {len(primitive_positions) * cell_size**3}")
            print(f"[ICET] Input atoms: {len(positions)}")
        
        # Create generator with primitive info
        if cation_indices is not None and len(cation_indices) > 0:
            generator = ICETSQSGeneratorMultiSublattice(
                lattice_vectors, positions, elements,
                cation_indices, element_A, element_B,
                composition,
                primitive_vectors=primitive_vectors,
                primitive_positions=primitive_positions,
                primitive_elements=primitive_elements,
                supercell_size=supercell_size,
                seed=int(time.time())
            )
        else:
            generator = ICETSQSGenerator(
                lattice_vectors, positions,
                element_A, element_B, composition,
                primitive_vectors=primitive_vectors,
                primitive_positions=primitive_positions,
                primitive_elements=primitive_elements,
                supercell_size=supercell_size,
                seed=int(time.time())
            )
        
        # Run the selected optimization method
        method = self.params.get('method', 'Random Search')
        
        if method == "Simulated Annealing":
            result = generator.simulated_annealing(
                T_start=self.params.get('temperature', 1.0),
                T_end=self.params.get('temperature', 1.0) * 0.01,
                steps_per_T=500,
                cooling_rate=0.95,
                convergence_threshold=self.params['convergence_threshold']
            )
        else:
            result = generator.random_search(
                n_trials=self.params.get('n_trials', 5000),
                convergence_threshold=self.params['convergence_threshold']
            )
        
        # Get final structure
        positions_out, elements_out = generator.get_structures()
        
        # Log the result
        print(f"[ICET] Final structure: {len(elements_out)} atoms")
        print(f"[ICET] Composition: {dict(zip(*np.unique(elements_out, return_counts=True)))}")
        
        return positions_out, elements_out, result

    def _run_fortran_backend(self, lattice_vectors, positions, elements,
                            cation_indices, composition, element_A, element_B):
        """Run Fortran backend - returns (positions, elements, result)"""
        
        engine = get_fortran_engine(lattice_vectors, positions, element_A, element_B, composition)
        if not engine or not engine.is_available:
            self.status.emit("Fortran not available, using Python")
            return self._run_python_backend(lattice_vectors, positions, elements,
                                            cation_indices, composition, element_A, element_B)
        
        # Handle multi-sublattice (TiO₂) by extracting only cation positions
        if cation_indices is not None and len(cation_indices) > 0:
            self.status.emit(f"Multi-sublattice detected: optimizing {len(cation_indices)} cation sites with Fortran")
            
            natoms_cations = len(cation_indices)
            n_B_cations = int(natoms_cations * composition)
            
            method = self.params.get('method', 'Random Search')
            
            try:
                if method == "Simulated Annealing":
                    result = engine.simulated_annealing(
                        natoms_cations, n_B_cations,
                        T_start=self.params.get('temperature', 1.0),
                        T_end=0.01,
                        steps_per_T=500,
                        cooling_rate=0.95,
                        composition=composition,
                        convergence_threshold=self.params['convergence_threshold']
                    )
                else:
                    result = engine.random_search(
                        natoms_cations, n_B_cations,
                        n_trials=self.params.get('n_trials', 5000),
                        composition=composition,
                        convergence_threshold=self.params['convergence_threshold']
                    )
                
                # Map back to full structure
                final_elements = elements.copy() if elements is not None else [element_A] * len(positions)
                for idx, spin in zip(cation_indices, result.spins):
                    final_elements[idx] = element_B if spin == 1 else element_A
                
                cart_positions = np.dot(positions, lattice_vectors)
                
                # Create SQSResult for compatibility
                from .utils.sqs_engine import SQSResult, SpinConfiguration
                config = SpinConfiguration(natoms_cations, composition)
                config.spins = np.array(result.spins)
                
                sqs_result = SQSResult(
                    configuration=config,
                    correlations={'pairs': {1: result.objective_value, 2: 0, 3: 0, 4: 0}},
                    objective_value=result.objective_value,
                    n_atoms=natoms_cations,
                    composition=composition,
                    method=result.method,
                    iterations=result.iterations,
                    time_seconds=result.time_seconds,
                    converged=result.converged
                )
                
                # Return TUPLE of 3 values
                return (cart_positions, final_elements, sqs_result)
                
            except Exception as e:
                self.status.emit(f"Fortran failed: {e}, using Python")
                return self._run_python_backend(lattice_vectors, positions, elements,
                                                cation_indices, composition, element_A, element_B)
        
        else:
            # Binary alloy - use Fortran directly
            natoms = len(positions)
            n_B = int(natoms * composition)
            
            method = self.params.get('method', 'Random Search')
            
            try:
                if method == "Simulated Annealing":
                    result = engine.simulated_annealing(
                        natoms, n_B,
                        T_start=self.params.get('temperature', 1.0),
                        T_end=0.01,
                        steps_per_T=500,
                        cooling_rate=0.95,
                        composition=composition,
                        convergence_threshold=self.params['convergence_threshold']
                    )
                else:
                    result = engine.random_search(
                        natoms, n_B,
                        n_trials=self.params.get('n_trials', 5000),
                        composition=composition,
                        convergence_threshold=self.params['convergence_threshold']
                    )
                
                final_elements = [element_B if s == 1 else element_A for s in result.spins]
                cart_positions = np.dot(positions, lattice_vectors)
                
                from .utils.sqs_engine import SQSResult, SpinConfiguration
                config = SpinConfiguration(natoms, composition)
                config.spins = np.array(result.spins)
                
                sqs_result = SQSResult(
                    configuration=config,
                    correlations={'pairs': {1: result.objective_value, 2: 0, 3: 0, 4: 0}},
                    objective_value=result.objective_value,
                    n_atoms=natoms,
                    composition=composition,
                    method=result.method,
                    iterations=result.iterations,
                    time_seconds=result.time_seconds,
                    converged=result.converged
                )
                
                # Return TUPLE of 3 values
                return (cart_positions, final_elements, sqs_result)
                
            except Exception as e:
                self.status.emit(f"Fortran failed: {e}, using Python")
                return self._run_python_backend(lattice_vectors, positions, elements,
                                                cation_indices, composition, element_A, element_B)

    def _run_luajit_backend(self, lattice_vectors, positions, elements,
                            cation_indices, composition, element_A, element_B):
        """Run LuaJIT backend - returns (positions, elements, result)"""
        
        engine = get_lua_engine(lattice_vectors, positions, element_A, element_B, composition)
        if not engine or not engine.is_available:
            self.status.emit("LuaJIT not available, using Python")
            return self._run_python_backend(lattice_vectors, positions, elements,
                                            cation_indices, composition, element_A, element_B)
        
        # Handle multi-sublattice (TiO₂) by extracting only cation positions
        if cation_indices is not None and len(cation_indices) > 0:
            self.status.emit(f"Multi-sublattice detected: optimizing {len(cation_indices)} cation sites with LuaJIT")
            
            natoms_cations = len(cation_indices)
            n_B_cations = int(natoms_cations * composition)
            
            method = self.params.get('method', 'Random Search')
            
            try:
                if method == "Simulated Annealing":
                    result = engine.simulated_annealing(
                        natoms_cations, n_B_cations,
                        T_start=self.params.get('temperature', 1.0),
                        T_end=0.01,
                        steps_per_T=500,
                        cooling_rate=0.95,
                        composition=composition,
                        convergence_threshold=self.params['convergence_threshold'],
                        callback=None
                    )
                else:
                    result = engine.random_search(
                        natoms_cations, n_B_cations,
                        n_trials=self.params.get('n_trials', 5000),
                        composition=composition,
                        convergence_threshold=self.params['convergence_threshold']
                    )
                
                # Map back to full structure
                final_elements = elements.copy() if elements is not None else [element_A] * len(positions)
                for idx, spin in zip(cation_indices, result.spins):
                    final_elements[idx] = element_B if spin == 1 else element_A
                
                cart_positions = np.dot(positions, lattice_vectors)
                
                from .utils.sqs_engine import SQSResult, SpinConfiguration
                config = SpinConfiguration(natoms_cations, composition)
                config.spins = np.array(result.spins)
                
                sqs_result = SQSResult(
                    configuration=config,
                    correlations={'pairs': {1: result.objective_value, 2: 0, 3: 0, 4: 0}},
                    objective_value=result.objective_value,
                    n_atoms=natoms_cations,
                    composition=composition,
                    method=result.method,
                    iterations=result.iterations,
                    time_seconds=result.time_seconds,
                    converged=result.converged
                )
                
                # Return TUPLE of 3 values
                return (cart_positions, final_elements, sqs_result)
                
            except Exception as e:
                self.status.emit(f"LuaJIT failed: {e}, using Python")
                return self._run_python_backend(lattice_vectors, positions, elements,
                                                cation_indices, composition, element_A, element_B)
        
        else:
            # Binary alloy - use LuaJIT directly
            natoms = len(positions)
            n_B = int(natoms * composition)
            
            method = self.params.get('method', 'Random Search')
            
            try:
                if method == "Simulated Annealing":
                    result = engine.simulated_annealing(
                        natoms, n_B,
                        T_start=self.params.get('temperature', 1.0),
                        T_end=0.01,
                        steps_per_T=500,
                        cooling_rate=0.95,
                        composition=composition,
                        convergence_threshold=self.params['convergence_threshold']
                    )
                else:
                    result = engine.random_search(
                        natoms, n_B,
                        n_trials=self.params.get('n_trials', 5000),
                        composition=composition,
                        convergence_threshold=self.params['convergence_threshold']
                    )
                
                final_elements = [element_B if s == 1 else element_A for s in result.spins]
                cart_positions = np.dot(positions, lattice_vectors)
                
                from .utils.sqs_engine import SQSResult, SpinConfiguration
                config = SpinConfiguration(natoms, composition)
                config.spins = np.array(result.spins)
                
                sqs_result = SQSResult(
                    configuration=config,
                    correlations={'pairs': {1: result.objective_value, 2: 0, 3: 0, 4: 0}},
                    objective_value=result.objective_value,
                    n_atoms=natoms,
                    composition=composition,
                    method=result.method,
                    iterations=result.iterations,
                    time_seconds=result.time_seconds,
                    converged=result.converged
                )
                
                # Return TUPLE of 3 values
                return (cart_positions, final_elements, sqs_result)
                
            except Exception as e:
                self.status.emit(f"LuaJIT failed: {e}, using Python")
                return self._run_python_backend(lattice_vectors, positions, elements,
                                                cation_indices, composition, element_A, element_B)

    def _run_luajit_ffi_backend(self, lattice_vectors, positions, elements,
                            cation_indices, composition, element_A, element_B):
        """Run LuaJIT FFI backend - returns (positions, elements, result)"""
        
        engine = get_ffi_engine(lattice_vectors, positions, element_A, element_B, composition)
        if not engine or not engine.is_available:
            self.status.emit("LuaJIT FFI not available, using Python")
            return self._run_python_backend(lattice_vectors, positions, elements,
                                            cation_indices, composition, element_A, element_B)
        
        # Handle multi-sublattice (TiO₂) by extracting only cation positions
        if cation_indices is not None and len(cation_indices) > 0:
            self.status.emit(f"Multi-sublattice detected: optimizing {len(cation_indices)} cation sites with LuaJIT FFI")
            
            natoms_cations = len(cation_indices)
            n_B_cations = int(natoms_cations * composition)
            
            method = self.params.get('method', 'Random Search')
            
            try:
                if method == "Simulated Annealing":
                    result = engine.simulated_annealing(
                        natoms_cations, n_B_cations,
                        T_start=self.params.get('temperature', 1.0),
                        T_end=0.01,
                        steps_per_T=500,
                        cooling_rate=0.95,
                        composition=composition,
                        convergence_threshold=self.params['convergence_threshold'],
                        callback=None
                    )
                else:
                    result = engine.random_search(
                        natoms_cations, n_B_cations,
                        n_trials=self.params.get('n_trials', 5000),
                        composition=composition,
                        convergence_threshold=self.params['convergence_threshold']
                    )
                
                # Map back to full structure
                final_elements = elements.copy() if elements is not None else [element_A] * len(positions)
                for idx, spin in zip(cation_indices, result.spins):
                    final_elements[idx] = element_B if spin == 1 else element_A
                
                cart_positions = np.dot(positions, lattice_vectors)
                
                from .utils.sqs_engine import SQSResult, SpinConfiguration
                config = SpinConfiguration(natoms_cations, composition)
                config.spins = np.array(result.spins)
                
                sqs_result = SQSResult(
                    configuration=config,
                    correlations={'pairs': {1: result.objective_value, 2: 0, 3: 0, 4: 0}},
                    objective_value=result.objective_value,
                    n_atoms=natoms_cations,
                    composition=composition,
                    method=result.method,
                    iterations=result.iterations,
                    time_seconds=result.time_seconds,
                    converged=result.converged
                )
                
                # Return TUPLE of 3 values
                return (cart_positions, final_elements, sqs_result)
                
            except Exception as e:
                self.status.emit(f"LuaJIT FFI failed: {e}, using Python")
                return self._run_python_backend(lattice_vectors, positions, elements,
                                                cation_indices, composition, element_A, element_B)
        
        else:
            # Binary alloy - use LuaJIT directly
            natoms = len(positions)
            n_B = int(natoms * composition)
            
            method = self.params.get('method', 'Random Search')
            
            try:
                if method == "Simulated Annealing":
                    result = engine.simulated_annealing(
                        natoms, n_B,
                        T_start=self.params.get('temperature', 1.0),
                        T_end=0.01,
                        steps_per_T=500,
                        cooling_rate=0.95,
                        composition=composition,
                        convergence_threshold=self.params['convergence_threshold']
                    )
                else:
                    result = engine.random_search(
                        natoms, n_B,
                        n_trials=self.params.get('n_trials', 5000),
                        composition=composition,
                        convergence_threshold=self.params['convergence_threshold']
                    )
                
                final_elements = [element_B if s == 1 else element_A for s in result.spins]
                cart_positions = np.dot(positions, lattice_vectors)
                
                from .utils.sqs_engine import SQSResult, SpinConfiguration
                config = SpinConfiguration(natoms, composition)
                config.spins = np.array(result.spins)
                
                sqs_result = SQSResult(
                    configuration=config,
                    correlations={'pairs': {1: result.objective_value, 2: 0, 3: 0, 4: 0}},
                    objective_value=result.objective_value,
                    n_atoms=natoms,
                    composition=composition,
                    method=result.method,
                    iterations=result.iterations,
                    time_seconds=result.time_seconds,
                    converged=result.converged
                )
                
                # Return TUPLE of 3 values
                return (cart_positions, final_elements, sqs_result)
                
            except Exception as e:
                self.status.emit(f"LuaJIT failed: {e}, using Python")
                return self._run_python_backend(lattice_vectors, positions, elements,
                                                cation_indices, composition, element_A, element_B)

    def run(self):
        try:
            self.status.emit("Generating lattice...")
            self.progress.emit(10)
            
            lattice_type = self.params.get('lattice_type')
            cell_size = self.params.get('cell_size', 2)
            backend = self.params.get('backend', 'python')
            
            # Generate lattice (same for all backends)
            if lattice_type == "FromPOSCAR":
                lattice_vectors = self.params['lattice_vectors']
                positions = self.params['positions']
                elements = self.params['elements']
                cation_indices = self.params.get('cation_indices')
                self.status.emit(f"Loaded structure with {len(positions)} atoms")
                self.progress.emit(20)
                
            else:
                # Generate from scratch
                if lattice_type == "FCC":
                    lattice_vectors, positions = LatticeGenerator.fcc_lattice(
                        cell_size, self.params.get('lattice_constant', 4.05)
                    )
                    elements = None
                    cation_indices = None
                    
                elif lattice_type == "BCC":
                    lattice_vectors, positions = LatticeGenerator.bcc_lattice(
                        cell_size, self.params.get('lattice_constant', 3.15)
                    )
                    elements = None
                    cation_indices = None
                    
                elif lattice_type == "Simple Cubic":
                    lattice_vectors, positions = LatticeGenerator.simple_cubic_lattice(
                        cell_size, self.params.get('lattice_constant', 3.0)
                    )
                    elements = None
                    cation_indices = None
                    
                elif lattice_type == "HCP":
                    lattice_vectors, positions = LatticeGenerator.hcp_lattice(
                        cell_size, (self.params.get('lattice_constant', 3.2), 
                                   self.params.get('lattice_constant', 3.2) * 1.633)
                    )
                    elements = None
                    cation_indices = None
                    
                elif lattice_type == "Rutile TiO₂":
                    a = self.params.get('tio2_a', 4.594)
                    c = self.params.get('tio2_c', 2.959)
                    lattice_vectors, positions, elements = LatticeGenerator.rutile_tio2(cell_size, a, c)
                    cation_indices = [i for i, e in enumerate(elements) if e == 'Ti']
                    
                elif lattice_type == "Anatase TiO₂":
                    a = self.params.get('tio2_a', 3.784)
                    c = self.params.get('tio2_c', 9.515)
                    lattice_vectors, positions, elements = LatticeGenerator.anatase_tio2(cell_size, a, c)
                    cation_indices = [i for i, e in enumerate(elements) if e == 'Ti']
                    
                elif lattice_type == "Brookite TiO₂":
                    a = self.params.get('tio2_a', 5.456)
                    b = self.params.get('tio2_b', 9.182)
                    c = self.params.get('tio2_c', 5.143)
                    lattice_vectors, positions, elements = LatticeGenerator.brookite_tio2(cell_size, a, b, c)
                    cation_indices = [i for i, e in enumerate(elements) if e == 'Ti']
                    
                else:
                    raise ValueError(f"Unknown lattice type: {lattice_type}")
            
            self.status.emit(f"Generated {len(positions)} atoms")
            self.progress.emit(30)
            
            if self._is_cancelled:
                return
            
            composition = self.params['composition']
            element_A = self.params['element_A']
            element_B = self.params['element_B']
            
            self.status.emit(f"Running {backend} backend...")
            
            # ALL backends must return 3 values: positions, elements, result
            if backend == "fortran" and FORTRAN_AVAILABLE:
                positions_out, elements_out, result = self._run_fortran_backend(
                    lattice_vectors, positions, elements,
                    cation_indices, composition, element_A, element_B
                )
            elif backend == "luajit" and LUA_AVAILABLE:
                positions_out, elements_out, result = self._run_luajit_backend(
                    lattice_vectors, positions, elements,
                    cation_indices, composition, element_A, element_B
                )
            elif backend == "luajitffi" and LUAFFI_AVAILABLE:
                positions_out, elements_out, result = self._run_luajit_ffi_backend(
                    lattice_vectors, positions, elements,
                    cation_indices, composition, element_A, element_B
                )
            elif backend == "icet" and HAS_ICET:
                positions_out, elements_out, result = self._run_icet_backend(
                    lattice_vectors, positions, elements,
                    cation_indices, composition, element_A, element_B
                )
            else:
                positions_out, elements_out, result = self._run_python_backend(
                    lattice_vectors, positions, elements,
                    cation_indices, composition, element_A, element_B
                )
            
            self.progress.emit(90)
            
            if self._is_cancelled:
                return
            
            self.status.emit("Optimization complete!")
            self.progress.emit(100)
            
            self.finished.emit(positions_out, elements_out, result)
            
        except Exception as e:
            self.error.emit(str(e))


class SQSGeneratorWidget(QWidget):
    """Main widget for SQS Generator"""

    # Signal to send substitution results to XYZ widget
    substitution_performed = Signal(object, object, object)  # positions, elements, info

    def __init__(self, plugin_instance=None):
        super().__init__()
        self.plugin = plugin_instance
        self.current_structure: Optional[POSCARStructure] = None
        self.worker = None
        self.current_positions = None
        self.current_elements = None
        self.current_lattice_vectors = None
        self.xyz_results = None
        self.temp_manager = TempFileManager()
        
        # Create XYZ visualization widget
        self.xyz_widget = XYZVisualizationWidget()
        
        self.init_ui()
        self.setup_connections()
        
        # Clean up old temp files on startup
        self.temp_manager.cleanup_old_files()
    
    def init_ui(self):
        # 1. Main Window Layout (The container for everything)
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)

        # 2. Main Vertical Splitter
        splitter_main = QSplitter(Qt.Vertical)

        # --- TOP SECTION (Header Container) ---
        header_container = QWidget()
        header_layout = QVBoxLayout(header_container)
        header_layout.setContentsMargins(5, 5, 5, 5)
        header_layout.setSpacing(5)

        title = QLabel("Special Quasirandom Structure (SQS) Generator")
        title.setFont(QFont("Arial", 12, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("""
            QLabel {
                color: #666;
                font-weight: bold;
                padding: 4px;
                border: 1px solid #2196F3;
                border-radius: 3px;
            }
        """)
        header_layout.addWidget(title)

        ref = QLabel("Zunger et al. PRL 65, 353 (1990) | van de Walle et al. CALPHAD 42, 13 (2013)")
        ref.setStyleSheet("""
            QLabel {
                color: #666;
                font-weight: bold;
                padding: 4px;
                font-size: 9px;
                border: 1px solid #2196F3;
                border-radius: 3px;
            }
        """)
        ref.setAlignment(Qt.AlignCenter)
        header_layout.addWidget(ref)

        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        header_layout.addWidget(self.progress_bar)

        self.status_label = QLabel("Ready")
        header_layout.addWidget(self.status_label)

        # --- BOTTOM SECTION (The Panels) ---
        panel_splitter = QSplitter(Qt.Horizontal)
        
        # Left Scroll Area
        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setWidget(self.create_control_panel())
        
        # Right Panel
        right_panel = self.create_results_panel()
        
        panel_splitter.addWidget(left_scroll)
        panel_splitter.addWidget(right_panel)
        panel_splitter.setSizes([400, 600])

        # 3. Assemble the Main Splitter
        splitter_main.addWidget(header_container) 
        splitter_main.addWidget(panel_splitter)
        splitter_main.setStretchFactor(0, 0)
        splitter_main.setStretchFactor(1, 1)
        splitter_main.setSizes([150, 850])

        # 4. Add the splitter to the window
        main_layout.addWidget(splitter_main)
    
    def create_control_panel(self) -> QWidget:
        """Create left control panel"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setSpacing(5)
        layout.setContentsMargins(5, 5, 5, 5)
        
        # Structure type
        type_group = QGroupBox("Structure Type")
        type_group.setStyleSheet("QGroupBox { font-weight: bold; margin-top: 6px; }")
        type_layout = QVBoxLayout()
        type_layout.setContentsMargins(5, 8, 5, 5)
        
        self.structure_type_combo = QComboBox()
        self.structure_type_combo.addItems([
            "Binary Alloy (FCC/BCC/HCP)",
            "TiO₂ - Rutile",
            "TiO₂ - Anatase",
            "TiO₂ - Brookite",
            "From POSCAR File"
        ])
        self.structure_type_combo.currentTextChanged.connect(self.on_structure_type_changed)
        type_layout.addWidget(self.structure_type_combo)
        
        type_group.setLayout(type_layout)
        layout.addWidget(type_group)
        
        # Lattice parameters container
        self.lattice_group = QGroupBox("Lattice Parameters")
        self.lattice_layout = QVBoxLayout()
        self.lattice_group.setLayout(self.lattice_layout)
        layout.addWidget(self.lattice_group)
        
        # Initialize default
        self.init_binary_alloy_controls()
        
        # Composition
        comp_group = QGroupBox("Composition")
        comp_layout = QGridLayout()
        
        comp_layout.addWidget(QLabel("Element A (Host):"), 0, 0)
        self.element_A_edit = QLineEdit("Ti")
        comp_layout.addWidget(self.element_A_edit, 0, 1)
        
        comp_layout.addWidget(QLabel("Element B (Dopant):"), 1, 0)
        self.element_B_edit = QLineEdit("Sn")
        comp_layout.addWidget(self.element_B_edit, 1, 1)
        
        comp_layout.addWidget(QLabel("Composition of B:"), 2, 0)
        self.composition_spin = QDoubleSpinBox()
        self.composition_spin.setRange(0.0, 1.0)
        self.composition_spin.setValue(0.25)
        self.composition_spin.setSingleStep(0.01)
        self.composition_spin.setDecimals(8)
        comp_layout.addWidget(self.composition_spin, 2, 1)
        
        comp_group.setLayout(comp_layout)
        layout.addWidget(comp_group)
        
        # Info label
        self.substitution_info_label = QLabel(
            "Sn will substitute Ti on cation sites.\nOxygen sublattice remains unchanged."
        )
        self.substitution_info_label.setWordWrap(True)
        self.substitution_info_label.setStyleSheet("color: #555; font-size: 10px; padding: 5px;")
        layout.addWidget(self.substitution_info_label)
        
        # Optimization
        opt_group = QGroupBox("Optimization")
        opt_layout = QGridLayout()
        
        opt_layout.addWidget(QLabel("Method:"), 0, 0)
        self.method_combo = QComboBox()
        self.method_combo.addItems(["Random Search", "Simulated Annealing"])
        self.method_combo.currentTextChanged.connect(self.on_method_changed)
        opt_layout.addWidget(self.method_combo, 0, 1)
        
        opt_layout.addWidget(QLabel("Number of Trials:"), 1, 0)
        self.trials_spin = QSpinBox()
        self.trials_spin.setRange(100, 100000)
        self.trials_spin.setValue(10000)
        self.trials_spin.setSingleStep(1000)
        opt_layout.addWidget(self.trials_spin, 1, 1)
        
        opt_layout.addWidget(QLabel("Temperature:"), 2, 0)
        self.temp_spin = QDoubleSpinBox()
        self.temp_spin.setRange(0.1, 10.0)
        self.temp_spin.setValue(1.0)
        self.temp_spin.setEnabled(False)
        opt_layout.addWidget(self.temp_spin, 2, 1)

        opt_layout.addWidget(QLabel("ConvergenceThreshold:"), 3, 0)
        self.convergence_spin = QDoubleSpinBox()
        self.convergence_spin.setRange(0.0001, 1.0)
        self.convergence_spin.setValue(0.15)
        self.convergence_spin.setDecimals(4)
        self.convergence_spin.setSingleStep(0.0001)
        self.convergence_spin.setToolTip(
            "Objective value threshold for considering the structure converged.\n"
            "Lower values = more strict convergence criteria.\n"
            "Default 0.15 works well for most alloys."
        )
        opt_layout.addWidget(self.convergence_spin, 3, 1)

        opt_layout.addWidget(QLabel("Presets Cutoff:"), 4, 0)
        self.cutoff_preset = QComboBox()
        self.cutoff_preset.addItems(["Custom", "Metals (~2.8Å)", "Oxides (~2.5Å)", "Molecular (~3.0Å)"])
        self.cutoff_preset.currentTextChanged.connect(self.on_cutoff_preset_changed)
        opt_layout.addWidget(self.cutoff_preset, 4, 1)

        opt_layout.addWidget(QLabel("Neighbor Cutoff (Å):"), 5, 0)
        self.neighbor_cutoff_spin = QDoubleSpinBox()
        self.neighbor_cutoff_spin.setRange(1.0, 10.0)
        self.neighbor_cutoff_spin.setValue(2.5)
        self.neighbor_cutoff_spin.setSingleStep(0.1)
        self.neighbor_cutoff_spin.setToolTip(
            "Distance cutoff for neighbor detection in correlation functions.\n"
            "Smaller values = fewer neighbors (faster).\n"
            "Larger values = more neighbors (more accurate).\n"
            "Default 2.5 Å works for most structures."
        )
        opt_layout.addWidget(self.neighbor_cutoff_spin, 5, 1)
        
        opt_group.setLayout(opt_layout)
        layout.addWidget(opt_group)

        # Backend Selector
        backend_group = self.init_backend_selector()
        layout.addWidget(backend_group)
        
        # Actions
        action_group = QGroupBox("Actions")
        action_layout = QVBoxLayout()
        
        self.generate_btn = QPushButton("Generate SQS")
        self.generate_btn.setStyleSheet("background-color: #4CAF50; color: white; font-weight: bold; padding: 8px;")
        self.generate_btn.clicked.connect(self.generate_sqs)
        action_layout.addWidget(self.generate_btn)
        
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.clicked.connect(self.cancel_generation)
        action_layout.addWidget(self.cancel_btn)
        
        action_group.setLayout(action_layout)
        layout.addWidget(action_group)
        
        # Export
        export_group = QGroupBox("Export")
        export_layout = QVBoxLayout()
        
        self.export_poscar_btn = QPushButton("Export POSCAR (VASP)")
        self.export_poscar_btn.setEnabled(False)
        self.export_poscar_btn.clicked.connect(lambda: self.export_file("poscar"))
        export_layout.addWidget(self.export_poscar_btn)
        
        self.export_xyz_btn = QPushButton("Export XYZ")
        self.export_xyz_btn.setEnabled(False)
        self.export_xyz_btn.clicked.connect(lambda: self.export_file("xyz"))
        export_layout.addWidget(self.export_xyz_btn)
        
        self.export_cif_btn = QPushButton("Export CIF")
        self.export_cif_btn.setEnabled(False)
        self.export_cif_btn.clicked.connect(lambda: self.export_file("cif"))
        export_layout.addWidget(self.export_cif_btn)
        
        export_group.setLayout(export_layout)
        layout.addWidget(export_group)
        
        layout.addStretch()
        
        return panel
    
    def init_binary_alloy_controls(self):
        """Initialize binary alloy lattice controls"""
        self.clear_lattice_controls()
        
        layout = QFormLayout()
        layout.setSpacing(3)
        layout.setContentsMargins(5, 5, 5, 5)
        
        self.binary_lattice_combo = QComboBox()
        self.binary_lattice_combo.addItems(["FCC", "BCC", "Simple Cubic", "HCP"])
        layout.addRow("Lattice Type:", self.binary_lattice_combo)
        
        self.binary_cell_size = QSpinBox()
        self.binary_cell_size.setRange(1, 5)
        self.binary_cell_size.setValue(2)
        layout.addRow("Cell Size:", self.binary_cell_size)
        
        self.binary_lattice_const = QDoubleSpinBox()
        self.binary_lattice_const.setRange(2.0, 10.0)
        self.binary_lattice_const.setValue(4.05)
        self.binary_lattice_const.setSingleStep(0.05)
        layout.addRow("Lattice Constant (Å):", self.binary_lattice_const)
        
        self.binary_n_atoms_label = QLabel("32")
        layout.addRow("Number of Atoms:", self.binary_n_atoms_label)
        
        self.binary_cell_size.valueChanged.connect(self.update_binary_atom_count)
        self.binary_lattice_combo.currentTextChanged.connect(self.update_binary_atom_count)
        
        self.lattice_layout.addLayout(layout)
        self.update_binary_atom_count()
    
    def init_tio2_controls(self, polymorph: str):
        """Initialize TiO₂ lattice controls"""
        self.clear_lattice_controls()
        
        layout = QFormLayout()
        layout.setSpacing(3)
        layout.setContentsMargins(5, 5, 5, 5)
        
        self.tio2_cell_size = QSpinBox()
        self.tio2_cell_size.setRange(1, 10)
        self.tio2_cell_size.setValue(2)
        layout.addRow("Supercell Size:", self.tio2_cell_size)
        
        if polymorph == "Rutile TiO₂":
            self.tio2_a = QDoubleSpinBox()
            self.tio2_a.setRange(4.0, 5.0)
            self.tio2_a.setValue(4.594)
            self.tio2_a.setSingleStep(0.01)
            layout.addRow("a = b (Å):", self.tio2_a)
            
            self.tio2_c = QDoubleSpinBox()
            self.tio2_c.setRange(2.5, 3.5)
            self.tio2_c.setValue(2.959)
            self.tio2_c.setSingleStep(0.01)
            layout.addRow("c (Å):", self.tio2_c)
            
        elif polymorph == "Anatase TiO₂":
            self.tio2_a = QDoubleSpinBox()
            self.tio2_a.setRange(3.5, 4.5)
            self.tio2_a.setValue(3.784)
            layout.addRow("a = b (Å):", self.tio2_a)
            
            self.tio2_c = QDoubleSpinBox()
            self.tio2_c.setRange(8.0, 11.0)
            self.tio2_c.setValue(9.515)
            layout.addRow("c (Å):", self.tio2_c)
            
        else:  # Brookite
            self.tio2_a = QDoubleSpinBox()
            self.tio2_a.setRange(5.0, 6.0)
            self.tio2_a.setValue(5.456)
            layout.addRow("a (Å):", self.tio2_a)
            
            self.tio2_b = QDoubleSpinBox()
            self.tio2_b.setRange(8.0, 10.0)
            self.tio2_b.setValue(9.182)
            layout.addRow("b (Å):", self.tio2_b)
            
            self.tio2_c = QDoubleSpinBox()
            self.tio2_c.setRange(4.5, 6.0)
            self.tio2_c.setValue(5.143)
            layout.addRow("c (Å):", self.tio2_c)
        
        # Atom counts
        self.tio2_n_ti_label = QLabel("16")
        self.tio2_n_o_label = QLabel("32")
        self.tio2_n_total_label = QLabel("48")
        layout.addRow("Ti atoms:", self.tio2_n_ti_label)
        layout.addRow("O atoms:", self.tio2_n_o_label)
        layout.addRow("Total:", self.tio2_n_total_label)
        
        self.tio2_cell_size.valueChanged.connect(lambda: self.update_tio2_atom_count(polymorph))
        
        self.lattice_layout.addLayout(layout)
        self.update_tio2_atom_count(polymorph)
    
    def init_poscar_controls(self):
        """Initialize POSCAR loading controls"""
        self.clear_lattice_controls()
        
        layout = QFormLayout()
        layout.setSpacing(3)
        layout.setContentsMargins(5, 5, 5, 5)
        
        self.load_poscar_btn = QPushButton("Load POSCAR File")
        self.load_poscar_btn.clicked.connect(self.load_poscar_file)
        layout.addRow("", self.load_poscar_btn)
        
        self.poscar_file_label = QLabel("No file loaded")
        self.poscar_file_label.setStyleSheet("color: #666; font-size: 10px;")
        layout.addRow("File:", self.poscar_file_label)
        
        self.poscar_info_label = QLabel("")
        self.poscar_info_label.setStyleSheet("color: #666; font-size: 10px;")
        layout.addRow("Info:", self.poscar_info_label)
        
        layout.addRow(QLabel(""), QLabel("--- Substitution Settings ---"))
        
        self.cation_element_edit = QLineEdit("Ti")
        layout.addRow("Cation Element:", self.cation_element_edit)
        
        self.available_cations_label = QLabel("0 cations available")
        self.available_cations_label.setStyleSheet("color: #666; font-size: 10px;")
        layout.addRow("Available:", self.available_cations_label)
        
        self.lattice_layout.addLayout(layout)
    
    def clear_lattice_controls(self):
        """Clear lattice controls"""
        for i in reversed(range(self.lattice_layout.count())):
            item = self.lattice_layout.itemAt(i)
            if item and item.layout():
                for j in reversed(range(item.layout().count())):
                    widget = item.layout().itemAt(j).widget()
                    if widget:
                        widget.deleteLater()
                item.layout().deleteLater()
            elif item and item.widget():
                item.widget().deleteLater()
    
    def update_binary_atom_count(self):
        """Update atom count for binary alloys"""
        lattice = self.binary_lattice_combo.currentText()
        cell_size = self.binary_cell_size.value()
        
        if lattice == "FCC":
            n_atoms = 4 * cell_size**3
        elif lattice == "BCC":
            n_atoms = 2 * cell_size**3
        elif lattice == "Simple Cubic":
            n_atoms = cell_size**3
        elif lattice == "HCP":
            n_atoms = 2 * cell_size**3
        else:
            n_atoms = 0
        
        self.binary_n_atoms_label.setText(str(n_atoms))
    
    def update_tio2_atom_count(self, polymorph: str):
        """Update atom count for TiO₂"""
        cell_size = self.tio2_cell_size.value()
        
        if "Rutile" in polymorph:
            n_ti = 2 * cell_size**3
            n_o = 4 * cell_size**3
        elif "Anatase" in polymorph:
            n_ti = 4 * cell_size**3
            n_o = 8 * cell_size**3
        else:
            n_ti = 8 * cell_size**3
            n_o = 16 * cell_size**3
        
        self.tio2_n_ti_label.setText(str(n_ti))
        self.tio2_n_o_label.setText(str(n_o))
        self.tio2_n_total_label.setText(str(n_ti + n_o))
    
    def on_structure_type_changed(self, structure_type: str):
        """Handle structure type change"""
        if "Binary" in structure_type:
            self.init_binary_alloy_controls()
            self.substitution_info_label.setText(
                "Binary alloy: Element B substitutes Element A on all sites.\nBoth elements share the same sublattice."
            )
            self.element_A_edit.setText("A")
            self.element_B_edit.setText("B")
            self.generate_btn.setEnabled(True)
            
        elif "Rutile" in structure_type:
            self.init_tio2_controls("Rutile TiO₂")
            self.substitution_info_label.setText(
                "TiO₂ (Rutile): Sn substitutes Ti on cation sites.\nOxygen sublattice remains unchanged.\nSpace group: P4₂/mnm"
            )
            self.element_A_edit.setText("Ti")
            self.element_B_edit.setText("Sn")
            self.generate_btn.setEnabled(True)
            
        elif "Anatase" in structure_type:
            self.init_tio2_controls("Anatase TiO₂")
            self.substitution_info_label.setText(
                "TiO₂ (Anatase): Sn substitutes Ti on cation sites.\nOxygen sublattice remains unchanged.\nSpace group: I4₁/amd"
            )
            self.element_A_edit.setText("Ti")
            self.element_B_edit.setText("Sn")
            self.generate_btn.setEnabled(True)
            
        elif "Brookite" in structure_type:
            self.init_tio2_controls("Brookite TiO₂")
            self.substitution_info_label.setText(
                "TiO₂ (Brookite): Sn substitutes Ti on cation sites.\nOxygen sublattice remains unchanged.\nSpace group: Pbca"
            )
            self.element_A_edit.setText("Ti")
            self.element_B_edit.setText("Sn")
            self.generate_btn.setEnabled(True)
            
        elif "From POSCAR" in structure_type:
            self.init_poscar_controls()
            self.substitution_info_label.setText(
                "Load an existing POSCAR file.\nThe SQS will be generated by substituting atoms\non the original structure's lattice."
            )
            self.element_A_edit.setText("Host")
            self.element_B_edit.setText("Dopant")
            self.generate_btn.setEnabled(False)

    def on_method_changed(self, method: str):
        """Handle optimization method change"""
        if method == "Simulated Annealing":
            self.temp_spin.setEnabled(True)
        else:
            self.temp_spin.setEnabled(False)

    def on_cutoff_preset_changed(self, preset):
        if preset == "Metals (~2.8Å)":
            self.neighbor_cutoff_spin.setValue(2.8)
        elif preset == "Oxides (~2.5Å)":
            self.neighbor_cutoff_spin.setValue(2.5)
        elif preset == "Molecular (~3.0Å)":
            self.neighbor_cutoff_spin.setValue(3.0)

    def load_poscar_file(self):
        """Load POSCAR file using the parser from vaps_poscar_editor"""
        try:           
            from .utils.poscar_parser import POSCARParser
            parser_available = True
            
        except ImportError:
            parser_available = False
        
        filepath, _ = QFileDialog.getOpenFileName(
            self, "Open POSCAR File", "",
            "POSCAR Files (POSCAR* CONTCAR*);;All Files (*.*)"
        )
        
        if not filepath:
            return
        
        try:
            if parser_available:
                structure = POSCARParser.parse(filepath)
                if structure:
                    self.current_lattice_vectors = structure.lattice * structure.scale
                    self.current_positions = POSCARParser.get_coordinate_matrix(structure)
                    
                    self.current_elements = []
                    for elem, count in zip(structure.elements, structure.atom_counts):
                        self.current_elements.extend([elem] * count)
                    
                    self.poscar_file_label.setText(Path(filepath).name)
                    self.poscar_info_label.setText(f"{len(self.current_elements)} atoms: {', '.join(structure.elements)}")
                    
                    unique_elements = set(self.current_elements)
                    if 'O' in unique_elements:
                        cations = [e for e in unique_elements if e != 'O']
                        if cations:
                            self.cation_element_edit.setText(cations[0])
                            self.available_cations_label.setText(f"{self.current_elements.count(cations[0])} {cations[0]} atoms")
                    
                    self.status_label.setText(f"Loaded: {Path(filepath).name}")
                    self.generate_btn.setEnabled(True)
                    
                    QMessageBox.information(self, "Success", f"Loaded POSCAR with {len(self.current_elements)} atoms")
                else:
                    QMessageBox.critical(self, "Error", "Failed to parse POSCAR file")
            else:
                QMessageBox.warning(self, "Warning", "POSCAR parser not available. Please install VAPS POSCAR Editor plugin.")
                
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load POSCAR: {str(e)}")
    
    def generate_sqs(self):
        """Start SQS generation"""
        element_A = self.element_A_edit.text().strip()
        element_B = self.element_B_edit.text().strip()
        
        if not element_A or not element_B:
            QMessageBox.warning(self, "Warning", "Please enter element symbols")
            return
        
        if element_A == element_B:
            QMessageBox.warning(self, "Warning", "Elements must be different")
            return
        
        composition = self.composition_spin.value()
        if composition <= 0 or composition >= 1:
            QMessageBox.warning(self, "Warning", "Composition must be between 0 and 1")
            return
        
        structure_type = self.structure_type_combo.currentText()
        
        if "From POSCAR" in structure_type and self.current_positions is None:
            QMessageBox.warning(self, "Warning", "Please load a POSCAR file first")
            return
        
        self.generate_btn.setEnabled(False)
        self.cancel_btn.setEnabled(True)
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.results_text.clear()
        
        params = {
            'element_A': element_A,
            'element_B': element_B,
            'composition': composition,
            'method': self.method_combo.currentText(),
            'n_trials': self.trials_spin.value(),
            'temperature': self.temp_spin.value(),
            'backend': self.backend_combo.currentData(),
            'convergence_threshold': self.convergence_spin.value(),
            'neighbor_cutoff': self.neighbor_cutoff_spin.value()
        }
        
        if "Binary" in structure_type:
            params['lattice_type'] = self.binary_lattice_combo.currentText()
            params['cell_size'] = self.binary_cell_size.value()
            params['lattice_constant'] = self.binary_lattice_const.value()
            
        elif "Rutile" in structure_type:
            params['lattice_type'] = "Rutile TiO₂"
            params['cell_size'] = self.tio2_cell_size.value()
            params['tio2_a'] = self.tio2_a.value()
            params['tio2_c'] = self.tio2_c.value()
            
        elif "Anatase" in structure_type:
            params['lattice_type'] = "Anatase TiO₂"
            params['cell_size'] = self.tio2_cell_size.value()
            params['tio2_a'] = self.tio2_a.value()
            params['tio2_c'] = self.tio2_c.value()
            
        elif "Brookite" in structure_type:
            params['lattice_type'] = "Brookite TiO₂"
            params['cell_size'] = self.tio2_cell_size.value()
            params['tio2_a'] = self.tio2_a.value()
            params['tio2_b'] = self.tio2_b.value()
            params['tio2_c'] = self.tio2_c.value()
            
        elif "From POSCAR" in structure_type:
            params['lattice_type'] = "FromPOSCAR"
            params['lattice_vectors'] = self.current_lattice_vectors
            params['positions'] = self.current_positions
            params['elements'] = self.current_elements
            params['cation_indices'] = [i for i, e in enumerate(self.current_elements) 
                                       if e == self.cation_element_edit.text().strip()]
        
        self.worker = SQSWorker(params)
        self.worker.progress.connect(self.update_progress)
        self.worker.status.connect(self.update_status)
        self.worker.finished.connect(self.on_generation_finished)
        self.worker.error.connect(self.on_generation_error)
        self.worker.start()
    
    def update_progress(self, value: int):
        self.progress_bar.setValue(value)
    
    def update_status(self, status: str):
        self.status_label.setText(status)
    
    def on_generation_finished_old(self, positions, elements, result):
        """Handle generation completion"""
        self.current_positions = positions
        self.current_elements = elements
        
        structure_type = self.structure_type_combo.currentText()
        if "Binary" in structure_type:
            a = self.binary_lattice_const.value()
            self.current_lattice_vectors = np.diag([a, a, a])
        elif "From POSCAR" in structure_type:
            pass  # Keep existing lattice vectors
        else:
            if hasattr(self, 'tio2_a'):
                a = self.tio2_a.value()
                if hasattr(self, 'tio2_c'):
                    c = self.tio2_c.value()
                    self.current_lattice_vectors = np.array([[a, 0, 0], [0, a, 0], [0, 0, c]])
        
        final_comp = Counter(elements)
        element_A = self.element_A_edit.text().strip()
        element_B = self.element_B_edit.text().strip()
        
        results_text = f"""
SQS Generation Results
======================

Structure Type: {structure_type}
Method: {result.method}
Objective value: {result.objective_value:.6f}
Iterations: {result.iterations}
Time: {result.time_seconds:.2f} seconds
Converged: {result.converged}

Composition:
  {element_A}: {final_comp.get(element_A, 0)}
  {element_B}: {final_comp.get(element_B, 0)}
"""
        if 'O' in final_comp:
            results_text += f"  O: {final_comp.get('O', 0)}\n"
        
        results_text += f"\nTotal atoms: {len(elements)}\n\nCorrelations (pair):\n"
        for shell, corr in result.correlations['pairs'].items():
            results_text += f"  Shell {shell}: {corr:.6f}\n"
        
        self.results_text.setText(results_text)
        
        self.export_poscar_btn.setEnabled(True)
        self.export_xyz_btn.setEnabled(True)
        self.export_cif_btn.setEnabled(True)
        
        self.generate_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.progress_bar.setVisible(False)
        self.status_label.setText("Generation complete!")
        
        # Show success message
        QMessageBox.information(self, "Success", f"SQS generated successfully!\nTotal atoms: {len(elements)}\nObjective value: {result.objective_value:.6f}")

        indices_list = [0] * final_comp.get(element_B, 0)
        self.xyz_results = {
            'strategy': result.method,
            'source_element': final_comp.get(element_A, 0),
            'target_element': final_comp.get(element_B, 0),
            'selected_indices': indices_list
        }
        
        # Update XYZ visualization with proper error handling
        try:
            # Ensure positions and elements are valid
            if positions is not None and len(positions) > 0:
                if elements is not None and len(elements) == len(positions):
                    self.xyz_widget.update_with_positions(positions, elements, self.xyz_results)
                    print(f"[SQS] Updated 3D view with {len(positions)} atoms")
                else:
                    print(f"[SQS] Error: elements length ({len(elements) if elements else 0}) != positions length ({len(positions)})")
            else:
                print(f"[SQS] Error: Invalid positions or elements")
        except Exception as e:
            print(f"[SQS] Error updating 3D view: {e}")
            import traceback
            traceback.print_exc()
        
        # Switch to visualization tab
        try:
            self.tab_widget.setCurrentIndex(1)
            print(f"[SQS] Switched to visualization tab")
        except Exception as e:
            print(f"[SQS] Error switching tab: {e}")
        
        # Emit signal for any other listeners (important for plugin integration)
        try:
            info = {
                'mode': 'sqs',
                'description': 'SQS generation complete',
                'n_atoms': len(elements),
                'objective_value': result.objective_value,
                'method': result.method
            }
            self.substitution_performed.emit(positions, elements, info)
            print(f"[SQS] Emitted substitution_performed signal")
        except Exception as e:
            print(f"[SQS] Error emitting signal: {e}")

    def on_generation_finished(self, positions, elements, result):
        """Handle generation completion"""
        self.current_positions = positions
        self.current_elements = elements
        
        structure_type = self.structure_type_combo.currentText()
        if "Binary" in structure_type:
            a = self.binary_lattice_const.value()
            self.current_lattice_vectors = np.diag([a, a, a])
        elif "From POSCAR" in structure_type:
            pass  # Keep existing lattice vectors
        else:
            if hasattr(self, 'tio2_a'):
                a = self.tio2_a.value()
                if hasattr(self, 'tio2_c'):
                    c = self.tio2_c.value()
                    self.current_lattice_vectors = np.array([[a, 0, 0], [0, a, 0], [0, 0, c]])
        
        final_comp = Counter(elements)
        element_A = self.element_A_edit.text().strip()
        element_B = self.element_B_edit.text().strip()
        
        results_text = f"""
SQS Generation Results
======================

Structure Type: {structure_type}
Method: {result.method}
Objective value: {result.objective_value:.6f}
Iterations: {result.iterations}
Time: {result.time_seconds:.2f} seconds
Converged: {result.converged}

Composition:
  {element_A}: {final_comp.get(element_A, 0)}
  {element_B}: {final_comp.get(element_B, 0)}
"""
        if 'O' in final_comp:
            results_text += f"  O: {final_comp.get('O', 0)}\n"
        
        results_text += f"\nTotal atoms: {len(elements)}\n\nCorrelations (pair):\n"
        for shell, corr in result.correlations['pairs'].items():
            results_text += f"  Shell {shell}: {corr:.6f}\n"
        
        self.results_text.setText(results_text)
        
        self.export_poscar_btn.setEnabled(True)
        self.export_xyz_btn.setEnabled(True)
        self.export_cif_btn.setEnabled(True)
        
        self.generate_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.progress_bar.setVisible(False)
        self.status_label.setText("Generation complete!")
        
        QMessageBox.information(self, "Success", f"SQS generated successfully!\nTotal atoms: {len(elements)}\nObjective value: {result.objective_value:.6f}")

        # Create correct substitution info dictionary
        # Find indices where element_B appears
        substituted_indices = [i for i, elem in enumerate(elements) if elem == element_B]
        
        substitution_info = {
            'strategy': result.method,
            'source_element': element_A,  # This is the element symbol (e.g., 'Ti')
            'target_element': element_B,  # This is the element symbol (e.g., 'Sn')
            'selected_indices': substituted_indices,  # List of indices where substitution happened
            'description': f"SQS generation: {element_B} substitutes {element_A} at {self.composition_spin.value()*100:.1f}%"
        }
        
        try:
            if positions is not None and len(positions) > 0:
                if elements is not None and len(elements) == len(positions):
                    # Pass the substitution_info directly
                    self.xyz_widget.update_with_positions(positions, elements, substitution_info)
                    print(f"[SQS] Updated 3D view with {len(positions)} atoms")
                    print(f"[SQS] Substitution info: {substitution_info}")
                else:
                    print(f"[SQS] Error: elements length ({len(elements) if elements else 0}) != positions length ({len(positions)})")
        except Exception as e:
            print(f"[SQS] Error updating 3D view: {e}")
            import traceback
            traceback.print_exc()
        
        try:
            self.tab_widget.setCurrentIndex(1)
            print(f"[SQS] Switched to visualization tab")
        except Exception as e:
            print(f"[SQS] Error switching tab: {e}")
        
        try:
            info = {
                'mode': 'sqs',
                'description': 'SQS generation complete',
                'n_atoms': len(elements),
                'objective_value': result.objective_value,
                'method': result.method,
                'source_element': element_A,
                'target_element': element_B,
                'selected_indices': substituted_indices
            }
            self.substitution_performed.emit(positions, elements, info)
            print(f"[SQS] Emitted substitution_performed signal")
        except Exception as e:
            print(f"[SQS] Error emitting signal: {e}")

    def on_generation_error(self, error: str):
        self.generate_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.progress_bar.setVisible(False)
        self.status_label.setText("Error")
        QMessageBox.critical(self, "Error", f"Generation failed:\n{error}")
    
    def cancel_generation(self):
        if self.worker:
            self.worker.cancel()
            self.worker.wait()
        self.generate_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.progress_bar.setVisible(False)
        self.status_label.setText("Cancelled")
    
    def export_file(self, format_type: str):
        """Export structure to file"""
        if self.current_positions is None:
            QMessageBox.warning(self, "Warning", "No structure to export")
            return
        
        default_name = f"SQS_{self.element_A_edit.text()}{self.element_B_edit.text()}"
        
        if format_type == "poscar":
            filename, _ = QFileDialog.getSaveFileName(
                self, "Save POSCAR", default_name,
                "POSCAR Files (POSCAR*);;VASP Files (*.vasp);;All Files (*)"
            )
            if filename:
                StructureWriter.write_poscar(
                    self.current_lattice_vectors, self.current_positions, self.current_elements,
                    filename, comment="SQS generated structure"
                )
                QMessageBox.information(self, "Success", f"Saved to {filename}")
        
        elif format_type == "xyz":
            filename, _ = QFileDialog.getSaveFileName(
                self, "Save XYZ", f"{default_name}.xyz",
                "XYZ Files (*.xyz);;All Files (*)"
            )
            if filename:
                StructureWriter.write_xyz(
                    self.current_positions, self.current_elements, filename,
                    comment="SQS generated structure"
                )
                QMessageBox.information(self, "Success", f"Saved to {filename}")
        
        elif format_type == "cif":
            filename, _ = QFileDialog.getSaveFileName(
                self, "Save CIF", f"{default_name}.cif",
                "CIF Files (*.cif);;All Files (*)"
            )
            if filename:
                StructureWriter.write_cif(
                    self.current_positions, self.current_elements, filename,
                    comment="SQS generated structure"
                )
                QMessageBox.information(self, "Success", f"Saved to {filename}")
    
    def create_results_panel(self) -> QWidget:
        """Create results display panel"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        
        # Create tab widget for different views
        self.tab_widget = QTabWidget()
        
        # Tab 1: Results
        results_tab = QWidget()
        results_layout = QVBoxLayout(results_tab)
        results_layout.setContentsMargins(0, 0, 0, 0)
        
        # Add scroll area for text editor
        results_scroll = QScrollArea()
        results_scroll.setWidgetResizable(True)
        results_scroll.setFrameShape(QFrame.NoFrame)
        
        self.results_text = QTextEdit()
        self.results_text.setFont(QFont("Courier New", 10))
        self.results_text.setLineWrapMode(QTextEdit.NoWrap)
        results_scroll.setWidget(self.results_text)
        
        results_layout.addWidget(results_scroll)
        self.tab_widget.addTab(results_tab, "SQS Results")
        
        # Tab 2: XYZ Visualization
        viz_tab = QWidget()
        viz_layout = QVBoxLayout(viz_tab)
        viz_layout.setContentsMargins(0, 0, 0, 0)
        viz_layout.addWidget(self.xyz_widget)
        self.tab_widget.addTab(viz_tab, "3D Visualization")

        layout.addWidget(self.tab_widget)
        
        return panel
    
    def closeEvent(self, event):
        if self.worker and self.worker.isRunning():
            self.worker.cancel()
            self.worker.wait()
        event.accept()

    def init_backend_selector(self):
        """Initialize backend selector in control panel"""
        backend_group = QGroupBox("Compute Backend")
        backend_layout = QVBoxLayout()
        backend_layout.setSpacing(3)
        
        self.backend_combo = QComboBox()
        self.backend_combo.addItem("Python (default)", "python")

        if HAS_ICET:
            self.backend_combo.addItem("ICET", "icet")
        
        if LUA_AVAILABLE:
            self.backend_combo.addItem("LuaJIT (fast)", "luajit")
        
        if LUAFFI_AVAILABLE:
            self.backend_combo.addItem("LuaJIT FFI (faster)", "luajitffi")
        
        if FORTRAN_AVAILABLE:
            self.backend_combo.addItem("Fortran (fastest)", "fortran")
        
        backend_layout.addWidget(self.backend_combo)
        
        # Backend info label
        self.backend_info = QLabel("")
        self.backend_info.setStyleSheet("color: #666; font-size: 9px; padding: 2px;")
        self.backend_info.setWordWrap(True)
        backend_layout.addWidget(self.backend_info)
        
        self.backend_combo.currentIndexChanged.connect(self.update_backend_info)
        self.update_backend_info()
        
        backend_group.setLayout(backend_layout)
        return backend_group

    def update_backend_info(self):
        """Update backend info display"""
        backend = self.backend_combo.currentData()
        if backend == "python":
            self.backend_info.setText("Pure Python implementation\n"
                                    "  Compatible, no additional libraries")
        elif backend == "luajit":
            self.backend_info.setText("LuaJIT accelerated\n"
                                    "  5-10x faster than Python\n"
                                    "  Requires LuaJIT bridge")
        elif backend == "luajitffi":
            self.backend_info.setText("LuaJIT FFI accelerated\n"
                                    "  10-15x faster than Python\n"
                                    "  Requires LuaJIT bridge")
        elif backend == "fortran":
            self.backend_info.setText("Fortran native\n"
                                    "  20-50x faster than Python\n"
                                    "  OpenMP parallel support")
        elif backend == "icet":
            self.backend_info.setText("ICET\n"
                                    "  Do whatever to match replacement target exactly\n"
                                    "  Built-in cluster space handling")
    
    def load_poscar(self):
        """Load a POSCAR file"""
        filepath, _ = QFileDialog.getOpenFileName(
            self, "Open POSCAR File", "",
            "POSCAR Files (POSCAR*);;All Files (*.*)"
        )
        
        if not filepath:
            return
        
        try:
            struct = POSCARParser.parse(filepath)
            if struct:
                self.current_structure = struct
                self.current_filepath = filepath
                
                # Update XYZ widget
                self.send_to_visualizer()
                
                self.status_label.setText(f"Loaded: {filepath}")
                QMessageBox.information(self, "Success", 
                    f"Loaded POSCAR with {sum(struct.atom_counts)} atoms\n"
                    f"Elements: {', '.join(struct.elements)}\n"
                    f"Counts: {struct.atom_counts}")
            else:
                QMessageBox.critical(self, "Error", "Failed to parse POSCAR file")
                
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load file: {str(e)}")
            logging.error(f"Load error: {e}")
    
    def send_to_visualizer(self):
        """Send current structure to XYZ visualizer"""
        if not self.current_structure:
            return
        
        # Get positions and elements
        positions = POSCARParser.get_coordinate_matrix(self.current_structure)
        
        # Build element list per atom
        elements = []
        for elem, count in zip(self.current_structure.elements, self.current_structure.atom_counts):
            elements.extend([elem] * count)
        
        # Emit signal with positions and elements
        self.substitution_performed.emit(
            positions, 
            elements,
            self.last_substitution_info or {'mode': 'display', 'description': 'Structure loaded'}
        )
        
        self.status_label.setText("Sent to 3D visualizer")

    def _get_default_filename(self, extension: str) -> str:
        """Get default filename based on current file"""
        if self.current_filepath and isinstance(self.current_filepath, (str, Path)) and self.current_filepath != False:
            original_path = Path(self.current_filepath)
            return str(original_path.with_suffix(f".{extension}"))
        return f"structure_substituted.{extension}"

    def on_substitution_finished(self, result: POSCARStructure, history: List[Dict]):
        """Handle substitution completion"""
        print(f"[DEBUG] on_substitution_finished called")
        print(f"[DEBUG] result type: {type(result)}")
        print(f"[DEBUG] history: {history}")
        
        self.current_structure = result
        
        # Store last substitution info
        if history and len(history) > 0:
            self.last_substitution_info = history[-1]
            print(f"[DEBUG] last_substitution_info: {self.last_substitution_info}")
        else:
            print(f"[DEBUG] No history, using default")
            self.last_substitution_info = {'mode': 'substitution', 'description': 'Substitution applied'}
        
        # Enable export buttons
        self.export_xyz_btn.setEnabled(True)
        self.export_cif_btn.setEnabled(True)
        
        self.progress_bar.setVisible(False)
        self.status_label.setText("Substitution complete")
        
        # Send to visualizer
        self.send_to_visualizer()
        
        # Show summary with substitution info
        total_atoms = sum(result.atom_counts)
        element_dist = POSCARParser.get_element_distribution(result)
        summary = "Substitution applied successfully!\n\n"
        
        if history and len(history) > 0:
            last = history[-1]
            summary += f"Rule: {last.get('source_element', '?')} → {last.get('target_element', '?')}\n"
            summary += f"Strategy: {last.get('strategy', '?')}\n"
            summary += f"Atoms substituted: {len(last.get('selected_indices', []))}\n"
            summary += f"Description: {last.get('description', '')}\n\n"
        
        summary += "New composition:\n"
        for elem, count in element_dist.items():
            summary += f"  {elem}: {count} ({count/total_atoms*100:.1f}%)\n"
        
        QMessageBox.information(self, "Success", summary)

    def refresh_3d_view(self):
        """Force refresh the 3D visualization"""
        if hasattr(self, 'current_positions') and hasattr(self, 'current_elements'):
            if self.current_positions is not None and self.current_elements is not None:
                self.xyz_widget.update_with_positions(self.current_positions, self.current_elements, self.xyz_results)
                self.tab_widget.setCurrentIndex(1)

    def setup_connections(self):
        """Setup all signal connections"""
        # Connect substitution signal to XYZ widget
        self.substitution_performed.connect(self.xyz_widget.update_with_positions)
        
        # Also connect tab change to refresh visualization
        self.tab_widget.currentChanged.connect(self.on_tab_changed)

    def on_tab_changed(self, index):
        """Handle tab change to refresh visualization when needed"""
        if index == 1:  # Visualization tab
            if hasattr(self, 'current_positions') and self.current_positions is not None:
                self.xyz_widget.update_with_positions(self.current_positions, self.current_elements, self.xyz_results)