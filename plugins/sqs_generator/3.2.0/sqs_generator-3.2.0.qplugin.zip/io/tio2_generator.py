#!/usr/bin/env python3
"""
Author: Acxel Orozco
Date: [10/2025]
Create TiO2 supercell for LAMMPS with customizable dimensions and vacuum
Supports: Anatase, Rutile, and Brookite phases - Quantum Analysis Helper (QAH)

QAH is a python software for plot and analyze Quantum Espresso DOS, 
PDOS and Bands structures with a friendly GUI and extensive plugins.

This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

QAH is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

import numpy as np
import argparse
import logging


class TiO2Generator:

    def create_brookite_supercell(nx=4, ny=4, nz=1, vacuum_x=0.0, vacuum_y=0.0, vacuum_z=0.0, 
                                output_prefix="TiO2_brookite", create_xyz=True):
        """
        Create brookite TiO2 supercell with optional vacuum
        
        Parameters:
        -----------
        nx, ny, nz : int
            Supercell dimensions (number of unit cells in each direction)
        vacuum_x, vacuum_y, vacuum_z : float
            Vacuum thickness in Angstroms in each direction
        output_prefix : str
            Prefix for output files
        create_xyz : bool
            Whether to create XYZ file in addition to LAMMPS data file
        """
        
        # Brookite TiO2 primitive cell parameters (experimental values)
        # Orthorhombic crystal system
        a = 9.184  # Angstrom
        b = 5.447  # Angstrom  
        c = 5.145  # Angstrom
        
        # Brookite basis vectors (fractional coordinates) - 8 TiO2 units per cell (24 atoms)
        # Space group: Pbca
        # These are approximate positions - brookite has complex atomic arrangement
        basis = np.array([
            # Ti atoms (8 per unit cell)
            [0.00000, 0.00000, 0.00000],    # Ti1
            [0.50000, 0.00000, 0.50000],    # Ti2
            [0.00000, 0.50000, 0.50000],    # Ti3
            [0.50000, 0.50000, 0.00000],    # Ti4
            [0.25000, 0.25000, 0.25000],    # Ti5
            [0.75000, 0.25000, 0.75000],    # Ti6
            [0.25000, 0.75000, 0.75000],    # Ti7
            [0.75000, 0.75000, 0.25000],    # Ti8
            
            # O atoms (16 per unit cell)
            [0.10000, 0.10000, 0.10000],    # O1
            [0.60000, 0.10000, 0.60000],    # O2
            [0.10000, 0.60000, 0.60000],    # O3
            [0.60000, 0.60000, 0.10000],    # O4
            [0.35000, 0.35000, 0.35000],    # O5
            [0.85000, 0.35000, 0.85000],    # O6
            [0.35000, 0.85000, 0.85000],    # O7
            [0.85000, 0.85000, 0.35000],    # O8
            [0.20000, 0.05000, 0.45000],    # O9
            [0.70000, 0.05000, 0.95000],    # O10
            [0.20000, 0.55000, 0.95000],    # O11
            [0.70000, 0.55000, 0.45000],    # O12
            [0.45000, 0.20000, 0.05000],    # O13
            [0.95000, 0.20000, 0.55000],    # O14
            [0.45000, 0.70000, 0.55000],    # O15
            [0.95000, 0.70000, 0.05000]     # O16
        ])
        
        # Element labels for each atom in basis (8 Ti + 16 O = 24 atoms per unit cell)
        elements = (['Ti'] * 8) + (['O'] * 16)
        
        natoms_unit = 24  # 8 Ti + 16 O in unit cell
        natoms = natoms_unit * nx * ny * nz
        
        # Calculate box dimensions with vacuum (brookite has a ≠ b ≠ c)
        lx = a * nx + vacuum_x
        ly = b * ny + vacuum_y  
        lz = c * nz + vacuum_z
        
        # Generate atom positions
        positions = []
        atom_types = []
        atom_elements_list = []
        
        for i in range(nx):
            for j in range(ny):
                for k in range(nz):
                    for atom_idx in range(natoms_unit):
                        # Fractional coordinates in supercell
                        x_frac = (basis[atom_idx, 0] + i) / nx
                        y_frac = (basis[atom_idx, 1] + j) / ny  
                        z_frac = (basis[atom_idx, 2] + k) / nz
                        
                        # Convert to Cartesian coordinates
                        x = x_frac * a * nx + vacuum_x / 2
                        y = y_frac * b * ny + vacuum_y / 2
                        z = z_frac * c * nz + vacuum_z / 2
                        
                        positions.append([x, y, z])
                        
                        # Set atom type (Ti=1, O=2)
                        if elements[atom_idx] == 'Ti':
                            atom_types.append(1)
                        else:
                            atom_types.append(2)
                        
                        atom_elements_list.append(elements[atom_idx])
        
        # Write LAMMPS data file
        data_filename = f"{output_prefix}_{nx}x{ny}x{nz}"
        if vacuum_x > 0 or vacuum_y > 0 or vacuum_z > 0:
            data_filename += f"_vacuum_{vacuum_x:.1f}x{vacuum_y:.1f}x{vacuum_z:.1f}"
        data_filename += ".data"
        
        with open(data_filename, 'w') as f:
            f.write(f"LAMMPS data file for {nx}x{ny}x{nz} Brookite TiO2")
            if vacuum_x > 0 or vacuum_y > 0 or vacuum_z > 0:
                f.write(f" with vacuum {vacuum_x:.1f}x{vacuum_y:.1f}x{vacuum_z:.1f} A")
            f.write("\n\n")
            
            f.write(f"{natoms} atoms\n")
            f.write("2 atom types\n\n")
            f.write(f"0.0 {lx:.6f} xlo xhi\n")
            f.write(f"0.0 {ly:.6f} ylo yhi\n") 
            f.write(f"0.0 {lz:.6f} zlo zhi\n\n")
            f.write("Masses\n\n")
            f.write("1 47.867\n")  # Ti
            f.write("2 15.999\n")  # O
            f.write("\nAtoms\n\n")
            
            for i in range(natoms):
                f.write(f"{i+1} {atom_types[i]} {positions[i][0]:.6f} {positions[i][1]:.6f} {positions[i][2]:.6f}\n")
        
        logging.info(f"Created {data_filename} with {natoms} atoms")
        logging.info(f"Box dimensions: {lx:.3f} x {ly:.3f} x {lz:.3f} Angstrom")
        ti_count = atom_elements_list.count('Ti')
        o_count = atom_elements_list.count('O')
        logging.info(f"Composition: {ti_count} Ti, {o_count} O atoms (TiO₂ ratio: {ti_count/o_count:.2f})")
        
        # Create XYZ file if requested
        if create_xyz:
            xyz_filename = data_filename.replace('.data', '.xyz')
            
            with open(xyz_filename, 'w') as f:
                f.write(f"{natoms}\n")
                f.write(f"Brookite TiO2 {nx}x{ny}x{nz} supercell")
                if vacuum_x > 0 or vacuum_y > 0 or vacuum_z > 0:
                    f.write(f" with vacuum {vacuum_x:.1f}x{vacuum_y:.1f}x{vacuum_z:.1f} A")
                f.write(f", a={a:.3f} A, b={b:.3f} A, c={c:.3f} A\n")
                
                for i in range(natoms):
                    f.write(f"{atom_elements_list[i]} {positions[i][0]:.6f} {positions[i][1]:.6f} {positions[i][2]:.6f}\n")
            
            logging.info(f"Created {xyz_filename}")

    def create_anatase_supercell(nx=4, ny=4, nz=1, vacuum_x=0.0, vacuum_y=0.0, vacuum_z=0.0, 
                                output_prefix="TiO2_anatase", create_xyz=True):
        """
        Create anatase TiO2 supercell with optional vacuum
        """
        
        # Anatase TiO2 primitive cell parameters
        a = 3.784  # Angstrom
        c = 9.515  # Angstrom
        
        # Anatase basis vectors (fractional coordinates)
        basis = np.array([
            [0.000000, 0.000000, 0.000000],    # Ti1
            [0.500000, 0.500000, 0.500000],    # Ti2
            [0.000000, 0.500000, 0.250000],    # Ti3
            [0.500000, 0.000000, 0.750000],    # Ti4
            [0.000000, 0.000000, 0.208100],    # O1
            [0.500000, 0.500000, 0.708100],    # O2
            [0.000000, 0.500000, 0.458100],    # O3
            [0.500000, 0.000000, 0.958100],    # O4
            [0.275000, 0.275000, 0.000000],    # O5
            [0.775000, 0.775000, 0.500000],    # O6
            [0.275000, 0.775000, 0.250000],    # O7
            [0.775000, 0.275000, 0.750000]     # O8
        ])
        
        # Element labels for each atom in basis
        elements = ['Ti', 'Ti', 'Ti', 'Ti', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O']
        
        natoms_unit = 12  # 4 Ti + 8 O in unit cell
        natoms = natoms_unit * nx * ny * nz
        
        # Calculate box dimensions with vacuum
        lx = a * nx + vacuum_x
        ly = a * ny + vacuum_y  
        lz = c * nz + vacuum_z
        
        # Generate atom positions
        positions = []
        atom_types = []
        atom_elements_list = []
        
        for i in range(nx):
            for j in range(ny):
                for k in range(nz):
                    for atom_idx in range(natoms_unit):
                        # Fractional coordinates in supercell
                        x_frac = (basis[atom_idx, 0] + i) / nx
                        y_frac = (basis[atom_idx, 1] + j) / ny  
                        z_frac = (basis[atom_idx, 2] + k) / nz
                        
                        # Convert to Cartesian coordinates
                        x = x_frac * a * nx + vacuum_x / 2
                        y = y_frac * a * ny + vacuum_y / 2
                        z = z_frac * c * nz + vacuum_z / 2
                        
                        positions.append([x, y, z])
                        
                        # Set atom type (Ti=1, O=2)
                        if elements[atom_idx] == 'Ti':
                            atom_types.append(1)
                        else:
                            atom_types.append(2)
                        
                        atom_elements_list.append(elements[atom_idx])
        
        # Write LAMMPS data file
        data_filename = f"{output_prefix}_{nx}x{ny}x{nz}"
        if vacuum_x > 0 or vacuum_y > 0 or vacuum_z > 0:
            data_filename += f"_vacuum_{vacuum_x:.1f}x{vacuum_y:.1f}x{vacuum_z:.1f}"
        data_filename += ".data"
        
        with open(data_filename, 'w') as f:
            f.write(f"LAMMPS data file for {nx}x{ny}x{nz} Anatase TiO2")
            if vacuum_x > 0 or vacuum_y > 0 or vacuum_z > 0:
                f.write(f" with vacuum {vacuum_x:.1f}x{vacuum_y:.1f}x{vacuum_z:.1f} A")
            f.write("\n\n")
            
            f.write(f"{natoms} atoms\n")
            f.write("2 atom types\n\n")
            f.write(f"0.0 {lx:.6f} xlo xhi\n")
            f.write(f"0.0 {ly:.6f} ylo yhi\n") 
            f.write(f"0.0 {lz:.6f} zlo zhi\n\n")
            f.write("Masses\n\n")
            f.write("1 47.867\n")  # Ti
            f.write("2 15.999\n")  # O
            f.write("\nAtoms\n\n")
            
            for i in range(natoms):
                f.write(f"{i+1} {atom_types[i]} {positions[i][0]:.6f} {positions[i][1]:.6f} {positions[i][2]:.6f}\n")
        
        logging.info(f"Created {data_filename} with {natoms} atoms")
        logging.info(f"Box dimensions: {lx:.3f} x {ly:.3f} x {lz:.3f} Angstrom")
        ti_count = atom_elements_list.count('Ti')
        o_count = atom_elements_list.count('O')
        logging.info(f"Composition: {ti_count} Ti, {o_count} O atoms (TiO₂ ratio: {ti_count/o_count:.2f})")
        
        # Create XYZ file if requested
        if create_xyz:
            xyz_filename = data_filename.replace('.data', '.xyz')
            
            with open(xyz_filename, 'w') as f:
                f.write(f"{natoms}\n")
                f.write(f"Anatase TiO2 {nx}x{ny}x{nz} supercell")
                if vacuum_x > 0 or vacuum_y > 0 or vacuum_z > 0:
                    f.write(f" with vacuum {vacuum_x:.1f}x{vacuum_y:.1f}x{vacuum_z:.1f} A")
                f.write(f", a={a:.3f} A, c={c:.3f} A\n")
                
                for i in range(natoms):
                    f.write(f"{atom_elements_list[i]} {positions[i][0]:.6f} {positions[i][1]:.6f} {positions[i][2]:.6f}\n")
            
            logging.info(f"Created {xyz_filename}")

    def create_rutile_supercell(nx=4, ny=4, nz=1, vacuum_x=0.0, vacuum_y=0.0, vacuum_z=0.0, 
                            output_prefix="TiO2_rutile", create_xyz=True):
        """
        Create rutile TiO2 supercell with optional vacuum
        """
        
        # Rutile TiO2 primitive cell parameters
        a = 4.594  # Angstrom
        c = 2.959  # Angstrom
        
        # Rutile basis vectors (fractional coordinates)
        basis = np.array([
            [0.0, 0.0, 0.0],      # Ti1
            [0.5, 0.5, 0.5],      # Ti2  
            [0.3, 0.3, 0.0],      # O1
            [0.7, 0.7, 0.0],      # O2
            [0.2, 0.8, 0.5],      # O3
            [0.8, 0.2, 0.5]       # O4
        ])
        
        # Element labels for each atom in basis
        elements = ['Ti', 'Ti', 'O', 'O', 'O', 'O']
        
        natoms_unit = 6  # 2 Ti + 4 O in unit cell
        natoms = natoms_unit * nx * ny * nz
        
        # Calculate box dimensions with vacuum
        lx = a * nx + vacuum_x
        ly = a * ny + vacuum_y  
        lz = c * nz + vacuum_z
        
        # Generate atom positions
        positions = []
        atom_types = []
        atom_elements_list = []
        
        for i in range(nx):
            for j in range(ny):
                for k in range(nz):
                    for atom_idx in range(natoms_unit):
                        # Fractional coordinates in supercell
                        x_frac = (basis[atom_idx, 0] + i) / nx
                        y_frac = (basis[atom_idx, 1] + j) / ny  
                        z_frac = (basis[atom_idx, 2] + k) / nz
                        
                        # Convert to Cartesian coordinates
                        x = x_frac * a * nx + vacuum_x / 2
                        y = y_frac * a * ny + vacuum_y / 2
                        z = z_frac * c * nz + vacuum_z / 2
                        
                        positions.append([x, y, z])
                        
                        # Set atom type (Ti=1, O=2)
                        if atom_idx < 2:
                            atom_types.append(1)
                        else:
                            atom_types.append(2)
                        
                        atom_elements_list.append(elements[atom_idx])
        
        # Write LAMMPS data file
        data_filename = f"{output_prefix}_{nx}x{ny}x{nz}"
        if vacuum_x > 0 or vacuum_y > 0 or vacuum_z > 0:
            data_filename += f"_vacuum_{vacuum_x:.1f}x{vacuum_y:.1f}x{vacuum_z:.1f}"
        data_filename += ".data"
        
        with open(data_filename, 'w') as f:
            f.write(f"LAMMPS data file for {nx}x{ny}x{nz} Rutile TiO2")
            if vacuum_x > 0 or vacuum_y > 0 or vacuum_z > 0:
                f.write(f" with vacuum {vacuum_x:.1f}x{vacuum_y:.1f}x{vacuum_z:.1f} A")
            f.write("\n\n")
            
            f.write(f"{natoms} atoms\n")
            f.write("2 atom types\n\n")
            f.write(f"0.0 {lx:.6f} xlo xhi\n")
            f.write(f"0.0 {ly:.6f} ylo yhi\n") 
            f.write(f"0.0 {lz:.6f} zlo zhi\n\n")
            f.write("Masses\n\n")
            f.write("1 47.867\n")  # Ti
            f.write("2 15.999\n")  # O
            f.write("\nAtoms\n\n")
            
            for i in range(natoms):
                f.write(f"{i+1} {atom_types[i]} {positions[i][0]:.6f} {positions[i][1]:.6f} {positions[i][2]:.6f}\n")
        
        logging.info(f"Created {data_filename} with {natoms} atoms")
        logging.info(f"Box dimensions: {lx:.3f} x {ly:.3f} x {lz:.3f} Angstrom")
        logging.info(f"Composition: {atom_elements_list.count('Ti')} Ti, {atom_elements_list.count('O')} O atoms")
        
        # Create XYZ file if requested
        if create_xyz:
            xyz_filename = data_filename.replace('.data', '.xyz')
            
            with open(xyz_filename, 'w') as f:
                f.write(f"{natoms}\n")
                f.write(f"Rutile TiO2 {nx}x{ny}x{nz} supercell")
                if vacuum_x > 0 or vacuum_y > 0 or vacuum_z > 0:
                    f.write(f" with vacuum {vacuum_x:.1f}x{vacuum_y:.1f}x{vacuum_z:.1f} A")
                f.write(f", a={a:.3f} A, c={c:.3f} A\n")
                
                for i in range(natoms):
                    f.write(f"{atom_elements_list[i]} {positions[i][0]:.6f} {positions[i][1]:.6f} {positions[i][2]:.6f}\n")
            
            logging.info(f"Created {xyz_filename}")

def main():
    parser = argparse.ArgumentParser(description='Create TiO2 supercell for LAMMPS')
    parser.add_argument('--phase', choices=['anatase', 'rutile', 'brookite'], default='anatase',
                       help='Crystal phase (default: anatase)')
    parser.add_argument('-x', '--nx', type=int, default=4, 
                       help='Number of unit cells in x direction (default: 4)')
    parser.add_argument('-y', '--ny', type=int, default=4, 
                       help='Number of unit cells in y direction (default: 4)')
    parser.add_argument('-z', '--nz', type=int, default=1, 
                       help='Number of unit cells in z direction (default: 1)')
    parser.add_argument('--vacuum_x', type=float, default=0.0,
                       help='Vacuum thickness in x direction (Angstroms, default: 0.0)')
    parser.add_argument('--vacuum_y', type=float, default=0.0,
                       help='Vacuum thickness in y direction (Angstroms, default: 0.0)')
    parser.add_argument('--vacuum_z', type=float, default=0.0,
                       help='Vacuum thickness in z direction (Angstroms, default: 0.0)')
    parser.add_argument('--output', type=str, default=None,
                       help='Output file prefix (default: auto-generated)')
    parser.add_argument('--no_xyz', action='store_true',
                       help='Skip creating XYZ file')
    
    args = parser.parse_args()

    tio2 = TiO2Generator()
    
    if args.output is None:
        output_prefix = f"TiO2_{args.phase}"
    else:
        output_prefix = args.output
    
    if args.phase == 'anatase':
        tio2.create_anatase_supercell(
            nx=args.nx,
            ny=args.ny, 
            nz=args.nz,
            vacuum_x=args.vacuum_x,
            vacuum_y=args.vacuum_y,
            vacuum_z=args.vacuum_z,
            output_prefix=output_prefix,
            create_xyz=not args.no_xyz
        )
    elif args.phase == 'rutile':
        tio2.create_rutile_supercell(
            nx=args.nx,
            ny=args.ny, 
            nz=args.nz,
            vacuum_x=args.vacuum_x,
            vacuum_y=args.vacuum_y,
            vacuum_z=args.vacuum_z,
            output_prefix=output_prefix,
            create_xyz=not args.no_xyz
        )
    else:  # brookite
        tio2.create_brookite_supercell(
            nx=args.nx,
            ny=args.ny, 
            nz=args.nz,
            vacuum_x=args.vacuum_x,
            vacuum_y=args.vacuum_y,
            vacuum_z=args.vacuum_z,
            output_prefix=output_prefix,
            create_xyz=not args.no_xyz
        )

def create_example_structures():
    """Create some common example structures for all phases"""
    
    logging.info("Creating example structures for all TiO2 phases...\n")
    tio2 = TiO2Generator()
    
    # Anatase examples
    logging.info("=== ANATASE STRUCTURES ===")
    tio2.create_anatase_supercell(nx=2, ny=2, nz=1, output_prefix="TiO2_anatase_bulk_2x2x1")
    tio2.create_anatase_supercell(nx=3, ny=3, nz=2, vacuum_z=20.0, output_prefix="TiO2_anatase_slab_3x3x2")
    
    # Rutile examples
    logging.info("\n=== RUTILE STRUCTURES ===")
    tio2.create_rutile_supercell(nx=2, ny=2, nz=2, output_prefix="TiO2_rutile_bulk_2x2x2")
    tio2.create_rutile_supercell(nx=4, ny=4, nz=3, vacuum_z=20.0, output_prefix="TiO2_rutile_slab_4x4x3")
    
    # Brookite examples
    logging.info("\n=== BROOKITE STRUCTURES ===")
    tio2.create_brookite_supercell(nx=1, ny=2, nz=2, output_prefix="TiO2_brookite_bulk_1x2x2")
    tio2.create_brookite_supercell(nx=2, ny=2, nz=1, vacuum_z=15.0, output_prefix="TiO2_brookite_slab_2x2x1")

def print_phase_info():
    """Print information about different TiO2 phases"""
    logging.info("\nTiO2 Crystal Phases Information:")
    logging.info("=" * 40)
    logging.info("ANATASE:")
    logging.info("  - Crystal system: Tetragonal")
    logging.info("  - Space group: I4₁/amd")
    logging.info("  - Lattice: a = 3.784 Å, c = 9.515 Å")
    logging.info("  - Unit cell: 4 TiO₂ (12 atoms)")
    logging.info("  - Applications: Photocatalysis, solar cells")
    logging.info()
    logging.info("RUTILE:")
    logging.info("  - Crystal system: Tetragonal") 
    logging.info("  - Space group: P4₂/mnm")
    logging.info("  - Lattice: a = 4.594 Å, c = 2.959 Å")
    logging.info("  - Unit cell: 2 TiO₂ (6 atoms)")
    logging.info("  - Applications: Pigments, ceramics")
    logging.info()
    logging.info("BROOKITE:")
    logging.info("  - Crystal system: Orthorhombic")
    logging.info("  - Space group: Pbca")
    logging.info("  - Lattice: a = 9.184 Å, b = 5.447 Å, c = 5.145 Å")
    logging.info("  - Unit cell: 8 TiO₂ (24 atoms)")
    logging.info("  - Applications: Rare phase, specialized catalysis")
    logging.info()

if __name__ == "__main__":
    # If run without arguments, show help and create examples
    import sys
    if len(sys.argv) == 1:
        logging.info("TiO2 Supercell Generator - Anatase, Rutile & Brookite Phases")
        logging.info("=" * 60)
        print_phase_info()
        logging.info("\nUsage examples:")
        logging.info("  python script.py --phase brookite -x 2 -y 2 -z 1")
        logging.info("  python script.py --phase anatase -x 3 -y 3 -z 2 --vacuum_z 20.0")
        logging.info("  python script.py --phase rutile -x 4 -y 4 -z 3")
        logging.info("  python script.py --help")
        logging.info("\nCreating example structures...\n")
        create_example_structures()
    else:
        main()