from pathlib import Path, PurePosixPath
from typing import List, Dict
from datetime import datetime

class TempFileManager:
    """Simple temporary file manager for SQS GENERATOT plugin"""
    
    def __init__(self):
        self.temp_dir = Path.home() / "QAH" / "plugin_files" / "SQS_GENERATOR"
        self.temp_dir.mkdir(parents=True, exist_ok=True)
        self.temp_files: Dict[str, Dict] = {}
    
    def create_temp_file(self, remote_path: str, content: bytes) -> Path:
        """Create a temporary file with content"""
        filename = PurePosixPath(remote_path).name
        # Add timestamp to avoid collisions
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        temp_filename = f"{PurePosixPath(filename).stem}_{timestamp}{PurePosixPath(filename).suffix}"
        temp_path = self.temp_dir / temp_filename
        
        temp_path.write_bytes(content)
        
        self.temp_files[temp_path.as_posix()] = {
            'remote_path': remote_path,
            'filename': filename,
            'created': datetime.now()
        }
        
        return temp_path
    
    def get_temp_files(self) -> List[Dict]:
        """Get list of temporary files"""
        return list(self.temp_files.values())
    
    def cleanup_old_files(self, max_hours: int = 24):
        """Clean up files older than max_hours"""
        cutoff = datetime.now().timestamp() - (max_hours * 3600)
        
        for temp_file in self.temp_dir.iterdir():
            if temp_file.is_file() and temp_file.stat().st_mtime < cutoff:
                temp_file.unlink()
                temp_file_str = temp_file.as_posix()
                if temp_file_str in self.temp_files:
                    del self.temp_files[temp_file_str]