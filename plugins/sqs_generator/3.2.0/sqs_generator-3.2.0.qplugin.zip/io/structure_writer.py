"""
Write SQS structures to various formats
"""

import numpy as np
from typing import List, Tuple


class StructureWriter:
    """Write structures to POSCAR, XYZ, and CIF formats"""
    
    @staticmethod
    def write_poscar(
        lattice_vectors: np.ndarray,
        positions: np.ndarray,
        elements: List[str],
        filename: str,
        selective: bool = False,
        comment: str = "SQS structure"
    ) -> str:
        """Write POSCAR file"""
        with open(filename, 'w') as f:
            f.write(f"{comment}\n")
            f.write("1.0\n")
            
            # Lattice vectors
            for i in range(3):
                f.write(f" {lattice_vectors[i,0]:.12f} {lattice_vectors[i,1]:.12f} {lattice_vectors[i,2]:.12f}\n")
            
            # Elements and counts
            unique_elements = []
            counts = []
            for elem in elements:
                if elem not in unique_elements:
                    unique_elements.append(elem)
                    counts.append(1)
                else:
                    counts[unique_elements.index(elem)] += 1
            
            f.write(" ".join(unique_elements) + "\n")
            f.write(" ".join(str(c) for c in counts) + "\n")
            
            if selective:
                f.write("Selective dynamics\n")
            
            f.write("Direct\n")
            
            # Positions (convert to fractional if needed)
            # Assuming positions are in Cartesian, need to convert to fractional
            inv_lattice = np.linalg.inv(lattice_vectors)
            for pos in positions:
                frac = np.dot(pos, inv_lattice)
                f.write(f" {frac[0]:.12f} {frac[1]:.12f} {frac[2]:.12f}\n")
        
        return filename
    
    @staticmethod
    def write_xyz(
        positions: np.ndarray,
        elements: List[str],
        filename: str,
        comment: str = "SQS structure"
    ) -> str:
        """Write XYZ file"""
        with open(filename, 'w') as f:
            f.write(f"{len(positions)}\n")
            f.write(f"{comment}\n")
            for elem, pos in zip(elements, positions):
                f.write(f"{elem} {pos[0]:.12f} {pos[1]:.12f} {pos[2]:.12f}\n")
        
        return filename
    
    @staticmethod
    def write_cif(
        positions: np.ndarray,
        elements: List[str],
        filename: str,
        comment: str = "SQS structure"
    ) -> str:
        """Write CIF file"""
        # Calculate bounding box
        min_coords = np.min(positions, axis=0)
        max_coords = np.max(positions, axis=0)
        
        a = max_coords[0] - min_coords[0]
        b = max_coords[1] - min_coords[1]
        c = max_coords[2] - min_coords[2]
        
        # Add padding
        padding = 2.0
        a += padding
        b += padding
        c += padding
        
        # Shift to origin
        shifted = positions - min_coords + padding/2
        
        with open(filename, 'w') as f:
            f.write(f"data_{filename.replace('.cif', '').replace('/', '_')}\n")
            f.write("_audit_creation_method 'SQS Generator'\n")
            f.write(f"_cell_length_a {a:.6f}\n")
            f.write(f"_cell_length_b {b:.6f}\n")
            f.write(f"_cell_length_c {c:.6f}\n")
            f.write("_cell_angle_alpha 90.0000\n")
            f.write("_cell_angle_beta 90.0000\n")
            f.write("_cell_angle_gamma 90.0000\n")
            f.write("\nloop_\n")
            f.write("_atom_site_label\n")
            f.write("_atom_site_type_symbol\n")
            f.write("_atom_site_fract_x\n")
            f.write("_atom_site_fract_y\n")
            f.write("_atom_site_fract_z\n")
            f.write("_atom_site_occupancy\n")
            
            for i, (elem, pos) in enumerate(zip(elements, shifted), 1):
                label = f"{elem}{i}"
                fract_x = pos[0] / a if a > 0 else 0.0
                fract_y = pos[1] / b if b > 0 else 0.0
                fract_z = pos[2] / c if c > 0 else 0.0
                f.write(f"  {label:<6} {elem:<2} {fract_x:.6f} {fract_y:.6f} {fract_z:.6f} 1.0000\n")
        
        return filename