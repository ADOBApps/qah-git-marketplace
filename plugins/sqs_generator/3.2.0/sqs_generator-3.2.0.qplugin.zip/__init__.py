"""
SQS Generator - Special Quasirandom Structures for binary alloys
Based on: Zunger et al. PRL 65, 353 (1990) and van de Walle et al. CALPHAD 42, 13 (2013)
"""

from pathlib import Path
from typing import Optional
import logging

from PySide6.QtWidgets import QWidget
from PySide6.QtCore import QObject

from plugins.libs.plugin_manager import PluginInfo


class SQSGeneratorPlugin(QObject):
    """Plugin wrapper for SQS Generator"""

    def __init__(self, plugin_info: PluginInfo):
        super().__init__()
        self.plugin_info = plugin_info
        self.ui_widget = None


    def initialize(self) -> bool:
        """Initialize plugin"""
        try:
            logging.info(f"Initializing {self.plugin_info.name} v{self.plugin_info.version}")
            return True
        except Exception as e:
            logging.error(f"Failed to initialize: {e}")
            return False

    def get_widget(self) -> Optional[QWidget]:
        """Get main widget"""
        if self.ui_widget is None:
            try:
                from .plugin_ui import SQSGeneratorWidget
                self.ui_widget = SQSGeneratorWidget(self)
            except Exception as e:
                logging.error(f"Failed to create widget: {e}")
                return None
        return self.ui_widget

    def cleanup(self):
        """Cleanup resources"""
        if self.ui_widget:
            self.ui_widget.deleteLater()
            self.ui_widget = None


Plugin = SQSGeneratorPlugin