#!/usr/bin/env python3
"""
Author: Acxel Orozco
Date: 23/10/25
Description: TiO2 Supercell Generator Widget
Features:
- User-selectable output directory
- Tabbed interface for crystal phase selection
- Customizable supercell dimensions
- Vacuum addition in any direction
- Real-time preview of structure parameters
- Multiple output formats (LAMMPS data + XYZ)

This file is part of Quantum Analysis Helper.
Quantum Analysis Helper is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Quantum Analysis Helper is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

import os
import sys
import numpy as np
from pathlib import Path

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QLineEdit, QPushButton, QComboBox, QDoubleSpinBox, QSpinBox,
    QTabWidget, QFileDialog, QMessageBox, QGroupBox, QSizePolicy,
    QCheckBox, QTextEdit, QScrollArea, QApplication, QMainWindow
)
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QFont, QPalette, QColor

from ..io.tio2_generator import (
    create_anatase_supercell,
    create_rutile_supercell,
    create_brookite_supercell
)


class StructureGeneratorThread(QThread):
    """Thread for generating structures to prevent UI freezing"""
    finished = Signal(str, str)  # success_message, error_message
    progress = Signal(str)
    
    def __init__(self, phase, nx, ny, nz, vacuum_x, vacuum_y, vacuum_z, output_dir, output_prefix):
        super().__init__()
        self.phase = phase
        self.nx = nx
        self.ny = ny
        self.nz = nz
        self.vacuum_x = vacuum_x
        self.vacuum_y = vacuum_y
        self.vacuum_z = vacuum_z
        self.output_dir = output_dir
        self.output_prefix = output_prefix
    
    def run(self):
        try:
            # from tio2_generator import create_anatase_supercell, create_rutile_supercell, create_brookite_supercell
            
            self.progress.emit(f"Generating {self.phase} supercell...")
            
            # Ensure output directory exists
            os.makedirs(self.output_dir, exist_ok=True)
            
            if self.phase == 'anatase':
                create_anatase_supercell(
                    nx=self.nx, ny=self.ny, nz=self.nz,
                    vacuum_x=self.vacuum_x, vacuum_y=self.vacuum_y, vacuum_z=self.vacuum_z,
                    output_prefix=os.path.join(self.output_dir, self.output_prefix),
                    create_xyz=True
                )
            elif self.phase == 'rutile':
                create_rutile_supercell(
                    nx=self.nx, ny=self.ny, nz=self.nz,
                    vacuum_x=self.vacuum_x, vacuum_y=self.vacuum_y, vacuum_z=self.vacuum_z,
                    output_prefix=os.path.join(self.output_dir, self.output_prefix),
                    create_xyz=True
                )
            else:  # brookite
                create_brookite_supercell(
                    nx=self.nx, ny=self.ny, nz=self.nz,
                    vacuum_x=self.vacuum_x, vacuum_y=self.vacuum_y, vacuum_z=self.vacuum_z,
                    output_prefix=os.path.join(self.output_dir, self.output_prefix),
                    create_xyz=True
                )
            
            self.progress.emit("Structure generation completed!")
            self.finished.emit(f"Successfully generated {self.phase} supercell", "")
            
        except Exception as e:
            self.finished.emit("", f"Error generating structure: {str(e)}")


class TiO2GeneratorWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # Initialize components
        self._setup_variables()
        self._create_widgets()
        self._setup_layout()
        self._connect_signals()
        
        # Update preview
        self._update_preview()

    def _setup_variables(self):
        """Initialize all variables"""
        # Structure parameters
        self.phase = "anatase"
        self.nx = 4
        self.ny = 4
        self.nz = 1
        
        # Vacuum parameters
        self.vacuum_x = 0.0
        self.vacuum_y = 0.0
        self.vacuum_z = 0.0
        self.add_vacuum = False
        
        # Output parameters - let user choose directory
        self.output_dir = ""  # Will be set by user
        self.output_prefix = "TiO2"
        
        # Crystal phase information
        self.phase_info = {
            "anatase": {
                "crystal_system": "Tetragonal",
                "space_group": "I4₁/amd",
                "lattice_a": 3.784,
                "lattice_c": 9.515,
                "atoms_per_cell": 12,
                "formula": "4 TiO₂"
            },
            "rutile": {
                "crystal_system": "Tetragonal",
                "space_group": "P4₂/mnm",
                "lattice_a": 4.594,
                "lattice_c": 2.959,
                "atoms_per_cell": 6,
                "formula": "2 TiO₂"
            },
            "brookite": {
                "crystal_system": "Orthorhombic",
                "space_group": "Pbca",
                "lattice_a": 9.184,
                "lattice_b": 5.447,
                "lattice_c": 5.145,
                "atoms_per_cell": 24,
                "formula": "8 TiO₂"
            }
        }

    def _create_widgets(self):
        """Create all widget components"""
        # Font configuration
        self.myfont = QFont("Times", 11)
        self.title_font = QFont("Times", 12, QFont.Bold)
        
        # Create tab widget
        self.tab_widget = QTabWidget()
        
        # Structure tab
        self.structure_tab = QWidget()
        self._create_structure_tab()
        
        # Vacuum tab
        self.vacuum_tab = QWidget()
        self._create_vacuum_tab()
        
        # Output tab - NOW MORE PROMINENT
        self.output_tab = QWidget()
        self._create_output_tab()
        
        # Preview tab
        self.preview_tab = QWidget()
        self._create_preview_tab()
        
        # Add tabs to tab widget
        self.tab_widget.addTab(self.output_tab, "Output Location")  # Make output first tab
        self.tab_widget.addTab(self.structure_tab, "Structure")
        self.tab_widget.addTab(self.vacuum_tab, "Vacuum")
        self.tab_widget.addTab(self.preview_tab, "Preview")
        
        # Action buttons
        self._create_action_buttons()
        
        # Status display
        self.status_label = QLabel("Please select an output directory to begin")
        self.status_label.setStyleSheet("QLabel { color: blue; font-weight: bold; }")

    def _create_structure_tab(self):
        """Create widgets for structure tab"""
        layout = QVBoxLayout(self.structure_tab)
        
        # Phase selection
        phase_group = QGroupBox("Crystal Phase")
        phase_layout = QVBoxLayout(phase_group)
        
        self.phase_combo = QComboBox()
        self.phase_combo.addItems(["anatase", "rutile", "brookite"])
        self.phase_combo.setFont(self.myfont)
        phase_layout.addWidget(self.phase_combo)
        
        # Phase info display
        self.phase_info_label = QLabel()
        self.phase_info_label.setFont(self.myfont)
        self.phase_info_label.setWordWrap(True)
        phase_layout.addWidget(self.phase_info_label)
        
        layout.addWidget(phase_group)
        
        # Supercell dimensions
        dim_group = QGroupBox("Supercell Dimensions")
        dim_layout = QGridLayout(dim_group)
        
        dim_layout.addWidget(QLabel("X:"), 0, 0)
        self.nx_spinbox = QSpinBox()
        self.nx_spinbox.setRange(1, 100)
        self.nx_spinbox.setValue(self.nx)
        self.nx_spinbox.setFont(self.myfont)
        dim_layout.addWidget(self.nx_spinbox, 0, 1)
        
        dim_layout.addWidget(QLabel("Y:"), 1, 0)
        self.ny_spinbox = QSpinBox()
        self.ny_spinbox.setRange(1, 100)
        self.ny_spinbox.setValue(self.ny)
        self.ny_spinbox.setFont(self.myfont)
        dim_layout.addWidget(self.ny_spinbox, 1, 1)
        
        dim_layout.addWidget(QLabel("Z:"), 2, 0)
        self.nz_spinbox = QSpinBox()
        self.nz_spinbox.setRange(1, 100)
        self.nz_spinbox.setValue(self.nz)
        self.nz_spinbox.setFont(self.myfont)
        dim_layout.addWidget(self.nz_spinbox, 2, 1)
        
        layout.addWidget(dim_group)
        layout.addStretch()

    def _create_vacuum_tab(self):
        """Create widgets for vacuum tab"""
        layout = QVBoxLayout(self.vacuum_tab)
        
        # Vacuum enable checkbox
        self.vacuum_checkbox = QCheckBox("Add Vacuum Regions")
        self.vacuum_checkbox.setFont(self.title_font)
        layout.addWidget(self.vacuum_checkbox)
        
        # Vacuum parameters
        vacuum_group = QGroupBox("Vacuum Thickness (Å)")
        vacuum_layout = QGridLayout(vacuum_group)
        
        vacuum_layout.addWidget(QLabel("X-direction:"), 0, 0)
        self.vacuum_x_spinbox = QDoubleSpinBox()
        self.vacuum_x_spinbox.setRange(0.0, 100.0)
        self.vacuum_x_spinbox.setValue(self.vacuum_x)
        self.vacuum_x_spinbox.setSuffix(" Å")
        self.vacuum_x_spinbox.setFont(self.myfont)
        self.vacuum_x_spinbox.setEnabled(False)
        vacuum_layout.addWidget(self.vacuum_x_spinbox, 0, 1)
        
        vacuum_layout.addWidget(QLabel("Y-direction:"), 1, 0)
        self.vacuum_y_spinbox = QDoubleSpinBox()
        self.vacuum_y_spinbox.setRange(0.0, 100.0)
        self.vacuum_y_spinbox.setValue(self.vacuum_y)
        self.vacuum_y_spinbox.setSuffix(" Å")
        self.vacuum_y_spinbox.setFont(self.myfont)
        self.vacuum_y_spinbox.setEnabled(False)
        vacuum_layout.addWidget(self.vacuum_y_spinbox, 1, 1)
        
        vacuum_layout.addWidget(QLabel("Z-direction:"), 2, 0)
        self.vacuum_z_spinbox = QDoubleSpinBox()
        self.vacuum_z_spinbox.setRange(0.0, 100.0)
        self.vacuum_z_spinbox.setValue(self.vacuum_z)
        self.vacuum_z_spinbox.setSuffix(" Å")
        self.vacuum_z_spinbox.setFont(self.myfont)
        self.vacuum_z_spinbox.setEnabled(False)
        vacuum_layout.addWidget(self.vacuum_z_spinbox, 2, 1)
        
        layout.addWidget(vacuum_group)
        
        # Vacuum usage examples
        examples_group = QGroupBox("Common Vacuum Configurations")
        examples_layout = QVBoxLayout(examples_group)
        
        examples_text = QLabel(
            "• Surface slab: Add vacuum in Z-direction (10-100 Å)\n"
            "• Nanowire: Add vacuum in X and Y directions\n"
            "• Nanoparticle: Add vacuum in all directions\n"
            "• 2D material: Add vacuum in Z-direction"
        )
        examples_text.setFont(self.myfont)
        examples_layout.addWidget(examples_text)
        
        layout.addWidget(examples_group)
        layout.addStretch()

    def _create_output_tab(self):
        """Create widgets for output tab - NOW MORE PROMINENT"""
        layout = QVBoxLayout(self.output_tab)
        
        # Output directory selection (MORE VISIBLE)
        dir_group = QGroupBox("Output Location")
        dir_group.setFont(self.title_font)
        dir_layout = QVBoxLayout(dir_group)
        
        dir_help = QLabel("Select where to save the generated structure files:")
        dir_help.setFont(self.myfont)
        dir_layout.addWidget(dir_help)
        
        # Directory selection with button
        dir_selection_layout = QHBoxLayout()
        
        self.dir_entry = QLineEdit()
        self.dir_entry.setFont(self.myfont)
        self.dir_entry.setPlaceholderText("Click 'Browse' to select output directory...")
        dir_selection_layout.addWidget(self.dir_entry)
        
        self.browse_dir_button = QPushButton("Browse...")
        self.browse_dir_button.setFont(self.myfont)
        self.browse_dir_button.setStyleSheet("QPushButton { background-color: #2196F3; color: white; }")
        dir_selection_layout.addWidget(self.browse_dir_button)
        
        dir_layout.addLayout(dir_selection_layout)
        
        # Current directory info
        self.current_dir_label = QLabel("No directory selected")
        self.current_dir_label.setFont(QFont("Times", 10))
        self.current_dir_label.setStyleSheet("QLabel { color: #666; font-style: italic; }")
        dir_layout.addWidget(self.current_dir_label)
        
        layout.addWidget(dir_group)
        
        # Output filename
        file_group = QGroupBox("Output Filename")
        file_layout = QVBoxLayout(file_group)
        
        file_help = QLabel("Base name for output files (files will be automatically named):")
        file_help.setFont(self.myfont)
        file_layout.addWidget(file_help)
        
        self.prefix_entry = QLineEdit(self.output_prefix)
        self.prefix_entry.setFont(self.myfont)
        self.prefix_entry.setPlaceholderText("e.g., TiO2, MyStructure, Anatase_Slab")
        file_layout.addWidget(self.prefix_entry)
        
        filename_example = QLabel("Example: TiO2_4x4x1_vacuum_10.0x0.0x0.0.data")
        filename_example.setFont(QFont("Times", 9))
        filename_example.setStyleSheet("QLabel { color: #888; }")
        file_layout.addWidget(filename_example)
        
        layout.addWidget(file_group)
        
        # Output formats
        format_group = QGroupBox("Output Formats")
        format_layout = QVBoxLayout(format_group)
        
        self.format_lammps_check = QCheckBox("LAMMPS Data File (.data) - for simulations")
        self.format_lammps_check.setChecked(True)
        self.format_lammps_check.setFont(self.myfont)
        format_layout.addWidget(self.format_lammps_check)
        
        self.format_xyz_check = QCheckBox("XYZ File (.xyz) - for visualization")
        self.format_xyz_check.setChecked(True)
        self.format_xyz_check.setFont(self.myfont)
        format_layout.addWidget(self.format_xyz_check)
        
        layout.addWidget(format_group)
        layout.addStretch()

    def _create_preview_tab(self):
        """Create widgets for preview tab"""
        layout = QVBoxLayout(self.preview_tab)
        
        # Preview text area
        preview_label = QLabel("Structure Preview:")
        preview_label.setFont(self.title_font)
        layout.addWidget(preview_label)
        
        preview_help = QLabel("This preview updates automatically as you change parameters:")
        preview_help.setFont(self.myfont)
        layout.addWidget(preview_help)
        
        self.preview_text = QTextEdit()
        self.preview_text.setFont(QFont("Courier", 10))
        self.preview_text.setReadOnly(True)
        
        # Set a nice style for the preview
        palette = self.preview_text.palette()
        palette.setColor(QPalette.Base, QColor(240, 240, 240))
        self.preview_text.setPalette(palette)
        
        layout.addWidget(self.preview_text)

    def _create_action_buttons(self):
        """Create action buttons"""
        self.action_layout = QHBoxLayout()
        
        self.generate_button = QPushButton("Generate Structure")
        self.generate_button.setFont(self.title_font)
        self.generate_button.setStyleSheet("QPushButton { background-color: #4CAF50; color: white; }")
        self.generate_button.setEnabled(False)  # Disabled until directory is selected
        self.action_layout.addWidget(self.generate_button)
        
        self.clear_button = QPushButton("Clear All")
        self.clear_button.setFont(self.myfont)
        self.action_layout.addWidget(self.clear_button)
        
        self.close_button = QPushButton("Close")
        self.close_button.setFont(self.myfont)
        self.action_layout.addWidget(self.close_button)

    def _setup_layout(self):
        """Arrange widgets in the frame"""
        main_layout = QVBoxLayout(self)
        main_layout.addWidget(self.tab_widget)
        main_layout.addWidget(self.status_label)
        main_layout.addLayout(self.action_layout)

    def _connect_signals(self):
        """Connect signals to slots"""
        # Structure signals
        self.phase_combo.currentTextChanged.connect(self._update_phase)
        self.nx_spinbox.valueChanged.connect(self._update_nx)
        self.ny_spinbox.valueChanged.connect(self._update_ny)
        self.nz_spinbox.valueChanged.connect(self._update_nz)
        
        # Vacuum signals
        self.vacuum_checkbox.toggled.connect(self._update_vacuum_enabled)
        self.vacuum_x_spinbox.valueChanged.connect(self._update_vacuum_x)
        self.vacuum_y_spinbox.valueChanged.connect(self._update_vacuum_y)
        self.vacuum_z_spinbox.valueChanged.connect(self._update_vacuum_z)
        
        # Output signals
        self.browse_dir_button.clicked.connect(self._browse_directory)
        self.prefix_entry.textChanged.connect(self._update_output_prefix)
        self.dir_entry.textChanged.connect(self._update_output_dir)
        
        # Action signals
        self.generate_button.clicked.connect(self._generate_structure)
        self.clear_button.clicked.connect(self._clear_inputs)
        self.close_button.clicked.connect(self.hide)

    def _update_phase(self, phase):
        self.phase = phase
        self._update_phase_info()
        self._update_preview()

    def _update_nx(self, value):
        self.nx = value
        self._update_preview()

    def _update_ny(self, value):
        self.ny = value
        self._update_preview()

    def _update_nz(self, value):
        self.nz = value
        self._update_preview()

    def _update_vacuum_enabled(self, enabled):
        self.add_vacuum = enabled
        self.vacuum_x_spinbox.setEnabled(enabled)
        self.vacuum_y_spinbox.setEnabled(enabled)
        self.vacuum_z_spinbox.setEnabled(enabled)
        self._update_preview()

    def _update_vacuum_x(self, value):
        self.vacuum_x = value
        self._update_preview()

    def _update_vacuum_y(self, value):
        self.vacuum_y = value
        self._update_preview()

    def _update_vacuum_z(self, value):
        self.vacuum_z = value
        self._update_preview()

    def _update_output_prefix(self, text):
        self.output_prefix = text.strip() or "TiO2"
        self._update_preview()

    def _update_output_dir(self, text):
        self.output_dir = text
        self._update_directory_status()

    def _update_directory_status(self):
        """Update directory status and enable/disable generate button"""
        if self.output_dir and os.path.exists(self.output_dir):
            self.current_dir_label.setText(f"[Ok] Directory ready: {self.output_dir}")
            self.current_dir_label.setStyleSheet("QLabel { color: green; font-style: normal; }")
            self.generate_button.setEnabled(True)
            self.status_label.setText("Ready to generate structure")
            self.status_label.setStyleSheet("QLabel { color: blue; font-weight: bold; }")
        else:
            self.current_dir_label.setText("✗ Please select a valid directory")
            self.current_dir_label.setStyleSheet("QLabel { color: red; font-style: normal; }")
            self.generate_button.setEnabled(False)
            self.status_label.setText("Please select a valid output directory")
            self.status_label.setStyleSheet("QLabel { color: orange; font-weight: bold; }")

    def _update_phase_info(self):
        """Update phase information display"""
        info = self.phase_info[self.phase]
        if self.phase == "brookite":
            text = (f"Crystal System: {info['crystal_system']}\n"
                   f"Space Group: {info['space_group']}\n"
                   f"Lattice: a={info['lattice_a']} Å, b={info['lattice_b']} Å, c={info['lattice_c']} Å\n"
                   f"Unit Cell: {info['formula']} ({info['atoms_per_cell']} atoms)")
        else:
            text = (f"Crystal System: {info['crystal_system']}\n"
                   f"Space Group: {info['space_group']}\n"
                   f"Lattice: a={info['lattice_a']} Å, c={info['lattice_c']} Å\n"
                   f"Unit Cell: {info['formula']} ({info['atoms_per_cell']} atoms)")
        
        self.phase_info_label.setText(text)

    def _update_preview(self):
        """Update the structure preview"""
        if not self.output_dir:
            self.preview_text.setText("Please select an output directory to see structure preview")
            return
            
        info = self.phase_info[self.phase]
        atoms_per_cell = info['atoms_per_cell']
        total_atoms = atoms_per_cell * self.nx * self.ny * self.nz
        
        # Calculate box dimensions
        if self.phase == "brookite":
            lx = info['lattice_a'] * self.nx + (self.vacuum_x if self.add_vacuum else 0)
            ly = info['lattice_b'] * self.ny + (self.vacuum_y if self.add_vacuum else 0)
            lz = info['lattice_c'] * self.nz + (self.vacuum_z if self.add_vacuum else 0)
        else:
            lx = info['lattice_a'] * self.nx + (self.vacuum_x if self.add_vacuum else 0)
            ly = info['lattice_a'] * self.ny + (self.vacuum_y if self.add_vacuum else 0)
            lz = info['lattice_c'] * self.nz + (self.vacuum_z if self.add_vacuum else 0)
        
        preview_text = f"""
STRUCTURE PREVIEW
=================

Phase: {self.phase.title()}
Supercell: {self.nx} × {self.ny} × {self.nz}
Total atoms: {total_atoms}

Box Dimensions:
  X: {lx:.2f} Å
  Y: {ly:.2f} Å  
  Z: {lz:.2f} Å

Vacuum: {'Yes' if self.add_vacuum else 'No'}
"""
        if self.add_vacuum:
            preview_text += f"""
Vacuum Thickness:
  X: {self.vacuum_x} Å
  Y: {self.vacuum_y} Å
  Z: {self.vacuum_z} Å
"""

        preview_text += f"""
Output Files:
  {self.output_prefix}_{self.nx}x{self.ny}x{self.nz}
  {'_vacuum_' + f'{self.vacuum_x:.1f}x{self.vacuum_y:.1f}x{self.vacuum_z:.1f}' if self.add_vacuum else ''}
  .data & .xyz
  
Output Location:
  {self.output_dir}
"""

        self.preview_text.setText(preview_text)

    def _browse_directory(self):
        """Browse for output directory"""
        dir_path = QFileDialog.getExistingDirectory(
            self,
            "Select Output Directory",
            os.path.expanduser("~")  # Start from home directory
        )
        if dir_path:
            self.output_dir = dir_path
            self.dir_entry.setText(dir_path)
            self._update_directory_status()
            self._update_preview()

    def _validate_inputs(self):
        """Validate all required inputs"""
        if not self.output_dir:
            QMessageBox.warning(self, "Output Directory Required", 
                               "Please select an output directory where the structure files will be saved.")
            self.tab_widget.setCurrentIndex(0)  # Switch to output tab
            return False
        
        if not os.path.exists(self.output_dir):
            QMessageBox.warning(self, "Invalid Directory", 
                               "The selected output directory does not exist. Please select a valid directory.")
            self.tab_widget.setCurrentIndex(0)  # Switch to output tab
            return False
        
        if not self.output_prefix.strip():
            QMessageBox.warning(self, "Filename Required", 
                               "Please enter a valid filename prefix for the output files.")
            self.tab_widget.setCurrentIndex(0)  # Switch to output tab
            return False
        
        return True

    def _generate_structure(self):
        """Generate the TiO2 structure"""
        if not self._validate_inputs():
            return
        
        # Disable generate button during generation
        self.generate_button.setEnabled(False)
        self.status_label.setText("Generating structure...")
        
        # Create and start generation thread
        self.generator_thread = StructureGeneratorThread(
            phase=self.phase,
            nx=self.nx,
            ny=self.ny,
            nz=self.nz,
            vacuum_x=self.vacuum_x if self.add_vacuum else 0.0,
            vacuum_y=self.vacuum_y if self.add_vacuum else 0.0,
            vacuum_z=self.vacuum_z if self.add_vacuum else 0.0,
            output_dir=self.output_dir,
            output_prefix=self.output_prefix
        )
        
        self.generator_thread.progress.connect(self.status_label.setText)
        self.generator_thread.finished.connect(self._on_generation_finished)
        self.generator_thread.start()

    def _on_generation_finished(self, success_message, error_message):
        """Handle generation completion"""
        self.generate_button.setEnabled(True)
        
        if error_message:
            QMessageBox.critical(self, "Generation Error", error_message)
            self.status_label.setText("Generation failed")
            self.status_label.setStyleSheet("QLabel { color: red; font-weight: bold; }")
        else:
            QMessageBox.information(self, "Success", success_message)
            self.status_label.setText("Generation completed successfully!")
            self.status_label.setStyleSheet("QLabel { color: green; font-weight: bold; }")
            
            # Show output directory
            reply = QMessageBox.question(
                self,
                "Open Output Directory",
                "Would you like to open the output directory to view the generated files?",
                QMessageBox.Yes | QMessageBox.No
            )
            
            if reply == QMessageBox.Yes:
                import subprocess
                try:
                    if os.name == 'nt':  # Windows
                        os.startfile(self.output_dir)
                    elif os.name == 'posix':  # Linux, macOS
                        subprocess.run(['xdg-open', self.output_dir])
                except Exception as e:
                    QMessageBox.warning(self, "Error", f"Could not open directory: {str(e)}")

    def _clear_inputs(self):
        """Clear all inputs and reset to defaults"""
        self.phase_combo.setCurrentText("anatase")
        self.nx_spinbox.setValue(4)
        self.ny_spinbox.setValue(4)
        self.nz_spinbox.setValue(1)
        self.vacuum_checkbox.setChecked(False)
        self.vacuum_x_spinbox.setValue(0.0)
        self.vacuum_y_spinbox.setValue(0.0)
        self.vacuum_z_spinbox.setValue(0.0)
        self.prefix_entry.setText("TiO2")
        self.dir_entry.clear()
        self.output_dir = ""
        self._update_directory_status()
        self.status_label.setText("Please select an output directory to begin")
        self.status_label.setStyleSheet("QLabel { color: blue; font-weight: bold; }")


if __name__ == "__main__":
    # Example usage
    
    app = QApplication(sys.argv)
    window = QMainWindow()
    window.setWindowTitle("TiO2 Supercell Generator")
    window.resize(800, 600)
    
    central_widget = TiO2GeneratorWidget()
    window.setCentralWidget(central_widget)
    
    window.show()
    sys.exit(app.exec())