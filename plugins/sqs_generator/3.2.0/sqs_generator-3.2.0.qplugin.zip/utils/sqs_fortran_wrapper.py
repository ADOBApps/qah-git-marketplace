"""
sqs_fortran_wrapper.py - Fortran SQS engine wrapper with unified interface
"""

import ctypes
import numpy as np
from pathlib import Path
import platform
import random
import time
from typing import Optional, Tuple, List, Dict, Callable
import os
import multiprocessing
import logging
from dataclasses import dataclass

# Platform-specific library path
system = platform.system().lower()
if system == 'windows':
    LIB_EXT = '.dll'
    LIB_FOLDER = 'windows'
elif system == 'darwin':
    LIB_EXT = '.dylib'
    LIB_FOLDER = 'macos'
else:  # linux
    LIB_EXT = '.so'
    LIB_FOLDER = 'linux'

lib_path = Path(__file__).parent / "fortran" / LIB_FOLDER / f"libsqs_engine{LIB_EXT}"


@dataclass
class FortranSQSResult:
    """Result from Fortran SQS engine"""
    spins: List[int]
    objective_value: float
    iterations: int
    method: str
    time_seconds: float
    converged: bool


class FortranSQSEngine:
    """Unified Fortran SQS engine wrapper compatible with sqs_engine.py interface"""
    
    MAX_NEIGHBORS = 50
    MAX_SHELLS = 10
    
    def __init__(self, lattice_vectors: np.ndarray = None, positions: np.ndarray = None,
                 element_A: str = 'A', element_B: str = 'B',
                 composition: float = 0.5, neighbor_cutoff: float = 2.5,
                 seed: Optional[int] = None):
        """
        Initialize Fortran SQS engine (compatible with sqs_engine.SQSGenerator)
        
        Args:
            lattice_vectors: 3x3 lattice matrix (optional, for compatibility)
            positions: atomic positions (optional, for compatibility)
            element_A: first element symbol
            element_B: second element symbol
            composition: fraction of element_B
            neighbor_cutoff: distance cutoff for neighbor detection (Angstroms)
            seed: random seed for reproducibility
        """
        self.lattice_vectors = lattice_vectors
        self.positions = positions
        self.element_A = element_A
        self.element_B = element_B
        self.composition = composition
        self.neighbor_cutoff = neighbor_cutoff
        
        if seed is not None:
            random.seed(seed)
            np.random.seed(seed)
        
        # Set OpenMP environment variables
        n_cores = multiprocessing.cpu_count()
        os.environ['OMP_NUM_THREADS'] = str(n_cores)
        os.environ['OMP_DYNAMIC'] = 'false'
        os.environ['OMP_PROC_BIND'] = 'true'
        os.environ['OMP_PLACES'] = 'cores'
        
        print(f"[FortranSQS] OpenMP configured with {n_cores} threads")
        print(f"[FortranSQS] Neighbor cutoff: {neighbor_cutoff} Å")
        
        self.lib = None
        self._loaded = False
        self._load_library()
    
    def _load_library(self):
        """Load Fortran shared library"""
        if lib_path.exists():
            try:
                self.lib = ctypes.CDLL(str(lib_path))
                self._setup_functions()
                self._loaded = True
                print(f"[Ok] Loaded Fortran SQS engine: {lib_path}")
            except Exception as e:
                print(f"[Warning] Failed to load Fortran SQS engine: {e}")
        else:
            print(f"[Warning] Fortran library not found at {lib_path}")
    
    def _setup_functions(self):
        """Setup ctypes function signatures"""
        
        # random_search_fast - values passed directly, not by reference
        self.lib.random_search_fast.argtypes = [
            ctypes.c_int,                    # natoms (by value)
            ctypes.c_int,                    # n_B (by value)
            ctypes.c_int,                    # n_trials (by value)
            ctypes.c_double,                 # composition (by value)
            ctypes.POINTER(ctypes.c_int),    # best_spins (output)
            ctypes.POINTER(ctypes.c_double), # best_objective (output)
            ctypes.POINTER(ctypes.c_int),    # iterations (output)
        ]
        self.lib.random_search_fast.restype = None
        
        # random_search_parallel
        try:
            self.lib.random_search_parallel.argtypes = [
                ctypes.c_int,                 # natoms (by value)
                ctypes.c_int,                 # n_B (by value)
                ctypes.c_int,                 # n_trials (by value)
                ctypes.c_double,              # composition (by value)
                ctypes.POINTER(ctypes.c_int), # best_spins (output)
                ctypes.POINTER(ctypes.c_double), # best_objective (output)
                ctypes.POINTER(ctypes.c_int), # iterations (output)
            ]
            self.lib.random_search_parallel.restype = None
        except AttributeError:
            pass
        
        # simulated_annealing_fast
        self.lib.simulated_annealing_fast.argtypes = [
            ctypes.c_int,                    # natoms (by value)
            ctypes.c_int,                    # n_B (by value)
            ctypes.c_double,                 # T_start (by value)
            ctypes.c_double,                 # T_end (by value)
            ctypes.c_int,                    # steps_per_T (by value)
            ctypes.c_double,                 # cooling_rate (by value)
            ctypes.c_double,                 # composition (by value)
            ctypes.POINTER(ctypes.c_int),    # best_spins (output)
            ctypes.POINTER(ctypes.c_double), # best_objective (output)
            ctypes.POINTER(ctypes.c_int),    # iterations (output)
        ]
        self.lib.simulated_annealing_fast.restype = None
        
        # calculate_objective
        self.lib.calculate_objective.argtypes = [
            ctypes.c_int,                    # natoms (by value)
            ctypes.POINTER(ctypes.c_int),    # spins (input array)
            ctypes.c_double,                 # composition (by value)
            ctypes.POINTER(ctypes.c_double), # obj_value (output)
        ]
        self.lib.calculate_objective.restype = None
        
        # get_version
        try:
            self.lib.get_version.argtypes = [ctypes.c_char_p]
            self.lib.get_version.restype = None
        except AttributeError:
            pass
    
    def get_version(self) -> str:
        """Get Fortran library version"""
        if not self._loaded or not hasattr(self.lib, 'get_version'):
            return "Fortran engine not loaded"
        
        version_buf = ctypes.create_string_buffer(100)
        self.lib.get_version(version_buf)
        return version_buf.value.decode()
    
    def random_search(self, natoms: int, n_B: int = None, n_trials: int = 10000,
                    composition: float = None, use_parallel: bool = False,
                    early_stop: float = None, convergence_threshold: float = 0.15, callback: Optional[Callable] = None) -> FortranSQSResult:
        """
        Run random search optimization
        """
        start_time = time.time()
        
        comp = composition if composition is not None else self.composition
        n_B_val = n_B if n_B is not None else int(natoms * comp)
        
        print(f"[FortranSQS] random_search called with:")
        print(f"  natoms: {natoms}")
        print(f"  n_B_val: {n_B_val} (composition: {comp})")
        print(f"  n_trials: {n_trials}")
        
        if not self._loaded:
            raise RuntimeError("Fortran library not loaded")
        
        # Prepare output arrays
        best_spins = (ctypes.c_int * natoms)()
        best_objective = ctypes.c_double(0.0)
        iterations = ctypes.c_int(0)
        
        c_natoms = ctypes.c_int(natoms)
        c_n_B = ctypes.c_int(n_B_val)
        c_n_trials = ctypes.c_int(n_trials)
        c_composition = ctypes.c_double(comp)
        
        if use_parallel and early_stop is not None and hasattr(self.lib, 'random_search_parallel_early'):
            print("[FortranSQS] Using random_search_parallel_early")
            c_early_stop = ctypes.c_double(early_stop)
            self.lib.random_search_parallel_early(
                c_natoms, c_n_B, c_n_trials, c_composition,
                best_spins, ctypes.byref(best_objective), ctypes.byref(iterations), c_early_stop
            )
        elif use_parallel and hasattr(self.lib, 'random_search_parallel'):
            print("[FortranSQS] Using random_search_parallel")
            self.lib.random_search_parallel(
                c_natoms, c_n_B, c_n_trials, c_composition,
                best_spins, ctypes.byref(best_objective), ctypes.byref(iterations)
            )
        else:
            print("[FortranSQS] Using random_search_fast")
            self.lib.random_search_fast(
                c_natoms, c_n_B, c_n_trials, c_composition,
                best_spins, ctypes.byref(best_objective), ctypes.byref(iterations)
            )
        
        if callback:
            callback(n_trials, best_objective.value)
        
        spins_list = [best_spins[i] for i in range(natoms)]
        n_B_result = sum(1 for s in spins_list if s == 1)
        print(f"[FortranSQS] Result has {n_B_result} B atoms (expected {n_B_val})")
        print(f"[FortranSQS] Objective: {best_objective.value:.6f}")
        
        return FortranSQSResult(
            spins=spins_list,
            objective_value=best_objective.value,
            iterations=iterations.value,
            method='Random Search (Fortran)',
            time_seconds=time.time() - start_time,
            converged=best_objective.value < convergence_threshold
        )
    
    def simulated_annealing(self, natoms: int, n_B: int = None,
                        T_start: float = 1.0, T_end: float = 0.01,
                        steps_per_T: int = 1000, cooling_rate: float = 0.95,
                        composition: float = None, use_replica: bool = False,
                        n_replicas: int = 4, convergence_threshold: float = 0.15, callback: Optional[Callable] = None) -> FortranSQSResult:
        """
        Run simulated annealing optimization
        """
        start_time = time.time()
        
        comp = composition if composition is not None else self.composition
        n_B_val = n_B if n_B is not None else int(natoms * comp)
        
        print(f"[FortranSQS] simulated_annealing called with:")
        print(f"  natoms: {natoms}")
        print(f"  n_B_val: {n_B_val} (composition: {comp})")
        
        if not self._loaded:
            raise RuntimeError("Fortran library not loaded")
        
        # Prepare output arrays
        best_spins = (ctypes.c_int * natoms)()
        best_objective = ctypes.c_double(0.0)
        iterations = ctypes.c_int(0)
        
        c_natoms = ctypes.c_int(natoms)
        c_n_B = ctypes.c_int(n_B_val)
        c_T_start = ctypes.c_double(T_start)
        c_T_end = ctypes.c_double(T_end)
        c_steps_per_T = ctypes.c_int(steps_per_T)
        c_cooling_rate = ctypes.c_double(cooling_rate)
        c_composition = ctypes.c_double(comp)
        
        if use_replica and hasattr(self.lib, 'simulated_annealing_replica'):
            print("[FortranSQS] Using simulated_annealing_replica")
            c_n_replicas = ctypes.c_int(n_replicas)
            self.lib.simulated_annealing_replica(
                c_natoms, c_n_B, c_T_start, c_T_end, c_steps_per_T,
                c_cooling_rate, c_composition, best_spins,
                ctypes.byref(best_objective), ctypes.byref(iterations), c_n_replicas
            )
        else:
            print("[FortranSQS] Using simulated_annealing_fast")
            self.lib.simulated_annealing_fast(
                c_natoms, c_n_B, c_T_start, c_T_end, c_steps_per_T,
                c_cooling_rate, c_composition, best_spins,
                ctypes.byref(best_objective), ctypes.byref(iterations)
            )
        
        spins_list = [best_spins[i] for i in range(natoms)]
        n_B_result = sum(1 for s in spins_list if s == 1)
        print(f"[FortranSQS] Result has {n_B_result} B atoms (expected {n_B_val})")
        print(f"[FortranSQS] Objective: {best_objective.value:.6f}")
        
        return FortranSQSResult(
            spins=spins_list,
            objective_value=best_objective.value,
            iterations=iterations.value,
            method='Simulated Annealing (Fortran)',
            time_seconds=time.time() - start_time,
            converged=best_objective.value < convergence_threshold
        )
    
    def calculate_objective(self, spins: List[int], composition: float = None) -> float:
        """Calculate objective function for a spin configuration"""
        if not self._loaded:
            raise RuntimeError("Fortran library not loaded")
        
        natoms = len(spins)
        comp = composition if composition is not None else self.composition
        
        c_natoms = ctypes.c_int(natoms)
        c_spins = (ctypes.c_int * natoms)(*spins)
        c_composition = ctypes.c_double(comp)
        c_obj = ctypes.c_double(0.0)
        
        self.lib.calculate_objective(
            c_natoms,
            c_spins,
            c_composition,
            ctypes.byref(c_obj)
        )
        
        return c_obj.value
    
    def spins_to_elements(self, spins: List[int]) -> List[str]:
        return [self.element_B if s == 1 else self.element_A for s in spins]
    
    @property
    def is_available(self) -> bool:
        return self._loaded


# Global instance management
_fortran_engine = None


def get_fortran_engine(lattice_vectors: np.ndarray = None, positions: np.ndarray = None,
                       element_A: str = 'A', element_B: str = 'B',
                       composition: float = 0.5, neighbor_cutoff: float = 2.5,
                       seed: Optional[int] = None) -> Optional[FortranSQSEngine]:
    """Get or create Fortran SQS engine instance"""
    global _fortran_engine
    if _fortran_engine is None:
        _fortran_engine = FortranSQSEngine(lattice_vectors, positions, element_A, element_B, 
                                            composition, neighbor_cutoff, seed)
    return _fortran_engine if _fortran_engine.is_available else None