"""
ffi_sqs_wrapper.py - FFI-Enhanced LuaJIT SQS engine wrapper
Uses FFI arrays for maximum performance with LuaJIT
Based on the pattern from sqs_lua_wrapper.py
"""

import numpy as np
import random
import math
import time
from pathlib import Path
from typing import Optional, Tuple, List, Dict, Callable, Any
from dataclasses import dataclass

try:
    from plugins.libs.lua.luajit_bridge import get_luajit_bridge
    LUAJIT_AVAILABLE = True
except ImportError:
    LUAJIT_AVAILABLE = False
    print("[Warning] LuaJIT bridge not available")


@dataclass
class FFISQSResult:
    """Result from FFI-optimized Lua SQS engine"""
    spins: List[int]
    objective_value: float
    iterations: int
    method: str
    time_seconds: float
    converged: bool
    ffi_enabled: bool = False
    speedup_factor: float = 1.0


class FFISQSEngine:
    """
    FFI-Enhanced LuaJIT SQS engine wrapper
    Uses native C arrays via FFI for maximum performance
    """
    
    def __init__(self, lattice_vectors: np.ndarray = None, positions: np.ndarray = None,
                 element_A: str = 'A', element_B: str = 'B',
                 composition: float = 0.5, neighbor_cutoff: float = 2.5,
                 seed: Optional[int] = None, use_ffi: bool = True):
        """
        Initialize FFI-Enhanced Lua SQS engine
        
        Args:
            lattice_vectors: 3x3 lattice matrix
            positions: atomic positions in fractional coordinates
            element_A: first element symbol
            element_B: second element symbol
            composition: fraction of element_B
            neighbor_cutoff: distance cutoff for neighbor detection (Angstroms)
            seed: random seed for reproducibility
            use_ffi: whether to use FFI optimization
        """
        self.lattice_vectors = lattice_vectors
        self.positions = positions
        self.element_A = element_A
        self.element_B = element_B
        self.composition = composition
        self.neighbor_cutoff = neighbor_cutoff
        self.use_ffi = use_ffi
        
        if seed is not None:
            random.seed(seed)
            np.random.seed(seed)
            self.seed = seed
        else:
            self.seed = int(time.time() * 1000) % 2**31
        
        self.bridge = None
        self.lua_state = None
        self._initialized = False
        self._ffi_ready = False
        self._neighbors_cache = None
        
        # Performance tracking
        self._ffi_prep_time = 0.0
        self._lua_exec_time = 0.0
        
        # Find Lua scripts directory
        self.script_dir = Path(__file__).parent / "lua"
        
        self._load_lua_engine()
    
    def _load_lua_engine(self):
        """Load FFI-enhanced LuaJIT SQS engine"""
        if not LUAJIT_AVAILABLE:
            print("[FFI-SQS] LuaJIT bridge not available, FFI optimization disabled")
            self.use_ffi = False
            return
        
        try:
            print("[LuaJIT] Getting bridge...")
            self.bridge = get_luajit_bridge()
            if not self.bridge:
                print("[Error] Failed to get LuaJIT bridge")
                return
            
            print("[LuaJIT] Initializing Lua state...")
            self.lua_state = self.bridge.init()
            if not self.lua_state:
                print("[Error] Failed to initialize Lua state")
                return
            
            # Load the FFI-enhanced Lua script
            ffi_script_path = self.script_dir / "ffi_sqs_engine.lua"
            
            if not ffi_script_path.exists():
                print(f"[FFI-SQS] FFI script not found: {ffi_script_path}")
                print("[FFI-SQS] Falling back to standard Lua SQS engine")
                
                # Try to load standard script as fallback
                standard_script_path = self.script_dir / "lua_sqs_engine.lua"
                if standard_script_path.exists():
                    print(f"[LuaJIT] Loading standard script: {standard_script_path}")
                    with open(standard_script_path, 'r', encoding='utf-8') as f:
                        script_content = f.read()
                    self.use_ffi = False
                else:
                    print(f"[Error] No Lua SQS script found")
                    return
            else:
                print(f"[LuaJIT] Loading FFI script: {ffi_script_path}")
                with open(ffi_script_path, 'r', encoding='utf-8') as f:
                    script_content = f.read()
            
            # Execute the Lua script
            success = self.bridge.execute_script(self.lua_state, script_content)
            if not success:
                error = self.bridge.get_last_error(self.lua_state)
                print(f"[Error] Failed to load Lua script: {error}")
                return
            
            # Verify all functions are loaded
            print("[LuaJIT] Verifying functions...")
            
            # Check standard functions
            self.bridge.execute_script(self.lua_state, 
                "_test_random = (type(sqs_random_search) == 'function') and 1 or 0")
            test_random = self._get_global_int("_test_random")
            print(f"[LuaJIT] sqs_random_search loaded: {test_random == 1}")
            
            self.bridge.execute_script(self.lua_state, 
                "_test_sa = (type(sqs_simulated_annealing) == 'function') and 1 or 0")
            test_sa = self._get_global_int("_test_sa")
            print(f"[LuaJIT] sqs_simulated_annealing loaded: {test_sa == 1}")
            
            # Check FFI-specific functions
            if self.use_ffi:
                self.bridge.execute_script(self.lua_state, 
                    "_test_ffi_prep = (type(sqs_prepare_neighbors_ffi) == 'function') and 1 or 0")
                test_ffi_prep = self._get_global_int("_test_ffi_prep")
                print(f"[LuaJIT] sqs_prepare_neighbors_ffi loaded: {test_ffi_prep == 1}")
                
                self.bridge.execute_script(self.lua_state, 
                    "_test_ffi_table = (type(sqs_table_to_ffi_double) == 'function') and 1 or 0")
                test_ffi_table = self._get_global_int("_test_ffi_table")
                print(f"[LuaJIT] sqs_table_to_ffi_double loaded: {test_ffi_table == 1}")
                
                if test_random and test_sa and test_ffi_prep:
                    self._ffi_ready = True
                    print("[FFI-SQS] FFI functions verified successfully")
                else:
                    print("[FFI-SQS] Some FFI functions missing, disabling FFI")
                    self.use_ffi = False
            else:
                if test_random and test_sa:
                    self._initialized = True
                    print("[Ok] Standard LuaJIT SQS engine initialized")
            
            self._initialized = True
            
            # Setup neighbors if we have lattice data
            self._setup_neighbors_ffi()
            
        except Exception as e:
            print(f"[Error] LuaJIT SQS engine initialization failed: {e}")
            import traceback
            traceback.print_exc()
            self._initialized = False
            self.use_ffi = False
    
    def _setup_neighbors_ffi(self):
        """Setup neighbor lists and convert to FFI arrays"""
        if not self._initialized:
            return
        
        if self.positions is not None and self.lattice_vectors is not None:
            t0 = time.time()
            
            # Build neighbor list
            natoms = len(self.positions)
            self._neighbors_cache = [[] for _ in range(natoms)]
            
            # Convert to Cartesian coordinates
            positions_cart = np.dot(self.positions, self.lattice_vectors)
            
            # Use user-defined cutoff
            cutoff = self.neighbor_cutoff
            print(f"[FFI-SQS] Building neighbor lists with cutoff={cutoff} Å")
            
            # Build neighbor lists efficiently
            for i in range(natoms):
                pos_i = positions_cart[i]
                for j in range(i + 1, natoms):
                    dist = np.linalg.norm(pos_i - positions_cart[j])
                    if dist < cutoff:
                        self._neighbors_cache[i].append(j + 1)  # 1-based for Lua
                        self._neighbors_cache[j].append(i + 1)
            
            # Count total neighbor pairs
            total_pairs = sum(len(n) for n in self._neighbors_cache) // 2
            print(f"[FFI-SQS] Found {total_pairs} neighbor pairs")
            
            # Register both standard and FFI neighbor data
            self._register_standard_neighbors()
            
            if self.use_ffi and self._ffi_ready:
                self._register_ffi_neighbors(natoms)
            
            self._ffi_prep_time = time.time() - t0
            print(f"[FFI-SQS] Neighbor preparation took {self._ffi_prep_time*1000:.1f} ms")
    
    def _register_standard_neighbors(self):
        """Register standard Lua table neighbors (backward compatibility)"""
        if not self._initialized or not self.bridge or not self.lua_state:
            return
        
        natoms = len(self._neighbors_cache)
        
        # Build neighbor tables as Lua code
        lines = [
            "sqs_neighbors = {}",
            "sqs_n_neighbors = {}",
            ""
        ]
        
        for i in range(natoms):
            lua_idx = i + 1
            neighbors = self._neighbors_cache[i]
            if neighbors:
                neighbors_str = ','.join(str(n) for n in neighbors)
                lines.append(f"sqs_neighbors[{lua_idx}] = {{{neighbors_str}}}")
            else:
                lines.append(f"sqs_neighbors[{lua_idx}] = {{}}")
            lines.append(f"sqs_n_neighbors[{lua_idx}] = {len(neighbors)}")
        
        script = "\n".join(lines)
        self.bridge.execute_script(self.lua_state, script)
        print("[FFI-SQS] Standard neighbor tables registered")
    
    def _register_ffi_neighbors(self, natoms: int):
        """Register FFI-optimized neighbor arrays"""
        if not self._initialized or not self.bridge or not self.lua_state:
            return
        
        # Build FFI registration script
        # This calls sqs_prepare_neighbors_ffi in Lua with proper tables
        lines = [
            "-- Create neighbor tables for FFI conversion",
            "local neighbors_table = {}",
            "local n_neighbors_table = {}",
            ""
        ]
        
        for i in range(natoms):
            lua_idx = i + 1
            neighbors = self._neighbors_cache[i]
            if neighbors:
                neighbors_str = ','.join(str(n) for n in neighbors)
                lines.append(f"neighbors_table[{lua_idx}] = {{{neighbors_str}}}")
            else:
                lines.append(f"neighbors_table[{lua_idx}] = {{}}")
            lines.append(f"n_neighbors_table[{lua_idx}] = {len(neighbors)}")
        
        lines.append("")
        lines.append(f"-- Convert to FFI arrays")
        lines.append(f"local ncdata, nncdata = sqs_prepare_neighbors_ffi(neighbors_table, n_neighbors_table, {natoms})")
        lines.append(f"if ncdata and nncdata then")
        lines.append(f"    _G['_ffi_neighbors_ready'] = 1")
        lines.append(f"else")
        lines.append(f"    _G['_ffi_neighbors_ready'] = 0")
        lines.append(f"end")
        
        script = "\n".join(lines)
        self.bridge.execute_script(self.lua_state, script)
        
        # Check if FFI preparation succeeded
        ffi_ready = self._get_global_int("_ffi_neighbors_ready")
        if ffi_ready == 1:
            print("[FFI-SQS] FFI neighbor arrays created successfully")
        else:
            print("[FFI-SQS] Failed to create FFI neighbor arrays, will use standard tables")
            self.use_ffi = False
    
    def _get_global_int(self, name: str) -> int:
        """Get integer global from Lua state"""
        try:
            val = self.bridge.get_global_number(self.lua_state, name)
            return int(val) if val is not None else 0
        except:
            return 0
    
    def _get_global_float(self, name: str) -> float:
        """Get float global from Lua state"""
        try:
            val = self.bridge.get_global_number(self.lua_state, name)
            return float(val) if val is not None else 0.0
        except:
            return 0.0
    
    def _get_global_string(self, name: str) -> str:
        """Get string global from Lua state"""
        try:
            val = self.bridge.get_global_string(self.lua_state, name)
            return val if val else ""
        except:
            return ""
    
    def _extract_spins_from_globals(self, prefix: str, natoms: int) -> List[int]:
        """Extract spin array from Lua globals"""
        spins_list = []
        for i in range(1, natoms + 1):
            spin = self._get_global_int(f"{prefix}_{i}")
            spins_list.append(spin if spin != 0 else -1)  # Default to -1 if missing
        return spins_list
    
    def _cleanup_globals(self, prefix: str, natoms_key: str):
        """Clean up Lua globals after use"""
        cleanup_script = f"""
            local count = _G["{natoms_key}"] or 0
            for i = 1, count do
                _G["{prefix}_"..i] = nil
            end
            _G["{natoms_key}"] = nil
            _G["{prefix}_objective"] = nil
            _G["{prefix}_iterations"] = nil
            _G["{prefix}_success"] = nil
            _G["{prefix}_ffi_used"] = nil
        """
        self.bridge.execute_script(self.lua_state, cleanup_script)
    
    def random_search(self, natoms: int = None, n_B: int = None, 
                     n_trials: int = 10000, composition: float = None, 
                     convergence_threshold: float = 0.15, 
                     callback: Optional[Callable] = None) -> FFISQSResult:
        """
        Run FFI-optimized random search optimization
        
        Args:
            natoms: number of atoms
            n_B: number of B atoms
            n_trials: number of random trials
            composition: fraction of element B
            convergence_threshold: threshold for convergence
            callback: optional progress callback
        
        Returns:
            FFISQSResult with optimization results
        """
        start_time = time.time()
        
        if natoms is None and self.positions is not None:
            natoms = len(self.positions)
        elif natoms is None:
            raise ValueError("natoms must be provided if positions not set")
        
        comp = composition if composition is not None else self.composition
        n_B_val = n_B if n_B is not None else int(natoms * comp)
        
        if not self._initialized:
            print("[FFI-SQS] Not initialized, using Python fallback")
            return self._random_search_python(natoms, n_B_val, n_trials, comp, 
                                            convergence_threshold, callback, start_time)
        
        try:
            # Set random seed in Lua
            self.bridge.execute_script(self.lua_state, 
                f"math.randomseed({self.seed})")
            
            # Create wrapper script that uses FFI if available
            prefix = "_sqs_rs"
            
            wrapper = f"""
            -- FFI-Enhanced Random Search
            local ffi_used = false
            
            -- Check if FFI neighbor arrays are available
            if sqs_neighbors_cdata and sqs_n_neighbors_cdata then
                ffi_used = true
            end
            
            -- Call SQS random search (Lua engine decides FFI vs standard)
            local spins, obj, iter = sqs_random_search({natoms}, {n_B_val}, {n_trials}, {comp})
            
            -- Store results in globals
            if spins then
                _G["{prefix}_natoms"] = #spins
                for i = 1, #spins do
                    _G["{prefix}_" .. i] = spins[i]
                end
            else
                _G["{prefix}_natoms"] = 0
            end
            
            -- Store metadata
            _G["{prefix}_objective"] = obj
            _G["{prefix}_iterations"] = iter
            _G["{prefix}_success"] = 1
            _G["{prefix}_ffi_used"] = ffi_used and 1 or 0
            """
            
            # Execute the wrapper
            t0 = time.time()
            success = self.bridge.execute_script(self.lua_state, wrapper)
            self._lua_exec_time = time.time() - t0
            
            if not success:
                error = self.bridge.get_last_error(self.lua_state)
                print(f"[Error] FFI-SQS random search error: {error}")
                return self._random_search_python(natoms, n_B_val, n_trials, comp, 
                                                convergence_threshold, callback, start_time)
            
            # Check success
            success_flag = self._get_global_int(f"{prefix}_success")
            if success_flag == 0:
                print("[Error] FFI-SQS random search failed")
                return self._random_search_python(natoms, n_B_val, n_trials, comp, 
                                                convergence_threshold, callback, start_time)
            
            # Extract results
            result_natoms = self._get_global_int(f"{prefix}_natoms")
            obj = self._get_global_float(f"{prefix}_objective")
            iterations = self._get_global_int(f"{prefix}_iterations")
            ffi_used = self._get_global_int(f"{prefix}_ffi_used") == 1
            
            if result_natoms != natoms:
                print(f"[Warning] Atom count mismatch: {result_natoms} vs {natoms}")
                return self._random_search_python(natoms, n_B_val, n_trials, comp, 
                                                convergence_threshold, callback, start_time)
            
            # Extract spins using the helper method
            spins_list = self._extract_spins_from_globals(prefix, natoms)
            
            # Clean up globals
            self._cleanup_globals(prefix, f"{prefix}_natoms")
            
            # Calculate performance metrics
            elapsed = time.time() - start_time
            speedup = self._estimate_speedup(ffi_used, elapsed, n_trials)
            
            if callback:
                callback(n_trials, obj)
            
            print(f"[FFI-SQS] Random search completed in {elapsed:.3f}s "
                  f"(Lua: {self._lua_exec_time:.3f}s, FFI: {ffi_used}, "
                  f"Speedup: {speedup:.1f}x)")
            
            return FFISQSResult(
                spins=spins_list,
                objective_value=obj,
                iterations=iterations if iterations > 0 else n_trials,
                method=f'Random Search ({"FFI-LuaJIT" if ffi_used else "LuaJIT"})',
                time_seconds=elapsed,
                converged=obj < convergence_threshold,
                ffi_enabled=ffi_used,
                speedup_factor=speedup
            )
            
        except Exception as e:
            print(f"[FFI-SQS] Random search exception: {e}")
            import traceback
            traceback.print_exc()
            return self._random_search_python(natoms, n_B_val, n_trials, comp, 
                                            convergence_threshold, callback, start_time)
    
    def simulated_annealing(self, natoms: int = None, n_B: int = None,
                          T_start: float = 1.0, T_end: float = 0.01,
                          steps_per_T: int = 1000, cooling_rate: float = 0.95,
                          composition: float = None, 
                          convergence_threshold: float = 0.15,
                          callback: Optional[Callable] = None) -> FFISQSResult:
        """
        Run FFI-optimized simulated annealing optimization
        
        Args:
            natoms: number of atoms
            n_B: number of B atoms
            T_start: starting temperature
            T_end: ending temperature
            steps_per_T: Monte Carlo steps per temperature
            cooling_rate: temperature multiplier each step
            composition: fraction of element B
            convergence_threshold: threshold for convergence
            callback: optional progress callback
        
        Returns:
            FFISQSResult with optimization results
        """
        start_time = time.time()
        
        if natoms is None and self.positions is not None:
            natoms = len(self.positions)
        elif natoms is None:
            raise ValueError("natoms must be provided if positions not set")
        
        comp = composition if composition is not None else self.composition
        n_B_val = n_B if n_B is not None else int(natoms * comp)
        
        if not self._initialized:
            return self._simulated_annealing_python(natoms, n_B_val, T_start, T_end,
                                                   steps_per_T, cooling_rate, comp, 
                                                   convergence_threshold, callback, start_time)
        
        try:
            # Set random seed in Lua
            self.bridge.execute_script(self.lua_state, 
                f"math.randomseed({self.seed})")
            
            prefix = "_sqs_sa"
            
            wrapper = f"""
            -- FFI-Enhanced Simulated Annealing with progress tracking
            local ffi_used = false
            
            -- Check if FFI neighbor arrays are available
            if sqs_neighbors_cdata and sqs_n_neighbors_cdata then
                ffi_used = true
            end
            
            -- Call SQS simulated annealing
            local spins, obj, iter = sqs_simulated_annealing(
                {natoms}, {n_B_val}, {T_start}, {T_end}, 
                {steps_per_T}, {cooling_rate}, {comp}
            )
            
            -- Store results in globals
            if spins then
                _G["{prefix}_natoms"] = #spins
                for i = 1, #spins do
                    _G["{prefix}_" .. i] = spins[i]
                end
            else
                _G["{prefix}_natoms"] = 0
            end
            
            -- Store metadata
            _G["{prefix}_objective"] = obj
            _G["{prefix}_iterations"] = iter
            _G["{prefix}_success"] = 1
            _G["{prefix}_ffi_used"] = ffi_used and 1 or 0
            """
            
            # Execute the wrapper
            t0 = time.time()
            success = self.bridge.execute_script(self.lua_state, wrapper)
            self._lua_exec_time = time.time() - t0
            
            if not success:
                error = self.bridge.get_last_error(self.lua_state)
                print(f"[Error] FFI-SQS SA error: {error}")
                return self._simulated_annealing_python(natoms, n_B_val, T_start, T_end,
                                                       steps_per_T, cooling_rate, comp, 
                                                       convergence_threshold, callback, start_time)
            
            # Check success
            success_flag = self._get_global_int(f"{prefix}_success")
            if success_flag == 0:
                print("[Error] FFI-SQS simulated annealing failed")
                return self._simulated_annealing_python(natoms, n_B_val, T_start, T_end,
                                                       steps_per_T, cooling_rate, comp, 
                                                       convergence_threshold, callback, start_time)
            
            # Extract results
            result_natoms = self._get_global_int(f"{prefix}_natoms")
            obj = self._get_global_float(f"{prefix}_objective")
            iterations = self._get_global_int(f"{prefix}_iterations")
            ffi_used = self._get_global_int(f"{prefix}_ffi_used") == 1
            
            if result_natoms != natoms:
                print(f"[Warning] Atom count mismatch: {result_natoms} vs {natoms}")
                return self._simulated_annealing_python(natoms, n_B_val, T_start, T_end,
                                                       steps_per_T, cooling_rate, comp, 
                                                       convergence_threshold, callback, start_time)
            
            # Extract spins
            spins_list = self._extract_spins_from_globals(prefix, natoms)
            
            # Clean up globals
            self._cleanup_globals(prefix, f"{prefix}_natoms")
            
            # Calculate performance metrics
            elapsed = time.time() - start_time
            speedup = self._estimate_speedup(ffi_used, elapsed, iterations)
            
            if callback:
                callback(0, T_start, obj)
            
            print(f"[FFI-SQS] Simulated annealing completed in {elapsed:.3f}s "
                  f"(Lua: {self._lua_exec_time:.3f}s, FFI: {ffi_used}, "
                  f"Speedup: {speedup:.1f}x, {iterations} steps)")
            
            return FFISQSResult(
                spins=spins_list,
                objective_value=obj,
                iterations=iterations,
                method=f'Simulated Annealing ({"FFI-LuaJIT" if ffi_used else "LuaJIT"})',
                time_seconds=elapsed,
                converged=obj < convergence_threshold,
                ffi_enabled=ffi_used,
                speedup_factor=speedup
            )
            
        except Exception as e:
            print(f"[FFI-SQS] Simulated annealing exception: {e}")
            import traceback
            traceback.print_exc()
            return self._simulated_annealing_python(natoms, n_B_val, T_start, T_end,
                                                   steps_per_T, cooling_rate, comp, 
                                                   convergence_threshold, callback, start_time)
    
    def _estimate_speedup(self, ffi_used: bool, elapsed: float, iterations: int) -> float:
        """
        Estimate speedup factor based on FFI usage and timing
        
        Returns:
            Estimated speedup factor (higher is better)
        """
        if not ffi_used:
            return 1.0
        
        # Conservative estimate: FFI typically gives 2-5x speedup
        # for array-heavy operations
        base_speedup = 3.0
        
        # Larger systems benefit more from FFI
        natoms = len(self._neighbors_cache) if self._neighbors_cache else 100
        size_factor = 1.0 + 0.5 * (natoms / 100.0)  # Scale with system size
        
        # More iterations benefit more from FFI optimization
        iteration_factor = 1.0 + 0.2 * (iterations / 10000.0)
        
        estimated = base_speedup * size_factor * iteration_factor
        return min(estimated, 10.0)  # Cap at 10x to be conservative
    
    def benchmark(self, natoms: int = 100, n_trials: int = 1000) -> Dict[str, Any]:
        """
        Benchmark FFI vs standard performance
        
        Args:
            natoms: number of atoms for benchmarking
            n_trials: number of trials for random search
        
        Returns:
            Dictionary with benchmark results
        """
        print(f"\n[FFI-SQS] Running benchmark with {natoms} atoms, {n_trials} trials...")
        
        results = {
            'natoms': natoms,
            'n_trials': n_trials,
            'ffi_available': self._ffi_ready,
            'standard_time': None,
            'ffi_time': None,
            'speedup': 0.0
        }
        
        # Benchmark standard Lua (temporarily disable FFI)
        if self._initialized:
            self.bridge.execute_script(self.lua_state, 
                "_bench_no_ffi = function() sqs_neighbors_cdata = nil; sqs_n_neighbors_cdata = nil; end")
            self.bridge.execute_script(self.lua_state, "_bench_no_ffi()")
            
            t0 = time.time()
            result_std = self.random_search(natoms=natoms, n_trials=n_trials)
            results['standard_time'] = time.time() - t0
            results['standard_obj'] = result_std.objective_value
        
        # Benchmark with FFI
        if self._ffi_ready:
            # Restore FFI arrays by re-registering neighbors
            self._register_ffi_neighbors(natoms)
            
            t0 = time.time()
            result_ffi = self.random_search(natoms=natoms, n_trials=n_trials)
            results['ffi_time'] = time.time() - t0
            results['ffi_obj'] = result_ffi.objective_value
            
            if results['standard_time'] and results['ffi_time']:
                results['speedup'] = results['standard_time'] / max(results['ffi_time'], 0.001)
        
        # Print benchmark summary
        print("\n" + "="*50)
        print("FFI-SQS BENCHMARK RESULTS")
        print("="*50)
        print(f"System size: {natoms} atoms")
        print(f"Random trials: {n_trials}")
        
        if results['standard_time']:
            print(f"\nStandard Lua: {results['standard_time']:.3f}s")
        if results['ffi_time']:
            print(f"FFI Lua:      {results['ffi_time']:.3f}s")
        if results['speedup'] > 0:
            print(f"\nSpeedup: {results['speedup']:.2f}x")
        print("="*50 + "\n")
        
        return results
    
    def _random_search_python(self, natoms: int, n_B: int, n_trials: int,
                              composition: float, convergence_threshold: float = 0.15, 
                              callback=None, start_time=None) -> FFISQSResult:
        """Python fallback for random search"""
        if start_time is None:
            start_time = time.time()
        
        best_spins = None
        best_obj = float('inf')
        
        # Pre-compute for speed
        indices = list(range(natoms))
        
        for trial in range(n_trials):
            # Generate random configuration
            spins = [-1] * natoms
            random.shuffle(indices)
            for i in range(n_B):
                spins[indices[i]] = 1
            
            # Calculate objective
            obj = self._calculate_objective_python(spins, composition)
            
            if obj < best_obj:
                best_obj = obj
                best_spins = spins.copy()
                if callback and callable(callback):
                    callback(trial, best_obj)
        
        elapsed = time.time() - start_time
        
        return FFISQSResult(
            spins=best_spins,
            objective_value=best_obj,
            iterations=n_trials,
            method='Random Search (Python fallback)',
            time_seconds=elapsed,
            converged=best_obj < convergence_threshold,
            ffi_enabled=False
        )
    
    def _simulated_annealing_python(self, natoms: int, n_B: int,
                                    T_start: float, T_end: float,
                                    steps_per_T: int, cooling_rate: float,
                                    composition: float, convergence_threshold: float = 0.15, 
                                    callback=None, start_time=None) -> FFISQSResult:
        """Python fallback for simulated annealing"""
        if start_time is None:
            start_time = time.time()
        
        # Initialize with random configuration
        current_spins = [-1] * natoms
        indices = list(range(natoms))
        random.shuffle(indices)
        for i in range(n_B):
            current_spins[indices[i]] = 1
        
        best_spins = current_spins.copy()
        current_obj = self._calculate_objective_python(current_spins, composition)
        best_obj = current_obj
        
        T = T_start
        iteration = 0
        total_steps = 0
        
        while T > T_end:
            for step in range(steps_per_T):
                # Select two random different atoms
                i = random.randint(0, natoms - 1)
                j = random.randint(0, natoms - 1)
                
                # Ensure different spins
                attempts = 0
                while (i == j or current_spins[i] == current_spins[j]) and attempts < natoms * 2:
                    i = random.randint(0, natoms - 1)
                    j = random.randint(0, natoms - 1)
                    attempts += 1
                
                if i != j and current_spins[i] != current_spins[j]:
                    # Try swap
                    current_spins[i], current_spins[j] = current_spins[j], current_spins[i]
                    new_obj = self._calculate_objective_python(current_spins, composition)
                    delta = new_obj - current_obj
                    
                    if delta <= 0 or random.random() < math.exp(-delta / T):
                        current_obj = new_obj
                        if current_obj < best_obj:
                            best_obj = current_obj
                            best_spins = current_spins.copy()
                            if callback and callable(callback):
                                callback(iteration, T, best_obj)
                    else:
                        # Revert swap
                        current_spins[i], current_spins[j] = current_spins[j], current_spins[i]
                
                total_steps += 1
            
            T *= cooling_rate
            iteration += 1
        
        elapsed = time.time() - start_time
        
        return FFISQSResult(
            spins=best_spins,
            objective_value=best_obj,
            iterations=total_steps,
            method='Simulated Annealing (Python fallback)',
            time_seconds=elapsed,
            converged=best_obj < convergence_threshold,
            ffi_enabled=False
        )
    
    def _calculate_objective_python(self, spins: List[int], composition: float) -> float:
        """Calculate objective function in Python"""
        natoms = len(spins)
        comp = float(composition)
        
        try:
            # Use NumPy for faster computation
            spins_arr = np.array(spins, dtype=np.float64)
            
            # Sample pairs for efficiency
            sample_size = min(natoms, 200)
            sample_indices = np.random.choice(natoms, sample_size, replace=False)
            
            pair_sum = 0.0
            n_pairs = 0
            
            # Sample nearby pairs (in index space since we don't have coordinates)
            for i_idx in range(sample_size):
                for j_idx in range(i_idx + 1, min(i_idx + 16, sample_size)):
                    pair_sum += spins_arr[sample_indices[i_idx]] * spins_arr[sample_indices[j_idx]]
                    n_pairs += 1
            
            if n_pairs == 0:
                return 1.0
            
            ideal_corr = (2.0 * comp - 1.0) ** 2
            actual_corr = pair_sum / n_pairs
            return abs(actual_corr - ideal_corr)
            
        except ImportError:
            # Pure Python fallback
            n_pairs = 0
            pair_sum = 0.0
            sample_size = min(natoms, 200)
            sample_indices = random.sample(range(natoms), sample_size)
            
            for i_idx in range(sample_size):
                for j_idx in range(i_idx + 1, min(i_idx + 16, sample_size)):
                    pair_sum += spins[sample_indices[i_idx]] * spins[sample_indices[j_idx]]
                    n_pairs += 1
            
            if n_pairs == 0:
                return 1.0
            
            ideal_corr = (2.0 * comp - 1.0) ** 2
            actual_corr = pair_sum / n_pairs
            return abs(actual_corr - ideal_corr)
    
    def spins_to_elements(self, spins: List[int]) -> List[str]:
        """Convert spin values to element symbols"""
        return [self.element_B if s == 1 else self.element_A for s in spins]
    
    def set_lattice(self, lattice_vectors: np.ndarray, positions: np.ndarray, 
                   neighbor_cutoff: float = 2.5):
        """Set lattice and positions for neighbor calculation"""
        self.lattice_vectors = lattice_vectors
        self.positions = positions
        self.neighbor_cutoff = neighbor_cutoff
        self._setup_neighbors_ffi()
    
    @property
    def is_available(self) -> bool:
        """Check if engine is initialized and ready"""
        return self._initialized
    
    @property
    def ffi_available(self) -> bool:
        """Check if FFI optimization is available"""
        return self._initialized and self._ffi_ready and self.use_ffi
    
    @property
    def status(self) -> Dict[str, Any]:
        """Get engine status information"""
        return {
            'initialized': self._initialized,
            'ffi_ready': self._ffi_ready,
            'use_ffi': self.use_ffi,
            'neighbors_built': self._neighbors_cache is not None,
            'natoms': len(self._neighbors_cache) if self._neighbors_cache else 0,
            'ffi_prep_time_ms': self._ffi_prep_time * 1000,
            'lua_exec_time_ms': self._lua_exec_time * 1000,
        }
    
    def cleanup(self):
        """Clean up Lua state and resources"""
        if self.bridge and self.lua_state:
            try:
                # Clean up FFI arrays
                self.bridge.execute_script(self.lua_state, """
                    sqs_neighbors_cdata = nil
                    sqs_n_neighbors_cdata = nil
                """)
                self.bridge.close(self.lua_state)
            except Exception as e:
                print(f"[FFI-SQS] Cleanup warning: {e}")
            finally:
                self.lua_state = None
                self._initialized = False
                self._ffi_ready = False
    
    def __del__(self):
        """Destructor to ensure cleanup"""
        self.cleanup()


# Global engine instance for singleton pattern
_ffi_engine = None


def get_ffi_engine(lattice_vectors: np.ndarray = None, positions: np.ndarray = None,
                  element_A: str = 'A', element_B: str = 'B',
                  composition: float = 0.5, neighbor_cutoff: float = 2.5,
                  seed: Optional[int] = None, use_ffi: bool = True,
                  force_new: bool = False) -> FFISQSEngine:
    """
    Get or create FFI-Enhanced SQS engine instance (singleton pattern)
    Similar to sqs_lua_wrapper.get_lua_engine()
    
    Args:
        lattice_vectors: 3x3 lattice matrix
        positions: atomic positions
        element_A: first element symbol  
        element_B: second element symbol
        composition: fraction of element B
        neighbor_cutoff: distance cutoff for neighbors
        seed: random seed
        use_ffi: whether to use FFI optimization
        force_new: force creation of new instance
    
    Returns:
        FFISQSEngine instance
    """
    global _ffi_engine
    
    if _ffi_engine is None or force_new:
        print(f"[FFI-SQS] Creating new engine instance (FFI: {use_ffi})...")
        
        if _ffi_engine is not None:
            _ffi_engine.cleanup()
        
        _ffi_engine = FFISQSEngine(
            lattice_vectors=lattice_vectors,
            positions=positions,
            element_A=element_A,
            element_B=element_B,
            composition=composition,
            neighbor_cutoff=neighbor_cutoff,
            seed=seed,
            use_ffi=use_ffi
        )
    else:
        print("[FFI-SQS] Returning existing engine instance")
        if lattice_vectors is not None and positions is not None:
            _ffi_engine.set_lattice(lattice_vectors, positions, neighbor_cutoff)
    
    return _ffi_engine


def cleanup_ffi_engine():
    """Clean up global FFI engine instance"""
    global _ffi_engine
    if _ffi_engine is not None:
        _ffi_engine.cleanup()
        _ffi_engine = None
    print("[FFI-SQS] Engine cleaned up")