"""
Generate lattice structures for SQS
"""

import numpy as np
from typing import Tuple, List, Dict
from math import gcd


class LatticeGenerator:
    """Generate FCC, BCC, and custom lattice structures"""
    
    @staticmethod
    def fcc_lattice(cell_size: int = 2, lattice_constant: float = 4.05) -> Tuple[np.ndarray, np.ndarray]:
        """
        Generate FCC lattice
        
        Args:
            cell_size: number of unit cells in each direction
            lattice_constant: lattice constant in Angstroms
        
        Returns:
            lattice_vectors: 3x3 lattice matrix
            positions: fractional coordinates of atoms
        """
        # FCC basis (4 atoms per unit cell)
        basis = np.array([
            [0.0, 0.0, 0.0],
            [0.0, 0.5, 0.5],
            [0.5, 0.0, 0.5],
            [0.5, 0.5, 0.0]
        ])
        
        # Lattice vectors
        a = lattice_constant
        lattice_vectors = np.array([
            [a, 0, 0],
            [0, a, 0],
            [0, 0, a]
        ])
        
        # Generate supercell positions
        positions = []
        for i in range(cell_size):
            for j in range(cell_size):
                for k in range(cell_size):
                    for b in basis:
                        pos = np.array([i, j, k]) + b
                        positions.append(pos / cell_size)
        
        return lattice_vectors, np.array(positions)
    
    @staticmethod
    def bcc_lattice(cell_size: int = 2, lattice_constant: float = 3.15) -> Tuple[np.ndarray, np.ndarray]:
        """
        Generate BCC lattice
        
        Args:
            cell_size: number of unit cells in each direction
            lattice_constant: lattice constant in Angstroms
        """
        # BCC basis (2 atoms per unit cell)
        basis = np.array([
            [0.0, 0.0, 0.0],
            [0.5, 0.5, 0.5]
        ])
        
        a = lattice_constant
        lattice_vectors = np.array([
            [a, 0, 0],
            [0, a, 0],
            [0, 0, a]
        ])
        
        positions = []
        for i in range(cell_size):
            for j in range(cell_size):
                for k in range(cell_size):
                    for b in basis:
                        pos = np.array([i, j, k]) + b
                        positions.append(pos / cell_size)
        
        return lattice_vectors, np.array(positions)
    
    @staticmethod
    def simple_cubic_lattice(cell_size: int = 3, lattice_constant: float = 3.0) -> Tuple[np.ndarray, np.ndarray]:
        """Generate simple cubic lattice"""
        basis = np.array([[0.0, 0.0, 0.0]])
        
        a = lattice_constant
        lattice_vectors = np.array([
            [a, 0, 0],
            [0, a, 0],
            [0, 0, a]
        ])
        
        positions = []
        for i in range(cell_size):
            for j in range(cell_size):
                for k in range(cell_size):
                    pos = np.array([i, j, k]) / cell_size
                    positions.append(pos)
        
        return lattice_vectors, np.array(positions)
    
    @staticmethod
    def hcp_lattice(cell_size: int = 2, lattice_constants: Tuple[float, float] = (3.2, 5.2)) -> Tuple[np.ndarray, np.ndarray]:
        """
        Generate HCP lattice
        
        Args:
            cell_size: number of unit cells
            lattice_constants: (a, c) lattice parameters
        """
        a, c = lattice_constants
        
        # HCP basis (2 atoms per unit cell)
        basis = np.array([
            [0.0, 0.0, 0.0],
            [1.0/3.0, 2.0/3.0, 0.5]
        ])
        
        lattice_vectors = np.array([
            [a, 0, 0],
            [-a/2, a*np.sqrt(3)/2, 0],
            [0, 0, c]
        ])
        
        positions = []
        for i in range(cell_size):
            for j in range(cell_size):
                for k in range(cell_size):
                    for b in basis:
                        pos = (np.array([i, j, k]) + b) / cell_size
                        positions.append(pos)
        
        return lattice_vectors, np.array(positions)
    
    @staticmethod
    def get_supercell_sizes(n_atoms: int, n_sites_per_cell: int) -> List[int]:
        """
        Get possible supercell sizes for given number of atoms
        
        Args:
            n_atoms: desired number of atoms
            n_sites_per_cell: number of sites per primitive cell
        """
        n_cells_needed = n_atoms // n_sites_per_cell
        sizes = []
        
        # Find divisors
        for i in range(1, int(np.cbrt(n_cells_needed)) + 2):
            if n_cells_needed % (i**3) == 0:
                sizes.append(i)
        
        return sizes
    
    @staticmethod
    def write_poscar(lattice_vectors: np.ndarray, positions: np.ndarray, 
                     elements: List[str], filename: str, comment: str = "SQS structure"):
        """Write POSCAR file"""
        with open(filename, 'w') as f:
            f.write(f"{comment}\n")
            f.write("1.0\n")
            
            # Lattice vectors
            for i in range(3):
                f.write(f" {lattice_vectors[i,0]:.12f} {lattice_vectors[i,1]:.12f} {lattice_vectors[i,2]:.12f}\n")
            
            # Elements
            unique_elements = []
            counts = []
            for elem in elements:
                if elem not in unique_elements:
                    unique_elements.append(elem)
                    counts.append(1)
                else:
                    counts[unique_elements.index(elem)] += 1
            
            f.write(" ".join(unique_elements) + "\n")
            f.write(" ".join(str(c) for c in counts) + "\n")
            f.write("Direct\n")
            
            # Positions
            for pos in positions:
                f.write(f" {pos[0]:.12f} {pos[1]:.12f} {pos[2]:.12f}\n")
        
        return filename
    
    @staticmethod
    def rutile_tio2(cell_size: int = 2, a: float = 4.594, c: float = 2.959) -> Tuple[np.ndarray, np.ndarray, List[str]]:
        """Generate Rutile TiO₂ supercell"""
        # Rutile basis: 2 Ti, 4 O per unit cell
        # basis = [
        #     ('Ti', 0.0, 0.0, 0.0),
        #     ('Ti', 0.5, 0.5, 0.5),
        #     ('O', 0.305, 0.305, 0.0),
        #     ('O', -0.305, -0.305, 0.0),
        #     ('O', 0.805, 0.195, 0.5),
        #     ('O', 0.195, 0.805, 0.5),
        # ]

        basis = [
            ('Ti', 0.0, 0.0, 0.0),      # Ti1
            ('Ti', 0.5, 0.5, 0.5),      # Ti2
            ('O', 0.3, 0.3, 0.0),       # O1
            ('O', 0.7, 0.7, 0.0),       # O2
            ('O', 0.2, 0.8, 0.5),       # O3
            ('O', 0.8, 0.2, 0.5),       # O4
        ]
        
        lattice_vectors = np.array([[a, 0, 0], [0, a, 0], [0, 0, c]])
        
        positions = []
        elements = []
        
        for i in range(cell_size):
            for j in range(cell_size):
                for k in range(cell_size):
                    for elem, x, y, z in basis:
                        pos_x = (i + x) / cell_size
                        pos_y = (j + y) / cell_size
                        pos_z = (k + z) / cell_size
                        positions.append([pos_x % 1.0, pos_y % 1.0, pos_z % 1.0])
                        elements.append(elem)
        
        return lattice_vectors, np.array(positions), elements


    @staticmethod
    def anatase_tio2(cell_size: int = 2, a: float = 3.784, c: float = 9.515) -> Tuple[np.ndarray, np.ndarray, List[str]]:
        """Generate Anatase TiO₂ supercell"""
        # Anatase basis: 4 Ti, 8 O per unit cell
        # basis = [
        #     ('Ti', 0.0, 0.0, 0.0),
        #     ('Ti', 0.5, 0.5, 0.5),
        #     ('Ti', 0.5, 0.0, 0.25),
        #     ('Ti', 0.0, 0.5, 0.75),
        #     ('O', 0.208, 0.208, 0.0),
        #     ('O', 0.792, 0.792, 0.0),
        #     ('O', 0.708, 0.292, 0.5),
        #     ('O', 0.292, 0.708, 0.5),
        #     ('O', 0.708, 0.208, 0.25),
        #     ('O', 0.208, 0.708, 0.25),
        #     ('O', 0.292, 0.792, 0.75),
        #     ('O', 0.792, 0.292, 0.75),
        # ]

        basis = [
            ('Ti', 0.0, 0.0, 0.0),
            ('Ti', 0.5, 0.5, 0.5),
            ('Ti', 0.5, 0.0, 0.25),
            ('Ti', 0.0, 0.5, 0.75),
            ('O', 0.000000, 0.000000, 0.208100),
            ('O', 0.500000, 0.500000, 0.708100),
            ('O', 0.000000, 0.500000, 0.458100),
            ('O', 0.500000, 0.000000, 0.958100),
            ('O', 0.275000, 0.275000, 0.000000),
            ('O', 0.775000, 0.775000, 0.500000),
            ('O', 0.275000, 0.775000, 0.250000),
            ('O', 0.775000, 0.275000, 0.750000),
        ]
        
        lattice_vectors = np.array([[a, 0, 0], [0, a, 0], [0, 0, c]])
        
        positions = []
        elements = []
        
        for i in range(cell_size):
            for j in range(cell_size):
                for k in range(cell_size):
                    for elem, x, y, z in basis:
                        pos_x = (i + x) / cell_size
                        pos_y = (j + y) / cell_size
                        pos_z = (k + z) / cell_size
                        positions.append([pos_x % 1.0, pos_y % 1.0, pos_z % 1.0])
                        elements.append(elem)
        
        return lattice_vectors, np.array(positions), elements


    @staticmethod
    def brookite_tio2(cell_size: int = 2, a: float = 5.456, b: float = 9.182, c: float = 5.143) -> Tuple[np.ndarray, np.ndarray, List[str]]:
        """Generate Brookite TiO₂ supercell (orthorhombic)"""
        # Brookite basis: 4 Ti, 8 O per unit cell
        # basis = [
        #     ('Ti', 0.127, 0.127, 0.125),
        #     ('Ti', 0.873, 0.873, 0.875),
        #     ('Ti', 0.373, 0.373, 0.625),
        #     ('Ti', 0.627, 0.627, 0.375),
        #     ('O', 0.010, 0.135, 0.250),
        #     ('O', 0.990, 0.865, 0.750),
        #     ('O', 0.230, 0.180, 0.500),
        #     ('O', 0.770, 0.820, 0.000),
        #     ('O', 0.750, 0.430, 0.250),
        #     ('O', 0.250, 0.570, 0.750),
        #     ('O', 0.500, 0.500, 0.500),
        #     ('O', 0.000, 0.000, 0.000),
        # ]

        basis = [
            # Ti atoms (8 per unit cell)
            ('Ti', 0.00000, 0.00000, 0.00000),    # Ti1
            ('Ti', 0.50000, 0.00000, 0.50000),    # Ti2
            ('Ti', 0.00000, 0.50000, 0.50000),    # Ti3
            ('Ti', 0.50000, 0.50000, 0.00000),    # Ti4
            ('Ti', 0.25000, 0.25000, 0.25000),    # Ti5
            ('Ti', 0.75000, 0.25000, 0.75000),    # Ti6
            ('Ti', 0.25000, 0.75000, 0.75000),    # Ti7
            ('Ti', 0.75000, 0.75000, 0.25000),    # Ti8
            
            # O atoms (16 per unit cell)
            ('O', 0.10000, 0.10000, 0.10000),    # O1
            ('O', 0.60000, 0.10000, 0.60000),    # O2
            ('O', 0.10000, 0.60000, 0.60000),    # O3
            ('O', 0.60000, 0.60000, 0.10000),    # O4
            ('O', 0.35000, 0.35000, 0.35000),    # O5
            ('O', 0.85000, 0.35000, 0.85000),    # O6
            ('O', 0.35000, 0.85000, 0.85000),    # O7
            ('O', 0.85000, 0.85000, 0.35000),    # O8
            ('O', 0.20000, 0.05000, 0.45000),    # O9
            ('O', 0.70000, 0.05000, 0.95000),    # O10
            ('O', 0.20000, 0.55000, 0.95000),    # O11
            ('O', 0.70000, 0.55000, 0.45000),    # O12
            ('O', 0.45000, 0.20000, 0.05000),    # O13
            ('O', 0.95000, 0.20000, 0.55000),    # O14
            ('O', 0.45000, 0.70000, 0.55000),    # O15
            ('O', 0.95000, 0.70000, 0.05000),    # O16
        ]
        
        lattice_vectors = np.array([[a, 0, 0], [0, b, 0], [0, 0, c]])
        
        positions = []
        elements = []
        
        for i in range(cell_size):
            for j in range(cell_size):
                for k in range(cell_size):
                    for elem, x, y, z in basis:
                        pos_x = (i + x) / cell_size
                        pos_y = (j + y) / cell_size
                        pos_z = (k + z) / cell_size
                        positions.append([pos_x % 1.0, pos_y % 1.0, pos_z % 1.0])
                        elements.append(elem)
        
        return lattice_vectors, np.array(positions), elements
    
    @staticmethod
    def rutile_tio2_primitive(a=4.594, c=2.959):
        """
        Return primitive cell of rutile TiO₂ (6 atoms)
        
        Rutile: tetragonal, space group P4₂/mnm (No. 136)
        Primitive cell contains 2 formula units (Ti₂O₄)
        """
        primitive_vectors = np.array([
            [a/2, a/2, 0],
            [-a/2, a/2, 0],
            [0, 0, c]
        ])
        
        # Fractional coordinates in primitive cell
        # Based on symmetry operations of space group P4₂/mnm
        primitive_positions = np.array([
            # Ti atoms (2)
            [0.0, 0.0, 0.0],        # Ti1 at origin
            [0.5, 0.5, 0.5],        # Ti2 at body center
            
            # O atoms (4)
            [0.305, 0.305, 0.0],    # O1 equatorial
            [0.695, 0.695, 0.0],    # O2 equatorial (symmetry-related)
            [0.805, 0.195, 0.5],    # O3 apical
            [0.195, 0.805, 0.5],    # O4 apical (symmetry-related)
        ])
        
        primitive_elements = ['Ti', 'Ti', 'O', 'O', 'O', 'O']
        
        return primitive_vectors, primitive_positions, primitive_elements


    @staticmethod
    def anatase_tio2_primitive(a=3.784, c=9.515):
        """
        Return primitive cell of anatase TiO₂ (12 atoms)
        
        Anatase: tetragonal, space group I4₁/amd (No. 141)
        Primitive cell contains 4 formula units (Ti₄O₈)
        """
        # Primitive vectors for body-centered tetragonal
        primitive_vectors = np.array([
            [a/2, -a/2, c/2],
            [a/2, a/2, c/2],
            [-a/2, -a/2, c/2]
        ])
        
        # Fractional coordinates in primitive cell
        # Based on Wyckoff positions of space group I4₁/amd
        primitive_positions = np.array([
            # Ti atoms (4) - Wyckoff position 4a (0,0,0) and equivalents
            [0.0, 0.0, 0.0],        # Ti1
            [0.5, 0.5, 0.5],        # Ti2 (body-centered)
            [0.0, 0.5, 0.25],       # Ti3
            [0.5, 0.0, 0.75],       # Ti4
            
            # O atoms (8) - Wyckoff position 8e (0,0,z) etc.
            [0.0, 0.0, 0.208],      # O1
            [0.5, 0.5, 0.708],      # O2
            [0.0, 0.5, 0.458],      # O3
            [0.5, 0.0, 0.958],      # O4
            [0.25, 0.25, 0.0],      # O5
            [0.75, 0.75, 0.5],      # O6
            [0.25, 0.75, 0.25],     # O7
            [0.75, 0.25, 0.75],     # O8
        ])
        
        primitive_elements = ['Ti'] * 4 + ['O'] * 8
        
        return primitive_vectors, primitive_positions, primitive_elements


    @staticmethod
    def brookite_tio2_primitive(a=5.456, b=9.182, c=5.143):
        """
        Return primitive cell of brookite TiO₂ (24 atoms)
        
        Brookite: orthorhombic, space group Pbca (No. 61)
        Conventional cell contains 8 formula units (Ti₈O₁₆)
        Primitive cell contains 4 formula units (Ti₄O₈ = 12 atoms)
        """
        # Primitive vectors for orthorhombic system
        primitive_vectors = np.array([
            [a/2, b/2, 0],
            [a/2, -b/2, 0],
            [0, 0, c]
        ])
        
        # Fractional coordinates in primitive cell
        # Based on Wyckoff positions of space group Pbca
        # Ti atoms (4) - Wyckoff position 8c (general position)
        # O atoms (8) - Wyckoff positions 8c
        primitive_positions = np.array([
            # Ti atoms (4)
            [0.127, 0.128, 0.875],   # Ti1
            [0.373, 0.128, 0.875],   # Ti2
            [0.127, 0.872, 0.875],   # Ti3
            [0.373, 0.872, 0.875],   # Ti4
            
            # O atoms (8)
            [0.010, 0.135, 0.250],   # O1
            [0.230, 0.180, 0.500],   # O2
            [0.750, 0.430, 0.250],   # O3
            [0.500, 0.500, 0.500],   # O4
            [0.990, 0.865, 0.750],   # O5 (symmetry-related to O1)
            [0.770, 0.820, 0.000],   # O6 (symmetry-related to O2)
            [0.250, 0.570, 0.750],   # O7 (symmetry-related to O3)
            [0.000, 0.000, 0.000],   # O8 (symmetry-related to O4)
        ])
        
        primitive_elements = ['Ti'] * 4 + ['O'] * 8
        
        return primitive_vectors, primitive_positions, primitive_elements


    @staticmethod
    def binary_alloy_primitive(lattice_type: str = 'FCC', lattice_constant: float = 4.05, cell_size: int = 1):
        """
        Return conventional cell for binary alloys
        
        Args:
            lattice_type: 'FCC', 'BCC', 'SC', 'HCP'
            lattice_constant: lattice constant in Angstroms
            cell_size: supercell size (for logging/info only)
        """
        a = lattice_constant
        
        if lattice_type == 'FCC':
            # FCC conventional cell (4 atoms)
            primitive_vectors = np.array([
                [a, 0, 0],
                [0, a, 0],
                [0, 0, a]
            ])
            primitive_positions = np.array([
                [0.0, 0.0, 0.0],
                [0.0, 0.5, 0.5],
                [0.5, 0.0, 0.5],
                [0.5, 0.5, 0.0]
            ])
            primitive_elements = ['A'] * 4
            
        elif lattice_type == 'BCC':
            # BCC conventional cell (2 atoms)
            primitive_vectors = np.array([
                [a, 0, 0],
                [0, a, 0],
                [0, 0, a]
            ])
            primitive_positions = np.array([
                [0.0, 0.0, 0.0],
                [0.5, 0.5, 0.5]
            ])
            primitive_elements = ['A'] * 2
            
        elif lattice_type == 'Simple Cubic':
            # Simple cubic conventional cell (1 atom)
            primitive_vectors = np.array([
                [a, 0, 0],
                [0, a, 0],
                [0, 0, a]
            ])
            primitive_positions = np.array([[0.0, 0.0, 0.0]])
            primitive_elements = ['A']
            
        elif lattice_type == 'HCP':
            # HCP conventional cell (2 atoms)
            c = lattice_constant * 1.633
            primitive_vectors = np.array([
                [a, 0, 0],
                [-a/2, a*np.sqrt(3)/2, 0],
                [0, 0, c]
            ])
            primitive_positions = np.array([
                [0.0, 0.0, 0.0],
                [1/3, 2/3, 0.5]
            ])
            primitive_elements = ['A'] * 2
            
        else:
            raise ValueError(f"Unknown lattice type: {lattice_type}")
        
        return primitive_vectors, primitive_positions, primitive_elements

    @staticmethod
    def get_primitive_from_supercell(supercell_vectors: np.ndarray, 
                                    supercell_positions: np.ndarray,
                                    supercell_elements: List[str],
                                    supercell_size: Tuple[int, int, int]) -> Tuple[np.ndarray, np.ndarray, List[str]]:
        """
        Extract primitive cell from a supercell
        
        Args:
            supercell_vectors: Lattice vectors of supercell
            supercell_positions: Positions in supercell (fractional coordinates)
            supercell_elements: Element symbols for each atom
            supercell_size: Size of supercell (nx, ny, nz)
        
        Returns:
            primitive_vectors, primitive_positions, primitive_elements
        """
        nx, ny, nz = supercell_size
        
        # Calculate primitive cell vectors
        primitive_vectors = supercell_vectors / np.array([[nx, ny, nz]]).T
        
        # Collect unique atoms from one copy of the primitive cell
        primitive_positions_set = set()
        primitive_elements_list = []
        
        for i in range(len(supercell_positions)):
            # Convert to primitive cell coordinates
            prim_x = (supercell_positions[i][0] * nx) % 1.0
            prim_y = (supercell_positions[i][1] * ny) % 1.0
            prim_z = (supercell_positions[i][2] * nz) % 1.0
            
            key = (round(prim_x, 6), round(prim_y, 6), round(prim_z, 6))
            
            if key not in primitive_positions_set:
                primitive_positions_set.add(key)
                primitive_elements_list.append(supercell_elements[i])
        
        primitive_positions = np.array(list(primitive_positions_set))
        
        return primitive_vectors, primitive_positions, primitive_elements_list