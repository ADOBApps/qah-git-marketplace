# sudo apt install gfortran-mingw-w64-x86-64

# Build the Fortran source file into an object file with position-independent code
x86_64-w64-mingw32-gfortran -c ../fortran_sqs.f90 -o libsqs_engine.o -fPIC -fopenmp

# Build the DLL with static linking to the Fortran runtime libraries
x86_64-w64-mingw32-gfortran -shared -o libsqs_engine.dll libsqs_engine.o -static-libgfortran -static-libgcc -static -lquadmath -fopenmp

# Verify the DLL was created and check its dependencies
x86_64-w64-mingw32-objdump -p libsqs_engine.dll | grep "DLL Name"

# Build the Fortran source file into an object file with position-independent code
# Using the new ICET-optimized version
x86_64-w64-mingw32-gfortran -c ../fortran_sqs_icet.f90 -o libsqs_icet_engine.o \
    -fPIC -fopenmp -O3 -march=native -ffast-math -funroll-loops -ftree-vectorize

# Build the DLL with static linking to the Fortran runtime libraries
# For maximum compatibility with Python on Windows
x86_64-w64-mingw32-gfortran -shared -o libsqs_icet_engine.dll libsqs_icet_engine.o \
    -static-libgfortran -static-libgcc -static -lquadmath -fopenmp \
    -Wl,--enable-auto-image-base \
    -Wl,--enable-auto-import \
    -Wl,--add-stdcall-alias

# Alternative: If you want dependency on Go runtime (for better compatibility with some Windows versions)
# x86_64-w64-mingw32-gfortran -shared -o libsqs_icet_engine.dll libsqs_icet_engine.o \
#     -static-libgfortran -static-libgcc -static -lquadmath -fopenmp \
#     -Wl,-Bstatic -lstdc++ -Wl,-Bdynamic \
#     -Wl,--enable-auto-image-base \
#     -Wl,--enable-auto-import

# Verify the DLL was created and check its dependencies
x86_64-w64-mingw32-objdump -p libsqs_icet_engine.dll | grep "DLL Name"

# Also check the DLL exports to ensure all C-binding functions are exported
x86_64-w64-mingw32-objdump -p libsqs_icet_engine.dll | grep "DLL Name"

# Optional: List all exported functions
x86_64-w64-mingw32-nm libsqs_icet_engine.dll | grep " T " | grep -v "___"

# Optional: Check for OpenMP dependency
x86_64-w64-mingw32-objdump -p libsqs_icet_engine.dll | grep "LIBGCC"

# Create a .def file for explicit exports (if needed)
cat > libsqs_icet_engine.def << 'EOF'
EXPORTS
    init_random_state
    random_double
    build_neighbor_list
    pair_correlation_fast
    compute_cluster_vector
    objective_value_multi
    estimate_correlation
    random_search_parallel
    simulated_annealing_parallel
    get_version
EOF

# Rebuild with explicit exports using .def file
x86_64-w64-mingw32-gfortran -shared -o libsqs_icet_engine.dll libsqs_icet_engine.o \
    -static-libgfortran -static-libgcc -static -lquadmath -fopenmp \
    -Wl,--enable-auto-image-base \
    -Wl,--enable-auto-import \
    -Wl,--add-stdcall-alias \
    libsqs_icet_engine.def