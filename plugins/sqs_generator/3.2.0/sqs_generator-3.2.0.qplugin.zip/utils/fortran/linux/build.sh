gfortran -shared -fPIC -O3 -fopenmp -o libsqs_engine.so ../fortran_sqs.f90
gfortran -shared -fPIC -O3 -march=native -ffast-math -fopenmp -o libsqs_icet_engine.so ../fortran_sqs_icet.f90