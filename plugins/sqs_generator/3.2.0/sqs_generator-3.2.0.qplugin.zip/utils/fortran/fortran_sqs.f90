! fortran_sqs.f90 - High-performance SQS engine with Fortran
! Compile: gfortran -shared -fPIC -O3 -o libsqs_engine.so fortran_sqs.f90

module sqs_engine
    use, intrinsic :: iso_c_binding
    implicit none
    
contains

    !==========================================================================
    ! Calculate simplified objective function
    !==========================================================================
    
    subroutine calculate_objective(natoms, spins, composition, obj_value) &
            bind(C, name="calculate_objective")
        integer(c_int), intent(in), value :: natoms
        integer(c_int), intent(in) :: spins(natoms)
        real(c_double), intent(in), value :: composition
        real(c_double), intent(out) :: obj_value
        
        integer :: i, j, n_pairs, idx_i, idx_j
        real(8) :: pair_sum, ideal_corr, actual_corr
        integer :: sample_size
        integer, allocatable :: indices(:)
        real(8) :: rand_val
        
        n_pairs = 0
        pair_sum = 0.0d0
        
        ! Sample pairs for performance
        sample_size = min(natoms, 200)
        
        if (sample_size < 2) then
            obj_value = 1.0d0
            return
        end if
        
        ! Create shuffled indices for sampling
        allocate(indices(sample_size))
        
        ! Generate random indices for sampling
        do i = 1, sample_size
            call random_number(rand_val)
            indices(i) = mod(int(rand_val * 1000000), natoms) + 1
        end do
        
        ! Sample pairs
        do i = 1, sample_size - 1
            do j = i + 1, min(i + 15, sample_size)
                idx_i = indices(i)
                idx_j = indices(j)
                pair_sum = pair_sum + dble(spins(idx_i) * spins(idx_j))
                n_pairs = n_pairs + 1
            end do
        end do
        
        if (n_pairs == 0) then
            obj_value = 1.0d0
            deallocate(indices)
            return
        end if
        
        ! Target correlation for random alloy
        ideal_corr = (2.0d0 * composition - 1.0d0) ** 2
        actual_corr = pair_sum / dble(n_pairs)
        obj_value = abs(actual_corr - ideal_corr)
        
        deallocate(indices)
        
    end subroutine calculate_objective
    
    !==========================================================================
    ! Fast random search
    !==========================================================================
    
    subroutine random_search_fast(natoms, n_B, n_trials, composition, &
                                  best_spins, best_objective, iterations) &
            bind(C, name="random_search_fast")
        integer(c_int), intent(in), value :: natoms, n_B, n_trials
        real(c_double), intent(in), value :: composition
        integer(c_int), intent(out) :: best_spins(natoms)
        real(c_double), intent(out) :: best_objective
        integer(c_int), intent(out) :: iterations
        
        integer :: trial, i, idx, n_B_count
        integer :: test_spins(natoms)
        real(8) :: obj, rand_val
        real(8) :: best_obj
        character(len=200) :: msg
        
        best_obj = 1.0d30
        best_spins = -1
        
        do trial = 1, n_trials
            ! Reset test_spins to all -1 (A atoms)
            test_spins = -1
            n_B_count = 0
            
            ! Place exactly n_B atoms of type B (spin = 1)
            do while (n_B_count < n_B)
                call random_number(rand_val)
                idx = mod(int(rand_val * 1000000), natoms) + 1
                if (test_spins(idx) == -1) then
                    test_spins(idx) = 1
                    n_B_count = n_B_count + 1
                end if
            end do
            
            ! Calculate objective
            call calculate_objective(natoms, test_spins, composition, obj)
            
            if (obj < best_obj) then
                best_obj = obj
                best_spins = test_spins
            end if
        end do
        
        best_objective = best_obj
        iterations = n_trials
        
    end subroutine random_search_fast
    
    !==========================================================================
    ! Parallel random search
    !==========================================================================
    
    subroutine random_search_parallel(natoms, n_B, n_trials, composition, &
                                      best_spins, best_objective, iterations) &
            bind(C, name="random_search_parallel")
        integer(c_int), intent(in), value :: natoms, n_B, n_trials
        real(c_double), intent(in), value :: composition
        integer(c_int), intent(out) :: best_spins(natoms)
        real(c_double), intent(out) :: best_objective
        integer(c_int), intent(out) :: iterations
        
        integer :: trial, idx, n_B_count, tid, nthreads
        integer, allocatable :: local_best_spins(:,:)
        real(8), allocatable :: local_best_obj(:)
        real(8) :: obj, rand_val
        real(8) :: best_obj
        integer :: test_spins(natoms)
        
        best_obj = 1.0d30
        best_spins = -1
        
        ! Get number of threads
        nthreads = 1  ! Start with 1 thread for stability
        allocate(local_best_spins(natoms, nthreads))
        allocate(local_best_obj(nthreads))
        local_best_obj = 1.0d30
        
        do trial = 1, n_trials
            test_spins = -1
            n_B_count = 0
            
            do while (n_B_count < n_B)
                call random_number(rand_val)
                idx = mod(int(rand_val * 1000000), natoms) + 1
                if (test_spins(idx) == -1) then
                    test_spins(idx) = 1
                    n_B_count = n_B_count + 1
                end if
            end do
            
            call calculate_objective(natoms, test_spins, composition, obj)
            
            if (obj < local_best_obj(1)) then
                local_best_obj(1) = obj
                local_best_spins(:, 1) = test_spins
            end if
        end do
        
        best_obj = local_best_obj(1)
        best_spins = local_best_spins(:, 1)
        
        best_objective = best_obj
        iterations = n_trials
        
        deallocate(local_best_spins, local_best_obj)
        
    end subroutine random_search_parallel
    
    !==========================================================================
    ! Simulated annealing
    !==========================================================================
    
    subroutine simulated_annealing_fast(natoms, n_B, T_start, T_end, &
                                        steps_per_T, cooling_rate, composition, &
                                        best_spins, best_objective, iterations) &
            bind(C, name="simulated_annealing_fast")
        integer(c_int), intent(in), value :: natoms, n_B, steps_per_T
        real(c_double), intent(in), value :: T_start, T_end, cooling_rate, composition
        integer(c_int), intent(out) :: best_spins(natoms)
        real(c_double), intent(out) :: best_objective
        integer(c_int), intent(out) :: iterations
        
        integer :: current_spins(natoms)
        integer :: step, i, j, idx, n_B_count, total_steps
        real(8) :: T, current_obj, new_obj, delta, accept_prob, rand_val
        real(8) :: best_obj
        logical :: accepted
        
        ! Generate initial random configuration with exact composition
        current_spins = -1
        n_B_count = 0
        do while (n_B_count < n_B)
            call random_number(rand_val)
            idx = mod(int(rand_val * 1000000), natoms) + 1
            if (current_spins(idx) == -1) then
                current_spins(idx) = 1
                n_B_count = n_B_count + 1
            end if
        end do
        
        call calculate_objective(natoms, current_spins, composition, current_obj)
        
        best_obj = current_obj
        best_spins = current_spins
        T = T_start
        total_steps = 0
        
        do while (T > T_end)
            do step = 1, steps_per_T
                ! Select two random different atoms with different spins
                call random_number(rand_val)
                i = mod(int(rand_val * 1000000), natoms) + 1
                call random_number(rand_val)
                j = mod(int(rand_val * 1000000), natoms) + 1
                
                do while (i == j .or. current_spins(i) == current_spins(j))
                    call random_number(rand_val)
                    j = mod(int(rand_val * 1000000), natoms) + 1
                end do
                
                ! Try swap
                current_spins(i) = -current_spins(i)
                current_spins(j) = -current_spins(j)
                
                call calculate_objective(natoms, current_spins, composition, new_obj)
                delta = new_obj - current_obj
                
                if (delta <= 0.0d0) then
                    current_obj = new_obj
                    accepted = .true.
                else
                    call random_number(accept_prob)
                    if (accept_prob < exp(-delta / T)) then
                        current_obj = new_obj
                        accepted = .true.
                    else
                        ! Revert swap
                        current_spins(i) = -current_spins(i)
                        current_spins(j) = -current_spins(j)
                        accepted = .false.
                    end if
                end if
                
                if (accepted .and. current_obj < best_obj) then
                    best_obj = current_obj
                    best_spins = current_spins
                end if
                
                total_steps = total_steps + 1
            end do
            
            T = T * cooling_rate
        end do
        
        best_objective = best_obj
        iterations = total_steps
        
    end subroutine simulated_annealing_fast
    
    !==========================================================================
    ! Get version info
    !==========================================================================
    
    subroutine get_version(version_str) bind(C, name="get_version")
        character(c_char), intent(out) :: version_str(*)
        character(len=50) :: ver
        integer :: i
        
        ver = 'SQS Fortran Engine v2.0.0' // c_null_char
        do i = 1, len_trim(ver)
            version_str(i) = ver(i:i)
        end do
    end subroutine get_version

end module sqs_engine