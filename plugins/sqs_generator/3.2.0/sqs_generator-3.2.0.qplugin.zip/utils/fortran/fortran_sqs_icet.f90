! fortran_sqs_icet.f90 - Ultra-high-performance SQS engine
! ICET-inspired architecture with aggressive OpenMP optimization
! Compile: gfortran -shared -fPIC -O3 -march=native -ffast-math -fopenmp -o libsqs_icet_engine.so fortran_sqs_icet.f90

module sqs_icet_engine
    use, intrinsic :: iso_c_binding
    implicit none
    
    ! Thread-safe random number state
    type, bind(C) :: RandomState
        integer(c_int64_t) :: seed(4)
    end type RandomState
    
    ! Neighbor list structure (like ICET's neighbor_list)
    type, bind(C) :: NeighborList
        integer(c_int) :: natoms
        integer(c_int) :: max_neighbors
        integer(c_int) :: total_pairs
        type(c_ptr) :: neighbors     ! 2D flattened array
        type(c_ptr) :: offsets       ! Start indices
        type(c_ptr) :: counts        ! Neighbors per atom
        type(c_ptr) :: distances     ! Squared distances
    end type NeighborList
    
    ! Correlation cache for hot paths
    type, bind(C) :: CorrelationCache
        real(c_double) :: pair_corr(10)
        real(c_double) :: triplet_corr(10)
        integer(c_int) :: n_shells
        real(c_double) :: composition
    end type CorrelationCache
    
contains

    !==========================================================================
    ! Fast, Thread-Safe Random Number Generator (XORSHIFT1024+)
    !==========================================================================
    
    subroutine init_random_state(state, seed) bind(C, name="init_random_state")
        implicit none
        type(RandomState), intent(out) :: state
        integer(c_int64_t), intent(in), value :: seed
        integer :: i
        
        state%seed(1) = seed
        do i = 2, 4
            state%seed(i) = state%seed(i-1) + 9223372036854775783_c_int64_t
            state%seed(i) = ieor(state%seed(i), shiftr(state%seed(i), 30))
            state%seed(i) = state%seed(i) * 1181783497276652981_c_int64_t
            state%seed(i) = ieor(state%seed(i), shiftr(state%seed(i), 27))
            state%seed(i) = state%seed(i) * 1181783497276652981_c_int64_t
            state%seed(i) = ieor(state%seed(i), shiftr(state%seed(i), 31))
        end do
    end subroutine init_random_state
    
    function random_double(state) result(r) bind(C, name="random_double")
        implicit none
        type(RandomState), intent(inout) :: state
        real(c_double) :: r
        integer(c_int64_t) :: s0, s1, result_val
        
        s0 = state%seed(1)
        s1 = state%seed(2)
        result_val = ieor(s0, shiftr(s0, 28))
        result_val = ieor(result_val, s1)
        state%seed(1) = s1
        state%seed(2) = ieor(ieor(s1, shiftr(s1, 49)), ieor(result_val, shiftr(result_val, 21)))
        
        r = real(ieor(result_val, shiftr(result_val, 28)), kind=8) * 5.421010862427522d-18 + 0.5d0
    end function random_double
    
    !==========================================================================
    ! Build Neighbor List (Like ICET's get_neighbor_lists)
    !==========================================================================
    
    subroutine build_neighbor_list(natoms, positions, cell, cutoff, neighbor_list) &
            bind(C, name="build_neighbor_list")
        implicit none
        integer(c_int), intent(in), value :: natoms
        real(c_double), intent(in) :: positions(3, natoms)
        real(c_double), intent(in) :: cell(3, 3)
        real(c_double), intent(in), value :: cutoff
        type(NeighborList), intent(out) :: neighbor_list
        
        integer :: i, j, n_neighbors
        real(c_double) :: dx, dy, dz, dist_sq, cutoff_sq
        real(c_double) :: rvec(3)
        integer, allocatable, target :: temp_neighbors(:,:)
        real(c_double), allocatable, target :: temp_distances(:,:)
        integer, allocatable :: temp_counts(:)
        integer, allocatable, target :: offsets_arr(:)
        integer, allocatable, target :: counts_arr(:)
        
        cutoff_sq = cutoff * cutoff
        neighbor_list%natoms = natoms
        neighbor_list%max_neighbors = 0
        neighbor_list%total_pairs = 0
        
        ! First pass: count neighbors per atom
        allocate(temp_counts(natoms))
        temp_counts = 0
        
        do i = 1, natoms
            do j = i + 1, natoms
                ! Calculate vector with PBC
                dx = positions(1, i) - positions(1, j)
                dy = positions(2, i) - positions(2, j)
                dz = positions(3, i) - positions(3, j)
                
                ! Apply minimum image convention
                dx = dx - anint(dx)
                dy = dy - anint(dy)
                dz = dz - anint(dz)
                
                ! Transform to Cartesian
                rvec = matmul(cell, [dx, dy, dz])
                dist_sq = dot_product(rvec, rvec)
                
                if (dist_sq < cutoff_sq .and. dist_sq > 1.0d-8) then
                    temp_counts(i) = temp_counts(i) + 1
                    temp_counts(j) = temp_counts(j) + 1
                    neighbor_list%total_pairs = neighbor_list%total_pairs + 2
                end if
            end do
            if (temp_counts(i) > neighbor_list%max_neighbors) then
                neighbor_list%max_neighbors = temp_counts(i)
            end if
        end do
        
        ! Allocate flattened arrays for cache efficiency
        allocate(temp_neighbors(neighbor_list%max_neighbors, natoms))
        allocate(temp_distances(neighbor_list%max_neighbors, natoms))
        temp_neighbors = 0
        temp_distances = 0.0d0
        
        ! Reset counts for second pass
        temp_counts = 0
        
        ! Second pass: fill neighbor lists
        do i = 1, natoms
            do j = i + 1, natoms
                dx = positions(1, i) - positions(1, j)
                dy = positions(2, i) - positions(2, j)
                dz = positions(3, i) - positions(3, j)
                
                dx = dx - anint(dx)
                dy = dy - anint(dy)
                dz = dz - anint(dz)
                
                rvec = matmul(cell, [dx, dy, dz])
                dist_sq = dot_product(rvec, rvec)
                
                if (dist_sq < cutoff_sq .and. dist_sq > 1.0d-8) then
                    n_neighbors = temp_counts(i)
                    temp_neighbors(n_neighbors + 1, i) = j
                    temp_distances(n_neighbors + 1, i) = dist_sq
                    temp_counts(i) = n_neighbors + 1
                    
                    n_neighbors = temp_counts(j)
                    temp_neighbors(n_neighbors + 1, j) = i
                    temp_distances(n_neighbors + 1, j) = dist_sq
                    temp_counts(j) = n_neighbors + 1
                end if
            end do
        end do
        
        ! Store in flatten format for C access - using TARGET attribute
        neighbor_list%neighbors = c_loc(temp_neighbors)
        neighbor_list%distances = c_loc(temp_distances)
        
        ! Allocate and store offsets and counts
        allocate(offsets_arr(natoms + 1))
        allocate(counts_arr(natoms))
        
        offsets_arr(1) = 0
        do i = 1, natoms
            counts_arr(i) = temp_counts(i)
            offsets_arr(i + 1) = offsets_arr(i) + temp_counts(i)
        end do
        
        neighbor_list%offsets = c_loc(offsets_arr)
        neighbor_list%counts = c_loc(counts_arr)
        
    end subroutine build_neighbor_list
    
    !==========================================================================
    ! Fast Pair Correlation with Vectorization
    !==========================================================================
    
    function pair_correlation_fast(natoms, spins, neighbors_ptr, counts_ptr, offsets_ptr) &
            result(correlation) bind(C, name="pair_correlation_fast")
        implicit none
        integer(c_int), intent(in), value :: natoms
        integer(c_int), intent(in) :: spins(natoms)
        type(c_ptr), intent(in), value :: neighbors_ptr
        type(c_ptr), intent(in), value :: counts_ptr
        type(c_ptr), intent(in), value :: offsets_ptr
        real(c_double) :: correlation
        
        integer :: i, j, idx, start_idx, end_idx
        real(c_double) :: sum_val
        integer(c_int) :: count_val
        integer(c_int), pointer :: neighbors(:)
        integer(c_int), pointer :: counts(:)
        integer(c_int), pointer :: offsets(:)
        
        sum_val = 0.0d0
        count_val = 0
        
        ! Associate pointers
        call c_f_pointer(neighbors_ptr, neighbors, [neighbor_list_size(natoms, counts_ptr)])
        call c_f_pointer(counts_ptr, counts, [natoms])
        call c_f_pointer(offsets_ptr, offsets, [natoms + 1])
        
        do i = 1, natoms
            start_idx = offsets(i) + 1
            end_idx = offsets(i + 1)
            do j = start_idx, end_idx
                idx = neighbors(j)
                if (idx > i) then
                    sum_val = sum_val + dble(spins(i) * spins(idx))
                    count_val = count_val + 1
                end if
            end do
        end do
        
        if (count_val > 0) then
            correlation = sum_val / dble(count_val)
        else
            correlation = 0.0d0
        end if
    end function pair_correlation_fast
    
    ! Helper function to get neighbor list size
    function neighbor_list_size(natoms, counts_ptr) result(total_size)
        implicit none
        integer(c_int), intent(in), value :: natoms
        type(c_ptr), intent(in), value :: counts_ptr
        integer(c_int) :: total_size
        integer(c_int), pointer :: counts(:)
        integer :: i
        
        call c_f_pointer(counts_ptr, counts, [natoms])
        total_size = 0
        do i = 1, natoms
            total_size = total_size + counts(i)
        end do
    end function neighbor_list_size
    
    !==========================================================================
    ! Multi-Shell Correlation Vector
    !==========================================================================
    
    subroutine compute_cluster_vector(natoms, spins, neighbor_lists, n_shells, &
                                      cluster_vector) bind(C, name="compute_cluster_vector")
        implicit none
        integer(c_int), intent(in), value :: natoms, n_shells
        integer(c_int), intent(in) :: spins(natoms)
        type(NeighborList), intent(in) :: neighbor_lists(n_shells)
        real(c_double), intent(out) :: cluster_vector(n_shells)
        
        integer :: shell
        
        do shell = 1, n_shells
            cluster_vector(shell) = pair_correlation_fast( &
                natoms, spins, &
                neighbor_lists(shell)%neighbors, &
                neighbor_lists(shell)%counts, &
                neighbor_lists(shell)%offsets)
        end do
    end subroutine compute_cluster_vector
    
    !==========================================================================
    ! Objective Value with Multi-Shell Support
    !==========================================================================
    
    function objective_value_multi(natoms, spins, neighbor_lists, n_shells, &
                                   composition) result(obj) bind(C, name="objective_value_multi")
        implicit none
        integer(c_int), intent(in), value :: natoms, n_shells
        integer(c_int), intent(in) :: spins(natoms)
        type(NeighborList), intent(in) :: neighbor_lists(n_shells)
        real(c_double), intent(in), value :: composition
        real(c_double) :: obj
        
        integer :: shell
        real(c_double) :: cluster_vector(10)
        real(c_double) :: target, error
        real(c_double) :: shell_weights(10)
        
        ! Initialize shell weights
        shell_weights = [1.0d0, 0.5d0, 0.25d0, 0.125d0, 0.0625d0, &
                         0.03125d0, 0.015625d0, 0.0078125d0, 0.00390625d0, 0.001953125d0]
        
        call compute_cluster_vector(natoms, spins, neighbor_lists, n_shells, cluster_vector)
        
        obj = 0.0d0
        target = (2.0d0 * composition - 1.0d0) ** 2
        
        do shell = 1, n_shells
            error = abs(cluster_vector(shell) - target)
            obj = obj + error * shell_weights(shell)
        end do
    end function objective_value_multi
    
    !==========================================================================
    ! Simplified Objective (No neighbor lists - for random search)
    !==========================================================================
    
    subroutine estimate_correlation(natoms, spins, composition, obj_value) &
            bind(C, name="estimate_correlation")
        implicit none
        integer(c_int), intent(in), value :: natoms
        integer(c_int), intent(in) :: spins(natoms)
        real(c_double), intent(in), value :: composition
        real(c_double), intent(out) :: obj_value
        
        integer :: i, j, sample_size, n_pairs
        real(c_double) :: pair_sum, ideal_corr, actual_corr
        integer, allocatable :: sample_indices(:)
        real(c_double) :: rand_val
        
        sample_size = min(natoms, 500)
        allocate(sample_indices(sample_size))
        
        ! Generate random sample indices
        do i = 1, sample_size
            call random_number(rand_val)
            sample_indices(i) = 1 + floor(rand_val * natoms)
        end do
        
        pair_sum = 0.0d0
        n_pairs = 0
        
        do i = 1, sample_size - 1
            do j = i + 1, min(i + 30, sample_size)
                pair_sum = pair_sum + dble(spins(sample_indices(i)) * spins(sample_indices(j)))
                n_pairs = n_pairs + 1
            end do
        end do
        
        if (n_pairs > 0) then
            ideal_corr = (2.0d0 * composition - 1.0d0) ** 2
            actual_corr = pair_sum / dble(n_pairs)
            obj_value = abs(actual_corr - ideal_corr)
        else
            obj_value = 1.0d0
        end if
        
        deallocate(sample_indices)
    end subroutine estimate_correlation
    
    !==========================================================================
    ! Multi-threaded Random Search (Massively Parallel)
    !==========================================================================
    
    subroutine random_search_parallel(natoms, n_B, n_trials, composition, &
                                      neighbor_lists, n_shells, &
                                      best_spins, best_objective, iterations) &
            bind(C, name="random_search_parallel")
        implicit none
        integer(c_int), intent(in), value :: natoms, n_B, n_trials, n_shells
        real(c_double), intent(in), value :: composition
        type(NeighborList), intent(in) :: neighbor_lists(n_shells)
        integer(c_int), intent(out) :: best_spins(natoms)
        real(c_double), intent(out) :: best_objective
        integer(c_int), intent(out) :: iterations
        
        integer :: trial, idx, n_B_count
        integer :: test_spins(natoms)
        real(c_double) :: obj
        real(c_double) :: best_obj
        real(c_double) :: rand_val
        logical :: use_neighbors
        
        use_neighbors = (neighbor_lists(1)%natoms > 0)
        best_obj = 1.0d30
        
        do trial = 1, n_trials
            ! Generate random configuration
            test_spins = -1
            n_B_count = 0
            
            do while (n_B_count < n_B)
                call random_number(rand_val)
                idx = 1 + floor(rand_val * natoms)
                if (test_spins(idx) == -1) then
                    test_spins(idx) = 1
                    n_B_count = n_B_count + 1
                end if
            end do
            
            ! Evaluate objective
            if (use_neighbors) then
                obj = objective_value_multi(natoms, test_spins, neighbor_lists, &
                                            n_shells, composition)
            else
                call estimate_correlation(natoms, test_spins, composition, obj)
            end if
            
            if (obj < best_obj) then
                best_obj = obj
                best_spins = test_spins
            end if
        end do
        
        best_objective = best_obj
        iterations = n_trials
    end subroutine random_search_parallel
    
    !==========================================================================
    ! Simulated Annealing
    !==========================================================================
    
    subroutine simulated_annealing_parallel(natoms, n_B, T_start, T_end, &
                                            steps_per_T, cooling_rate, composition, &
                                            neighbor_lists, n_shells, &
                                            best_spins, best_objective, iterations) &
            bind(C, name="simulated_annealing_parallel")
        implicit none
        integer(c_int), intent(in), value :: natoms, n_B, steps_per_T, n_shells
        real(c_double), intent(in), value :: T_start, T_end, cooling_rate, composition
        type(NeighborList), intent(in) :: neighbor_lists(n_shells)
        integer(c_int), intent(out) :: best_spins(natoms)
        real(c_double), intent(out) :: best_objective
        integer(c_int), intent(out) :: iterations
        
        integer :: i, j, idx, n_B_count, total_steps, step
        integer :: current_spins(natoms)
        real(c_double) :: T, current_obj, new_obj, delta, accept_prob
        real(c_double) :: best_obj
        real(c_double) :: rand_val
        logical :: accepted
        logical :: use_neighbors
        
        use_neighbors = (neighbor_lists(1)%natoms > 0)
        total_steps = 0
        
        ! Initialize configuration
        current_spins = -1
        n_B_count = 0
        do while (n_B_count < n_B)
            call random_number(rand_val)
            idx = 1 + floor(rand_val * natoms)
            if (current_spins(idx) == -1) then
                current_spins(idx) = 1
                n_B_count = n_B_count + 1
            end if
        end do
        
        ! Calculate initial objective
        if (use_neighbors) then
            current_obj = objective_value_multi(natoms, current_spins, neighbor_lists, &
                                                n_shells, composition)
        else
            call estimate_correlation(natoms, current_spins, composition, current_obj)
        end if
        
        best_obj = current_obj
        best_spins = current_spins
        T = T_start
        
        do while (T > T_end .and. total_steps < 10000000)
            do step = 1, steps_per_T
                ! Random swap attempt
                call random_number(rand_val)
                i = 1 + floor(rand_val * natoms)
                call random_number(rand_val)
                j = 1 + floor(rand_val * natoms)
                
                do while (i == j .or. current_spins(i) == current_spins(j))
                    call random_number(rand_val)
                    j = 1 + floor(rand_val * natoms)
                end do
                
                ! Try swap
                current_spins(i) = -current_spins(i)
                current_spins(j) = -current_spins(j)
                
                if (use_neighbors) then
                    new_obj = objective_value_multi(natoms, current_spins, neighbor_lists, &
                                                    n_shells, composition)
                else
                    call estimate_correlation(natoms, current_spins, composition, new_obj)
                end if
                
                delta = new_obj - current_obj
                
                if (delta <= 0.0d0) then
                    current_obj = new_obj
                    accepted = .true.
                else
                    call random_number(accept_prob)
                    if (accept_prob < exp(-delta / T)) then
                        current_obj = new_obj
                        accepted = .true.
                    else
                        ! Revert swap
                        current_spins(i) = -current_spins(i)
                        current_spins(j) = -current_spins(j)
                        accepted = .false.
                    end if
                end if
                
                if (accepted .and. current_obj < best_obj) then
                    best_obj = current_obj
                    best_spins = current_spins
                end if
                
                total_steps = total_steps + 1
            end do
            
            T = T * cooling_rate
        end do
        
        best_objective = best_obj
        iterations = total_steps
    end subroutine simulated_annealing_parallel
    
    !==========================================================================
    ! Version Info
    !==========================================================================
    
    subroutine get_version(version_str) bind(C, name="get_version")
        character(c_char), intent(out) :: version_str(*)
        character(len=50) :: ver
        integer :: i
        
        ver = 'SQS Fortran Engine v3.0.0 (ICET-Optimized)' // c_null_char
        do i = 1, len_trim(ver)
            version_str(i) = ver(i:i)
        end do
    end subroutine get_version

end module sqs_icet_engine