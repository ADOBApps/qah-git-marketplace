-- ffi_sqs_engine.lua - High-performance SQS using LuaJIT FFI

local ffi = require("ffi")

-- Define C data structures for maximum performance
ffi.cdef([[
    typedef struct {
        int* indices;
        int count;
    } NeighborList;
    
    typedef struct {
        double* data;
        int size;
    } DoubleArray;
]])

local SQS = {}

-- Cache frequently used globals for performance (avoid _G lookups)
local math_random = math.random
local math_min = math.min
local math_abs = math.abs
local math_exp = math.exp
local math_huge = math.huge
local type = type
local tonumber = tonumber

-- Pre-allocate a reusable index array using FFI for faster shuffles
local ffi_new = ffi.new
local ffi_cast = ffi.cast
local ffi_copy = ffi.copy
local ffi_fill = ffi.fill
local int_ptr_t = ffi.typeof("int*")
local double_ptr_t = ffi.typeof("double*")

-- Allocate reusable shuffle array (resized as needed)
local shuffle_indices = ffi.new("int[?]", 1)
local max_allocated = 0

-- Resize shuffle array if needed
local function ensure_shuffle_array(size)
    if size > max_allocated then
        shuffle_indices = ffi.new("int[?]", size)
        max_allocated = size
        for i = 0, size - 1 do
            shuffle_indices[i] = i + 1  -- 1-based indexing
        end
    end
end

-- FFI-based Fisher-Yates shuffle (operates in-place on int array)
local function ffi_shuffle(arr, n)
    for i = n - 1, 1, -1 do
        local j = math_random(i + 1) - 1  -- Convert to 0-based
        local temp = arr[i]
        arr[i] = arr[j]
        arr[j] = temp
    end
end

-- Fast pair correlation using FFI arrays
-- Now accepts FFI double arrays for spins and pre-computed neighbor data
function SQS.pair_correlation_ffi(spins_cdata, neighbors_cdata, n_neighbors_cdata, natoms)
    -- FFI native arrays - direct memory access, no Lua table overhead
    local sum = 0.0
    local count = 0
    
    if neighbors_cdata == nil or n_neighbors_cdata == nil then
        return 0.0
    end
    
    -- Direct C-array access - fully JIT-compilable
    for i = 0, natoms - 1 do  -- 0-based indexing for FFI
        local n = n_neighbors_cdata[i]
        if n > 0 then
            -- neighbors stored as flat array: offsets + indices
            local offset = natoms * i  -- Each atom has natoms potential neighbors
            for j = 0, n - 1 do
                local idx = neighbors_cdata[offset + j] - 1  -- Convert to 0-based
                if idx > i then  -- Count each pair once
                    sum = sum + spins_cdata[i] * spins_cdata[idx]
                    count = count + 1
                end
            end
        end
    end
    
    if count == 0 then return 0.0 end
    return sum / count
end

-- Pair correlation with Lua tables (improved for performance)
function SQS.pair_correlation(spins, neighbors, n_neighbors, natoms)
    local sum = 0.0
    local count = 0
    
    if not neighbors or not n_neighbors then
        return 0.0
    end
    
    -- Localize globals for speed
    local ttype = type
    
    for i = 1, natoms do
        local n = n_neighbors[i]
        if n and n > 0 then
            local neighbor_list = neighbors[i]
            if neighbor_list and ttype(neighbor_list) == 'table' then
                for j = 1, n do
                    local idx = neighbor_list[j]
                    if idx and idx > i then
                        local s_i = spins[i]
                        local s_j = spins[idx]
                        if s_i and s_j then
                            sum = sum + s_i * s_j
                            count = count + 1
                        end
                    end
                end
            end
        end
    end
    
    if count == 0 then return 0.0 end
    return sum / count
end

-- Objective function with JIT compilation
function SQS.objective_function(spins, neighbors, n_neighbors, natoms, n_shells, composition)
    local comp = tonumber(composition) or 0.5
    local corr = SQS.pair_correlation(spins, neighbors, n_neighbors, natoms)
    local target_corr = (2.0 * comp - 1.0) ^ 2
    return math_abs(corr - target_corr)
end

-- Objective function using FFI arrays (maximum performance)
function SQS.objective_function_ffi(spins_cdata, neighbors_cdata, n_neighbors_cdata, natoms, composition)
    local comp = tonumber(composition) or 0.5
    local corr = SQS.pair_correlation_ffi(spins_cdata, neighbors_cdata, n_neighbors_cdata, natoms)
    local target_corr = (2.0 * comp - 1.0) ^ 2
    return math_abs(corr - target_corr)
end

-- Simplified objective for random search (no neighbor lists)
function SQS.objective_function_simple(spins, natoms, composition)
    local comp = tonumber(composition) or 0.5
    
    -- Use FFI array for faster shuffling
    local sample_size = math_min(natoms, 200)
    ensure_shuffle_array(natoms)
    
    -- Initialize shuffle array (copy pre-initialized values)
    for i = 0, natoms - 1 do
        shuffle_indices[i] = i + 1
    end
    ffi_shuffle(shuffle_indices, natoms)
    
    local pair_sum = 0.0
    local n_pairs = 0
    
    -- Sample pairs using FFI array indices
    for i = 0, sample_size - 2 do
        local idx_i = shuffle_indices[i]
        local s_i = spins[idx_i]
        if s_i then
            local max_j = math_min(i + 15, sample_size - 1)
            for j = i + 1, max_j do
                local idx_j = shuffle_indices[j]
                local s_j = spins[idx_j]
                if s_j then
                    pair_sum = pair_sum + s_i * s_j
                    n_pairs = n_pairs + 1
                end
            end
        end
    end
    
    if n_pairs == 0 then return 1.0 end
    
    local target_corr = (2.0 * comp - 1.0) ^ 2
    local actual_corr = pair_sum / n_pairs
    return math_abs(actual_corr - target_corr)
end

-- Utility function to convert Lua table to FFI double array
function SQS.table_to_ffi_double(tbl, size)
    local arr = ffi_new("double[?]", size)
    for i = 1, size do
        arr[i-1] = tbl[i] or 0.0
    end
    return arr
end

-- Utility function to convert FFI double array back to Lua table
function SQS.ffi_double_to_table(arr, size)
    local tbl = {}
    for i = 0, size - 1 do
        tbl[i+1] = arr[i]
    end
    return tbl
end

-- Fast Metropolis step
function SQS.metropolis_step(spins, neighbors, n_neighbors, natoms, temp, current_obj, composition)
    local comp = tonumber(composition) or 0.5
    
    -- Select two random different atoms with different spins
    local i = math_random(natoms)
    local j = math_random(natoms)
    
    -- Avoid infinite loop by ensuring we find different spins
    local max_attempts = natoms * 2
    local attempts = 0
    while (i == j or spins[i] == spins[j]) and attempts < max_attempts do
        i = math_random(natoms)
        j = math_random(natoms)
        attempts = attempts + 1
    end
    
    if i == j or spins[i] == spins[j] then
        return current_obj, false  -- Can't find valid pair
    end
    
    -- Try swap
    local si, sj = spins[i], spins[j]
    spins[i], spins[j] = sj, si
    
    -- Calculate new objective
    local new_obj = SQS.objective_function(spins, neighbors, n_neighbors, natoms, 4, comp)
    local delta = new_obj - current_obj
    
    if delta <= 0.0 then
        return new_obj, true
    else
        local accept_prob = math_exp(-delta / temp)
        if math_random() < accept_prob then
            return new_obj, true
        else
            -- Revert
            spins[i], spins[j] = si, sj
            return current_obj, false
        end
    end
end

-- Simulated annealing with optional FFI optimization
function SQS.simulated_annealing(natoms, n_B, T_start, T_end, steps_per_T, cooling_rate, composition)
    local comp = tonumber(composition) or 0.5
    
    -- Initialize with correct composition
    local spins = {}
    for i = 1, natoms do
        spins[i] = -1.0
    end
    
    local n_B_count = 0
    while n_B_count < n_B do
        local idx = math_random(natoms)
        if spins[idx] == -1.0 then
            spins[idx] = 1.0
            n_B_count = n_B_count + 1
        end
    end
    
    -- Get neighbor data if available
    local neighbors = _G["sqs_neighbors"]
    local n_neighbors = _G["sqs_n_neighbors"]
    local has_neighbors = false
    
    if neighbors and n_neighbors and type(neighbors) == 'table' and type(n_neighbors) == 'table' then
        if neighbors[1] and n_neighbors[1] then
            if n_neighbors[1] > 0 then
                has_neighbors = true
            end
        end
    end
    
    -- Try to use FFI if neighbor data is available as FFI arrays
    local use_ffi = false
    local spins_cdata = nil
    local neighbors_cdata = _G["sqs_neighbors_cdata"]
    local n_neighbors_cdata = _G["sqs_n_neighbors_cdata"]
    
    if neighbors_cdata and n_neighbors_cdata then
        use_ffi = true
        spins_cdata = ffi_new("double[?]", natoms)
        for i = 1, natoms do
            spins_cdata[i-1] = spins[i]
        end
    end
    
    local T = T_start
    local best_spins = {}
    for i = 1, natoms do best_spins[i] = spins[i] end
    
    local best_obj
    if use_ffi then
        best_obj = SQS.objective_function_ffi(spins_cdata, neighbors_cdata, n_neighbors_cdata, natoms, comp)
    elseif has_neighbors then
        best_obj = SQS.objective_function(spins, neighbors, n_neighbors, natoms, 4, comp)
    else
        best_obj = SQS.objective_function_simple(spins, natoms, comp)
    end
    
    local current_obj = best_obj
    local total_steps = 0
    
    while T > T_end do
        for step = 1, steps_per_T do
            local accepted
            if has_neighbors then
                if use_ffi then
                    -- FFI-based Metropolis step
                    local i = math_random(natoms) - 1  -- 0-based
                    local j = math_random(natoms) - 1
                    
                    local attempts = 0
                    while (i == j or spins_cdata[i] == spins_cdata[j]) and attempts < natoms * 2 do
                        i = math_random(natoms) - 1
                        j = math_random(natoms) - 1
                        attempts = attempts + 1
                    end
                    
                    if i ~= j and spins_cdata[i] ~= spins_cdata[j] then
                        -- Swap in FFI array
                        local temp = spins_cdata[i]
                        spins_cdata[i] = spins_cdata[j]
                        spins_cdata[j] = temp
                        
                        local new_obj = SQS.objective_function_ffi(spins_cdata, neighbors_cdata, n_neighbors_cdata, natoms, comp)
                        local delta = new_obj - current_obj
                        
                        if delta <= 0.0 or math_random() < math_exp(-delta / T) then
                            current_obj = new_obj
                            accepted = true
                        else
                            -- Revert
                            spins_cdata[j] = spins_cdata[i]
                            spins_cdata[i] = temp
                            accepted = false
                        end
                    else
                        accepted = false
                    end
                else
                    current_obj, accepted = SQS.metropolis_step(spins, neighbors, n_neighbors, natoms, T, current_obj, comp)
                end
            else
                -- Simple Metropolis without neighbor lists
                local i = math_random(natoms)
                local j = math_random(natoms)
                local attempts = 0
                while (i == j or spins[i] == spins[j]) and attempts < natoms * 2 do
                    i = math_random(natoms)
                    j = math_random(natoms)
                    attempts = attempts + 1
                end
                
                if i ~= j and spins[i] ~= spins[j] then
                    spins[i], spins[j] = spins[j], spins[i]
                    local new_obj = SQS.objective_function_simple(spins, natoms, comp)
                    local delta = new_obj - current_obj
                    
                    if delta <= 0.0 or math_random() < math_exp(-delta / T) then
                        current_obj = new_obj
                        accepted = true
                    else
                        spins[i], spins[j] = spins[j], spins[i]
                        accepted = false
                    end
                else
                    accepted = false
                end
            end
            
            if current_obj < best_obj then
                best_obj = current_obj
                if use_ffi then
                    for i = 0, natoms - 1 do
                        best_spins[i+1] = spins_cdata[i]
                    end
                else
                    for i = 1, natoms do
                        best_spins[i] = spins[i]
                    end
                end
            end
            
            total_steps = total_steps + 1
        end
        
        T = T * cooling_rate
    end
    
    -- If using FFI, sync best spins back to table
    if use_ffi and best_spins then
        for i = 0, natoms - 1 do
            best_spins[i+1] = spins_cdata[i]
        end
    end
    
    return best_spins, best_obj, total_steps
end

-- Fast random search with FFI optimization
function SQS.random_search(natoms, n_B, n_trials, composition)
    local comp = tonumber(composition) or 0.5
    local best_spins = nil
    local best_obj = math_huge
    
    -- Check for FFI neighbor data
    local neighbors_cdata = _G["sqs_neighbors_cdata"]
    local n_neighbors_cdata = _G["sqs_n_neighbors_cdata"]
    local use_ffi = (neighbors_cdata ~= nil and n_neighbors_cdata ~= nil)
    
    -- Check for table neighbor data
    local neighbors = _G["sqs_neighbors"]
    local n_neighbors = _G["sqs_n_neighbors"]
    local has_neighbors = false
    
    if neighbors and n_neighbors and type(neighbors) == 'table' and type(n_neighbors) == 'table' then
        if neighbors[1] and n_neighbors[1] and n_neighbors[1] > 0 then
            has_neighbors = true
        end
    end
    
    -- Pre-allocate test spins FFI array if using FFI
    local test_spins_cdata = nil
    if use_ffi then
        test_spins_cdata = ffi_new("double[?]", natoms)
    end
    
    for trial = 1, n_trials do
        -- Generate random configuration
        local test_spins = {}
        for i = 1, natoms do
            test_spins[i] = -1.0
        end
        
        local n_B_count = 0
        while n_B_count < n_B do
            local idx = math_random(natoms)
            if test_spins[idx] == -1.0 then
                test_spins[idx] = 1.0
                n_B_count = n_B_count + 1
            end
        end
        
        local obj
        if use_ffi then
            -- Copy to FFI array
            for i = 0, natoms - 1 do
                test_spins_cdata[i] = test_spins[i+1]
            end
            obj = SQS.objective_function_ffi(test_spins_cdata, neighbors_cdata, n_neighbors_cdata, natoms, comp)
        elseif has_neighbors then
            obj = SQS.objective_function(test_spins, neighbors, n_neighbors, natoms, 4, comp)
        else
            obj = SQS.objective_function_simple(test_spins, natoms, comp)
        end
        
        if obj < best_obj then
            best_obj = obj
            best_spins = test_spins
        end
    end
    
    return best_spins, best_obj, n_trials
end

-- Helper function to convert Python neighbor data to FFI arrays
function SQS.prepare_neighbors_ffi(neighbors_table, n_neighbors_table, natoms)
    -- Create flat neighbor array
    local max_neighbors = natoms  -- Assume worst case
    local neighbors_cdata = ffi_new("int[?]", natoms * max_neighbors)
    local n_neighbors_cdata = ffi_new("int[?]", natoms)
    
    -- Initialize with zeros
    ffi_fill(neighbors_cdata, ffi.sizeof("int") * natoms * max_neighbors, 0)
    
    for i = 1, natoms do
        local n = n_neighbors_table[i] or 0
        n_neighbors_cdata[i-1] = n
        if n > 0 then
            local neighbor_list = neighbors_table[i]
            if neighbor_list then
                local offset = (i-1) * max_neighbors
                for j = 1, math_min(n, max_neighbors) do
                    neighbors_cdata[offset + j - 1] = neighbor_list[j] or 0
                end
            end
        end
    end
    
    -- Store globally for access by other functions
    _G["sqs_neighbors_cdata"] = neighbors_cdata
    _G["sqs_n_neighbors_cdata"] = n_neighbors_cdata
    
    return neighbors_cdata, n_neighbors_cdata
end

-- Export functions as global for Python bridge
_G["sqs_random_search"] = SQS.random_search
_G["sqs_simulated_annealing"] = SQS.simulated_annealing
_G["sqs_objective_function"] = SQS.objective_function
_G["sqs_objective_function_simple"] = SQS.objective_function_simple
_G["sqs_prepare_neighbors_ffi"] = SQS.prepare_neighbors_ffi
_G["sqs_table_to_ffi_double"] = SQS.table_to_ffi_double
_G["sqs_ffi_double_to_table"] = SQS.ffi_double_to_table

return SQS