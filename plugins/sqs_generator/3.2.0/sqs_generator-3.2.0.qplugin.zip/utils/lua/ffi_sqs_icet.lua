-- High-performance SQS using LuaJIT FFI
-- Optimized based on ICET's architecture patterns

local ffi = require("ffi")

-- Define C data structures matching ICET's patterns
ffi.cdef([[
    typedef struct {
        int* data;
        int size;
    } IntArray;
    
    typedef struct {
        double* data;
        int size;
    } DoubleArray;
    
    typedef struct {
        int* indices;
        int* offsets;
        int n_atoms;
        int max_neighbors;
    } NeighborList;
    
    typedef struct {
        double* spins;
        int size;
    } SpinVector;
]])

local SQS = {}

-- Cache frequently used globals
local math_random = math.random
local math_min = math.min
local math_abs = math.abs
local math_exp = math.exp
local math_huge = math.huge
local math_log = math.log
local math_sqrt = math.sqrt
local table_insert = table.insert
local table_sort = table.sort
local type = type
local tonumber = tonumber
local ffi_new = ffi.new
local ffi_fill = ffi.fill
local ffi_copy = ffi.copy

-- ============================================================================
-- Data Structures (Inspired by ICET)
-- ============================================================================

-- Structure to hold neighbor information (like ICET's neighbor_list)
local NeighborList = ffi.typeof([[struct {
    int* neighbors;      -- Flat array of neighbor indices
    int* offsets;        -- Start indices for each atom
    int* counts;         -- Number of neighbors per atom
    int n_atoms;
    int total_neighbors;
}]])

-- Structure to hold correlation function state
local CorrelationState = ffi.typeof([[struct {
    double* pair_correlations;
    double* triplet_correlations;
    int n_shells;
    double composition;
}]])

-- ============================================================================
-- Memory Management (Reusable buffers - like ICET's pre-allocation)
-- ============================================================================

local reusable_buffers = {
    int_buffer = nil,
    double_buffer = nil,
    shuffle_buffer = nil,
    spins_buffer = nil
}

-- Reusable integer buffer
local function get_int_buffer(size)
    if not reusable_buffers.int_buffer or reusable_buffers.int_buffer_size < size then
        reusable_buffers.int_buffer = ffi_new("int[?]", size)
        reusable_buffers.int_buffer_size = size
    end
    return reusable_buffers.int_buffer
end

-- Reusable double buffer
local function get_double_buffer(size)
    if not reusable_buffers.double_buffer or reusable_buffers.double_buffer_size < size then
        reusable_buffers.double_buffer = ffi_new("double[?]", size)
        reusable_buffers.double_buffer_size = size
    end
    return reusable_buffers.double_buffer
end

-- ============================================================================
-- Neighbor List Construction (Like ICET's get_neighbor_lists)
-- ============================================================================

-- Build neighbor list from positions (like ICET's approach)
function SQS.build_neighbor_list(positions, cell, cutoff, natoms)
    -- Pre-calculate cell metrics
    local cell_matrix = ffi_new("double[3][3]")
    for i = 0, 2 do
        for j = 0, 2 do
            cell_matrix[i][j] = cell[i+1][j+1] or (i == j and 1.0 or 0.0)
        end
    end
    
    -- Calculate maximum possible neighbors
    local max_neighbors = math_min(natoms * 12, natoms - 1)
    local neighbors_flat = ffi_new("int[?]", natoms * max_neighbors)
    local offsets = ffi_new("int[?]", natoms + 1)
    local counts = ffi_new("int[?]", natoms)
    
    ffi_fill(neighbors_flat, ffi.sizeof("int") * natoms * max_neighbors, 0)
    ffi_fill(offsets, ffi.sizeof("int") * (natoms + 1), 0)
    ffi_fill(counts, ffi.sizeof("int") * natoms, 0)
    
    -- Build neighbor list (SIMD-friendly loop)
    local cutoff_sq = cutoff * cutoff
    local total_neighbors = 0
    
    for i = 0, natoms - 1 do
        offsets[i] = total_neighbors
        local px = positions[i+1][1]
        local py = positions[i+1][2]
        local pz = positions[i+1][3]
        
        for j = i + 1, natoms - 1 do
            -- Calculate distance squared with periodic boundary conditions
            local dx = px - positions[j+1][1]
            local dy = py - positions[j+1][2]
            local dz = pz - positions[j+1][3]
            
            -- Apply minimum image convention
            dx = dx - math_floor(dx + 0.5)
            dy = dy - math_floor(dy + 0.5)
            dz = dz - math_floor(dz + 0.5)
            
            -- Transform to Cartesian
            local rx = dx * cell_matrix[0][0] + dy * cell_matrix[0][1] + dz * cell_matrix[0][2]
            local ry = dx * cell_matrix[1][0] + dy * cell_matrix[1][1] + dz * cell_matrix[1][2]
            local rz = dx * cell_matrix[2][0] + dy * cell_matrix[2][1] + dz * cell_matrix[2][2]
            
            local dist_sq = rx*rx + ry*ry + rz*rz
            
            if dist_sq < cutoff_sq and dist_sq > 1e-8 then
                neighbors_flat[total_neighbors] = j + 1  -- 1-based indexing
                total_neighbors = total_neighbors + 1
                neighbors_flat[total_neighbors] = i + 1
                total_neighbors = total_neighbors + 1
                counts[i] = counts[i] + 1
                counts[j] = counts[j] + 1
            end
        end
    end
    offsets[natoms] = total_neighbors
    
    local neighbor_list = NeighborList()
    neighbor_list.neighbors = neighbors_flat
    neighbor_list.offsets = offsets
    neighbor_list.counts = counts
    neighbor_list.n_atoms = natoms
    neighbor_list.total_neighbors = total_neighbors
    
    return neighbor_list
end

-- ============================================================================
-- Fast Correlation Functions (Like ICET's cluster_vector)
-- ============================================================================

-- Fast pair correlation using flattened neighbor list (cache-friendly)
local function pair_correlation_fast(spins, neighbors, natoms)
    local sum = 0.0
    local count = 0
    
    local neighbors_ptr = neighbors.neighbors
    local offsets_ptr = neighbors.offsets
    local counts_ptr = neighbors.counts
    
    -- Direct memory access - fully JIT-compilable
    for i = 0, natoms - 1 do
        local n = counts_ptr[i]
        if n > 0 then
            local start = offsets_ptr[i]
            local end_idx = start + n - 1
            local si = spins[i]
            for j = start, end_idx do
                local idx = neighbors_ptr[j] - 1  -- Convert to 0-based
                if idx > i then  -- Count each pair once
                    sum = sum + si * spins[idx]
                    count = count + 1
                end
            end
        end
    end
    
    if count > 0 then
        return sum / count
    end
    return 0.0
end

-- Multi-shell pair correlations (like ICET's get_cluster_vector)
function SQS.compute_cluster_vector(spins, neighbor_lists, natoms, n_shells)
    local cluster_vector = ffi_new("double[?]", n_shells)
    ffi_fill(cluster_vector, ffi.sizeof("double") * n_shells, 0)
    
    for shell = 1, n_shells do
        local neighbors = neighbor_lists[shell]
        if neighbors then
            cluster_vector[shell - 1] = pair_correlation_fast(spins, neighbors, natoms)
        end
    end
    
    return cluster_vector
end

-- Objective value (like ICET's objective_function)
function SQS.objective_value(spins, neighbors, natoms, composition, n_shells)
    local comp = tonumber(composition) or 0.5
    
    if neighbors then
        -- Use neighbor list for accurate correlations
        local corr = pair_correlation_fast(spins, neighbors, natoms)
        local target_corr = (2.0 * comp - 1.0) ^ 2
        return math_abs(corr - target_corr)
    else
        -- Simplified estimation for random search
        return SQS.estimate_correlation_error(spins, natoms, comp)
    end
end

-- Fast correlation estimation for random search (no neighbor lists needed)
function SQS.estimate_correlation_error(spins, natoms, composition)
    -- Sample-based estimation using Rejection sampling
    local sample_size = math_min(natoms, 500)
    local shuffle_buffer = get_int_buffer(natoms)
    
    -- Initialize shuffle indices
    for i = 0, natoms - 1 do
        shuffle_buffer[i] = i + 1
    end
    
    -- Fisher-Yates shuffle
    for i = natoms - 1, 1, -1 do
        local j = math_random(i + 1) - 1
        shuffle_buffer[i], shuffle_buffer[j] = shuffle_buffer[j], shuffle_buffer[i]
    end
    
    -- Calculate sampled correlation
    local pair_sum = 0.0
    local n_pairs = 0
    
    for i = 0, sample_size - 2 do
        local idx_i = shuffle_buffer[i] - 1
        local si = spins[idx_i]
        local max_j = math_min(i + 30, sample_size - 1)
        for j = i + 1, max_j do
            local idx_j = shuffle_buffer[j] - 1
            pair_sum = pair_sum + si * spins[idx_j]
            n_pairs = n_pairs + 1
        end
    end
    
    if n_pairs == 0 then
        return 1.0
    end
    
    local target_corr = (2.0 * composition - 1.0) ^ 2
    local actual_corr = pair_sum / n_pairs
    return math_abs(actual_corr - target_corr)
end

-- ============================================================================
-- Spin Configuration (Like ICET's Structure class)
-- ============================================================================

-- Create initial spin configuration with target composition
function SQS.create_initial_configuration(natoms, n_B)
    local spins = ffi_new("double[?]", natoms)
    ffi_fill(spins, ffi.sizeof("double") * natoms, 0)
    
    -- Set all to -1 initially
    for i = 0, natoms - 1 do
        spins[i] = -1.0
    end
    
    -- Randomly set n_B atoms to +1
    local n_placed = 0
    while n_placed < n_B do
        local idx = math_random(natoms) - 1
        if spins[idx] == -1.0 then
            spins[idx] = 1.0
            n_placed = n_placed + 1
        end
    end
    
    return spins
end

-- Copy spin configuration
local function copy_spins(source, dest, natoms)
    ffi_copy(dest, source, ffi.sizeof("double") * natoms)
end

-- ============================================================================
-- Monte Carlo Steps (Optimized like ICET's C++ implementation)
-- ============================================================================

-- Fast Metropolis step using FFI arrays
local function metropolis_step_fast(spins, neighbors, natoms, temp, current_obj, composition)
    -- Select two different atoms (ICET uses random site selection)
    local i = math_random(natoms) - 1
    local j = math_random(natoms) - 1
    
    -- Find different spins (limited attempts)
    local attempts = 0
    while (i == j or spins[i] == spins[j]) and attempts < natoms * 2 do
        i = math_random(natoms) - 1
        j = math_random(natoms) - 1
        attempts = attempts + 1
    end
    
    if i == j or spins[i] == spins[j] then
        return current_obj, false
    end
    
    -- Swap spins
    local si = spins[i]
    local sj = spins[j]
    spins[i] = sj
    spins[j] = si
    
    -- Calculate new objective
    local new_obj = SQS.objective_value(spins, neighbors, natoms, composition, 4)
    local delta = new_obj - current_obj
    
    if delta <= 0.0 then
        return new_obj, true
    else
        local accept_prob = math_exp(-delta / temp)
        if math_random() < accept_prob then
            return new_obj, true
        else
            -- Revert swap
            spins[i] = si
            spins[j] = sj
            return current_obj, false
        end
    end
end

-- ============================================================================
-- Main SQS Generation Functions
-- ============================================================================

-- Simulated Annealing (Like ICET's generate_sqs with annealing)
function SQS.simulated_annealing(natoms, n_B, T_start, T_end, steps_per_T, 
                                  cooling_rate, composition, neighbor_list)
    local comp = tonumber(composition) or 0.5
    local spins = SQS.create_initial_configuration(natoms, n_B)
    local best_spins = ffi_new("double[?]", natoms)
    copy_spins(spins, best_spins, natoms)
    
    -- Get or build neighbor list
    local neighbors = neighbor_list or _G["sqs_neighbor_list"]
    if not neighbors then
        -- Fallback to Lua table neighbors
        neighbors = _G["sqs_neighbors_table"]
    end
    
    local current_obj = SQS.objective_value(spins, neighbors, natoms, comp, 4)
    local best_obj = current_obj
    
    local T = T_start
    local total_accepts = 0
    local total_steps = 0
    
    if T_start <= 0 then
        T_start = 1.0
    end
    if steps_per_T <= 0 then
        steps_per_T = 1000
    end
    if cooling_rate <= 0 or cooling_rate > 1 then
        cooling_rate = 0.95
    end
    
    while T > T_end and total_steps < 10000000 do  -- Safety limit
        local step_accepts = 0
        
        for step = 1, steps_per_T do
            local new_obj, accepted = metropolis_step_fast(spins, neighbors, natoms, 
                                                            T, current_obj, comp)
            if accepted then
                current_obj = new_obj
                step_accepts = step_accepts + 1
                
                if current_obj < best_obj then
                    best_obj = current_obj
                    copy_spins(spins, best_spins, natoms)
                end
            end
            total_steps = total_steps + 1
        end
        
        total_accepts = total_accepts + step_accepts
        T = T * cooling_rate
    end
    
    -- Convert to Lua table for return
    local result_spins = {}
    for i = 0, natoms - 1 do
        result_spins[i+1] = best_spins[i]
    end
    
    return result_spins, best_obj, total_steps
end

-- Random Search (Like ICET's random trial generation)
function SQS.random_search(natoms, n_B, n_trials, composition)
    local comp = tonumber(composition) or 0.5
    local best_spins = nil
    local best_obj = math_huge
    
    -- Get neighbor list if available
    local neighbors = _G["sqs_neighbor_list"]
    local has_neighbors = (neighbors ~= nil)
    
    -- Reusable buffer for test configuration
    local test_spins = ffi_new("double[?]", natoms)
    
    for trial = 1, n_trials do
        -- Generate random configuration (like ICET's random structure generation)
        ffi_fill(test_spins, ffi.sizeof("double") * natoms, 0)
        for i = 0, natoms - 1 do
            test_spins[i] = -1.0
        end
        
        local n_placed = 0
        while n_placed < n_B do
            local idx = math_random(natoms) - 1
            if test_spins[idx] == -1.0 then
                test_spins[idx] = 1.0
                n_placed = n_placed + 1
            end
        end
        
        -- Evaluate objective
        local obj
        if has_neighbors then
            obj = SQS.objective_value(test_spins, neighbors, natoms, comp, 4)
        else
            obj = SQS.estimate_correlation_error(test_spins, natoms, comp)
        end
        
        if obj < best_obj then
            best_obj = obj
            -- Copy to Lua table for return
            best_spins = {}
            for i = 0, natoms - 1 do
                best_spins[i+1] = test_spins[i]
            end
        end
    end
    
    return best_spins, best_obj, n_trials
end

-- ============================================================================
-- Python Bridge Interface
-- ============================================================================

-- Convert Python neighbor tables to FFI neighbor list
function SQS.prepare_neighbor_list(neighbors_table, n_neighbors_table, natoms, cutoff)
    -- Build flat neighbor list structure
    local max_neighbors = 0
    for i = 1, natoms do
        local n = n_neighbors_table[i] or 0
        if n > max_neighbors then
            max_neighbors = n
        end
    end
    
    local neighbors_flat = ffi_new("int[?]", natoms * max_neighbors)
    local offsets = ffi_new("int[?]", natoms + 1)
    local counts = ffi_new("int[?]", natoms)
    
    ffi_fill(neighbors_flat, ffi.sizeof("int") * natoms * max_neighbors, 0)
    ffi_fill(offsets, ffi.sizeof("int") * (natoms + 1), 0)
    ffi_fill(counts, ffi.sizeof("int") * natoms, 0)
    
    local total = 0
    for i = 1, natoms do
        offsets[i-1] = total
        local n = n_neighbors_table[i] or 0
        counts[i-1] = n
        
        if n > 0 then
            local neighbor_list = neighbors_table[i]
            if neighbor_list then
                local offset = (i-1) * max_neighbors
                for j = 1, n do
                    neighbors_flat[offset + j - 1] = neighbor_list[j] or 0
                    total = total + 1
                end
            end
        end
    end
    offsets[natoms] = total
    
    local neighbor_list = NeighborList()
    neighbor_list.neighbors = neighbors_flat
    neighbor_list.offsets = offsets
    neighbor_list.counts = counts
    neighbor_list.n_atoms = natoms
    neighbor_list.total_neighbors = total
    
    -- Store globally
    _G["sqs_neighbor_list"] = neighbor_list
    
    return neighbor_list
end

-- Export functions for Python bridge
_G["sqs_random_search"] = SQS.random_search
_G["sqs_simulated_annealing"] = SQS.simulated_annealing
_G["sqs_build_neighbor_list"] = SQS.build_neighbor_list
_G["sqs_prepare_neighbor_list"] = SQS.prepare_neighbor_list
_G["sqs_compute_cluster_vector"] = SQS.compute_cluster_vector
_G["sqs_objective_value"] = SQS.objective_value

return SQS