-- lua_sqs_engine.lua - High-performance SQS using LuaJIT JIT compilation

local SQS = {}

-- Fast pair correlation using JIT compilation
function SQS.pair_correlation(spins, neighbors, n_neighbors, natoms)
    local sum = 0
    local count = 0
    
    -- FIX: Check if neighbors table exists and has data
    if not neighbors or not n_neighbors then
        return 0
    end
    
    -- LuaJIT JIT compiles this loop to machine code
    for i = 1, natoms do
        -- FIX: Check if n_neighbors[i] exists and is a number
        local n = n_neighbors[i]
        if n and type(n) == 'number' and n > 0 then
            local neighbor_list = neighbors[i]
            if neighbor_list and type(neighbor_list) == 'table' then
                for j = 1, n do
                    local idx = neighbor_list[j]
                    if idx and idx > i then  -- Count each pair once
                        local s_i = spins[i]
                        local s_j = spins[idx]
                        if s_i and s_j then
                            sum = sum + s_i * s_j
                            count = count + 1
                        end
                    end
                end
            end
        end
    end
    
    if count == 0 then return 0 end
    return sum / count
end

-- Objective function with JIT compilation
function SQS.objective_function(spins, neighbors, n_neighbors, natoms, n_shells, composition)
    -- Ensure composition is a number
    local comp = tonumber(composition) or 0.5
    
    -- Calculate pair correlations
    local corr = SQS.pair_correlation(spins, neighbors, n_neighbors, natoms)
    
    -- Target correlation for random alloy
    local target_corr = (2 * comp - 1) ^ 2
    
    -- Objective is absolute difference from target
    return math.abs(corr - target_corr)
end

-- Simplified objective for random search (no neighbor lists)
function SQS.objective_function_simple(spins, natoms, composition)
    -- Ensure composition is a number
    local comp = tonumber(composition) or 0.5
    
    -- Sample pairs for performance
    local sample_size = math.min(natoms, 200)
    local pair_sum = 0
    local n_pairs = 0
    
    -- Create shuffled indices
    local indices = {}
    for i = 1, natoms do indices[i] = i end
    for i = natoms, 2, -1 do
        local j = math.random(i)
        indices[i], indices[j] = indices[j], indices[i]
    end
    
    -- Sample pairs
    for i = 1, sample_size - 1 do
        for j = i + 1, math.min(i + 15, sample_size) do
            local idx_i = indices[i]
            local idx_j = indices[j]
            local s_i = spins[idx_i]
            local s_j = spins[idx_j]
            if s_i and s_j then
                pair_sum = pair_sum + s_i * s_j
                n_pairs = n_pairs + 1
            end
        end
    end
    
    if n_pairs == 0 then return 1.0 end
    
    local target_corr = (2 * comp - 1) ^ 2
    local actual_corr = pair_sum / n_pairs
    return math.abs(actual_corr - target_corr)
end

-- Fast Metropolis step
function SQS.metropolis_step(spins, neighbors, n_neighbors, natoms, temp, current_obj, composition)
    -- Ensure composition is a number
    local comp = tonumber(composition) or 0.5
    
    -- Select two random different atoms with different spins
    local i = math.random(natoms)
    local j = math.random(natoms)
    
    while i == j or spins[i] == spins[j] do
        i = math.random(natoms)
        j = math.random(natoms)
    end
    
    -- Try swap
    local si, sj = spins[i], spins[j]
    spins[i], spins[j] = sj, si
    
    -- Calculate new objective
    local new_obj = SQS.objective_function(spins, neighbors, n_neighbors, natoms, 4, comp)
    local delta = new_obj - current_obj
    
    if delta <= 0 then
        return new_obj, true
    else
        local accept_prob = math.exp(-delta / temp)
        if math.random() < accept_prob then
            return new_obj, true
        else
            -- Revert
            spins[i], spins[j] = si, sj
            return current_obj, false
        end
    end
end

-- Simulated annealing with JIT compilation
function SQS.simulated_annealing(natoms, n_B, T_start, T_end, steps_per_T, cooling_rate, composition)
    -- Ensure composition is a number
    local comp = tonumber(composition) or 0.5
    
    -- Initialize with correct composition
    local spins = {}
    for i = 1, natoms do
        spins[i] = -1
    end
    
    local n_B_count = 0
    while n_B_count < n_B do
        local idx = math.random(natoms)
        if spins[idx] == -1 then
            spins[idx] = 1
            n_B_count = n_B_count + 1
        end
    end
    
    -- Get neighbor data if available (with safety checks)
    local neighbors = _G["sqs_neighbors"]
    local n_neighbors = _G["sqs_n_neighbors"]
    local has_neighbors = false
    
    -- FIX: Check if neighbor data exists and is valid
    if neighbors and n_neighbors and type(neighbors) == 'table' and type(n_neighbors) == 'table' then
        -- Check first element exists and has data
        if neighbors[1] and n_neighbors[1] then
            if type(n_neighbors[1]) == 'number' and n_neighbors[1] > 0 then
                has_neighbors = true
            end
        end
    end
    
    local T = T_start
    local best_spins = {}
    for i = 1, natoms do best_spins[i] = spins[i] end
    
    local best_obj
    if has_neighbors then
        best_obj = SQS.objective_function(spins, neighbors, n_neighbors, natoms, 4, comp)
    else
        best_obj = SQS.objective_function_simple(spins, natoms, comp)
    end
    
    local current_obj = best_obj
    local iteration = 0
    local total_steps = 0
    
    while T > T_end do
        for step = 1, steps_per_T do
            local accepted
            if has_neighbors then
                current_obj, accepted = SQS.metropolis_step(spins, neighbors, n_neighbors, natoms, T, current_obj, comp)
            else
                -- Simple Metropolis without neighbor lists
                local i = math.random(natoms)
                local j = math.random(natoms)
                while i == j or spins[i] == spins[j] do
                    i = math.random(natoms)
                    j = math.random(natoms)
                end
                
                spins[i], spins[j] = spins[j], spins[i]
                local new_obj = SQS.objective_function_simple(spins, natoms, comp)
                local delta = new_obj - current_obj
                
                if delta <= 0 or math.random() < math.exp(-delta / T) then
                    current_obj = new_obj
                    accepted = true
                else
                    spins[i], spins[j] = spins[j], spins[i]
                    accepted = false
                end
            end
            
            if current_obj < best_obj then
                best_obj = current_obj
                for i = 1, natoms do best_spins[i] = spins[i] end
            end
            
            total_steps = total_steps + 1
        end
        
        T = T * cooling_rate
        iteration = iteration + 1
    end
    
    -- Return as table that can be converted to Lua table
    return best_spins, best_obj, total_steps
end

-- Fast random search
function SQS.random_search(natoms, n_B, n_trials, composition)
    -- Ensure composition is a number
    local comp = tonumber(composition) or 0.5
    
    local best_spins = nil
    local best_obj = math.huge
    
    -- Get neighbor data if available (with safety checks)
    local neighbors = _G["sqs_neighbors"]
    local n_neighbors = _G["sqs_n_neighbors"]
    local has_neighbors = false
    
    -- FIX: Check if neighbor data exists and is valid
    if neighbors and n_neighbors and type(neighbors) == 'table' and type(n_neighbors) == 'table' then
        -- Check first element exists and has data
        if neighbors[1] and n_neighbors[1] then
            if type(n_neighbors[1]) == 'number' and n_neighbors[1] > 0 then
                has_neighbors = true
                print("[Lua] Using neighbor lists for random search")
            end
        end
    end
    
    if not has_neighbors then
        print("[Lua] No neighbor data, using simple objective")
    end
    
    for trial = 1, n_trials do
        -- Generate random configuration
        local test_spins = {}
        for i = 1, natoms do
            test_spins[i] = -1
        end
        
        local n_B_count = 0
        while n_B_count < n_B do
            local idx = math.random(natoms)
            if test_spins[idx] == -1 then
                test_spins[idx] = 1
                n_B_count = n_B_count + 1
            end
        end
        
        local obj
        if has_neighbors then
            obj = SQS.objective_function(test_spins, neighbors, n_neighbors, natoms, 4, comp)
        else
            obj = SQS.objective_function_simple(test_spins, natoms, comp)
        end
        
        if obj < best_obj then
            best_obj = obj
            best_spins = test_spins
        end
    end
    
    return best_spins, best_obj, n_trials
end

-- Export functions as global for Python bridge
_G["sqs_random_search"] = SQS.random_search
_G["sqs_simulated_annealing"] = SQS.simulated_annealing
_G["sqs_objective_function"] = SQS.objective_function
_G["sqs_objective_function_simple"] = SQS.objective_function_simple

return SQS