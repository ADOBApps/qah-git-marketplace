#!/usr/bin/env python3
"""
ICET Backend for SQS Generator - Compatible with sqs_engine.py interface
Updated for ICET v3.2 API
"""

import numpy as np
import time
import logging
from typing import Tuple, List, Dict, Optional, Callable, Union
from dataclasses import dataclass, field
from pathlib import Path

try:
    import icet
    from icet import ClusterSpace, StructureContainer
    from icet.tools.structure_generation import generate_sqs
    from ase.io import read, write
    from ase import Atoms
    from ase.build import make_supercell
    from ase.cell import Cell
    HAS_ICET = True
    print(f"[ICET] Loaded version: {getattr(icet, '__version__', 'unknown')}")
except ImportError as e:
    HAS_ICET = False
    IMPORT_ERROR = str(e)
    print(f"[ICET] Import failed: {e}")

# from icet import ClusterSpace, StructureContainer
# from icet.tools.structure_generation import generate_sqs
# from ase.io import read, write
# from ase import Atoms
# from ase.build import make_supercell
# from ase.cell import Cell

@dataclass
class ICETSQSResult:
    """SQS generation result - compatible with SQSResult from sqs_engine.py"""
    configuration: Union['ICETSpinConfiguration', None] = None
    correlations: Dict = field(default_factory=dict)
    objective_value: float = 0.0
    n_atoms: int = 0
    composition: float = 0.5
    method: str = 'ICET'
    iterations: int = 0
    time_seconds: float = 0.0
    converged: bool = False
    structure: Optional[Atoms] = None
    cluster_space_info: Dict = field(default_factory=dict)


class ICETSpinConfiguration:
    """Dummy SpinConfiguration for ICET backend compatibility"""
    
    def __init__(self, n_atoms: int, composition: float = 0.5):
        self.n_atoms = n_atoms
        self.composition = composition
        self.n_B = int(n_atoms * composition)
        self.n_A = n_atoms - self.n_B
        self.spins = np.ones(n_atoms)
        self.spins[:self.n_A] = -1
    
    def randomize(self, seed: Optional[int] = None):
        if seed is not None:
            np.random.seed(seed)
        indices = np.random.permutation(self.n_atoms)
        self.spins = np.ones(self.n_atoms)
        self.spins[indices[:self.n_A]] = -1
    
    def swap(self, i: int, j: int):
        self.spins[i], self.spins[j] = self.spins[j], self.spins[i]
    
    def copy(self) -> 'ICETSpinConfiguration':
        new = ICETSpinConfiguration(self.n_atoms, self.composition)
        new.spins = self.spins.copy()
        return new
    
    def get_elements(self, element_A: str = 'A', element_B: str = 'B') -> List[str]:
        return [element_B if spin == 1 else element_A for spin in self.spins]


class CorrelationFunctions:
    """Dummy CorrelationFunctions for ICET backend compatibility"""
    
    def __init__(self, lattice_vectors: np.ndarray, positions: np.ndarray):
        self.lattice_vectors = lattice_vectors
        self.positions = positions
    
    def objective_function(self, spins: np.ndarray) -> float:
        return 0.0
    
    def all_correlations(self, spins: np.ndarray) -> Dict:
        return {}


class ICETSQSGenerator:
    """ICET-based SQS generator for binary systems (ICET v3.2)"""

    def __init__(self, lattice_vectors: np.ndarray, positions: np.ndarray,
                element_A: str = 'A', element_B: str = 'B',
                composition: float = 0.5,
                primitive_vectors: np.ndarray = None,
                primitive_positions: np.ndarray = None,
                primitive_elements: List[str] = None,
                supercell_size: Tuple[int, int, int] = None,
                seed: Optional[int] = None):
        
        if not HAS_ICET:
            raise ImportError(
                f"ICET not installed: {IMPORT_ERROR}\n"
                "Install with: pip install icet ase"
            )
        
        self.lattice_vectors = lattice_vectors
        self.positions = positions
        self.element_A = element_A
        self.element_B = element_B
        self.composition = composition
        self.n_atoms = len(positions)
        self.seed = seed
        
        if seed is not None:
            np.random.seed(seed)
        
        # Store primitive and supercell info
        self.primitive_vectors = primitive_vectors
        self.primitive_positions = primitive_positions
        self.primitive_elements = primitive_elements
        self.supercell_size = supercell_size
        self.generated_structure = None  # Store generated structure
        
        # Create the appropriate structure for ICET
        if primitive_vectors is not None and primitive_positions is not None:
            # Use primitive cell for ClusterSpace
            cell = Cell(primitive_vectors)
            n_primitive_atoms = len(primitive_positions)
            
            # Store primitive atoms count
            self.n_primitive_atoms = n_primitive_atoms
            
            # Create primitive structure for cluster space
            self.primitive_structure = Atoms(
                symbols=[element_A] * n_primitive_atoms,
                positions=primitive_positions,
                cell=cell, pbc=True
            )
            
            # Calculate target size for ICET
            if supercell_size:
                self.target_size = n_primitive_atoms * supercell_size[0] * supercell_size[1] * supercell_size[2]
                print(f"[ICET] Primitive/conventional atoms: {n_primitive_atoms}")
                print(f"[ICET] Supercell size: {supercell_size}")
                print(f"[ICET] Target size for ICET: {self.target_size}")
                print(f"[ICET] Input atoms: {self.n_atoms}")
            else:
                self.target_size = self.n_atoms
            
            # Store the supercell structure for output (if different from target)
            cell = Cell(lattice_vectors)
            self.supercell_structure = Atoms(
                symbols=[element_A] * self.n_atoms,
                positions=positions,
                cell=cell, pbc=True
            )
            self.ase_structure = self.supercell_structure
        else:
            # No primitive provided - treat input as primitive
            cell = Cell(lattice_vectors)
            self.primitive_structure = Atoms(
                symbols=[element_A] * self.n_atoms,
                positions=positions,
                cell=cell, pbc=True
            )
            self.ase_structure = self.primitive_structure.copy()
            self.target_size = self.n_atoms
            if supercell_size is None:
                self.supercell_size = (1, 1, 1)
            self.n_primitive_atoms = self.n_atoms
        
        # Initialize dummy components
        self.corr_func = CorrelationFunctions(lattice_vectors, positions)
        self.config = ICETSpinConfiguration(self.n_atoms, composition)
        self.config.randomize(seed)
        
        self.best_config = None
        self.best_config_structure = None  # Store the actual generated structure
        self.best_objective = float('inf')
        self.best_correlations = None
    
    def _create_cluster_space(self, cutoffs: List[float]):
        """Create ClusterSpace using primitive structure"""
        chemical_symbols = list(set([self.element_A, self.element_B]))
        
        cluster_space = ClusterSpace(
            structure=self.primitive_structure,  # Always use primitive!
            cutoffs=cutoffs,
            chemical_symbols=chemical_symbols
        )
        return cluster_space
    
    def _get_supercell_size_from_structure(self):
        """Calculate supercell size if not provided"""
        if self.supercell_size is not None:
            return self.supercell_size
        
        # Try to determine from primitive vs current structure
        if hasattr(self, 'primitive_structure') and self.primitive_structure:
            n_prim = len(self.primitive_structure)
            if n_prim > 0:
                ratio = self.n_atoms / n_prim
                size = int(round(ratio ** (1/3)))
                if size**3 == ratio:
                    return (size, size, size)
        
        # Default fallback
        return (2, 2, 2)
    
    def _create_ase_structure(self):
        """Convert lattice vectors and positions to ASE Atoms object"""
        cell = Cell(self.lattice_vectors)
        symbols = [self.element_A] * self.n_atoms
        self.ase_structure = Atoms(symbols=symbols, positions=self.positions, cell=cell, pbc=True)
    
    def _get_concentrations_dict(self) -> Dict[str, float]:
        """Convert composition to ICET concentration format"""
        return {self.element_A: 1.0 - self.composition, self.element_B: self.composition}
    
    def objective(self, config: ICETSpinConfiguration = None) -> float:
        return 0.0
    
    def _create_cluster_space_old(self, cutoffs: List[float]):
        """Create ClusterSpace for ICET v3.2"""
        # For ICET v3.2, ClusterSpace is created from atoms with chemical symbols
        # from icet import ClusterSpace
        
        # Get unique chemical symbols in the structure
        chemical_symbols = list(set([self.element_A, self.element_B]))
        
        # Create cluster space - ICET v3.2 API
        cluster_space = ClusterSpace(
            structure=self.ase_structure,
            cutoffs=cutoffs,
            chemical_symbols=chemical_symbols
        )
        
        return cluster_space
    
    def simulated_annealing(self, T_start: float = 1.0, T_end: float = 0.01,
                        steps_per_T: int = 1000, cooling_rate: float = 0.95,
                        convergence_threshold: float = 0.15,
                        callback: Optional[Callable] = None) -> ICETSQSResult:
        """Run simulated annealing using ICET v3.2"""
        start_time = time.time()
        
        # Map parameters to ICET
        n_trials = max(1, int(steps_per_T / 100))
        max_iterations = steps_per_T * int(np.log(T_end / T_start) / np.log(cooling_rate)) if cooling_rate < 1 else steps_per_T
        
        # Calculate cutoffs based on cell size
        cell_diag = np.sqrt(np.sum(self.lattice_vectors**2, axis=1))
        max_cutoff = min(cell_diag) / 2
        cutoffs = [max_cutoff * 0.8, max_cutoff * 0.6]
        
        # Create cluster space for ICET v3.2
        cluster_space = self._create_cluster_space(cutoffs)
        concentrations = self._get_concentrations_dict()
        
        if callback:
            callback(0, T_start, float('inf'), 0)
        
        # Use target_size for generation
        sqs_structure = generate_sqs(
            cluster_space=cluster_space,
            max_size=self.target_size,
            target_concentrations=concentrations,
            include_smaller_cells=False,
            n_steps=n_trials,
            T_start=T_start,
            T_stop=T_end,
            tol=convergence_threshold
        )
        
        # Store the generated structure
        self.generated_structure = sqs_structure.copy()
        
        print(f"[ICET] Requested size: {self.target_size}, Generated: {len(sqs_structure)} atoms")
        
        # Get cluster vector
        cluster_vector = cluster_space.get_cluster_vector(sqs_structure)
        
        # Calculate objective value
        if len(cluster_vector) > 0:
            non_zero = cluster_vector[np.abs(cluster_vector) > 1e-10]
            objective_value = np.std(non_zero) if len(non_zero) > 0 else 0.0
        else:
            objective_value = 0.0
        
        end_time = time.time()
        
        if callback:
            callback(1, T_end, objective_value, 1)
        
        # Convert to spin configuration
        self.best_config = self._atoms_to_spin_configuration(sqs_structure)
        self.best_config_structure = sqs_structure.copy()
        self.best_objective = objective_value
        self.best_correlations = {'icet_objective': objective_value, 'full_vector': cluster_vector.tolist()}
        
        # Get orbit info
        orbit_list = cluster_space.orbit_list
        n_orbits = len(orbit_list)
        n_parameters = len(cluster_vector)
        
        max_cluster_diameter = 0.0
        for orbit in orbit_list:
            if 'radius' in orbit and orbit['radius'] > max_cluster_diameter:
                max_cluster_diameter = orbit['radius']
        
        return ICETSQSResult(
            configuration=self.best_config,
            correlations={
                'pairs': {1: objective_value, 2: 0.0, 3: 0.0, 4: 0.0},
                'objective': objective_value,
                'full_vector': cluster_vector.tolist(),
                'n_orbits': cluster_space.number_of_orbits_by_order,
                'n_parameters': len(cluster_vector)
            },
            objective_value=objective_value,
            n_atoms=len(sqs_structure),  # Use actual generated size
            composition=self.composition,
            method='ICET Simulated Annealing',
            iterations=max_iterations,
            time_seconds=end_time - start_time,
            converged=objective_value < convergence_threshold,
            structure=sqs_structure,
            cluster_space_info={
                'n_orbits': cluster_space.number_of_orbits_by_order,
                'n_parameters': n_parameters,
                'cutoffs': cutoffs,
                'max_cluster_diameter': max_cluster_diameter
            }
        )
    
    def random_search(self, n_trials: int = 1000, convergence_threshold: float = 0.15, 
                    callback: Optional[Callable] = None) -> ICETSQSResult:
        """Random search using ICET v3.2"""
        start_time = time.time()
        
        # Calculate cutoffs
        cell_diag = np.sqrt(np.sum(self.lattice_vectors**2, axis=1))
        max_cutoff = min(cell_diag) / 2
        cutoffs = [max_cutoff * 0.8, max_cutoff * 0.6]
        
        # Create cluster space using primitive structure
        cluster_space = self._create_cluster_space(cutoffs)
        concentrations = self._get_concentrations_dict()
        
        # Use target_size for generation (not self.n_atoms)
        sqs_structure = generate_sqs(
            cluster_space=cluster_space,
            max_size=self.target_size,
            target_concentrations=concentrations,
            include_smaller_cells=False,  # Force exact size
            n_steps=n_trials,
            tol=convergence_threshold
        )
        
        # Store the generated structure
        self.generated_structure = sqs_structure.copy()
        
        print(f"[ICET] Requested size: {self.target_size}, Generated: {len(sqs_structure)} atoms")
        if len(sqs_structure) != self.target_size:
            print(f"[ICET] WARNING: Size mismatch! Expected {self.target_size}, got {len(sqs_structure)}")
        
        # Calculate objective value
        structure_container = StructureContainer(cluster_space)
        structure_container.add_structure(sqs_structure)
        cluster_vector = cluster_space.get_cluster_vector(sqs_structure)
        non_zero = cluster_vector[np.abs(cluster_vector) > 1e-10]
        objective_value = np.std(non_zero) if len(non_zero) > 0 else 0.0
        
        end_time = time.time()
        
        # Convert to spin configuration (this also stores the structure)
        self.best_config = self._atoms_to_spin_configuration(sqs_structure)
        self.best_config_structure = sqs_structure.copy()
        self.best_objective = objective_value
        self.best_correlations = {'icet_objective': objective_value}
        
        if callback:
            callback(n_trials, objective_value)
        
        # Get number of orbits
        orbit_list = cluster_space.orbit_list
        n_orbits = len(orbit_list)
        n_parameters = len(cluster_vector)
        
        return ICETSQSResult(
            configuration=self.best_config,
            correlations={
                'pairs': {1: objective_value, 2: 0.0, 3: 0.0, 4: 0.0},
                'objective': objective_value,
                'full_vector': cluster_vector.tolist(),
                'n_orbits': cluster_space.number_of_orbits_by_order,
                'n_parameters': len(cluster_vector)
            },
            objective_value=objective_value,
            n_atoms=len(sqs_structure),  # Use actual generated size
            composition=self.composition,
            method='ICET Random Search',
            iterations=n_trials,
            time_seconds=end_time - start_time,
            converged=objective_value < convergence_threshold,
            structure=sqs_structure,
            cluster_space_info={
                'n_orbits': n_orbits,
                'n_parameters': n_parameters,
                'cutoffs': cutoffs
            }
        )
    
    def _atoms_to_spin_configuration(self, atoms: Atoms) -> ICETSpinConfiguration:
        """Convert ASE Atoms to SpinConfiguration for compatibility"""
        symbols = atoms.get_chemical_symbols()
        n_generated = len(symbols)
        
        # Create config with the CORRECT number of atoms
        config = ICETSpinConfiguration(n_generated, self.composition)
        
        # Convert symbols to spins (-1 for A, 1 for B)
        spins = np.array([1 if s == self.element_B else -1 for s in symbols])
        config.spins = spins
        config.n_atoms = n_generated
        config.n_A = int(n_generated * (1 - self.composition))
        config.n_B = n_generated - config.n_A
        
        # Update instance to match generated structure
        self.n_atoms = n_generated
        
        return config
    
    def get_structures(self) -> Tuple[np.ndarray, List[str]]:
        """Get final positions and element list using the generated structure"""
        if self.best_config_structure is not None:
            # Use the actual ICET-generated structure
            atoms = self.best_config_structure
            positions = atoms.get_positions()
            elements = atoms.get_chemical_symbols()
            
            print(f"[ICET] get_structures: returning {len(elements)} atoms")
            return positions, elements
        
        elif self.generated_structure is not None:
            # Fallback to generated structure
            atoms = self.generated_structure
            positions = atoms.get_positions()
            elements = atoms.get_chemical_symbols()
            
            print(f"[ICET] get_structures (fallback): returning {len(elements)} atoms")
            return positions, elements
        
        elif self.best_config is not None:
            # Last resort - use best_config
            elements = self.best_config.get_elements(self.element_A, self.element_B)
            # Get positions from original lattice (this may be wrong size!)
            cart_positions = np.dot(self.positions, self.lattice_vectors)
            
            if len(elements) != len(cart_positions):
                print(f"[ICET] ERROR: Size mismatch! Config elements={len(elements)}, positions={len(cart_positions)}")
                print(f"[ICET] Cannot return valid structure")
                # Return empty arrays to avoid crash
                return np.array([]), []
            
            return cart_positions, elements
        else:
            # Return initial configuration
            elements = self.config.get_elements(self.element_A, self.element_B)
            cart_positions = np.dot(self.positions, self.lattice_vectors)
            return cart_positions, elements
    
    def write_xyz(self, filename: str, comment: str = "SQS structure"):
        """Write XYZ file"""
        positions, elements = self.get_structures()
        
        with open(filename, 'w') as f:
            f.write(f"{len(positions)}\n")
            f.write(f"{comment}\n")
            for elem, pos in zip(elements, positions):
                f.write(f"{elem} {pos[0]:.12f} {pos[1]:.12f} {pos[2]:.12f}\n")
        return filename
    
    def write_cif(self, filename: str, comment: str = "SQS structure"):
        """Write CIF file"""
        positions, elements = self.get_structures()
        
        min_coords = np.min(positions, axis=0)
        max_coords = np.max(positions, axis=0)
        a = max_coords[0] - min_coords[0]
        b = max_coords[1] - min_coords[1]
        c = max_coords[2] - min_coords[2]
        shifted = positions - min_coords
        
        with open(filename, 'w') as f:
            f.write(f"data_{filename.replace('.cif', '')}\n")
            f.write("_audit_creation_method 'ICET SQS Generator'\n")
            f.write(f"_cell_length_a {a:.6f}\n")
            f.write(f"_cell_length_b {b:.6f}\n")
            f.write(f"_cell_length_c {c:.6f}\n")
            f.write("_cell_angle_alpha 90.0000\n")
            f.write("_cell_angle_beta 90.0000\n")
            f.write("_cell_angle_gamma 90.0000\n")
            f.write("\nloop_\n")
            f.write("_atom_site_label\n")
            f.write("_atom_site_type_symbol\n")
            f.write("_atom_site_fract_x\n")
            f.write("_atom_site_fract_y\n")
            f.write("_atom_site_fract_z\n")
            f.write("_atom_site_occupancy\n")
            
            for i, (elem, pos) in enumerate(zip(elements, shifted), 1):
                label = f"{elem}{i}"
                fract_x = pos[0] / a if a > 0 else 0.0
                fract_y = pos[1] / b if b > 0 else 0.0
                fract_z = pos[2] / c if c > 0 else 0.0
                f.write(f"  {label:<6} {elem:<2} {fract_x:.6f} {fract_y:.6f} {fract_z:.6f} 1.0000\n")
        
        return filename


class ICETSQSGeneratorMultiSublattice(ICETSQSGenerator):
    """ICET-based SQS generator for multi-sublattice systems (ICET v3.2)"""
    
    def __init__(self, lattice_vectors, positions, elements,
                 cation_indices: List[int],
                 element_A: str, element_B: str,
                 composition: float = 0.5,
                 primitive_vectors: np.ndarray = None,
                 primitive_positions: np.ndarray = None,
                 primitive_elements: List[str] = None,
                 supercell_size: Tuple[int, int, int] = None,
                 seed: Optional[int] = None):
        
        self.cation_indices = cation_indices
        self.all_elements = elements.copy()
        self.n_cations = len(cation_indices)
        self.original_positions = positions
        self.original_lattice_vectors = lattice_vectors
        
        self.element_A = element_A
        self.element_B = element_B
        self.composition = composition
        self.n_atoms = self.n_cations
        
        # Store lattice_vectors explicitly for compatibility
        self.lattice_vectors = lattice_vectors
        
        if seed is not None:
            np.random.seed(seed)
        
        # Store primitive and supercell info
        self.primitive_vectors = primitive_vectors
        self.primitive_positions = primitive_positions
        self.primitive_elements = primitive_elements
        self.supercell_size = supercell_size
        self.generated_structure = None
        self.best_config_structure = None
        
        # Create cation-only positions
        cation_positions = positions[cation_indices]
        
        # Create the appropriate structure for ICET
        if primitive_vectors is not None and primitive_positions is not None:
            # For multi-sublattice, we need to extract ONLY cation positions from primitive
            # Filter primitive positions to get only cation sites (where element is element_A)
            prim_cation_indices = [i for i, elem in enumerate(primitive_elements) if elem == element_A]
            prim_cation_positions = primitive_positions[prim_cation_indices]
            
            # Use primitive cation positions for ClusterSpace
            cell = Cell(primitive_vectors)
            n_prim_cations = len(prim_cation_positions)
            self.primitive_structure = Atoms(
                symbols=[element_A] * n_prim_cations,
                positions=prim_cation_positions,
                cell=cell, pbc=True
            )
            
            # Store the supercell structure (cations only)
            cell = Cell(lattice_vectors)
            cation_symbols = [element_A] * self.n_cations
            self.ase_structure = Atoms(
                symbols=cation_symbols,
                positions=cation_positions,
                cell=cell, pbc=True
            )
            
            # Calculate target size for ICET
            if supercell_size:
                self.target_size = n_prim_cations * supercell_size[0] * supercell_size[1] * supercell_size[2]
                print(f"[ICET] Multi-sublattice: primitive cations={n_prim_cations}, supercell size={supercell_size}")
                print(f"[ICET] Target size: {self.target_size}, Input cations: {self.n_cations}")
            else:
                self.target_size = self.n_cations
        else:
            # No primitive provided - treat input as primitive (cations only)
            cell = Cell(lattice_vectors)
            self.primitive_structure = Atoms(
                symbols=[element_A] * self.n_cations,
                positions=cation_positions,
                cell=cell, pbc=True
            )
            self.ase_structure = self.primitive_structure.copy()
            self.target_size = self.n_cations
            if supercell_size is None:
                self.supercell_size = (1, 1, 1)
        
        # Initialize dummy components
        self.corr_func = CorrelationFunctions(lattice_vectors, cation_positions)
        self.config = ICETSpinConfiguration(self.n_cations, composition)
        self.config.randomize(seed)
        self.best_config = None
        self.best_objective = float('inf')
        self.best_correlations = None
    
    def _get_concentrations_dict(self) -> Dict[str, float]:
        return {self.element_A: 1.0 - self.composition, self.element_B: self.composition}
    
    def _create_cluster_space(self, cutoffs: List[float]):
        """Create ClusterSpace using primitive cation structure"""
        chemical_symbols = list(set([self.element_A, self.element_B]))
        
        cluster_space = ClusterSpace(
            structure=self.primitive_structure,  # Use primitive, not self.ase_structure!
            cutoffs=cutoffs,
            chemical_symbols=chemical_symbols
        )
        return cluster_space
    
    def random_search(self, n_trials: int = 1000, convergence_threshold: float = 0.15, 
                     callback: Optional[Callable] = None) -> ICETSQSResult:
        """Random search for multi-sublattice"""
        start_time = time.time()
        
        # Calculate cutoffs
        cell_diag = np.sqrt(np.sum(self.original_lattice_vectors**2, axis=1))
        max_cutoff = min(cell_diag) / 2
        cutoffs = [max_cutoff * 0.8, max_cutoff * 0.6]
        
        # Create cluster space using primitive structure (cations only)
        cluster_space = self._create_cluster_space(cutoffs)
        concentrations = self._get_concentrations_dict()
        
        # Generate SQS for cation sublattice
        sqs_structure = generate_sqs(
            cluster_space=cluster_space,
            max_size=self.target_size,
            target_concentrations=concentrations,
            include_smaller_cells=False,
            n_steps=n_trials,
            tol=convergence_threshold
        )
        
        # Store the generated structure
        self.generated_structure = sqs_structure.copy()
        
        print(f"[ICET] Multi-sublattice: Requested {self.target_size} cations, Generated: {len(sqs_structure)} cations")
        
        # Calculate objective value
        structure_container = StructureContainer(cluster_space)
        structure_container.add_structure(sqs_structure)
        cluster_vector = cluster_space.get_cluster_vector(sqs_structure)
        non_zero = cluster_vector[np.abs(cluster_vector) > 1e-10]
        objective_value = np.std(non_zero) if len(non_zero) > 0 else 0.0
        
        end_time = time.time()
        
        # Convert to spin configuration
        self.best_config = self._atoms_to_spin_configuration(sqs_structure)
        self.best_config_structure = sqs_structure.copy()
        self.best_objective = objective_value
        self.best_correlations = {'icet_objective': objective_value}
        
        if callback:
            callback(n_trials, objective_value)
        
        # Get number of orbits
        orbit_list = cluster_space.orbit_list
        n_orbits = len(orbit_list)
        n_parameters = len(cluster_vector)
        
        return ICETSQSResult(
            configuration=self.best_config,
            correlations={
                'pairs': {1: objective_value, 2: 0.0, 3: 0.0, 4: 0.0},
                'objective': objective_value,
                'full_vector': cluster_vector.tolist(),
                'n_orbits': cluster_space.number_of_orbits_by_order,
                'n_parameters': len(cluster_vector)
            },
            objective_value=objective_value,
            n_atoms=len(sqs_structure),
            composition=self.composition,
            method='ICET Multi-Sublattice Random',
            iterations=n_trials,
            time_seconds=end_time - start_time,
            converged=objective_value < convergence_threshold,
            structure=sqs_structure,
            cluster_space_info={
                'n_orbits': n_orbits,
                'n_parameters': n_parameters,
                'cutoffs': cutoffs
            }
        )
    
    def simulated_annealing(self, T_start: float = 1.0, T_end: float = 0.01,
                           steps_per_T: int = 1000, cooling_rate: float = 0.95,
                           convergence_threshold: float = 0.15,
                           callback: Optional[Callable] = None) -> ICETSQSResult:
        """Simulated annealing for multi-sublattice"""
        start_time = time.time()
        
        # Map parameters to ICET
        n_trials = max(1, int(steps_per_T / 100))
        max_iterations = steps_per_T * int(np.log(T_end / T_start) / np.log(cooling_rate)) if cooling_rate < 1 else steps_per_T
        
        # Calculate cutoffs
        cell_diag = np.sqrt(np.sum(self.original_lattice_vectors**2, axis=1))
        max_cutoff = min(cell_diag) / 2
        cutoffs = [max_cutoff * 0.8, max_cutoff * 0.6]
        
        # Create cluster space
        cluster_space = self._create_cluster_space(cutoffs)
        concentrations = self._get_concentrations_dict()
        
        if callback:
            callback(0, T_start, float('inf'), 0)
        
        # Generate SQS for cation sublattice
        sqs_structure = generate_sqs(
            cluster_space=cluster_space,
            max_size=self.target_size,
            target_concentrations=concentrations,
            include_smaller_cells=False,
            n_steps=n_trials,
            T_start=T_start,
            T_stop=T_end,
            tol=convergence_threshold
        )
        
        # Store the generated structure
        self.generated_structure = sqs_structure.copy()
        
        print(f"[ICET] Multi-sublattice: Requested {self.target_size} cations, Generated: {len(sqs_structure)} cations")
        
        # Calculate objective value
        structure_container = StructureContainer(cluster_space)
        structure_container.add_structure(sqs_structure)
        cluster_vector = cluster_space.get_cluster_vector(sqs_structure)
        non_zero = cluster_vector[np.abs(cluster_vector) > 1e-10]
        objective_value = np.std(non_zero) if len(non_zero) > 0 else 0.0
        
        end_time = time.time()
        
        if callback:
            callback(1, T_end, objective_value, 1)
        
        # Convert to spin configuration
        self.best_config = self._atoms_to_spin_configuration(sqs_structure)
        self.best_config_structure = sqs_structure.copy()
        self.best_objective = objective_value
        self.best_correlations = {'icet_objective': objective_value}
        
        # Get orbit info
        orbit_list = cluster_space.orbit_list
        n_orbits = len(orbit_list)
        n_parameters = len(cluster_vector)
        
        return ICETSQSResult(
            configuration=self.best_config,
            correlations={
                'pairs': {1: objective_value, 2: 0.0, 3: 0.0, 4: 0.0},
                'objective': objective_value,
                'full_vector': cluster_vector.tolist(),
                'n_orbits': cluster_space.number_of_orbits_by_order,
                'n_parameters': len(cluster_vector)
            },
            objective_value=objective_value,
            n_atoms=len(sqs_structure),
            composition=self.composition,
            method='ICET Multi-Sublattice SA',
            iterations=max_iterations,
            time_seconds=end_time - start_time,
            converged=objective_value < convergence_threshold,
            structure=sqs_structure,
            cluster_space_info={
                'n_orbits': n_orbits,
                'n_parameters': n_parameters,
                'cutoffs': cutoffs
            }
        )
    
    def _atoms_to_spin_configuration(self, atoms: Atoms) -> ICETSpinConfiguration:
        """Convert ASE Atoms (cations only) to SpinConfiguration"""
        symbols = atoms.get_chemical_symbols()
        n_generated = len(symbols)
        
        # Create config with the correct number of atoms
        config = ICETSpinConfiguration(n_generated, self.composition)
        
        # Convert symbols to spins (-1 for A, 1 for B)
        spins = np.array([1 if s == self.element_B else -1 for s in symbols])
        config.spins = spins
        config.n_atoms = n_generated
        config.n_A = int(n_generated * (1 - self.composition))
        config.n_B = n_generated - config.n_A
        
        return config
    
    def get_structures(self):
        """Get final structure with all atoms (including fixed sublattice)"""
        if self.best_config_structure is not None:
            # Use the generated cation configuration
            cation_symbols = self.best_config_structure.get_chemical_symbols()
            
            # Start with original elements
            final_elements = self.all_elements.copy()
            
            # Replace cations according to generated configuration
            for idx in range(min(self.n_cations, len(cation_symbols))):
                atom_idx = self.cation_indices[idx]
                final_elements[atom_idx] = cation_symbols[idx]
            
            cart_positions = np.dot(self.original_positions, self.original_lattice_vectors)
            return cart_positions, final_elements
        
        elif self.generated_structure is not None:
            # Fallback to generated structure
            cation_symbols = self.generated_structure.get_chemical_symbols()
            
            final_elements = self.all_elements.copy()
            for idx in range(min(self.n_cations, len(cation_symbols))):
                atom_idx = self.cation_indices[idx]
                final_elements[atom_idx] = cation_symbols[idx]
            
            cart_positions = np.dot(self.original_positions, self.original_lattice_vectors)
            return cart_positions, final_elements
        
        else:
            # Return original structure
            cart_positions = np.dot(self.original_positions, self.original_lattice_vectors)
            return cart_positions, self.all_elements.copy()