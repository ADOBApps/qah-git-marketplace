"""
Main SQS generation engine implementing Monte Carlo simulated annealing
Based on van de Walle et al. CALPHAD 42, 13 (2013)
"""

import numpy as np
import random
from typing import Tuple, List, Dict, Optional, Callable
from dataclasses import dataclass, field
import time
from .correlation_functions import CorrelationFunctions, SpinConfiguration
from .lattice_generator import LatticeGenerator

class SpinConfiguration:
    """Handle spin configurations for binary alloys"""
    
    def __init__(self, n_atoms: int, composition: float = 0.5):
        self.n_atoms = n_atoms
        self.composition = composition
        self.n_B = int(n_atoms * composition)
        self.n_A = n_atoms - self.n_B
        
        self.spins = np.ones(n_atoms)
        self.spins[:self.n_A] = -1
    
    def randomize(self, seed: Optional[int] = None):
        if seed is not None:
            np.random.seed(seed)
        indices = np.random.permutation(self.n_atoms)
        self.spins = np.ones(self.n_atoms)
        self.spins[indices[:self.n_A]] = -1
    
    def swap(self, i: int, j: int):
        self.spins[i], self.spins[j] = self.spins[j], self.spins[i]
    
    def copy(self) -> 'SpinConfiguration':
        new = SpinConfiguration(self.n_atoms, self.composition)
        new.spins = self.spins.copy()
        return new
    
    def get_elements(self, element_A: str = 'A', element_B: str = 'B') -> List[str]:
        return [element_B if spin == 1 else element_A for spin in self.spins]

@dataclass
class SQSResult:
    """SQS generation result"""
    configuration: SpinConfiguration
    correlations: Dict
    objective_value: float
    n_atoms: int
    composition: float
    method: str
    iterations: int
    time_seconds: float
    converged: bool


class SQSGenerator:
    """
    Special Quasirandom Structure generator using Monte Carlo simulated annealing
    Implements algorithm from van de Walle et al. (2013)
    """
    
    def __init__(self, lattice_vectors: np.ndarray, positions: np.ndarray,
                 element_A: str = 'A', element_B: str = 'B',
                 composition: float = 0.5, seed: Optional[int] = None):
        """
        Initialize SQS generator
        
        Args:
            lattice_vectors: 3x3 lattice matrix
            positions: atomic positions in fractional coordinates
            element_A: first element symbol
            element_B: second element symbol
            composition: fraction of element_B (x in A₁₋ₓBₓ)
            seed: random seed for reproducibility
        """
        self.lattice_vectors = lattice_vectors
        self.positions = positions
        self.element_A = element_A
        self.element_B = element_B
        self.composition = composition
        self.n_atoms = len(positions)
        
        if seed is not None:
            random.seed(seed)
            np.random.seed(seed)
        
        # Initialize correlation functions
        self.corr_func = CorrelationFunctions(lattice_vectors, positions)
        
        # Initialize spin configuration
        self.config = SpinConfiguration(self.n_atoms, composition)
        self.config.randomize()
        
        # Track best configuration
        self.best_config = None
        self.best_objective = float('inf')
        self.best_correlations = None
    
    def objective(self, config: SpinConfiguration) -> float:
        """Calculate objective function value"""
        return self.corr_func.objective_function(config.spins)
    
    def metropolis_step(self, temperature: float) -> bool:
        """
        Perform one Metropolis Monte Carlo step
        
        Returns:
            True if step was accepted
        """
        # Randomly select two different atoms
        i, j = random.sample(range(self.n_atoms), 2)
        
        # Only swap if they are different
        if self.config.spins[i] == self.config.spins[j]:
            return False
        
        # Calculate energy change
        current_obj = self.objective(self.config)
        
        # Perform swap
        self.config.swap(i, j)
        new_obj = self.objective(self.config)
        
        # Metropolis acceptance criterion
        delta = new_obj - current_obj
        
        if delta <= 0:
            return True
        else:
            accept_prob = np.exp(-delta / temperature)
            if random.random() < accept_prob:
                return True
            else:
                # Revert swap
                self.config.swap(i, j)
                return False
    
    def simulated_annealing(self, T_start: float = 1.0, T_end: float = 0.01,
                           steps_per_T: int = 1000, cooling_rate: float = 0.95,
                           convergence_threshold: float = 0.15,
                           callback: Optional[Callable] = None) -> SQSResult:
        """
        Run simulated annealing optimization
        
        Args:
            T_start: initial temperature
            T_end: final temperature
            steps_per_T: Monte Carlo steps per temperature
            cooling_rate: temperature reduction factor
            callback: optional callback for progress updates
        """
        start_time = time.time()
        T = T_start
        iteration = 0
        accept_count = 0
        
        # Initialize best
        self.best_config = self.config.copy()
        self.best_objective = self.objective(self.best_config)
        self.best_correlations = self.corr_func.all_correlations(self.best_config.spins)
        
        while T > T_end:
            # Run Monte Carlo steps at this temperature
            for step in range(steps_per_T):
                if self.metropolis_step(T):
                    accept_count += 1
                
                # Check if this is new best
                current_obj = self.objective(self.config)
                if current_obj < self.best_objective:
                    self.best_config = self.config.copy()
                    self.best_objective = current_obj
                    self.best_correlations = self.corr_func.all_correlations(self.best_config.spins)
                    
                    if callback:
                        callback(iteration, T, self.best_objective, accept_count)
            
            # Cool down
            T *= cooling_rate
            iteration += 1
            
            if callback:
                callback(iteration, T, self.best_objective, accept_count)
        
        end_time = time.time()
        
        return SQSResult(
            configuration=self.best_config,
            correlations=self.best_correlations,
            objective_value=self.best_objective,
            n_atoms=self.n_atoms,
            composition=self.composition,
            method='Simulated Annealing',
            iterations=iteration,
            time_seconds=end_time - start_time,
            converged=self.best_objective < convergence_threshold
        )
    
    def random_search(self, n_trials: int = 1000, convergence_threshold: float = 0.15, callback: Optional[Callable] = None) -> SQSResult:
        """
        Random search optimization (simpler, faster)
        
        Args:
            n_trials: number of random configurations to test
            callback: optional progress callback
        """
        start_time = time.time()
        
        self.best_config = self.config.copy()
        self.best_objective = self.objective(self.best_config)
        self.best_correlations = self.corr_func.all_correlations(self.best_config.spins)
        
        for trial in range(n_trials):
            # Generate random configuration
            test_config = SpinConfiguration(self.n_atoms, self.composition)
            test_config.randomize()
            
            obj = self.objective(test_config)
            
            if obj < self.best_objective:
                self.best_config = test_config.copy()
                self.best_objective = obj
                self.best_correlations = self.corr_func.all_correlations(self.best_config.spins)
                
                if callback:
                    callback(trial, self.best_objective)
        
        end_time = time.time()
        
        return SQSResult(
            configuration=self.best_config,
            correlations=self.best_correlations,
            objective_value=self.best_objective,
            n_atoms=self.n_atoms,
            composition=self.composition,
            method='Random Search',
            iterations=n_trials,
            time_seconds=end_time - start_time,
            converged=self.best_objective < convergence_threshold
        )
    
    def get_structures(self) -> Tuple[np.ndarray, List[str]]:
        """
        Get final positions and element list
        
        Returns:
            positions: Cartesian coordinates
            elements: list of element symbols for each atom
        """
        # Convert to Cartesian coordinates
        cart_positions = np.dot(self.best_config.spins.reshape(-1, 1) * 0 + self.positions, self.lattice_vectors)
        
        # Get element symbols
        elements = self.best_config.get_elements(self.element_A, self.element_B)
        
        return cart_positions, elements
    
    def write_xyz(self, filename: str, comment: str = "SQS structure"):
        """Write XYZ file"""
        positions, elements = self.get_structures()
        
        with open(filename, 'w') as f:
            f.write(f"{len(positions)}\n")
            f.write(f"{comment}\n")
            for elem, pos in zip(elements, positions):
                f.write(f"{elem} {pos[0]:.12f} {pos[1]:.12f} {pos[2]:.12f}\n")
        
        return filename
    
    def write_cif(self, filename: str, comment: str = "SQS structure"):
        """Write CIF file"""
        positions, elements = self.get_structures()
        
        # Calculate bounding box
        min_coords = np.min(positions, axis=0)
        max_coords = np.max(positions, axis=0)
        a = max_coords[0] - min_coords[0]
        b = max_coords[1] - min_coords[1]
        c = max_coords[2] - min_coords[2]
        
        # Shift to origin
        shifted = positions - min_coords
        
        with open(filename, 'w') as f:
            f.write(f"data_{filename.replace('.cif', '')}\n")
            f.write("_audit_creation_method 'SQS Generator'\n")
            f.write(f"_cell_length_a {a:.6f}\n")
            f.write(f"_cell_length_b {b:.6f}\n")
            f.write(f"_cell_length_c {c:.6f}\n")
            f.write("_cell_angle_alpha 90.0000\n")
            f.write("_cell_angle_beta 90.0000\n")
            f.write("_cell_angle_gamma 90.0000\n")
            f.write("\nloop_\n")
            f.write("_atom_site_label\n")
            f.write("_atom_site_type_symbol\n")
            f.write("_atom_site_fract_x\n")
            f.write("_atom_site_fract_y\n")
            f.write("_atom_site_fract_z\n")
            f.write("_atom_site_occupancy\n")
            
            for i, (elem, pos) in enumerate(zip(elements, shifted), 1):
                label = f"{elem}{i}"
                fract_x = pos[0] / a if a > 0 else 0.0
                fract_y = pos[1] / b if b > 0 else 0.0
                fract_z = pos[2] / c if c > 0 else 0.0
                f.write(f"  {label:<6} {elem:<2} {fract_x:.6f} {fract_y:.6f} {fract_z:.6f} 1.0000\n")
        
        return filename


class SQSGeneratorMultiSublattice(SQSGenerator):
    """
    SQS generator for multi-sublattice systems like TiO₂
    where only one sublattice (cations) is mixed
    """
    
    def __init__(self, lattice_vectors, positions, elements,
                 cation_indices: List[int],  # Indices of Ti atoms to substitute
                 element_A: str, element_B: str,
                 composition: float = 0.5, seed: Optional[int] = None):
        """
        Args:
            cation_indices: list of atom indices that are Ti (to be substituted)
            element_A: original element (Ti)
            element_B: substituting element (Sn)
        """
        # Store data
        self.cation_indices = cation_indices
        self.all_elements = elements.copy()
        self.n_cations = len(cation_indices)
        self.original_positions = positions
        self.original_lattice_vectors = lattice_vectors
        
        # Store parent class attributes that we need to override
        self.element_A = element_A
        self.element_B = element_B
        self.composition = composition
        
        if seed is not None:
            random.seed(seed)
            np.random.seed(seed)
        
        # For correlation functions, we only need cation positions
        # Extract only cation positions for correlation calculations
        cation_positions = positions[cation_indices]
        
        # Initialize correlation functions with cation positions only
        self.corr_func = CorrelationFunctions(lattice_vectors, cation_positions)
        
        # Initialize spin configuration only for cation sites
        self.n_atoms = self.n_cations
        self.config = SpinConfiguration(self.n_cations, composition)
        self.config.randomize()
        
        # Track best configuration
        self.best_config = None
        self.best_objective = float('inf')
        self.best_correlations = None
    
    def objective(self, config: SpinConfiguration) -> float:
        """Calculate objective function value using cation positions only"""
        return self.corr_func.objective_function(config.spins)
    
    def metropolis_step(self, temperature: float) -> bool:
        """
        Perform one Metropolis Monte Carlo step on cation sites only
        """
        # Randomly select two different cation indices
        i, j = random.sample(range(self.n_cations), 2)
        
        # Only swap if they are different
        if self.config.spins[i] == self.config.spins[j]:
            return False
        
        # Calculate energy change
        current_obj = self.objective(self.config)
        
        # Perform swap
        self.config.swap(i, j)
        new_obj = self.objective(self.config)
        
        # Metropolis acceptance criterion
        delta = new_obj - current_obj
        
        if delta <= 0:
            return True
        else:
            accept_prob = np.exp(-delta / temperature)
            if random.random() < accept_prob:
                return True
            else:
                # Revert swap
                self.config.swap(i, j)
                return False
    
    def simulated_annealing(self, T_start: float = 1.0, T_end: float = 0.01,
                           steps_per_T: int = 1000, cooling_rate: float = 0.95,
                           convergence_threshold: float = 0.15,
                           callback: Optional[Callable] = None) -> SQSResult:
        """
        Run simulated annealing optimization on cation sites only
        """
        start_time = time.time()
        T = T_start
        iteration = 0
        accept_count = 0
        
        # Initialize best
        self.best_config = self.config.copy()
        self.best_objective = self.objective(self.best_config)
        self.best_correlations = self.corr_func.all_correlations(self.best_config.spins)
        
        while T > T_end:
            # Run Monte Carlo steps at this temperature
            for step in range(steps_per_T):
                if self.metropolis_step(T):
                    accept_count += 1
                
                # Check if this is new best
                current_obj = self.objective(self.config)
                if current_obj < self.best_objective:
                    self.best_config = self.config.copy()
                    self.best_objective = current_obj
                    self.best_correlations = self.corr_func.all_correlations(self.best_config.spins)
                    
                    if callback:
                        callback(iteration, T, self.best_objective, accept_count)
            
            # Cool down
            T *= cooling_rate
            iteration += 1
            
            if callback:
                callback(iteration, T, self.best_objective, accept_count)
        
        end_time = time.time()
        
        return SQSResult(
            configuration=self.best_config,
            correlations=self.best_correlations,
            objective_value=self.best_objective,
            n_atoms=self.n_cations,
            composition=self.composition,
            method='Simulated Annealing',
            iterations=iteration,
            time_seconds=end_time - start_time,
            converged=self.best_objective < convergence_threshold
        )
    
    def random_search(self, n_trials: int = 1000, convergence_threshold: float = 0.15, callback: Optional[Callable] = None) -> SQSResult:
        """
        Random search optimization on cation sites only
        """
        start_time = time.time()
        
        self.best_config = self.config.copy()
        self.best_objective = self.objective(self.best_config)
        self.best_correlations = self.corr_func.all_correlations(self.best_config.spins)
        
        for trial in range(n_trials):
            # Generate random configuration for cations only
            test_config = SpinConfiguration(self.n_cations, self.composition)
            test_config.randomize()
            
            obj = self.objective(test_config)
            
            if obj < self.best_objective:
                self.best_config = test_config.copy()
                self.best_objective = obj
                self.best_correlations = self.corr_func.all_correlations(self.best_config.spins)
                
                if callback:
                    callback(trial, self.best_objective)
        
        end_time = time.time()
        
        return SQSResult(
            configuration=self.best_config,
            correlations=self.best_correlations,
            objective_value=self.best_objective,
            n_atoms=self.n_cations,
            composition=self.composition,
            method='Random Search',
            iterations=n_trials,
            time_seconds=end_time - start_time,
            converged=self.best_objective < convergence_threshold
        )
    
    def get_structures(self):
        """Get final structure with O atoms fixed"""
        # Start with original elements
        final_elements = self.all_elements.copy()
        
        # Replace Ti with Sn according to configuration
        for idx in range(self.n_cations):
            is_B = (self.best_config.spins[idx] == 1)
            atom_idx = self.cation_indices[idx]
            
            if is_B:
                final_elements[atom_idx] = self.element_B
            else:
                final_elements[atom_idx] = self.element_A
        
        # Convert to Cartesian coordinates
        cart_positions = np.dot(self.original_positions, self.original_lattice_vectors)
        
        return cart_positions, final_elements