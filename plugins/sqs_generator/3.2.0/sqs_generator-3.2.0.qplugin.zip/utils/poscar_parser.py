"""
POSCAR Parser - Parse and manipulate VASP POSCAR files
"""

import re
import numpy as np
from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional, Union
from pathlib import Path
import logging


@dataclass
class POSCARSite:
    """Single atomic site in POSCAR"""
    element: str
    position: np.ndarray
    is_direct: bool = True
    is_selective: bool = False
    is_fixed: Tuple[bool, bool, bool] = (False, False, False)


@dataclass
class POSCARStructure:
    """Complete POSCAR structure"""
    comment: str = ""
    scale: float = 1.0
    lattice: np.ndarray = None
    elements: List[str] = None
    atom_counts: List[int] = None
    selective_dynamics: bool = False
    coordinate_type: str = "Direct"
    positions: List[np.ndarray] = None
    selective_flags: List[Tuple[bool, bool, bool]] = None
    
    # Extra metadata
    filepath: str = ""
    original_content: str = ""
    
    def __post_init__(self):
        """Initialize mutable defaults after dataclass initialization"""
        if self.lattice is None:
            self.lattice = np.eye(3)
        if self.elements is None:
            self.elements = []
        if self.atom_counts is None:
            self.atom_counts = []
        if self.positions is None:
            self.positions = []
        if self.selective_flags is None:
            self.selective_flags = []


class POSCARParser:
    """Parser for VASP POSCAR files"""
    
    @staticmethod
    def parse(filepath: str) -> Optional[POSCARStructure]:
        """Parse POSCAR file into structure object"""
        try:
            with open(filepath, 'r') as f:
                content = f.read()
            return POSCARParser.parse_string(content, filepath)
        except Exception as e:
            logging.error(f"Failed to parse POSCAR: {e}")
            return None
    
    @staticmethod
    def parse_string(content: str, filepath: str = "") -> Optional[POSCARStructure]:
        """Parse POSCAR string into structure object"""
        lines = content.split('\n')
        while lines and not lines[-1].strip():
            lines.pop()
        
        # Filter out comment lines (starting with #)
        non_comment_lines = [line for line in lines if not line.strip().startswith('#')]
        
        if len(non_comment_lines) < 7:
            logging.error(f"POSCAR too short: only {len(non_comment_lines)} non-comment lines")
            return None
        
        struct = POSCARStructure()
        struct.filepath = filepath
        struct.original_content = content
        
        line_idx = 0
        
        # Line 1: Comment
        struct.comment = non_comment_lines[0].strip()
        line_idx += 1
        
        # Line 2: Scale factor
        try:
            struct.scale = float(non_comment_lines[line_idx].split()[0])
        except (ValueError, IndexError):
            struct.scale = 1.0
        line_idx += 1
        
        # Lines 3-5: Lattice vectors
        struct.lattice = np.zeros((3, 3))
        for i in range(3):
            parts = non_comment_lines[line_idx + i].split()
            if len(parts) >= 3:
                struct.lattice[i] = [float(p) for p in parts[:3]]
        line_idx += 3
        
        # Line 6: Element names
        elem_line = non_comment_lines[line_idx]
        struct.elements = [x for x in elem_line.split() if x]
        line_idx += 1
        
        # Line 7: Atom counts
        count_line = non_comment_lines[line_idx]
        struct.atom_counts = [int(x) for x in count_line.split()]
        line_idx += 1
        
        # Check for selective dynamics
        if line_idx < len(non_comment_lines):
            next_line = non_comment_lines[line_idx].lower().strip()
            if 'selective' in next_line or next_line == 's':
                struct.selective_dynamics = True
                line_idx += 1
        
        # Coordinate type
        if line_idx < len(non_comment_lines):
            coord_line = non_comment_lines[line_idx].lower().strip()
            if 'cart' in coord_line or 'cartesian' in coord_line:
                struct.coordinate_type = 'Cartesian'
            else:
                struct.coordinate_type = 'Direct'
            line_idx += 1
        
        # Parse positions
        struct.positions = []
        struct.selective_flags = []
        
        for elem, count in zip(struct.elements, struct.atom_counts):
            for _ in range(count):
                if line_idx >= len(non_comment_lines):
                    logging.error(f"Unexpected end of file while reading positions for {elem}")
                    return None
                
                line = non_comment_lines[line_idx]
                parts = line.split()
                
                if len(parts) < 3:
                    logging.error(f"Invalid position line: {line}")
                    return None
                
                try:
                    pos = [float(p) for p in parts[:3]]
                    struct.positions.append(np.array(pos))
                except ValueError as e:
                    logging.error(f"Failed to parse position: {e}")
                    return None
                
                # Check for selective flags
                if struct.selective_dynamics and len(parts) >= 6:
                    flags = (
                        parts[3].lower() == 't' or parts[3].lower() == 'true' or parts[3] == 'T',
                        parts[4].lower() == 't' or parts[4].lower() == 'true' or parts[4] == 'T',
                        parts[5].lower() == 't' or parts[5].lower() == 'true' or parts[5] == 'T'
                    )
                    struct.selective_flags.append(flags)
                else:
                    struct.selective_flags.append((False, False, False))
                
                line_idx += 1
        
        # Validate
        expected_total = sum(struct.atom_counts)
        if len(struct.positions) != expected_total:
            logging.warning(f"Atom count mismatch: expected {expected_total}, got {len(struct.positions)}")
        
        return struct
    
    @staticmethod
    def to_string(struct: POSCARStructure) -> str:
        """Convert structure back to POSCAR string"""
        lines = []
        
        # Comment line
        lines.append(struct.comment if struct.comment else "Generated by VAPS POSCAR Editor")
        
        # Scale factor
        lines.append(f"{struct.scale:.12f}")
        
        # Lattice vectors
        for i in range(3):
            lines.append(f"{struct.lattice[i, 0]:.12f} {struct.lattice[i, 1]:.12f} {struct.lattice[i, 2]:.12f}")
        
        # Element names line
        lines.append(" ".join(struct.elements))
        
        # Atom counts line
        lines.append(" ".join(str(c) for c in struct.atom_counts))
        
        # Selective dynamics
        if struct.selective_dynamics:
            lines.append("Selective dynamics")
        
        # Coordinate type
        lines.append(struct.coordinate_type)
        
        # Positions
        idx = 0
        for elem, count in zip(struct.elements, struct.atom_counts):
            for j in range(count):
                pos = struct.positions[idx]
                if struct.selective_dynamics:
                    flags = struct.selective_flags[idx] if idx < len(struct.selective_flags) else (False, False, False)
                    lines.append(f"{pos[0]:.12f} {pos[1]:.12f} {pos[2]:.12f} "
                               f"{'T' if flags[0] else 'F'} "
                               f"{'T' if flags[1] else 'F'} "
                               f"{'T' if flags[2] else 'F'}")
                else:
                    lines.append(f"{pos[0]:.12f} {pos[1]:.12f} {pos[2]:.12f}")
                idx += 1
        
        return "\n".join(lines)
    
    @staticmethod
    def get_atom_indices_by_element(struct: POSCARStructure, element: str) -> List[int]:
        """Get indices of atoms of given element"""
        indices = []
        start_idx = 0
        for elem, count in zip(struct.elements, struct.atom_counts):
            if elem == element:
                indices.extend(range(start_idx, start_idx + count))
            start_idx += count
        return indices
    
    @staticmethod
    def replace_element_at_indices(struct: POSCARStructure, indices: List[int], new_element: str):
        """
        Replace element at given indices.
        Updates BOTH the element names line AND the atom counts line.
        """
        if not indices:
            return
        
        # Create mapping of original indices to elements
        original_elements = []
        for elem, count in zip(struct.elements, struct.atom_counts):
            original_elements.extend([elem] * count)
        
        # Count how many of each original element are being replaced
        replaced_counts = {}
        for idx in indices:
            if idx < len(original_elements):
                elem = original_elements[idx]
                replaced_counts[elem] = replaced_counts.get(elem, 0) + 1
        
        # Build new elements and counts
        new_elements = []
        new_counts = []
        
        # First, add all unchanged elements
        for elem, count in zip(struct.elements, struct.atom_counts):
            remaining = count - replaced_counts.get(elem, 0)
            if remaining > 0:
                new_elements.append(elem)
                new_counts.append(remaining)
        
        # Then, add the new element (if not already present)
        total_replaced = len(indices)
        if total_replaced > 0:
            if new_element in new_elements:
                # Add to existing element
                idx = new_elements.index(new_element)
                new_counts[idx] += total_replaced
            else:
                # Add as new element
                new_elements.append(new_element)
                new_counts.append(total_replaced)
        
        # Update structure
        struct.elements = new_elements
        struct.atom_counts = new_counts
    
    @staticmethod
    def get_coordinate_matrix(struct: POSCARStructure) -> np.ndarray:
        """Get positions as matrix"""
        return np.array([pos for pos in struct.positions])
    
    @staticmethod
    def get_element_distribution(struct: POSCARStructure) -> Dict[str, int]:
        """Get element distribution"""
        dist = {}
        for elem, count in zip(struct.elements, struct.atom_counts):
            dist[elem] = dist.get(elem, 0) + count
        return dist