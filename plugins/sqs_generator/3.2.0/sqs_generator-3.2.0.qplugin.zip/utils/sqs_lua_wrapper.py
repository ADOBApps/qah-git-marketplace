"""
sqs_lua_wrapper.py - LuaJIT SQS engine wrapper
Following the same pattern as lua_parser.py
"""

import numpy as np
import random
import math
import time
from pathlib import Path
from typing import Optional, Tuple, List, Dict, Callable, Any
from dataclasses import dataclass

try:
    from plugins.libs.lua.luajit_bridge import get_luajit_bridge
    LUAJIT_AVAILABLE = True
except ImportError:
    LUAJIT_AVAILABLE = False
    print("[Warning] LuaJIT bridge not available")


@dataclass
class LuaSQSResult:
    """Result from Lua SQS engine"""
    spins: List[int]
    objective_value: float
    iterations: int
    method: str
    time_seconds: float
    converged: bool


class LuaSQSEngine:
    """
    LuaJIT SQS engine wrapper - follows same pattern as lua_parser.py
    """
    
    def __init__(self, lattice_vectors: np.ndarray = None, positions: np.ndarray = None,
                 element_A: str = 'A', element_B: str = 'B',
                 composition: float = 0.5, neighbor_cutoff: float = 2.5,
                 seed: Optional[int] = None):
        """
        Initialize Lua SQS engine
        
        Args:
            lattice_vectors: 3x3 lattice matrix (optional, for compatibility)
            positions: atomic positions (optional, for compatibility)
            element_A: first element symbol
            element_B: second element symbol
            composition: fraction of element_B
            neighbor_cutoff: distance cutoff for neighbor detection (Angstroms)
            seed: random seed for reproducibility
        """
        self.lattice_vectors = lattice_vectors
        self.positions = positions
        self.element_A = element_A
        self.element_B = element_B
        self.composition = composition
        self.neighbor_cutoff = neighbor_cutoff
        
        if seed is not None:
            random.seed(seed)
            np.random.seed(seed)
        
        self.bridge = None
        self.lua_state = None
        self._initialized = False
        self._neighbors_cache = None
        
        # Find Lua scripts directory
        self.script_dir = Path(__file__).parent / "lua"
        
        self._load_lua_engine()
    
    def _load_lua_engine(self):
        """Load LuaJIT SQS engine - following pattern from lua_parser.py"""
        if not LUAJIT_AVAILABLE:
            print("[SQS] LuaJIT bridge not available")
            return
        
        try:
            print("[LuaJIT] Getting bridge...")
            self.bridge = get_luajit_bridge()
            if not self.bridge:
                print("[Error] Failed to get LuaJIT bridge")
                return
            
            print("[LuaJIT] Initializing Lua state...")
            self.lua_state = self.bridge.init()
            if not self.lua_state:
                print("[Error] Failed to initialize Lua state")
                return
            
            # Load Lua script
            script_path = self.script_dir / "lua_sqs_engine.lua"
            if not script_path.exists():
                print(f"[Error] Lua script not found: {script_path}")
                return
            
            print(f"[LuaJIT] Loading: {script_path}")
            with open(script_path, 'r', encoding='utf-8') as f:
                script_content = f.read()
            
            success = self.bridge.execute_script(self.lua_state, script_content)
            if not success:
                error = self.bridge.get_last_error(self.lua_state)
                print(f"[Error] Failed to load Lua script: {error}")
                return
            
            # Verify functions are loaded - using the same pattern as lua_parser.py
            print("[LuaJIT] Verifying functions...")
            
            self.bridge.execute_script(self.lua_state, 
                "_test_random = (type(sqs_random_search) == 'function') and 1 or 0")
            test_random = self._get_global_int("_test_random")
            print(f"[LuaJIT] sqs_random_search loaded: {test_random == 1}")
            
            self.bridge.execute_script(self.lua_state, 
                "_test_sa = (type(sqs_simulated_annealing) == 'function') and 1 or 0")
            test_sa = self._get_global_int("_test_sa")
            print(f"[LuaJIT] sqs_simulated_annealing loaded: {test_sa == 1}")
            
            if test_random != 1:
                print("[Error] SQS functions not loaded correctly")
                return
            
            self._initialized = True
            print("[Ok] LuaJIT SQS engine initialized successfully")
            
            # Setup neighbors if we have lattice data
            self._setup_neighbors()
            
        except Exception as e:
            print(f"[Error] LuaJIT SQS engine initialization failed: {e}")
            import traceback
            traceback.print_exc()
            self._initialized = False
    
    def _get_global_int(self, name: str) -> int:
        """Get integer global from Lua state - pattern from lua_parser.py"""
        try:
            val = self.bridge.get_global_number(self.lua_state, name)
            return int(val) if val is not None else 0
        except:
            return 0
    
    def _get_global_float(self, name: str) -> float:
        """Get float global from Lua state"""
        try:
            val = self.bridge.get_global_number(self.lua_state, name)
            return float(val) if val is not None else 0.0
        except:
            return 0.0
    
    def _get_global_string(self, name: str) -> str:
        """Get string global from Lua state"""
        try:
            val = self.bridge.get_global_string(self.lua_state, name)
            return val if val else ""
        except:
            return ""
    
    def _setup_neighbors(self):
        """Setup neighbor lists for correlation calculations using user-defined cutoff"""
        if not self._initialized:
            return
        
        if self.positions is not None and self.lattice_vectors is not None:
            # Build neighbor list
            natoms = len(self.positions)
            self._neighbors_cache = [[] for _ in range(natoms)]
            
            positions_cart = np.dot(self.positions, self.lattice_vectors)
            
            # Use user-defined cutoff
            cutoff = self.neighbor_cutoff
            print(f"[LuaJIT] Building neighbor lists with cutoff={cutoff} Å")
            
            for i in range(natoms):
                for j in range(i + 1, natoms):
                    dist = np.linalg.norm(positions_cart[i] - positions_cart[j])
                    if dist < cutoff:
                        self._neighbors_cache[i].append(j + 1)  # 1-indexed for Lua
                        self._neighbors_cache[j].append(i + 1)
            
            # Count total neighbor pairs
            total_pairs = sum(len(n) for n in self._neighbors_cache) // 2
            print(f"[LuaJIT] Found {total_pairs} neighbor pairs")
            
            self._register_neighbors_with_lua()
    
    def _register_neighbors_with_lua(self):
        """Register neighbor lists with Lua state - pattern from lua_parser.py"""
        if not self._initialized or not self.bridge or not self.lua_state:
            return
        
        natoms = len(self._neighbors_cache)
        
        # Build neighbor tables as Lua code
        lines = ["sqs_neighbors = {}", "sqs_n_neighbors = {}"]
        
        for i in range(natoms):
            lua_idx = i + 1
            neighbors = self._neighbors_cache[i]
            if neighbors:
                neighbors_str = ','.join(str(n) for n in neighbors)
                lines.append(f"sqs_neighbors[{lua_idx}] = {{{neighbors_str}}}")
            else:
                lines.append(f"sqs_neighbors[{lua_idx}] = {{}}")
            lines.append(f"sqs_n_neighbors[{lua_idx}] = {len(neighbors)}")
        
        script = "\n".join(lines)
        self.bridge.execute_script(self.lua_state, script)
    
    def random_search(self, natoms: int = None, n_B: int = None, n_trials: int = 10000,
                 composition: float = None, convergence_threshold: float = 0.15, callback: Optional[Callable] = None) -> LuaSQSResult:
        """
        Run random search optimization using LuaJIT
        Following the same pattern as parse_file in lua_parser.py
        """
        start_time = time.time()
        
        if natoms is None and self.positions is not None:
            natoms = len(self.positions)
        elif natoms is None:
            raise ValueError("natoms must be provided if positions not set")
        
        comp = composition if composition is not None else self.composition
        n_B_val = n_B if n_B is not None else int(natoms * comp)
        
        if not self._initialized:
            print("[LuaJIT] Not initialized, using Python fallback")
            return self._random_search_python(natoms, n_B_val, n_trials, comp, convergence_threshold, callback, start_time)
        
        try:
            # Set random seed in Lua
            seed = int(time.time() * 1000) % 2**31
            self.bridge.execute_script(self.lua_state, f"math.randomseed({seed})")
            
            # Create wrapper that calls sqs_random_search and stores results in globals
            wrapper = f"""
            -- Call SQS random search
            local spins, obj, iter = sqs_random_search({natoms}, {n_B_val}, {n_trials}, {comp})
            
            -- Store spins in globals
            if spins then
                _G["_sqs_natoms"] = #spins
                for i = 1, #spins do
                    _G["_sqs_spin_" .. i] = spins[i]
                end
            end
            
            -- Store other results
            _G["_sqs_objective"] = obj
            _G["_sqs_iterations"] = iter
            _G["_sqs_success"] = 1
            """
            
            # Execute
            success = self.bridge.execute_script(self.lua_state, wrapper)
            
            if not success:
                error = self.bridge.get_last_error(self.lua_state)
                print(f"[Error] LuaJIT random search error: {error}")
                return self._random_search_python(natoms, n_B_val, n_trials, comp, convergence_threshold, callback, start_time)
            
            # Check success
            success_flag = self._get_global_int("_sqs_success")
            if success_flag == 0:
                print("[Error] Random search failed")
                return self._random_search_python(natoms, n_B_val, n_trials, comp, convergence_threshold, callback, start_time)
            
            # Extract results
            result_natoms = self._get_global_int("_sqs_natoms")
            obj = self._get_global_float("_sqs_objective")
            iterations = self._get_global_int("_sqs_iterations")
            
            if result_natoms != natoms:
                print(f"[Warning] Atom count mismatch: {result_natoms} vs {natoms}")
                return self._random_search_python(natoms, n_B_val, n_trials, comp, convergence_threshold, callback, start_time)
            
            # Extract spins
            spins_list = []
            for i in range(1, natoms + 1):
                spin = self._get_global_int(f"_sqs_spin_{i}")
                spins_list.append(spin)
            
            # Clean up globals
            self.bridge.execute_script(self.lua_state, """
                for i = 1, (_G["_sqs_natoms"] or 0) do
                    _G["_sqs_spin_"..i] = nil
                end
                _G["_sqs_natoms"] = nil
                _G["_sqs_objective"] = nil
                _G["_sqs_iterations"] = nil
                _G["_sqs_success"] = nil
            """)
            
            if callback:
                callback(n_trials, obj)
            
            return LuaSQSResult(
                spins=spins_list,
                objective_value=obj,
                iterations=iterations if iterations > 0 else n_trials,
                method='Random Search (LuaJIT)',
                time_seconds=time.time() - start_time,
                converged=obj < convergence_threshold
            )
            
        except Exception as e:
            print(f"[LuaJIT] Random search exception: {e}")
            import traceback
            traceback.print_exc()
            return self._random_search_python(natoms, n_B_val, n_trials, comp, convergence_threshold, callback, start_time)
    
    def _random_search_python(self, natoms: int, n_B: int, n_trials: int,
                              composition: float, convergence_threshold: float = 0.15, callback=None, start_time=None) -> LuaSQSResult:
        """Python fallback for random search"""
        if start_time is None:
            start_time = time.time()
        
        best_spins = None
        best_obj = float('inf')
        
        for trial in range(n_trials):
            spins = [-1] * natoms
            indices = list(range(natoms))
            random.shuffle(indices)
            for i in range(n_B):
                spins[indices[i]] = 1
            
            obj = self._calculate_objective_python(spins, composition)
            
            if obj < best_obj:
                best_obj = obj
                best_spins = spins.copy()
                if callback and callable(callback):
                    callback(trial, best_obj)
        
        return LuaSQSResult(
            spins=best_spins,
            objective_value=best_obj,
            iterations=n_trials,
            method='Random Search (Python fallback)',
            time_seconds=time.time() - start_time,
            converged=best_obj < convergence_threshold
        )
    
    def simulated_annealing(self, natoms: int = None, n_B: int = None,
                        T_start: float = 1.0, T_end: float = 0.01,
                        steps_per_T: int = 1000, cooling_rate: float = 0.95,
                        composition: float = None, 
                        convergence_threshold: float = 0.15,
                        callback: Optional[Callable] = None) -> LuaSQSResult:
        """
        Run simulated annealing optimization using LuaJIT
        """
        start_time = time.time()
        
        if natoms is None and self.positions is not None:
            natoms = len(self.positions)
        elif natoms is None:
            raise ValueError("natoms must be provided if positions not set")
        
        comp = composition if composition is not None else self.composition
        n_B_val = n_B if n_B is not None else int(natoms * comp)
        
        if not self._initialized:
            return self._simulated_annealing_python(natoms, n_B_val, T_start, T_end,
                                                    steps_per_T, cooling_rate, comp, convergence_threshold, callback, start_time)
        
        try:
            # Set random seed in Lua
            seed = int(time.time() * 1000) % 2**31
            self.bridge.execute_script(self.lua_state, f"math.randomseed({seed})")
            
            # Create wrapper that calls sqs_simulated_annealing and stores results
            wrapper = f"""
            -- Call SQS simulated annealing
            local spins, obj, iter = sqs_simulated_annealing({natoms}, {n_B_val}, {T_start}, {T_end}, {steps_per_T}, {cooling_rate}, {comp})
            
            -- Store spins in globals
            if spins then
                _G["_sqs_sa_natoms"] = #spins
                for i = 1, #spins do
                    _G["_sqs_sa_spin_" .. i] = spins[i]
                end
            end
            
            -- Store other results
            _G["_sqs_sa_objective"] = obj
            _G["_sqs_sa_iterations"] = iter
            _G["_sqs_sa_success"] = 1
            """
            
            # Execute
            success = self.bridge.execute_script(self.lua_state, wrapper)
            
            if not success:
                error = self.bridge.get_last_error(self.lua_state)
                print(f"[Error] LuaJIT SA error: {error}")
                return self._simulated_annealing_python(natoms, n_B_val, T_start, T_end,
                                                        steps_per_T, cooling_rate, comp, convergence_threshold, callback, start_time)
            
            # Check success
            success_flag = self._get_global_int("_sqs_sa_success")
            if success_flag == 0:
                print("[Error] Simulated annealing failed")
                return self._simulated_annealing_python(natoms, n_B_val, T_start, T_end,
                                                        steps_per_T, cooling_rate, comp, convergence_threshold, callback, start_time)
            
            # Extract results
            result_natoms = self._get_global_int("_sqs_sa_natoms")
            obj = self._get_global_float("_sqs_sa_objective")
            iterations = self._get_global_int("_sqs_sa_iterations")
            
            if result_natoms != natoms:
                print(f"[Warning] Atom count mismatch: {result_natoms} vs {natoms}")
                return self._simulated_annealing_python(natoms, n_B_val, T_start, T_end,
                                                        steps_per_T, cooling_rate, comp, convergence_threshold, callback, start_time)
            
            # Extract spins
            spins_list = []
            for i in range(1, natoms + 1):
                spin = self._get_global_int(f"_sqs_sa_spin_{i}")
                spins_list.append(spin)
            
            # Clean up globals
            self.bridge.execute_script(self.lua_state, """
                for i = 1, (_G["_sqs_sa_natoms"] or 0) do
                    _G["_sqs_sa_spin_"..i] = nil
                end
                _G["_sqs_sa_natoms"] = nil
                _G["_sqs_sa_objective"] = nil
                _G["_sqs_sa_iterations"] = nil
                _G["_sqs_sa_success"] = nil
            """)
            
            if callback:
                callback(0, T_start, obj)
            
            return LuaSQSResult(
                spins=spins_list,
                objective_value=obj,
                iterations=iterations,
                method='Simulated Annealing (LuaJIT)',
                time_seconds=time.time() - start_time,
                converged=obj < convergence_threshold
            )
            
        except Exception as e:
            print(f"[LuaJIT] Simulated annealing exception: {e}")
            import traceback
            traceback.print_exc()
            return self._simulated_annealing_python(natoms, n_B_val, T_start, T_end,
                                                    steps_per_T, cooling_rate, comp, convergence_threshold, callback, start_time)
    
    def _simulated_annealing_python(self, natoms: int, n_B: int,
                                    T_start: float, T_end: float,
                                    steps_per_T: int, cooling_rate: float,
                                    composition: float, convergence_threshold: float = 0.15, callback=None, start_time=None) -> LuaSQSResult:
        """Python simulated annealing"""
        if start_time is None:
            start_time = time.time()
        
        current_spins = [-1] * natoms
        indices = list(range(natoms))
        random.shuffle(indices)
        for i in range(n_B):
            current_spins[indices[i]] = 1
        
        best_spins = current_spins.copy()
        
        def calculate_obj(spins):
            return self._calculate_objective_python(spins, composition)
        
        current_obj = calculate_obj(current_spins)
        best_obj = current_obj
        T = T_start
        iteration = 0
        total_steps = 0
        
        while T > T_end:
            for step in range(steps_per_T):
                i = random.randint(0, natoms - 1)
                j = random.randint(0, natoms - 1)
                
                while i == j or current_spins[i] == current_spins[j]:
                    i = random.randint(0, natoms - 1)
                    j = random.randint(0, natoms - 1)
                
                current_spins[i], current_spins[j] = current_spins[j], current_spins[i]
                new_obj = calculate_obj(current_spins)
                delta = new_obj - current_obj
                
                if delta <= 0 or random.random() < math.exp(-delta / T):
                    current_obj = new_obj
                    if current_obj < best_obj:
                        best_obj = current_obj
                        best_spins = current_spins.copy()
                        if callback and callable(callback):
                            callback(iteration, T, best_obj)
                else:
                    current_spins[i], current_spins[j] = current_spins[j], current_spins[i]
                
                total_steps += 1
            
            T *= cooling_rate
            iteration += 1
        
        return LuaSQSResult(
            spins=best_spins,
            objective_value=best_obj,
            iterations=total_steps,
            method='Simulated Annealing (Python)',
            time_seconds=time.time() - start_time,
            converged=best_obj < convergence_threshold
        )
    
    def _calculate_objective_python(self, spins: List[int], composition: float) -> float:
        """Calculate objective function in Python"""
        natoms = len(spins)
        
        try:
            import numpy as np
            spins_arr = np.array(spins, dtype=np.float64)
            
            sample_size = min(natoms, 200)
            indices = np.random.choice(natoms, sample_size, replace=False)
            
            pair_sum = 0.0
            n_pairs = 0
            
            for i in range(sample_size):
                for j in range(i + 1, min(i + 15, sample_size)):
                    pair_sum += spins_arr[indices[i]] * spins_arr[indices[j]]
                    n_pairs += 1
            
            if n_pairs == 0:
                return 1.0
            
            ideal_corr = (2 * composition - 1) ** 2
            actual_corr = pair_sum / n_pairs
            return abs(actual_corr - ideal_corr)
            
        except ImportError:
            n_pairs = 0
            pair_sum = 0
            sample_size = min(natoms, 200)
            indices = random.sample(range(natoms), sample_size)
            
            for i in range(sample_size):
                for j in range(i + 1, min(i + 15, sample_size)):
                    pair_sum += spins[indices[i]] * spins[indices[j]]
                    n_pairs += 1
            
            if n_pairs == 0:
                return 1.0
            
            ideal_corr = (2 * composition - 1) ** 2
            actual_corr = pair_sum / n_pairs
            return abs(actual_corr - ideal_corr)
    
    def spins_to_elements(self, spins: List[int]) -> List[str]:
        return [self.element_B if s == 1 else self.element_A for s in spins]
    
    def set_lattice(self, lattice_vectors: np.ndarray, positions: np.ndarray, neighbor_cutoff: float = 2.5):
        """Set lattice and positions for neighbor calculation"""
        self.lattice_vectors = lattice_vectors
        self.positions = positions
        self.neighbor_cutoff = neighbor_cutoff
        self._setup_neighbors()
    
    @property
    def is_available(self) -> bool:
        return self._initialized
    
    def cleanup(self):
        if self.bridge and self.lua_state:
            self.bridge.close(self.lua_state)
            self.lua_state = None
            self._initialized = False
    
    def __del__(self):
        self.cleanup()


_lua_engine = None


def get_lua_engine(lattice_vectors: np.ndarray = None, positions: np.ndarray = None,
                   element_A: str = 'A', element_B: str = 'B',
                   composition: float = 0.5, neighbor_cutoff: float = 2.5,
                   seed: Optional[int] = None) -> LuaSQSEngine:
    """Get or create Lua SQS engine instance"""
    global _lua_engine
    if _lua_engine is None:
        print("[LuaJIT] Creating SQS engine instance...")
        _lua_engine = LuaSQSEngine(lattice_vectors, positions, element_A, element_B, 
                                    composition, neighbor_cutoff, seed)
    return _lua_engine