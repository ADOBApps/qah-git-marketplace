"""
Correlation functions for SQS as defined in Zunger PRL 65, 353 (1990)
"""

import numpy as np
from itertools import combinations, product
from typing import List, Tuple, Dict
from collections import defaultdict


class CorrelationFunctions:
    """Calculate multi-site correlation functions for binary alloys"""
    
    def __init__(self, lattice_vectors, positions, neighbor_cutoffs=None):
        """
        Initialize correlation functions
        
        Args:
            lattice_vectors: 3x3 lattice matrix
            positions: atomic positions in fractional coordinates
            neighbor_cutoffs: dict of cutoff distances for each shell
        """
        self.lattice_vectors = np.array(lattice_vectors)
        self.positions = np.array(positions)
        self.n_atoms = len(positions)
        self.cutoffs = neighbor_cutoffs or {1: 1.5, 2: 2.2, 3: 2.8, 4: 3.4}
        
        # Convert to Cartesian coordinates
        self.cart_positions = self._to_cartesian(positions)
        
        # Precompute neighbor lists
        self.neighbors = self._compute_neighbors()
    
    def _to_cartesian(self, frac_coords):
        """Convert fractional to Cartesian coordinates"""
        return np.dot(frac_coords, self.lattice_vectors)
    
    def _compute_neighbors(self):
        """Compute neighbor lists for each shell"""
        neighbors = {shell: [] for shell in self.cutoffs}
        
        for i in range(self.n_atoms):
            for j in range(i + 1, self.n_atoms):
                # Calculate distance with PBC
                diff = self.cart_positions[j] - self.cart_positions[i]
                # Apply minimum image convention
                for k in range(3):
                    if abs(diff[k]) > 0.5 * self.lattice_vectors[k, k]:
                        diff[k] -= np.sign(diff[k]) * self.lattice_vectors[k, k]
                
                dist = np.linalg.norm(diff)
                
                # Assign to nearest shell
                for shell, cutoff in sorted(self.cutoffs.items()):
                    if dist < cutoff:
                        neighbors[shell].append((i, j))
                        break
        
        return neighbors
    
    def pair_correlation(self, configuration: np.ndarray, shell: int) -> float:
        """
        Calculate pair correlation function for given shell
        
        For binary alloy with spins ±1, pair correlation = <σ_i·σ_j>
        For random alloy at x=0.5: pair correlation = 0
        """
        if shell not in self.neighbors:
            return 0.0
        
        pairs = self.neighbors[shell]
        if not pairs:
            return 0.0
        
        correlations = []
        for i, j in pairs:
            correlations.append(configuration[i] * configuration[j])
        
        return np.mean(correlations)
    
    def triplet_correlation(self, configuration: np.ndarray, shell: int) -> float:
        """Calculate three-body correlation function"""
        # For triangles, need to find triplets within shell distance
        # Simplified: use combinations of pairs
        if shell not in self.neighbors:
            return 0.0
        
        pairs = self.neighbors[shell][:50]  # Limit for performance
        triplets = []
        
        for (i, j), (k, l) in combinations(pairs, 2):
            # Find overlapping triplets
            if i == k:
                triplets.append((i, j, l))
            elif i == l:
                triplets.append((i, j, k))
            elif j == k:
                triplets.append((j, i, l))
            elif j == l:
                triplets.append((j, i, k))
        
        if not triplets:
            return 0.0
        
        correlations = []
        for i, j, k in triplets[:100]:  # Limit for performance
            correlations.append(configuration[i] * configuration[j] * configuration[k])
        
        return np.mean(correlations) if correlations else 0.0
    
    def all_correlations(self, configuration: np.ndarray) -> Dict:
        """Calculate all correlation functions"""
        results = {'pairs': {}, 'triplets': {}}
        
        for shell in self.cutoffs:
            results['pairs'][shell] = self.pair_correlation(configuration, shell)
            results['triplets'][shell] = self.triplet_correlation(configuration, shell)
        
        return results
    
    def objective_function(self, configuration: np.ndarray, weights: Dict = None) -> float:
        """
        Objective function for SQS optimization (Eq. 3 in van de Walle 2013)
        
        Q = -ω·L + Σ|Δρ_α|
        """
        if weights is None:
            weights = {'pairs': {1: 1.0, 2: 0.5, 3: 0.25, 4: 0.125},
                      'triplets': {1: 0.1, 2: 0.05}}
        
        correlations = self.all_correlations(configuration)
        
        # Find L = largest shell with perfect correlation match
        L = 0
        for shell in sorted(self.cutoffs.keys()):
            if abs(correlations['pairs'][shell]) < 1e-6:
                L = shell
            else:
                break
        
        # Calculate weighted sum of errors
        error_sum = 0.0
        for shell, weight in weights['pairs'].items():
            error_sum += weight * abs(correlations['pairs'][shell])
        
        for shell, weight in weights['triplets'].items():
            if shell in correlations['triplets']:
                error_sum += weight * abs(correlations['triplets'][shell])
        
        omega = 1.0  # Weight for perfect match range
        return -omega * L + error_sum


class SpinConfiguration:
    """Handle spin configurations for binary alloys"""
    
    def __init__(self, n_atoms: int, composition: float = 0.5):
        """
        Initialize spin configuration
        
        Args:
            n_atoms: number of atoms
            composition: fraction of B atoms (x in A₁₋ₓBₓ)
        """
        self.n_atoms = n_atoms
        self.composition = composition
        self.n_B = int(n_atoms * composition)
        self.n_A = n_atoms - self.n_B
        
        # Spins: +1 for B, -1 for A
        self.spins = np.ones(n_atoms)
        self.spins[:self.n_A] = -1
    
    def randomize(self, seed=None):
        """Randomize configuration"""
        if seed is not None:
            np.random.seed(seed)
        
        indices = np.random.permutation(self.n_atoms)
        self.spins = np.ones(self.n_atoms)
        self.spins[indices[:self.n_A]] = -1
    
    def swap(self, i, j):
        """Swap spins at positions i and j"""
        self.spins[i], self.spins[j] = self.spins[j], self.spins[i]
    
    def copy(self):
        """Create copy"""
        new = SpinConfiguration(self.n_atoms, self.composition)
        new.spins = self.spins.copy()
        return new
    
    def get_elements(self, element_A: str = 'A', element_B: str = 'B') -> List[str]:
        """Convert spins to element symbols"""
        elements = []
        for spin in self.spins:
            elements.append(element_B if spin == 1 else element_A)
        return elements