"""
Fortran SQS engine wrapper with unified interface
Updated for ICET-optimized Fortran engine with neighbor lists and multi-shell support
"""

import ctypes
import numpy as np
from pathlib import Path
import platform
import random
import time
from typing import Optional, Tuple, List, Dict, Callable, Any
import os
import multiprocessing
import logging
from dataclasses import dataclass

# Platform-specific library path
system = platform.system().lower()
if system == 'windows':
    LIB_EXT = '.dll'
    LIB_FOLDER = 'windows'
elif system == 'darwin':
    LIB_EXT = '.dylib'
    LIB_FOLDER = 'macos'
else:  # linux
    LIB_EXT = '.so'
    LIB_FOLDER = 'linux'

lib_path = Path(__file__).parent / "fortran" / LIB_FOLDER / f"libsqs_icet_engine{LIB_EXT}"


@dataclass
class FortranSQSResult:
    """Result from Fortran SQS engine"""
    spins: List[int]
    objective_value: float
    iterations: int
    method: str
    time_seconds: float
    converged: bool
    correlations: Dict = None  # Multi-shell correlations if available


class FortranSQSEngine:
    """Unified Fortran SQS engine wrapper compatible with sqs_engine.py interface"""
    
    MAX_NEIGHBORS = 50
    MAX_SHELLS = 10
    
    def __init__(self, lattice_vectors: np.ndarray = None, positions: np.ndarray = None,
                 element_A: str = 'A', element_B: str = 'B',
                 composition: float = 0.5, neighbor_cutoff: float = 2.5,
                 n_shells: int = 4, seed: Optional[int] = None):
        """
        Initialize Fortran SQS engine (compatible with sqs_engine.SQSGenerator)
        
        Args:
            lattice_vectors: 3x3 lattice matrix (optional, for compatibility)
            positions: atomic positions (optional, for compatibility)
            element_A: first element symbol
            element_B: second element symbol
            composition: fraction of element_B
            neighbor_cutoff: distance cutoff for neighbor detection (Angstroms)
            n_shells: Number of neighbor shells to consider
            seed: random seed for reproducibility
        """
        self.lattice_vectors = lattice_vectors
        self.positions = positions
        self.element_A = element_A
        self.element_B = element_B
        self.composition = composition
        self.neighbor_cutoff = neighbor_cutoff
        self.n_shells = n_shells
        
        if seed is not None:
            random.seed(seed)
            np.random.seed(seed)
        
        # Set OpenMP environment variables
        n_cores = multiprocessing.cpu_count()
        os.environ['OMP_NUM_THREADS'] = str(n_cores)
        os.environ['OMP_DYNAMIC'] = 'false'
        os.environ['OMP_PROC_BIND'] = 'true'
        os.environ['OMP_PLACES'] = 'cores'
        
        print(f"[FortranSQS] OpenMP configured with {n_cores} threads")
        print(f"[FortranSQS] Neighbor cutoff: {neighbor_cutoff} Å")
        print(f"[FortranSQS] Number of shells: {n_shells}")
        
        self.lib = None
        self._loaded = False
        self._neighbor_lists = None  # Store neighbor lists for multi-shell
        self._load_library()
        
        # Build neighbor lists if positions are provided
        if positions is not None and lattice_vectors is not None:
            self._build_neighbor_lists()
    
    def _load_library(self):
        """Load Fortran shared library"""
        if lib_path.exists():
            try:
                self.lib = ctypes.CDLL(str(lib_path))
                self._setup_functions()
                self._loaded = True
                version = self.get_version()
                print(f"[Ok] Loaded Fortran SQS engine: {lib_path}")
                print(f"[Ok] Version: {version}")
            except Exception as e:
                print(f"[Warning] Failed to load Fortran SQS engine: {e}")
        else:
            print(f"[Warning] Fortran library not found at {lib_path}")
    
    def _setup_functions(self):
        """Setup ctypes function signatures"""
        
        # ===== Build Neighbor List =====
        if hasattr(self.lib, 'build_neighbor_list'):
            self.lib.build_neighbor_list.argtypes = [
                ctypes.c_int,                    # natoms
                ctypes.POINTER(ctypes.c_double), # positions (3, natoms) flattened
                ctypes.POINTER(ctypes.c_double), # cell (3, 3) flattened
                ctypes.c_double,                 # cutoff
                ctypes.c_void_p                  # neighbor_list pointer
            ]
            self.lib.build_neighbor_list.restype = None
        
        # ===== Pair Correlation Fast =====
        if hasattr(self.lib, 'pair_correlation_fast'):
            self.lib.pair_correlation_fast.argtypes = [
                ctypes.c_int,                    # natoms
                ctypes.POINTER(ctypes.c_int),    # spins
                ctypes.c_void_p,                 # neighbors_ptr
                ctypes.c_void_p,                 # counts_ptr
                ctypes.c_void_p,                 # offsets_ptr
                ctypes.POINTER(ctypes.c_double)  # correlation (output)
            ]
            self.lib.pair_correlation_fast.restype = None
        
        # ===== Compute Cluster Vector =====
        if hasattr(self.lib, 'compute_cluster_vector'):
            self.lib.compute_cluster_vector.argtypes = [
                ctypes.c_int,                    # natoms
                ctypes.POINTER(ctypes.c_int),    # spins
                ctypes.c_void_p,                 # neighbor_lists array
                ctypes.c_int,                    # n_shells
                ctypes.POINTER(ctypes.c_double)  # cluster_vector (output)
            ]
            self.lib.compute_cluster_vector.restype = None
        
        # ===== Objective Value Multi =====
        if hasattr(self.lib, 'objective_value_multi'):
            self.lib.objective_value_multi.argtypes = [
                ctypes.c_int,                    # natoms
                ctypes.POINTER(ctypes.c_int),    # spins
                ctypes.c_void_p,                 # neighbor_lists array
                ctypes.c_int,                    # n_shells
                ctypes.c_double,                 # composition
                ctypes.POINTER(ctypes.c_double)  # obj (output)
            ]
            self.lib.objective_value_multi.restype = None
        
        # ===== Random Search Fast =====
        if hasattr(self.lib, 'random_search_fast'):
            self.lib.random_search_fast.argtypes = [
                ctypes.c_int,                    # natoms
                ctypes.c_int,                    # n_B
                ctypes.c_int,                    # n_trials
                ctypes.c_double,                 # composition
                ctypes.POINTER(ctypes.c_int),    # best_spins
                ctypes.POINTER(ctypes.c_double), # best_objective
                ctypes.POINTER(ctypes.c_int),    # iterations
            ]
            self.lib.random_search_fast.restype = None
        
        # ===== Random Search Parallel =====
        if hasattr(self.lib, 'random_search_parallel'):
            self.lib.random_search_parallel.argtypes = [
                ctypes.c_int,                    # natoms
                ctypes.c_int,                    # n_B
                ctypes.c_int,                    # n_trials
                ctypes.c_double,                 # composition
                ctypes.POINTER(ctypes.c_int),    # best_spins
                ctypes.POINTER(ctypes.c_double), # best_objective
                ctypes.POINTER(ctypes.c_int),    # iterations
            ]
            self.lib.random_search_parallel.restype = None
        
        # ===== Simulated Annealing Fast =====
        if hasattr(self.lib, 'simulated_annealing_fast'):
            self.lib.simulated_annealing_fast.argtypes = [
                ctypes.c_int,                    # natoms
                ctypes.c_int,                    # n_B
                ctypes.c_double,                 # T_start
                ctypes.c_double,                 # T_end
                ctypes.c_int,                    # steps_per_T
                ctypes.c_double,                 # cooling_rate
                ctypes.c_double,                 # composition
                ctypes.POINTER(ctypes.c_int),    # best_spins
                ctypes.POINTER(ctypes.c_double), # best_objective
                ctypes.POINTER(ctypes.c_int),    # iterations
            ]
            self.lib.simulated_annealing_fast.restype = None
        
        # ===== Simulated Annealing Parallel =====
        if hasattr(self.lib, 'simulated_annealing_parallel'):
            self.lib.simulated_annealing_parallel.argtypes = [
                ctypes.c_int,                    # natoms
                ctypes.c_int,                    # n_B
                ctypes.c_double,                 # T_start
                ctypes.c_double,                 # T_end
                ctypes.c_int,                    # steps_per_T
                ctypes.c_double,                 # cooling_rate
                ctypes.c_double,                 # composition
                ctypes.c_void_p,                 # neighbor_lists
                ctypes.c_int,                    # n_shells
                ctypes.POINTER(ctypes.c_int),    # best_spins
                ctypes.POINTER(ctypes.c_double), # best_objective
                ctypes.POINTER(ctypes.c_int),    # iterations
            ]
            self.lib.simulated_annealing_parallel.restype = None
        
        # ===== Estimate Correlation =====
        if hasattr(self.lib, 'estimate_correlation'):
            self.lib.estimate_correlation.argtypes = [
                ctypes.c_int,                    # natoms
                ctypes.POINTER(ctypes.c_int),    # spins
                ctypes.c_double,                 # composition
                ctypes.POINTER(ctypes.c_double), # obj_value
            ]
            self.lib.estimate_correlation.restype = None
        
        # ===== Get Version =====
        if hasattr(self.lib, 'get_version'):
            self.lib.get_version.argtypes = [ctypes.c_char_p]
            self.lib.get_version.restype = None
    
    def _build_neighbor_lists(self):
        """Build neighbor lists for multiple shells using Fortran"""
        if not self._loaded or self.positions is None or self.lattice_vectors is None:
            return
        
        try:
            natoms = len(self.positions)
            
            # Flatten positions (3 x natoms) for Fortran
            positions_flat = np.ascontiguousarray(self.positions.T.flatten(), dtype=np.float64)
            positions_ptr = positions_flat.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
            
            # Flatten cell (3 x 3)
            cell_flat = np.ascontiguousarray(self.lattice_vectors.flatten(), dtype=np.float64)
            cell_ptr = cell_flat.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
            
            # Build neighbor list structure (simplified - store in instance)
            self._neighbor_lists = []
            
            for shell in range(self.n_shells):
                cutoff = self.neighbor_cutoff * (shell + 1)
                
                # For now, use Python to build neighbor lists
                # In production, this would call Fortran's build_neighbor_list
                neighbors = [[] for _ in range(natoms)]
                for i in range(natoms):
                    for j in range(natoms):
                        if i != j:
                            dx = self.positions[i][0] - self.positions[j][0]
                            dy = self.positions[i][1] - self.positions[j][1]
                            dz = self.positions[i][2] - self.positions[j][2]
                            
                            # Apply PBC
                            dx -= np.round(dx)
                            dy -= np.round(dy)
                            dz -= np.round(dz)
                            
                            # Transform to Cartesian
                            rvec = np.dot(self.lattice_vectors, [dx, dy, dz])
                            dist = np.sqrt(np.sum(rvec**2))
                            
                            if dist < cutoff and dist > 1e-8:
                                neighbors[i].append(j + 1)  # 1-based indexing for Fortran
            
                self._neighbor_lists.append(neighbors)
            
            print(f"[FortranSQS] Built {self.n_shells} neighbor shells")
            
        except Exception as e:
            print(f"[FortranSQS] Warning: Could not build neighbor lists: {e}")
            self._neighbor_lists = None
    
    def get_version(self) -> str:
        """Get Fortran library version"""
        if not self._loaded or not hasattr(self.lib, 'get_version'):
            return "Fortran engine not loaded"
        
        version_buf = ctypes.create_string_buffer(100)
        self.lib.get_version(version_buf)
        return version_buf.value.decode()
    
    def random_search(self, natoms: int, n_B: int = None, n_trials: int = 10000,
                    composition: float = None, use_parallel: bool = True,
                    early_stop: float = None, convergence_threshold: float = 0.15, 
                    callback: Optional[Callable] = None) -> FortranSQSResult:
        """
        Run random search optimization
        
        Args:
            natoms: Total number of atoms
            n_B: Number of B atoms (calculated from composition if None)
            n_trials: Number of random trials
            composition: Fraction of B atoms
            use_parallel: Use parallel version (OpenMP)
            early_stop: Early stopping threshold
            convergence_threshold: Threshold for convergence
            callback: Progress callback function
        """
        start_time = time.time()
        
        comp = composition if composition is not None else self.composition
        n_B_val = n_B if n_B is not None else int(natoms * comp + 0.5)  # Round to nearest integer
        
        print(f"[FortranSQS] random_search called with:")
        print(f"  natoms: {natoms}")
        print(f"  n_B_val: {n_B_val} (composition: {comp})")
        print(f"  n_trials: {n_trials}")
        print(f"  use_parallel: {use_parallel}")
        
        if not self._loaded:
            raise RuntimeError("Fortran library not loaded")
        
        # Prepare output arrays
        best_spins = (ctypes.c_int * natoms)()
        best_objective = ctypes.c_double(0.0)
        iterations = ctypes.c_int(0)
        
        if use_parallel and hasattr(self.lib, 'random_search_parallel'):
            print("[FortranSQS] Using random_search_parallel")
            self.lib.random_search_parallel(
                ctypes.c_int(natoms),
                ctypes.c_int(n_B_val),
                ctypes.c_int(n_trials),
                ctypes.c_double(comp),
                best_spins,
                ctypes.byref(best_objective),
                ctypes.byref(iterations)
            )
        else:
            print("[FortranSQS] Using random_search_fast")
            self.lib.random_search_fast(
                ctypes.c_int(natoms),
                ctypes.c_int(n_B_val),
                ctypes.c_int(n_trials),
                ctypes.c_double(comp),
                best_spins,
                ctypes.byref(best_objective),
                ctypes.byref(iterations)
            )
        
        if callback:
            callback(n_trials, best_objective.value)
        
        spins_list = [best_spins[i] for i in range(natoms)]
        n_B_result = sum(1 for s in spins_list if s == 1)
        print(f"[FortranSQS] Result has {n_B_result} B atoms (expected {n_B_val})")
        print(f"[FortranSQS] Objective: {best_objective.value:.6f}")
        
        return FortranSQSResult(
            spins=spins_list,
            objective_value=best_objective.value,
            iterations=iterations.value,
            method='Random Search (Fortran)',
            time_seconds=time.time() - start_time,
            converged=best_objective.value < convergence_threshold,
            correlations={
                'pairs': {1: best_objective.value, 2: 0.0, 3: 0.0, 4: 0.0},
                'objective': best_objective.value,
                'iterations': iterations.value
            }
        )
    
    def simulated_annealing(self, natoms: int, n_B: int = None,
                        T_start: float = 1.0, T_end: float = 0.01,
                        steps_per_T: int = 1000, cooling_rate: float = 0.95,
                        composition: float = None, use_parallel: bool = True,
                        convergence_threshold: float = 0.15, 
                        callback: Optional[Callable] = None) -> FortranSQSResult:
        """
        Run simulated annealing optimization
        
        Args:
            natoms: Total number of atoms
            n_B: Number of B atoms (calculated from composition if None)
            T_start: Starting temperature
            T_end: Ending temperature
            steps_per_T: Steps per temperature
            cooling_rate: Cooling rate
            composition: Fraction of B atoms
            use_parallel: Use parallel version (OpenMP)
            convergence_threshold: Threshold for convergence
            callback: Progress callback function
        """
        start_time = time.time()
        
        comp = composition if composition is not None else self.composition
        n_B_val = n_B if n_B is not None else int(natoms * comp + 0.5)
        
        print(f"[FortranSQS] simulated_annealing called with:")
        print(f"  natoms: {natoms}")
        print(f"  n_B_val: {n_B_val} (composition: {comp})")
        print(f"  T_start: {T_start}, T_end: {T_end}")
        print(f"  steps_per_T: {steps_per_T}, cooling_rate: {cooling_rate}")
        print(f"  use_parallel: {use_parallel}")
        
        if not self._loaded:
            raise RuntimeError("Fortran library not loaded")
        
        # Prepare output arrays
        best_spins = (ctypes.c_int * natoms)()
        best_objective = ctypes.c_double(0.0)
        iterations = ctypes.c_int(0)
        
        # Prepare neighbor lists for multi-shell support if available
        neighbor_lists_ptr = ctypes.c_void_p(0)
        
        if use_parallel and hasattr(self.lib, 'simulated_annealing_parallel'):
            print("[FortranSQS] Using simulated_annealing_parallel with neighbor lists")
            
            # Pass neighbor list structure (simplified - in production, pass actual pointer)
            self.lib.simulated_annealing_parallel(
                ctypes.c_int(natoms),
                ctypes.c_int(n_B_val),
                ctypes.c_double(T_start),
                ctypes.c_double(T_end),
                ctypes.c_int(steps_per_T),
                ctypes.c_double(cooling_rate),
                ctypes.c_double(comp),
                neighbor_lists_ptr,
                ctypes.c_int(self.n_shells),
                best_spins,
                ctypes.byref(best_objective),
                ctypes.byref(iterations)
            )
        else:
            print("[FortranSQS] Using simulated_annealing_fast")
            self.lib.simulated_annealing_fast(
                ctypes.c_int(natoms),
                ctypes.c_int(n_B_val),
                ctypes.c_double(T_start),
                ctypes.c_double(T_end),
                ctypes.c_int(steps_per_T),
                ctypes.c_double(cooling_rate),
                ctypes.c_double(comp),
                best_spins,
                ctypes.byref(best_objective),
                ctypes.byref(iterations)
            )
        
        if callback:
            callback(iterations.value, best_objective.value)
        
        spins_list = [best_spins[i] for i in range(natoms)]
        n_B_result = sum(1 for s in spins_list if s == 1)
        print(f"[FortranSQS] Result has {n_B_result} B atoms (expected {n_B_val})")
        print(f"[FortranSQS] Objective: {best_objective.value:.6f}")
        print(f"[FortranSQS] Iterations: {iterations.value}")
        
        return FortranSQSResult(
            spins=spins_list,
            objective_value=best_objective.value,
            iterations=iterations.value,
            method='Simulated Annealing (Fortran)',
            time_seconds=time.time() - start_time,
            converged=best_objective.value < convergence_threshold,
            correlations={
                'pairs': {1: best_objective.value, 2: 0.0, 3: 0.0, 4: 0.0},
                'objective': best_objective.value,
                'iterations': iterations.value
            }
        )
    
    def calculate_objective(self, spins: List[int], composition: float = None, 
                           use_neighbors: bool = True) -> float:
        """Calculate objective function for a spin configuration"""
        if not self._loaded:
            raise RuntimeError("Fortran library not loaded")
        
        natoms = len(spins)
        comp = composition if composition is not None else self.composition
        
        # Convert spins to ctypes array
        spins_array = (ctypes.c_int * natoms)(*spins)
        obj_value = ctypes.c_double(0.0)
        
        # Use neighbor list version if available
        if use_neighbors and hasattr(self.lib, 'objective_value_multi') and self._neighbor_lists:
            # Would need to pass neighbor lists - simplified for now
            self.lib.estimate_correlation(
                ctypes.c_int(natoms),
                spins_array,
                ctypes.c_double(comp),
                ctypes.byref(obj_value)
            )
        elif hasattr(self.lib, 'estimate_correlation'):
            self.lib.estimate_correlation(
                ctypes.c_int(natoms),
                spins_array,
                ctypes.c_double(comp),
                ctypes.byref(obj_value)
            )
        elif hasattr(self.lib, 'calculate_objective'):
            self.lib.calculate_objective(
                ctypes.c_int(natoms),
                spins_array,
                ctypes.c_double(comp),
                ctypes.byref(obj_value)
            )
        else:
            # Fallback to Python calculation
            n_B = sum(spins)  # spins are +1 for B, -1 for A
            comp_actual = (n_B + natoms) / (2 * natoms)  # Convert to composition
            obj_value.value = abs(comp_actual - comp)
        
        return obj_value.value
    
    def spins_to_elements(self, spins: List[int]) -> List[str]:
        """Convert spin configuration to element symbols"""
        return [self.element_B if s == 1 else self.element_A for s in spins]
    
    def objective(self, spins: List[int]) -> float:
        """Compatibility method for sqs_engine interface"""
        return self.calculate_objective(spins)
    
    def get_configuration(self) -> Tuple[np.ndarray, List[str]]:
        """Get current best configuration"""
        # This would be set by the optimization methods
        if hasattr(self, '_best_spins'):
            elements = self.spins_to_elements(self._best_spins)
            if self.positions is not None:
                cart_positions = np.dot(self.positions, self.lattice_vectors)
                return cart_positions, elements
        return None, None
    
    @property
    def is_available(self) -> bool:
        return self._loaded


# Global instance management
_fortran_engine = None


def get_fortran_engine(lattice_vectors: np.ndarray = None, positions: np.ndarray = None,
                       element_A: str = 'A', element_B: str = 'B',
                       composition: float = 0.5, neighbor_cutoff: float = 2.5,
                       n_shells: int = 4, seed: Optional[int] = None) -> Optional[FortranSQSEngine]:
    """Get or create Fortran SQS engine instance"""
    global _fortran_engine
    if _fortran_engine is None:
        _fortran_engine = FortranSQSEngine(lattice_vectors, positions, element_A, element_B, 
                                            composition, neighbor_cutoff, n_shells, seed)
    return _fortran_engine if _fortran_engine.is_available else None


def cleanup_fortran_engine():
    """Clean up Fortran engine instance"""
    global _fortran_engine
    _fortran_engine = None