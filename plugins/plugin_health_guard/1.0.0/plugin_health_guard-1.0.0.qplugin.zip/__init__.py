"""Plugin Health Guard - a headless QAH maintenance plugin.

Runs a plugin-manifest health check shortly after QAH starts, writes a JSON
report, and exposes two menu actions. It deliberately has no widget: the value
is a zero-click startup check and a machine-readable report for support/CI.

GPLv3 or later.
"""

from __future__ import annotations

import json
import logging
import os
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Tuple

from PySide6.QtCore import QObject, QTimer, QUrl
from PySide6.QtGui import QAction, QDesktopServices, QIcon
from PySide6.QtWidgets import QWidget

try:
    from plugins.libs import plugin_manager, plugin_paths
except Exception:
    plugin_manager = None
    plugin_paths = None

ID_RE = re.compile(r"^[a-z][a-z0-9_]{2,63}$")
VERSION_RE = re.compile(r"^\d+\.\d+(?:\.\d+)?(?:[-+][0-9A-Za-z.-]+)?$")
SKIP = {"__pycache__", ".git", "build", "dist", "target", ".venv"}


def _state_dir() -> Path:
    root = Path.home() / "QAH" / "plugin_health_guard"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _system_dir() -> Path:
    if plugin_manager is not None:
        try:
            return Path(plugin_manager.__file__).resolve().parents[1] / "python_plugins"
        except Exception:
            pass
    return Path(__file__).resolve().parents[1]


def _plugin_roots() -> List[Tuple[Path, str]]:
    if plugin_paths is not None:
        try:
            user = Path(plugin_paths.classic_plugins_dir())
            wheels = Path(plugin_paths.wheels_dir())
        except Exception:
            user = Path.home() / "QAH" / "plugins" / "python_plugins"
            wheels = Path.home() / "QAH" / "plugins" / "wheels"
    else:
        user = Path.home() / "QAH" / "plugins" / "python_plugins"
        wheels = Path.home() / "QAH" / "plugins" / "wheels"
    roots: List[Tuple[Path, str]] = []
    seen = set()

    def add(path: Path, source: str):
        try:
            key = str(path.resolve())
        except OSError:
            key = str(path)
        if key in seen:
            return
        seen.add(key)
        roots.append((path, source))

    for base, source in ((user, "user"), (_system_dir(), "system")):
        base = Path(base)
        if not base.is_dir():
            continue
        found: List[Path] = []
        for current_root, dirs, files in os.walk(base):
            current = Path(current_root)
            try:
                depth = len(current.relative_to(base).parts)
            except ValueError:
                continue
            if depth > 8:
                dirs[:] = []
                continue
            dirs[:] = [name for name in dirs if not name.startswith((".", "_")) and name not in SKIP]
            if current != base and "manifest.json" in files:
                found.append(current)
                dirs[:] = []
        for path in found:
            add(path, source)
        # Legacy top-level package without a manifest.
        try:
            children = sorted(base.iterdir())
        except OSError:
            continue
        for child in children:
            if not child.is_dir() or child.name.startswith((".", "_")) or child.name in SKIP:
                continue
            if (child / "manifest.json").is_file() or not (child / "__init__.py").is_file():
                continue
            if any(str(item.resolve()).startswith(str(child.resolve()) + os.sep) for item in found):
                continue
            add(child, source)

    try:
        wheel_children = sorted(Path(wheels).iterdir())
    except OSError:
        wheel_children = []
    for child in wheel_children:
        if child.is_dir() and not child.name.startswith((".", "_")):
            add(child, "wheel")
        elif child.suffix.lower() == ".whl":
            add(child, "wheel")
    return roots


class PluginHealthGuard(QObject):
    def __init__(self, plugin_info):
        super().__init__()
        self.plugin_info = plugin_info
        self.report_path = _state_dir() / "health.json"
        self.icon = None
        icon_path = Path(__file__).parent / "icon.svg"
        if icon_path.is_file():
            self.icon = QIcon(str(icon_path))
        self._last_report: Dict[str, Any] = {}

    # -- QAH lifecycle ---------------------------------------------------
    def initialize(self) -> bool:
        logging.info("Initializing %s v%s", self.plugin_info.name, self.plugin_info.version)
        QTimer.singleShot(1500, self._startup_check)
        return True

    def get_widget(self) -> None:
        """This plugin is intentionally headless."""
        return None

    def get_menu_actions(self):
        check = QAction("Run plugin health check", self)
        if self.icon is not None:
            check.setIcon(self.icon)
        check.triggered.connect(lambda _checked=False: self.run_check())
        report = QAction("Open health report", self)
        report.triggered.connect(lambda _checked=False: self.open_report())
        return [check, report]

    def cleanup(self):
        pass

    # -- check -----------------------------------------------------------
    def _startup_check(self):
        try:
            report = self.run_check()
            issues = report.get("counts", {}).get("issues", 0)
            if issues:
                logging.warning("Plugin Health Guard: %s issue(s) found; report: %s", issues, self.report_path)
            else:
                logging.info("Plugin Health Guard: plugin manifests look healthy.")
        except Exception:
            logging.exception("Plugin Health Guard startup check failed")

    def run_check(self) -> Dict[str, Any]:
        started = time.time()
        plugins: List[Dict[str, Any]] = []
        issues: List[Dict[str, Any]] = []
        by_id: Dict[str, List[Dict[str, Any]]] = {}

        for path, source in _plugin_roots():
            record = self._inspect_plugin(path, source, issues)
            plugins.append(record)
            if record.get("id"):
                by_id.setdefault(record["id"], []).append(record)

        for plugin_id, group in by_id.items():
            if len(group) < 2:
                continue
            sources = ", ".join(sorted({str(item.get("source")) for item in group}))
            for record in group:
                issues.append({
                    "severity": "high",
                    "code": "duplicate.id",
                    "message": f"Plugin id {plugin_id!r} is installed more than once ({sources})",
                    "path": record.get("path", ""),
                    "source": record.get("source", ""),
                })

        counts = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
        for issue in issues:
            counts[issue.get("severity", "info")] = counts.get(issue.get("severity", "info"), 0) + 1
        report = {
            "format": "qah-plugin-health",
            "version": 1,
            "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "duration": round(time.time() - started, 3),
            "counts": {
                "plugins": len(plugins),
                "issues": len(issues),
                **counts,
            },
            "plugins": plugins,
            "issues": issues,
        }
        self._last_report = report
        try:
            self.report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
        except Exception:
            logging.exception("Could not write Plugin Health Guard report")
        return report

    def _inspect_plugin(self, path: Path, source: str, issues: List[Dict[str, Any]]) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "path": str(path),
            "source": source,
            "name": path.name,
            "id": "",
            "version": "",
        }
        manifest_path = path / "manifest.json"
        if not manifest_path.is_file():
            issues.append({
                "severity": "low", "code": "manifest.missing",
                "message": "Plugin folder has no manifest.json",
                "path": str(path), "source": source,
            })
            return record
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception as exc:
            issues.append({
                "severity": "critical", "code": "manifest.invalid",
                "message": f"manifest.json is not valid JSON: {exc}",
                "path": str(path), "source": source,
            })
            return record
        if not isinstance(manifest, dict):
            issues.append({
                "severity": "critical", "code": "manifest.invalid",
                "message": "manifest.json is not an object",
                "path": str(path), "source": source,
            })
            return record
        plugin_id = str(manifest.get("id") or "")
        name = str(manifest.get("name") or path.name)
        version = str(manifest.get("version") or "")
        main = str(manifest.get("main") or "")
        author = str(manifest.get("author") or "")
        description = str(manifest.get("description") or "")
        record.update({"id": plugin_id, "name": name, "version": version})

        if not ID_RE.fullmatch(plugin_id):
            issues.append({
                "severity": "medium", "code": "manifest.id",
                "message": f"Invalid or missing plugin id: {plugin_id!r}",
                "path": str(path), "source": source,
            })
        if not VERSION_RE.fullmatch(version):
            issues.append({
                "severity": "low", "code": "manifest.version",
                "message": f"Version is not semver-like: {version!r}",
                "path": str(path), "source": source,
            })
        if not name:
            issues.append({"severity": "low", "code": "manifest.name", "message": "Missing display name", "path": str(path), "source": source})
        if not author:
            issues.append({"severity": "low", "code": "manifest.author", "message": "Missing author", "path": str(path), "source": source})
        if not description:
            issues.append({"severity": "info", "code": "manifest.description", "message": "Missing description", "path": str(path), "source": source})
        if not main:
            issues.append({"severity": "medium", "code": "manifest.main", "message": "Missing main entry point", "path": str(path), "source": source})
        elif not (path / main).is_file():
            issues.append({"severity": "high", "code": "manifest.main_missing", "message": f"Main file not found: {main}", "path": str(path), "source": source})
        icon = str(manifest.get("icon") or "")
        if icon and not (path / icon).is_file():
            issues.append({"severity": "low", "code": "manifest.icon_missing", "message": f"Icon not found: {icon}", "path": str(path), "source": source})
        deps = manifest.get("dependencies") or []
        if isinstance(deps, list):
            for dep in deps:
                text = str(dep)
                if re.match(r"^(?:git\+|https?://|ssh://|file:|\.{0,2}/)", text):
                    issues.append({"severity": "high", "code": "manifest.unsafe_dependency", "message": f"URL/VCS/local dependency: {text}", "path": str(path), "source": source})
        for file in path.rglob("*"):
            lower = file.name.lower()
            if lower.endswith((".stable", ".old")):
                issues.append({"severity": "medium", "code": "plugin.backup", "message": f"Backup file present: {file.relative_to(path)}", "path": str(path), "source": source})
            elif "__pycache__" in file.parts or lower.endswith((".pyc", ".pyo")):
                issues.append({"severity": "info", "code": "plugin.bytecode", "message": f"Stale bytecode: {file.relative_to(path)}", "path": str(path), "source": source})
        return record

    # -- action ----------------------------------------------------------
    def open_report(self):
        if not self.report_path.is_file():
            self.run_check()
        if self.report_path.is_file():
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.report_path)))


Plugin = PluginHealthGuard
