"""Public, read-only API for Plugin Health Guard reports.

Other plugins can read the latest health report without loading the headless
Health Guard plugin:

    from plugin_health_guard import health_api
    report = health_api.load_report()
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict


def report_path() -> Path:
    return Path.home() / "QAH" / "plugin_health_guard" / "health.json"


def load_report() -> Dict[str, Any]:
    path = report_path()
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def summary() -> Dict[str, Any]:
    report = load_report()
    counts = report.get("counts") or {}
    return {
        "generated_at": report.get("generated_at", ""),
        "plugins": int(counts.get("plugins", 0) or 0),
        "issues": int(counts.get("issues", 0) or 0),
        "critical": int(counts.get("critical", 0) or 0),
        "high": int(counts.get("high", 0) or 0),
        "medium": int(counts.get("medium", 0) or 0),
        "low": int(counts.get("low", 0) or 0),
        "info": int(counts.get("info", 0) or 0),
    }
