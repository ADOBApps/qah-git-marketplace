# Geometry sources

The `.xyz` files in this folder are PubChem 3D conformers converted from the
corresponding PubChem Compound records. PubChem data is public data.

| File | PubChem CID | Compound |
|---|---|---|
| `water.xyz` | 962 | Water |
| `benzene.xyz` | 241 | Benzene |
| `caffeine.xyz` | 2519 | Caffeine |
| `estrone.xyz` | 5870 | Estrone (E1) |
| `estradiol.xyz` | 5757 | 17β-Estradiol (E2) |
| `ethinylestradiol.xyz` | 5991 | Ethinylestradiol (EE2) |
| `estriol.xyz` | 5756 | Estriol (E3) |
| `testosterone.xyz` | 6013 | Testosterone |
| `progesterone.xyz` | 5994 | Progesterone |

Water and benzene are the reference geometries shipped with PyQInt.

These are starting geometries for single-point calculations. The plugin does not
optimize them, add solvent, or apply dispersion corrections.
