# pydft_molecule_lab/__init__.py
"""PyDFT Molecule Lab — pydft electronic-structure analysis for QAH.

Runs single-point pydft Kohn-Sham calculations on small organic molecules,
reports HOMO/LUMO and derived descriptors, and draws molecular-orbital slices.

The plugin loads without pydft and shows a dependency panel until the user
injects it with Wheel Plugin Manager.

GPLv3 or later.
"""

from __future__ import annotations

import importlib
import importlib.util
import logging
import os
import sys
from pathlib import Path
from typing import Optional

# Bound native thread pools before pydft/pyqint are imported anywhere in QAH.
for _key in (
    "OMP_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "MKL_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "NUMBA_NUM_THREADS",
):
    os.environ.setdefault(_key, "1")

from PySide6.QtCore import QObject
from PySide6.QtGui import QAction, QIcon
from PySide6.QtWidgets import QWidget

try:
    from plugins.libs.plugin_manager import PluginInfo
except Exception:
    PluginInfo = object  # type: ignore


def _load_sibling(name: str):
    try:
        return importlib.import_module(f"{__name__}.{name}")
    except ImportError:
        path = Path(__file__).parent / f"{name}.py"
        spec = importlib.util.spec_from_file_location(f"{__name__}_{name}", path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        return module


class PyDFTMoleculeLabPlugin(QObject):
    def __init__(self, plugin_info: PluginInfo):
        super().__init__()
        self.plugin_info = plugin_info
        self.ui_widget: Optional[QWidget] = None
        self.icon: Optional[QIcon] = None
        icon_path = Path(__file__).parent / "icon.svg"
        if icon_path.is_file():
            self.icon = QIcon(str(icon_path))

    def initialize(self) -> bool:
        logging.info(
            "Initializing %s v%s",
            getattr(self.plugin_info, "name", "PyDFT Molecule Lab"),
            getattr(self.plugin_info, "version", "?"),
        )
        return True

    def get_widget(self) -> Optional[QWidget]:
        if self.ui_widget is None:
            try:
                ui = _load_sibling("molecule_lab_widget")
                self.ui_widget = ui.MoleculeLabWidget(self)
            except Exception as exc:
                logging.error("Could not build PyDFT Molecule Lab: %s", exc)
                logging.debug("Traceback", exc_info=True)
                return None
        return self.ui_widget

    def get_menu_actions(self):
        action = QAction("PyDFT Molecule Lab", self)
        if self.icon is not None:
            action.setIcon(self.icon)
        action.setToolTip("pydft electronic structure and orbital plots for small molecules")
        return [action]

    def cleanup(self):
        if self.ui_widget is not None:
            try:
                if hasattr(self.ui_widget, "cleanup"):
                    self.ui_widget.cleanup()
            finally:
                self.ui_widget.deleteLater()
                self.ui_widget = None


Plugin = PyDFTMoleculeLabPlugin
