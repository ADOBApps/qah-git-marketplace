"""PyDFT Molecule Lab engine.

pydft/pyqint electronic-structure calculations for small organic molecules.
The module is deliberately Qt-free so the UI can call it from a worker thread.

Resource defaults:
* one native thread unless the user changes it,
* bounded SCF iterations,
* a stop flag checked between SCF iterations,
* no implicit calculation on plugin load.
"""

from __future__ import annotations

import importlib
import math
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

PLUGIN_DIR = Path(__file__).resolve().parent
MOLECULE_DIR = PLUGIN_DIR / "molecules"

BOHR_TO_ANGSTROM = 0.529177210903
HARTREE_TO_EV = 27.211386245988
AU_TO_DEBYE = 2.541746473

MOLECULES: List[Dict[str, Any]] = [
    {
        "id": "water",
        "name": "Water",
        "formula": "H2O",
        "family": "Reference",
        "cid": 962,
        "atoms": 3,
        "load": "tiny",
        "note": "Fast smoke test. Start here before running a hormone.",
    },
    {
        "id": "benzene",
        "name": "Benzene",
        "formula": "C6H6",
        "family": "Aromatic reference",
        "cid": 241,
        "atoms": 12,
        "load": "small",
        "note": "Small aromatic reference for orbital and gap checks.",
    },
    {
        "id": "caffeine",
        "name": "Caffeine",
        "formula": "C8H10N4O2",
        "family": "Alkaloid",
        "cid": 2519,
        "atoms": 24,
        "load": "moderate",
        "note": "Heteroatom-rich organic test molecule.",
    },
    {
        "id": "estrone",
        "name": "Estrone (E1)",
        "formula": "C18H22O2",
        "family": "Hormone",
        "cid": 5870,
        "atoms": 42,
        "load": "heavy",
        "note": "Estrogen-family hormone. Heavy for educational DFT.",
    },
    {
        "id": "estradiol",
        "name": "17β-Estradiol (E2)",
        "formula": "C18H24O2",
        "family": "Hormone",
        "cid": 5757,
        "atoms": 44,
        "load": "heavy",
        "note": "Primary estrogen. Run under a temperature watchdog.",
    },
    {
        "id": "ethinylestradiol",
        "name": "Ethinylestradiol (EE2)",
        "formula": "C20H24O2",
        "family": "Hormone",
        "cid": 5991,
        "atoms": 46,
        "load": "heavy",
        "note": "Synthetic estrogen. Heaviest molecule in this library.",
    },
    {
        "id": "estriol",
        "name": "Estriol (E3)",
        "formula": "C18H24O3",
        "family": "Hormone",
        "cid": 5756,
        "atoms": 45,
        "load": "heavy",
        "note": "Estrogen metabolite with three hydroxyl groups.",
    },
    {
        "id": "testosterone",
        "name": "Testosterone",
        "formula": "C19H28O2",
        "family": "Hormone",
        "cid": 6013,
        "atoms": 49,
        "load": "heavy",
        "note": "Androgen reference structure.",
    },
    {
        "id": "progesterone",
        "name": "Progesterone",
        "formula": "C21H30O2",
        "family": "Hormone",
        "cid": 5994,
        "atoms": 53,
        "load": "heavy",
        "note": "Largest molecule in this starter library.",
    },
]

MOLECULE_BY_ID = {item["id"]: item for item in MOLECULES}

BASIS_CHOICES = [
    ("STO-3G (fast, recommended)", "sto3g"),
    ("STO-6G (slower)", "sto6g"),
    ("3-21G (heavy; small molecules only)", "p321"),
]

FUNCTIONAL_CHOICES = [
    ("SVWN5 (LDA)", "svwn5"),
    ("SVWN3 (LDA)", "svwn3"),
    ("PBE (GGA)", "pbe"),
]

GRID_CHOICES = [
    ("Low-power (fastest; qualitative)", "low", 18, 38),
    ("Balanced", "balanced", 20, 50),
    ("Accurate (slowest; hotter)", "accurate", 25, 110),
]

_ACTIVE_THREADS = 1


def qah_home() -> Path:
    for parent in Path(__file__).resolve().parents:
        if (parent / "plugins" / "vendor").is_dir():
            return parent
    return Path.home() / "QAH"


def vendor_targets() -> List[Path]:
    root = qah_home() / "plugins" / "vendor"
    return [root / "pydft_molecule_lab", root / "global"]


def total_threads() -> int:
    """Return the number of logical CPU threads reported by the OS."""
    return max(1, int(os.cpu_count() or 1))


def set_thread_budget(threads: int = 1) -> None:
    """Bound native thread pools before pydft/pyqint are imported.

    Changing this after pyqint has been loaded may require a QAH restart.
    """
    global _ACTIVE_THREADS
    _ACTIVE_THREADS = max(1, min(int(threads or 1), total_threads()))
    value = str(_ACTIVE_THREADS)
    for key in (
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
        "VECLIB_MAXIMUM_THREADS",
        "NUMBA_NUM_THREADS",
    ):
        os.environ[key] = value


def activate_vendor(threads: Optional[int] = None) -> List[str]:
    if threads is not None:
        set_thread_budget(threads)
    added: List[str] = []
    for path in vendor_targets():
        if path.is_dir() and str(path) not in sys.path:
            sys.path.insert(0, str(path))
            added.append(str(path))
    if added:
        importlib.invalidate_caches()
    return added


def probe_dependencies(threads: Optional[int] = None) -> Dict[str, Any]:
    activate_vendor(threads)
    result: Dict[str, Any] = {
        "ok": False,
        "error": "",
        "python": sys.version.split()[0],
        "versions": {},
        "vendor": [str(path) for path in vendor_targets() if path.is_dir()],
        "threads": _ACTIVE_THREADS,
        "total_threads": total_threads(),
    }
    try:
        import numpy
        import pydft
        import pyqint
        import scipy

        result["versions"] = {
            "pydft": getattr(pydft, "__version__", "?"),
            "pyqint": getattr(pyqint, "__version__", "?"),
            "numpy": getattr(numpy, "__version__", "?"),
            "scipy": getattr(scipy, "__version__", "?"),
        }
        try:
            import matplotlib

            result["versions"]["matplotlib"] = getattr(matplotlib, "__version__", "?")
        except Exception:
            result["versions"]["matplotlib"] = "missing"
        result["ok"] = True
        result["plots"] = result["versions"]["matplotlib"] != "missing"
        result["pydft_file"] = getattr(pydft, "__file__", "")
    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
    return result


def molecule_path(molecule_id: str) -> Path:
    return MOLECULE_DIR / f"{molecule_id}.xyz"


def xyz_summary(path: os.PathLike | str) -> Dict[str, Any]:
    path = Path(path)
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    if len(lines) < 3:
        raise ValueError(f"Not an XYZ file: {path}")
    count = int(lines[0].strip())
    symbols: List[str] = []
    for line in lines[2 : 2 + count]:
        parts = line.split()
        if len(parts) < 4:
            raise ValueError(f"Bad atom line in {path}: {line!r}")
        symbols.append(parts[0])
    formula = ""
    for symbol in sorted(set(symbols)):
        formula += symbol
        amount = symbols.count(symbol)
        if amount > 1:
            formula += str(amount)
    return {
        "path": str(path),
        "name": lines[1].strip() or path.stem,
        "atoms": count,
        "formula": formula,
        "symbols": symbols,
    }


def load_molecule(molecule_id: str):
    activate_vendor()
    from pyqint import MoleculeBuilder

    return MoleculeBuilder.from_file(str(molecule_path(molecule_id)))


def molecule_info(molecule_id: str) -> Dict[str, Any]:
    item = dict(MOLECULE_BY_ID.get(molecule_id) or {})
    path = molecule_path(molecule_id)
    if path.is_file():
        summary = xyz_summary(path)
        item.setdefault("name", summary["name"])
        item.setdefault("formula", summary["formula"])
        item["atoms"] = summary["atoms"]
        item["path"] = str(path)
    return item


def _core_guess(dft) -> None:
    """Seed pydft with a core-Hamiltonian density instead of a zero matrix."""
    import numpy as np

    S = dft._DFT__S
    H = dft._DFT__T + dft._DFT__V
    s, U = np.linalg.eigh(S)
    keep = s > 1e-8
    X = U[:, keep] / np.sqrt(s[keep])
    _, C = np.linalg.eigh(X.T @ H @ X)
    C = X @ C
    nocc = int(dft._DFT__nelec) // 2
    dft._DFT__P = 2.0 * C[:, :nocc] @ C[:, :nocc].T


def _run_scf(
    dft,
    tolerance: float,
    max_iter: int,
    stop_event=None,
    progress=None,
    cooldown: float = 0.0,
) -> Dict[str, Any]:
    """Run SCF with a core guess and a stop check between iterations.

    Falls back to the public ``DFT.scf`` if pydft's private layout changes.
    """
    setup = getattr(dft, "_DFT__setup", None)
    iterate = getattr(dft, "_DFT__iterate", None)
    if setup is None or iterate is None:
        try:
            setattr(dft, "_DFT__itermax", max(1, int(max_iter)))
        except Exception:
            pass
        result = dft.scf(tolerance)
        return {
            "result": result,
            "converged": True,
            "iterations": len(result.get("energies") or []),
            "stopped": "",
            "energies": list(result.get("energies") or []),
        }

    setup()
    try:
        _core_guess(dft)
    except Exception:
        import numpy as np

        dft._DFT__P = np.zeros_like(dft._DFT__S)

    dft._DFT__energies = []
    energies: List[float] = []
    previous: Optional[float] = None
    stable = 0
    converged = False
    stopped = ""
    for niter in range(max(1, int(max_iter))):
        if stop_event is not None and stop_event.is_set():
            stopped = "cancelled"
            break
        energy = float(iterate(niter, giis=(stable == 0), mix=0.9))
        energies.append(energy)
        dft._DFT__energies.append(energy)
        if progress is not None:
            progress(niter + 1, energy)
        if previous is not None:
            if abs(energy - previous) < tolerance:
                stable += 1
                if stable >= 2:
                    converged = True
                    break
            else:
                stable = 0
        previous = energy
        if cooldown:
            time.sleep(cooldown)

    calculate_p = getattr(dft, "_DFT__calculate_P", None)
    if calculate_p is not None:
        try:
            dft._DFT__P = calculate_p()
        except Exception:
            pass
    return {
        "result": dft.get_data(),
        "converged": converged,
        "iterations": len(energies),
        "stopped": stopped,
        "energies": energies,
    }


def _mulliken(res) -> List[Dict[str, Any]]:
    from pyqint import PopulationAnalysis

    try:
        analysis = PopulationAnalysis(res)
        charges = []
        for index, (position, charge) in enumerate(res["nuclei"]):
            symbol = _symbol_for_charge(int(charge))
            charges.append(
                {
                    "index": index,
                    "symbol": symbol,
                    "nuclear_charge": int(charge),
                    "mulliken": float(analysis.mulliken(index)),
                }
            )
        return charges
    except Exception:
        return []


_ELEMENT_BY_Z = {
    1: "H", 2: "He", 3: "Li", 4: "Be", 5: "B", 6: "C", 7: "N", 8: "O",
    9: "F", 10: "Ne", 11: "Na", 12: "Mg", 13: "Al", 14: "Si", 15: "P",
    16: "S", 17: "Cl", 18: "Ar", 19: "K", 20: "Ca", 26: "Fe", 29: "Cu",
    30: "Zn", 35: "Br", 53: "I",
}


def _symbol_for_charge(charge: int) -> str:
    return _ELEMENT_BY_Z.get(int(charge), str(charge))


def _dipole(res) -> Dict[str, Any]:
    """Electronic + nuclear dipole from density-matrix dipole integrals."""
    import numpy as np
    from pyqint import PyQInt

    try:
        integrator = PyQInt()
        cgfs = res["cgfs"]
        density = res["density"]
        count = len(cgfs)
        electronic = np.zeros(3)
        for i in range(count):
            for j in range(i, count):
                weight = float(density[i, j])
                if abs(weight) < 1e-12:
                    continue
                factor = 1.0 if i == j else 2.0
                for component in range(3):
                    electronic[component] -= (
                        factor
                        * weight
                        * float(integrator.dipole(cgfs[i], cgfs[j], component))
                    )
        nuclear = np.zeros(3)
        for position, charge in res["nuclei"]:
            nuclear += float(charge) * np.asarray(position, dtype=float)
        vector = electronic + nuclear
        return {
            "vector_au": [float(v) for v in vector],
            "vector_debye": [float(v) * AU_TO_DEBYE for v in vector],
            "magnitude_debye": float(np.linalg.norm(vector)) * AU_TO_DEBYE,
        }
    except Exception:
        return {}


def best_fit_plane(atoms) -> Tuple[Any, Any, Any, Any]:
    """Return centroid, in-plane axes and normal for the heavy-atom frame."""
    import numpy as np

    points = [np.asarray(position, dtype=float) for symbol, position in atoms if symbol != "H"]
    if len(points) < 3:
        points = [np.asarray(position, dtype=float) for _, position in atoms]
    data = np.asarray(points)
    center = data.mean(axis=0)
    _, _, vt = np.linalg.svd(data - center, full_matrices=False)
    if vt.shape[0] < 2:
        axis_u = np.array([1.0, 0.0, 0.0])
        axis_v = np.array([0.0, 1.0, 0.0])
        normal = np.cross(axis_u, axis_v)
    else:
        axis_u = vt[0]
        axis_v = vt[1] if vt.shape[0] > 1 else np.cross(vt[0], [0, 0, 1])
        normal = np.cross(axis_u, axis_v)
        norm = np.linalg.norm(normal)
        normal = normal / norm if norm else np.array([0.0, 0.0, 1.0])
    return center, axis_u, axis_v, normal


def orbital_slice(
    res,
    orbital_index: int,
    grid_points: int = 55,
    margin: float = 2.6,
) -> Dict[str, Any]:
    """Evaluate one molecular orbital on a best-fit molecular plane."""
    import numpy as np
    from pyqint import PyQInt

    atoms = []
    for position, charge in res["nuclei"]:
        symbol = _symbol_for_charge(int(charge))
        atoms.append((symbol, np.asarray(position, dtype=float)))
    center, axis_u, axis_v, normal = best_fit_plane(atoms)
    projected = []
    extent = 0.0
    for symbol, position in atoms:
        delta = position - center
        u = float(np.dot(delta, axis_u))
        v = float(np.dot(delta, axis_v))
        projected.append((symbol, u, v))
        extent = max(extent, abs(u), abs(v))
    extent += margin
    values = np.linspace(-extent, extent, max(25, int(grid_points)))
    uu, vv = np.meshgrid(values, values)
    points = (
        center[None, None, :]
        + uu[:, :, None] * axis_u[None, None, :]
        + vv[:, :, None] * axis_v[None, None, :]
    ).reshape(-1, 3)
    coefficients = np.asarray(res["orbc"])[:, int(orbital_index)]
    wave = PyQInt().plot_wavefunction(points, coefficients, res["cgfs"])
    wave = np.asarray(wave, dtype=float).reshape(uu.shape)
    return {
        "u": values.tolist(),
        "v": values.tolist(),
        "values": wave.tolist(),
        "atoms": [
            {"symbol": symbol, "u": u, "v": v} for symbol, u, v in projected
        ],
        "extent": float(extent),
        "center": [float(v) for v in center],
        "axis_u": [float(v) for v in axis_u],
        "axis_v": [float(v) for v in axis_v],
        "normal": [float(v) for v in normal],
        "index": int(orbital_index),
    }


def orbital_window(res, span: int = 3) -> List[Dict[str, Any]]:
    raw = res.get("orbe")
    orbe = list(raw) if raw is not None else []
    nelec = int(res.get("nelec") or 0)
    nocc = max(0, nelec // 2)
    start = max(0, nocc - span)
    end = min(len(orbe), nocc + span)
    window = []
    for index in range(start, end):
        window.append(
            {
                "index": index,
                "label": orbital_label(index, nocc),
                "energy": float(orbe[index]),
                "occupied": index < nocc,
            }
        )
    return window


def orbital_label(index: int, nocc: int) -> str:
    if index == nocc - 1:
        return "HOMO"
    if index == nocc:
        return "LUMO"
    if index < nocc - 1:
        return f"HOMO-{nocc - 1 - index}"
    return f"LUMO+{index - nocc}"


def run_calculation(
    molecule_id: str,
    *,
    basis: str = "sto3g",
    functional: str = "svwn5",
    grid: str = "low",
    tolerance: float = 1e-4,
    max_iter: int = 30,
    threads: int = 1,
    stop_event=None,
    progress=None,
    cooldown: float = 0.0,
    engine: str = "pydft",
) -> Dict[str, Any]:
    activate_vendor(threads)
    import numpy as np

    started = time.time()
    mol = load_molecule(molecule_id)
    info = molecule_info(molecule_id)
    grid_map = {key: (label, shells, angular) for label, key, shells, angular in GRID_CHOICES}
    _, shells, angular = grid_map.get(grid, grid_map["low"])

    if engine == "hf":
        from pyqint import HF

        hf = HF(mol, basis)
        res = hf.rhf(
            tolerance=float(tolerance),
            itermax=max(1, int(max_iter)),
            use_diis=True,
        )
        scf = {
            "result": res,
            "converged": bool(res.get("converged", True)),
            "iterations": len(res.get("energies") or []),
            "stopped": "",
            "energies": list(res.get("energies") or []),
        }
        method = "HF"
        dft = None
    else:
        from pydft import DFT

        dft = DFT(
            mol,
            basis=basis,
            functional=functional,
            nshells=int(shells),
            nangpts=int(angular),
        )
        scf = _run_scf(
            dft,
            float(tolerance),
            max(1, int(max_iter)),
            stop_event=stop_event,
            progress=progress,
            cooldown=float(cooldown),
        )
        res = scf["result"]
        method = "DFT"

    raw_orbe = res.get("orbe")
    orbe = list(raw_orbe) if raw_orbe is not None else []
    nelec = int(res.get("nelec") or 0)
    nocc = max(0, nelec // 2)
    homo = float(orbe[nocc - 1]) if len(orbe) >= nocc and nocc > 0 else None
    lumo = float(orbe[nocc]) if len(orbe) > nocc else None
    gap = (lumo - homo) if homo is not None and lumo is not None else None
    hardness = gap / 2.0 if gap is not None else None
    softness = (1.0 / (2.0 * hardness)) if hardness and hardness > 0 else None
    electronegativity = (-(homo + lumo) / 2.0) if homo is not None and lumo is not None else None
    electrophilicity = (
        (electronegativity ** 2) / (2.0 * hardness)
        if electronegativity is not None and hardness and hardness > 0
        else None
    )

    result: Dict[str, Any] = {
        "molecule": info.get("name", molecule_id),
        "molecule_id": molecule_id,
        "formula": info.get("formula", ""),
        "atoms": info.get("atoms", len(mol)),
        "family": info.get("family", ""),
        "load": info.get("load", ""),
        "method": method,
        "engine": engine,
        "basis": basis,
        "functional": functional if engine != "hf" else "HF",
        "grid": grid,
        "tolerance": float(tolerance),
        "max_iter": int(max_iter),
        "threads": int(threads),
        "energy": float(res.get("energy") or 0.0),
        "energy_ev": float(res.get("energy") or 0.0) * HARTREE_TO_EV,
        "homo": homo,
        "lumo": lumo,
        "gap": gap,
        "gap_ev": gap * HARTREE_TO_EV if gap is not None else None,
        "hardness": hardness,
        "softness": softness,
        "electronegativity": electronegativity,
        "electrophilicity": electrophilicity,
        "nelec": nelec,
        "nocc": nocc,
        "nbasis": len(res.get("cgfs") or []),
        "iterations": int(scf["iterations"]),
        "converged": bool(scf["converged"]),
        "stopped": str(scf["stopped"]),
        "scf_energies": [float(value) for value in scf["energies"]],
        "seconds": round(time.time() - started, 3),
        "mulliken": _mulliken(res),
        "dipole": _dipole(res),
        "orbitals": orbital_window(res),
        "recommended": {
            "low_power": True,
            "note": (
                "Educational DFT. Values are indicative, not publication-grade."
            ),
        },
    }

    # Keep the calculation objects only in memory for orbital slices.
    result["_res"] = res
    result["_dft"] = dft
    result["_mol"] = mol
    return result


def slices_for_window(result: Dict[str, Any], grid_points: int = 55) -> Dict[int, Dict[str, Any]]:
    res = result.get("_res")
    if not res:
        return {}
    output: Dict[int, Dict[str, Any]] = {}
    for item in result.get("orbitals") or []:
        index = int(item["index"])
        try:
            output[index] = orbital_slice(res, index, grid_points=grid_points)
        except Exception as exc:
            output[index] = {"error": f"{type(exc).__name__}: {exc}", "index": index}
    return output


def report_markdown(result: Dict[str, Any], slices: Dict[int, Dict[str, Any]]) -> str:
    def fmt(value, digits=6, suffix=""):
        if value is None:
            return "—"
        return f"{float(value):.{digits}f}{suffix}"

    lines = [
        f"# {result.get('molecule', 'Molecule')} — electronic structure",
        "",
        f"- Formula: {result.get('formula', '')}",
        f"- Family: {result.get('family', '')}",
        f"- Method: {result.get('method', '')} / {result.get('functional', '')}",
        f"- Basis: {result.get('basis', '')}",
        f"- Grid: {result.get('grid', '')}",
        f"- Threads: {result.get('threads', 1)}",
        f"- Atoms: {result.get('atoms', '')}",
        f"- Basis functions: {result.get('nbasis', '')}",
        f"- Electrons: {result.get('nelec', '')}",
        f"- SCF iterations: {result.get('iterations', '')}",
        f"- Converged: {'yes' if result.get('converged') else 'no'}",
        f"- Wall time: {result.get('seconds', 0):.2f} s",
        "",
        "## Electronic properties",
        "",
        f"- Total energy: {fmt(result.get('energy'), 8)} Ha",
        f"- Total energy: {fmt(result.get('energy_ev'), 3)} eV",
        f"- HOMO: {fmt(result.get('homo'))} Ha",
        f"- LUMO: {fmt(result.get('lumo'))} Ha",
        f"- Gap: {fmt(result.get('gap'))} Ha ({fmt(result.get('gap_ev'), 3)} eV)",
        f"- Chemical hardness: {fmt(result.get('hardness'))} Ha",
        f"- Softness: {fmt(result.get('softness'))} Ha^-1",
        f"- Electronegativity: {fmt(result.get('electronegativity'))} Ha",
        f"- Electrophilicity: {fmt(result.get('electrophilicity'))} Ha",
    ]
    dipole = result.get("dipole") or {}
    if dipole:
        lines.append(f"- Dipole moment: {fmt(dipole.get('magnitude_debye'), 3)} D")
    lines += ["", "## Orbital window", ""]
    for item in result.get("orbitals") or []:
        marker = "occupied" if item.get("occupied") else "virtual"
        lines.append(
            f"- {item.get('label')} (MO {item.get('index') + 1}): "
            f"{item.get('energy'):.6f} Ha · {marker}"
        )
    if not result.get("converged"):
        lines += [
            "",
            "> **Warning:** SCF did not converge. Treat HOMO/LUMO and orbital "
            "plots as indicative only. Try more iterations, a different "
            "functional, or the PyQInt HF fallback.",
        ]
    if result.get("load") == "heavy":
        lines += [
            "",
            "> **Heavy molecule:** pydft may need more iterations and can run "
            "for minutes. Run under a temperature watchdog with one thread and "
            "the low-power grid. The HF fallback is slower but may converge "
            "where DFT does not.",
        ]
    lines += [
        "",
        "## Method and limitations",
        "",
        "Single-point pydft Kohn-Sham calculation on a PubChem 3D conformer. "
        "No geometry optimization, solvent, dispersion correction or "
        "thermochemistry is included. pydft is an educational localized-orbital "
        "DFT code; absolute energies and gaps are not publication-grade.",
        "",
        "Orbital plots show a two-dimensional slice through the heavy-atom "
        "best-fit plane.",
        "",
    ]
    return "\n".join(lines)
