"""PySide6 interface for PyDFT Molecule Lab."""

from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import numpy as np
except Exception:  # pragma: no cover - QAH always carries numpy
    np = None  # type: ignore

from PySide6.QtCore import QThread, QTimer, Qt, Signal
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from . import molecule_lab as lab

try:
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
    from matplotlib.figure import Figure

    MATPLOTLIB_OK = True
except Exception:
    FigureCanvasQTAgg = None  # type: ignore
    Figure = None  # type: ignore
    MATPLOTLIB_OK = False


ATOM_COLORS = {
    "H": "#e5e7eb",
    "C": "#374151",
    "N": "#2563eb",
    "O": "#dc2626",
    "F": "#059669",
    "S": "#ca8a04",
    "P": "#ea580c",
}
COVALENT_RADII = {
    "H": 0.31, "C": 0.76, "N": 0.71, "O": 0.66, "F": 0.57,
    "S": 1.05, "P": 1.07, "Cl": 1.02,
}


class CalculationWorker(QThread):
    done = Signal(dict)
    failed = Signal(str)
    progress = Signal(int, float)

    def __init__(self, kwargs: Dict[str, Any], parent=None):
        super().__init__(parent)
        self.kwargs = dict(kwargs)
        self.stop_event = threading.Event()

    def request_stop(self) -> None:
        self.stop_event.set()

    def run(self) -> None:
        try:
            result = lab.run_calculation(
                **self.kwargs,
                stop_event=self.stop_event,
                progress=lambda iteration, energy: self.progress.emit(iteration, energy),
            )
        except Exception as exc:  # noqa: BLE001 - shown to the user
            self.failed.emit(f"{type(exc).__name__}: {exc}")
            return
        self.done.emit(result)


class MoleculeLabWidget(QWidget):
    def __init__(self, plugin=None, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.worker: Optional[CalculationWorker] = None
        self.dependency: Dict[str, Any] = {}
        self.current_id = "water"
        self.result: Optional[Dict[str, Any]] = None
        self._slices: Dict[int, Dict[str, Any]] = {}
        self._build_ui()
        QTimer.singleShot(0, lambda: self._detect(show_message=False))

    # -- construction -----------------------------------------------------

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        header = QHBoxLayout()
        title = QLabel("<b>PyDFT Molecule Lab</b>")
        title.setFont(QFont("Segoe UI", 15, QFont.Weight.Bold))
        header.addWidget(title)
        subtitle = QLabel("Single-point electronic structure · orbital slices · analysis")
        subtitle.setStyleSheet("color:#6b7280;")
        header.addWidget(subtitle, 1)
        self.dependency_badge = QLabel("Checking pydft…")
        self.dependency_badge.setStyleSheet("color:#b45309;")
        header.addWidget(self.dependency_badge)
        self.cpu_label = QLabel(f"{lab.total_threads()} logical CPU threads detected")
        self.cpu_label.setStyleSheet("color:#6b7280;")
        header.addWidget(self.cpu_label)
        probe_button = QPushButton("Probe dependencies")
        probe_button.clicked.connect(lambda _checked=False: self._probe())
        header.addWidget(probe_button)
        layout.addLayout(header)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_library_tab(), "Library")
        self.tabs.addTab(self._build_calculation_tab(), "Calculation")
        self.tabs.addTab(self._build_properties_tab(), "Properties")
        self.tabs.addTab(self._build_orbitals_tab(), "Orbitals")
        self.tabs.addTab(self._build_report_tab(), "Report")
        self.tabs.addTab(self._build_help_tab(), "Help")
        layout.addWidget(self.tabs, 1)

        self.status = QLabel("Ready. Water is selected for a fast smoke test.")
        self.status.setStyleSheet("color:#6b7280;")
        layout.addWidget(self.status)

        self._refresh_library()
        self._select_molecule("water")

    def _build_library_tab(self) -> QWidget:
        page = QWidget()
        outer = QVBoxLayout(page)
        outer.setContentsMargins(6, 6, 6, 6)

        splitter = QSplitter(Qt.Orientation.Horizontal)

        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 0, 0)
        note = QLabel(
            "Library geometries are PubChem 3D conformers. Heavy hormones are "
            "shown for completeness; run them only under your temperature watchdog."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color:#6b7280;")
        left_layout.addWidget(note)

        self.molecule_table = QTableWidget(0, 6)
        self.molecule_table.setHorizontalHeaderLabels(
            ["Molecule", "Formula", "Family", "Atoms", "Load", "Note"]
        )
        self.molecule_table.verticalHeader().setVisible(False)
        self.molecule_table.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows
        )
        self.molecule_table.setSelectionMode(
            QAbstractItemView.SelectionMode.SingleSelection
        )
        self.molecule_table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers
        )
        self.molecule_table.setWordWrap(False)
        self.molecule_table.setHorizontalScrollMode(
            QAbstractItemView.ScrollMode.ScrollPerPixel
        )
        header = self.molecule_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        header.setStretchLastSection(True)
        for column, width in enumerate((150, 95, 120, 55, 75, 320)):
            self.molecule_table.setColumnWidth(column, width)
        self.molecule_table.itemSelectionChanged.connect(self._preview_selected)
        left_layout.addWidget(self.molecule_table, 1)

        buttons = QHBoxLayout()
        self.use_button = QPushButton("Use selected molecule")
        self.use_button.clicked.connect(self._use_selected)
        buttons.addWidget(self.use_button)
        import_button = QPushButton("Import custom XYZ…")
        import_button.clicked.connect(self._import_xyz)
        buttons.addWidget(import_button)
        buttons.addStretch(1)
        left_layout.addLayout(buttons)
        splitter.addWidget(left)

        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        self.structure_info = QLabel("")
        self.structure_info.setWordWrap(True)
        self.structure_info.setStyleSheet("color:#4b5563;")
        right_layout.addWidget(self.structure_info)
        self.structure_canvas = self._make_canvas(4.4, 4.0)
        right_layout.addWidget(self.structure_canvas, 1)
        splitter.addWidget(right)
        splitter.setSizes([620, 420])
        outer.addWidget(splitter, 1)
        return page

    def _build_calculation_tab(self) -> QWidget:
        page = QWidget()
        outer = QVBoxLayout(page)
        outer.setContentsMargins(6, 6, 6, 6)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(0, 0, 0, 0)

        self.calc_molecule_label = QLabel("Water (H2O)")
        self.calc_molecule_label.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        layout.addWidget(self.calc_molecule_label)

        method_box = QGroupBox("Method")
        method_form = QFormLayout(method_box)
        self.engine_label = QLabel("pydft Kohn–Sham DFT")
        method_form.addRow("Engine:", self.engine_label)
        self.functional_combo = QComboBox()
        for label, key in lab.FUNCTIONAL_CHOICES:
            self.functional_combo.addItem(label, key)
        method_form.addRow("Functional:", self.functional_combo)
        self.basis_combo = QComboBox()
        for label, key in lab.BASIS_CHOICES:
            self.basis_combo.addItem(label, key)
        method_form.addRow("Basis:", self.basis_combo)
        self.grid_combo = QComboBox()
        for label, key, _shells, _angular in lab.GRID_CHOICES:
            self.grid_combo.addItem(label, key)
        method_form.addRow("Integration grid:", self.grid_combo)
        layout.addWidget(method_box)

        limits_box = QGroupBox("CPU and convergence limits")
        limits_form = QFormLayout(limits_box)
        self.thread_combo = QComboBox()
        for value in range(1, lab.total_threads() + 1):
            label = "1 thread (default)" if value == 1 else f"{value} threads"
            self.thread_combo.addItem(label, value)
        self.thread_combo.currentIndexChanged.connect(self._threads_changed)
        limits_form.addRow("CPU threads:", self.thread_combo)
        self.tolerance_combo = QComboBox()
        for label, value in (
            ("1e-3 (fast preview)", 1e-3),
            ("1e-4 (default)", 1e-4),
            ("1e-5 (tighter)", 1e-5),
        ):
            self.tolerance_combo.addItem(label, value)
        self.tolerance_combo.setCurrentIndex(1)
        limits_form.addRow("SCF tolerance:", self.tolerance_combo)
        self.max_iter_spin = QSpinBox()
        self.max_iter_spin.setRange(5, 120)
        self.max_iter_spin.setValue(30)
        self.max_iter_spin.setSuffix(" iterations")
        limits_form.addRow("Iteration cap:", self.max_iter_spin)
        self.cooldown_spin = QSpinBox()
        self.cooldown_spin.setRange(0, 3000)
        self.cooldown_spin.setValue(250)
        self.cooldown_spin.setSuffix(" ms")
        limits_form.addRow("Pause between SCF steps:", self.cooldown_spin)
        self.one_at_a_time = QCheckBox("Refuse to start while another calculation runs")
        self.one_at_a_time.setChecked(True)
        limits_form.addRow("", self.one_at_a_time)
        layout.addWidget(limits_box)

        self.cost_label = QLabel("")
        self.cost_label.setWordWrap(True)
        self.cost_label.setStyleSheet("color:#6b7280;")
        layout.addWidget(self.cost_label)

        row = QHBoxLayout()
        self.run_button = QPushButton("Run calculation")
        self.run_button.clicked.connect(lambda _checked=False: self._run())
        row.addWidget(self.run_button)
        self.stop_button = QPushButton("Stop after current SCF step")
        self.stop_button.clicked.connect(lambda _checked=False: self._stop())
        self.stop_button.setEnabled(False)
        row.addWidget(self.stop_button)
        row.addStretch(1)
        layout.addLayout(row)

        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setVisible(False)
        self.progress.setMaximumHeight(14)
        layout.addWidget(self.progress)

        self.calc_log = QPlainTextEdit()
        self.calc_log.setReadOnly(True)
        self.calc_log.setFont(QFont("Consolas", 9))
        self.calc_log.setPlaceholderText(
            "Calculation log. Nothing runs until you press Run calculation."
        )
        layout.addWidget(self.calc_log, 1)
        scroll.setWidget(content)
        outer.addWidget(scroll, 1)
        return page

    def _build_properties_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        self.convergence_banner = QLabel("")
        self.convergence_banner.setWordWrap(True)
        self.convergence_banner.setVisible(False)
        layout.addWidget(self.convergence_banner)

        splitter = QSplitter(Qt.Orientation.Vertical)
        self.property_table = QTableWidget(0, 3)
        self.property_table.setHorizontalHeaderLabels(["Property", "Value", "Unit"])
        self.property_table.verticalHeader().setVisible(False)
        self.property_table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers
        )
        self.property_table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Interactive
        )
        self.property_table.setColumnWidth(0, 260)
        self.property_table.setColumnWidth(1, 170)
        self.property_table.setColumnWidth(2, 90)
        splitter.addWidget(self.property_table)

        charges_box = QGroupBox("Mulliken atomic charges")
        charges_layout = QVBoxLayout(charges_box)
        self.charge_table = QTableWidget(0, 3)
        self.charge_table.setHorizontalHeaderLabels(["Atom", "Symbol", "Charge (e)"])
        self.charge_table.verticalHeader().setVisible(False)
        self.charge_table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers
        )
        self.charge_table.horizontalHeader().setStretchLastSection(True)
        charges_layout.addWidget(self.charge_table)
        splitter.addWidget(charges_box)
        splitter.setSizes([360, 240])
        layout.addWidget(splitter, 1)
        return page

    def _build_orbitals_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        controls = QHBoxLayout()
        controls.addWidget(QLabel("Orbital:"))
        self.orbital_combo = QComboBox()
        self.orbital_combo.currentIndexChanged.connect(self._orbital_changed)
        controls.addWidget(self.orbital_combo, 1)
        self.export_plot_button = QPushButton("Export plot…")
        self.export_plot_button.clicked.connect(lambda _checked=False: self._export_plot())
        self.export_plot_button.setEnabled(False)
        controls.addWidget(self.export_plot_button)
        layout.addLayout(controls)
        self.orbital_canvas = self._make_canvas(8.0, 5.0)
        layout.addWidget(self.orbital_canvas, 1)
        self.orbital_note = QLabel(
            "Orbital plots appear after a calculation. The slice uses the "
            "heavy-atom best-fit plane; the right panel shows the orbital window."
        )
        self.orbital_note.setWordWrap(True)
        self.orbital_note.setStyleSheet("color:#6b7280;")
        layout.addWidget(self.orbital_note)
        return page

    def _build_report_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        row = QHBoxLayout()
        copy_button = QPushButton("Copy Markdown")
        copy_button.clicked.connect(self._copy_report)
        row.addWidget(copy_button)
        save_button = QPushButton("Save Markdown…")
        save_button.clicked.connect(self._save_markdown)
        row.addWidget(save_button)
        json_button = QPushButton("Save JSON…")
        json_button.clicked.connect(self._save_json)
        row.addWidget(json_button)
        row.addStretch(1)
        layout.addLayout(row)
        self.report_view = QPlainTextEdit()
        self.report_view.setReadOnly(True)
        self.report_view.setFont(QFont("Consolas", 9))
        layout.addWidget(self.report_view, 1)
        return page

    def _build_help_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        browser = QTextBrowser()
        browser.setOpenExternalLinks(True)
        browser.setHtml(
            """
            <h2>PyDFT Molecule Lab</h2>
            <p>Single-point <b>pydft</b> Kohn–Sham calculations for small organic
            molecules. The library includes reference molecules and several
            estrogen/androgen-family hormones.</p>
            <h3>What is computed</h3>
            <ul>
              <li>total electronic energy (Ha and eV);</li>
              <li>HOMO, LUMO and HOMO–LUMO gap;</li>
              <li>chemical hardness, softness, electronegativity and electrophilicity;</li>
              <li>Mulliken atomic charges;</li>
              <li>dipole moment from density-matrix dipole integrals;</li>
              <li>two-dimensional molecular-orbital slices and an orbital-energy diagram.</li>
            </ul>
            <h3>CPU limits</h3>
            <p>pydft and pyqint are CPU-only. The header reports the number of
            logical CPU threads detected by the OS, and the thread selector can
            use any value from 1 up to that total. The default is one thread,
            with a low-power grid, a bounded iteration cap and a pause between
            SCF steps. It never starts a calculation on its own. Heavy hormones
            (E2, EE2, E3, testosterone, progesterone) can run for minutes and
            heat the CPU; use your external temperature watchdog.</p>
            <h3>GPU?</h3>
            <p>No. pydft/pyqint have no GPU backend, and an integrated GPU has no
            CUDA path. GPU quantum chemistry would need a separate CUDA-capable
            package such as GPU4PySCF and an NVIDIA GPU.</p>
            <h3>Dependencies</h3>
            <p>Inject <code>pydft</code> with Wheel Plugin Manager into target
            <code>global</code> (shared) or <code>pydft_molecule_lab</code>
            (private). pydft brings pyqint, pylebedev, numpy, scipy and numba.
            Then press <b>Probe dependencies</b>.</p>
            <h3>Limitations</h3>
            <p>Geometry is a PubChem 3D conformer; there is no geometry
            optimization, solvent, dispersion or thermochemistry. pydft is an
            educational code: absolute energies and gaps are indicative, not
            publication-grade. If the SCF does not converge, results and orbital
            plots are marked accordingly; increase the iteration cap or loosen
            the tolerance.</p>
            <p>Geometry source: PubChem 3D conformers (public data).</p>
            """
        )
        layout.addWidget(browser, 1)
        return page

    def _make_canvas(self, width: float, height: float):
        if not MATPLOTLIB_OK:
            label = QLabel("matplotlib is not available; plots are disabled.")
            label.setStyleSheet("color:#b91c1c;")
            return label
        figure = Figure(figsize=(width, height), tight_layout=True)
        canvas = FigureCanvasQTAgg(figure)
        canvas.setMinimumHeight(240)
        return canvas

    # -- library ---------------------------------------------------------

    def _refresh_library(self) -> None:
        self.molecule_table.setRowCount(0)
        for item in lab.MOLECULES:
            row = self.molecule_table.rowCount()
            self.molecule_table.insertRow(row)
            values = [
                item["name"],
                item["formula"],
                item["family"],
                str(item["atoms"]),
                item["load"],
                item.get("note", ""),
            ]
            for column, value in enumerate(values):
                cell = QTableWidgetItem(value)
                cell.setData(Qt.ItemDataRole.UserRole, item["id"])
                self.molecule_table.setItem(row, column, cell)
            if item["load"] == "heavy":
                for column in range(5):
                    self.molecule_table.item(row, column).setForeground(
                        QColor("#b91c1c")
                    )

    def _selected_id(self) -> str:
        rows = self.molecule_table.selectionModel().selectedRows()
        if not rows:
            return self.current_id
        item = self.molecule_table.item(rows[0].row(), 0)
        return str(item.data(Qt.ItemDataRole.UserRole) or self.current_id)

    def _select_molecule(self, molecule_id: str) -> None:
        self.current_id = molecule_id
        for row in range(self.molecule_table.rowCount()):
            item = self.molecule_table.item(row, 0)
            if item is not None and item.data(Qt.ItemDataRole.UserRole) == molecule_id:
                self.molecule_table.selectRow(row)
                break
        self._update_current_labels()
        self._draw_current_structure()

    def _preview_selected(self) -> None:
        self._draw_current_structure()

    def _use_selected(self) -> None:
        self.current_id = self._selected_id()
        self._update_current_labels()
        self._draw_current_structure()
        self.tabs.setCurrentIndex(1)

    def _import_xyz(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Import XYZ geometry", str(lab.MOLECULE_DIR), "XYZ files (*.xyz)"
        )
        if not path:
            return
        try:
            summary = lab.xyz_summary(path)
            target = lab.MOLECULE_DIR / f"custom_{summary['formula']}.xyz"
            target.write_text(Path(path).read_text(encoding="utf-8", errors="replace"), encoding="utf-8")
            molecule_id = target.stem
            lab.MOLECULE_BY_ID[molecule_id] = {
                "id": molecule_id,
                "name": summary["name"],
                "formula": summary["formula"],
                "family": "Custom",
                "atoms": summary["atoms"],
                "load": "custom",
                "note": str(path),
            }
            lab.MOLECULES.append(lab.MOLECULE_BY_ID[molecule_id])
            self._refresh_library()
            self._select_molecule(molecule_id)
            self.status.setText(f"Imported {summary['name']}.")
        except Exception as exc:
            QMessageBox.warning(self, "Import XYZ", str(exc))

    def _update_current_labels(self) -> None:
        info = lab.molecule_info(self.current_id)
        text = f"{info.get('name', self.current_id)} ({info.get('formula', '')})"
        self.calc_molecule_label.setText(text)
        self.structure_info.setText(
            f"<b>{info.get('name', self.current_id)}</b> · "
            f"{info.get('formula', '')} · {info.get('atoms', '?')} atoms<br>"
            f"{info.get('note', '')}"
        )
        self._update_cost_label()

    def _update_cost_label(self) -> None:
        info = lab.MOLECULE_BY_ID.get(self.current_id) or {}
        atoms = int(info.get("atoms") or 0)
        basis = self.basis_combo.currentData() if hasattr(self, "basis_combo") else "sto3g"
        estimate = ""
        if basis == "sto3g":
            # C/N/O -> 5, H -> 1; enough for the starter library.
            formula = str(info.get("formula") or "")
            import re

            counts = {symbol: int(count or 1) for symbol, count in re.findall(r"([A-Z][a-z]?)(\d*)", formula) if symbol}
            per_shell = {"H": 1, "C": 5, "N": 5, "O": 5, "F": 5}
            estimate = sum(per_shell.get(symbol, 5) * count for symbol, count in counts.items())
        message = f"Atoms: {atoms}. "
        if estimate:
            message += f"Approximate STO-3G basis functions: {estimate}. "
        if info.get("load") == "heavy":
            message += (
                "HEAVY: expect minutes and significant CPU load. Use 1 thread, "
                "low-power grid and your temperature watchdog."
            )
        elif info.get("load") in ("tiny", "small"):
            message += "Suitable for a quick smoke test."
        self.cost_label.setText(message)

    def _draw_current_structure(self) -> None:
        if not MATPLOTLIB_OK or not hasattr(self.structure_canvas, "figure"):
            return
        molecule_id = self._selected_id()
        try:
            mol = lab.load_molecule(molecule_id)
        except Exception as exc:
            self.structure_info.setText(f"<b>Preview unavailable</b><br>{exc}")
            return
        atoms = [(symbol, np.asarray(position, dtype=float)) for symbol, position in mol]
        center, axis_u, axis_v, _normal = lab.best_fit_plane(atoms)
        projected = []
        for symbol, position in atoms:
            delta = position - center
            projected.append(
                (symbol, float(np.dot(delta, axis_u)), float(np.dot(delta, axis_v)))
            )
        figure = self.structure_canvas.figure
        figure.clear()
        axis = figure.add_subplot(111)
        for i in range(len(projected)):
            for j in range(i + 1, len(projected)):
                symbol_i, u_i, v_i = projected[i]
                symbol_j, u_j, v_j = projected[j]
                distance = float(np.linalg.norm(atoms[i][1] - atoms[j][1]))
                cutoff = (
                    COVALENT_RADII.get(symbol_i, 0.8)
                    + COVALENT_RADII.get(symbol_j, 0.8)
                ) * 1.25 * 1.8897259886
                if distance <= cutoff:
                    axis.plot([u_i, u_j], [v_i, v_j], color="#9ca3af", linewidth=1.3, zorder=1)
        for symbol, u, v in projected:
            axis.scatter(
                [u], [v], s=170 if symbol != "H" else 90,
                color=ATOM_COLORS.get(symbol, "#a855f7"),
                edgecolors="#111827", linewidths=0.8, zorder=2,
            )
            axis.text(u, v, symbol, ha="center", va="center", fontsize=7,
                      color="white" if symbol != "H" else "#111827", zorder=3)
        axis.set_aspect("equal")
        axis.axis("off")
        axis.set_title(f"{mol.get_name()} · heavy-atom plane projection")
        figure.tight_layout()
        self.structure_canvas.draw_idle()

    # -- dependency / method --------------------------------------------

    def _threads_changed(self) -> None:
        threads = int(self.thread_combo.currentData() or 1)
        lab.set_thread_budget(threads)
        total = lab.total_threads()
        self.cpu_label.setText(f"{total} logical CPU threads detected")
        self.status.setText(
            f"Using {threads} of {total} logical CPU threads. If pydft was already "
            "imported, restart QAH to apply the native thread cap."
        )

    def _detect(self, show_message: bool = False) -> None:
        threads = int(self.thread_combo.currentData() or 1)
        self.dependency = lab.probe_dependencies(threads=threads)
        versions = self.dependency.get("versions") or {}
        total = int(self.dependency.get("total_threads") or lab.total_threads())
        self.cpu_label.setText(f"{total} logical CPU threads detected")
        if self.dependency.get("ok"):
            self.dependency_badge.setText(f"pydft {versions.get('pydft', '')}")
            self.dependency_badge.setStyleSheet("color:#15803d;")
            self.run_button.setEnabled(True)
            self.status.setText(
                "pydft {} · pyqint {} · numpy {} · matplotlib {} · Python {}".format(
                    versions.get("pydft", "?"),
                    versions.get("pyqint", "?"),
                    versions.get("numpy", "?"),
                    versions.get("matplotlib", "?"),
                    self.dependency.get("python", "?"),
                )
            )
        else:
            self.dependency_badge.setText("pydft not injected")
            self.dependency_badge.setStyleSheet("color:#b45309;")
            self.run_button.setEnabled(False)
            self.status.setText(self.dependency.get("error", "pydft missing"))
            if show_message:
                QMessageBox.information(
                    self,
                    "PyDFT Molecule Lab dependencies",
                    "pydft is not available yet.\n\n"
                    "Inject it from Wheel Plugin Manager:\n"
                    "  Package: pydft\n"
                    "  Target : global (or pydft_molecule_lab)\n\n"
                    "Then press Probe dependencies.",
                )

    def _probe(self) -> None:
        self._detect(show_message=True)

    # -- calculation -----------------------------------------------------

    def _run(self) -> None:
        if not self.dependency.get("ok"):
            self._detect(show_message=True)
            return
        if self.worker is not None and self.worker.isRunning():
            if self.one_at_a_time.isChecked():
                QMessageBox.information(
                    self, "PyDFT Molecule Lab",
                    "A calculation is already running. Wait for it to finish or stop it."
                )
                return
        info = lab.MOLECULE_BY_ID.get(self.current_id) or {}
        if info.get("load") == "heavy":
            answer = QMessageBox.question(
                self,
                "Heavy calculation",
                "This molecule can run for minutes and raise CPU temperature.\n\n"
                "Recommended: 1 thread, low-power grid, and your 60 °C watchdog.\n\n"
                "Start the calculation?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if answer != QMessageBox.Yes:
                return
        kwargs = {
            "molecule_id": self.current_id,
            "basis": self.basis_combo.currentData(),
            "functional": self.functional_combo.currentData(),
            "grid": self.grid_combo.currentData(),
            "tolerance": float(self.tolerance_combo.currentData() or 1e-4),
            "max_iter": int(self.max_iter_spin.value()),
            "threads": int(self.thread_combo.currentData() or 1),
            "cooldown": self.cooldown_spin.value() / 1000.0,
        }
        self.result = None
        self._slices = {}
        self.orbital_combo.clear()
        self.export_plot_button.setEnabled(False)
        self.run_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self.progress.setVisible(True)
        self.calc_log.setPlainText(
            "Calculation started.\n"
            f"  molecule  : {info.get('name', self.current_id)}\n"
            f"  basis     : {kwargs['basis']}\n"
            f"  grid      : {kwargs['grid']}\n"
            f"  threads   : {kwargs['threads']}\n"
            f"  max iter  : {kwargs['max_iter']}\n"
            f"  cooldown  : {kwargs['cooldown']:.2f} s between SCF steps\n"
        )
        self.status.setText("Running calculation…")
        worker = CalculationWorker(kwargs, self)
        worker.progress.connect(self._on_progress)
        worker.done.connect(self._on_done)
        worker.failed.connect(self._on_failed)
        worker.finished.connect(worker.deleteLater)
        self.worker = worker
        worker.start()

    def _stop(self) -> None:
        if self.worker is not None and self.worker.isRunning():
            self.worker.request_stop()
            self.stop_button.setEnabled(False)
            self.status.setText(
                "Stop requested. The current SCF step will finish, then the run stops."
            )

    def _on_progress(self, iteration: int, energy: float) -> None:
        self.calc_log.appendPlainText(
            f"SCF {iteration:03d}  E = {energy: .8f} Ha"
        )
        self.status.setText(f"SCF iteration {iteration} · E = {energy:.8f} Ha")

    def _on_done(self, result: Dict[str, Any]) -> None:
        self.worker = None
        self.result = result
        self.run_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.progress.setVisible(False)
        self._slices = {}
        self._refresh_properties()
        self._refresh_orbitals()
        self.report_view.setPlainText(lab.report_markdown(result, self._slices))
        self.export_plot_button.setEnabled(True)
        if result.get("stopped") == "cancelled":
            self.status.setText("Calculation stopped between SCF steps.")
        elif not result.get("converged"):
            self.status.setText(
                "Calculation finished WITHOUT convergence. Results are indicative only."
            )
        else:
            self.status.setText(
                f"Calculation complete in {result.get('seconds', 0):.2f} s."
            )
        self.tabs.setCurrentIndex(2)
        if not result.get("converged"):
            QMessageBox.warning(
                self,
                "SCF not converged",
                "The SCF did not converge within the iteration cap.\n\n"
                "Results and orbital plots are indicative only. Increase the cap, "
                "loosen tolerance, or increase the iteration cap.",
            )

    def _on_failed(self, message: str) -> None:
        self.worker = None
        self.run_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.progress.setVisible(False)
        self.status.setText("Calculation failed.")
        self.calc_log.appendPlainText(f"\nERROR: {message}")
        QMessageBox.critical(self, "PyDFT Molecule Lab", message)

    # -- properties ------------------------------------------------------

    def _refresh_properties(self) -> None:
        if not self.result:
            return
        result = self.result
        converged = bool(result.get("converged"))
        self.convergence_banner.setVisible(not converged)
        if not converged:
            self.convergence_banner.setText(
                "SCF did NOT converge. HOMO/LUMO, gap and orbital plots are "
                "indicative only. Increase the iteration cap or loosen the tolerance."
            )
            self.convergence_banner.setStyleSheet(
                "background:#fef2f2; color:#991b1b; padding:6px; border:1px solid #fecaca;"
            )
        rows = [
            ("Molecule", result.get("molecule", ""), ""),
            ("Formula", result.get("formula", ""), ""),
            ("Method", f"{result.get('method')} / {result.get('functional')}", ""),
            ("Basis", result.get("basis", ""), ""),
            ("Grid", result.get("grid", ""), ""),
            ("Threads", str(result.get("threads", 1)), ""),
            ("Atoms", str(result.get("atoms", "")), ""),
            ("Basis functions", str(result.get("nbasis", "")), ""),
            ("Electrons", str(result.get("nelec", "")), ""),
            ("SCF iterations", str(result.get("iterations", "")), ""),
            ("Converged", "yes" if converged else "no", ""),
            ("Wall time", f"{result.get('seconds', 0):.2f}", "s"),
            ("Total energy", self._fmt(result.get("energy"), 8), "Ha"),
            ("Total energy", self._fmt(result.get("energy_ev"), 3), "eV"),
            ("HOMO", self._fmt(result.get("homo")), "Ha"),
            ("LUMO", self._fmt(result.get("lumo")), "Ha"),
            ("HOMO–LUMO gap", self._fmt(result.get("gap")), "Ha"),
            ("HOMO–LUMO gap", self._fmt(result.get("gap_ev"), 3), "eV"),
            ("Chemical hardness", self._fmt(result.get("hardness")), "Ha"),
            ("Softness", self._fmt(result.get("softness")), "Ha⁻¹"),
            ("Electronegativity", self._fmt(result.get("electronegativity")), "Ha"),
            ("Electrophilicity", self._fmt(result.get("electrophilicity")), "Ha"),
        ]
        dipole = result.get("dipole") or {}
        if dipole:
            rows.append(("Dipole moment", self._fmt(dipole.get("magnitude_debye"), 3), "D"))
        self.property_table.setRowCount(0)
        for name, value, unit in rows:
            row = self.property_table.rowCount()
            self.property_table.insertRow(row)
            self.property_table.setItem(row, 0, QTableWidgetItem(str(name)))
            self.property_table.setItem(row, 1, QTableWidgetItem(str(value)))
            self.property_table.setItem(row, 2, QTableWidgetItem(str(unit)))

        charges = result.get("mulliken") or []
        self.charge_table.setRowCount(0)
        for charge in charges:
            row = self.charge_table.rowCount()
            self.charge_table.insertRow(row)
            self.charge_table.setItem(
                row, 0, QTableWidgetItem(str(charge.get("index", "") + 1))
            )
            self.charge_table.setItem(
                row, 1, QTableWidgetItem(str(charge.get("symbol", "")))
            )
            self.charge_table.setItem(
                row, 2, QTableWidgetItem(f"{charge.get('mulliken', 0.0): .4f}")
            )

    @staticmethod
    def _fmt(value, digits: int = 6) -> str:
        if value is None:
            return "—"
        try:
            return f"{float(value):.{digits}f}"
        except Exception:
            return str(value)

    # -- orbitals --------------------------------------------------------

    def _refresh_orbitals(self) -> None:
        self.orbital_combo.blockSignals(True)
        self.orbital_combo.clear()
        if self.result:
            for item in self.result.get("orbitals") or []:
                self.orbital_combo.addItem(
                    f"{item['label']}  (MO {item['index'] + 1})  "
                    f"{item['energy']:.6f} Ha",
                    item["index"],
                )
            # Default to HOMO.
            for index in range(self.orbital_combo.count()):
                if self.orbital_combo.itemText(index).startswith("HOMO "):
                    self.orbital_combo.setCurrentIndex(index)
                    break
        self.orbital_combo.blockSignals(False)
        self._orbital_changed()

    def _orbital_changed(self) -> None:
        if not self.result or not MATPLOTLIB_OK:
            return
        index = self.orbital_combo.currentData()
        if index is None:
            return
        index = int(index)
        if index not in self._slices:
            try:
                self._slices[index] = lab.orbital_slice(
                    self.result["_res"], index, grid_points=55
                )
            except Exception as exc:
                self._slices[index] = {"error": f"{type(exc).__name__}: {exc}"}
        self._draw_orbitals(index)

    def _draw_orbitals(self, index: int) -> None:
        if not MATPLOTLIB_OK or not hasattr(self.orbital_canvas, "figure"):
            return
        figure = self.orbital_canvas.figure
        figure.clear()
        grid = figure.add_gridspec(1, 2, width_ratios=[4.2, 1.2])
        axis = figure.add_subplot(grid[0, 0])
        energy_axis = figure.add_subplot(grid[0, 1])
        data = self._slices.get(index) or {}
        if "error" in data:
            axis.text(0.5, 0.5, data["error"], ha="center", va="center", wrap=True)
            axis.axis("off")
        else:
            u = np.asarray(data["u"])
            v = np.asarray(data["v"])
            values = np.asarray(data["values"])
            maximum = max(abs(float(values.min())), abs(float(values.max())), 1e-9)
            levels = np.linspace(-maximum, maximum, 25)
            contour = axis.contourf(u, v, values, levels=levels, cmap="RdBu_r")
            axis.contour(u, v, values, levels=[0.0], colors="#111827", linewidths=0.6)
            for atom in data.get("atoms") or []:
                symbol = atom["symbol"]
                axis.scatter(
                    [atom["u"]], [atom["v"]],
                    s=80 if symbol != "H" else 45,
                    color=ATOM_COLORS.get(symbol, "#a855f7"),
                    edgecolors="#111827", linewidths=0.6, zorder=3,
                )
            label = ""
            for item in self.result.get("orbitals") or []:
                if int(item["index"]) == index:
                    label = f"{item['label']} · {item['energy']:.6f} Ha"
                    break
            axis.set_title(label)
            axis.set_aspect("equal")
            axis.set_xlabel("in-plane u (bohr)")
            axis.set_ylabel("in-plane v (bohr)")
            axis.grid(False)
            figure.colorbar(contour, ax=axis, fraction=0.046, pad=0.03)

        orbitals = self.result.get("orbitals") or []
        energies = [item["energy"] for item in orbitals]
        labels = [item["label"] for item in orbitals]
        colors = ["#2563eb" if item["occupied"] else "#dc2626" for item in orbitals]
        positions = list(range(len(orbitals)))
        energy_axis.bar(positions, energies, color=colors, width=0.65)
        energy_axis.set_xticks(positions)
        energy_axis.set_xticklabels(labels, rotation=90, fontsize=7)
        energy_axis.set_ylabel("Orbital energy (Ha)")
        energy_axis.axhline(0.0, color="#6b7280", linewidth=0.8)
        energy_axis.set_title("Orbital window", fontsize=9)
        figure.tight_layout()
        self.orbital_canvas.draw_idle()

    def _export_plot(self) -> None:
        if not MATPLOTLIB_OK or not hasattr(self.orbital_canvas, "figure"):
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export orbital plot", "orbital.png", "PNG (*.png);;SVG (*.svg)"
        )
        if path:
            self.orbital_canvas.figure.savefig(path, dpi=180)

    # -- report ----------------------------------------------------------

    def _copy_report(self) -> None:
        from PySide6.QtWidgets import QApplication

        QApplication.clipboard().setText(self.report_view.toPlainText())
        self.status.setText("Report copied to clipboard.")

    def _save_markdown(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self, "Save report", "molecule_report.md", "Markdown (*.md)"
        )
        if path:
            with open(path, "w", encoding="utf-8") as handle:
                handle.write(self.report_view.toPlainText())
            self.status.setText(f"Saved {path}")

    def _save_json(self) -> None:
        if not self.result:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save result JSON", "molecule_result.json", "JSON (*.json)"
        )
        if not path:
            return
        safe = {
            key: value
            for key, value in self.result.items()
            if not key.startswith("_")
        }
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(safe, handle, indent=2, default=self._json_default)
        self.status.setText(f"Saved {path}")

    @staticmethod
    def _json_default(value):
        if np is not None:
            if isinstance(value, np.ndarray):
                return value.tolist()
            if isinstance(value, np.generic):
                return value.item()
        return str(value)

    # -- lifecycle -------------------------------------------------------

    def cleanup(self) -> None:
        if self.worker is not None:
            self.worker.request_stop()
            self.worker.wait(30000)
            if self.worker.isRunning():
                self.worker.setParent(None)
            self.worker = None
