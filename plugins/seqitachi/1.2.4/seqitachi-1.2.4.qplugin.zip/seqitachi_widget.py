"""PySide6 interface for SEQItachi."""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSpinBox,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from . import seqitachi_core as core
from . import seqitachi_tools as tools

try:
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
    from matplotlib.figure import Figure
    MATPLOTLIB_OK = True
except Exception:
    FigureCanvasQTAgg = None  # type: ignore
    Figure = None  # type: ignore
    MATPLOTLIB_OK = False

ATOM_COLORS = {
    "H": "#e5e7eb", "C": "#374151", "N": "#2563eb", "O": "#dc2626",
    "F": "#059669", "S": "#ca8a04", "P": "#ea580c", "Cl": "#16a34a",
    "Br": "#7c2d12", "I": "#4c1d95", "Fe": "#b45309", "Pd": "#0f766e",
    "Pt": "#475569", "Ni": "#15803d", "Cu": "#b45309", "Zn": "#64748b",
}


class SEQItachiWidget(QWidget):
    def __init__(self, plugin=None, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.molecule: Optional[core.Molecule] = None
        self.output: Dict[str, Any] = {}
        self.outputs: List[Dict[str, Any]] = []
        self.weights: List[float] = []
        self.experimental: Optional[tuple] = None
        self.spectrum_data: Dict[str, Any] = {}
        self._updating_range = False
        self.cube: Dict[str, Any] = {}
        self._build_ui()
        self._load_demo()

    # -- construction -----------------------------------------------------

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)
        header = QHBoxLayout()
        title = QLabel("<b>SEQItachi</b>")
        title.setFont(QFont("Segoe UI", 15, QFont.Weight.Bold))
        header.addWidget(title)
        subtitle = QLabel("Structure · QM input/output · spectra · thermochemistry · cubes")
        subtitle.setStyleSheet("color:#6b7280;")
        subtitle.setWordWrap(True)
        subtitle.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        header.addWidget(subtitle, 1)
        self.badge = QLabel("GPL-3.0 · independent implementation")
        self.badge.setStyleSheet("color:#6b7280;")
        self.badge.setWordWrap(True)
        self.badge.setSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Preferred)
        header.addWidget(self.badge)
        layout.addLayout(header)

        self.tabs = QTabWidget()
        for builder, title in (
            (self._build_structure_tab, "Structure"),
            (self._build_edit_tab, "Edit"),
            (self._build_analysis_tab, "Analysis"),
            (self._build_input_tab, "QM Input"),
            (self._build_results_tab, "Results"),
            (self._build_cube_tab, "Cube"),
            (self._build_tools_tab, "Tools"),
            (self._build_help_tab, "Help"),
        ):
            self.tabs.addTab(self._wrap_scroll(builder()), title)
        self.tabs.setUsesScrollButtons(True)
        layout.addWidget(self.tabs, 1)

        self.status = QLabel("Ready.")
        self.status.setStyleSheet("color:#6b7280;")
        self.status.setWordWrap(True)
        self.status.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        layout.addWidget(self.status)

    def _wrap_scroll(self, page: QWidget) -> QScrollArea:
        """Put a tab page in a scroll area; both bars appear only as needed."""
        if page.layout() is not None:
            page.layout().activate()
        page.setMinimumWidth(0)
        hint = page.sizeHint()
        page.setMinimumHeight(max(300, min(950, int(hint.height()))))
        page.setMinimumWidth(0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setWidget(page)
        return scroll

    def _make_canvas(self, w: float, h: float):
        if not MATPLOTLIB_OK:
            label = QLabel("matplotlib is not available; 3D views are disabled.")
            label.setStyleSheet("color:#b91c1c;")
            return label
        canvas = FigureCanvasQTAgg(Figure(figsize=(w, h), tight_layout=True))
        canvas.setMinimumHeight(240)
        return canvas

    def _build_structure_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        row = QHBoxLayout()
        load = QPushButton("Load…")
        load.setToolTip("Load an XYZ structure or a QM output file")
        load.clicked.connect(self._load_structure)
        row.addWidget(load)
        demo = QPushButton("Water")
        demo.clicked.connect(lambda _c=False: self._load_demo("water"))
        row.addWidget(demo)
        benzene = QPushButton("Benzene")
        benzene.clicked.connect(lambda _c=False: self._load_demo("benzene"))
        row.addWidget(benzene)
        center = QPushButton("Center")
        center.setToolTip("Translate the molecule so its center of mass is at the origin")
        center.clicked.connect(self._center_molecule)
        row.addWidget(center)
        row.addStretch(1)
        self.structure_label = QLabel("No structure")
        row.addWidget(self.structure_label)
        layout.addLayout(row)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        self.structure_canvas = self._make_canvas(6.0, 5.0)
        splitter.addWidget(self.structure_canvas)
        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        self.atom_table = QTableWidget(0, 5)
        self.atom_table.setHorizontalHeaderLabels(["#", "Element", "X (Å)", "Y (Å)", "Z (Å)"])
        self.atom_table.verticalHeader().setVisible(False)
        self.atom_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.atom_table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.atom_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.atom_table.setColumnWidth(0, 45)
        self.atom_table.setColumnWidth(1, 70)
        self.atom_table.itemSelectionChanged.connect(self._selection_changed)
        right_layout.addWidget(self.atom_table, 1)
        self.bond_label = QLabel("")
        self.bond_label.setWordWrap(True)
        self.bond_label.setStyleSheet("color:#6b7280;")
        right_layout.addWidget(self.bond_label)
        splitter.addWidget(right)
        splitter.setSizes([650, 420])
        layout.addWidget(splitter, 1)
        return page

    def _build_edit_tab(self) -> QWidget:
        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(6, 6, 6, 6)

        add_box = QGroupBox("Add atom")
        add_form = QFormLayout(add_box)
        self.add_symbol = QComboBox()
        self.add_symbol.addItems(core.SYMBOLS)
        add_form.addRow("Element:", self.add_symbol)
        coord_row = QHBoxLayout()
        self.add_x = QDoubleSpinBox(); self.add_x.setRange(-99, 99); self.add_x.setDecimals(4)
        self.add_y = QDoubleSpinBox(); self.add_y.setRange(-99, 99); self.add_y.setDecimals(4)
        self.add_z = QDoubleSpinBox(); self.add_z.setRange(-99, 99); self.add_z.setDecimals(4)
        for widget in (self.add_x, self.add_y, self.add_z):
            coord_row.addWidget(widget)
        add_form.addRow("X/Y/Z:", coord_row)
        add_button = QPushButton("Add atom")
        add_button.clicked.connect(self._add_atom)
        add_form.addRow("", add_button)
        layout.addWidget(add_box)

        edit_box = QGroupBox("Selected atoms")
        edit_form = QFormLayout(edit_box)
        self.change_symbol = QComboBox()
        self.change_symbol.addItems(core.SYMBOLS)
        edit_form.addRow("Change element to:", self.change_symbol)
        apply_element = QPushButton("Apply element to selection")
        apply_element.clicked.connect(self._change_element)
        edit_form.addRow("", apply_element)
        delete_button = QPushButton("Delete selected atoms")
        delete_button.clicked.connect(self._delete_atoms)
        edit_form.addRow("", delete_button)
        layout.addWidget(edit_box)

        bond_box = QGroupBox("Bonds")
        bond_form = QFormLayout(bond_box)
        self.bond_i = QSpinBox(); self.bond_i.setRange(1, 1)
        self.bond_j = QSpinBox(); self.bond_j.setRange(1, 1)
        self.bond_order = QDoubleSpinBox(); self.bond_order.setRange(0.5, 3.0); self.bond_order.setSingleStep(0.5); self.bond_order.setValue(1.0)
        bond_form.addRow("Atom i:", self.bond_i)
        bond_form.addRow("Atom j:", self.bond_j)
        bond_form.addRow("Order:", self.bond_order)
        bond_row = QHBoxLayout()
        add_bond = QPushButton("Add/replace bond")
        add_bond.clicked.connect(self._add_bond)
        bond_row.addWidget(add_bond)
        remove_bond = QPushButton("Remove bond")
        remove_bond.clicked.connect(self._remove_bond)
        bond_row.addWidget(remove_bond)
        bond_form.addRow("", bond_row)
        self.length_value = QDoubleSpinBox(); self.length_value.setRange(0.1, 10.0); self.length_value.setDecimals(4); self.length_value.setValue(1.0)
        bond_form.addRow("Set bond length:", self.length_value)
        set_length = QPushButton("Apply length")
        set_length.clicked.connect(self._set_bond_length)
        bond_form.addRow("", set_length)
        layout.addWidget(bond_box)

        transform_box = QGroupBox("Transform")
        transform_form = QFormLayout(transform_box)
        self.rot_axis = QComboBox(); self.rot_axis.addItems(["X", "Y", "Z"])
        self.rot_angle = QDoubleSpinBox(); self.rot_angle.setRange(-360, 360); self.rot_angle.setValue(90)
        transform_form.addRow("Rotate axis:", self.rot_axis)
        transform_form.addRow("Angle (deg):", self.rot_angle)
        rotate = QPushButton("Rotate molecule")
        rotate.clicked.connect(self._rotate)
        transform_form.addRow("", rotate)
        trans_row = QHBoxLayout()
        self.trans_x = QDoubleSpinBox(); self.trans_x.setRange(-99, 99); self.trans_x.setDecimals(3)
        self.trans_y = QDoubleSpinBox(); self.trans_y.setRange(-99, 99); self.trans_y.setDecimals(3)
        self.trans_z = QDoubleSpinBox(); self.trans_z.setRange(-99, 99); self.trans_z.setDecimals(3)
        for widget in (self.trans_x, self.trans_y, self.trans_z):
            trans_row.addWidget(widget)
        transform_form.addRow("Translate:", trans_row)
        translate = QPushButton("Translate molecule")
        translate.clicked.connect(self._translate)
        transform_form.addRow("", translate)
        layout.addWidget(transform_box)
        return content

    def _build_analysis_tab(self) -> QWidget:
        content = QWidget(); layout = QVBoxLayout(content); layout.setContentsMargins(6, 6, 6, 6)

        info_box = QGroupBox("Structure")
        info_form = QFormLayout(info_box)
        self.info_formula = QLabel("—"); self.info_mw = QLabel("—"); self.info_atoms = QLabel("—")
        self.info_bonds = QLabel("—"); self.info_com = QLabel("—"); self.info_rg = QLabel("—")
        for label, widget in (("Formula:", self.info_formula), ("Molecular weight:", self.info_mw),
                              ("Atoms:", self.info_atoms), ("Bonds:", self.info_bonds),
                              ("Center of mass:", self.info_com), ("Radius of gyration:", self.info_rg)):
            info_form.addRow(label, widget)
        layout.addWidget(info_box)

        geom_box = QGroupBox("Geometry selection")
        geom_form = QFormLayout(geom_box)
        self.geom_i = QSpinBox(); self.geom_i.setRange(1, 1)
        self.geom_j = QSpinBox(); self.geom_j.setRange(1, 1)
        self.geom_k = QSpinBox(); self.geom_k.setRange(1, 1)
        self.geom_l = QSpinBox(); self.geom_l.setRange(1, 1)
        for label, widget in (("Atom i:", self.geom_i), ("Atom j:", self.geom_j), ("Atom k:", self.geom_k), ("Atom l:", self.geom_l)):
            geom_form.addRow(label, widget)
        row = QHBoxLayout()
        for label, func in (("Distance", self._calc_distance), ("Angle", self._calc_angle), ("Dihedral", self._calc_dihedral)):
            button = QPushButton(label); button.clicked.connect(lambda _c=False, f=func: f()); row.addWidget(button)
        geom_form.addRow("", row)
        layout.addWidget(geom_box)

        steri_box = QGroupBox("Sterimol / cone / buried volume")
        steri_form = QFormLayout(steri_box)
        self.center_atom = QSpinBox(); self.center_atom.setRange(1, 1)
        self.ligand_atoms = QLineEdit(); self.ligand_atoms.setPlaceholderText("e.g. 2,3,4,5")
        self.bv_radius = QDoubleSpinBox(); self.bv_radius.setRange(1.0, 10.0); self.bv_radius.setValue(3.5)
        self.bv_spacing = QDoubleSpinBox(); self.bv_spacing.setRange(0.1, 1.0); self.bv_spacing.setValue(0.3); self.bv_spacing.setSingleStep(0.1)
        steri_form.addRow("Center atom:", self.center_atom)
        steri_form.addRow("Ligand atoms:", self.ligand_atoms)
        steri_form.addRow("Buried radius (Å):", self.bv_radius)
        steri_form.addRow("Voxel spacing (Å):", self.bv_spacing)
        row2 = QHBoxLayout()
        for label, func in (("Sterimol", self._calc_sterimol), ("Cone angle", self._calc_cone), ("Buried volume", self._calc_buried)):
            button = QPushButton(label); button.clicked.connect(lambda _c=False, f=func: f()); row2.addWidget(button)
        steri_form.addRow("", row2)
        layout.addWidget(steri_box)
        self.analysis_output = QPlainTextEdit(); self.analysis_output.setReadOnly(True)
        self.analysis_output.setFont(QFont("Consolas", 9))
        layout.addWidget(self.analysis_output, 1)
        return content

    def _build_input_tab(self) -> QWidget:
        content = QWidget(); layout = QVBoxLayout(content); layout.setContentsMargins(6, 6, 6, 6)
        box = QGroupBox("Build QM input")
        form = QFormLayout(box)
        self.qm_software = QComboBox(); self.qm_software.addItems(["Gaussian", "ORCA", "Psi4", "Q-Chem", "xTB", "sqm"])
        form.addRow("Software:", self.qm_software)
        self.qm_method = QLineEdit("B3LYP"); form.addRow("Method:", self.qm_method)
        self.qm_basis = QLineEdit("6-31G(d)"); form.addRow("Basis:", self.qm_basis)
        self.qm_job = QLineEdit("opt freq"); form.addRow("Job:", self.qm_job)
        self.qm_charge = QSpinBox(); self.qm_charge.setRange(-5, 5); form.addRow("Charge:", self.qm_charge)
        self.qm_mult = QSpinBox(); self.qm_mult.setRange(1, 5); form.addRow("Multiplicity:", self.qm_mult)
        self.qm_nproc = QSpinBox(); self.qm_nproc.setRange(1, 64); self.qm_nproc.setValue(4); form.addRow("CPU threads:", self.qm_nproc)
        self.qm_memory = QLineEdit("4GB"); form.addRow("Memory:", self.qm_memory)
        self.qm_solvent = QLineEdit(); self.qm_solvent.setPlaceholderText("optional, e.g. water"); form.addRow("Solvent:", self.qm_solvent)
        self.qm_title = QLineEdit("SEQItachi job"); form.addRow("Title:", self.qm_title)
        row = QHBoxLayout()
        preview = QPushButton("Preview"); preview.clicked.connect(lambda _c=False: self._preview_input()); row.addWidget(preview)
        save = QPushButton("Save input…"); save.clicked.connect(lambda _c=False: self._save_input()); row.addWidget(save)
        row.addStretch(1); form.addRow("", row)
        layout.addWidget(box)
        self.input_preview = QPlainTextEdit(); self.input_preview.setReadOnly(True); self.input_preview.setFont(QFont("Consolas", 9))
        layout.addWidget(self.input_preview, 1)
        return content

    def _build_results_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page); layout.setContentsMargins(6, 6, 6, 6)
        row = QHBoxLayout()
        load = QPushButton("Load…"); load.setToolTip("Load one QM output and replace the current conformers"); load.clicked.connect(self._load_output); row.addWidget(load)
        add_conf = QPushButton("Add…"); add_conf.setToolTip("Append another conformer output"); add_conf.clicked.connect(self._add_conformers); row.addWidget(add_conf)
        use_geom = QPushButton("Use geometry"); use_geom.setToolTip("Use the selected output geometry as the current structure"); use_geom.clicked.connect(self._use_output_geometry); row.addWidget(use_geom)
        clear = QPushButton("Clear"); clear.setToolTip("Remove all loaded outputs"); clear.clicked.connect(self._clear_outputs); row.addWidget(clear)
        export = QPushButton("Export…"); export.setToolTip("Export the peak table and curve data as CSV"); export.clicked.connect(self._export_spectrum_csv); row.addWidget(export)
        row.addStretch(1); layout.addLayout(row)

        self.conformer_table = QTableWidget(0, 4)
        self.conformer_table.setHorizontalHeaderLabels(["Conformer", "Energy (Ha)", "Weight", "IR / Raman / VCD"])
        self.conformer_table.verticalHeader().setVisible(False)
        self.conformer_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.conformer_table.setMaximumHeight(96)
        self.conformer_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.conformer_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.conformer_table)

        controls = QGroupBox("Spectrum")
        form = QFormLayout(controls)
        form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.plot_type = QComboBox(); self.plot_type.addItems(["Absorbance", "Transmittance", "VCD", "Raman"])
        form.addRow("Plot:", self.plot_type)
        range_row = QHBoxLayout()
        self.range_min = QDoubleSpinBox(); self.range_min.setRange(0.0, 6000.0); self.range_min.setDecimals(1); self.range_min.setSingleStep(50.0); self.range_min.setValue(400.0); self.range_min.setSuffix(" cm⁻¹")
        self.range_max = QDoubleSpinBox(); self.range_max.setRange(0.0, 6000.0); self.range_max.setDecimals(1); self.range_max.setSingleStep(50.0); self.range_max.setValue(4000.0); self.range_max.setSuffix(" cm⁻¹")
        range_row.addWidget(self.range_min, 1)
        range_row.addWidget(QLabel("to"))
        range_row.addWidget(self.range_max, 1)
        self.auto_range = QCheckBox("auto")
        self.auto_range.setChecked(True)
        self.auto_range.setToolTip("Fit the x-axis around the active peaks with padding; uncheck or edit a bound to zoom manually.")
        range_row.addWidget(self.auto_range)
        form.addRow("Range:", range_row)
        self.peak_type = QComboBox(); self.peak_type.addItems(["pseudo-Voigt", "Gaussian", "Lorentzian", "Delta"])
        form.addRow("Peak:", self.peak_type)
        self.fwhm = QDoubleSpinBox(); self.fwhm.setRange(0.01, 200.0); self.fwhm.setValue(15.0); self.fwhm.setSuffix(" cm⁻¹")
        form.addRow("FWHM:", self.fwhm)
        self.voigt_mix = QDoubleSpinBox(); self.voigt_mix.setRange(0.0, 1.0); self.voigt_mix.setDecimals(3); self.voigt_mix.setSingleStep(0.05); self.voigt_mix.setValue(0.5)
        form.addRow("Voigt mix:", self.voigt_mix)

        self.scale_preset = QComboBox(); self.scale_preset.addItems(list(core.SCALE_PRESETS.keys()) + ["custom"])
        self.scale_preset.setCurrentText("custom")
        self.scale_preset.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.scale_preset.setMinimumContentsLength(18)
        self.scale_preset.setToolTip("Approximate literature scaling factors; verify for your method/basis or edit the factor manually.")
        form.addRow("Scale preset:", self.scale_preset)
        self.scale_factor = QDoubleSpinBox(); self.scale_factor.setRange(0.5, 1.2); self.scale_factor.setDecimals(4); self.scale_factor.setSingleStep(0.001); self.scale_factor.setValue(1.0)
        form.addRow("Scale factor:", self.scale_factor)
        self.quadratic = QDoubleSpinBox(); self.quadratic.setRange(-1e-5, 1e-5); self.quadratic.setDecimals(8); self.quadratic.setSingleStep(1e-7); self.quadratic.setValue(0.0)
        form.addRow("Quadratic:", self.quadratic)
        self.shift = QDoubleSpinBox(); self.shift.setRange(-500.0, 500.0); self.shift.setDecimals(2); self.shift.setSuffix(" cm⁻¹")
        form.addRow("Shift:", self.shift)

        self.temperature = QDoubleSpinBox(); self.temperature.setRange(1.0, 2000.0); self.temperature.setDecimals(2); self.temperature.setValue(298.15); self.temperature.setSuffix(" K")
        form.addRow("Temperature:", self.temperature)
        self.show_components = QCheckBox("show individual conformers")
        form.addRow("", self.show_components)
        self.reverse_x = QCheckBox("reverse x-axis"); self.reverse_x.setChecked(True)
        form.addRow("", self.reverse_x)
        exp_row = QHBoxLayout()
        exp_load = QPushButton("Load experimental CSV…"); exp_load.clicked.connect(self._load_experimental_csv)
        exp_row.addWidget(exp_load)
        exp_clear = QPushButton("Clear experimental"); exp_clear.clicked.connect(self._clear_experimental)
        exp_row.addWidget(exp_clear)
        exp_row.addStretch(1)
        form.addRow("Experimental:", exp_row)
        layout.addWidget(controls)

        for widget in (self.plot_type, self.peak_type, self.scale_preset):
            widget.currentIndexChanged.connect(lambda *_: self._draw_spectra())
        for widget in (self.fwhm, self.voigt_mix, self.scale_factor, self.quadratic, self.shift, self.temperature):
            widget.valueChanged.connect(lambda *_: self._draw_spectra())
        for widget in (self.show_components, self.reverse_x):
            widget.stateChanged.connect(lambda *_: self._draw_spectra())
        self.scale_preset.currentTextChanged.connect(self._apply_scale_preset)
        self.auto_range.toggled.connect(self._range_mode_changed)
        self.range_min.valueChanged.connect(self._range_edited)
        self.range_max.valueChanged.connect(self._range_edited)

        self.result_summary = QPlainTextEdit(); self.result_summary.setReadOnly(True); self.result_summary.setFont(QFont("Consolas", 9)); self.result_summary.setMaximumHeight(120)
        layout.addWidget(self.result_summary)
        splitter = QSplitter(Qt.Orientation.Horizontal)
        self.freq_table = QTableWidget(0, 6)
        self.freq_table.setHorizontalHeaderLabels(["Mode", "Frequency", "Scaled", "IR", "Raman", "VCD"])
        self.freq_table.verticalHeader().setVisible(False); self.freq_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.freq_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        splitter.addWidget(self.freq_table)
        self.exc_table = QTableWidget(0, 3); self.exc_table.setHorizontalHeaderLabels(["eV", "nm", "f"])
        self.exc_table.verticalHeader().setVisible(False); self.exc_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        splitter.addWidget(self.exc_table)
        layout.addWidget(splitter, 1)
        self.spectrum_canvas = self._make_canvas(8.0, 3.4)
        layout.addWidget(self.spectrum_canvas)
        self.thermo_output = QPlainTextEdit(); self.thermo_output.setReadOnly(True); self.thermo_output.setFont(QFont("Consolas", 9)); self.thermo_output.setMaximumHeight(110)
        layout.addWidget(self.thermo_output)
        return page

    def _build_cube_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page); layout.setContentsMargins(6, 6, 6, 6)
        row = QHBoxLayout()
        load = QPushButton("Load cube…"); load.clicked.connect(self._load_cube); row.addWidget(load)
        row.addWidget(QLabel("Axis:"))
        self.cube_axis = QComboBox(); self.cube_axis.addItems(["z", "y", "x"]); self.cube_axis.currentTextChanged.connect(lambda _t: self._draw_cube()); row.addWidget(self.cube_axis)
        row.addWidget(QLabel("Index:"))
        self.cube_index = QSpinBox(); self.cube_index.setRange(0, 0); self.cube_index.valueChanged.connect(lambda _v: self._draw_cube()); row.addWidget(self.cube_index)
        use_atoms = QPushButton("Use cube atoms"); use_atoms.clicked.connect(self._use_cube_atoms); row.addWidget(use_atoms)
        row.addStretch(1); layout.addLayout(row)
        self.cube_canvas = self._make_canvas(7.0, 5.0); layout.addWidget(self.cube_canvas, 1)
        self.cube_info = QLabel("No cube loaded. Supports Gaussian cube files."); self.cube_info.setStyleSheet("color:#6b7280;")
        layout.addWidget(self.cube_info)
        return page

    def _build_tools_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        note = QLabel(
            "External executables are optional and user-supplied. SEQItachi never "
            "bundles ORCA, xtb, CREST, Gaussian, Psi4 or Q-Chem. Missing tools are "
            "reported as errors only when an external job is requested."
        )
        note.setWordWrap(True)
        note.setStyleSheet("background:#eff6ff; color:#1e3a8a; padding:6px; border:1px solid #bfdbfe;")
        layout.addWidget(note)

        self.tool_table = QTableWidget(0, 4)
        self.tool_table.setHorizontalHeaderLabels(["Tool", "Status", "Path", "Source / hint"])
        self.tool_table.verticalHeader().setVisible(False)
        self.tool_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tool_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.tool_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tool_table.setWordWrap(True)
        header = self.tool_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.tool_table.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        layout.addWidget(self.tool_table, 1)

        row = QHBoxLayout()
        detect = QPushButton("Detect")
        detect.setToolTip("Detect external tools")
        detect.clicked.connect(lambda _c=False: self._refresh_tools())
        row.addWidget(detect)
        browse = QPushButton("Set path…")
        browse.setToolTip("Set the executable path for the selected tool")
        browse.clicked.connect(lambda _c=False: self._browse_tool())
        row.addWidget(browse)
        clear = QPushButton("Clear path")
        clear.setToolTip("Clear the saved executable path for the selected tool")
        clear.clicked.connect(lambda _c=False: self._clear_tool())
        row.addWidget(clear)
        require = QPushButton("Check")
        require.setToolTip("Check that the selected tool is available")
        require.clicked.connect(lambda _c=False: self._check_tool())
        row.addWidget(require)
        row.addStretch(1)
        layout.addLayout(row)
        self.tool_status = QLabel("")
        self.tool_status.setWordWrap(True)
        self.tool_status.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.tool_status.setStyleSheet("color:#6b7280;")
        layout.addWidget(self.tool_status)
        self._refresh_tools()
        return page

    def _refresh_tools(self) -> None:
        data = tools.detect_all()
        self.tool_table.setRowCount(0)
        for tool_id, info in data.items():
            row = self.tool_table.rowCount()
            self.tool_table.insertRow(row)
            values = [
                info.get("label", tool_id),
                "found" if info.get("found") else "missing",
                info.get("path", ""),
                info.get("source", "") if info.get("found") else info.get("hint", ""),
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setData(Qt.ItemDataRole.UserRole, tool_id)
                if col == 1:
                    item.setForeground(QColor("#15803d") if info.get("found") else QColor("#b91c1c"))
                self.tool_table.setItem(row, col, item)
        self.tool_status.setText(f"Toolchain config: {tools.CONFIG}")

    def _selected_tool(self) -> str:
        rows = self.tool_table.selectionModel().selectedRows()
        if not rows:
            return ""
        item = self.tool_table.item(rows[0].row(), 0)
        return str(item.data(Qt.ItemDataRole.UserRole) or "") if item else ""

    def _browse_tool(self) -> None:
        tool = self._selected_tool()
        if not tool:
            QMessageBox.information(self, "SEQItachi", "Select a tool row first.")
            return
        path, _ = QFileDialog.getOpenFileName(self, f"Set {tool} executable", str(Path.home()), "Executables (*.exe);;All files (*)")
        if path:
            tools.set_tool_path(tool, path)
            self._refresh_tools()

    def _clear_tool(self) -> None:
        tool = self._selected_tool()
        if tool:
            tools.set_tool_path(tool, "")
            self._refresh_tools()

    def _check_tool(self) -> None:
        tool = self._selected_tool()
        if not tool:
            QMessageBox.information(self, "SEQItachi", "Select a tool row first.")
            return
        try:
            info = tools.require_tool(tool)
            QMessageBox.information(self, "SEQItachi", f"{info['label']} found:\n{info['path']}")
        except tools.ToolNotFoundError as exc:
            QMessageBox.warning(self, "SEQItachi", str(exc))

    def _build_help_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page); layout.setContentsMargins(6, 6, 6, 6)
        browser = QTextBrowser(); browser.setOpenExternalLinks(True)
        browser.setHtml("""
        <h2>SEQItachi</h2>
        <p>A QAH-native structure and quantum-chemistry workbench inspired by
        <b>SEQCROW</b> (GPL-3.0). This is an independent implementation; no
        SEQCROW code is copied and it is not affiliated with the SEQCROW
        authors.</p>
        <h3>Implemented</h3>
        <ul>
          <li>XYZ import, molecule table, inferred bonds, 3D ball-and-stick view;</li>
          <li>atom add/delete, element change, bond add/remove/order/length, rotate/translate;</li>
          <li>formula, molecular weight, center of mass, radius of gyration, distance/angle/dihedral;</li>
          <li>approximate Sterimol, cone angle and buried-volume voxel analysis;</li>
          <li>Gaussian, ORCA, Psi4, Q-Chem, xTB and sqm input builders;</li>
          <li>Gaussian/ORCA/Psi4/Q-Chem output parsing: energy, geometry, HOMO/LUMO, frequencies, excitations;</li>
          <li>IR and UV/Vis broadening plots, RRHO thermochemistry from frequencies;</li>
          <li>Gaussian cube 2D slices.</li>
          <li>external-tool detection for ORCA, xtb, CREST, Gaussian, Psi4 and
              Q-Chem, with saved custom paths and clear missing-tool errors.</li>
        </ul>
        <h3>Not yet implemented</h3>
        <p>ChimeraX mouse modes, 2D sketcher, AaronTools fragment library,
        conformer search/CREST, transition-state interpolation, normal-mode
        animation, full orbital isosurfaces, point groups, and the complete
        Sterimol/ligand library. These are roadmap items, not claims of complete
        SEQCROW parity.</p>
        <h3>License</h3>
        <p>SEQItachi is GPL-3.0 or later. SEQCROW is GPL-3.0; see its GitHub
        repository and the J. Comput. Chem. 2021 citation. This plugin does not
        bundle SEQCROW or AaronTools.</p>
        """)
        layout.addWidget(browser, 1)
        return page

    # -- structure --------------------------------------------------------

    def _load_demo(self, name: str = "water") -> None:
        if name == "benzene":
            text = """12
benzene
C  1.3960  0.0000  0.0000
C  0.6980  1.2090  0.0000
C -0.6980  1.2090  0.0000
C -1.3960  0.0000  0.0000
C -0.6980 -1.2090  0.0000
C  0.6980 -1.2090  0.0000
H  2.4790  0.0000  0.0000
H  1.2395  2.1460  0.0000
H -1.2395  2.1460  0.0000
H -2.4790  0.0000  0.0000
H -1.2395 -2.1460  0.0000
H  1.2395 -2.1460  0.0000
"""
        else:
            text = """3
water
O  0.0000  0.0000  0.1173
H  0.0000  0.7572 -0.4692
H  0.0000 -0.7572 -0.4692
"""
        self.molecule = core.Molecule.from_xyz_text(text)
        self._refresh_all()

    def _load_structure(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Load structure", str(Path.home()),
                                              "Structures (*.xyz *.out *.log);;All files (*)")
        if not path:
            return
        try:
            lower = path.lower()
            if lower.endswith((".out", ".log")):
                result = core.parse_output(path)
                if result.get("geometry") is None:
                    raise ValueError("No geometry found in output")
                self.molecule = result["geometry"]
                self.output = result
                self._show_output()
            else:
                self.molecule = core.Molecule.from_xyz_file(path)
            self._refresh_all()
            self.status.setText(f"Loaded {path}")
        except Exception as exc:
            QMessageBox.warning(self, "SEQItachi", str(exc))

    def _center_molecule(self) -> None:
        if not self.molecule:
            return
        com = self.molecule.center_of_mass()
        self.molecule.translate(-com[0], -com[1], -com[2])
        self._refresh_all()

    def _refresh_all(self) -> None:
        self._refresh_tables()
        self._draw_molecule()
        self._refresh_analysis()
        self._refresh_spin_limits()

    def _refresh_tables(self) -> None:
        mol = self.molecule
        self.atom_table.setRowCount(0)
        if not mol:
            return
        for index, (symbol, x, y, z) in enumerate(mol.atoms):
            row = self.atom_table.rowCount(); self.atom_table.insertRow(row)
            for col, value in enumerate((str(index + 1), symbol, f"{x:.4f}", f"{y:.4f}", f"{z:.4f}")):
                self.atom_table.setItem(row, col, QTableWidgetItem(value))
        self.bond_label.setText(f"{len(mol.bonds)} inferred/defined bond(s)")
        self.structure_label.setText(f"{mol.formula()} · {len(mol)} atoms")

    def _selection_changed(self) -> None:
        if not self.molecule:
            return
        rows = self.atom_table.selectionModel().selectedRows()
        if rows:
            index = rows[0].row()
            if 0 <= index < len(self.molecule.atoms):
                symbol = self.molecule.atoms[index][0]
                pos = self.molecule.atoms[index][1:]
                self.status.setText(f"Atom {index + 1}: {symbol} at ({pos[0]:.3f}, {pos[1]:.3f}, {pos[2]:.3f}) Å")

    def _selected_indices(self) -> List[int]:
        return sorted({row.row() for row in self.atom_table.selectionModel().selectedRows()})

    def _draw_molecule(self) -> None:
        if not MATPLOTLIB_OK or not hasattr(self.structure_canvas, "figure"):
            return
        fig = self.structure_canvas.figure; fig.clear()
        ax = fig.add_subplot(111, projection="3d")
        mol = self.molecule
        if not mol:
            ax.text(0, 0, 0, "No structure")
            self.structure_canvas.draw_idle(); return
        coords = mol.coords()
        for i, j, _order in mol.bonds:
            ax.plot([coords[i, 0], coords[j, 0]], [coords[i, 1], coords[j, 1]], [coords[i, 2], coords[j, 2]], color="#9ca3af", linewidth=1.6)
        for index, (symbol, x, y, z) in enumerate(mol.atoms):
            ax.scatter([x], [y], [z], s=180 if symbol != "H" else 80,
                       color=ATOM_COLORS.get(symbol, "#a855f7"), edgecolors="#111827", linewidths=0.7)
            ax.text(x, y, z, symbol, fontsize=7, ha="center", va="center", color="white" if symbol != "H" else "#111827")
        ax.set_box_aspect((1, 1, 1)); ax.axis("off")
        ax.set_title(f"{mol.name} · {mol.formula()}")
        self.structure_canvas.draw_idle()

    # -- editing ----------------------------------------------------------

    def _add_atom(self) -> None:
        if not self.molecule:
            return
        self.molecule.add_atom(self.add_symbol.currentText(), self.add_x.value(), self.add_y.value(), self.add_z.value())
        self._refresh_all()

    def _change_element(self) -> None:
        if not self.molecule: return
        for index in self._selected_indices():
            self.molecule.set_element(index, self.change_symbol.currentText())
        self._refresh_all()

    def _delete_atoms(self) -> None:
        if not self.molecule: return
        for index in sorted(self._selected_indices(), reverse=True):
            self.molecule.remove_atom(index)
        self._refresh_all()

    def _add_bond(self) -> None:
        if not self.molecule: return
        self.molecule.add_bond(self.bond_i.value() - 1, self.bond_j.value() - 1, self.bond_order.value())
        self._refresh_all()

    def _remove_bond(self) -> None:
        if not self.molecule: return
        self.molecule.remove_bond(self.bond_i.value() - 1, self.bond_j.value() - 1)
        self._refresh_all()

    def _set_bond_length(self) -> None:
        if not self.molecule: return
        self.molecule.set_bond_length(self.bond_i.value() - 1, self.bond_j.value() - 1, self.length_value.value())
        self._refresh_all()

    def _rotate(self) -> None:
        if not self.molecule: return
        axis = {"X": (1, 0, 0), "Y": (0, 1, 0), "Z": (0, 0, 1)}[self.rot_axis.currentText()]
        self.molecule.rotate(axis, self.rot_angle.value())
        self._refresh_all()

    def _translate(self) -> None:
        if not self.molecule: return
        self.molecule.translate(self.trans_x.value(), self.trans_y.value(), self.trans_z.value())
        self._refresh_all()

    def _refresh_spin_limits(self) -> None:
        count = len(self.molecule) if self.molecule else 1
        for spin in (self.geom_i, self.geom_j, self.geom_k, self.geom_l, self.center_atom, self.bond_i, self.bond_j):
            spin.setRange(1, max(1, count))
        self.geom_k.setValue(min(3, count)); self.geom_l.setValue(min(4, count))

    # -- analysis ---------------------------------------------------------

    def _refresh_analysis(self) -> None:
        mol = self.molecule
        if not mol:
            return
        self.info_formula.setText(mol.formula())
        self.info_mw.setText(f"{mol.molecular_weight():.3f} g/mol")
        self.info_atoms.setText(str(len(mol)))
        self.info_bonds.setText(str(len(mol.bonds)))
        com = mol.center_of_mass()
        self.info_com.setText(f"({com[0]:.3f}, {com[1]:.3f}, {com[2]:.3f}) Å")
        self.info_rg.setText(f"{mol.radius_of_gyration():.3f} Å")

    def _calc_distance(self) -> None:
        if not self.molecule: return
        self.analysis_output.appendPlainText(f"Distance {self.geom_i.value()}–{self.geom_j.value()}: {self.molecule.distance(self.geom_i.value()-1, self.geom_j.value()-1):.4f} Å")

    def _calc_angle(self) -> None:
        if not self.molecule: return
        self.analysis_output.appendPlainText(f"Angle {self.geom_i.value()}–{self.geom_j.value()}–{self.geom_k.value()}: {self.molecule.angle(self.geom_i.value()-1, self.geom_j.value()-1, self.geom_k.value()-1):.3f}°")

    def _calc_dihedral(self) -> None:
        if not self.molecule: return
        self.analysis_output.appendPlainText(f"Dihedral {self.geom_i.value()}–{self.geom_j.value()}–{self.geom_k.value()}–{self.geom_l.value()}: {self.molecule.dihedral(self.geom_i.value()-1, self.geom_j.value()-1, self.geom_k.value()-1, self.geom_l.value()-1):.3f}°")

    def _ligands(self) -> List[int]:
        return [int(x) - 1 for x in self.ligand_atoms.text().replace(";", ",").split(",") if x.strip().isdigit()]

    def _calc_sterimol(self) -> None:
        if not self.molecule: return
        values = core.sterimol(self.molecule, self.center_atom.value() - 1, self._ligands())
        self.analysis_output.appendPlainText("Sterimol (approximate): " + ", ".join(f"{k}={v:.3f}" for k, v in values.items()))

    def _calc_cone(self) -> None:
        if not self.molecule: return
        value = core.cone_angle(self.molecule, self.center_atom.value() - 1, self._ligands())
        self.analysis_output.appendPlainText(f"Cone angle (approximate): {value:.2f}°")

    def _calc_buried(self) -> None:
        if not self.molecule: return
        value = core.buried_volume(self.molecule, self.center_atom.value() - 1, self._ligands(), self.bv_radius.value(), self.bv_spacing.value())
        self.analysis_output.appendPlainText(f"Buried volume (approximate): {value:.2f}%")

    # -- QM input ---------------------------------------------------------

    def _preview_input(self) -> None:
        if not self.molecule: return
        try:
            text = core.build_qm_input(
                self.qm_software.currentText(), self.molecule,
                method=self.qm_method.text(), basis=self.qm_basis.text(),
                job=self.qm_job.text(), charge=self.qm_charge.value(),
                multiplicity=self.qm_mult.value(), title=self.qm_title.text(),
                nproc=self.qm_nproc.value(), memory=self.qm_memory.text(),
                solvent=self.qm_solvent.text().strip(),
            )
            self.input_preview.setPlainText(text)
        except Exception as exc:
            QMessageBox.warning(self, "SEQItachi", str(exc))

    def _save_input(self) -> None:
        if not self.molecule: return
        path, _ = QFileDialog.getSaveFileName(self, "Save QM input", "input.inp", "Input (*.inp *.com *.gjf *.txt);;All files (*)")
        if not path: return
        self._preview_input()
        Path(path).write_text(self.input_preview.toPlainText(), encoding="utf-8")
        self.status.setText(f"Saved {path}")

    # -- results ----------------------------------------------------------

    def _load_output(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Load QM output",
            str(Path.home()),
            "Output (*.out *.log *.txt);;All files (*)",
        )
        if not path:
            return
        self._set_outputs([path], reset=True)
        self._refresh_all()

    def _add_conformers(self) -> None:
        paths, _ = QFileDialog.getOpenFileNames(
            self,
            "Add conformer outputs",
            str(Path.home()),
            "Output (*.out *.log *.txt);;All files (*)",
        )
        if not paths:
            return
        self._set_outputs(paths, reset=False)
        self._refresh_all()

    def _clear_outputs(self) -> None:
        self.outputs = []
        self.weights = []
        self.output = {}
        self.spectrum_data = {}
        self.conformer_table.setRowCount(0)
        self.freq_table.setRowCount(0)
        self.exc_table.setRowCount(0)
        self.result_summary.clear()
        self.thermo_output.clear()
        self._draw_spectra()
        self.status.setText("Loaded outputs cleared.")

    def _set_outputs(self, paths: List[str], reset: bool = False) -> None:
        if reset:
            self.outputs = []
            self.weights = []
        errors = []
        for path in paths:
            try:
                self.outputs.append(core.parse_output(path))
            except Exception as exc:
                errors.append(f"{Path(path).name}: {exc}")
        if not self.outputs:
            if errors:
                QMessageBox.warning(self, "SEQItachi", "\n".join(errors))
            return
        self.output = self.outputs[-1]
        if self.output.get("geometry"):
            self.molecule = self.output["geometry"]
        self._update_weights()
        self._auto_scale_preset()
        self._show_output()
        if errors:
            self.status.setText("Some outputs failed: " + "; ".join(errors[:3]))
        else:
            self.status.setText(f"Loaded {len(self.outputs)} output(s).")

    def _update_weights(self) -> None:
        energies = [data.get("energy") for data in self.outputs]
        self.weights = core.boltzmann_weights(energies, self.temperature.value())

    def _auto_scale_preset(self) -> None:
        key = f"{self.output.get('method', '')}/{self.output.get('basis', '')}".upper()
        for name in core.SCALE_PRESETS:
            if name.upper() == key:
                self.scale_preset.setCurrentText(name)
                return
        self.scale_preset.setCurrentText("custom")

    def _apply_scale_preset(self, name: str) -> None:
        preset = core.SCALE_PRESETS.get(name)
        if preset is None:
            return
        scale, quadratic = preset
        self.scale_factor.blockSignals(True)
        self.quadratic.blockSignals(True)
        self.scale_factor.setValue(float(scale))
        self.quadratic.setValue(float(quadratic))
        self.scale_factor.blockSignals(False)
        self.quadratic.blockSignals(False)
        self._draw_spectra()

    def _set_range_values(self, low: float, high: float) -> None:
        self._updating_range = True
        try:
            self.range_min.setValue(float(low))
            self.range_max.setValue(float(high))
        finally:
            self._updating_range = False

    def _range_mode_changed(self, *_args) -> None:
        self.range_min.setEnabled(True)
        self.range_max.setEnabled(True)
        self._draw_spectra()

    def _range_edited(self, *_args) -> None:
        if self._updating_range:
            return
        if self.auto_range.isChecked():
            self.auto_range.setChecked(False)
        else:
            self._draw_spectra()

    def _update_conformer_table(self) -> None:
        self.conformer_table.setRowCount(0)
        for index, data in enumerate(self.outputs):
            row = self.conformer_table.rowCount()
            self.conformer_table.insertRow(row)
            weight = self.weights[index] if index < len(self.weights) else 0.0
            energy = data.get("energy")
            modes = data.get("modes") or []
            capabilities = []
            if any(mode.get("ir_intensity") is not None for mode in modes):
                capabilities.append("IR")
            if any(mode.get("raman_activity") is not None for mode in modes):
                capabilities.append("Raman")
            if any(mode.get("vcd_rotation") is not None for mode in modes):
                capabilities.append("VCD")
            values = (
                Path(str(data.get("path") or "output")).name,
                f"{energy:.8f}" if isinstance(energy, (int, float)) else "—",
                f"{weight * 100.0:.1f}%",
                " / ".join(capabilities) or "frequencies only",
            )
            for col, value in enumerate(values):
                self.conformer_table.setItem(row, col, QTableWidgetItem(str(value)))

    def _show_output(self) -> None:
        data = self.output
        self._update_weights()
        self._update_conformer_table()
        modes = data.get("modes") or []
        imaginary = data.get("imaginary_count")
        if imaginary is None:
            imaginary = sum(1 for mode in modes if mode.get("imaginary"))
        route = data.get("route") or ""
        level = "/".join(part for part in (data.get("method"), data.get("basis")) if part)
        lines = [
            f"Software: {data.get('software', '')}",
            f"Level: {level or '—'}" + (f"   Route: {route}" if route else ""),
            f"Energy: {data.get('energy')} Ha" if data.get("energy") is not None else "Energy: —",
            f"HOMO: {data.get('homo')} Ha" if data.get("homo") is not None else "HOMO: —",
            f"LUMO: {data.get('lumo')} Ha" if data.get("lumo") is not None else "LUMO: —",
            f"Gap: {data.get('gap')} Ha" if data.get("gap") is not None else "Gap: —",
            f"Modes: {len(modes)}   Imaginary: {imaginary}",
            f"IR intensity: {data.get('ir_intensity_source') or 'not printed'}",
            f"Raman: {'yes' if data.get('raman_available') else 'no'}   VCD: {'yes' if data.get('vcd_available') else 'no'}",
            f"Excitations: {len(data.get('excitations') or [])}",
            f"Conformers: {len(self.outputs)}   T = {self.temperature.value():.2f} K",
        ]
        self.result_summary.setPlainText("\n".join(lines))
        self._populate_frequency_table()
        self.exc_table.setRowCount(0)
        for exc in data.get("excitations") or []:
            row = self.exc_table.rowCount()
            self.exc_table.insertRow(row)
            for col, value in enumerate((exc.get("energy_ev"), exc.get("wavelength_nm"), exc.get("oscillator"))):
                self.exc_table.setItem(row, col, QTableWidgetItem(f"{value:.4f}" if value is not None else ""))
        self._draw_spectra()
        thermo = core.thermo(data.get("frequencies") or [], self.molecule) if self.molecule else {}
        if thermo:
            self.thermo_output.setPlainText(
                "\n".join(f"{key}: {value:.6f}" if isinstance(value, float) else f"{key}: {value}" for key, value in thermo.items())
            )
        else:
            self.thermo_output.setPlainText("Thermochemistry needs vibrational frequencies.")

    def _populate_frequency_table(self) -> None:
        data = self.output
        modes = data.get("modes") or []
        self.freq_table.setRowCount(0)
        scale = self.scale_factor.value()
        quadratic = self.quadratic.value()
        shift = self.shift.value()
        if not modes:
            for frequency in data.get("frequencies") or []:
                row = self.freq_table.rowCount()
                self.freq_table.insertRow(row)
                scaled = core.scaled_frequency(frequency, scale, quadratic, shift)
                values = ("", f"{frequency:.2f}", f"{scaled:.2f}", "", "", "")
                for col, value in enumerate(values):
                    self.freq_table.setItem(row, col, QTableWidgetItem(value))
            return
        for mode in modes:
            row = self.freq_table.rowCount()
            self.freq_table.insertRow(row)
            frequency = float(mode.get("frequency") or 0.0)
            scaled = core.scaled_frequency(frequency, scale, quadratic, shift)

            def fmt(value):
                return f"{value:.4g}" if isinstance(value, (int, float)) else ""

            values = (
                str(mode.get("mode", "")),
                f"{frequency:.2f}",
                f"{scaled:.2f}",
                fmt(mode.get("ir_intensity")),
                fmt(mode.get("raman_activity")),
                fmt(mode.get("vcd_rotation")),
            )
            for col, value in enumerate(values):
                self.freq_table.setItem(row, col, QTableWidgetItem(value))

    def _compute_spectrum(self):
        if not self.outputs:
            return None
        choices = {
            "Absorbance": ("ir", "IR absorbance", "km/mol"),
            "Transmittance": ("ir", "IR transmittance", "% T"),
            "VCD": ("vcd", "VCD", "rotational strength"),
            "Raman": ("raman", "Raman", "activity"),
        }
        kind, title, ylabel = choices.get(self.plot_type.currentText(), ("ir", "IR", "km/mol"))
        if self.auto_range.isChecked():
            low, high = core.spectrum_extent(
                self.outputs,
                kind=kind,
                scale=self.scale_factor.value(),
                quadratic=self.quadratic.value(),
                shift=self.shift.value(),
            )
            self._set_range_values(low, high)
        else:
            low = self.range_min.value()
            high = self.range_max.value()
            if high <= low:
                high = low + 100.0
                self._set_range_values(low, high)
        x, total, components = core.combined_spectrum(
            self.outputs,
            self.weights or [1.0] * len(self.outputs),
            kind=kind,
            fwhm=self.fwhm.value(),
            peak_type=self.peak_type.currentText(),
            voigt_mix=self.voigt_mix.value(),
            scale=self.scale_factor.value(),
            quadratic=self.quadratic.value(),
            shift=self.shift.value(),
            x_min=low,
            x_max=high,
        )
        available = any(component.get("peaks") for component in components)
        if self.plot_type.currentText() == "Transmittance":
            total = core.transmittance(total)
            components = [
                dict(component, y=core.transmittance(component["y"]))
                for component in components
            ]
        return {
            "x": x,
            "y": total,
            "components": components,
            "kind": kind,
            "title": title,
            "ylabel": ylabel,
            "available": available,
            "x_min": low,
            "x_max": high,
        }

    def _draw_spectra(self) -> None:
        if not MATPLOTLIB_OK or not hasattr(self.spectrum_canvas, "figure"):
            return
        if self.outputs:
            self._update_weights()
            self._update_conformer_table()
            self._populate_frequency_table()
        fig = self.spectrum_canvas.figure
        fig.clear()
        ax1 = fig.add_subplot(121)
        ax2 = fig.add_subplot(122)
        spectrum = self._compute_spectrum()
        if spectrum is None:
            ax1.text(0.5, 0.5, "No output loaded", ha="center", va="center")
            ax1.axis("off")
        elif not spectrum["available"]:
            ax1.text(
                0.5,
                0.5,
                f"No {self.plot_type.currentText()} data\nin the loaded output(s)",
                ha="center",
                va="center",
            )
            ax1.axis("off")
        else:
            x = spectrum["x"]
            y = spectrum["y"]
            if self.show_components.isChecked() and len(spectrum["components"]) > 1:
                for component in spectrum["components"]:
                    ax1.plot(
                        x,
                        component["y"],
                        lw=1.0,
                        alpha=0.55,
                        label=f"{component['label']} ({component['weight'] * 100:.1f}%)",
                    )
            ax1.plot(x, y, color="#2563eb", lw=1.8, label="total")
            if self.experimental is not None:
                exp_x, exp_y = self.experimental
                peak = float(np.max(np.abs(y))) if len(y) else 0.0
                exp_peak = float(np.max(np.abs(exp_y))) if len(exp_y) else 0.0
                if peak > 0 and exp_peak > 0:
                    ax1.plot(
                        exp_x,
                        exp_y * peak / exp_peak,
                        color="#6b7280",
                        lw=1.0,
                        ls="--",
                        label="experimental",
                    )
            ax1.set_title(spectrum["title"])
            ax1.set_xlabel("cm⁻¹")
            ax1.set_ylabel(spectrum["ylabel"])
            if self.reverse_x.isChecked():
                ax1.invert_xaxis()
            if self.show_components.isChecked() and len(spectrum["components"]) > 1:
                ax1.legend(fontsize=7, frameon=False)
            elif self.experimental is not None:
                ax1.legend(fontsize=7, frameon=False)
        self.spectrum_data = spectrum or {}

        excitations = []
        for data in self.outputs:
            excitations.extend(data.get("excitations") or [])
        if excitations:
            x_uv = None
            y_uv = None
            for index, data in enumerate(self.outputs):
                values = data.get("excitations") or []
                if not values:
                    continue
                x_part, y_part = core.uv_spectrum(values)
                weight = self.weights[index] if index < len(self.weights) else 1.0
                y_part = y_part * weight
                x_uv = x_part
                y_uv = y_part if y_uv is None else y_uv + y_part
            if x_uv is not None and y_uv is not None:
                ax2.plot(x_uv, y_uv, color="#dc2626")
                ax2.set_title("UV/Vis (broadened)")
                ax2.set_xlabel("nm")
            else:
                ax2.text(0.5, 0.5, "No excitations", ha="center", va="center")
                ax2.axis("off")
        else:
            ax2.text(0.5, 0.5, "No excitations", ha="center", va="center")
            ax2.axis("off")
        fig.tight_layout()
        self.spectrum_canvas.draw_idle()

    def _load_experimental_csv(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Load experimental spectrum",
            str(Path.home()),
            "CSV/Text (*.csv *.txt *.dat);;All files (*)",
        )
        if not path:
            return
        x_values, y_values = [], []
        try:
            for line in Path(path).read_text(encoding="utf-8", errors="replace").splitlines():
                stripped = line.strip()
                if not stripped or stripped.startswith("#"):
                    continue
                parts = stripped.replace(",", " ").replace(";", " ").split()
                if len(parts) < 2:
                    continue
                try:
                    x_values.append(float(parts[0]))
                    y_values.append(float(parts[1]))
                except ValueError:
                    continue
        except OSError as exc:
            QMessageBox.warning(self, "SEQItachi", str(exc))
            return
        if not x_values:
            QMessageBox.warning(self, "SEQItachi", "No numeric x,y rows were found.")
            return
        self.experimental = (np.asarray(x_values), np.asarray(y_values))
        self._draw_spectra()
        self.status.setText(f"Experimental spectrum loaded: {Path(path).name}")

    def _clear_experimental(self) -> None:
        self.experimental = None
        self._draw_spectra()
        self.status.setText("Experimental spectrum cleared.")

    def _export_spectrum_csv(self) -> None:
        if not self.outputs:
            QMessageBox.information(self, "SEQItachi", "Load at least one output first.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Export spectrum CSV",
            str(Path.home() / "seqitachi_spectrum.csv"),
            "CSV (*.csv);;All files (*)",
        )
        if not path:
            return
        peaks = core.spectrum_peaks(
            self.outputs,
            self.weights,
            kind={"Absorbance": "ir", "Transmittance": "ir", "VCD": "vcd", "Raman": "raman"}.get(
                self.plot_type.currentText(), "ir"
            ),
            scale=self.scale_factor.value(),
            quadratic=self.quadratic.value(),
            shift=self.shift.value(),
        )
        try:
            with open(path, "w", encoding="utf-8", newline="") as handle:
                handle.write("# SEQItachi spectrum export\n")
                handle.write(f"# plot_type,{self.plot_type.currentText()}\n")
                handle.write(f"# peak_type,{self.peak_type.currentText()}\n")
                handle.write(f"# fwhm_cm-1,{self.fwhm.value():.4f}\n")
                handle.write(f"# voigt_mix,{self.voigt_mix.value():.4f}\n")
                handle.write(f"# scale_factor,{self.scale_factor.value():.6f}\n")
                handle.write(f"# quadratic,{self.quadratic.value():.8f}\n")
                handle.write(f"# shift_cm-1,{self.shift.value():.4f}\n")
                handle.write(f"# temperature_K,{self.temperature.value():.2f}\n")
                handle.write("# conformer,energy_Ha,weight\n")
                for index, data in enumerate(self.outputs):
                    handle.write(
                        "# {},{},{:.8f}\n".format(
                            Path(str(data.get("path") or "output")).name,
                            data.get("energy") if data.get("energy") is not None else "",
                            self.weights[index] if index < len(self.weights) else 0.0,
                        )
                    )
                writer = csv.writer(handle)
                writer.writerow(
                    [
                        "conformer",
                        "path",
                        "weight",
                        "mode",
                        "frequency_cm-1",
                        "scaled_cm-1",
                        "ir_intensity",
                        "raman_activity",
                        "vcd_rotation",
                        "imaginary",
                        "selected_intensity",
                    ]
                )
                for row in peaks:
                    writer.writerow(
                        [
                            row.get("conformer"),
                            row.get("path"),
                            f"{row.get('weight', 0.0):.8f}",
                            row.get("mode"),
                            f"{row.get('frequency', 0.0):.4f}",
                            f"{row.get('scaled', 0.0):.4f}",
                            "" if row.get("ir_intensity") is None else f"{row['ir_intensity']:.6f}",
                            "" if row.get("raman_activity") is None else f"{row['raman_activity']:.6f}",
                            "" if row.get("vcd_rotation") is None else f"{row['vcd_rotation']:.6f}",
                            "true" if row.get("imaginary") else "false",
                            "" if row.get("selected") is None else f"{row['selected']:.6f}",
                        ]
                    )
            spectrum = self.spectrum_data or self._compute_spectrum()
            if spectrum:
                curve_path = Path(path).with_name(Path(path).stem + "_curve.csv")
                with open(curve_path, "w", encoding="utf-8", newline="") as handle:
                    writer = csv.writer(handle)
                    header = ["wavenumber_cm-1", "total"]
                    header += [f"component_{index + 1}" for index in range(len(spectrum.get("components") or []))]
                    writer.writerow(header)
                    components = spectrum.get("components") or []
                    for index, x in enumerate(spectrum["x"]):
                        row = [f"{x:.4f}", f"{spectrum['y'][index]:.8f}"]
                        for component in components:
                            row.append(f"{component['y'][index]:.8f}")
                        writer.writerow(row)
            QMessageBox.information(
                self,
                "SEQItachi",
                f"Spectrum table: {path}\nCurve data: {Path(path).stem}_curve.csv",
            )
        except OSError as exc:
            QMessageBox.warning(self, "SEQItachi", str(exc))

    def _use_output_geometry(self) -> None:
        if self.output.get("geometry"):
            self.molecule = self.output["geometry"]
            self._refresh_all()

    # -- cube -------------------------------------------------------------

    def _load_cube(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Load cube", str(Path.home()), "Cube (*.cube);;All files (*)")
        if not path: return
        try:
            self.cube = core.parse_cube(path)
            dims = self.cube["dims"]
            self.cube_index.setRange(0, max(dims) - 1); self.cube_index.setValue(dims[2] // 2)
            self.cube_info.setText(f"{Path(path).name} · grid {dims[0]}×{dims[1]}×{dims[2]} · {len(self.cube['atoms'])} atoms")
            self._draw_cube()
        except Exception as exc:
            QMessageBox.warning(self, "SEQItachi", str(exc))

    def _draw_cube(self) -> None:
        if not MATPLOTLIB_OK or not hasattr(self.cube_canvas, "figure") or not self.cube:
            return
        axis = self.cube_axis.currentText()
        index = self.cube_index.value()
        data = core.cube_slice(self.cube, axis, index)
        fig = self.cube_canvas.figure; fig.clear(); ax = fig.add_subplot(111)
        values = np.asarray(data["values"]); u = np.asarray(data["u"]); v = np.asarray(data["v"])
        maximum = max(abs(float(values.min())), abs(float(values.max())), 1e-12)
        levels = np.linspace(-maximum, maximum, 25)
        contour = ax.contourf(u, v, values, levels=levels, cmap="RdBu_r")
        ax.contour(u, v, values, levels=[0.0], colors="#111827", linewidths=0.5)
        ax.set_aspect("equal"); ax.set_title(f"{axis} = {index}")
        fig.colorbar(contour, ax=ax, fraction=0.046, pad=0.03)
        fig.tight_layout(); self.cube_canvas.draw_idle()

    def _use_cube_atoms(self) -> None:
        if not self.cube:
            return
        self.molecule = core.Molecule([tuple(atom) for atom in self.cube["atoms"]], name="cube geometry")
        self.molecule.infer_bonds()
        self._refresh_all()

    # -- lifecycle --------------------------------------------------------

    def cleanup(self) -> None:
        pass
