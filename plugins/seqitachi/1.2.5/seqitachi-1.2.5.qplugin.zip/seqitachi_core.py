"""SEQItachi core: structures, parsers, analysis, QM input, spectra and cubes.

Independent QAH implementation inspired by SEQCROW's workflow. No SEQCROW code
is copied. SEQCROW itself is GPL-3.0; this plugin is GPL-3.0 or later.
"""

from __future__ import annotations

import hashlib
import math
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None  # type: ignore

# symbol, atomic number, standard atomic weight, covalent radius (angstrom)
_ELEMENT_ROWS = [
    ("H", 1, 1.008, 0.31), ("He", 2, 4.0026, 0.28),
    ("Li", 3, 6.94, 1.28), ("Be", 4, 9.0122, 0.96), ("B", 5, 10.81, 0.84),
    ("C", 6, 12.011, 0.76), ("N", 7, 14.007, 0.71), ("O", 8, 15.999, 0.66),
    ("F", 9, 18.998, 0.57), ("Ne", 10, 20.180, 0.58),
    ("Na", 11, 22.990, 1.66), ("Mg", 12, 24.305, 1.41), ("Al", 13, 26.982, 1.21),
    ("Si", 14, 28.085, 1.11), ("P", 15, 30.974, 1.07), ("S", 16, 32.06, 1.05),
    ("Cl", 17, 35.45, 1.02), ("Ar", 18, 39.948, 1.06),
    ("K", 19, 39.098, 2.03), ("Ca", 20, 40.078, 1.76), ("Sc", 21, 44.956, 1.70),
    ("Ti", 22, 47.867, 1.60), ("V", 23, 50.942, 1.53), ("Cr", 24, 51.996, 1.39),
    ("Mn", 25, 54.938, 1.39), ("Fe", 26, 55.845, 1.32), ("Co", 27, 58.933, 1.26),
    ("Ni", 28, 58.693, 1.24), ("Cu", 29, 63.546, 1.32), ("Zn", 30, 65.38, 1.22),
    ("Ga", 31, 69.723, 1.22), ("Ge", 32, 72.630, 1.20), ("As", 33, 74.922, 1.19),
    ("Se", 34, 78.971, 1.20), ("Br", 35, 79.904, 1.20), ("Kr", 36, 83.798, 1.16),
    ("Rb", 37, 85.468, 2.20), ("Sr", 38, 87.62, 1.95), ("Y", 39, 88.906, 1.90),
    ("Zr", 40, 91.224, 1.75), ("Nb", 41, 92.906, 1.64), ("Mo", 42, 95.95, 1.54),
    ("Tc", 43, 98.0, 1.47), ("Ru", 44, 101.07, 1.46), ("Rh", 45, 102.91, 1.42),
    ("Pd", 46, 106.42, 1.39), ("Ag", 47, 107.87, 1.45), ("Cd", 48, 112.41, 1.44),
    ("In", 49, 114.82, 1.42), ("Sn", 50, 118.71, 1.39), ("Sb", 51, 121.76, 1.39),
    ("Te", 52, 127.60, 1.38), ("I", 53, 126.90, 1.39), ("Xe", 54, 131.29, 1.40),
    ("Cs", 55, 132.91, 2.44), ("Ba", 56, 137.33, 2.15), ("La", 57, 138.91, 2.07),
    ("Ce", 58, 140.12, 2.04), ("Pr", 59, 140.91, 2.03), ("Nd", 60, 144.24, 2.01),
    ("Pm", 61, 145.0, 1.99), ("Sm", 62, 150.36, 1.98), ("Eu", 63, 151.96, 1.98),
    ("Gd", 64, 157.25, 1.96), ("Tb", 65, 158.93, 1.95), ("Dy", 66, 162.50, 1.92),
    ("Ho", 67, 164.93, 1.92), ("Er", 68, 167.26, 1.89), ("Tm", 69, 168.93, 1.90),
    ("Yb", 70, 173.05, 1.87), ("Lu", 71, 174.97, 1.87), ("Hf", 72, 178.49, 1.75),
    ("Ta", 73, 180.95, 1.70), ("W", 74, 183.84, 1.62), ("Re", 75, 186.21, 1.51),
    ("Os", 76, 190.23, 1.44), ("Ir", 77, 192.22, 1.41), ("Pt", 78, 195.08, 1.36),
    ("Au", 79, 196.97, 1.36), ("Hg", 80, 200.59, 1.32), ("Tl", 81, 204.38, 1.45),
    ("Pb", 82, 207.2, 1.46), ("Bi", 83, 208.98, 1.48), ("Po", 84, 209.0, 1.40),
    ("At", 85, 210.0, 1.50), ("Rn", 86, 222.0, 1.50),
]
SYMBOLS = [row[0] for row in _ELEMENT_ROWS]
Z_BY_SYMBOL = {row[0]: row[1] for row in _ELEMENT_ROWS}
SYMBOL_BY_Z = {row[1]: row[0] for row in _ELEMENT_ROWS}
WEIGHT = {row[0]: row[2] for row in _ELEMENT_ROWS}
COVALENT = {row[0]: row[3] for row in _ELEMENT_ROWS}

HARTREE_TO_KJ = 2625.4996394799
HARTREE_TO_EV = 27.211386245988
CM_TO_EV = 0.0001239841984332003
R_GAS = 8.31446261815324
H_PLANCK = 6.62607015e-34
C_LIGHT = 2.99792458e8
KB = 1.380649e-23
AMU = 1.66053906660e-27
R_HARTREE = 3.166811563e-6  # Hartree / K

# Common harmonic frequency scaling factors (approximate literature values).
# The UI exposes these as presets; a manual factor always wins.
SCALE_PRESETS = {
    "B3LYP/6-31G(d)": (0.961, 0.0),
    "B3LYP/6-31G*": (0.961, 0.0),
    "B3LYP/6-311G(d,p)": (0.967, 0.0),
    "B3LYP/def2-SVP": (0.965, 0.0),
    "B3LYP/def2-TZVP": (0.965, 0.0),
    "B3LYP/cc-pVTZ": (0.966, 0.0),
    "PBE0/def2-TZVP": (0.956, 0.0),
    "PBE0/6-31G(d)": (0.950, 0.0),
    "M06-2X/6-31G(d)": (0.955, 0.0),
    "M06-2X/def2-TZVP": (0.947, 0.0),
    "BP86/def2-SVP": (0.9956, 0.0),
    "BP86/6-31G(d)": (0.994, 0.0),
    "HF/6-31G(d)": (0.899, 0.0),
    "HF/6-311G(d,p)": (0.905, 0.0),
    "MP2/6-31G(d)": (0.943, 0.0),
    "MP2/cc-pVTZ": (0.950, 0.0),
}

_METHOD_NAMES = (
    "M06-2X", "M06-2X-D3", "M06-L", "M06", "WB97X-D3", "WB97X-D", "WB97X",
    "B3LYP", "B3PW91", "B3P86", "PBE0", "PBE", "BP86", "BLYP", "TPSS",
    "CAM-B3LYP", "LC-WPBE", "HF", "MP2", "RI-MP2", "CCSD", "CCSD(T)",
)
_BASIS_NAMES = (
    "DEF2-QZVPP", "DEF2-QZVP", "DEF2-TZVPP", "DEF2-TZVP", "DEF2-SVP",
    "CC-PVQZ", "CC-PVTZ", "CC-PVDZ", "6-311++G(2D,2P)", "6-311++G(D,P)",
    "6-311G(D,P)", "6-311G(D)", "6-31++G(D,P)", "6-31+G(D)", "6-31G(D,P)",
    "6-31G(D)", "6-31G*", "STO-3G",
)


@dataclass
class Molecule:
    atoms: List[Tuple[str, float, float, float]] = field(default_factory=list)
    bonds: List[Tuple[int, int, float]] = field(default_factory=list)
    name: str = "molecule"
    charge: int = 0
    multiplicity: int = 1
    comment: str = ""

    def copy(self) -> "Molecule":
        return Molecule(
            [tuple(atom) for atom in self.atoms],
            [tuple(bond) for bond in self.bonds],
            self.name,
            self.charge,
            self.multiplicity,
            self.comment,
        )

    def __len__(self) -> int:
        return len(self.atoms)

    def coords(self):
        if np is None:
            return []
        return np.asarray([[a[1], a[2], a[3]] for a in self.atoms], dtype=float)

    def symbols(self) -> List[str]:
        return [atom[0] for atom in self.atoms]

    def formula(self) -> str:
        counts = {}
        for symbol, *_ in self.atoms:
            counts[symbol] = counts.get(symbol, 0) + 1
        order = sorted(counts, key=lambda s: (s != "C", s != "H", s))
        return "".join(symbol + (str(counts[symbol]) if counts[symbol] > 1 else "") for symbol in order)

    def molecular_weight(self) -> float:
        return sum(WEIGHT.get(symbol, 0.0) for symbol, *_ in self.atoms)

    def infer_bonds(self, tolerance: float = 1.18) -> None:
        self.bonds = []
        if np is None:
            return
        coords = self.coords()
        for i in range(len(coords)):
            for j in range(i + 1, len(coords)):
                d = float(np.linalg.norm(coords[i] - coords[j]))
                cutoff = (COVALENT.get(self.atoms[i][0], 0.8) + COVALENT.get(self.atoms[j][0], 0.8)) * tolerance
                if 0.25 < d <= cutoff:
                    self.bonds.append((i, j, 1.0))
        # remove H-H contacts except H2
        if len(self.atoms) > 2:
            self.bonds = [b for b in self.bonds if not (self.atoms[b[0]][0] == "H" and self.atoms[b[1]][0] == "H")]

    def to_xyz(self) -> str:
        lines = [str(len(self.atoms)), self.name]
        for symbol, x, y, z in self.atoms:
            lines.append(f"{symbol:2s} {x:14.8f} {y:14.8f} {z:14.8f}")
        return "\n".join(lines) + "\n"

    @classmethod
    def from_xyz_text(cls, text: str) -> "Molecule":
        lines = text.splitlines()
        if len(lines) < 3:
            raise ValueError("XYZ needs at least 3 lines")
        count = int(lines[0].strip())
        atoms = []
        for line in lines[2 : 2 + count]:
            parts = line.split()
            if len(parts) < 4:
                raise ValueError(f"Bad XYZ atom line: {line!r}")
            atoms.append((parts[0], float(parts[1]), float(parts[2]), float(parts[3])))
        mol = cls(atoms, name=lines[1].strip() or "molecule")
        mol.infer_bonds()
        return mol

    @classmethod
    def from_xyz_file(cls, path: os.PathLike | str) -> "Molecule":
        return cls.from_xyz_text(Path(path).read_text(encoding="utf-8", errors="replace"))

    def center_of_mass(self):
        if np is None or not self.atoms:
            return (0.0, 0.0, 0.0)
        masses = np.asarray([WEIGHT.get(a[0], 1.0) for a in self.atoms])
        coords = self.coords()
        return tuple((coords * masses[:, None]).sum(axis=0) / masses.sum())

    def radius_of_gyration(self) -> float:
        if np is None or not self.atoms:
            return 0.0
        masses = np.asarray([WEIGHT.get(a[0], 1.0) for a in self.atoms])
        coords = self.coords()
        com = np.asarray(self.center_of_mass())
        return float(math.sqrt(((masses * ((coords - com) ** 2).sum(axis=1)).sum()) / masses.sum()))

    def distance(self, i: int, j: int) -> float:
        a, b = np.asarray(self.atoms[i][1:]), np.asarray(self.atoms[j][1:])
        return float(np.linalg.norm(a - b))

    def angle(self, i: int, j: int, k: int) -> float:
        a = np.asarray(self.atoms[i][1:]) - np.asarray(self.atoms[j][1:])
        b = np.asarray(self.atoms[k][1:]) - np.asarray(self.atoms[j][1:])
        cosang = float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-12))
        return math.degrees(math.acos(max(-1.0, min(1.0, cosang))))

    def dihedral(self, i: int, j: int, k: int, l: int) -> float:
        p0, p1, p2, p3 = (np.asarray(self.atoms[x][1:]) for x in (i, j, k, l))
        b0, b1, b2 = p0 - p1, p2 - p1, p3 - p2
        b1n = b1 / (np.linalg.norm(b1) + 1e-12)
        v = b0 - np.dot(b0, b1n) * b1n
        w = b2 - np.dot(b2, b1n) * b1n
        return math.degrees(math.atan2(float(np.dot(np.cross(b1n, v), w)), float(np.dot(v, w))))

    def add_atom(self, symbol: str, x: float, y: float, z: float) -> int:
        self.atoms.append((symbol, float(x), float(y), float(z)))
        return len(self.atoms) - 1

    def remove_atom(self, index: int) -> None:
        if not (0 <= index < len(self.atoms)):
            return
        self.atoms.pop(index)
        bonds = []
        for i, j, order in self.bonds:
            if i == index or j == index:
                continue
            bonds.append((i - (i > index), j - (j > index), order))
        self.bonds = bonds

    def set_element(self, index: int, symbol: str) -> None:
        if 0 <= index < len(self.atoms):
            self.atoms[index] = (symbol, *self.atoms[index][1:])

    def add_bond(self, i: int, j: int, order: float = 1.0) -> None:
        if i == j or not (0 <= i < len(self.atoms) and 0 <= j < len(self.atoms)):
            return
        self.remove_bond(i, j)
        self.bonds.append((min(i, j), max(i, j), float(order)))

    def remove_bond(self, i: int, j: int) -> None:
        self.bonds = [b for b in self.bonds if {b[0], b[1]} != {i, j}]

    def set_bond_length(self, i: int, j: int, length: float) -> None:
        a, b = np.asarray(self.atoms[i][1:]), np.asarray(self.atoms[j][1:])
        direction = b - a
        norm = np.linalg.norm(direction)
        if norm < 1e-9:
            return
        new_b = a + direction / norm * float(length)
        self.atoms[j] = (self.atoms[j][0], *map(float, new_b))

    def translate(self, dx: float, dy: float, dz: float) -> None:
        self.atoms = [(s, x + dx, y + dy, z + dz) for s, x, y, z in self.atoms]

    def rotate(self, axis: Sequence[float], degrees: float, center: Optional[Sequence[float]] = None) -> None:
        axis = np.asarray(axis, dtype=float)
        norm = np.linalg.norm(axis)
        if norm < 1e-9:
            return
        axis = axis / norm
        theta = math.radians(degrees)
        K = np.array([[0, -axis[2], axis[1]], [axis[2], 0, -axis[0]], [-axis[1], axis[0], 0]])
        R = np.eye(3) + math.sin(theta) * K + (1 - math.cos(theta)) * (K @ K)
        origin = np.asarray(center if center is not None else self.center_of_mass(), dtype=float)
        self.atoms = [
            (s, *(R @ (np.asarray((x, y, z)) - origin) + origin)) for s, x, y, z in self.atoms
        ]

    def align_to(self, other: "Molecule") -> None:
        if len(self.atoms) != len(other.atoms) or np is None:
            return
        P = self.coords() - self.coords().mean(axis=0)
        Q = other.coords() - other.coords().mean(axis=0)
        H = P.T @ Q
        U, _, Vt = np.linalg.svd(H)
        d = np.sign(np.linalg.det(Vt.T @ U.T))
        R = Vt.T @ np.diag([1, 1, d]) @ U.T
        transformed = (R @ self.coords().T).T
        transformed += other.coords().mean(axis=0) - transformed.mean(axis=0)
        self.atoms = [(a[0], *map(float, transformed[i])) for i, a in enumerate(self.atoms)]


# -- parsing ---------------------------------------------------------------


def _last_float(pattern: str, text: str) -> Optional[float]:
    matches = re.findall(pattern, text, re.IGNORECASE)
    return float(matches[-1]) if matches else None


def _parse_gaussian_geometry(text: str) -> Optional[Molecule]:
    for marker in ("Standard orientation:", "Input orientation:"):
        start = text.rfind(marker)
        if start < 0:
            continue
        lines = text[start:].splitlines()
        dashes = [i for i, line in enumerate(lines) if line.strip().startswith("---")]
        if len(dashes) < 3:
            continue
        atoms = []
        for line in lines[dashes[1] + 1 : dashes[2]]:
            parts = line.split()
            if len(parts) < 6:
                continue
            try:
                atomic_number = int(parts[1])
                atoms.append((SYMBOL_BY_Z.get(atomic_number, "X"), float(parts[3]), float(parts[4]), float(parts[5])))
            except ValueError:
                continue
        if atoms:
            mol = Molecule(atoms, name="Gaussian geometry")
            mol.infer_bonds()
            return mol
    return None


def guess_method_basis(text: str) -> Tuple[str, str]:
    """Best-effort method/basis detection from a route line or output header."""
    upper = text.upper()
    method = ""
    for name in _METHOD_NAMES:
        if re.search(r"(?<![A-Z0-9-])" + re.escape(name) + r"(?![A-Z0-9-])", upper):
            method = name
            break
    basis = ""
    for name in _BASIS_NAMES:
        if name in upper:
            basis = name
            break
    return method, basis


def _orca_route(text: str) -> Tuple[str, str, str]:
    routes = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("!"):
            routes.append(stripped[1:].strip())
            continue
        match = re.match(r"\|?\s*\d+>\s*!\s*(.*)", stripped)
        if match:
            routes.append(match.group(1).strip())
    for route in routes:
        method, basis = guess_method_basis(route)
        if method and basis:
            return route, method, basis
    if routes:
        method, basis = guess_method_basis(routes[0])
        return routes[0], method, basis
    return "", "", ""


def _new_mode(index: int, frequency: float) -> Dict[str, Any]:
    return {
        "mode": int(index),
        "frequency": float(frequency),
        "ir_intensity": None,
        "raman_activity": None,
        "vcd_rotation": None,
        "imaginary": frequency < 0,
    }


def _modes_from_orca(text: str) -> Tuple[List[Dict[str, Any]], str]:
    modes: List[Dict[str, Any]] = []
    lines = text.splitlines()

    # Scan from the real section heading to NORMAL MODES/IR SPECTRUM. ORCA 6
    # inserts blank lines and a "Scaling factor" line before the mode values,
    # so a regex stopping at the first blank line misses every mode.
    section_start = None
    for index, line in enumerate(lines):
        if line.strip() != "VIBRATIONAL FREQUENCIES":
            continue
        window = lines[index + 1 : index + 3]
        if any(item.strip() and not item.strip().strip("-") for item in window):
            section_start = index + 1
            break
    if section_start is not None:
        for line in lines[section_start:]:
            stripped = line.strip()
            if stripped in ("NORMAL MODES", "IR SPECTRUM", "THERMOCHEMISTRY"):
                break
            match = re.match(r"\s*(\d+):\s+(-?\d+\.\d+)\s+cm", line)
            if not match:
                continue
            frequency = float(match.group(2))
            if abs(frequency) <= 0.5:
                continue
            modes.append(_new_mode(int(match.group(1)), frequency))

    # IR intensities: column "Int" (ORCA 4.2.1+) or "T**2" (older).
    ir_source = ""
    for index, line in enumerate(lines):
        if line.strip() != "IR SPECTRUM":
            continue
        header_index = index + 1
        while header_index < len(lines):
            stripped = lines[header_index].strip()
            if not stripped or not stripped.strip("-"):
                header_index += 1
                continue
            break
        if header_index >= len(lines):
            break
        header = lines[header_index].split()
        lowered = [token.lower().strip(":") for token in header]
        intensity_index = None
        if "int" in lowered:
            intensity_index = lowered.index("int")
            ir_source = "Int (km/mol)"
        elif "t**2" in lowered:
            intensity_index = lowered.index("t**2") - 1
            ir_source = "T**2 (a.u.)"
        if intensity_index is None:
            break
        by_mode = {mode["mode"]: mode for mode in modes}
        started = False
        for data_line in lines[header_index + 1 :]:
            match = re.match(r"\s*(\d+):", data_line)
            if not match:
                if not data_line.strip():
                    continue
                if started or data_line.strip().startswith("OVERTONES"):
                    break
                continue
            started = True
            fields = data_line.split()
            if intensity_index >= len(fields):
                continue
            try:
                value = float(fields[intensity_index])
            except (TypeError, ValueError):
                continue
            mode = by_mode.get(int(match.group(1)))
            if mode is not None:
                mode["ir_intensity"] = value
        break

    # Raman activities: ORCA prints mode, frequency, activity, depolarization.
    for index, line in enumerate(lines):
        if line.strip() != "RAMAN SPECTRUM":
            continue
        by_mode = {mode["mode"]: mode for mode in modes}
        started = False
        for data_line in lines[index + 1 :]:
            match = re.match(r"\s*(\d+):", data_line)
            if not match:
                if started and data_line.strip() and not data_line.strip().startswith("-"):
                    break
                continue
            started = True
            fields = data_line.split()
            if len(fields) < 3:
                continue
            try:
                activity = float(fields[2])
            except (TypeError, ValueError):
                continue
            mode = by_mode.get(int(match.group(1)))
            if mode is not None:
                mode["raman_activity"] = activity
        break

    # VCD: optional table of mode, frequency, rotational strength.
    for index, line in enumerate(lines):
        if "VCD SPECTRUM CALCULATION" not in line:
            continue
        candidates: List[Tuple[int, float, float]] = []
        for data_line in lines[index + 1 :]:
            match = re.match(
                r"\s*(\d+):?\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)", data_line
            )
            if not match:
                continue
            candidates.append(
                (int(match.group(1)), float(match.group(2)), float(match.group(3)))
            )
        by_mode = {mode["mode"]: mode for mode in modes}
        real_modes = [mode for mode in modes if not mode["imaginary"]]
        real_index = 0
        for mode_index, frequency, rotation in candidates:
            mode = by_mode.get(mode_index)
            if mode is None and real_index < len(real_modes):
                mode = real_modes[real_index]
            if mode is not None:
                mode["vcd_rotation"] = rotation
                real_index += 1
        break

    return modes, ir_source


def _numbers_after_dash(text: str, marker: str) -> List[float]:
    values: List[float] = []
    for line in text.splitlines():
        if marker in line and "--" in line:
            payload = line.split("--", 1)[1]
            values.extend(float(x) for x in re.findall(r"-?\d+\.\d+", payload))
    return values


def _parse_gaussian(text: str) -> Dict[str, Any]:
    result: Dict[str, Any] = {"software": "Gaussian"}
    result["energy"] = _last_float(r"SCF Done:\s+E\([^)]*\)\s+=\s+(-?\d+\.\d+)", text)
    route = ""
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("#"):
            route = stripped.lstrip("#").strip()
            break
    method, basis = guess_method_basis(route)
    result["route"] = route
    result["method"] = method
    result["basis"] = basis
    occ = re.findall(r"Alpha\s+occ\.\s+eigenvalues\s+--\s+([\d\s.-]+)", text)
    virt = re.findall(r"Alpha\s+virt\.\s+eigenvalues\s+--\s+([\d\s.-]+)", text)
    if occ and virt:
        occ_values = [float(x) for x in occ[-1].split()]
        virt_values = [float(x) for x in virt[-1].split()]
        if occ_values and virt_values:
            result["homo"] = occ_values[-1]
            result["lumo"] = virt_values[0]
    raw_freqs = []
    for block in re.findall(r"Frequencies\s+---\s+([\d\s.-]+)", text):
        raw_freqs.extend(float(x) for x in block.split())
    ir_values = _numbers_after_dash(text, "IR Inten")
    raman_values = _numbers_after_dash(text, "Raman Activ")
    vcd_values = _numbers_after_dash(text, "Rot. str.")
    modes = []
    for index, frequency in enumerate(raw_freqs):
        if abs(frequency) <= 0.5:
            continue
        mode = _new_mode(index, frequency)
        if index < len(ir_values):
            mode["ir_intensity"] = ir_values[index]
        if index < len(raman_values):
            mode["raman_activity"] = raman_values[index]
        if index < len(vcd_values):
            mode["vcd_rotation"] = vcd_values[index]
        modes.append(mode)
    result["modes"] = modes
    result["frequencies"] = [m["frequency"] for m in modes if m["frequency"] > 10.0]
    result["imaginary_count"] = sum(1 for m in modes if m["imaginary"])
    result["ir_intensity_source"] = "IR Inten (km/mol)" if ir_values else ""
    result["raman_available"] = bool(raman_values)
    result["vcd_available"] = bool(vcd_values)
    result["excitations"] = []
    for match in re.finditer(
        r"Excited State\s+\d+:\s+.*?([\d.]+)\s+eV\s+([\d.]+)\s+nm\s+f=([\d.]+)",
        text,
    ):
        result["excitations"].append({
            "energy_ev": float(match.group(1)),
            "wavelength_nm": float(match.group(2)),
            "oscillator": float(match.group(3)),
        })
    result["geometry"] = _parse_gaussian_geometry(text)
    return result


def _parse_orca_geometry(text: str) -> Optional[Molecule]:
    match = re.search(
        r"CARTESIAN COORDINATES \(ANGSTROEM\)\s*-+\s*(.*?)\n\s*\n",
        text,
        re.DOTALL,
    )
    if not match:
        return None
    atoms = []
    for line in match.group(1).splitlines():
        parts = line.split()
        if len(parts) >= 4:
            try:
                atoms.append((parts[0], float(parts[1]), float(parts[2]), float(parts[3])))
            except ValueError:
                continue
    if not atoms:
        return None
    mol = Molecule(atoms, name="ORCA geometry")
    mol.infer_bonds()
    return mol


def _parse_orca(text: str) -> Dict[str, Any]:
    result: Dict[str, Any] = {"software": "ORCA"}
    result["energy"] = _last_float(r"FINAL SINGLE POINT ENERGY\s+(-?\d+\.\d+)", text)
    occ, virt = [], []
    block = re.search(r"ORBITAL ENERGIES\s*-+\s*(.*?)\n\s*\n", text, re.DOTALL)
    if block:
        for line in block.group(1).splitlines():
            if "MOLECULAR ORBITALS" in line:
                break
            parts = line.split()
            if len(parts) < 4 or not re.fullmatch(r"\d+", parts[0]):
                continue
            try:
                occupancy = float(parts[1])
                energy = float(parts[2])
            except ValueError:
                continue
            if occupancy > 0:
                occ.append(energy)
            else:
                virt.append(energy)
    if occ and virt:
        result["homo"] = max(occ)
        result["lumo"] = min(virt)
    route, method, basis = _orca_route(text)
    result["route"] = route
    result["method"] = method
    result["basis"] = basis
    modes, ir_source = _modes_from_orca(text)
    result["modes"] = modes
    result["frequencies"] = [m["frequency"] for m in modes if m["frequency"] > 10.0]
    result["imaginary_count"] = sum(1 for m in modes if m["imaginary"])
    result["ir_intensity_source"] = ir_source
    result["raman_available"] = any(m.get("raman_activity") is not None for m in modes)
    result["vcd_available"] = any(m.get("vcd_rotation") is not None for m in modes)
    result["excitations"] = []
    block = re.search(
        r"ABSORPTION SPECTRUM VIA TRANSITION ELECTRIC DIPOLE MOMENTS\s*-+\s*(.*?)\n\s*\n",
        text,
        re.DOTALL,
    )
    if block:
        for line in block.group(1).splitlines():
            parts = line.split()
            if len(parts) >= 4:
                try:
                    energy_cm = float(parts[1])
                    wavelength = float(parts[2])
                    oscillator = float(parts[-1])
                except ValueError:
                    continue
                result["excitations"].append({
                    "energy_ev": energy_cm * CM_TO_EV,
                    "wavelength_nm": wavelength,
                    "oscillator": oscillator,
                })
    result["geometry"] = _parse_orca_geometry(text)
    return result


def _parse_psi4_geometry(text: str) -> Optional[Molecule]:
    match = re.search(
        r"Geometry \(in Angstrom\), charge = .*?\n\s*([A-Za-z].*?)\n\s*\n",
        text,
        re.DOTALL,
    )
    if not match:
        return None
    atoms = []
    for line in match.group(1).splitlines():
        parts = line.split()
        if len(parts) >= 4:
            try:
                atoms.append((parts[0], float(parts[1]), float(parts[2]), float(parts[3])))
            except ValueError:
                continue
    if not atoms:
        return None
    mol = Molecule(atoms, name="Psi4 geometry")
    mol.infer_bonds()
    return mol


def _parse_psi4(text: str) -> Dict[str, Any]:
    result: Dict[str, Any] = {"software": "Psi4"}
    result["energy"] = _last_float(r"(?:Final Energy|Total Energy)\s*[:=]\s*(-?\d+\.\d+)", text)
    modes = [
        _new_mode(index, float(value))
        for index, value in enumerate(re.findall(r"Frequency:\s+(-?\d+\.\d+)", text))
        if abs(float(value)) > 0.5
    ]
    result["modes"] = modes
    result["frequencies"] = [m["frequency"] for m in modes if m["frequency"] > 10]
    result["excitations"] = []
    result["geometry"] = _parse_psi4_geometry(text)
    return result


def _parse_qchem_geometry(text: str) -> Optional[Molecule]:
    start = text.rfind("Standard Nuclear Orientation (Angstroms)")
    if start < 0:
        return None
    lines = text[start:].splitlines()
    dashes = [i for i, line in enumerate(lines) if line.strip().startswith("---")]
    if len(dashes) < 3:
        return None
    atoms = []
    for line in lines[dashes[1] + 1 : dashes[2]]:
        parts = line.split()
        if len(parts) >= 5:
            try:
                atoms.append((parts[1], float(parts[2]), float(parts[3]), float(parts[4])))
            except ValueError:
                continue
    if not atoms:
        return None
    mol = Molecule(atoms, name="Q-Chem geometry")
    mol.infer_bonds()
    return mol


def _parse_qchem(text: str) -> Dict[str, Any]:
    result: Dict[str, Any] = {"software": "Q-Chem"}
    result["energy"] = _last_float(r"Total energy in the final basis set\s*=\s*(-?\d+\.\d+)", text)
    modes = [
        _new_mode(index, float(value))
        for index, value in enumerate(re.findall(r"Frequency:\s+(-?\d+\.\d+)", text))
        if abs(float(value)) > 0.5
    ]
    result["modes"] = modes
    result["frequencies"] = [m["frequency"] for m in modes if m["frequency"] > 10]
    result["excitations"] = []
    for match in re.finditer(
        r"Excited state\s+\d+:\s+.*?([\d.]+)\s+eV\s+([\d.]+)\s+nm\s+f=([\d.]+)",
        text,
    ):
        result["excitations"].append({
            "energy_ev": float(match.group(1)),
            "wavelength_nm": float(match.group(2)),
            "oscillator": float(match.group(3)),
        })
    result["geometry"] = _parse_qchem_geometry(text)
    return result


def parse_output(path: os.PathLike | str) -> Dict[str, Any]:
    path = Path(path)
    text = path.read_text(encoding="utf-8", errors="replace")
    if "Gaussian, Inc." in text or "SCF Done" in text or "Standard orientation:" in text:
        parser = _parse_gaussian
    elif "FINAL SINGLE POINT ENERGY" in text or "O   R   C   A" in text or "ORBITAL ENERGIES" in text:
        parser = _parse_orca
    elif "Geometry (in Angstrom)" in text or "Psi4" in text:
        parser = _parse_psi4
    elif "Standard Nuclear Orientation" in text or "Q-Chem" in text or "Total energy in the final basis set" in text:
        parser = _parse_qchem
    else:
        parser = None
    if parser is not None:
        result = parser(text)
        result["path"] = str(path)
        if result.get("homo") is not None and result.get("lumo") is not None:
            result["gap"] = result["lumo"] - result["homo"]
        return result
    # generic fallback
    result = {"software": "Unknown", "path": str(path),
              "energy": _last_float(r"(-?\d+\.\d{6,})", text),
              "frequencies": [], "modes": [], "excitations": [], "geometry": None}
    return result


# -- analysis --------------------------------------------------------------


def cone_angle(mol: Molecule, center: int, ligands: Sequence[int]) -> float:
    if np is None or not ligands:
        return 0.0
    origin = np.asarray(mol.atoms[center][1:])
    vectors = np.asarray([np.asarray(mol.atoms[i][1:]) - origin for i in ligands])
    norms = np.linalg.norm(vectors, axis=1)
    good = norms > 1e-9
    if not good.any():
        return 0.0
    vectors = vectors[good] / norms[good, None]
    axis = vectors.sum(axis=0)
    axis /= np.linalg.norm(axis) + 1e-12
    cosines = np.clip(vectors @ axis, -1.0, 1.0)
    return 2.0 * math.degrees(math.acos(float(cosines.min())))


def sterimol(mol: Molecule, center: int, substituent: Sequence[int]) -> Dict[str, float]:
    if np is None or not substituent:
        return {}
    origin = np.asarray(mol.atoms[center][1:])
    points = np.asarray([mol.atoms[i][1:] for i in substituent])
    axis = points.mean(axis=0) - origin
    axis /= np.linalg.norm(axis) + 1e-12
    helper = np.array([0.0, 0.0, 1.0]) if abs(axis[2]) < 0.9 else np.array([0.0, 1.0, 0.0])
    u = np.cross(axis, helper); u /= np.linalg.norm(u) + 1e-12
    v = np.cross(axis, u)
    projections = (points - origin) @ axis
    radial = np.sqrt(((points - origin) @ u) ** 2 + ((points - origin) @ v) ** 2)
    radii = np.asarray([COVALENT.get(mol.atoms[i][0], 0.8) for i in substituent])
    l_value = float(projections.max() + radii[projections.argmax()]) if len(projections) else 0.0
    bins = np.linspace(0, max(l_value, 1e-6), 6)
    widths = []
    for a, b in zip(bins[:-1], bins[1:]):
        mask = (projections >= a) & (projections <= b)
        widths.append(float((radial[mask] + radii[mask]).max() * 2) if mask.any() else 0.0)
    return {"L": l_value, "B1": widths[0], "B2": widths[1], "B3": widths[2], "B4": widths[3], "B5": widths[4]}


def buried_volume(mol: Molecule, center: int, ligands: Sequence[int], radius: float = 3.5, spacing: float = 0.3) -> float:
    if np is None or not ligands:
        return 0.0
    origin = np.asarray(mol.atoms[center][1:])
    axes = [np.arange(-radius, radius + spacing / 2, spacing) for _ in range(3)]
    grid = np.stack(np.meshgrid(*axes, indexing="ij"), axis=-1).reshape(-1, 3)
    inside_sphere = np.linalg.norm(grid, axis=1) <= radius
    total = int(inside_sphere.sum())
    if total == 0:
        return 0.0
    occupied = np.zeros(total, dtype=bool)
    points = grid[inside_sphere]
    for index in ligands:
        atom = np.asarray(mol.atoms[index][1:]) - origin
        r = COVALENT.get(mol.atoms[index][0], 0.8) + 1.2
        occupied |= np.linalg.norm(points - atom, axis=1) <= r
    return 100.0 * float(occupied.sum()) / total


# -- QM input --------------------------------------------------------------


def build_qm_input(
    software: str,
    mol: Molecule,
    *,
    method: str = "B3LYP",
    basis: str = "6-31G(d)",
    job: str = "opt freq",
    charge: int = 0,
    multiplicity: int = 1,
    title: str = "SEQItachi job",
    nproc: int = 4,
    memory: str = "4GB",
    solvent: str = "",
) -> str:
    xyz = "\n".join(f"{s:2s} {x:14.8f} {y:14.8f} {z:14.8f}" for s, x, y, z in mol.atoms)
    solvent_line = f" scrf=(smd,solvent={solvent})" if solvent else ""
    if software == "Gaussian":
        return (
            f"%chk={Path(mol.name).stem}.chk\n%mem={memory}\n%nprocshared={nproc}\n"
            f"#p {method}/{basis} {job}{solvent_line}\n\n{title}\n\n"
            f"{charge} {multiplicity}\n{xyz}\n\n"
        )
    if software == "ORCA":
        return (
            f"! {method} {basis} {job} {('CPCM(' + solvent + ')') if solvent else ''}\n"
            f"%pal nprocs {nproc} end\n%maxcore {max(256, int(memory.rstrip('GB')) * 1024 // max(1, nproc))}\n"
            f"* xyz {charge} {multiplicity}\n{xyz}\n*\n"
        )
    if software == "Psi4":
        return (
            f"memory {memory}\n\nmolecule {{\n{charge} {multiplicity}\n{xyz}\n}}\n\n"
            f"set basis {basis}\nset reference {'rhf' if multiplicity == 1 else 'uhf'}\n"
            f"{'optimize' if 'opt' in job else 'energy'}('{method.lower()}')\n"
        )
    if software == "Q-Chem":
        jobtype = "opt" if "opt" in job else ("freq" if "freq" in job else "sp")
        return (
            f"$molecule\n{charge} {multiplicity}\n{xyz}\n$end\n\n$rem\n"
            f"JOBTYPE {jobtype}\nMETHOD {method}\nBASIS {basis}\n"
            f"${'solvent' if solvent else ''}\n$end\n"
        )
    if software == "xTB":
        return f"$coord\n" + "\n".join(f"{x:14.8f} {y:14.8f} {z:14.8f} {s}" for s, x, y, z in mol.atoms) + "\n$end\n"
    if software == "sqm":
        return (
            "$AM1\n &qmmm\n  qm_theory='AM1',\n  qmcharge=" + str(charge) + ",\n /\n"
            + "\n".join(f"{s:2s} {x:14.8f} {y:14.8f} {z:14.8f}" for s, x, y, z in mol.atoms)
            + "\n"
        )
    raise ValueError(f"Unsupported QM software: {software}")


# -- spectra and thermochemistry -------------------------------------------


def broaden(positions: Sequence[float], intensities: Sequence[float], x, sigma: float) -> Any:
    y = np.zeros_like(x, dtype=float)
    for position, intensity in zip(positions, intensities):
        y += intensity * np.exp(-0.5 * ((x - position) / sigma) ** 2)
    return y


def peak_profile(
    x,
    positions: Sequence[float],
    intensities: Sequence[float],
    *,
    fwhm: float = 15.0,
    peak_type: str = "pseudo-Voigt",
    voigt_mix: float = 0.5,
) -> Any:
    """Gaussian, Lorentzian, pseudo-Voigt or delta profile (FWHM in cm^-1)."""
    y = np.zeros_like(x, dtype=float)
    if not positions:
        return y
    kind = (peak_type or "pseudo-Voigt").strip().lower()
    if kind == "delta":
        for position, intensity in zip(positions, intensities):
            index = int(np.argmin(np.abs(x - position)))
            y[index] += float(intensity)
        return y
    width = max(0.01, float(fwhm))
    for position, intensity in zip(positions, intensities):
        delta = (x - position) / width
        gaussian = np.exp(-4.0 * math.log(2.0) * delta * delta)
        lorentzian = 1.0 / (1.0 + 4.0 * delta * delta)
        if kind == "gaussian":
            shape = gaussian
        elif kind == "lorentzian":
            shape = lorentzian
        else:
            shape = voigt_mix * gaussian + (1.0 - voigt_mix) * lorentzian
        y += float(intensity) * shape
    return y


def boltzmann_weights(
    energies: Sequence[Optional[float]], temperature: float = 298.15
) -> List[float]:
    """Normalized Boltzmann weights from Hartree energies; equal if missing."""
    if not energies:
        return []
    values = [float(value) for value in energies if isinstance(value, (int, float))]
    if len(values) != len(energies) or not values:
        return [1.0 / len(energies)] * len(energies)
    temperature = max(1.0, float(temperature))
    minimum = min(values)
    factors = [math.exp(-(value - minimum) / (R_HARTREE * temperature)) for value in values]
    total = sum(factors) or 1.0
    return [factor / total for factor in factors]


def scaled_frequency(
    frequency: float, scale: float = 1.0, quadratic: float = 0.0, shift: float = 0.0
) -> float:
    return frequency * float(scale) - float(quadratic) * frequency ** 2 + float(shift)


def _mode_intensities(
    data: Dict[str, Any], kind: str, allow_fallback: bool = True
) -> Tuple[List[float], List[float], bool, int]:
    modes = data.get("modes") or []
    key = {
        "ir": "ir_intensity",
        "raman": "raman_activity",
        "vcd": "vcd_rotation",
    }.get(kind, "ir_intensity")
    positions: List[float] = []
    intensities: List[float] = []
    missing = 0
    has_values = any(mode.get(key) is not None for mode in modes)
    for mode in modes:
        frequency = float(mode.get("frequency") or 0.0)
        if frequency <= 0:
            continue
        value = mode.get(key)
        if value is None:
            missing += 1
            if kind == "ir" and allow_fallback and not has_values:
                value = 1.0
            else:
                continue
        positions.append(frequency)
        intensities.append(float(value))
    if not modes:
        # Older parse results only had a frequencies list.
        for frequency in data.get("frequencies") or []:
            if float(frequency) > 0:
                positions.append(float(frequency))
                intensities.append(1.0)
        missing = len(positions)
        has_values = False
    fallback = kind == "ir" and bool(positions) and not has_values
    return positions, intensities, fallback, missing


def spectrum_extent(
    conformers: Sequence[Dict[str, Any]],
    *,
    kind: str = "ir",
    scale: float = 1.0,
    quadratic: float = 0.0,
    shift: float = 0.0,
    padding: float = 0.08,
    minimum_span: float = 200.0,
    lower_limit: float = 0.0,
    upper_limit: float = 6000.0,
) -> Tuple[float, float]:
    """Auto-detect a plotting window around the active peaks.

    Uses scaled peak positions, ignores zero-intensity IR modes, always keeps at
    least 200 cm^-1 span, adds 8% padding and rounds outward to 50 cm^-1.
    """
    positions: List[float] = []
    for data in conformers:
        values, intensities, _fallback, _missing = _mode_intensities(data, kind)
        for position, intensity in zip(values, intensities):
            if kind == "ir" and intensity <= 0:
                continue
            positions.append(scaled_frequency(position, scale, quadratic, shift))
    if not positions:
        return (400.0, 4000.0)
    low, high = min(positions), max(positions)
    span = max(high - low, float(minimum_span))
    pad = max(50.0, span * float(padding))
    low = max(float(lower_limit), low - pad)
    high = min(float(upper_limit), high + pad)
    low = math.floor(low / 50.0) * 50.0
    high = math.ceil(high / 50.0) * 50.0
    if high <= low:
        high = low + 50.0
    return (float(low), float(high))


def combined_spectrum(
    conformers: Sequence[Dict[str, Any]],
    weights: Sequence[float],
    *,
    kind: str = "ir",
    fwhm: float = 15.0,
    peak_type: str = "pseudo-Voigt",
    voigt_mix: float = 0.5,
    scale: float = 1.0,
    quadratic: float = 0.0,
    shift: float = 0.0,
    x_min: float = 400.0,
    x_max: float = 4000.0,
    points: int = 1800,
) -> Tuple[Any, Any, List[Dict[str, Any]]]:
    x = np.linspace(float(x_min), float(x_max), int(points))
    total = np.zeros_like(x, dtype=float)
    components: List[Dict[str, Any]] = []
    for data, weight in zip(conformers, weights):
        positions, intensities, fallback, missing = _mode_intensities(data, kind)
        scaled = [
            scaled_frequency(value, scale, quadratic, shift)
            for value in positions
        ]
        y = peak_profile(
            x,
            scaled,
            intensities,
            fwhm=fwhm,
            peak_type=peak_type,
            voigt_mix=voigt_mix,
        ) * float(weight)
        total += y
        label = Path(str(data.get("path") or "output")).name or "output"
        components.append(
            {
                "label": label,
                "path": data.get("path", ""),
                "x": x,
                "y": y,
                "weight": float(weight),
                "fallback": fallback,
                "missing_intensities": missing,
                "peaks": len(positions),
            }
        )
    return x, total, components


def transmittance(absorbance) -> Any:
    values = np.asarray(absorbance, dtype=float)
    peak = float(np.max(np.abs(values))) if values.size else 0.0
    if peak <= 0:
        return np.full_like(values, 100.0)
    return 100.0 * np.power(10.0, -2.0 * values / peak)


def spectrum_peaks(
    conformers: Sequence[Dict[str, Any]],
    weights: Sequence[float],
    *,
    kind: str = "ir",
    scale: float = 1.0,
    quadratic: float = 0.0,
    shift: float = 0.0,
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for data, weight in zip(conformers, weights):
        path = str(data.get("path") or "")
        for mode in data.get("modes") or []:
            frequency = float(mode.get("frequency") or 0.0)
            if abs(frequency) <= 0.5:
                continue
            rows.append(
                {
                    "conformer": Path(path).name if path else "",
                    "path": path,
                    "weight": float(weight),
                    "mode": mode.get("mode"),
                    "frequency": frequency,
                    "scaled": scaled_frequency(frequency, scale, quadratic, shift),
                    "ir_intensity": mode.get("ir_intensity"),
                    "raman_activity": mode.get("raman_activity"),
                    "vcd_rotation": mode.get("vcd_rotation"),
                    "imaginary": bool(mode.get("imaginary")),
                    "selected": mode.get(
                        {"ir": "ir_intensity", "raman": "raman_activity", "vcd": "vcd_rotation"}.get(kind, "ir_intensity")
                    ),
                }
            )
    return rows


def ir_spectrum(
    frequencies: Sequence[float],
    sigma: float = 20.0,
    intensities: Optional[Sequence[float]] = None,
    *,
    fwhm: Optional[float] = None,
    peak_type: str = "pseudo-Voigt",
    voigt_mix: float = 0.5,
):
    x = np.linspace(400.0, 4000.0, 1800)
    positions = [float(f) for f in frequencies if float(f) > 100]
    if intensities is None:
        values = [1.0] * len(positions)
    else:
        values = [float(v) for v in intensities][: len(positions)]
    width = fwhm if fwhm is not None else sigma * 2.354820045
    y = peak_profile(
        x,
        positions,
        values,
        fwhm=width,
        peak_type=peak_type,
        voigt_mix=voigt_mix,
    )
    return x, y


def uv_spectrum(excitations: Sequence[Dict[str, float]], sigma: float = 0.15):
    x = np.linspace(100.0, 800.0, 1400)
    positions = [e["wavelength_nm"] for e in excitations if e.get("wavelength_nm")]
    intensities = [e.get("oscillator", 0.0) for e in excitations if e.get("wavelength_nm")]
    return x, broaden(positions, intensities, x, sigma)


def thermo(frequencies: Sequence[float], mol: Molecule, temperature: float = 298.15) -> Dict[str, float]:
    freqs = np.asarray([f for f in frequencies if f > 10.0], dtype=float)
    if freqs.size == 0:
        return {}
    # harmonic oscillator in cm^-1
    x = (H_PLANCK * C_LIGHT * freqs * 100.0) / (KB * temperature)
    zpe = float(np.sum(0.5 * H_PLANCK * C_LIGHT * freqs * 100.0) * 6.02214076e23 / 1000.0)
    vib_u = float(R_GAS * temperature * np.sum(x / np.expm1(x)) / 1000.0)
    vib_s = float(R_GAS * np.sum(x / np.expm1(x) - np.log1p(-np.exp(-x))))
    # translation
    mass = mol.molecular_weight() * AMU
    volume = KB * temperature / 101325.0
    q_trans = ((2 * math.pi * mass * KB * temperature) / H_PLANCK**2) ** 1.5 * volume
    s_trans = R_GAS * (math.log(q_trans) + 2.5)
    # rotation (convert Angstrom to metres)
    coords = mol.coords() * 1e-10
    com = np.asarray(mol.center_of_mass()) * 1e-10
    masses = np.asarray([WEIGHT.get(a[0], 1.0) for a in mol.atoms]) * AMU
    rel = coords - com
    inertia = np.zeros((3, 3))
    for m, r in zip(masses, rel):
        inertia += m * (np.dot(r, r) * np.eye(3) - np.outer(r, r))
    eig = np.linalg.eigvalsh(inertia)
    eig = eig[eig > 1e-60]
    if eig.size == 3:
        q_rot = math.sqrt(math.pi) / 1.0 * (8 * math.pi**2 * KB * temperature / H_PLANCK**2) ** 1.5 * math.sqrt(float(np.prod(eig)))
        s_rot = R_GAS * (math.log(q_rot) + 1.5)
    else:
        s_rot = 0.0
    s_elec = R_GAS * math.log(max(1, mol.multiplicity))
    s_total = s_trans + s_rot + vib_s + s_elec
    thermal_u = 1.5 * R_GAS * temperature / 1000.0 + 1.5 * R_GAS * temperature / 1000.0 + vib_u
    gibbs = zpe + thermal_u - temperature * s_total / 1000.0
    return {
        "temperature_k": temperature,
        "zpe_kj": zpe,
        "thermal_correction_kj": thermal_u,
        "entropy_j_k": s_total,
        "gibbs_correction_kj": gibbs,
        "zpe_hartree": zpe / HARTREE_TO_KJ,
        "gibbs_hartree": gibbs / HARTREE_TO_KJ,
    }


# -- cube files ------------------------------------------------------------


def parse_cube(path: os.PathLike | str) -> Dict[str, Any]:
    path = Path(path)
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    if len(lines) < 8:
        raise ValueError("Cube file too short")
    parts = lines[2].split()
    natoms = int(parts[0])
    origin = np.asarray([float(x) for x in parts[1:4]])
    dims, axes = [], []
    for i in range(3):
        parts = lines[3 + i].split()
        dims.append(abs(int(parts[0])))
        axes.append([float(x) for x in parts[1:4]])
    atoms = []
    for line in lines[6 : 6 + natoms]:
        parts = line.split()
        if len(parts) >= 5:
            atoms.append((SYMBOL_BY_Z.get(int(float(parts[0])), "X"), *[float(x) for x in parts[2:5]]))
    data_lines = lines[6 + natoms :]
    values = np.fromstring(" ".join(data_lines), sep=" ")
    expected = dims[0] * dims[1] * dims[2]
    values = values[:expected]
    if values.size != expected:
        raise ValueError(f"Cube data size {values.size} != {expected}")
    data = values.reshape((dims[0], dims[1], dims[2]), order="F")
    return {
        "path": str(path),
        "origin": origin,
        "axes": np.asarray(axes),
        "dims": dims,
        "atoms": atoms,
        "data": data,
    }


def cube_slice(cube: Dict[str, Any], axis: str = "z", index: Optional[int] = None) -> Dict[str, Any]:
    data = cube["data"]
    dims = cube["dims"]
    if axis == "x":
        index = dims[0] // 2 if index is None else index
        values = data[index, :, :].T
        u = np.arange(dims[1]); v = np.arange(dims[2])
    elif axis == "y":
        index = dims[1] // 2 if index is None else index
        values = data[:, index, :].T
        u = np.arange(dims[0]); v = np.arange(dims[2])
    else:
        index = dims[2] // 2 if index is None else index
        values = data[:, :, index].T
        u = np.arange(dims[0]); v = np.arange(dims[1])
    return {"axis": axis, "index": int(index), "u": u.tolist(), "v": v.tolist(), "values": values.tolist()}
