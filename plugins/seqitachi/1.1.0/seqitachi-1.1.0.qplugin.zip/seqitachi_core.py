"""SEQItachi core: structures, parsers, analysis, QM input, spectra and cubes.

Independent QAH implementation inspired by SEQCROW's workflow. No SEQCROW code
is copied. SEQCROW itself is GPL-3.0; this plugin is GPL-3.0 or later.
"""

from __future__ import annotations

import hashlib
import math
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None  # type: ignore

# symbol, atomic number, standard atomic weight, covalent radius (angstrom)
_ELEMENT_ROWS = [
    ("H", 1, 1.008, 0.31), ("He", 2, 4.0026, 0.28),
    ("Li", 3, 6.94, 1.28), ("Be", 4, 9.0122, 0.96), ("B", 5, 10.81, 0.84),
    ("C", 6, 12.011, 0.76), ("N", 7, 14.007, 0.71), ("O", 8, 15.999, 0.66),
    ("F", 9, 18.998, 0.57), ("Ne", 10, 20.180, 0.58),
    ("Na", 11, 22.990, 1.66), ("Mg", 12, 24.305, 1.41), ("Al", 13, 26.982, 1.21),
    ("Si", 14, 28.085, 1.11), ("P", 15, 30.974, 1.07), ("S", 16, 32.06, 1.05),
    ("Cl", 17, 35.45, 1.02), ("Ar", 18, 39.948, 1.06),
    ("K", 19, 39.098, 2.03), ("Ca", 20, 40.078, 1.76), ("Sc", 21, 44.956, 1.70),
    ("Ti", 22, 47.867, 1.60), ("V", 23, 50.942, 1.53), ("Cr", 24, 51.996, 1.39),
    ("Mn", 25, 54.938, 1.39), ("Fe", 26, 55.845, 1.32), ("Co", 27, 58.933, 1.26),
    ("Ni", 28, 58.693, 1.24), ("Cu", 29, 63.546, 1.32), ("Zn", 30, 65.38, 1.22),
    ("Ga", 31, 69.723, 1.22), ("Ge", 32, 72.630, 1.20), ("As", 33, 74.922, 1.19),
    ("Se", 34, 78.971, 1.20), ("Br", 35, 79.904, 1.20), ("Kr", 36, 83.798, 1.16),
    ("Rb", 37, 85.468, 2.20), ("Sr", 38, 87.62, 1.95), ("Y", 39, 88.906, 1.90),
    ("Zr", 40, 91.224, 1.75), ("Nb", 41, 92.906, 1.64), ("Mo", 42, 95.95, 1.54),
    ("Tc", 43, 98.0, 1.47), ("Ru", 44, 101.07, 1.46), ("Rh", 45, 102.91, 1.42),
    ("Pd", 46, 106.42, 1.39), ("Ag", 47, 107.87, 1.45), ("Cd", 48, 112.41, 1.44),
    ("In", 49, 114.82, 1.42), ("Sn", 50, 118.71, 1.39), ("Sb", 51, 121.76, 1.39),
    ("Te", 52, 127.60, 1.38), ("I", 53, 126.90, 1.39), ("Xe", 54, 131.29, 1.40),
    ("Cs", 55, 132.91, 2.44), ("Ba", 56, 137.33, 2.15), ("La", 57, 138.91, 2.07),
    ("Ce", 58, 140.12, 2.04), ("Pr", 59, 140.91, 2.03), ("Nd", 60, 144.24, 2.01),
    ("Pm", 61, 145.0, 1.99), ("Sm", 62, 150.36, 1.98), ("Eu", 63, 151.96, 1.98),
    ("Gd", 64, 157.25, 1.96), ("Tb", 65, 158.93, 1.95), ("Dy", 66, 162.50, 1.92),
    ("Ho", 67, 164.93, 1.92), ("Er", 68, 167.26, 1.89), ("Tm", 69, 168.93, 1.90),
    ("Yb", 70, 173.05, 1.87), ("Lu", 71, 174.97, 1.87), ("Hf", 72, 178.49, 1.75),
    ("Ta", 73, 180.95, 1.70), ("W", 74, 183.84, 1.62), ("Re", 75, 186.21, 1.51),
    ("Os", 76, 190.23, 1.44), ("Ir", 77, 192.22, 1.41), ("Pt", 78, 195.08, 1.36),
    ("Au", 79, 196.97, 1.36), ("Hg", 80, 200.59, 1.32), ("Tl", 81, 204.38, 1.45),
    ("Pb", 82, 207.2, 1.46), ("Bi", 83, 208.98, 1.48), ("Po", 84, 209.0, 1.40),
    ("At", 85, 210.0, 1.50), ("Rn", 86, 222.0, 1.50),
]
SYMBOLS = [row[0] for row in _ELEMENT_ROWS]
Z_BY_SYMBOL = {row[0]: row[1] for row in _ELEMENT_ROWS}
SYMBOL_BY_Z = {row[1]: row[0] for row in _ELEMENT_ROWS}
WEIGHT = {row[0]: row[2] for row in _ELEMENT_ROWS}
COVALENT = {row[0]: row[3] for row in _ELEMENT_ROWS}

HARTREE_TO_KJ = 2625.4996394799
HARTREE_TO_EV = 27.211386245988
CM_TO_EV = 0.0001239841984332003
R_GAS = 8.31446261815324
H_PLANCK = 6.62607015e-34
C_LIGHT = 2.99792458e8
KB = 1.380649e-23
AMU = 1.66053906660e-27


@dataclass
class Molecule:
    atoms: List[Tuple[str, float, float, float]] = field(default_factory=list)
    bonds: List[Tuple[int, int, float]] = field(default_factory=list)
    name: str = "molecule"
    charge: int = 0
    multiplicity: int = 1
    comment: str = ""

    def copy(self) -> "Molecule":
        return Molecule(
            [tuple(atom) for atom in self.atoms],
            [tuple(bond) for bond in self.bonds],
            self.name,
            self.charge,
            self.multiplicity,
            self.comment,
        )

    def __len__(self) -> int:
        return len(self.atoms)

    def coords(self):
        if np is None:
            return []
        return np.asarray([[a[1], a[2], a[3]] for a in self.atoms], dtype=float)

    def symbols(self) -> List[str]:
        return [atom[0] for atom in self.atoms]

    def formula(self) -> str:
        counts = {}
        for symbol, *_ in self.atoms:
            counts[symbol] = counts.get(symbol, 0) + 1
        order = sorted(counts, key=lambda s: (s != "C", s != "H", s))
        return "".join(symbol + (str(counts[symbol]) if counts[symbol] > 1 else "") for symbol in order)

    def molecular_weight(self) -> float:
        return sum(WEIGHT.get(symbol, 0.0) for symbol, *_ in self.atoms)

    def infer_bonds(self, tolerance: float = 1.18) -> None:
        self.bonds = []
        if np is None:
            return
        coords = self.coords()
        for i in range(len(coords)):
            for j in range(i + 1, len(coords)):
                d = float(np.linalg.norm(coords[i] - coords[j]))
                cutoff = (COVALENT.get(self.atoms[i][0], 0.8) + COVALENT.get(self.atoms[j][0], 0.8)) * tolerance
                if 0.25 < d <= cutoff:
                    self.bonds.append((i, j, 1.0))
        # remove H-H contacts except H2
        if len(self.atoms) > 2:
            self.bonds = [b for b in self.bonds if not (self.atoms[b[0]][0] == "H" and self.atoms[b[1]][0] == "H")]

    def to_xyz(self) -> str:
        lines = [str(len(self.atoms)), self.name]
        for symbol, x, y, z in self.atoms:
            lines.append(f"{symbol:2s} {x:14.8f} {y:14.8f} {z:14.8f}")
        return "\n".join(lines) + "\n"

    @classmethod
    def from_xyz_text(cls, text: str) -> "Molecule":
        lines = text.splitlines()
        if len(lines) < 3:
            raise ValueError("XYZ needs at least 3 lines")
        count = int(lines[0].strip())
        atoms = []
        for line in lines[2 : 2 + count]:
            parts = line.split()
            if len(parts) < 4:
                raise ValueError(f"Bad XYZ atom line: {line!r}")
            atoms.append((parts[0], float(parts[1]), float(parts[2]), float(parts[3])))
        mol = cls(atoms, name=lines[1].strip() or "molecule")
        mol.infer_bonds()
        return mol

    @classmethod
    def from_xyz_file(cls, path: os.PathLike | str) -> "Molecule":
        return cls.from_xyz_text(Path(path).read_text(encoding="utf-8", errors="replace"))

    def center_of_mass(self):
        if np is None or not self.atoms:
            return (0.0, 0.0, 0.0)
        masses = np.asarray([WEIGHT.get(a[0], 1.0) for a in self.atoms])
        coords = self.coords()
        return tuple((coords * masses[:, None]).sum(axis=0) / masses.sum())

    def radius_of_gyration(self) -> float:
        if np is None or not self.atoms:
            return 0.0
        masses = np.asarray([WEIGHT.get(a[0], 1.0) for a in self.atoms])
        coords = self.coords()
        com = np.asarray(self.center_of_mass())
        return float(math.sqrt(((masses * ((coords - com) ** 2).sum(axis=1)).sum()) / masses.sum()))

    def distance(self, i: int, j: int) -> float:
        a, b = np.asarray(self.atoms[i][1:]), np.asarray(self.atoms[j][1:])
        return float(np.linalg.norm(a - b))

    def angle(self, i: int, j: int, k: int) -> float:
        a = np.asarray(self.atoms[i][1:]) - np.asarray(self.atoms[j][1:])
        b = np.asarray(self.atoms[k][1:]) - np.asarray(self.atoms[j][1:])
        cosang = float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-12))
        return math.degrees(math.acos(max(-1.0, min(1.0, cosang))))

    def dihedral(self, i: int, j: int, k: int, l: int) -> float:
        p0, p1, p2, p3 = (np.asarray(self.atoms[x][1:]) for x in (i, j, k, l))
        b0, b1, b2 = p0 - p1, p2 - p1, p3 - p2
        b1n = b1 / (np.linalg.norm(b1) + 1e-12)
        v = b0 - np.dot(b0, b1n) * b1n
        w = b2 - np.dot(b2, b1n) * b1n
        return math.degrees(math.atan2(float(np.dot(np.cross(b1n, v), w)), float(np.dot(v, w))))

    def add_atom(self, symbol: str, x: float, y: float, z: float) -> int:
        self.atoms.append((symbol, float(x), float(y), float(z)))
        return len(self.atoms) - 1

    def remove_atom(self, index: int) -> None:
        if not (0 <= index < len(self.atoms)):
            return
        self.atoms.pop(index)
        bonds = []
        for i, j, order in self.bonds:
            if i == index or j == index:
                continue
            bonds.append((i - (i > index), j - (j > index), order))
        self.bonds = bonds

    def set_element(self, index: int, symbol: str) -> None:
        if 0 <= index < len(self.atoms):
            self.atoms[index] = (symbol, *self.atoms[index][1:])

    def add_bond(self, i: int, j: int, order: float = 1.0) -> None:
        if i == j or not (0 <= i < len(self.atoms) and 0 <= j < len(self.atoms)):
            return
        self.remove_bond(i, j)
        self.bonds.append((min(i, j), max(i, j), float(order)))

    def remove_bond(self, i: int, j: int) -> None:
        self.bonds = [b for b in self.bonds if {b[0], b[1]} != {i, j}]

    def set_bond_length(self, i: int, j: int, length: float) -> None:
        a, b = np.asarray(self.atoms[i][1:]), np.asarray(self.atoms[j][1:])
        direction = b - a
        norm = np.linalg.norm(direction)
        if norm < 1e-9:
            return
        new_b = a + direction / norm * float(length)
        self.atoms[j] = (self.atoms[j][0], *map(float, new_b))

    def translate(self, dx: float, dy: float, dz: float) -> None:
        self.atoms = [(s, x + dx, y + dy, z + dz) for s, x, y, z in self.atoms]

    def rotate(self, axis: Sequence[float], degrees: float, center: Optional[Sequence[float]] = None) -> None:
        axis = np.asarray(axis, dtype=float)
        norm = np.linalg.norm(axis)
        if norm < 1e-9:
            return
        axis = axis / norm
        theta = math.radians(degrees)
        K = np.array([[0, -axis[2], axis[1]], [axis[2], 0, -axis[0]], [-axis[1], axis[0], 0]])
        R = np.eye(3) + math.sin(theta) * K + (1 - math.cos(theta)) * (K @ K)
        origin = np.asarray(center if center is not None else self.center_of_mass(), dtype=float)
        self.atoms = [
            (s, *(R @ (np.asarray((x, y, z)) - origin) + origin)) for s, x, y, z in self.atoms
        ]

    def align_to(self, other: "Molecule") -> None:
        if len(self.atoms) != len(other.atoms) or np is None:
            return
        P = self.coords() - self.coords().mean(axis=0)
        Q = other.coords() - other.coords().mean(axis=0)
        H = P.T @ Q
        U, _, Vt = np.linalg.svd(H)
        d = np.sign(np.linalg.det(Vt.T @ U.T))
        R = Vt.T @ np.diag([1, 1, d]) @ U.T
        transformed = (R @ self.coords().T).T
        transformed += other.coords().mean(axis=0) - transformed.mean(axis=0)
        self.atoms = [(a[0], *map(float, transformed[i])) for i, a in enumerate(self.atoms)]


# -- parsing ---------------------------------------------------------------


def _last_float(pattern: str, text: str) -> Optional[float]:
    matches = re.findall(pattern, text, re.IGNORECASE)
    return float(matches[-1]) if matches else None


def _parse_gaussian_geometry(text: str) -> Optional[Molecule]:
    for marker in ("Standard orientation:", "Input orientation:"):
        start = text.rfind(marker)
        if start < 0:
            continue
        lines = text[start:].splitlines()
        dashes = [i for i, line in enumerate(lines) if line.strip().startswith("---")]
        if len(dashes) < 3:
            continue
        atoms = []
        for line in lines[dashes[1] + 1 : dashes[2]]:
            parts = line.split()
            if len(parts) < 6:
                continue
            try:
                atomic_number = int(parts[1])
                atoms.append((SYMBOL_BY_Z.get(atomic_number, "X"), float(parts[3]), float(parts[4]), float(parts[5])))
            except ValueError:
                continue
        if atoms:
            mol = Molecule(atoms, name="Gaussian geometry")
            mol.infer_bonds()
            return mol
    return None


def _parse_gaussian(text: str) -> Dict[str, Any]:
    result: Dict[str, Any] = {"software": "Gaussian"}
    result["energy"] = _last_float(r"SCF Done:\s+E\([^)]*\)\s+=\s+(-?\d+\.\d+)", text)
    occ = re.findall(r"Alpha\s+occ\.\s+eigenvalues\s+--\s+([\d\s.-]+)", text)
    virt = re.findall(r"Alpha\s+virt\.\s+eigenvalues\s+--\s+([\d\s.-]+)", text)
    if occ and virt:
        occ_values = [float(x) for x in occ[-1].split()]
        virt_values = [float(x) for x in virt[-1].split()]
        if occ_values and virt_values:
            result["homo"] = occ_values[-1]
            result["lumo"] = virt_values[0]
    freqs = []
    for block in re.findall(r"Frequencies\s+---\s+([\d\s.-]+)", text):
        freqs.extend(float(x) for x in block.split())
    result["frequencies"] = [f for f in freqs if f > 10.0]
    result["excitations"] = []
    for match in re.finditer(
        r"Excited State\s+\d+:\s+.*?([\d.]+)\s+eV\s+([\d.]+)\s+nm\s+f=([\d.]+)",
        text,
    ):
        result["excitations"].append({
            "energy_ev": float(match.group(1)),
            "wavelength_nm": float(match.group(2)),
            "oscillator": float(match.group(3)),
        })
    result["geometry"] = _parse_gaussian_geometry(text)
    return result


def _parse_orca_geometry(text: str) -> Optional[Molecule]:
    match = re.search(
        r"CARTESIAN COORDINATES \(ANGSTROEM\)\s*-+\s*(.*?)\n\s*\n",
        text,
        re.DOTALL,
    )
    if not match:
        return None
    atoms = []
    for line in match.group(1).splitlines():
        parts = line.split()
        if len(parts) >= 4:
            try:
                atoms.append((parts[0], float(parts[1]), float(parts[2]), float(parts[3])))
            except ValueError:
                continue
    if not atoms:
        return None
    mol = Molecule(atoms, name="ORCA geometry")
    mol.infer_bonds()
    return mol


def _parse_orca(text: str) -> Dict[str, Any]:
    result: Dict[str, Any] = {"software": "ORCA"}
    result["energy"] = _last_float(r"FINAL SINGLE POINT ENERGY\s+(-?\d+\.\d+)", text)
    occ, virt = [], []
    block = re.search(r"ORBITAL ENERGIES\s*-+\s*(.*?)\n\s*\n", text, re.DOTALL)
    if block:
        for line in block.group(1).splitlines():
            parts = line.split()
            if len(parts) < 4:
                continue
            try:
                occupancy = float(parts[1])
                energy = float(parts[2])
            except ValueError:
                continue
            if occupancy > 0:
                occ.append(energy)
            else:
                virt.append(energy)
    if occ and virt:
        result["homo"] = max(occ)
        result["lumo"] = min(virt)
    freqs = []
    block = re.search(r"VIBRATIONAL FREQUENCIES\s*-+\s*(.*?)\n\s*\n", text, re.DOTALL)
    if block:
        for line in block.group(1).splitlines():
            match = re.match(r"\s*\d+:\s+(-?\d+\.\d+)\s+cm", line)
            if match:
                value = float(match.group(1))
                if value > 10:
                    freqs.append(value)
    result["frequencies"] = freqs
    result["excitations"] = []
    block = re.search(
        r"ABSORPTION SPECTRUM VIA TRANSITION ELECTRIC DIPOLE MOMENTS\s*-+\s*(.*?)\n\s*\n",
        text,
        re.DOTALL,
    )
    if block:
        for line in block.group(1).splitlines():
            parts = line.split()
            if len(parts) >= 4:
                try:
                    energy_cm = float(parts[1])
                    wavelength = float(parts[2])
                    oscillator = float(parts[-1])
                except ValueError:
                    continue
                result["excitations"].append({
                    "energy_ev": energy_cm * CM_TO_EV,
                    "wavelength_nm": wavelength,
                    "oscillator": oscillator,
                })
    result["geometry"] = _parse_orca_geometry(text)
    return result


def _parse_psi4_geometry(text: str) -> Optional[Molecule]:
    match = re.search(
        r"Geometry \(in Angstrom\), charge = .*?\n\s*([A-Za-z].*?)\n\s*\n",
        text,
        re.DOTALL,
    )
    if not match:
        return None
    atoms = []
    for line in match.group(1).splitlines():
        parts = line.split()
        if len(parts) >= 4:
            try:
                atoms.append((parts[0], float(parts[1]), float(parts[2]), float(parts[3])))
            except ValueError:
                continue
    if not atoms:
        return None
    mol = Molecule(atoms, name="Psi4 geometry")
    mol.infer_bonds()
    return mol


def _parse_psi4(text: str) -> Dict[str, Any]:
    result: Dict[str, Any] = {"software": "Psi4"}
    result["energy"] = _last_float(r"(?:Final Energy|Total Energy)\s*[:=]\s*(-?\d+\.\d+)", text)
    result["frequencies"] = [float(x) for x in re.findall(r"Frequency:\s+(-?\d+\.\d+)", text) if float(x) > 10]
    result["excitations"] = []
    result["geometry"] = _parse_psi4_geometry(text)
    return result


def _parse_qchem_geometry(text: str) -> Optional[Molecule]:
    start = text.rfind("Standard Nuclear Orientation (Angstroms)")
    if start < 0:
        return None
    lines = text[start:].splitlines()
    dashes = [i for i, line in enumerate(lines) if line.strip().startswith("---")]
    if len(dashes) < 3:
        return None
    atoms = []
    for line in lines[dashes[1] + 1 : dashes[2]]:
        parts = line.split()
        if len(parts) >= 5:
            try:
                atoms.append((parts[1], float(parts[2]), float(parts[3]), float(parts[4])))
            except ValueError:
                continue
    if not atoms:
        return None
    mol = Molecule(atoms, name="Q-Chem geometry")
    mol.infer_bonds()
    return mol


def _parse_qchem(text: str) -> Dict[str, Any]:
    result: Dict[str, Any] = {"software": "Q-Chem"}
    result["energy"] = _last_float(r"Total energy in the final basis set\s*=\s*(-?\d+\.\d+)", text)
    result["frequencies"] = [float(x) for x in re.findall(r"Frequency:\s+(-?\d+\.\d+)", text) if float(x) > 10]
    result["excitations"] = []
    for match in re.finditer(
        r"Excited state\s+\d+:\s+.*?([\d.]+)\s+eV\s+([\d.]+)\s+nm\s+f=([\d.]+)",
        text,
    ):
        result["excitations"].append({
            "energy_ev": float(match.group(1)),
            "wavelength_nm": float(match.group(2)),
            "oscillator": float(match.group(3)),
        })
    result["geometry"] = _parse_qchem_geometry(text)
    return result


def parse_output(path: os.PathLike | str) -> Dict[str, Any]:
    path = Path(path)
    text = path.read_text(encoding="utf-8", errors="replace")
    if "Gaussian, Inc." in text or "SCF Done" in text or "Standard orientation:" in text:
        parser = _parse_gaussian
    elif "FINAL SINGLE POINT ENERGY" in text or "O   R   C   A" in text or "ORBITAL ENERGIES" in text:
        parser = _parse_orca
    elif "Geometry (in Angstrom)" in text or "Psi4" in text:
        parser = _parse_psi4
    elif "Standard Nuclear Orientation" in text or "Q-Chem" in text or "Total energy in the final basis set" in text:
        parser = _parse_qchem
    else:
        parser = None
    if parser is not None:
        result = parser(text)
        result["path"] = str(path)
        if result.get("homo") is not None and result.get("lumo") is not None:
            result["gap"] = result["lumo"] - result["homo"]
        return result
    # generic fallback
    result = {"software": "Unknown", "path": str(path),
              "energy": _last_float(r"(-?\d+\.\d{6,})", text),
              "frequencies": [], "excitations": [], "geometry": None}
    return result


# -- analysis --------------------------------------------------------------


def cone_angle(mol: Molecule, center: int, ligands: Sequence[int]) -> float:
    if np is None or not ligands:
        return 0.0
    origin = np.asarray(mol.atoms[center][1:])
    vectors = np.asarray([np.asarray(mol.atoms[i][1:]) - origin for i in ligands])
    norms = np.linalg.norm(vectors, axis=1)
    good = norms > 1e-9
    if not good.any():
        return 0.0
    vectors = vectors[good] / norms[good, None]
    axis = vectors.sum(axis=0)
    axis /= np.linalg.norm(axis) + 1e-12
    cosines = np.clip(vectors @ axis, -1.0, 1.0)
    return 2.0 * math.degrees(math.acos(float(cosines.min())))


def sterimol(mol: Molecule, center: int, substituent: Sequence[int]) -> Dict[str, float]:
    if np is None or not substituent:
        return {}
    origin = np.asarray(mol.atoms[center][1:])
    points = np.asarray([mol.atoms[i][1:] for i in substituent])
    axis = points.mean(axis=0) - origin
    axis /= np.linalg.norm(axis) + 1e-12
    helper = np.array([0.0, 0.0, 1.0]) if abs(axis[2]) < 0.9 else np.array([0.0, 1.0, 0.0])
    u = np.cross(axis, helper); u /= np.linalg.norm(u) + 1e-12
    v = np.cross(axis, u)
    projections = (points - origin) @ axis
    radial = np.sqrt(((points - origin) @ u) ** 2 + ((points - origin) @ v) ** 2)
    radii = np.asarray([COVALENT.get(mol.atoms[i][0], 0.8) for i in substituent])
    l_value = float(projections.max() + radii[projections.argmax()]) if len(projections) else 0.0
    bins = np.linspace(0, max(l_value, 1e-6), 6)
    widths = []
    for a, b in zip(bins[:-1], bins[1:]):
        mask = (projections >= a) & (projections <= b)
        widths.append(float((radial[mask] + radii[mask]).max() * 2) if mask.any() else 0.0)
    return {"L": l_value, "B1": widths[0], "B2": widths[1], "B3": widths[2], "B4": widths[3], "B5": widths[4]}


def buried_volume(mol: Molecule, center: int, ligands: Sequence[int], radius: float = 3.5, spacing: float = 0.3) -> float:
    if np is None or not ligands:
        return 0.0
    origin = np.asarray(mol.atoms[center][1:])
    axes = [np.arange(-radius, radius + spacing / 2, spacing) for _ in range(3)]
    grid = np.stack(np.meshgrid(*axes, indexing="ij"), axis=-1).reshape(-1, 3)
    inside_sphere = np.linalg.norm(grid, axis=1) <= radius
    total = int(inside_sphere.sum())
    if total == 0:
        return 0.0
    occupied = np.zeros(total, dtype=bool)
    points = grid[inside_sphere]
    for index in ligands:
        atom = np.asarray(mol.atoms[index][1:]) - origin
        r = COVALENT.get(mol.atoms[index][0], 0.8) + 1.2
        occupied |= np.linalg.norm(points - atom, axis=1) <= r
    return 100.0 * float(occupied.sum()) / total


# -- QM input --------------------------------------------------------------


def build_qm_input(
    software: str,
    mol: Molecule,
    *,
    method: str = "B3LYP",
    basis: str = "6-31G(d)",
    job: str = "opt freq",
    charge: int = 0,
    multiplicity: int = 1,
    title: str = "SEQItachi job",
    nproc: int = 4,
    memory: str = "4GB",
    solvent: str = "",
) -> str:
    xyz = "\n".join(f"{s:2s} {x:14.8f} {y:14.8f} {z:14.8f}" for s, x, y, z in mol.atoms)
    solvent_line = f" scrf=(smd,solvent={solvent})" if solvent else ""
    if software == "Gaussian":
        return (
            f"%chk={Path(mol.name).stem}.chk\n%mem={memory}\n%nprocshared={nproc}\n"
            f"#p {method}/{basis} {job}{solvent_line}\n\n{title}\n\n"
            f"{charge} {multiplicity}\n{xyz}\n\n"
        )
    if software == "ORCA":
        return (
            f"! {method} {basis} {job} {('CPCM(' + solvent + ')') if solvent else ''}\n"
            f"%pal nprocs {nproc} end\n%maxcore {max(256, int(memory.rstrip('GB')) * 1024 // max(1, nproc))}\n"
            f"* xyz {charge} {multiplicity}\n{xyz}\n*\n"
        )
    if software == "Psi4":
        return (
            f"memory {memory}\n\nmolecule {{\n{charge} {multiplicity}\n{xyz}\n}}\n\n"
            f"set basis {basis}\nset reference {'rhf' if multiplicity == 1 else 'uhf'}\n"
            f"{'optimize' if 'opt' in job else 'energy'}('{method.lower()}')\n"
        )
    if software == "Q-Chem":
        jobtype = "opt" if "opt" in job else ("freq" if "freq" in job else "sp")
        return (
            f"$molecule\n{charge} {multiplicity}\n{xyz}\n$end\n\n$rem\n"
            f"JOBTYPE {jobtype}\nMETHOD {method}\nBASIS {basis}\n"
            f"${'solvent' if solvent else ''}\n$end\n"
        )
    if software == "xTB":
        return f"$coord\n" + "\n".join(f"{x:14.8f} {y:14.8f} {z:14.8f} {s}" for s, x, y, z in mol.atoms) + "\n$end\n"
    if software == "sqm":
        return (
            "$AM1\n &qmmm\n  qm_theory='AM1',\n  qmcharge=" + str(charge) + ",\n /\n"
            + "\n".join(f"{s:2s} {x:14.8f} {y:14.8f} {z:14.8f}" for s, x, y, z in mol.atoms)
            + "\n"
        )
    raise ValueError(f"Unsupported QM software: {software}")


# -- spectra and thermochemistry -------------------------------------------


def broaden(positions: Sequence[float], intensities: Sequence[float], x, sigma: float) -> Any:
    y = np.zeros_like(x, dtype=float)
    for position, intensity in zip(positions, intensities):
        y += intensity * np.exp(-0.5 * ((x - position) / sigma) ** 2)
    return y


def ir_spectrum(frequencies: Sequence[float], sigma: float = 20.0):
    x = np.linspace(400.0, 4000.0, 1800)
    y = broaden([f for f in frequencies if f > 100], [1.0] * len([f for f in frequencies if f > 100]), x, sigma)
    return x, y


def uv_spectrum(excitations: Sequence[Dict[str, float]], sigma: float = 0.15):
    x = np.linspace(100.0, 800.0, 1400)
    positions = [e["wavelength_nm"] for e in excitations if e.get("wavelength_nm")]
    intensities = [e.get("oscillator", 0.0) for e in excitations if e.get("wavelength_nm")]
    return x, broaden(positions, intensities, x, sigma)


def thermo(frequencies: Sequence[float], mol: Molecule, temperature: float = 298.15) -> Dict[str, float]:
    freqs = np.asarray([f for f in frequencies if f > 10.0], dtype=float)
    if freqs.size == 0:
        return {}
    # harmonic oscillator in cm^-1
    x = (H_PLANCK * C_LIGHT * freqs * 100.0) / (KB * temperature)
    zpe = float(np.sum(0.5 * H_PLANCK * C_LIGHT * freqs * 100.0) * 6.02214076e23 / 1000.0)
    vib_u = float(R_GAS * temperature * np.sum(x / np.expm1(x)) / 1000.0)
    vib_s = float(R_GAS * np.sum(x / np.expm1(x) - np.log1p(-np.exp(-x))))
    # translation
    mass = mol.molecular_weight() * AMU
    volume = KB * temperature / 101325.0
    q_trans = ((2 * math.pi * mass * KB * temperature) / H_PLANCK**2) ** 1.5 * volume
    s_trans = R_GAS * (math.log(q_trans) + 2.5)
    # rotation (convert Angstrom to metres)
    coords = mol.coords() * 1e-10
    com = np.asarray(mol.center_of_mass()) * 1e-10
    masses = np.asarray([WEIGHT.get(a[0], 1.0) for a in mol.atoms]) * AMU
    rel = coords - com
    inertia = np.zeros((3, 3))
    for m, r in zip(masses, rel):
        inertia += m * (np.dot(r, r) * np.eye(3) - np.outer(r, r))
    eig = np.linalg.eigvalsh(inertia)
    eig = eig[eig > 1e-60]
    if eig.size == 3:
        q_rot = math.sqrt(math.pi) / 1.0 * (8 * math.pi**2 * KB * temperature / H_PLANCK**2) ** 1.5 * math.sqrt(float(np.prod(eig)))
        s_rot = R_GAS * (math.log(q_rot) + 1.5)
    else:
        s_rot = 0.0
    s_elec = R_GAS * math.log(max(1, mol.multiplicity))
    s_total = s_trans + s_rot + vib_s + s_elec
    thermal_u = 1.5 * R_GAS * temperature / 1000.0 + 1.5 * R_GAS * temperature / 1000.0 + vib_u
    gibbs = zpe + thermal_u - temperature * s_total / 1000.0
    return {
        "temperature_k": temperature,
        "zpe_kj": zpe,
        "thermal_correction_kj": thermal_u,
        "entropy_j_k": s_total,
        "gibbs_correction_kj": gibbs,
        "zpe_hartree": zpe / HARTREE_TO_KJ,
        "gibbs_hartree": gibbs / HARTREE_TO_KJ,
    }


# -- cube files ------------------------------------------------------------


def parse_cube(path: os.PathLike | str) -> Dict[str, Any]:
    path = Path(path)
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    if len(lines) < 8:
        raise ValueError("Cube file too short")
    parts = lines[2].split()
    natoms = int(parts[0])
    origin = np.asarray([float(x) for x in parts[1:4]])
    dims, axes = [], []
    for i in range(3):
        parts = lines[3 + i].split()
        dims.append(abs(int(parts[0])))
        axes.append([float(x) for x in parts[1:4]])
    atoms = []
    for line in lines[6 : 6 + natoms]:
        parts = line.split()
        if len(parts) >= 5:
            atoms.append((SYMBOL_BY_Z.get(int(float(parts[0])), "X"), *[float(x) for x in parts[2:5]]))
    data_lines = lines[6 + natoms :]
    values = np.fromstring(" ".join(data_lines), sep=" ")
    expected = dims[0] * dims[1] * dims[2]
    values = values[:expected]
    if values.size != expected:
        raise ValueError(f"Cube data size {values.size} != {expected}")
    data = values.reshape((dims[0], dims[1], dims[2]), order="F")
    return {
        "path": str(path),
        "origin": origin,
        "axes": np.asarray(axes),
        "dims": dims,
        "atoms": atoms,
        "data": data,
    }


def cube_slice(cube: Dict[str, Any], axis: str = "z", index: Optional[int] = None) -> Dict[str, Any]:
    data = cube["data"]
    dims = cube["dims"]
    if axis == "x":
        index = dims[0] // 2 if index is None else index
        values = data[index, :, :].T
        u = np.arange(dims[1]); v = np.arange(dims[2])
    elif axis == "y":
        index = dims[1] // 2 if index is None else index
        values = data[:, index, :].T
        u = np.arange(dims[0]); v = np.arange(dims[2])
    else:
        index = dims[2] // 2 if index is None else index
        values = data[:, :, index].T
        u = np.arange(dims[0]); v = np.arange(dims[1])
    return {"axis": axis, "index": int(index), "u": u.tolist(), "v": v.tolist(), "values": values.tolist()}
