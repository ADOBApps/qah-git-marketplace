"""PySide6 interface for SEQItachi."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from . import seqitachi_core as core
from . import seqitachi_tools as tools

try:
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
    from matplotlib.figure import Figure
    MATPLOTLIB_OK = True
except Exception:
    FigureCanvasQTAgg = None  # type: ignore
    Figure = None  # type: ignore
    MATPLOTLIB_OK = False

ATOM_COLORS = {
    "H": "#e5e7eb", "C": "#374151", "N": "#2563eb", "O": "#dc2626",
    "F": "#059669", "S": "#ca8a04", "P": "#ea580c", "Cl": "#16a34a",
    "Br": "#7c2d12", "I": "#4c1d95", "Fe": "#b45309", "Pd": "#0f766e",
    "Pt": "#475569", "Ni": "#15803d", "Cu": "#b45309", "Zn": "#64748b",
}


class SEQItachiWidget(QWidget):
    def __init__(self, plugin=None, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.molecule: Optional[core.Molecule] = None
        self.output: Dict[str, Any] = {}
        self.cube: Dict[str, Any] = {}
        self._build_ui()
        self._load_demo()

    # -- construction -----------------------------------------------------

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)
        header = QHBoxLayout()
        title = QLabel("<b>SEQItachi</b>")
        title.setFont(QFont("Segoe UI", 15, QFont.Weight.Bold))
        header.addWidget(title)
        subtitle = QLabel("Structure · QM input/output · spectra · thermochemistry · cubes")
        subtitle.setStyleSheet("color:#6b7280;")
        header.addWidget(subtitle, 1)
        self.badge = QLabel("GPL-3.0 · independent implementation")
        self.badge.setStyleSheet("color:#6b7280;")
        header.addWidget(self.badge)
        layout.addLayout(header)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_structure_tab(), "Structure")
        self.tabs.addTab(self._build_edit_tab(), "Edit")
        self.tabs.addTab(self._build_analysis_tab(), "Analysis")
        self.tabs.addTab(self._build_input_tab(), "QM Input")
        self.tabs.addTab(self._build_results_tab(), "Results")
        self.tabs.addTab(self._build_cube_tab(), "Cube")
        self.tabs.addTab(self._build_tools_tab(), "Tools")
        self.tabs.addTab(self._build_help_tab(), "Help")
        layout.addWidget(self.tabs, 1)

        self.status = QLabel("Ready.")
        self.status.setStyleSheet("color:#6b7280;")
        layout.addWidget(self.status)

    def _make_canvas(self, w: float, h: float):
        if not MATPLOTLIB_OK:
            label = QLabel("matplotlib is not available; 3D views are disabled.")
            label.setStyleSheet("color:#b91c1c;")
            return label
        canvas = FigureCanvasQTAgg(Figure(figsize=(w, h), tight_layout=True))
        canvas.setMinimumHeight(240)
        return canvas

    def _build_structure_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        row = QHBoxLayout()
        load = QPushButton("Load XYZ/output…")
        load.clicked.connect(self._load_structure)
        row.addWidget(load)
        demo = QPushButton("Water")
        demo.clicked.connect(lambda _c=False: self._load_demo("water"))
        row.addWidget(demo)
        benzene = QPushButton("Benzene")
        benzene.clicked.connect(lambda _c=False: self._load_demo("benzene"))
        row.addWidget(benzene)
        center = QPushButton("Center at origin")
        center.clicked.connect(self._center_molecule)
        row.addWidget(center)
        row.addStretch(1)
        self.structure_label = QLabel("No structure")
        row.addWidget(self.structure_label)
        layout.addLayout(row)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        self.structure_canvas = self._make_canvas(6.0, 5.0)
        splitter.addWidget(self.structure_canvas)
        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        self.atom_table = QTableWidget(0, 5)
        self.atom_table.setHorizontalHeaderLabels(["#", "Element", "X (Å)", "Y (Å)", "Z (Å)"])
        self.atom_table.verticalHeader().setVisible(False)
        self.atom_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.atom_table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.atom_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.atom_table.setColumnWidth(0, 45)
        self.atom_table.setColumnWidth(1, 70)
        self.atom_table.itemSelectionChanged.connect(self._selection_changed)
        right_layout.addWidget(self.atom_table, 1)
        self.bond_label = QLabel("")
        self.bond_label.setWordWrap(True)
        self.bond_label.setStyleSheet("color:#6b7280;")
        right_layout.addWidget(self.bond_label)
        splitter.addWidget(right)
        splitter.setSizes([650, 420])
        layout.addWidget(splitter, 1)
        return page

    def _build_edit_tab(self) -> QWidget:
        page = QWidget()
        outer = QVBoxLayout(page)
        outer.setContentsMargins(6, 6, 6, 6)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(0, 0, 0, 0)

        add_box = QGroupBox("Add atom")
        add_form = QFormLayout(add_box)
        self.add_symbol = QComboBox()
        self.add_symbol.addItems(core.SYMBOLS)
        add_form.addRow("Element:", self.add_symbol)
        coord_row = QHBoxLayout()
        self.add_x = QDoubleSpinBox(); self.add_x.setRange(-99, 99); self.add_x.setDecimals(4)
        self.add_y = QDoubleSpinBox(); self.add_y.setRange(-99, 99); self.add_y.setDecimals(4)
        self.add_z = QDoubleSpinBox(); self.add_z.setRange(-99, 99); self.add_z.setDecimals(4)
        for widget in (self.add_x, self.add_y, self.add_z):
            coord_row.addWidget(widget)
        add_form.addRow("X/Y/Z:", coord_row)
        add_button = QPushButton("Add atom")
        add_button.clicked.connect(self._add_atom)
        add_form.addRow("", add_button)
        layout.addWidget(add_box)

        edit_box = QGroupBox("Selected atoms")
        edit_form = QFormLayout(edit_box)
        self.change_symbol = QComboBox()
        self.change_symbol.addItems(core.SYMBOLS)
        edit_form.addRow("Change element to:", self.change_symbol)
        apply_element = QPushButton("Apply element to selection")
        apply_element.clicked.connect(self._change_element)
        edit_form.addRow("", apply_element)
        delete_button = QPushButton("Delete selected atoms")
        delete_button.clicked.connect(self._delete_atoms)
        edit_form.addRow("", delete_button)
        layout.addWidget(edit_box)

        bond_box = QGroupBox("Bonds")
        bond_form = QFormLayout(bond_box)
        self.bond_i = QSpinBox(); self.bond_i.setRange(1, 1)
        self.bond_j = QSpinBox(); self.bond_j.setRange(1, 1)
        self.bond_order = QDoubleSpinBox(); self.bond_order.setRange(0.5, 3.0); self.bond_order.setSingleStep(0.5); self.bond_order.setValue(1.0)
        bond_form.addRow("Atom i:", self.bond_i)
        bond_form.addRow("Atom j:", self.bond_j)
        bond_form.addRow("Order:", self.bond_order)
        bond_row = QHBoxLayout()
        add_bond = QPushButton("Add/replace bond")
        add_bond.clicked.connect(self._add_bond)
        bond_row.addWidget(add_bond)
        remove_bond = QPushButton("Remove bond")
        remove_bond.clicked.connect(self._remove_bond)
        bond_row.addWidget(remove_bond)
        bond_form.addRow("", bond_row)
        self.length_value = QDoubleSpinBox(); self.length_value.setRange(0.1, 10.0); self.length_value.setDecimals(4); self.length_value.setValue(1.0)
        bond_form.addRow("Set bond length:", self.length_value)
        set_length = QPushButton("Apply length")
        set_length.clicked.connect(self._set_bond_length)
        bond_form.addRow("", set_length)
        layout.addWidget(bond_box)

        transform_box = QGroupBox("Transform")
        transform_form = QFormLayout(transform_box)
        self.rot_axis = QComboBox(); self.rot_axis.addItems(["X", "Y", "Z"])
        self.rot_angle = QDoubleSpinBox(); self.rot_angle.setRange(-360, 360); self.rot_angle.setValue(90)
        transform_form.addRow("Rotate axis:", self.rot_axis)
        transform_form.addRow("Angle (deg):", self.rot_angle)
        rotate = QPushButton("Rotate molecule")
        rotate.clicked.connect(self._rotate)
        transform_form.addRow("", rotate)
        trans_row = QHBoxLayout()
        self.trans_x = QDoubleSpinBox(); self.trans_x.setRange(-99, 99); self.trans_x.setDecimals(3)
        self.trans_y = QDoubleSpinBox(); self.trans_y.setRange(-99, 99); self.trans_y.setDecimals(3)
        self.trans_z = QDoubleSpinBox(); self.trans_z.setRange(-99, 99); self.trans_z.setDecimals(3)
        for widget in (self.trans_x, self.trans_y, self.trans_z):
            trans_row.addWidget(widget)
        transform_form.addRow("Translate:", trans_row)
        translate = QPushButton("Translate molecule")
        translate.clicked.connect(self._translate)
        transform_form.addRow("", translate)
        layout.addWidget(transform_box)
        scroll.setWidget(content)
        outer.addWidget(scroll, 1)
        return page

    def _build_analysis_tab(self) -> QWidget:
        page = QWidget()
        outer = QVBoxLayout(page)
        outer.setContentsMargins(6, 6, 6, 6)
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        content = QWidget(); layout = QVBoxLayout(content); layout.setContentsMargins(0, 0, 0, 0)

        info_box = QGroupBox("Structure")
        info_form = QFormLayout(info_box)
        self.info_formula = QLabel("—"); self.info_mw = QLabel("—"); self.info_atoms = QLabel("—")
        self.info_bonds = QLabel("—"); self.info_com = QLabel("—"); self.info_rg = QLabel("—")
        for label, widget in (("Formula:", self.info_formula), ("Molecular weight:", self.info_mw),
                              ("Atoms:", self.info_atoms), ("Bonds:", self.info_bonds),
                              ("Center of mass:", self.info_com), ("Radius of gyration:", self.info_rg)):
            info_form.addRow(label, widget)
        layout.addWidget(info_box)

        geom_box = QGroupBox("Geometry selection")
        geom_form = QFormLayout(geom_box)
        self.geom_i = QSpinBox(); self.geom_i.setRange(1, 1)
        self.geom_j = QSpinBox(); self.geom_j.setRange(1, 1)
        self.geom_k = QSpinBox(); self.geom_k.setRange(1, 1)
        self.geom_l = QSpinBox(); self.geom_l.setRange(1, 1)
        for label, widget in (("Atom i:", self.geom_i), ("Atom j:", self.geom_j), ("Atom k:", self.geom_k), ("Atom l:", self.geom_l)):
            geom_form.addRow(label, widget)
        row = QHBoxLayout()
        for label, func in (("Distance", self._calc_distance), ("Angle", self._calc_angle), ("Dihedral", self._calc_dihedral)):
            button = QPushButton(label); button.clicked.connect(lambda _c=False, f=func: f()); row.addWidget(button)
        geom_form.addRow("", row)
        layout.addWidget(geom_box)

        steri_box = QGroupBox("Sterimol / cone / buried volume")
        steri_form = QFormLayout(steri_box)
        self.center_atom = QSpinBox(); self.center_atom.setRange(1, 1)
        self.ligand_atoms = QLineEdit(); self.ligand_atoms.setPlaceholderText("e.g. 2,3,4,5")
        self.bv_radius = QDoubleSpinBox(); self.bv_radius.setRange(1.0, 10.0); self.bv_radius.setValue(3.5)
        self.bv_spacing = QDoubleSpinBox(); self.bv_spacing.setRange(0.1, 1.0); self.bv_spacing.setValue(0.3); self.bv_spacing.setSingleStep(0.1)
        steri_form.addRow("Center atom:", self.center_atom)
        steri_form.addRow("Ligand atoms:", self.ligand_atoms)
        steri_form.addRow("Buried radius (Å):", self.bv_radius)
        steri_form.addRow("Voxel spacing (Å):", self.bv_spacing)
        row2 = QHBoxLayout()
        for label, func in (("Sterimol", self._calc_sterimol), ("Cone angle", self._calc_cone), ("Buried volume", self._calc_buried)):
            button = QPushButton(label); button.clicked.connect(lambda _c=False, f=func: f()); row2.addWidget(button)
        steri_form.addRow("", row2)
        layout.addWidget(steri_box)
        self.analysis_output = QPlainTextEdit(); self.analysis_output.setReadOnly(True)
        self.analysis_output.setFont(QFont("Consolas", 9))
        layout.addWidget(self.analysis_output, 1)
        scroll.setWidget(content); outer.addWidget(scroll, 1)
        return page

    def _build_input_tab(self) -> QWidget:
        page = QWidget()
        outer = QVBoxLayout(page); outer.setContentsMargins(6, 6, 6, 6)
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        content = QWidget(); layout = QVBoxLayout(content); layout.setContentsMargins(0, 0, 0, 0)
        box = QGroupBox("Build QM input")
        form = QFormLayout(box)
        self.qm_software = QComboBox(); self.qm_software.addItems(["Gaussian", "ORCA", "Psi4", "Q-Chem", "xTB", "sqm"])
        form.addRow("Software:", self.qm_software)
        self.qm_method = QLineEdit("B3LYP"); form.addRow("Method:", self.qm_method)
        self.qm_basis = QLineEdit("6-31G(d)"); form.addRow("Basis:", self.qm_basis)
        self.qm_job = QLineEdit("opt freq"); form.addRow("Job:", self.qm_job)
        self.qm_charge = QSpinBox(); self.qm_charge.setRange(-5, 5); form.addRow("Charge:", self.qm_charge)
        self.qm_mult = QSpinBox(); self.qm_mult.setRange(1, 5); form.addRow("Multiplicity:", self.qm_mult)
        self.qm_nproc = QSpinBox(); self.qm_nproc.setRange(1, 64); self.qm_nproc.setValue(4); form.addRow("CPU threads:", self.qm_nproc)
        self.qm_memory = QLineEdit("4GB"); form.addRow("Memory:", self.qm_memory)
        self.qm_solvent = QLineEdit(); self.qm_solvent.setPlaceholderText("optional, e.g. water"); form.addRow("Solvent:", self.qm_solvent)
        self.qm_title = QLineEdit("SEQItachi job"); form.addRow("Title:", self.qm_title)
        row = QHBoxLayout()
        preview = QPushButton("Preview"); preview.clicked.connect(lambda _c=False: self._preview_input()); row.addWidget(preview)
        save = QPushButton("Save input…"); save.clicked.connect(lambda _c=False: self._save_input()); row.addWidget(save)
        row.addStretch(1); form.addRow("", row)
        layout.addWidget(box)
        self.input_preview = QPlainTextEdit(); self.input_preview.setReadOnly(True); self.input_preview.setFont(QFont("Consolas", 9))
        layout.addWidget(self.input_preview, 1)
        scroll.setWidget(content); outer.addWidget(scroll, 1)
        return page

    def _build_results_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page); layout.setContentsMargins(6, 6, 6, 6)
        row = QHBoxLayout()
        load = QPushButton("Load output…"); load.clicked.connect(self._load_output); row.addWidget(load)
        use_geom = QPushButton("Use output geometry"); use_geom.clicked.connect(self._use_output_geometry); row.addWidget(use_geom)
        row.addStretch(1); layout.addLayout(row)
        self.result_summary = QPlainTextEdit(); self.result_summary.setReadOnly(True); self.result_summary.setFont(QFont("Consolas", 9)); self.result_summary.setMaximumHeight(210)
        layout.addWidget(self.result_summary)
        splitter = QSplitter(Qt.Orientation.Horizontal)
        self.freq_table = QTableWidget(0, 1); self.freq_table.setHorizontalHeaderLabels(["Frequency (cm⁻¹)"])
        self.freq_table.verticalHeader().setVisible(False); self.freq_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        splitter.addWidget(self.freq_table)
        self.exc_table = QTableWidget(0, 3); self.exc_table.setHorizontalHeaderLabels(["eV", "nm", "f"])
        self.exc_table.verticalHeader().setVisible(False); self.exc_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        splitter.addWidget(self.exc_table)
        layout.addWidget(splitter, 1)
        self.spectrum_canvas = self._make_canvas(6.0, 3.2)
        layout.addWidget(self.spectrum_canvas)
        self.thermo_output = QPlainTextEdit(); self.thermo_output.setReadOnly(True); self.thermo_output.setFont(QFont("Consolas", 9)); self.thermo_output.setMaximumHeight(150)
        layout.addWidget(self.thermo_output)
        return page

    def _build_cube_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page); layout.setContentsMargins(6, 6, 6, 6)
        row = QHBoxLayout()
        load = QPushButton("Load cube…"); load.clicked.connect(self._load_cube); row.addWidget(load)
        row.addWidget(QLabel("Axis:"))
        self.cube_axis = QComboBox(); self.cube_axis.addItems(["z", "y", "x"]); self.cube_axis.currentTextChanged.connect(lambda _t: self._draw_cube()); row.addWidget(self.cube_axis)
        row.addWidget(QLabel("Index:"))
        self.cube_index = QSpinBox(); self.cube_index.setRange(0, 0); self.cube_index.valueChanged.connect(lambda _v: self._draw_cube()); row.addWidget(self.cube_index)
        use_atoms = QPushButton("Use cube atoms"); use_atoms.clicked.connect(self._use_cube_atoms); row.addWidget(use_atoms)
        row.addStretch(1); layout.addLayout(row)
        self.cube_canvas = self._make_canvas(7.0, 5.0); layout.addWidget(self.cube_canvas, 1)
        self.cube_info = QLabel("No cube loaded. Supports Gaussian cube files."); self.cube_info.setStyleSheet("color:#6b7280;")
        layout.addWidget(self.cube_info)
        return page

    def _build_tools_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(6, 6, 6, 6)
        note = QLabel(
            "External executables are optional and user-supplied. SEQItachi never "
            "bundles ORCA, xtb, CREST, Gaussian, Psi4 or Q-Chem. Missing tools are "
            "reported as errors only when an external job is requested."
        )
        note.setWordWrap(True)
        note.setStyleSheet("background:#eff6ff; color:#1e3a8a; padding:6px; border:1px solid #bfdbfe;")
        layout.addWidget(note)

        self.tool_table = QTableWidget(0, 4)
        self.tool_table.setHorizontalHeaderLabels(["Tool", "Status", "Path", "Source / hint"])
        self.tool_table.verticalHeader().setVisible(False)
        self.tool_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tool_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.tool_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tool_table.setWordWrap(True)
        self.tool_table.setColumnWidth(0, 110)
        self.tool_table.setColumnWidth(1, 80)
        self.tool_table.setColumnWidth(2, 420)
        self.tool_table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.tool_table, 1)

        row = QHBoxLayout()
        detect = QPushButton("Detect tools")
        detect.clicked.connect(lambda _c=False: self._refresh_tools())
        row.addWidget(detect)
        browse = QPushButton("Set selected path…")
        browse.clicked.connect(lambda _c=False: self._browse_tool())
        row.addWidget(browse)
        clear = QPushButton("Clear selected path")
        clear.clicked.connect(lambda _c=False: self._clear_tool())
        row.addWidget(clear)
        require = QPushButton("Check selected tool")
        require.clicked.connect(lambda _c=False: self._check_tool())
        row.addWidget(require)
        row.addStretch(1)
        layout.addLayout(row)
        self.tool_status = QLabel("")
        self.tool_status.setStyleSheet("color:#6b7280;")
        layout.addWidget(self.tool_status)
        self._refresh_tools()
        return page

    def _refresh_tools(self) -> None:
        data = tools.detect_all()
        self.tool_table.setRowCount(0)
        for tool_id, info in data.items():
            row = self.tool_table.rowCount()
            self.tool_table.insertRow(row)
            values = [
                info.get("label", tool_id),
                "found" if info.get("found") else "missing",
                info.get("path", ""),
                info.get("source", "") if info.get("found") else info.get("hint", ""),
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setData(Qt.ItemDataRole.UserRole, tool_id)
                if col == 1:
                    item.setForeground(QColor("#15803d") if info.get("found") else QColor("#b91c1c"))
                self.tool_table.setItem(row, col, item)
        self.tool_status.setText(f"Toolchain config: {tools.CONFIG}")

    def _selected_tool(self) -> str:
        rows = self.tool_table.selectionModel().selectedRows()
        if not rows:
            return ""
        item = self.tool_table.item(rows[0].row(), 0)
        return str(item.data(Qt.ItemDataRole.UserRole) or "") if item else ""

    def _browse_tool(self) -> None:
        tool = self._selected_tool()
        if not tool:
            QMessageBox.information(self, "SEQItachi", "Select a tool row first.")
            return
        path, _ = QFileDialog.getOpenFileName(self, f"Set {tool} executable", str(Path.home()), "Executables (*.exe);;All files (*)")
        if path:
            tools.set_tool_path(tool, path)
            self._refresh_tools()

    def _clear_tool(self) -> None:
        tool = self._selected_tool()
        if tool:
            tools.set_tool_path(tool, "")
            self._refresh_tools()

    def _check_tool(self) -> None:
        tool = self._selected_tool()
        if not tool:
            QMessageBox.information(self, "SEQItachi", "Select a tool row first.")
            return
        try:
            info = tools.require_tool(tool)
            QMessageBox.information(self, "SEQItachi", f"{info['label']} found:\n{info['path']}")
        except tools.ToolNotFoundError as exc:
            QMessageBox.warning(self, "SEQItachi", str(exc))

    def _build_help_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page); layout.setContentsMargins(6, 6, 6, 6)
        browser = QTextBrowser(); browser.setOpenExternalLinks(True)
        browser.setHtml("""
        <h2>SEQItachi</h2>
        <p>A QAH-native structure and quantum-chemistry workbench inspired by
        <b>SEQCROW</b> (GPL-3.0). This is an independent implementation; no
        SEQCROW code is copied and it is not affiliated with the SEQCROW
        authors.</p>
        <h3>Implemented</h3>
        <ul>
          <li>XYZ import, molecule table, inferred bonds, 3D ball-and-stick view;</li>
          <li>atom add/delete, element change, bond add/remove/order/length, rotate/translate;</li>
          <li>formula, molecular weight, center of mass, radius of gyration, distance/angle/dihedral;</li>
          <li>approximate Sterimol, cone angle and buried-volume voxel analysis;</li>
          <li>Gaussian, ORCA, Psi4, Q-Chem, xTB and sqm input builders;</li>
          <li>Gaussian/ORCA/Psi4/Q-Chem output parsing: energy, geometry, HOMO/LUMO, frequencies, excitations;</li>
          <li>IR and UV/Vis broadening plots, RRHO thermochemistry from frequencies;</li>
          <li>Gaussian cube 2D slices.</li>
          <li>external-tool detection for ORCA, xtb, CREST, Gaussian, Psi4 and
              Q-Chem, with saved custom paths and clear missing-tool errors.</li>
        </ul>
        <h3>Not yet implemented</h3>
        <p>ChimeraX mouse modes, 2D sketcher, AaronTools fragment library,
        conformer search/CREST, transition-state interpolation, normal-mode
        animation, full orbital isosurfaces, point groups, and the complete
        Sterimol/ligand library. These are roadmap items, not claims of complete
        SEQCROW parity.</p>
        <h3>License</h3>
        <p>SEQItachi is GPL-3.0 or later. SEQCROW is GPL-3.0; see its GitHub
        repository and the J. Comput. Chem. 2021 citation. This plugin does not
        bundle SEQCROW or AaronTools.</p>
        """)
        layout.addWidget(browser, 1)
        return page

    # -- structure --------------------------------------------------------

    def _load_demo(self, name: str = "water") -> None:
        if name == "benzene":
            text = """12
benzene
C  1.3960  0.0000  0.0000
C  0.6980  1.2090  0.0000
C -0.6980  1.2090  0.0000
C -1.3960  0.0000  0.0000
C -0.6980 -1.2090  0.0000
C  0.6980 -1.2090  0.0000
H  2.4790  0.0000  0.0000
H  1.2395  2.1460  0.0000
H -1.2395  2.1460  0.0000
H -2.4790  0.0000  0.0000
H -1.2395 -2.1460  0.0000
H  1.2395 -2.1460  0.0000
"""
        else:
            text = """3
water
O  0.0000  0.0000  0.1173
H  0.0000  0.7572 -0.4692
H  0.0000 -0.7572 -0.4692
"""
        self.molecule = core.Molecule.from_xyz_text(text)
        self._refresh_all()

    def _load_structure(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Load structure", str(Path.home()),
                                              "Structures (*.xyz *.out *.log);;All files (*)")
        if not path:
            return
        try:
            lower = path.lower()
            if lower.endswith((".out", ".log")):
                result = core.parse_output(path)
                if result.get("geometry") is None:
                    raise ValueError("No geometry found in output")
                self.molecule = result["geometry"]
                self.output = result
                self._show_output()
            else:
                self.molecule = core.Molecule.from_xyz_file(path)
            self._refresh_all()
            self.status.setText(f"Loaded {path}")
        except Exception as exc:
            QMessageBox.warning(self, "SEQItachi", str(exc))

    def _center_molecule(self) -> None:
        if not self.molecule:
            return
        com = self.molecule.center_of_mass()
        self.molecule.translate(-com[0], -com[1], -com[2])
        self._refresh_all()

    def _refresh_all(self) -> None:
        self._refresh_tables()
        self._draw_molecule()
        self._refresh_analysis()
        self._refresh_spin_limits()

    def _refresh_tables(self) -> None:
        mol = self.molecule
        self.atom_table.setRowCount(0)
        if not mol:
            return
        for index, (symbol, x, y, z) in enumerate(mol.atoms):
            row = self.atom_table.rowCount(); self.atom_table.insertRow(row)
            for col, value in enumerate((str(index + 1), symbol, f"{x:.4f}", f"{y:.4f}", f"{z:.4f}")):
                self.atom_table.setItem(row, col, QTableWidgetItem(value))
        self.bond_label.setText(f"{len(mol.bonds)} inferred/defined bond(s)")
        self.structure_label.setText(f"{mol.formula()} · {len(mol)} atoms")

    def _selection_changed(self) -> None:
        if not self.molecule:
            return
        rows = self.atom_table.selectionModel().selectedRows()
        if rows:
            index = rows[0].row()
            if 0 <= index < len(self.molecule.atoms):
                symbol = self.molecule.atoms[index][0]
                pos = self.molecule.atoms[index][1:]
                self.status.setText(f"Atom {index + 1}: {symbol} at ({pos[0]:.3f}, {pos[1]:.3f}, {pos[2]:.3f}) Å")

    def _selected_indices(self) -> List[int]:
        return sorted({row.row() for row in self.atom_table.selectionModel().selectedRows()})

    def _draw_molecule(self) -> None:
        if not MATPLOTLIB_OK or not hasattr(self.structure_canvas, "figure"):
            return
        fig = self.structure_canvas.figure; fig.clear()
        ax = fig.add_subplot(111, projection="3d")
        mol = self.molecule
        if not mol:
            ax.text(0, 0, 0, "No structure")
            self.structure_canvas.draw_idle(); return
        coords = mol.coords()
        for i, j, _order in mol.bonds:
            ax.plot([coords[i, 0], coords[j, 0]], [coords[i, 1], coords[j, 1]], [coords[i, 2], coords[j, 2]], color="#9ca3af", linewidth=1.6)
        for index, (symbol, x, y, z) in enumerate(mol.atoms):
            ax.scatter([x], [y], [z], s=180 if symbol != "H" else 80,
                       color=ATOM_COLORS.get(symbol, "#a855f7"), edgecolors="#111827", linewidths=0.7)
            ax.text(x, y, z, symbol, fontsize=7, ha="center", va="center", color="white" if symbol != "H" else "#111827")
        ax.set_box_aspect((1, 1, 1)); ax.axis("off")
        ax.set_title(f"{mol.name} · {mol.formula()}")
        self.structure_canvas.draw_idle()

    # -- editing ----------------------------------------------------------

    def _add_atom(self) -> None:
        if not self.molecule:
            return
        self.molecule.add_atom(self.add_symbol.currentText(), self.add_x.value(), self.add_y.value(), self.add_z.value())
        self._refresh_all()

    def _change_element(self) -> None:
        if not self.molecule: return
        for index in self._selected_indices():
            self.molecule.set_element(index, self.change_symbol.currentText())
        self._refresh_all()

    def _delete_atoms(self) -> None:
        if not self.molecule: return
        for index in sorted(self._selected_indices(), reverse=True):
            self.molecule.remove_atom(index)
        self._refresh_all()

    def _add_bond(self) -> None:
        if not self.molecule: return
        self.molecule.add_bond(self.bond_i.value() - 1, self.bond_j.value() - 1, self.bond_order.value())
        self._refresh_all()

    def _remove_bond(self) -> None:
        if not self.molecule: return
        self.molecule.remove_bond(self.bond_i.value() - 1, self.bond_j.value() - 1)
        self._refresh_all()

    def _set_bond_length(self) -> None:
        if not self.molecule: return
        self.molecule.set_bond_length(self.bond_i.value() - 1, self.bond_j.value() - 1, self.length_value.value())
        self._refresh_all()

    def _rotate(self) -> None:
        if not self.molecule: return
        axis = {"X": (1, 0, 0), "Y": (0, 1, 0), "Z": (0, 0, 1)}[self.rot_axis.currentText()]
        self.molecule.rotate(axis, self.rot_angle.value())
        self._refresh_all()

    def _translate(self) -> None:
        if not self.molecule: return
        self.molecule.translate(self.trans_x.value(), self.trans_y.value(), self.trans_z.value())
        self._refresh_all()

    def _refresh_spin_limits(self) -> None:
        count = len(self.molecule) if self.molecule else 1
        for spin in (self.geom_i, self.geom_j, self.geom_k, self.geom_l, self.center_atom, self.bond_i, self.bond_j):
            spin.setRange(1, max(1, count))
        self.geom_k.setValue(min(3, count)); self.geom_l.setValue(min(4, count))

    # -- analysis ---------------------------------------------------------

    def _refresh_analysis(self) -> None:
        mol = self.molecule
        if not mol:
            return
        self.info_formula.setText(mol.formula())
        self.info_mw.setText(f"{mol.molecular_weight():.3f} g/mol")
        self.info_atoms.setText(str(len(mol)))
        self.info_bonds.setText(str(len(mol.bonds)))
        com = mol.center_of_mass()
        self.info_com.setText(f"({com[0]:.3f}, {com[1]:.3f}, {com[2]:.3f}) Å")
        self.info_rg.setText(f"{mol.radius_of_gyration():.3f} Å")

    def _calc_distance(self) -> None:
        if not self.molecule: return
        self.analysis_output.appendPlainText(f"Distance {self.geom_i.value()}–{self.geom_j.value()}: {self.molecule.distance(self.geom_i.value()-1, self.geom_j.value()-1):.4f} Å")

    def _calc_angle(self) -> None:
        if not self.molecule: return
        self.analysis_output.appendPlainText(f"Angle {self.geom_i.value()}–{self.geom_j.value()}–{self.geom_k.value()}: {self.molecule.angle(self.geom_i.value()-1, self.geom_j.value()-1, self.geom_k.value()-1):.3f}°")

    def _calc_dihedral(self) -> None:
        if not self.molecule: return
        self.analysis_output.appendPlainText(f"Dihedral {self.geom_i.value()}–{self.geom_j.value()}–{self.geom_k.value()}–{self.geom_l.value()}: {self.molecule.dihedral(self.geom_i.value()-1, self.geom_j.value()-1, self.geom_k.value()-1, self.geom_l.value()-1):.3f}°")

    def _ligands(self) -> List[int]:
        return [int(x) - 1 for x in self.ligand_atoms.text().replace(";", ",").split(",") if x.strip().isdigit()]

    def _calc_sterimol(self) -> None:
        if not self.molecule: return
        values = core.sterimol(self.molecule, self.center_atom.value() - 1, self._ligands())
        self.analysis_output.appendPlainText("Sterimol (approximate): " + ", ".join(f"{k}={v:.3f}" for k, v in values.items()))

    def _calc_cone(self) -> None:
        if not self.molecule: return
        value = core.cone_angle(self.molecule, self.center_atom.value() - 1, self._ligands())
        self.analysis_output.appendPlainText(f"Cone angle (approximate): {value:.2f}°")

    def _calc_buried(self) -> None:
        if not self.molecule: return
        value = core.buried_volume(self.molecule, self.center_atom.value() - 1, self._ligands(), self.bv_radius.value(), self.bv_spacing.value())
        self.analysis_output.appendPlainText(f"Buried volume (approximate): {value:.2f}%")

    # -- QM input ---------------------------------------------------------

    def _preview_input(self) -> None:
        if not self.molecule: return
        try:
            text = core.build_qm_input(
                self.qm_software.currentText(), self.molecule,
                method=self.qm_method.text(), basis=self.qm_basis.text(),
                job=self.qm_job.text(), charge=self.qm_charge.value(),
                multiplicity=self.qm_mult.value(), title=self.qm_title.text(),
                nproc=self.qm_nproc.value(), memory=self.qm_memory.text(),
                solvent=self.qm_solvent.text().strip(),
            )
            self.input_preview.setPlainText(text)
        except Exception as exc:
            QMessageBox.warning(self, "SEQItachi", str(exc))

    def _save_input(self) -> None:
        if not self.molecule: return
        path, _ = QFileDialog.getSaveFileName(self, "Save QM input", "input.inp", "Input (*.inp *.com *.gjf *.txt);;All files (*)")
        if not path: return
        self._preview_input()
        Path(path).write_text(self.input_preview.toPlainText(), encoding="utf-8")
        self.status.setText(f"Saved {path}")

    # -- results ----------------------------------------------------------

    def _load_output(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Load QM output", str(Path.home()), "Output (*.out *.log *.txt);;All files (*)")
        if not path: return
        try:
            self.output = core.parse_output(path)
            if self.output.get("geometry"):
                self.molecule = self.output["geometry"]
            self._show_output()
            self._refresh_all()
        except Exception as exc:
            QMessageBox.warning(self, "SEQItachi", str(exc))

    def _show_output(self) -> None:
        data = self.output
        lines = [
            f"Software: {data.get('software', '')}",
            f"Energy: {data.get('energy')} Ha" if data.get("energy") is not None else "Energy: —",
            f"HOMO: {data.get('homo')} Ha" if data.get("homo") is not None else "HOMO: —",
            f"LUMO: {data.get('lumo')} Ha" if data.get("lumo") is not None else "LUMO: —",
            f"Gap: {data.get('gap')} Ha" if data.get("gap") is not None else "Gap: —",
            f"Frequencies: {len(data.get('frequencies') or [])}",
            f"Excitations: {len(data.get('excitations') or [])}",
        ]
        self.result_summary.setPlainText("\n".join(lines))
        self.freq_table.setRowCount(0)
        for freq in data.get("frequencies") or []:
            row = self.freq_table.rowCount(); self.freq_table.insertRow(row)
            self.freq_table.setItem(row, 0, QTableWidgetItem(f"{freq:.2f}"))
        self.exc_table.setRowCount(0)
        for exc in data.get("excitations") or []:
            row = self.exc_table.rowCount(); self.exc_table.insertRow(row)
            for col, value in enumerate((exc.get("energy_ev"), exc.get("wavelength_nm"), exc.get("oscillator"))):
                self.exc_table.setItem(row, col, QTableWidgetItem(f"{value:.4f}" if value is not None else ""))
        self._draw_spectra()
        thermo = core.thermo(data.get("frequencies") or [], self.molecule) if self.molecule else {}
        if thermo:
            self.thermo_output.setPlainText(
                "\n".join(f"{key}: {value:.6f}" if isinstance(value, float) else f"{key}: {value}" for key, value in thermo.items())
            )
        else:
            self.thermo_output.setPlainText("Thermochemistry needs vibrational frequencies.")

    def _draw_spectra(self) -> None:
        if not MATPLOTLIB_OK or not hasattr(self.spectrum_canvas, "figure"):
            return
        fig = self.spectrum_canvas.figure; fig.clear()
        ax1 = fig.add_subplot(121); ax2 = fig.add_subplot(122)
        freqs = self.output.get("frequencies") or []
        if freqs:
            x, y = core.ir_spectrum(freqs)
            ax1.plot(x, y, color="#2563eb"); ax1.set_title("IR (broadened)"); ax1.set_xlabel("cm⁻¹")
        else:
            ax1.text(0.5, 0.5, "No frequencies", ha="center", va="center"); ax1.axis("off")
        exc = self.output.get("excitations") or []
        if exc:
            x, y = core.uv_spectrum(exc)
            ax2.plot(x, y, color="#dc2626"); ax2.set_title("UV/Vis (broadened)"); ax2.set_xlabel("nm")
        else:
            ax2.text(0.5, 0.5, "No excitations", ha="center", va="center"); ax2.axis("off")
        fig.tight_layout(); self.spectrum_canvas.draw_idle()

    def _use_output_geometry(self) -> None:
        if self.output.get("geometry"):
            self.molecule = self.output["geometry"]
            self._refresh_all()

    # -- cube -------------------------------------------------------------

    def _load_cube(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Load cube", str(Path.home()), "Cube (*.cube);;All files (*)")
        if not path: return
        try:
            self.cube = core.parse_cube(path)
            dims = self.cube["dims"]
            self.cube_index.setRange(0, max(dims) - 1); self.cube_index.setValue(dims[2] // 2)
            self.cube_info.setText(f"{Path(path).name} · grid {dims[0]}×{dims[1]}×{dims[2]} · {len(self.cube['atoms'])} atoms")
            self._draw_cube()
        except Exception as exc:
            QMessageBox.warning(self, "SEQItachi", str(exc))

    def _draw_cube(self) -> None:
        if not MATPLOTLIB_OK or not hasattr(self.cube_canvas, "figure") or not self.cube:
            return
        axis = self.cube_axis.currentText()
        index = self.cube_index.value()
        data = core.cube_slice(self.cube, axis, index)
        fig = self.cube_canvas.figure; fig.clear(); ax = fig.add_subplot(111)
        values = np.asarray(data["values"]); u = np.asarray(data["u"]); v = np.asarray(data["v"])
        maximum = max(abs(float(values.min())), abs(float(values.max())), 1e-12)
        levels = np.linspace(-maximum, maximum, 25)
        contour = ax.contourf(u, v, values, levels=levels, cmap="RdBu_r")
        ax.contour(u, v, values, levels=[0.0], colors="#111827", linewidths=0.5)
        ax.set_aspect("equal"); ax.set_title(f"{axis} = {index}")
        fig.colorbar(contour, ax=ax, fraction=0.046, pad=0.03)
        fig.tight_layout(); self.cube_canvas.draw_idle()

    def _use_cube_atoms(self) -> None:
        if not self.cube:
            return
        self.molecule = core.Molecule([tuple(atom) for atom in self.cube["atoms"]], name="cube geometry")
        self.molecule.infer_bonds()
        self._refresh_all()

    # -- lifecycle --------------------------------------------------------

    def cleanup(self) -> None:
        pass
