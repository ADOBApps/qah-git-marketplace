"""External-tool detection for SEQItachi.

SEQItachi never bundles ORCA, xtb, CREST, Gaussian, Psi4 or Q-Chem. It detects
user-installed executables, stores optional paths, and raises an actionable
error when a requested tool is unavailable.
"""

from __future__ import annotations

import json
import os
import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional

STATE_DIR = Path.home() / "QAH" / "seqitachi"
CONFIG = STATE_DIR / "toolchain.json"

TOOLS: Dict[str, Dict[str, Any]] = {
    "orca": {
        "label": "ORCA",
        "executables": ("orca.exe", "orca"),
        "env": ("QAH_ORCA", "ORCA"),
        "common": (
            r"D:\ProgramData\ORCA_6.1.0\orca.exe",
            r"C:\Program Files\ORCA\orca.exe",
            r"C:\ORCA\orca.exe",
        ),
        "hint": "Install ORCA and set its path in Tools, or put orca.exe on PATH.",
    },
    "xtb": {
        "label": "xtb",
        "executables": ("xtb.exe", "xtb"),
        "env": ("QAH_XTB", "XTB"),
        "common": (
            r"D:\ProgramData\ORCA_6.1.0\xtb-6.7.1pre\xtb.exe",
            r"C:\Program Files\xtb\xtb.exe",
        ),
        "hint": "Install xtb and set its path in Tools, or put xtb.exe on PATH.",
    },
    "crest": {
        "label": "CREST",
        "executables": ("crest.exe", "crest"),
        "env": ("QAH_CREST", "CREST"),
        "common": (r"C:\Program Files\CREST\crest.exe", r"C:\CREST\crest.exe"),
        "hint": "CREST is not bundled. Install CREST (or use WSL/Linux) and set its path in Tools.",
    },
    "gaussian": {
        "label": "Gaussian",
        "executables": ("g16.exe", "g09.exe", "g16", "g09"),
        "env": ("QAH_GAUSSIAN", "GAUSSIAN"),
        "common": (),
        "hint": "Install Gaussian and set g16.exe/g09.exe in Tools, or put it on PATH.",
    },
    "psi4": {
        "label": "Psi4",
        "executables": ("psi4.exe", "psi4"),
        "env": ("QAH_PSI4", "PSI4"),
        "common": (),
        "hint": "Install Psi4 and set psi4.exe in Tools, or put it on PATH.",
    },
    "qchem": {
        "label": "Q-Chem",
        "executables": ("qchem.exe", "qchem"),
        "env": ("QAH_QCHEM", "QCHEM"),
        "common": (),
        "hint": "Install Q-Chem and set qchem.exe in Tools, or put it on PATH.",
    },
}


class ToolNotFoundError(RuntimeError):
    """Raised when an external program is requested but not installed."""


def load_config() -> Dict[str, str]:
    try:
        value = json.loads(CONFIG.read_text(encoding="utf-8"))
        return {str(k): str(v) for k, v in value.items()} if isinstance(value, dict) else {}
    except Exception:
        return {}


def save_config(data: Dict[str, str]) -> None:
    try:
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        CONFIG.write_text(json.dumps(data, indent=2), encoding="utf-8")
    except OSError:
        pass


def set_tool_path(tool: str, path: Optional[str]) -> None:
    data = load_config()
    if path and str(path).strip():
        data[tool] = str(Path(path).expanduser())
    else:
        data.pop(tool, None)
    save_config(data)


def _candidates(spec: Dict[str, Any], configured: Optional[str]) -> List[tuple]:
    out: List[tuple] = []
    if configured:
        out.append((str(Path(configured).expanduser()), "config"))
    for env_key in spec.get("env") or ():
        value = os.environ.get(env_key)
        if value:
            out.append((value, f"env:{env_key}"))
    for name in spec.get("executables") or ():
        found = shutil.which(name)
        if found:
            out.append((found, "PATH"))
    for path in spec.get("common") or ():
        if Path(path).is_file():
            out.append((path, "common"))
    seen = set()
    unique = []
    for path, source in out:
        key = os.path.normcase(os.path.abspath(path))
        if key in seen:
            continue
        seen.add(key)
        unique.append((path, source))
    return unique


def detect_tool(tool: str, configured: Optional[str] = None) -> Dict[str, Any]:
    spec = TOOLS.get(tool)
    if spec is None:
        return {"tool": tool, "label": tool, "found": False, "path": "", "source": "unknown", "hint": "Unknown tool."}
    for path, source in _candidates(spec, configured):
        if Path(path).is_file():
            return {
                "tool": tool,
                "label": spec["label"],
                "found": True,
                "path": str(path),
                "source": source,
                "hint": "",
            }
    return {
        "tool": tool,
        "label": spec["label"],
        "found": False,
        "path": "",
        "source": "missing",
        "hint": spec["hint"],
    }


def detect_all() -> Dict[str, Dict[str, Any]]:
    config = load_config()
    return {tool: detect_tool(tool, config.get(tool)) for tool in TOOLS}


def require_tool(tool: str) -> Dict[str, Any]:
    result = detect_tool(tool, load_config().get(tool))
    if not result["found"]:
        spec = TOOLS.get(tool, {})
        raise ToolNotFoundError(
            f"{spec.get('label', tool)} is not installed or was not found.\n\n"
            f"{spec.get('hint', 'Set the executable path in SEQItachi -> Tools.')}\n\n"
            "SEQItachi does not bundle external quantum-chemistry executables. "
            "No job was started."
        )
    return result


def version_hint(tool: str) -> str:
    info = detect_tool(tool)
    return info["label"] + (" found" if info["found"] else " missing")
