# qah_ws_client/client_core.py
"""Author: Acxel Orozco
QAH WS Client - encrypted remote command console (client side).
"""

from __future__ import annotations

import base64
import json
import os
import platform
import re
import socket
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, Optional

try:
    from . import ws_common
except ImportError:
    try:
        import ws_common  # type: ignore
    except ImportError:
        import importlib.util
        import sys

        _path = Path(__file__).with_name("ws_common.py")
        _spec = importlib.util.spec_from_file_location("qah_ws_common_client", _path)
        if _spec is None or _spec.loader is None:
            raise ImportError(f"Could not load {_path}")
        _module = importlib.util.module_from_spec(_spec)
        sys.modules[_spec.name] = _module
        _spec.loader.exec_module(_module)
        ws_common = _module

ws = ws_common


def qah_home() -> Path:
    override = os.environ.get("QAH_HOME")
    return Path(override).expanduser() if override else Path.home() / "QAH"


def default_root() -> Path:
    override = os.environ.get("QAH_WS_CLIENT_HOME")
    return Path(override).expanduser() if override else qah_home() / "qah_ws_client"


@dataclass
class ClientSettings:
    name: str = ""
    url: str = ""
    fingerprint: str = ""
    server_id: str = ""
    client_id: str = ""
    key: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "url": self.url,
            "fingerprint": self.fingerprint,
            "server_id": self.server_id,
            "client_id": self.client_id,
            "key": self.key,
        }

    @classmethod
    def from_dict(cls, data: Optional[Dict[str, Any]]) -> "ClientSettings":
        data = dict(data or {})
        return cls(
            name=str(data.get("name", "")),
            url=str(data.get("url", "")),
            fingerprint=str(data.get("fingerprint", "")),
            server_id=str(data.get("server_id", "")),
            client_id=str(data.get("client_id", "")),
            key=str(data.get("key", "")),
        )


class ClientSession:
    def __init__(
        self,
        root: Optional[os.PathLike | str] = None,
        *,
        settings: Optional[ClientSettings] = None,
    ):
        self.root = Path(root).expanduser() if root else default_root()
        self.root.mkdir(parents=True, exist_ok=True)
        self.settings_path = self.root / "client.json"
        self.settings = settings or ClientSettings.from_dict(
            ws.read_json(self.settings_path, {})
        )
        if not self.settings.name:
            self.settings.name = platform.node() or "QAH WS Client"
        if not self.settings.client_id:
            self.settings.client_id = ws.new_id()
        self.save()

        self.connection: Optional[ws.WSConnection] = None
        self.session_key: bytes = b""
        self.unlock_required = False
        self.unlocked = False
        self.on_log: Optional[Callable[[str], None]] = None

    def _log(self, text: str) -> None:
        if self.on_log:
            try:
                self.on_log(text)
            except Exception:
                pass

    def save(self) -> None:
        ws.write_private(
            self.settings_path, json.dumps(self.settings.to_dict(), indent=2)
        )

    # -- pairing --------------------------------------------------------
    def pair(self, invite_code: str, name: Optional[str] = None) -> Dict[str, Any]:
        invite = ws.decode_invite(invite_code)
        if name:
            self.settings.name = name
        self.settings.url = invite["url"]
        self.settings.fingerprint = invite["fingerprint"]
        self.settings.server_id = invite["server_id"]
        if not self.settings.client_id:
            self.settings.client_id = ws.new_id()
        nonce = os.urandom(16)
        nonce_text = ws._b64(nonce)
        secret = ws._unb64(invite["secret"])
        client_proof = ws.proof(
            secret, f"pair|{self.settings.client_id}|{nonce_text}"
        )
        connection = ws.WebSocketClient.connect(
            invite["url"], invite["fingerprint"]
        )
        try:
            connection.send_json(
                {
                    "kind": "pair",
                    "client_id": self.settings.client_id,
                    "name": self.settings.name,
                    "nonce": nonce_text,
                    "proof": client_proof,
                }
            )
            response = connection.recv_json()
            if not response or response.get("kind") != "pair_ok":
                error = (response or {}).get("error", "pairing failed")
                raise ws.WSError(str(error))
            server_nonce = ws._unb64(response["server_nonce"])
            base_key = ws.derive_key(
                secret, nonce, server_nonce, b"qah-ws-pair/v1"
            )
            self.settings.key = ws._b64(base_key)
            self.settings.server_id = str(
                response.get("server_id", self.settings.server_id)
            )
            self.unlock_required = bool(response.get("unlock_required"))
            self.save()
            self._log(
                f"Paired with {self.settings.server_id[:8]} at {self.settings.url}."
            )
            return {
                "client_id": self.settings.client_id,
                "server_id": self.settings.server_id,
                "url": self.settings.url,
                "unlock_required": self.unlock_required,
            }
        finally:
            connection.close()

    # -- connection -----------------------------------------------------
    def connect(self) -> bool:
        if not self.settings.key:
            raise ws.WSError("Pair with the server first.")
        if not self.settings.fingerprint:
            raise ws.WSError("The server certificate fingerprint is missing; pair again.")
        self.close()
        connection = ws.WebSocketClient.connect(
            self.settings.url, self.settings.fingerprint
        )
        try:
            connection.sock.settimeout(700)
            nonce = os.urandom(16)
            nonce_text = ws._b64(nonce)
            base_key = ws._unb64(self.settings.key)
            hello_proof = ws.proof(
                base_key, f"hello|{self.settings.client_id}|{nonce_text}"
            )
            connection.send_json(
                {
                    "kind": "hello",
                    "client_id": self.settings.client_id,
                    "nonce": nonce_text,
                    "proof": hello_proof,
                }
            )
            response = connection.recv_json()
            if not response or response.get("kind") != "hello_ok":
                error = (response or {}).get("error", "authentication failed")
                raise ws.WSError(str(error))
            server_nonce = ws._unb64(response["server_nonce"])
            self.session_key = ws.derive_key(
                base_key, nonce, server_nonce, b"qah-ws-session/v1"
            )
            self.unlock_required = bool(response.get("unlock_required"))
            self.unlocked = False
            self.connection = connection
            self._log(f"Connected to {self.settings.url}.")
            return True
        except Exception:
            connection.close()
            raise

    def close(self) -> None:
        if self.connection is not None:
            try:
                self.connection.close()
            except Exception:
                pass
            self.connection = None
        self.session_key = b""
        self.unlocked = False

    @property
    def connected(self) -> bool:
        return self.connection is not None and not self.connection.closed

    # -- encrypted messages ---------------------------------------------
    def _send_secure(self, kind: str, payload: Dict[str, Any]) -> str:
        if not self.connected or not self.session_key:
            raise ws.WSError("Not connected.")
        message_id = ws.new_id()
        timestamp = ws.now()
        aad = {
            "v": ws.PROTOCOL_VERSION,
            "kind": kind,
            "id": message_id,
            "ts": timestamp,
            "from": self.settings.client_id,
            "to": self.settings.server_id,
        }
        nonce, ciphertext = ws.seal(self.session_key, payload, aad)
        self.connection.send_json(
            {**aad, "nonce": nonce, "ciphertext": ciphertext}
        )
        return message_id

    def unlock(self, password: str) -> None:
        message_id = self._send_secure("unlock", {"password": password})
        while True:
            message = self.connection.recv_json()
            if message is None:
                raise ws.WSError("Server closed the connection.")
            kind = message.get("kind")
            if kind == "ping":
                continue
            payload = ws.unseal(self.session_key, message)
            if kind == "unlock_ok":
                self.unlocked = True
                self._log("Permanent auto-approve unlocked for this session.")
                return
            if kind == "error":
                raise ws.WSError(str(payload.get("error", "unlock failed")))
            if kind not in ("unlock_ok", "error"):
                # Commands are not expected before unlock in this UI.
                continue

    def execute(
        self,
        command: str,
        *,
        cwd: Optional[str] = None,
        timeout: int = 120,
        on_start: Optional[Callable[[Dict[str, Any]], None]] = None,
        on_stdout: Optional[Callable[[bytes], None]] = None,
        on_stderr: Optional[Callable[[bytes], None]] = None,
    ) -> Dict[str, Any]:
        if not self.connected:
            self.connect()
        exec_id = self._send_secure(
            "exec",
            {
                "command": command,
                # Empty means "use the server user's home". Never send the
                # client's own home path, which may not exist on the server.
                "cwd": str(cwd) if cwd else "",
                "timeout": max(1, min(int(timeout), 600)),
            },
        )
        try:
            if on_start:
                on_start({"id": exec_id, "command": command})
            while True:
                message = self.connection.recv_json()
                if message is None:
                    raise ws.WSError("Server closed the connection.")
                kind = message.get("kind")
                if kind == "ping":
                    continue
                payload = ws.unseal(self.session_key, message)
                if kind == "stdout":
                    data = base64.b64decode(payload.get("data", ""))
                    if on_stdout:
                        on_stdout(data)
                elif kind == "stderr":
                    data = base64.b64decode(payload.get("data", ""))
                    if on_stderr:
                        on_stderr(data)
                elif kind == "exit":
                    return payload
                elif kind == "error":
                    raise ws.WSError(str(payload.get("error", "remote error")))
                # exec_start is informational
        finally:
            pass

    def cancel(self, exec_id: str) -> None:
        if self.connected:
            self._send_secure("cancel", {"id": exec_id})


def decode_output(data: bytes) -> str:
    return data.decode("utf-8", "replace")
