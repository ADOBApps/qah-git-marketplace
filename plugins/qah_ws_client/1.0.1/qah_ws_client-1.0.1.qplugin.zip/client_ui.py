# qah_ws_client/client_ui.py
"""PySide6 UI for QAH WS Client."""

from __future__ import annotations

import importlib
import importlib.util
import sys
import traceback
from datetime import datetime
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QObject, QThread, QTimer, Qt, Signal
from PySide6.QtGui import QFont, QFontDatabase, QTextCursor
from PySide6.QtWidgets import (
    QApplication,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QInputDialog,
    QPlainTextEdit,
    QPushButton,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)


def _load_sibling(name: str):
    try:
        return importlib.import_module(f"{__name__}.{name}")
    except ImportError:
        path = Path(__file__).with_name(f"{name}.py")
        spec = importlib.util.spec_from_file_location(f"_qah_ws_client_{name}", path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        return module


core = _load_sibling("client_core")


class _Bridge(QObject):
    log = Signal(str)
    stdout = Signal(object)
    stderr = Signal(object)
    started = Signal(object)


class _Task(QThread):
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, function, parent=None):
        super().__init__(parent)
        self._function = function

    def run(self):
        try:
            self.done.emit(self._function())
        except Exception:
            self.failed.emit(traceback.format_exc())


class ClientWidget(QWidget):
    def __init__(self, plugin):
        super().__init__()
        self.plugin = plugin
        self.client = plugin.client
        self._task: Optional[_Task] = None
        self._exec_id: Optional[str] = None
        self._running = False

        self.bridge = _Bridge(self)
        self.bridge.log.connect(self._log)
        self.bridge.stdout.connect(self._stdout)
        self.bridge.stderr.connect(self._stderr)
        self.bridge.started.connect(self._started)
        self.client.on_log = lambda text: self.bridge.log.emit(text)

        self._build_ui()
        self._load_settings()
        self._refresh_status()

    # -- UI -------------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        header = QHBoxLayout()
        title = QLabel("<b>QAH WS Client</b>")
        title.setFont(QFont("Arial", 14))
        header.addWidget(title)
        self.status_label = QLabel("Disconnected")
        self.status_label.setStyleSheet("color: #6c757d;")
        header.addWidget(self.status_label, 1)
        layout.addLayout(header)

        warning = QLabel(
            "Remote command execution. Connect only to servers you control and "
            "keep the pairing invite private."
        )
        warning.setStyleSheet("color: #b91c1c;")
        warning.setWordWrap(True)
        layout.addWidget(warning)

        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, 1)
        self._build_connection_tab()
        self._build_console_tab()
        self._build_settings_tab()

        self.activity = QPlainTextEdit()
        self.activity.setReadOnly(True)
        self.activity.setMaximumHeight(110)
        self.activity.setFont(_mono_font())
        layout.addWidget(self.activity)

    def _build_connection_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        form = QFormLayout()
        self.url_label = QLabel("not configured")
        self.url_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.fingerprint_label = QLabel("")
        self.fingerprint_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.fingerprint_label.setWordWrap(True)
        self.client_id_label = QLabel("")
        self.client_id_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        form.addRow("Server:", self.url_label)
        form.addRow("Fingerprint:", self.fingerprint_label)
        form.addRow("Client id:", self.client_id_label)
        layout.addLayout(form)

        layout.addWidget(QLabel("Pairing invite:"))
        self.invite_text = QPlainTextEdit()
        self.invite_text.setFont(_mono_font())
        self.invite_text.setPlaceholderText("QAHWS1:...")
        self.invite_text.setMaximumHeight(120)
        layout.addWidget(self.invite_text)

        row = QHBoxLayout()
        pair = QPushButton("Pair")
        pair.clicked.connect(self._pair)
        row.addWidget(pair)
        self.connect_button = QPushButton("Connect")
        self.connect_button.clicked.connect(self._connect)
        row.addWidget(self.connect_button)
        self.disconnect_button = QPushButton("Disconnect")
        self.disconnect_button.clicked.connect(self._disconnect)
        row.addWidget(self.disconnect_button)
        row.addStretch(1)
        layout.addLayout(row)
        layout.addStretch(1)
        self.tabs.addTab(tab, "Connection")

    def _build_console_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        self.output = QPlainTextEdit()
        self.output.setReadOnly(True)
        self.output.setFont(_mono_font())
        self.output.setPlaceholderText("Remote output appears here.")
        layout.addWidget(self.output, 1)

        cwd_row = QHBoxLayout()
        cwd_row.addWidget(QLabel("Working dir:"))
        self.cwd_edit = QLineEdit()
        self.cwd_edit.setPlaceholderText("blank = server user's home")
        cwd_row.addWidget(self.cwd_edit, 1)
        layout.addLayout(cwd_row)

        row = QHBoxLayout()
        row.addWidget(QLabel(">"))
        self.command = QLineEdit()
        self.command.setPlaceholderText("command to run on the server")
        self.command.returnPressed.connect(self._run)
        row.addWidget(self.command, 1)
        self.run_button = QPushButton("Run")
        self.run_button.clicked.connect(self._run)
        row.addWidget(self.run_button)
        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.clicked.connect(self._cancel)
        self.cancel_button.setEnabled(False)
        row.addWidget(self.cancel_button)
        layout.addLayout(row)
        self.exit_label = QLabel("")
        self.exit_label.setStyleSheet("color: #6c757d;")
        layout.addWidget(self.exit_label)
        self.tabs.addTab(tab, "Console")

    def _build_settings_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        form = QFormLayout()
        self.name_edit = QLineEdit()
        form.addRow("Client name:", self.name_edit)
        layout.addLayout(form)
        row = QHBoxLayout()
        save = QPushButton("Save")
        save.clicked.connect(self._save_settings)
        row.addWidget(save)
        clear = QPushButton("Clear pairing")
        clear.clicked.connect(self._clear_pairing)
        row.addWidget(clear)
        row.addStretch(1)
        layout.addLayout(row)
        self.settings_info = QLabel("")
        self.settings_info.setWordWrap(True)
        self.settings_info.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(self.settings_info)
        layout.addStretch(1)
        self.tabs.addTab(tab, "Settings")

    # -- state ----------------------------------------------------------
    def _load_settings(self):
        self.name_edit.setText(self.client.settings.name)
        self._refresh_status()

    def _refresh_status(self):
        s = self.client.settings
        self.url_label.setText(s.url or "not configured")
        self.fingerprint_label.setText(s.fingerprint[:32] + ("..." if len(s.fingerprint) > 32 else ""))
        self.client_id_label.setText(s.client_id)
        self.connect_button.setEnabled(bool(s.key) and not self.client.connected)
        self.disconnect_button.setEnabled(self.client.connected)
        self.status_label.setText("Connected" if self.client.connected else "Disconnected")
        self.settings_info.setText(
            f"Settings: {self.client.settings_path}<br>"
            f"Server id: {s.server_id or '-'}<br>"
            f"Pairing key stored: {'yes' if s.key else 'no'}"
        )

    # -- pairing / connection -------------------------------------------
    def _pair(self):
        code = self.invite_text.toPlainText().strip()
        if not code:
            QMessageBox.warning(self, "No invite", "Paste a QAHWS1 invite first.")
            return
        name = self.name_edit.text().strip() or self.client.settings.name

        def operation():
            return self.client.pair(code, name)

        def done(result):
            self._log(f"Paired with {result['server_id'][:8]}.")
            self.invite_text.clear()
            self._refresh_status()
            QTimer.singleShot(50, self._connect)

        self._start("Pairing...", operation, done)

    def _connect(self):
        if not self.client.settings.key:
            QMessageBox.information(self, "Not paired", "Pair with an invite first.")
            return

        def operation():
            self.client.connect()
            return self.client.unlock_required

        def done(unlock_required):
            self._refresh_status()
            self._log("Connected.")
            if unlock_required:
                QTimer.singleShot(50, self._prompt_unlock)
            else:
                self._log("Timed/off policy: the server handles auto-approve or prompts.")

        self._start("Connecting...", operation, done)

    def _prompt_unlock(self):
        password, ok = QInputDialog.getText(
            self,
            "Permanent auto-approve",
            "Server password for this session:",
            QLineEdit.Password,
        )
        if not ok:
            self._log("Connected without unlocking permanent auto-approve.")
            return

        def operation():
            self.client.unlock(password)
            return True

        def done(_result):
            self._log("Permanent auto-approve unlocked for this session.")

        self._start("Unlocking...", operation, done)

    def _disconnect(self):
        self.client.close()
        self._refresh_status()
        self._log("Disconnected.")

    # -- execution ------------------------------------------------------
    def _run(self):
        command = self.command.text().strip()
        if not command:
            return
        if not self.client.connected:
            QMessageBox.information(self, "Not connected", "Connect first.")
            return
        self._running = True
        self.run_button.setEnabled(False)
        self.cancel_button.setEnabled(True)
        self.exit_label.setText("running...")
        self._log(f"> {command}")

        def on_start(info):
            self._exec_id = info.get("id")
            self.bridge.started.emit(info)

        def operation():
            return self.client.execute(
                command,
                cwd=self.cwd_edit.text().strip() or None,
                timeout=300,
                on_start=on_start,
                on_stdout=lambda data: self.bridge.stdout.emit(data),
                on_stderr=lambda data: self.bridge.stderr.emit(data),
            )

        def done(result):
            self._running = False
            self.run_button.setEnabled(True)
            self.cancel_button.setEnabled(False)
            code = result.get("code")
            self.exit_label.setText(
                f"exit {code} · {result.get('duration')}s · "
                f"{result.get('bytes')} bytes"
                + (" · truncated" if result.get("truncated") else "")
            )
            self._log(f"exit {code} in {result.get('duration')}s")
            self.command.selectAll()

        self._start("Running...", operation, done, quiet=True)

    def _cancel(self):
        if self._exec_id:
            try:
                self.client.cancel(self._exec_id)
                self._log("Cancel requested.")
            except Exception as exc:
                self._log(f"Cancel failed: {exc}")

    def _started(self, info):
        self._exec_id = info.get("id")

    def _stdout(self, data):
        text = core.decode_output(bytes(data))
        self.output.moveCursor(QTextCursor.End)
        self.output.insertPlainText(text)
        bar = self.output.verticalScrollBar()
        bar.setValue(bar.maximum())

    def _stderr(self, data):
        text = core.decode_output(bytes(data))
        self.output.moveCursor(QTextCursor.End)
        self.output.insertPlainText(text)
        bar = self.output.verticalScrollBar()
        bar.setValue(bar.maximum())

    # -- settings -------------------------------------------------------
    def _save_settings(self):
        self.client.settings.name = self.name_edit.text().strip() or self.client.settings.name
        self.client.save()
        self._refresh_status()
        self._log("Client name saved.")

    def _clear_pairing(self):
        answer = QMessageBox.question(
            self,
            "Clear pairing",
            "Remove the stored server URL, fingerprint and pairing key?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return
        self.client.close()
        s = self.client.settings
        s.url = ""
        s.fingerprint = ""
        s.server_id = ""
        s.key = ""
        self.client.save()
        self._refresh_status()
        self._log("Pairing cleared.")

    # -- threading / log ------------------------------------------------
    def _start(self, label, function, on_done, *, quiet: bool = False):
        if self._task is not None and self._task.isRunning():
            if not quiet:
                QMessageBox.information(self, "Busy", "Another operation is running.")
            return
        if not quiet:
            self._log(label)
        task = _Task(function, self)
        task.done.connect(on_done)
        task.failed.connect(lambda text: self._on_failed(text, quiet=quiet))
        task.finished.connect(self._on_finished)
        self._task = task
        task.start()

    def _on_finished(self):
        if self._task is not None:
            self._task.deleteLater()
            self._task = None

    def _on_failed(self, text, *, quiet: bool = False):
        self._running = False
        self.run_button.setEnabled(True)
        self.cancel_button.setEnabled(False)
        self.exit_label.setText("error / cancelled")
        self._log("[Error] " + text)
        if not quiet:
            QMessageBox.critical(self, "QAH WS Client", "See the activity log.")

    def _log(self, text):
        stamp = datetime.now().strftime("%H:%M:%S")
        for index, line in enumerate(str(text).splitlines() or [""]):
            prefix = f"[{stamp}] " if index == 0 else "           "
            self.activity.appendPlainText(prefix + line)
        bar = self.activity.verticalScrollBar()
        bar.setValue(bar.maximum())

    def cleanup(self):
        self.client.close()
        task = self._task
        if task is not None and task.isRunning():
            task.setParent(None)
            task.finished.connect(task.deleteLater)
            self._task = None


def _mono_font() -> QFont:
    try:
        font = QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont)
    except Exception:
        font = QFontDatabase.systemFont(QFontDatabase.FixedFont)
    font.setPointSize(10)
    return font
