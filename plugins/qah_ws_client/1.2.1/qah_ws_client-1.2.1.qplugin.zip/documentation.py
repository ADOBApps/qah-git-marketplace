# qah_ws_server/documentation.py
"""Offline documentation shown in the QAH WS Documentation tab.

The same guide is shipped with QAH WS Server and QAH WS Client so both sides
describe the same setup and security model.
"""

from __future__ import annotations

from textwrap import dedent


DOCS_HTML = dedent(
    """
    <html>
    <head>
    <style>
      body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 10pt; color: #1f2937; }
      h1 { font-size: 17pt; color: #0f172a; margin-bottom: 2px; }
      h2 { font-size: 12.5pt; color: #1d4ed8; margin-top: 18px; margin-bottom: 4px; }
      h3 { font-size: 11pt; color: #111827; margin-top: 12px; margin-bottom: 3px; }
      p, li { line-height: 1.35; }
      code { background: #f3f4f6; padding: 1px 3px; }
      pre { background: #f3f4f6; padding: 8px; border: 1px solid #e5e7eb; }
      .warn { color: #b91c1c; font-weight: bold; }
      .note { color: #92400e; }
      .muted { color: #6b7280; }
      ul { margin-top: 4px; }
      table { border-collapse: collapse; margin-top: 6px; }
      th, td { border: 1px solid #d1d5db; padding: 5px 8px; text-align: left; }
      th { background: #f3f4f6; }
    </style>
    </head>
    <body>

    <h1>QAH WS Remote Access Guide</h1>
    <p class="muted">Applies to QAH WS Server and QAH WS Client 1.2.0 and later.</p>

    <p>
      QAH WS is an encrypted <b>remote command console</b>, not a full SSH or
      desktop session. The server listens for WSS connections and streams
      stdout/stderr back to a paired client. This guide explains how to reach
      the server from another network without an SSH tunnel.
    </p>

    <p class="warn">
      A paired client can run commands with the server user's Windows account.
      Treat the pairing invite and server password like passwords.
    </p>

    <h2>1. Two-minute checklist</h2>
    <ul>
      <li>Both computers have QAH and the matching QAH WS plugins installed.</li>
      <li>Choose a transport: <b>Tailscale</b> (recommended), same LAN, or a public tunnel.</li>
      <li>Start QAH WS Server only while you need it.</li>
      <li>Create a fresh pairing invite and send it through a trusted channel.</li>
      <li>Pair the client, then connect and run a harmless test command.</li>
      <li>Stop the server when finished.</li>
    </ul>

    <h2>2. Tailscale (recommended for your own computers)</h2>
    <p>
      Tailscale creates a private WireGuard network between your devices. It
      works behind NAT and CGNAT, needs no port forwarding, and does not expose
      QAH WS to the public internet. The existing self-signed certificate and
      fingerprint pinning continue to work because QAH WS sees a direct TLS
      connection over the tailnet.
    </p>

    <h3>On the server computer</h3>
    <ol>
      <li>Install Tailscale from <b>tailscale.com/download</b> and sign in.</li>
      <li>Open a terminal and find the tailnet address:
        <pre>tailscale ip -4</pre>
        It looks like <code>100.x.y.z</code>. The MagicDNS name is usually
        <code>mypc.tailXXXX.ts.net</code>.
      </li>
      <li>In <b>QAH WS Server &rarr; Settings</b>:
        <ul>
          <li><b>Bind address:</b> <code>0.0.0.0</code> or the Tailscale <code>100.x.y.z</code>.</li>
          <li><b>Port:</b> <code>45900</code> (or your chosen port).</li>
          <li><b>Public host:</b> <code>mypc.tailXXXX.ts.net:45900</code> or
              <code>100.x.y.z:45900</code>.</li>
        </ul>
      </li>
      <li>Allow inbound TCP <code>45900</code> in Windows Firewall. If possible,
          limit the rule to the private/Tailscale network profile.</li>
      <li>Click <b>Start server</b>, then <b>Create pairing invite</b>.</li>
    </ol>

    <h3>On the client computer</h3>
    <ol>
      <li>Install Tailscale and sign in with the <b>same account</b>.</li>
      <li>Open <b>QAH WS Client &rarr; Connection</b>.</li>
      <li>Paste the <code>QAHWS1:...</code> invite and click <b>Pair</b>.</li>
      <li>The client connects automatically. If not, click <b>Connect</b>.</li>
      <li>Run a harmless command such as <code>whoami</code> or <code>hostname</code>.</li>
    </ol>

    <p class="note">
      If the client cannot resolve the MagicDNS name, use the Tailscale
      <code>100.x.y.z</code> address instead. Do not enable Tailscale Funnel
      unless you deliberately want a public endpoint.
    </p>

    <h2>3. Same LAN (no internet)</h2>
    <ol>
      <li>Set <b>Public host</b> to the server's LAN address, for example
          <code>192.168.1.25:45900</code>.</li>
      <li>Allow TCP <code>45900</code> in Windows Firewall for private networks.</li>
      <li>Start the server, create an invite and pair the client.</li>
    </ol>
    <p>
      This is the simplest option when both computers are on the same Wi-Fi or
      Ethernet network. It does not work across the internet.
    </p>

    <h2>4. Public port forwarding (not recommended)</h2>
    <p>
      You can forward TCP <code>45900</code> on the router and set
      <b>Public host</b> to your public DNS name or IP. This exposes the server
      directly to the internet and is the highest-risk option.
    </p>
    <ul>
      <li>Use <b>Permanent password</b> mode with a strong password.</li>
      <li>Keep the server disarmed except during the session.</li>
      <li>Revoke unused clients and review <b>Audit</b> regularly.</li>
      <li>Do not use UPnP to open the port automatically.</li>
    </ul>

    <h2>5. Cloudflare Tunnel (optional, requires a future build)</h2>
    <p>
      Cloudflare Tunnel is free for basic use and supports WebSockets. The
      server makes an outbound connection to Cloudflare, so no inbound port is
      needed. A quick test on the server is:
    </p>
    <pre>cloudflared tunnel --url https://127.0.0.1:45900 --no-tls-verify</pre>
    <p>
      Cloudflare returns a temporary <code>https://...trycloudflare.com</code>
      URL. For a stable name you need a domain managed by Cloudflare and a named
      tunnel.
    </p>
    <p class="warn">
      Not enabled in this build. Cloudflare terminates TLS at its edge and
      presents its own certificate, so the current client-side fingerprint
      pinning would reject it. A future QAH WS release can add a
      <code>tls: "ca"</code> transport mode that verifies the public CA instead.
      The QAH application layer still encrypts command and output frames with
      AES-256-GCM, so Cloudflare would see only ciphertext.
    </p>
    <p>
      If you expose a public hostname, add Cloudflare Access or another
      authentication layer and keep the QAH permanent password enabled.
    </p>

    <h2>6. Relay mode (outbound rendezvous)</h2>
    <p>
      Relay mode makes both the server and client connect <b>outbound</b> to a
      rendezvous relay. Neither side needs an open inbound port. This is
      different from Secure Share's Git relay, which is a store-and-forward
      mailbox on GitHub with 5&ndash;30 second polling; a command console needs
      a live, low-latency pipe.
    </p>
    <p>
      The bundled relay is a <b>dumb TCP byte pipe</b>. It sees only the TLS
      stream. The server certificate fingerprint remains pinned by the client,
      and the existing pairing and AES-256-GCM layers are unchanged. Direct
      mode remains the default, so old settings and invites keep working.
    </p>

    <h3>Run the relay</h3>
    <p>
      Copy <code>relay_server.py</code> from the QAH WS Server plugin folder to
      a machine with a public TCP port (a small VPS or free-tier VM), then run:
    </p>
    <pre>python relay_server.py --host 0.0.0.0 --port 45901</pre>
    <p>
      Open TCP <code>45901</code> in that machine's firewall. The relay has no
      TLS certificate of its own; TLS is carried end-to-end by QAH WS.
    </p>

    <h3>Configure the server</h3>
    <ol>
      <li>Open <b>QAH WS Server &rarr; Relay</b>.</li>
      <li>Set <b>Transport</b> to <b>Relay</b>.</li>
      <li>Enter the relay host and port, for example
          <code>relay.example.com</code> and <code>45901</code>.</li>
      <li>Click <b>Generate new room &amp; token</b>, then <b>Save relay settings</b>.</li>
      <li>Click <b>Start server</b>. The status line should show the room and
          at least one registered slot.</li>
      <li>Click <b>Create pairing invite</b> and send the invite to the client.</li>
    </ol>

    <h3>Configure the client</h3>
    <ol>
      <li>Paste the invite into <b>QAH WS Client &rarr; Connection</b> and
          click <b>Pair</b>.</li>
      <li>The client reads the relay address, room and room token from the
          invite. The <b>Relay</b> tab shows what was imported.</li>
      <li>Connect and run a harmless command such as <code>whoami</code>.</li>
    </ol>

    <p>
      <b>Waiting slots</b> controls how many clients can be paired at the same
      time without waiting for a slot. The relay pairs each client with one
      waiting server slot; after a client disconnects the server re-registers
      automatically.
    </p>

    <p class="note">
      The room token is an admission token for the relay, not the server
      password. Anyone with the invite can attempt to join the room, but the
      QAH pairing secret and certificate pinning still protect the session.
      Generate a new room and token if an invite is exposed, then restart the
      server.
    </p>

    <p class="warn">
      Relay mode does not make the server public. The relay operator can see
      connection metadata (addresses, timing, byte counts) and can drop
      traffic, but cannot read commands or output.
    </p>

    <h2>7. Security checklist</h2>
    <ul>
      <li><b>Server:</b> keep the default <b>disarmed</b> policy.</li>
      <li><b>Timed arm:</b> use it only for the session, then click <b>Disarm now</b>.</li>
      <li><b>Permanent mode:</b> set a strong server password before exposing the server.</li>
      <li><b>Clients:</b> remove a client to revoke its key immediately.</li>
      <li><b>Invites:</b> single-use, expire after one hour. Send them through a trusted channel.</li>
      <li><b>Audit:</b> review <code>audit.jsonl</code> for unexpected commands.</li>
      <li><b>Exposure:</b> prefer Tailscale; do not leave a public port open.</li>
      <li><b>Destructive guard:</b> commands such as <code>format</code>,
          <code>diskpart</code> and <code>shutdown</code> always require approval.</li>
    </ul>

    <h2>8. Troubleshooting</h2>
    <table>
      <tr><th>Symptom</th><th>What to check</th></tr>
      <tr>
        <td>Client cannot connect</td>
        <td>Is the server running? Is the port allowed by Windows Firewall?
            Does <b>Public host</b> match the address the client uses? Is
            Tailscale up on both machines?</td>
      </tr>
      <tr>
        <td>Fingerprint mismatch</td>
        <td>The invite belongs to a different certificate. Create a new invite
            after the server certificate changes.</td>
      </tr>
      <tr>
        <td>Invalid or expired invite</td>
        <td>Invites are single-use and expire after one hour. Create a new one.</td>
      </tr>
      <tr>
        <td>Authentication failed</td>
        <td>The client was removed or its pairing key was cleared. Pair again.</td>
      </tr>
      <tr>
        <td>Password rejected</td>
        <td>Permanent mode uses the server's current password. Ask the server
            operator to reset it.</td>
      </tr>
      <tr>
        <td>Command denied</td>
        <td>The server is disarmed, the client is not unlocked, or the command
            is blocked by the destructive-command guard.</td>
      </tr>
      <tr>
        <td>Connection drops</td>
        <td>The server was stopped, the firewall changed, the network roamed,
            or the certificate was replaced.</td>
      </tr>
      <tr>
        <td>Relay: server cannot register</td>
        <td>Is <code>relay_server.py</code> running? Is TCP <code>45901</code>
            open? Does the relay host/port match? Check the activity log for
            the retry message.</td>
      </tr>
      <tr>
        <td>Relay: no server slot available</td>
        <td>The server is not running, all waiting slots are in use, or the
            room/token changed. Increase <b>Waiting slots</b>, stop/start the
            server, or create a new invite.</td>
      </tr>
      <tr>
        <td>Relay: invalid room token</td>
        <td>The invite belongs to an older room/token. Generate a new room and
            token, restart the server, and pair again.</td>
      </tr>
      <tr>
        <td>No output</td>
        <td>Many programs buffer when stdout is a pipe. Use non-interactive
            flags; full-screen programs and password prompts need a real PTY.</td>
      </tr>
    </table>

    <h2>9. Data files</h2>
    <p>Server:</p>
    <pre>%USERPROFILE%\\QAH\\qah_ws_server\\
    cert.pem          self-signed certificate
    key.pem           private key
    settings.json     bind/port/public host, policy, password hash
    clients.json      paired clients and derived keys
    pending.json      unused invites
    audit.jsonl       command audit log</pre>
    <p>Client:</p>
    <pre>%USERPROFILE%\\QAH\\qah_ws_client\\client.json
    server URL, certificate fingerprint, client id, pairing key</pre>

    <h2>10. What the invite contains</h2>
    <p>
      A <code>QAHWS1:...</code> invite contains the server URL, server id,
      certificate fingerprint and a one-time pairing secret. Anyone who has the
      invite can attempt to pair until it expires, so treat it as a bearer
      secret. The invite does <b>not</b> contain the server password.
    </p>

    <p class="muted">
      For the full text version, open <code>README.md</code> in the plugin
      folder. This tab is generated locally and works offline.
    </p>

    </body>
    </html>
    """
)


def docs_html() -> str:
    """Return the documentation HTML."""
    return DOCS_HTML
