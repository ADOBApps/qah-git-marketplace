# qah_ws_server/ws_common.py
"""
Author: Acxel Orozco
Shared WebSocket/TLS/crypto helpers for QAH WS Server and QAH WS Client.

Identical copies live in both plugin projects. Pure standard library plus
`cryptography` (bundled with QAH).

This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import socket
import ssl
import struct
import threading
import time
import urllib.parse
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Tuple

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.x509.oid import NameOID

APP_TAG = "qah-ws"
PROTOCOL_VERSION = 1
INVITE_PREFIX = "QAHWS1:"
DEFAULT_PORT = 45900
DEFAULT_RELAY_PORT = 45901
MAX_FRAME_BYTES = 8 * 1024 * 1024
MAX_COMMAND_CHARS = 8192
MAX_OUTPUT_BYTES = 16 * 1024 * 1024
WS_MAGIC = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"


class WSError(RuntimeError):
    """WebSocket, TLS or protocol error."""


# ---------------------------------------------------------------------------
# Certificates
# ---------------------------------------------------------------------------


def ensure_certificate(cert_path: Path, key_path: Path) -> str:
    """Create a self-signed certificate if missing. Returns SHA-256 fingerprint."""
    cert_path.parent.mkdir(parents=True, exist_ok=True)
    if cert_path.is_file() and key_path.is_file():
        try:
            return fingerprint_pem(cert_path.read_bytes())
        except Exception:
            pass
    key = ec.generate_private_key(ec.SECP256R1())
    subject = issuer = x509.Name(
        [
            x509.NameAttribute(NameOID.COMMON_NAME, "QAH WS Server"),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Quantum Analysis Helper"),
        ]
    )
    now = datetime.now(timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - timedelta(days=1))
        .not_valid_after(now + timedelta(days=3650))
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .sign(key, hashes.SHA256())
    )
    key_path.write_bytes(
        key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8,
            serialization.NoEncryption(),
        )
    )
    cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    if os.name != "nt":
        try:
            key_path.chmod(0o600)
            cert_path.chmod(0o644)
        except OSError:
            pass
    return fingerprint_der(cert.public_bytes(serialization.Encoding.DER))


def fingerprint_der(der: bytes) -> str:
    return hashlib.sha256(der).hexdigest()


def fingerprint_pem(pem: bytes) -> str:
    cert = x509.load_pem_x509_certificate(pem)
    return fingerprint_der(cert.public_bytes(serialization.Encoding.DER))


def server_context(cert_path: Path, key_path: Path) -> ssl.SSLContext:
    """Build the TLS server context used by direct and relay modes."""
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(str(cert_path), str(key_path))
    return context


# ---------------------------------------------------------------------------
# Crypto / invite helpers
# ---------------------------------------------------------------------------


def derive_key(secret: bytes, client_nonce: bytes, server_nonce: bytes, info: bytes) -> bytes:
    return HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=client_nonce + server_nonce,
        info=info,
    ).derive(secret)


def seal(key: bytes, payload: Dict[str, Any], aad: Dict[str, Any]) -> Tuple[str, str]:
    nonce = os.urandom(12)
    plaintext = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    ciphertext = AESGCM(key).encrypt(nonce, plaintext, _canonical(aad))
    return _b64(nonce), _b64(ciphertext)


def unseal(key: bytes, envelope: Dict[str, Any]) -> Dict[str, Any]:
    aad = {
        "v": envelope.get("v"),
        "kind": envelope.get("kind"),
        "id": envelope.get("id"),
        "ts": envelope.get("ts"),
        "from": envelope.get("from"),
        "to": envelope.get("to"),
    }
    try:
        plaintext = AESGCM(key).decrypt(
            _unb64(envelope["nonce"]),
            _unb64(envelope["ciphertext"]),
            _canonical(aad),
        )
    except Exception as exc:
        raise WSError("Message authentication failed.") from exc
    try:
        payload = json.loads(plaintext.decode("utf-8"))
    except Exception as exc:
        raise WSError("Message payload is not JSON.") from exc
    if not isinstance(payload, dict):
        raise WSError("Message payload is not an object.")
    return payload


def _canonical(data: Dict[str, Any]) -> bytes:
    return json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def _unb64(text: str) -> bytes:
    return base64.b64decode(str(text).encode("ascii"))


def proof(key: bytes, text: str) -> str:
    return hmac.new(key, text.encode("utf-8"), hashlib.sha256).hexdigest()


def check_proof(key: bytes, text: str, value: str) -> bool:
    return hmac.compare_digest(proof(key, text), str(value))


def encode_invite(invite: Dict[str, Any]) -> str:
    raw = json.dumps(invite, separators=(",", ":")).encode("utf-8")
    return INVITE_PREFIX + base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def decode_invite(code: str) -> Dict[str, Any]:
    text = "".join(str(code).split())
    if not text.startswith(INVITE_PREFIX):
        raise WSError("This is not a QAH WS pairing invite.")
    body = text[len(INVITE_PREFIX) :]
    body += "=" * (-len(body) % 4)
    try:
        data = json.loads(base64.urlsafe_b64decode(body.encode("ascii")))
    except Exception as exc:
        raise WSError("The pairing invite is corrupt.") from exc
    if not isinstance(data, dict) or data.get("app") != APP_TAG:
        raise WSError("The pairing invite belongs to another application.")
    if int(data.get("v", 0)) != PROTOCOL_VERSION or data.get("kind") != "invite":
        raise WSError("Unsupported pairing invite.")
    if int(data.get("expires", 0)) < int(time.time()):
        raise WSError("The pairing invite has expired.")
    for key in ("server_id", "url", "fingerprint", "secret"):
        if not data.get(key):
            raise WSError(f"The pairing invite is missing {key!r}.")
    if not str(data["url"]).startswith("wss://"):
        raise WSError("The pairing invite is not a WSS URL.")
    if not re.fullmatch(r"[A-Za-z0-9_-]{8,64}", str(data["server_id"])):
        raise WSError("The pairing invite has an invalid server id.")
    return data


def hash_password(password: str, salt: Optional[bytes] = None) -> Tuple[str, str]:
    salt = salt or os.urandom(16)
    digest = hashlib.scrypt(
        password.encode("utf-8"), salt=salt, n=2**14, r=8, p=1, dklen=32
    )
    return _b64(salt), _b64(digest)


def verify_password(password: str, salt_b64: str, hash_b64: str) -> bool:
    try:
        salt = _unb64(salt_b64)
        expected = _unb64(hash_b64)
        actual = hashlib.scrypt(
            password.encode("utf-8"), salt=salt, n=2**14, r=8, p=1, dklen=32
        )
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False


DANGEROUS_PATTERNS = [
    r"\bformat(\.com)?\b",
    r"\bdiskpart\b",
    r"\bbcdedit\b",
    r"\bshutdown\b",
    r"\breboot\b",
    r"\brm\s+-rf\s+/(\s|$)",
    r"\bdel\s+/[fsq]\b",
    r"\breg\s+delete\b",
    r"\btakeown\b",
    r"\bicacls\b.*\/grant",
    r"powershell(\.exe)?.*-(enc|encodedcommand)\b",
    r"\bcurl\b.*\|\s*(ba)?sh\b",
    r"\bwget\b.*\|\s*(ba)?sh\b",
    r"\bnet\s+user\b",
    r"\bwmic\b.*\bdelete\b",
    r"\bmkfs\b",
    r"\bdd\s+if=.*of=/dev/",
    r"\bchmod\s+777\s+/",
    r"\bpasswd\b",
]
_DANGEROUS = [re.compile(pattern, re.IGNORECASE) for pattern in DANGEROUS_PATTERNS]


def is_dangerous_command(command: str) -> bool:
    text = str(command or "")
    return any(pattern.search(text) for pattern in _DANGEROUS)


# ---------------------------------------------------------------------------
# RFC 6455 WebSocket
# ---------------------------------------------------------------------------


class WSConnection:
    def __init__(self, sock: socket.socket, *, server_side: bool):
        self.sock = sock
        self.server_side = server_side
        self._send_lock = threading.Lock()
        self.closed = False

    def handshake_server(self) -> None:
        request = self._read_http_headers(self.sock)
        lines = request.decode("iso-8859-1", "replace").split("\r\n")
        headers: Dict[str, str] = {}
        for line in lines[1:]:
            if ":" in line:
                name, value = line.split(":", 1)
                headers[name.strip().lower()] = value.strip()
        key = headers.get("sec-websocket-key", "")
        if not key or headers.get("upgrade", "").lower() != "websocket":
            raise WSError("Invalid WebSocket upgrade request.")
        accept = base64.b64encode(
            hashlib.sha1((key + WS_MAGIC).encode("ascii")).digest()
        ).decode("ascii")
        response = (
            "HTTP/1.1 101 Switching Protocols\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Accept: {accept}\r\n"
            "\r\n"
        )
        self.sock.sendall(response.encode("ascii"))

    def handshake_client(self, host: str, path: str = "/") -> None:
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        request = (
            f"GET {path or '/'} HTTP/1.1\r\n"
            f"Host: {host}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n"
            "\r\n"
        )
        self.sock.sendall(request.encode("ascii"))
        response = self._read_http_headers(self.sock)
        text = response.decode("iso-8859-1", "replace")
        if not text.startswith("HTTP/1.1 101"):
            raise WSError(f"WebSocket handshake failed: {text.splitlines()[0] if text else 'empty'}")
        expected = base64.b64encode(
            hashlib.sha1((key + WS_MAGIC).encode("ascii")).digest()
        ).decode("ascii")
        if f"sec-websocket-accept: {expected}".lower() not in text.lower():
            raise WSError("Invalid WebSocket accept value.")

    def _read_http_headers(self, sock: socket.socket) -> bytes:
        data = b""
        while b"\r\n\r\n" not in data:
            chunk = sock.recv(4096)
            if not chunk:
                raise WSError("Connection closed during handshake.")
            data += chunk
            if len(data) > 32768:
                raise WSError("HTTP handshake too large.")
        return data.split(b"\r\n\r\n", 1)[0] + b"\r\n\r\n"

    def send_text(self, text: str) -> None:
        if self.closed:
            raise WSError("WebSocket is closed.")
        payload = text.encode("utf-8")
        if len(payload) > MAX_FRAME_BYTES:
            raise WSError("Frame too large.")
        header = bytearray([0x81])
        mask = not self.server_side
        mask_bit = 0x80 if mask else 0
        length = len(payload)
        if length < 126:
            header.append(mask_bit | length)
        elif length < 65536:
            header.append(mask_bit | 126)
            header += struct.pack("!H", length)
        else:
            header.append(mask_bit | 127)
            header += struct.pack("!Q", length)
        if mask:
            mask_key = os.urandom(4)
            header += mask_key
            payload = bytes(b ^ mask_key[i % 4] for i, b in enumerate(payload))
        with self._send_lock:
            self.sock.sendall(bytes(header) + payload)

    def send_json(self, payload: Dict[str, Any]) -> None:
        self.send_text(json.dumps(payload, separators=(",", ":")))

    def recv_json(self) -> Optional[Dict[str, Any]]:
        text = self.recv_text()
        if text is None:
            return None
        try:
            data = json.loads(text)
        except Exception as exc:
            raise WSError("Received invalid JSON.") from exc
        if not isinstance(data, dict):
            raise WSError("Received JSON is not an object.")
        return data

    def recv_text(self) -> Optional[str]:
        fragments = bytearray()
        message_opcode: Optional[int] = None
        while True:
            header = self._recv_exact(2)
            b1, b2 = header[0], header[1]
            fin = bool(b1 & 0x80)
            opcode = b1 & 0x0F
            masked = bool(b2 & 0x80)
            length = b2 & 0x7F
            if length == 126:
                length = struct.unpack("!H", self._recv_exact(2))[0]
            elif length == 127:
                length = struct.unpack("!Q", self._recv_exact(8))[0]
            if length > MAX_FRAME_BYTES:
                raise WSError("Frame too large.")
            mask_key = self._recv_exact(4) if masked else b""
            payload = self._recv_exact(length)
            if masked:
                payload = bytes(b ^ mask_key[i % 4] for i, b in enumerate(payload))

            if opcode == 0x8:
                self._send_control(0x8, b"")
                self.closed = True
                return None
            if opcode == 0x9:
                self._send_control(0xA, payload)
                continue
            if opcode == 0xA:
                continue
            if opcode in (0x1, 0x2):
                if message_opcode is not None:
                    raise WSError("Unexpected new data frame.")
                message_opcode = opcode
                fragments = bytearray(payload)
            elif opcode == 0x0:
                if message_opcode is None:
                    raise WSError("Unexpected continuation frame.")
                fragments += payload
            else:
                raise WSError(f"Unsupported opcode {opcode}.")
            if fin:
                try:
                    return fragments.decode("utf-8")
                except UnicodeDecodeError as exc:
                    raise WSError("Text frame is not UTF-8.") from exc

    def _send_control(self, opcode: int, payload: bytes) -> None:
        frame = bytearray([0x80 | opcode, len(payload)])
        with self._send_lock:
            self.sock.sendall(bytes(frame) + payload)

    def _recv_exact(self, size: int) -> bytes:
        chunks = []
        remaining = size
        while remaining > 0:
            chunk = self.sock.recv(min(remaining, 1024 * 1024))
            if not chunk:
                raise WSError("Connection closed.")
            chunks.append(chunk)
            remaining -= len(chunk)
        return b"".join(chunks)

    def close(self) -> None:
        if self.closed:
            return
        self.closed = True
        try:
            self._send_control(0x8, b"")
        except Exception:
            pass
        try:
            self.sock.close()
        except OSError:
            pass


class WebSocketServer:
    def __init__(
        self,
        host: str,
        port: int,
        cert_path: Path,
        key_path: Path,
        handler: Callable[[WSConnection, Tuple[str, int]], None],
        on_log: Optional[Callable[[str], None]] = None,
    ):
        self.host = host
        self.port = int(port)
        self.cert_path = Path(cert_path)
        self.key_path = Path(key_path)
        self.handler = handler
        self.on_log = on_log or (lambda _text: None)
        self._stop = threading.Event()
        self._server: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None
        self._context: Optional[ssl.SSLContext] = None

    def make_context(self) -> ssl.SSLContext:
        """Create a TLS context without starting the listening socket."""
        self._context = server_context(self.cert_path, self.key_path)
        return self._context

    def handle_socket(
        self,
        raw: socket.socket,
        address: Tuple[str, int],
        context: Optional[ssl.SSLContext] = None,
    ) -> None:
        """Run the TLS + WebSocket server handshake on an already connected socket."""
        self._handle(raw, address, context or self._context)

    def start(self) -> int:
        self._context = self.make_context()
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((self.host, self.port))
        server.listen(8)
        self.port = int(server.getsockname()[1])
        self._server = server
        self._stop.clear()
        self._thread = threading.Thread(target=self._accept_loop, daemon=True)
        self._thread.start()
        self.on_log(f"WSS listening on {self.host}:{self.port}")
        return self.port

    def stop(self) -> None:
        self._stop.set()
        if self._server is not None:
            try:
                self._server.close()
            except OSError:
                pass
            self._server = None
        if self._thread is not None:
            self._thread.join(timeout=2)
            self._thread = None

    def _accept_loop(self) -> None:
        server = self._server
        context = self._context
        if server is None or context is None:
            return
        while not self._stop.is_set():
            try:
                raw, address = server.accept()
            except OSError:
                break
            threading.Thread(
                target=self._handle, args=(raw, address, context), daemon=True
            ).start()

    def _handle(self, raw: socket.socket, address, context: ssl.SSLContext) -> None:
        connection = None
        tls = None
        try:
            raw.settimeout(30)
            tls = context.wrap_socket(raw, server_side=True)
            tls.settimeout(700)
            connection = WSConnection(tls, server_side=True)
            connection.handshake_server()
            self.handler(connection, address)
        except Exception as exc:
            self.on_log(f"Connection from {address[0]} failed: {exc}")
        finally:
            if connection is not None:
                try:
                    connection.close()
                except Exception:
                    pass
            elif tls is not None:
                try:
                    tls.close()
                except OSError:
                    pass
            try:
                raw.close()
            except OSError:
                pass


def _client_tls_connect(
    raw: socket.socket,
    logical_url: str,
    fingerprint: str,
    timeout: float,
) -> WSConnection:
    """Run the TLS + WebSocket client handshake over an existing TCP socket."""
    parsed = urllib.parse.urlparse(logical_url)
    if parsed.scheme != "wss" or not parsed.hostname:
        raise WSError("The URL must be wss://host:port.")
    host = parsed.hostname
    path = parsed.path or "/"
    if parsed.query:
        path += "?" + parsed.query
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    try:
        tls = context.wrap_socket(raw, server_hostname=host)
        der = tls.getpeercert(binary_form=True)
        actual = fingerprint_der(der or b"")
        if fingerprint and not hmac.compare_digest(
            actual, str(fingerprint).lower()
        ):
            tls.close()
            raise WSError(
                "The server certificate fingerprint does not match the invite."
            )
        tls.settimeout(300)
        connection = WSConnection(tls, server_side=False)
        connection.handshake_client(host, path)
        return connection
    except Exception:
        try:
            raw.close()
        except OSError:
            pass
        raise


class WebSocketClient:
    @staticmethod
    def connect(url: str, fingerprint: str, timeout: float = 15.0) -> WSConnection:
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme != "wss" or not parsed.hostname:
            raise WSError("The URL must be wss://host:port.")
        raw = socket.create_connection(
            (parsed.hostname, parsed.port or 443), timeout=timeout
        )
        raw.settimeout(timeout)
        return _client_tls_connect(raw, url, fingerprint, timeout)


class RelayClient:
    """Connect to a QAH relay room, then run the normal pinned TLS handshake."""

    @staticmethod
    def connect(
        relay: str,
        room: str,
        token: str,
        logical_url: str,
        fingerprint: str,
        timeout: float = 15.0,
    ) -> WSConnection:
        host, port = parse_relay_address(relay)
        if not room:
            raise WSError("The relay room is missing from the invite.")
        if not token:
            raise WSError("The relay token is missing from the invite.")
        deadline = time.monotonic() + min(max(1.0, timeout), 10.0)
        transient = (
            "room not found or server offline",
            "no server slot available",
        )
        while True:
            raw = socket.create_connection((host, port), timeout=timeout)
            raw.settimeout(timeout)
            try:
                send_line(
                    raw,
                    {
                        "role": "client",
                        "room": room,
                        "token": token,
                    },
                )
                reply = recv_json_line(raw)
            except Exception:
                try:
                    raw.close()
                except OSError:
                    pass
                raise
            if reply.get("ok"):
                break
            error = str(
                reply.get("error", "The relay rejected this room.")
            )
            try:
                raw.close()
            except OSError:
                pass
            if error in transient and time.monotonic() < deadline:
                time.sleep(0.4)
                continue
            raise WSError(error)
        raw.settimeout(timeout)
        return _client_tls_connect(raw, logical_url, fingerprint, timeout)


def parse_relay_address(relay: str) -> Tuple[str, int]:
    """Parse host:port, tcp://host:port or relay://host:port."""
    text = str(relay or "").strip()
    if not text:
        raise WSError("The relay address is empty.")
    if "://" not in text:
        text = "tcp://" + text
    parsed = urllib.parse.urlparse(text)
    host = parsed.hostname
    if not host:
        raise WSError("The relay address must be host:port.")
    try:
        port = int(parsed.port or DEFAULT_RELAY_PORT)
    except ValueError as exc:
        raise WSError("The relay port is invalid.") from exc
    if not (1 <= port <= 65535):
        raise WSError("The relay port is out of range.")
    return host, port


def send_line(sock: socket.socket, payload: Dict[str, Any]) -> None:
    body = json.dumps(payload, separators=(",", ":")).encode("utf-8") + b"\n"
    sock.sendall(body)


def recv_line(sock: socket.socket, max_bytes: int = 65536) -> bytes:
    data = bytearray()
    while True:
        chunk = sock.recv(1)
        if not chunk:
            raise WSError("The relay closed the connection during the handshake.")
        data.extend(chunk)
        if chunk == b"\n":
            return bytes(data)
        if len(data) > max_bytes:
            raise WSError("The relay handshake line is too long.")


def recv_json_line(sock: socket.socket) -> Dict[str, Any]:
    raw = recv_line(sock)
    try:
        value = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise WSError("The relay returned an invalid handshake.") from exc
    if not isinstance(value, dict):
        raise WSError("The relay returned an invalid handshake.")
    return value


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------


def new_id() -> str:
    return uuid.uuid4().hex


def now() -> int:
    return int(time.time())


def write_private(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)
    if os.name != "nt":
        try:
            path.chmod(0o600)
        except OSError:
            pass


def read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default
