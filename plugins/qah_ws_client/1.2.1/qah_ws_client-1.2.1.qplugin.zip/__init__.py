# qah_ws_client/__init__.py
"""Author: Acxel Orozco
QAH WS Client - encrypted remote command console for QAH.
"""

from __future__ import annotations

import importlib
import importlib.util
import logging
import sys
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QObject
from PySide6.QtGui import QAction, QIcon
from PySide6.QtWidgets import QWidget

try:
    from plugins.libs.plugin_manager import PluginInfo
except Exception:
    PluginInfo = object  # type: ignore


def _load_sibling(name: str):
    try:
        return importlib.import_module(f"{__name__}.{name}")
    except ImportError:
        path = Path(__file__).with_name(f"{name}.py")
        spec = importlib.util.spec_from_file_location(f"{__name__}_{name}", path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        return module


_core = _load_sibling("client_core")


class QAHWSClient(QObject):
    def __init__(self, plugin_info: PluginInfo):
        super().__init__()
        self.plugin_info = plugin_info
        self.ui_widget: Optional[QWidget] = None
        self.icon: Optional[QIcon] = None
        self.client = None
        try:
            self.client = _core.ClientSession()
        except Exception as exc:
            logging.error("QAH WS Client core could not start: %s", exc)
        icon_path = Path(__file__).parent / "icon.svg"
        if icon_path.is_file():
            self.icon = QIcon(str(icon_path))

    def initialize(self) -> bool:
        return self.client is not None

    def get_widget(self) -> Optional[QWidget]:
        if self.ui_widget is None:
            if self.client is None:
                return None
            try:
                ui = _load_sibling("client_ui")
                self.ui_widget = ui.ClientWidget(self)
            except Exception as exc:
                logging.error("Could not build QAH WS Client UI: %s", exc)
                logging.debug("Traceback", exc_info=True)
                return None
        return self.ui_widget

    def get_menu_actions(self):
        action = QAction("QAH WS Client", self)
        if self.icon is not None:
            action.setIcon(self.icon)
        action.setToolTip("Encrypted remote command console (client)")
        return [action]

    def cleanup(self):
        if self.client is not None:
            try:
                self.client.close()
            except Exception:
                pass
        if self.ui_widget is not None:
            try:
                if hasattr(self.ui_widget, "cleanup"):
                    self.ui_widget.cleanup()
            finally:
                self.ui_widget.deleteLater()
                self.ui_widget = None


Plugin = QAHWSClient
