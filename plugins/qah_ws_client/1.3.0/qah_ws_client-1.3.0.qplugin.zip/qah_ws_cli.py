#!/usr/bin/env python3
"""Headless QAH WS client for scripted/AI-to-AI remote commands.

This is a thin CLI over ``client_core.ClientSession``. It does not import Qt
and can run from the plugin folder or a copied bridge folder.

Examples:
  python qah_ws_cli.py pair --invite-file invite.txt --name windows-agent
  python qah_ws_cli.py status
  python qah_ws_cli.py run "cd ~/benchmark && bash run_benchmark.sh" --timeout 600
  python qah_ws_cli.py run "cat results/pkad2_summary.json" --json

The invite code is as sensitive as a password. Do not paste it into logs.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from client_core import ClientSession, default_root  # noqa: E402


def session_for(root: str | None) -> ClientSession:
    return ClientSession(root=Path(root).expanduser() if root else default_root())


def cmd_pair(args) -> int:
    invite = args.invite or ""
    if args.invite_file:
        invite = Path(args.invite_file).expanduser().read_text(encoding="utf-8").strip()
    if not invite:
        print("Provide --invite or --invite-file.", file=sys.stderr)
        return 2
    session = session_for(args.root)
    result = session.pair(invite, name=args.name or None)
    print(json.dumps(result, indent=2))
    return 0


def cmd_status(args) -> int:
    session = session_for(args.root)
    settings = session.settings
    print(json.dumps({
        "root": str(session.root),
        "name": settings.name,
        "url": settings.url,
        "transport": settings.transport,
        "server_id": settings.server_id,
        "paired": bool(settings.key),
        "connected": session.connected,
    }, indent=2))
    return 0


def cmd_run(args) -> int:
    session = session_for(args.root)
    password = args.password or os.environ.get("QAH_WS_PASSWORD", "")
    if password:
        if not session.connected:
            session.connect()
        session.unlock(password)

    def on_stdout(data: bytes) -> None:
        sys.stdout.write(data.decode("utf-8", "replace"))
        sys.stdout.flush()

    def on_stderr(data: bytes) -> None:
        sys.stderr.write(data.decode("utf-8", "replace"))
        sys.stderr.flush()

    result = session.execute(
        args.command,
        cwd=args.cwd or None,
        timeout=max(1, min(int(args.timeout), 600)),
        on_stdout=on_stdout,
        on_stderr=on_stderr,
    )
    code = int(result.get("code", result.get("exit_code", 0)) or 0)
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(
            f"\nexit {code} · {result.get('duration', '?')}s · "
            f"{result.get('bytes', '?')} bytes",
            file=sys.stderr,
        )
    return 0 if code == 0 else code


def main() -> int:
    parser = argparse.ArgumentParser(description="Headless QAH WS client")
    parser.add_argument("--root", default="", help="Client settings directory")
    sub = parser.add_subparsers(dest="command", required=True)

    pair = sub.add_parser("pair", help="Pair with a QAH WS Server invite")
    pair.add_argument("--invite", default="", help="QAHWS1:... invite code")
    pair.add_argument("--invite-file", default="", help="File containing the invite")
    pair.add_argument("--name", default="qah-ws-cli", help="Client display name")
    pair.set_defaults(func=cmd_pair)

    status = sub.add_parser("status", help="Show saved pairing state")
    status.set_defaults(func=cmd_status)

    run = sub.add_parser("run", aliases=["exec"], help="Run a remote command")
    run.add_argument("command", help="Command to execute on the server")
    run.add_argument("--cwd", default="", help="Server working directory")
    run.add_argument("--timeout", type=int, default=120, help="Seconds (max 600)")
    run.add_argument("--password", default="", help="Server auto-approve password")
    run.add_argument("--json", action="store_true", help="Print the exit payload")
    run.set_defaults(func=cmd_run)

    args = parser.parse_args()
    try:
        return int(args.func(args))
    except KeyboardInterrupt:
        print("cancelled", file=sys.stderr)
        return 130
    except Exception as exc:
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
