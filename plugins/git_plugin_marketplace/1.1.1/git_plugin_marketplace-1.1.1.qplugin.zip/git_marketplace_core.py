# git_plugin_marketplace/git_marketplace_core.py
"""
Author: Acxel Orozco
Git Plugin Marketplace - Qt-free core.

A drop-in alternative to QAH's Firebase Plugin Marketplace that stores the
catalog and plugin ZIPs in a Git repository (GitHub) instead of Firebase:

    index.json                              catalog
    plugins/<id>/manifest.json              canonical manifest
    plugins/<id>/README.md                  optional description
    plugins/<id>/<version>/<id>-<version>.qplugin.zip

Reads work on public repositories without a token. Publishing, deleting and
initialising a repository need a GitHub token with `contents: write`.

This module uses only the Python standard library (requests is used when
available, for its bundled CA certificates inside the QAH bundle).

This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

from __future__ import annotations

import base64
import hashlib
import io
import json
import os
import re
import shutil
import ssl
import stat
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

SCHEMA_VERSION = 1
CATALOG_FILE = "index.json"
PLUGIN_ROOT = "plugins"
DEFAULT_API_BASE = "https://api.github.com"
USER_AGENT = "QAH-Git-Plugin-Marketplace/1.0"
PLUGIN_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
DEFAULT_CACHE_TTL = 300

ENV_CONFIG = "QAH_GIT_MARKETPLACE_CONFIG"
ENV_CACHE = "QAH_GIT_MARKETPLACE_CACHE"
ENV_HOME = "QAH_HOME"
ENV_REPO = "QAH_GIT_MARKETPLACE_REPO"
ENV_BRANCH = "QAH_GIT_MARKETPLACE_BRANCH"
ENV_TOKEN = "QAH_GIT_MARKETPLACE_TOKEN"

_EXCLUDED_DIRS = frozenset(
    {
        ".git",
        ".hg",
        ".svn",
        "__pycache__",
        ".venv",
        "venv",
        "env",
        "node_modules",
        "build",
        "dist",
        "target",
        "tests",
        "test",
        "docs",
        "examples",
        ".idea",
        ".vscode",
        ".pytest_cache",
        ".mypy_cache",
    }
)
_EXCLUDED_SUFFIXES = (
    ".pyc",
    ".pyo",
    ".qplugin.zip",
    ".qah-bak",
    ".swp",
    ".tmp",
)


class MarketplaceError(RuntimeError):
    """Base error for the Git marketplace."""


class AuthError(MarketplaceError):
    """GitHub rejected the credentials or they lack the needed scope."""


class NotFound(MarketplaceError):
    """The repository, branch, file or plugin does not exist."""


class Conflict(MarketplaceError):
    """The branch moved while preparing a commit."""


# ---------------------------------------------------------------------------
# Paths and configuration
# ---------------------------------------------------------------------------


def qah_home() -> Path:
    override = os.environ.get(ENV_HOME)
    if override:
        return Path(override).expanduser()
    return Path.home() / "QAH"


def classic_plugins_dir(create: bool = True) -> Path:
    """QAH's writable classic-plugin directory."""
    try:
        from plugins.libs.plugin_paths import classic_plugins_dir as _dir  # type: ignore

        path = Path(_dir())
    except Exception:
        override = os.environ.get("QAH_PLUGINS_DIR")
        path = (
            Path(override).expanduser()
            if override
            else qah_home() / "plugins" / "python_plugins"
        )
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def legacy_plugins_dir() -> Optional[Path]:
    try:
        from plugins.libs.plugin_paths import legacy_classic_plugins_dir as _dir  # type: ignore

        return Path(_dir())
    except Exception:
        return None


def config_path() -> Path:
    override = os.environ.get(ENV_CONFIG)
    if override:
        return Path(override).expanduser()
    return Path.home() / ".qah" / "git_marketplace.json"


def cache_path() -> Path:
    override = os.environ.get(ENV_CACHE)
    if override:
        return Path(override).expanduser()
    return Path.home() / ".qah" / "git_marketplace_cache.json"


@dataclass
class MarketplaceConfig:
    owner: str = ""
    repo: str = ""
    branch: str = "main"
    token: str = ""
    api_base: str = DEFAULT_API_BASE
    cache_ttl: int = DEFAULT_CACHE_TTL
    name: str = "QAH Git Marketplace"
    description: str = ""

    @property
    def slug(self) -> str:
        return f"{self.owner}/{self.repo}".strip("/")

    @property
    def web_url(self) -> str:
        return f"https://github.com/{self.slug}" if self.owner and self.repo else ""

    def validate(self) -> None:
        if not self.owner or not self.repo:
            raise MarketplaceError(
                "No marketplace repository configured. Open Settings and enter "
                "the GitHub owner and repository."
            )
        if not PLUGIN_ID_RE.match(self.owner):
            raise MarketplaceError(f"Invalid GitHub owner: {self.owner!r}")
        if not PLUGIN_ID_RE.match(self.repo):
            raise MarketplaceError(f"Invalid repository name: {self.repo!r}")
        if not self.branch:
            raise MarketplaceError("The branch must not be empty.")

    def to_dict(self, include_token: bool = True) -> Dict[str, Any]:
        data = {
            "owner": self.owner,
            "repo": self.repo,
            "branch": self.branch,
            "api_base": self.api_base,
            "cache_ttl": int(self.cache_ttl),
            "name": self.name,
            "description": self.description,
        }
        if include_token:
            data["token"] = self.token
        return data

    @classmethod
    def from_dict(cls, data: Optional[Dict[str, Any]]) -> "MarketplaceConfig":
        data = dict(data or {})
        return cls(
            owner=str(data.get("owner", "")).strip(),
            repo=str(data.get("repo", "")).strip(),
            branch=str(data.get("branch", "main")).strip() or "main",
            token=str(data.get("token", "")).strip(),
            api_base=str(data.get("api_base", DEFAULT_API_BASE)).strip()
            or DEFAULT_API_BASE,
            cache_ttl=int(data.get("cache_ttl", DEFAULT_CACHE_TTL) or 0),
            name=str(data.get("name", "QAH Git Marketplace")),
            description=str(data.get("description", "")),
        )

    def with_env(self) -> "MarketplaceConfig":
        """Apply environment overrides (repo, branch, token)."""
        repo = os.environ.get(ENV_REPO, "").strip()
        if repo and "/" in repo:
            owner, name = repo.split("/", 1)
            self.owner, self.repo = owner.strip(), name.strip()
        branch = os.environ.get(ENV_BRANCH, "").strip()
        if branch:
            self.branch = branch
        token = os.environ.get(ENV_TOKEN, "").strip()
        if token:
            self.token = token
        return self


def load_config(
    plugin_config: Optional[Dict[str, Any]] = None,
    *,
    use_file: bool = True,
) -> MarketplaceConfig:
    """Merge manifest defaults, the user config file and environment vars."""
    data: Dict[str, Any] = {}
    if plugin_config:
        # Accept either a flat mapping or {"repository": {...}}.
        repo_cfg = plugin_config.get("repository")
        if isinstance(repo_cfg, dict):
            data.update(repo_cfg)
        data.update(
            {
                key: value
                for key, value in plugin_config.items()
                if key
                in {
                    "owner",
                    "repo",
                    "branch",
                    "token",
                    "api_base",
                    "cache_ttl",
                    "name",
                    "description",
                }
            }
        )
    path = config_path()
    if use_file and path.is_file():
        try:
            data.update(json.loads(path.read_text(encoding="utf-8")))
        except Exception:
            pass
    return MarketplaceConfig.from_dict(data).with_env()


def save_config(config: MarketplaceConfig, *, remember_token: bool = True) -> Path:
    path = config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = config.to_dict(include_token=remember_token)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    os.replace(tmp, path)
    if os.name != "nt":
        try:
            path.chmod(0o600)
        except OSError:
            pass
    return path


def resolve_token(config: MarketplaceConfig, *, use_gh_cli: bool = True) -> str:
    """Token precedence: config, env vars, then `gh auth token`."""
    candidates = (
        config.token,
        os.environ.get(ENV_TOKEN, ""),
        os.environ.get("GITHUB_TOKEN", ""),
        os.environ.get("GH_TOKEN", ""),
    )
    for candidate in candidates:
        if candidate and candidate.strip():
            return candidate.strip()
    if use_gh_cli:
        gh = shutil.which("gh")
        if gh:
            try:
                kwargs: Dict[str, Any] = {}
                if os.name == "nt":
                    kwargs["creationflags"] = getattr(
                        subprocess, "CREATE_NO_WINDOW", 0x08000000
                    )
                completed = subprocess.run(
                    [gh, "auth", "token"],
                    capture_output=True,
                    text=True,
                    timeout=8,
                    **kwargs,
                )
                if completed.returncode == 0 and completed.stdout.strip():
                    return completed.stdout.strip()
            except Exception:
                pass
    return ""


# ---------------------------------------------------------------------------
# Version handling and catalog
# ---------------------------------------------------------------------------


def version_key(value: str) -> Tuple:
    """Sortable key that treats 1.10 > 1.9 and releases > pre-releases."""
    text = str(value or "").strip().lstrip("vV")
    try:
        from packaging.version import Version  # type: ignore

        return (1, Version(text))
    except Exception:
        numbers = [int(part) for part in re.findall(r"\d+", text)][:4]
        base = tuple(numbers + [0] * (4 - len(numbers)))
        is_prerelease = bool(
            re.search(r"(?:a|b|rc|alpha|beta|pre|dev|nightly)", text, re.I)
        )
        return (0, base + (0 if is_prerelease else 1,))


def latest_version(versions: Sequence[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    usable = [v for v in versions if v.get("version") and not v.get("yanked")]
    if not usable:
        return None
    return max(usable, key=lambda item: version_key(str(item.get("version", ""))))


def _as_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _as_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _as_list(value: Any) -> List[str]:
    if value is None:
        return []
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return []
        try:
            parsed = json.loads(text)
        except Exception:
            return [part.strip() for part in text.split(",") if part.strip()]
        return _as_list(parsed)
    if isinstance(value, (list, tuple, set)):
        return [str(item).strip() for item in value if str(item).strip()]
    return [str(value).strip()]


def _normalize_version_entry(raw: Any) -> Optional[Dict[str, Any]]:
    if isinstance(raw, str):
        raw = {"version": raw}
    if not isinstance(raw, dict):
        return None
    version = str(raw.get("version") or raw.get("tag") or "").strip()
    if not version:
        return None
    entry = {
        "version": version,
        "path": str(raw.get("path") or "").strip(),
        "url": str(raw.get("url") or raw.get("download_url") or "").strip(),
        "sha256": str(raw.get("sha256") or "").strip().lower(),
        "size": _as_int(raw.get("size"), 0),
        "changelog": str(raw.get("changelog") or ""),
        "published": str(raw.get("published") or raw.get("published_at") or ""),
        "yanked": bool(raw.get("yanked", False)),
    }
    return entry


def normalize_plugin(raw: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Normalize a catalog entry (native Git or legacy Firebase-shaped)."""
    if not isinstance(raw, dict):
        return None
    plugin_id = str(raw.get("id") or "").strip()
    if not plugin_id:
        return None

    versions = [
        entry
        for entry in (
            _normalize_version_entry(item) for item in (raw.get("versions") or [])
        )
        if entry
    ]

    plugin_version = str(raw.get("version") or "").strip()
    if not versions and plugin_version:
        versions = [
            _normalize_version_entry(
                {
                    "version": plugin_version,
                    "path": raw.get("path"),
                    "url": raw.get("download_url") or raw.get("url"),
                    "sha256": raw.get("sha256"),
                    "size": raw.get("size"),
                }
            )
        ]
        versions = [entry for entry in versions if entry]

    latest = latest_version(versions)
    if latest is None:
        return None

    plugin = dict(raw)
    plugin["id"] = plugin_id
    plugin["name"] = str(raw.get("name") or plugin_id)
    plugin["version"] = str(latest["version"])
    plugin["versions"] = sorted(
        versions, key=lambda item: version_key(str(item["version"]))
    )
    plugin["dependencies"] = _as_list(raw.get("dependencies"))
    plugin["price"] = _as_float(raw.get("price"), 0.0)
    plugin["currency"] = str(raw.get("currency") or "USD")
    plugin["price_model"] = str(raw.get("price_model") or "free")
    plugin["license_type"] = str(
        (
            (raw.get("license") or {}).get("type", "free")
            if isinstance(raw.get("license"), dict)
            else raw.get("license_type")
            or (raw.get("license") if isinstance(raw.get("license"), str) else "")
            or "free"
        )
    )
    plugin["max_activations"] = _as_int(raw.get("max_activations"), 0)
    plugin["category"] = str(raw.get("category") or "tools")
    plugin["author"] = str(raw.get("author") or "")
    plugin["description"] = str(raw.get("description") or "")
    plugin["homepage"] = str(raw.get("homepage") or raw.get("repository") or "")
    plugin["tags"] = _as_list(raw.get("tags"))
    plugin["latest"] = latest
    return plugin


def empty_catalog(name: str = "QAH Git Marketplace", description: str = "") -> Dict[str, Any]:
    return {
        "schema": SCHEMA_VERSION,
        "name": name,
        "description": description,
        "updated": _timestamp(),
        "plugins": [],
    }


def normalize_catalog(data: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    catalog = dict(data or {})
    catalog.setdefault("schema", SCHEMA_VERSION)
    catalog.setdefault("name", "QAH Git Marketplace")
    catalog.setdefault("description", "")
    catalog["plugins"] = [
        plugin
        for plugin in (normalize_plugin(item) for item in (catalog.get("plugins") or []))
        if plugin
    ]
    catalog["plugins"].sort(key=lambda item: str(item.get("name", "")).lower())
    return catalog


class Catalog:
    """Mutable catalog with helpers used by publish/delete."""

    def __init__(self, data: Optional[Dict[str, Any]] = None):
        self.data = normalize_catalog(data)

    @property
    def plugins(self) -> List[Dict[str, Any]]:
        return self.data["plugins"]

    def get(self, plugin_id: str) -> Optional[Dict[str, Any]]:
        for plugin in self.plugins:
            if plugin["id"] == plugin_id:
                return plugin
        return None

    def upsert(
        self,
        manifest: Dict[str, Any],
        *,
        version: str,
        path: str,
        sha256: str,
        size: int,
        changelog: str = "",
        homepage: str = "",
    ) -> Dict[str, Any]:
        plugin_id = manifest["id"]
        existing = self.get(plugin_id)
        plugin = dict(existing) if existing else {"id": plugin_id}
        marketplace = manifest.get("marketplace") or {}
        license_info = manifest.get("license") or {}
        plugin.update(
            {
                "id": plugin_id,
                "name": manifest.get("name", plugin_id),
                "author": manifest.get("author", ""),
                "description": manifest.get("description", ""),
                "category": manifest.get("category", "tools"),
                "type": manifest.get("type", "python"),
                "dependencies": _as_list(manifest.get("dependencies")),
                "requires_qah": manifest.get("requires_qah", ""),
                "homepage": homepage or manifest.get("homepage", ""),
                "tags": _as_list(manifest.get("tags")),
                "price": _as_float(marketplace.get("price"), 0.0),
                "currency": marketplace.get("currency", "USD"),
                "price_model": marketplace.get("price_model", "free"),
                "license_type": (
                    license_info.get("type", "free")
                    if isinstance(license_info, dict)
                    else str(license_info or "free")
                ),
                "max_activations": _as_int(
                    license_info.get("max_activations", 0)
                    if isinstance(license_info, dict)
                    else 0,
                    0,
                ),
            }
        )
        versions = [
            entry
            for entry in (plugin.get("versions") or [])
            if entry.get("version") != version
        ]
        versions.append(
            {
                "version": version,
                "path": path,
                "url": "",
                "sha256": sha256,
                "size": int(size),
                "changelog": changelog,
                "published": _timestamp(),
                "yanked": False,
            }
        )
        versions.sort(key=lambda item: version_key(str(item["version"])))
        plugin["versions"] = versions
        latest = latest_version(versions)
        plugin["version"] = latest["version"] if latest else version
        plugin["latest"] = latest
        for index, item in enumerate(self.plugins):
            if item.get("id") == plugin_id:
                self.plugins[index] = plugin
                break
        else:
            self.plugins.append(plugin)
        self.plugins.sort(key=lambda item: str(item.get("name", "")).lower())
        self.data["updated"] = _timestamp()
        return plugin

    def remove(self, plugin_id: str, version: Optional[str] = None) -> Tuple[bool, List[str]]:
        """Remove a version (or the whole plugin). Returns (removed, paths)."""
        plugin = self.get(plugin_id)
        if plugin is None:
            return False, []
        paths: List[str] = []
        if version:
            keep = []
            for entry in plugin.get("versions") or []:
                if str(entry.get("version")) == version:
                    if entry.get("path"):
                        paths.append(str(entry["path"]))
                else:
                    keep.append(entry)
            plugin["versions"] = keep
            if not keep:
                self.plugins.remove(plugin)
                paths.extend(_plugin_metadata_paths(plugin_id))
            else:
                latest = latest_version(keep)
                plugin["version"] = latest["version"] if latest else ""
                plugin["latest"] = latest
        else:
            for entry in plugin.get("versions") or []:
                if entry.get("path"):
                    paths.append(str(entry["path"]))
            self.plugins.remove(plugin)
            paths.extend(_plugin_metadata_paths(plugin_id))
        self.data["updated"] = _timestamp()
        return True, sorted(set(paths))

    def to_dict(self) -> Dict[str, Any]:
        data = dict(self.data)
        plugins = []
        for plugin in self.data.get("plugins") or []:
            cleaned = dict(plugin)
            cleaned.pop("latest", None)
            plugins.append(cleaned)
        data["plugins"] = plugins
        return data

    def to_bytes(self) -> bytes:
        return json.dumps(self.to_dict(), indent=2, sort_keys=False).encode("utf-8")


def _plugin_metadata_paths(plugin_id: str) -> List[str]:
    return [
        f"{PLUGIN_ROOT}/{plugin_id}/manifest.json",
        f"{PLUGIN_ROOT}/{plugin_id}/README.md",
    ]


def version_path(plugin_id: str, version: str) -> str:
    safe_version = re.sub(r"[^A-Za-z0-9._+-]", "_", version)
    return (
        f"{PLUGIN_ROOT}/{plugin_id}/{safe_version}/"
        f"{plugin_id}-{safe_version}.qplugin.zip"
    )


def _timestamp() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


# ---------------------------------------------------------------------------
# HTTP and GitHub API
# ---------------------------------------------------------------------------


class _Transport:
    """Small HTTP shim: requests when present, urllib otherwise."""

    def request(
        self,
        method: str,
        url: str,
        headers: Dict[str, str],
        data: Optional[bytes] = None,
        timeout: int = 60,
    ) -> Tuple[int, Dict[str, str], bytes]:
        try:
            import requests  # type: ignore

            try:
                response = requests.request(
                    method,
                    url,
                    headers=headers,
                    data=data,
                    timeout=timeout,
                    allow_redirects=True,
                )
            except Exception as exc:
                raise MarketplaceError(f"Cannot reach {url}: {exc}") from exc
            return response.status_code, dict(response.headers), response.content
        except ImportError:
            pass

        request = urllib.request.Request(
            url, data=data, headers=headers, method=method
        )
        try:
            with urllib.request.urlopen(
                request, timeout=timeout, context=_ssl_context()
            ) as response:
                return (
                    int(response.status),
                    dict(response.headers.items()),
                    response.read(),
                )
        except urllib.error.HTTPError as exc:
            return int(exc.code), dict(exc.headers.items()), exc.read()
        except urllib.error.URLError as exc:
            raise MarketplaceError(f"Cannot reach {url}: {exc.reason}") from exc


def _ssl_context() -> ssl.SSLContext:
    try:
        import certifi  # type: ignore

        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


_HTTP = _Transport()


def _api_error_message(content: bytes) -> str:
    try:
        payload = json.loads(content.decode("utf-8", "replace"))
    except Exception:
        return content.decode("utf-8", "replace")[:500]
    message = str(payload.get("message") or "")
    errors = payload.get("errors")
    if errors:
        message += " " + json.dumps(errors)
    return message or content.decode("utf-8", "replace")[:500]


class GitHubClient:
    """Minimal GitHub REST client using the Git Data API for atomic commits."""

    def __init__(
        self,
        config: MarketplaceConfig,
        token: Optional[str] = None,
        transport: Optional[_Transport] = None,
    ):
        config.validate()
        self.config = config
        self.token = resolve_token(config) if token is None else token
        self.transport = transport or _HTTP
        self.api = config.api_base.rstrip("/")

    # -- low level -------------------------------------------------------
    def _url(self, path: str) -> str:
        return self.api + path

    def _headers(self, accept: str) -> Dict[str, str]:
        headers = {
            "Accept": accept,
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": USER_AGENT,
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    def _request(
        self,
        method: str,
        path: str,
        *,
        data: Optional[Dict[str, Any]] = None,
        accept: str = "application/vnd.github+json",
        raw: bool = False,
        allow_404: bool = False,
    ) -> Any:
        body = None
        headers = self._headers(accept)
        if data is not None:
            body = json.dumps(data).encode("utf-8")
            headers["Content-Type"] = "application/json"
        status, _headers, content = self.transport.request(
            method, self._url(path), headers, body
        )
        if status == 404 and allow_404:
            return None
        if status == 401:
            raise AuthError(
                "GitHub rejected the token (401). Create a token with "
                "'contents: write' access to this repository."
            )
        if status == 403:
            raise AuthError(
                "GitHub refused the request (403). The token may lack "
                "'contents: write', or the API rate limit was reached."
            )
        if status == 404:
            raise NotFound(
                f"GitHub returned 404 for {self.config.slug}. Check the owner, "
                "repository and branch; private repositories also need a token."
            )
        if status == 409:
            raise Conflict("The repository is empty or the branch is out of date.")
        if status == 422:
            raise Conflict(
                "GitHub rejected the update (422), usually because the branch "
                "moved. Refresh and try again. Details: "
                + _api_error_message(content)
            )
        if status >= 400:
            raise MarketplaceError(
                f"GitHub API {status} for {path}: {_api_error_message(content)}"
            )
        if raw:
            return content
        if not content:
            return None
        try:
            return json.loads(content.decode("utf-8"))
        except Exception as exc:
            raise MarketplaceError(
                f"GitHub returned a non-JSON response for {path}: "
                f"{content[:200]!r}"
            ) from exc

    def _get(self, path: str, **kwargs) -> Any:
        return self._request("GET", path, **kwargs)

    def _post(self, path: str, data: Dict[str, Any]) -> Any:
        return self._request("POST", path, data=data)

    def _patch(self, path: str, data: Dict[str, Any]) -> Any:
        return self._request("PATCH", path, data=data)

    def _put(self, path: str, data: Dict[str, Any]) -> Any:
        return self._request("PUT", path, data=data)

    # -- repository ------------------------------------------------------
    def repo_info(self) -> Dict[str, Any]:
        return self._get(f"/repos/{self.config.slug}")

    def branch_info(self) -> Optional[Dict[str, Any]]:
        return self._get(
            f"/repos/{self.config.slug}/branches/"
            f"{urllib.parse.quote(self.config.branch, safe='')}",
            allow_404=True,
        )

    def test_connection(self) -> Dict[str, Any]:
        repo = self.repo_info()
        branch = self.branch_info()
        permissions = repo.get("permissions") or {}
        return {
            "slug": repo.get("full_name", self.config.slug),
            "private": bool(repo.get("private")),
            "default_branch": repo.get("default_branch", ""),
            "branch": self.config.branch,
            "branch_exists": branch is not None,
            "head": ((branch or {}).get("commit") or {}).get("sha", ""),
            "writable": bool(permissions.get("push")),
            "html_url": repo.get("html_url", ""),
            "token": bool(self.token),
        }

    # -- pull-request workflow ------------------------------------------
    def whoami(self) -> Dict[str, Any]:
        if not self.token:
            raise AuthError(
                "Submitting a pull request needs a GitHub token. Add one in "
                "Settings or set GITHUB_TOKEN."
            )
        return self._get("/user")

    def repo_exists(self, slug: str) -> bool:
        return self._request("GET", f"/repos/{slug}", allow_404=True) is not None

    def ensure_fork(self, progress: Optional[Callable[[str], None]] = None) -> str:
        """Return ``owner/repo`` for the token user's fork, creating it if needed."""
        user = self.whoami()
        login = str(user.get("login") or "").strip()
        if not login:
            raise AuthError("GitHub did not return a user login for this token.")
        if login.lower() == self.config.owner.lower():
            return self.config.slug
        fork_slug = f"{login}/{self.config.repo}"
        if self.repo_exists(fork_slug):
            return fork_slug
        if progress:
            progress(f"Creating fork {fork_slug}...")
        try:
            self._post(f"/repos/{self.config.slug}/forks", {})
        except MarketplaceError as exc:
            raise MarketplaceError(
                f"Could not fork {self.config.slug} to {fork_slug}. The token "
                f"needs permission to create a fork. Details: {exc}"
            ) from exc
        for _ in range(30):
            if self.repo_exists(fork_slug):
                return fork_slug
            time.sleep(1)
        raise MarketplaceError(
            f"GitHub accepted the fork request for {fork_slug}, but it is not "
            "available yet. Try again in a minute."
        )

    def branch_head(self, branch: Optional[str] = None) -> str:
        branch = branch or self.config.branch
        ref = self._get(
            f"/repos/{self.config.slug}/git/ref/heads/"
            f"{urllib.parse.quote(branch, safe='')}"
        )
        return str(ref["object"]["sha"])

    def create_branch(self, branch: str, sha: str) -> None:
        self._post(
            f"/repos/{self.config.slug}/git/refs",
            {"ref": f"refs/heads/{branch}", "sha": sha},
        )

    def delete_branch(self, branch: str) -> None:
        try:
            self._request(
                "DELETE",
                f"/repos/{self.config.slug}/git/refs/heads/"
                f"{urllib.parse.quote(branch, safe='')}",
            )
        except Exception:
            pass

    def sync_fork(self, branch: Optional[str] = None) -> None:
        """Fast-forward a fork's branch from its upstream (best effort)."""
        try:
            self._post(
                f"/repos/{self.config.slug}/merge-upstream",
                {"branch": branch or self.config.branch},
            )
        except Exception:
            pass

    def open_pull_request(
        self,
        *,
        title: str,
        body: str,
        head: str,
        base: Optional[str] = None,
        draft: bool = False,
    ) -> Dict[str, Any]:
        payload = {
            "title": title,
            "body": body,
            "head": head,
            "base": base or self.config.branch,
            "draft": bool(draft),
        }
        try:
            return self._post(f"/repos/{self.config.slug}/pulls", payload)
        except Conflict as exc:
            raise MarketplaceError(
                "GitHub could not open the pull request. It may already exist "
                "for this branch, or the base branch changed. Details: "
                f"{exc}"
            ) from exc

    # -- file access -----------------------------------------------------
    def _contents_path(self, path: str) -> str:
        return (
            f"/repos/{self.config.slug}/contents/"
            f"{urllib.parse.quote(path, safe='/')}"
            f"?ref={urllib.parse.quote(self.config.branch, safe='')}"
        )

    def file_bytes(self, path: str) -> Optional[bytes]:
        content = self._request(
            "GET",
            self._contents_path(path),
            accept="application/vnd.github.raw+json",
            raw=True,
            allow_404=True,
        )
        if content is None:
            return None
        # Some proxies ignore the raw media type and return JSON.
        if content[:1] == b"{":
            try:
                payload = json.loads(content.decode("utf-8"))
                if isinstance(payload, dict) and payload.get("content"):
                    return base64.b64decode(payload["content"])
                if isinstance(payload, dict) and payload.get("download_url"):
                    return self._fetch_url(payload["download_url"])
            except Exception:
                pass
        return content

    def _fetch_url(self, url: str) -> bytes:
        parsed = urllib.parse.urlparse(url)
        headers = {"User-Agent": USER_AGENT}
        # Never send the GitHub token to third-party hosts referenced by a
        # catalog entry.
        github_hosts = {
            "api.github.com",
            "github.com",
            "raw.githubusercontent.com",
            "objects.githubusercontent.com",
            "codeload.github.com",
        }
        if self.token and parsed.hostname in github_hosts:
            headers["Authorization"] = f"Bearer {self.token}"
        status, _headers, content = self.transport.request("GET", url, headers)
        if status >= 400:
            raise MarketplaceError(f"Download failed ({status}) from {url}")
        return content

    def catalog_bytes(self) -> Optional[bytes]:
        return self.file_bytes(CATALOG_FILE)

    def catalog(self) -> Dict[str, Any]:
        raw = self.catalog_bytes()
        if raw is None:
            raise NotFound(
                f"{CATALOG_FILE} was not found in {self.config.slug} "
                f"(branch {self.config.branch}). Run 'init' or the Settings "
                "'Initialize repository' action first."
            )
        try:
            return normalize_catalog(json.loads(raw.decode("utf-8")))
        except Exception as exc:
            raise MarketplaceError(f"{CATALOG_FILE} is not valid JSON: {exc}") from exc

    # -- commits ---------------------------------------------------------
    def _head(self, branch: Optional[str] = None) -> Tuple[str, str]:
        branch = branch or self.config.branch
        ref = self._get(
            f"/repos/{self.config.slug}/git/ref/heads/"
            f"{urllib.parse.quote(branch, safe='')}"
        )
        commit_sha = ref["object"]["sha"]
        commit = self._get(f"/repos/{self.config.slug}/git/commits/{commit_sha}")
        return commit_sha, commit["tree"]["sha"]

    def _create_blob(self, content: bytes) -> str:
        payload = self._post(
            f"/repos/{self.config.slug}/git/blobs",
            {
                "content": base64.b64encode(content).decode("ascii"),
                "encoding": "base64",
            },
        )
        return str(payload["sha"])

    def commit_files(
        self,
        files: Dict[str, bytes],
        message: str,
        deletions: Iterable[str] = (),
        *,
        branch: Optional[str] = None,
    ) -> str:
        """Create one commit containing all files and deletions."""
        branch = branch or self.config.branch
        deletions = list(deletions)
        last_error: Optional[Exception] = None
        for _attempt in range(2):
            try:
                parent_sha, base_tree = self._head(branch)
                entries: List[Dict[str, Any]] = []
                for path, content in files.items():
                    entries.append(
                        {
                            "path": path,
                            "mode": "100644",
                            "type": "blob",
                            "sha": self._create_blob(content),
                        }
                    )
                for path in deletions:
                    entries.append(
                        {
                            "path": path,
                            "mode": "100644",
                            "type": "blob",
                            "sha": None,
                        }
                    )
                tree = self._post(
                    f"/repos/{self.config.slug}/git/trees",
                    {"base_tree": base_tree, "tree": entries},
                )
                commit = self._post(
                    f"/repos/{self.config.slug}/git/commits",
                    {
                        "message": message,
                        "tree": tree["sha"],
                        "parents": [parent_sha],
                    },
                )
                self._patch(
                    f"/repos/{self.config.slug}/git/refs/heads/"
                    f"{urllib.parse.quote(branch, safe='')}",
                    {"sha": commit["sha"], "force": False},
                )
                return str(commit["sha"])
            except Conflict as exc:
                last_error = exc
                time.sleep(0.4)
                continue
        raise Conflict(
            "Could not update the branch because it kept moving. Try again."
        ) from last_error

    def create_first_file(self, path: str, content: bytes, message: str) -> str:
        """Create the initial file in an empty repository."""
        payload = {
            "message": message,
            "content": base64.b64encode(content).decode("ascii"),
            "branch": self.config.branch,
        }
        try:
            result = self._put(
                f"/repos/{self.config.slug}/contents/"
                f"{urllib.parse.quote(path, safe='/')}",
                payload,
            )
        except (NotFound, Conflict):
            payload.pop("branch", None)
            result = self._put(
                f"/repos/{self.config.slug}/contents/"
                f"{urllib.parse.quote(path, safe='/')}",
                payload,
            )
        return str(((result or {}).get("commit") or {}).get("sha", ""))


# ---------------------------------------------------------------------------
# ZIP helpers
# ---------------------------------------------------------------------------


def _should_skip(path: Path, root: Path) -> bool:
    relative = path.relative_to(root)
    if any(part in _EXCLUDED_DIRS for part in relative.parts[:-1]):
        return True
    if path.name in _EXCLUDED_DIRS:
        return True
    if path.name.startswith(".") and path.name not in (".plugincreator",):
        return True
    if path.suffix.lower() in _EXCLUDED_SUFFIXES:
        return True
    if path.name.endswith(".qplugin.zip"):
        return True
    return False


def build_plugin_zip(
    folder: os.PathLike | str,
    *,
    manifest_override: Optional[Dict[str, Any]] = None,
) -> Tuple[bytes, Dict[str, Any], int]:
    """Build a .qplugin.zip in memory. Returns (bytes, manifest, size)."""
    folder = Path(folder).expanduser().resolve()
    if not folder.is_dir():
        raise MarketplaceError(f"Plugin folder not found: {folder}")
    manifest_path = folder / "manifest.json"
    if not manifest_path.is_file():
        raise MarketplaceError(f"{folder} has no manifest.json")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest_override:
        manifest.update(manifest_override)
    if not manifest.get("id"):
        raise MarketplaceError("manifest.json has no id")
    if not (folder / "__init__.py").is_file():
        raise MarketplaceError(f"{folder} has no __init__.py")

    files: List[Path] = []
    for path in folder.rglob("*"):
        if path.is_file() and not _should_skip(path, folder):
            files.append(path)
    files.sort(key=lambda item: item.relative_to(folder).as_posix())

    buffer = io.BytesIO()
    manifest_mtime = manifest_path.stat().st_mtime
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            arcname = path.relative_to(folder).as_posix()
            if arcname == "manifest.json":
                info = zipfile.ZipInfo(
                    arcname, date_time=time.localtime(manifest_mtime)[:6]
                )
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o644 << 16
                archive.writestr(
                    info, json.dumps(manifest, indent=2).encode("utf-8")
                )
            else:
                archive.write(path, arcname)
        if not any(path.name == "manifest.json" for path in files):
            info = zipfile.ZipInfo(
                "manifest.json", date_time=time.localtime(manifest_mtime)[:6]
            )
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, json.dumps(manifest, indent=2).encode("utf-8"))
    data = buffer.getvalue()
    if len(data) > 100 * 1024 * 1024:
        raise MarketplaceError(
            "The plugin ZIP is larger than GitHub's 100 MB file limit."
        )
    return data, manifest, len(data)


def _safe_members(archive: zipfile.ZipFile) -> List[Tuple[zipfile.ZipInfo, PurePosixPath]]:
    members: List[Tuple[zipfile.ZipInfo, PurePosixPath]] = []
    total_size = 0
    for info in archive.infolist():
        name = info.filename.replace("\\", "/")
        if not name or name.startswith("__MACOSX/"):
            continue
        path = PurePosixPath(name)
        if path.is_absolute() or ".." in path.parts:
            raise MarketplaceError(f"Unsafe path in plugin ZIP: {name!r}")
        if any(part == "" for part in path.parts):
            continue
        mode = (info.external_attr >> 16) & 0o170000
        if stat.S_ISLNK(mode):
            raise MarketplaceError(f"Symlink entries are not allowed: {name!r}")
        total_size += int(info.file_size)
        members.append((info, path))
    if len(members) > 20000:
        raise MarketplaceError("The plugin ZIP contains too many files.")
    if total_size > 512 * 1024 * 1024:
        raise MarketplaceError(
            "The plugin ZIP expands to more than 512 MB; refusing to extract it."
        )
    return members


def extract_plugin_zip(data: bytes, destination: os.PathLike | str) -> Path:
    """Extract a plugin ZIP safely, stripping a single wrapper directory."""
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        members = _safe_members(archive)
        if not members:
            raise MarketplaceError("The plugin ZIP is empty.")
        roots = {path.parts[0] for _info, path in members if len(path.parts) > 1}
        root_files = {path.parts[0] for _info, path in members if len(path.parts) == 1}
        strip_root = len(roots) == 1 and not root_files
        for info, path in members:
            parts = path.parts[1:] if strip_root else path.parts
            if not parts:
                continue
            target = destination.joinpath(*parts)
            resolved = target.resolve()
            if destination.resolve() not in resolved.parents and resolved != destination.resolve():
                raise MarketplaceError(f"Unsafe path in plugin ZIP: {info.filename!r}")
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info) as source, open(target, "wb") as output:
                shutil.copyfileobj(source, output)
    return destination


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: os.PathLike | str) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _rmtree(path: Path) -> None:
    def _onerror(function, failing_path, _exc_info):
        try:
            os.chmod(failing_path, stat.S_IWRITE)
            function(failing_path)
        except Exception:
            pass

    shutil.rmtree(path, onerror=_onerror)


# ---------------------------------------------------------------------------
# High-level marketplace
# ---------------------------------------------------------------------------


class Marketplace:
    def __init__(
        self,
        config: Optional[MarketplaceConfig] = None,
        *,
        client: Optional[GitHubClient] = None,
        plugin_config: Optional[Dict[str, Any]] = None,
        fork_client_factory: Optional[Callable[[MarketplaceConfig], GitHubClient]] = None,
    ):
        self.config = config or load_config(plugin_config)
        self.client = client or GitHubClient(self.config)
        self.fork_client_factory = fork_client_factory
        self._catalog: Optional[Dict[str, Any]] = None
        self._catalog_time = 0.0

    def _fork_client(self, fork_slug: str, branch: str) -> GitHubClient:
        owner, repo = fork_slug.split("/", 1)
        config = MarketplaceConfig(
            owner=owner,
            repo=repo,
            branch=branch,
            token=self.client.token,
            api_base=self.config.api_base,
            cache_ttl=self.config.cache_ttl,
        )
        if self.fork_client_factory is not None:
            return self.fork_client_factory(config)
        return GitHubClient(config, token=self.client.token)

    # -- catalog ---------------------------------------------------------
    def refresh(
        self,
        force: bool = False,
        *,
        progress: Optional[Callable[[str], None]] = None,
    ) -> List[Dict[str, Any]]:
        now = time.time()
        if (
            not force
            and self._catalog is not None
            and now - self._catalog_time < max(self.config.cache_ttl, 0)
        ):
            return list(self._catalog.get("plugins") or [])

        if not force and self.config.cache_ttl > 0:
            cached = self._load_cache()
            if cached is not None:
                self._catalog = cached
                self._catalog_time = now
                return list(cached.get("plugins") or [])

        if progress:
            progress(f"Reading {CATALOG_FILE} from {self.config.slug}...")
        catalog = self.client.catalog()
        self._catalog = catalog
        self._catalog_time = now
        self._save_cache(catalog)
        return list(catalog.get("plugins") or [])

    def _cache_key(self) -> Dict[str, Any]:
        return {
            "slug": self.config.slug,
            "branch": self.config.branch,
            "api_base": self.config.api_base,
        }

    def _load_cache(self) -> Optional[Dict[str, Any]]:
        path = cache_path()
        if not path.is_file():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return None
        if any(data.get(key) != value for key, value in self._cache_key().items()):
            return None
        if time.time() - float(data.get("timestamp", 0)) > max(self.config.cache_ttl, 0):
            return None
        catalog = data.get("catalog")
        return normalize_catalog(catalog) if isinstance(catalog, dict) else None

    def _save_cache(self, catalog: Dict[str, Any]) -> None:
        path = cache_path()
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            payload = {
                **self._cache_key(),
                "timestamp": time.time(),
                "catalog": catalog,
            }
            path.write_text(json.dumps(payload), encoding="utf-8")
        except OSError:
            pass

    def get_plugin(self, plugin_id: str) -> Optional[Dict[str, Any]]:
        for plugin in self.refresh():
            if plugin.get("id") == plugin_id:
                return plugin
        return None

    # -- installed plugins ----------------------------------------------
    def installed_plugins(self) -> Dict[str, Dict[str, Any]]:
        result: Dict[str, Dict[str, Any]] = {}
        directories: List[Tuple[Path, str]] = [(classic_plugins_dir(False), "user")]
        legacy = legacy_plugins_dir()
        if legacy and legacy != classic_plugins_dir(False):
            directories.append((legacy, "legacy"))
        for directory, source in directories:
            if not directory.is_dir():
                continue
            for child in directory.iterdir():
                manifest_path = child / "manifest.json"
                if not child.is_dir() or not manifest_path.is_file():
                    continue
                try:
                    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                except Exception:
                    continue
                plugin_id = str(manifest.get("id") or child.name)
                result[plugin_id] = {
                    "id": plugin_id,
                    "name": manifest.get("name", plugin_id),
                    "version": str(manifest.get("version", "")),
                    "path": str(child),
                    "source": source,
                }
        return result

    def check_updates(self) -> Dict[str, Dict[str, Any]]:
        installed = self.installed_plugins()
        updates: Dict[str, Dict[str, Any]] = {}
        for plugin in self.refresh():
            current = installed.get(plugin["id"])
            if not current:
                continue
            if version_key(plugin["version"]) > version_key(current["version"]):
                updates[plugin["id"]] = {
                    "current_version": current["version"],
                    "new_version": plugin["version"],
                    "name": current["name"],
                    "plugin": plugin,
                }
        return updates

    # -- download / install ---------------------------------------------
    def download_version(
        self,
        plugin: Dict[str, Any],
        version: Optional[str] = None,
        *,
        progress: Optional[Callable[[str], None]] = None,
    ) -> Tuple[bytes, Dict[str, Any]]:
        entry = None
        if version:
            entry = next(
                (
                    item
                    for item in plugin.get("versions") or []
                    if str(item.get("version")) == str(version)
                ),
                None,
            )
        if entry is None:
            entry = plugin.get("latest") or (plugin.get("versions") or [None])[-1]
        if not entry:
            raise MarketplaceError(f"{plugin['id']} has no downloadable version.")

        if progress:
            progress(f"Downloading {plugin['id']} {entry['version']}...")
        if entry.get("url"):
            data = self.client._fetch_url(entry["url"])
        elif entry.get("path"):
            data = self.client.file_bytes(entry["path"])
            if data is None:
                raise NotFound(
                    f"{entry['path']} is missing from {self.config.slug}."
                )
        else:
            raise MarketplaceError(
                f"{plugin['id']} {entry['version']} has no path or URL."
            )

        expected = str(entry.get("sha256") or "").lower()
        if expected and sha256_bytes(data) != expected:
            raise MarketplaceError(
                f"SHA256 mismatch for {plugin['id']} {entry['version']}. "
                "The catalog may be out of date."
            )
        return data, entry

    def install_plugin(
        self,
        plugin_id: str,
        version: Optional[str] = None,
        *,
        target_dir: Optional[os.PathLike | str] = None,
        progress: Optional[Callable[[str], None]] = None,
    ) -> Path:
        plugin = self.get_plugin(plugin_id)
        if plugin is None:
            raise NotFound(f"Plugin '{plugin_id}' is not in the marketplace.")
        data, entry = self.download_version(plugin, version, progress=progress)

        root = Path(target_dir) if target_dir else classic_plugins_dir()
        root.mkdir(parents=True, exist_ok=True)
        target = root / plugin_id
        staging = Path(tempfile.mkdtemp(prefix=f".{plugin_id}-", dir=str(root)))
        backup: Optional[Path] = None
        try:
            extract_plugin_zip(data, staging)
            # Flatten a single wrapper directory if the archive had extra roots.
            if not (staging / "manifest.json").is_file():
                subdirs = [child for child in staging.iterdir() if child.is_dir()]
                if (
                    len(subdirs) == 1
                    and (subdirs[0] / "manifest.json").is_file()
                ):
                    wrapper = subdirs[0]
                    for item in list(wrapper.iterdir()):
                        shutil.move(str(item), str(staging / item.name))
                    wrapper.rmdir()
            manifest_path = staging / "manifest.json"
            if not manifest_path.is_file():
                raise MarketplaceError("manifest.json not found in the plugin ZIP.")
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            manifest_id = str(manifest.get("id") or "")
            if manifest_id and manifest_id != plugin_id:
                raise MarketplaceError(
                    f"The ZIP contains plugin '{manifest_id}', not '{plugin_id}'."
                )
            if target.exists():
                backup = target.with_name(f".{plugin_id}.backup-{int(time.time())}")
                os.replace(target, backup)
            os.replace(staging, target)
            if backup:
                _rmtree(backup)
            if progress:
                progress(f"Installed {plugin_id} {entry['version']} into {target}")
            return target
        except Exception:
            if staging.exists():
                _rmtree(staging)
            if backup and backup.exists() and not target.exists():
                os.replace(backup, target)
            raise

    def uninstall_plugin(self, plugin_id: str) -> str:
        installed = self.installed_plugins().get(plugin_id)
        if not installed:
            raise NotFound(f"Plugin '{plugin_id}' is not installed.")
        target = Path(installed["path"])
        root = classic_plugins_dir(False).resolve()
        try:
            if target.resolve().parent != root:
                raise MarketplaceError(
                    f"Refusing to remove a plugin outside {root}: {target}"
                )
        except OSError as exc:
            raise MarketplaceError(f"Cannot resolve {target}: {exc}") from exc
        _rmtree(target)
        return f"Removed {target}"

    # -- publishing ------------------------------------------------------
    def _prepare_publish(
        self,
        folder: os.PathLike | str,
        *,
        version: Optional[str],
        changelog: str,
        homepage: str,
        metadata: Optional[Dict[str, Any]],
        progress: Optional[Callable[[str], None]],
    ) -> Dict[str, Any]:
        folder = Path(folder).expanduser()
        manifest_path = folder / "manifest.json"
        if not manifest_path.is_file():
            raise MarketplaceError(f"{folder} has no manifest.json")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        manifest_id = str(manifest.get("id") or "").strip()
        if not PLUGIN_ID_RE.match(manifest_id):
            raise MarketplaceError(
                f"Invalid plugin id {manifest_id!r}; use letters, digits, '.', "
                "'_' or '-'."
            )
        if metadata:
            for key in ("name", "author", "description", "category", "type"):
                value = metadata.get(key)
                if value not in (None, ""):
                    manifest[key] = value
        publish_version = str(version or manifest.get("version") or "").strip()
        if not publish_version:
            raise MarketplaceError("The manifest has no version.")
        if version:
            manifest["version"] = publish_version

        if progress:
            progress(f"Building {manifest_id} {publish_version}...")
        data, manifest, size = build_plugin_zip(
            folder, manifest_override=manifest
        )
        digest = sha256_bytes(data)

        if progress:
            progress("Fetching the current catalog...")
        self.config.validate()
        catalog = Catalog(self.client.catalog())
        path = version_path(manifest_id, publish_version)
        catalog.upsert(
            manifest,
            version=publish_version,
            path=path,
            sha256=digest,
            size=size,
            changelog=changelog,
            homepage=homepage or str(manifest.get("homepage") or ""),
        )

        files: Dict[str, bytes] = {
            CATALOG_FILE: catalog.to_bytes(),
            f"{PLUGIN_ROOT}/{manifest_id}/manifest.json": json.dumps(
                manifest, indent=2
            ).encode("utf-8"),
            path: data,
        }
        readme = folder / "README.md"
        if readme.is_file():
            files[f"{PLUGIN_ROOT}/{manifest_id}/README.md"] = readme.read_bytes()

        return {
            "folder": folder,
            "manifest": manifest,
            "id": manifest_id,
            "version": publish_version,
            "path": path,
            "data": data,
            "sha256": digest,
            "size": size,
            "catalog": catalog,
            "files": files,
            "changelog": changelog,
        }

    def publish_plugin(
        self,
        folder: os.PathLike | str,
        *,
        version: Optional[str] = None,
        changelog: str = "",
        homepage: str = "",
        metadata: Optional[Dict[str, Any]] = None,
        progress: Optional[Callable[[str], None]] = None,
    ) -> Dict[str, Any]:
        prepared = self._prepare_publish(
            folder,
            version=version,
            changelog=changelog,
            homepage=homepage,
            metadata=metadata,
            progress=progress,
        )
        manifest_id = prepared["id"]
        publish_version = prepared["version"]
        files = prepared["files"]

        if progress:
            progress(
                f"Committing {len(files)} file(s) to "
                f"{self.config.slug}@{self.config.branch}..."
            )
        commit = self.client.commit_files(
            files, f"Publish {manifest_id} {publish_version}"
        )
        self._catalog = prepared["catalog"].to_dict()
        self._catalog_time = time.time()
        self._save_cache(self._catalog)
        return {
            "id": manifest_id,
            "version": publish_version,
            "path": prepared["path"],
            "sha256": prepared["sha256"],
            "size": prepared["size"],
            "commit": commit,
        }

    def _pull_request_body(self, prepared: Dict[str, Any]) -> str:
        manifest = prepared["manifest"]
        lines = [
            "## Plugin submission",
            "",
            f"- **Plugin id:** `{prepared['id']}`",
            f"- **Version:** `{prepared['version']}`",
            f"- **Name:** {manifest.get('name', '')}",
            f"- **Author:** {manifest.get('author', '')}",
            f"- **Category:** {manifest.get('category', '')}",
            f"- **ZIP:** `{prepared['path']}`",
            f"- **Size:** {prepared['size']} bytes",
            f"- **SHA256:** `{prepared['sha256']}`",
            "",
        ]
        if prepared.get("changelog"):
            lines.extend(["### Changelog", "", prepared["changelog"], ""])
        lines.extend(
            [
                "---",
                "",
                "Generated by **Git Plugin Marketplace**.",
                "",
                "- [ ] I own or am allowed to redistribute this plugin.",
                "- [ ] The validation workflow passes.",
                "- [ ] I understand this public repository exposes the ZIP contents.",
                "",
                "Merging is owner-only.",
            ]
        )
        return "\n".join(lines)

    def submit_pull_request(
        self,
        folder: os.PathLike | str,
        *,
        version: Optional[str] = None,
        changelog: str = "",
        homepage: str = "",
        metadata: Optional[Dict[str, Any]] = None,
        title: Optional[str] = None,
        body: Optional[str] = None,
        draft: bool = False,
        progress: Optional[Callable[[str], None]] = None,
    ) -> Dict[str, Any]:
        """Fork the marketplace, commit to a branch and open a pull request."""
        if not self.client.token:
            raise AuthError(
                "Submitting a pull request needs a GitHub token in Settings "
                "(or GITHUB_TOKEN / GH_TOKEN / gh auth token)."
            )
        prepared = self._prepare_publish(
            folder,
            version=version,
            changelog=changelog,
            homepage=homepage,
            metadata=metadata,
            progress=progress,
        )
        manifest_id = prepared["id"]
        publish_version = prepared["version"]

        if progress:
            progress("Identifying the GitHub account...")
        user = self.client.whoami()
        login = str(user.get("login") or "").strip()
        if not login:
            raise AuthError("GitHub did not return a user login for this token.")

        base = self.config.branch
        branch = re.sub(
            r"[^A-Za-z0-9._/-]",
            "-",
            f"marketplace/{manifest_id}-{publish_version}-{int(time.time())}",
        )
        same_repo = login.lower() == self.config.owner.lower()
        if same_repo:
            fork_slug = self.config.slug
            fork_client = self.client
            head_ref = branch
            base_sha = self.client.branch_head(base)
        else:
            fork_slug = self.client.ensure_fork(progress=progress)
            fork_client = self._fork_client(fork_slug, base)
            # Keep an old fork close to upstream; ignore if GitHub refuses.
            fork_client.sync_fork(base)
            try:
                base_sha = fork_client.branch_head(base)
            except Exception:
                base_sha = self.client.branch_head(base)
            head_ref = f"{login}:{branch}"

        if progress:
            progress(f"Creating branch {branch} on {fork_slug}...")
        fork_client.create_branch(branch, base_sha)
        try:
            if progress:
                progress(
                    f"Committing {len(prepared['files'])} file(s) to {branch}..."
                )
            commit = fork_client.commit_files(
                prepared["files"],
                f"Publish {manifest_id} {publish_version}",
                branch=branch,
            )
            if progress:
                progress("Opening pull request...")
            pull = self.client.open_pull_request(
                title=title or f"Publish {manifest_id} {publish_version}",
                body=body or self._pull_request_body(prepared),
                head=head_ref,
                base=base,
                draft=draft,
            )
        except Exception:
            fork_client.delete_branch(branch)
            raise

        return {
            "id": manifest_id,
            "version": publish_version,
            "path": prepared["path"],
            "sha256": prepared["sha256"],
            "size": prepared["size"],
            "commit": commit,
            "fork": fork_slug,
            "branch": branch,
            "head": head_ref,
            "pr_number": pull.get("number"),
            "pr_url": pull.get("html_url", ""),
            "draft": bool(draft),
        }

    def delete_plugin(
        self,
        plugin_id: str,
        version: Optional[str] = None,
        *,
        progress: Optional[Callable[[str], None]] = None,
    ) -> Dict[str, Any]:
        catalog = Catalog(self.client.catalog())
        plugin = catalog.get(plugin_id)
        if plugin is None:
            raise NotFound(f"Plugin '{plugin_id}' is not in the marketplace.")
        versions = plugin.get("versions") or []
        if version and not any(
            str(entry.get("version")) == str(version) for entry in versions
        ):
            raise NotFound(f"{plugin_id} {version} is not in the marketplace.")

        removed, paths = catalog.remove(plugin_id, version)
        if not removed:
            raise NotFound(f"Nothing to delete for {plugin_id}.")
        # GitHub's tree API expects deletions to exist; skip missing READMEs.
        existing_paths = [
            path for path in paths if self.client.file_bytes(path) is not None
        ]
        action = f"{plugin_id} {version}" if version else f"{plugin_id} (all versions)"
        if progress:
            progress(f"Deleting {action}...")
        commit = self.client.commit_files(
            {CATALOG_FILE: catalog.to_bytes()},
            f"Delete {action}",
            deletions=existing_paths,
        )
        self._catalog = catalog.to_dict()
        self._catalog_time = time.time()
        self._save_cache(self._catalog)
        return {
            "id": plugin_id,
            "version": version,
            "deleted_paths": paths,
            "commit": commit,
        }

    # -- repository bootstrap -------------------------------------------
    def initialize_marketplace(
        self,
        *,
        name: str = "",
        description: str = "",
        progress: Optional[Callable[[str], None]] = None,
    ) -> Dict[str, Any]:
        self.config.validate()
        if self.client.catalog_bytes() is not None:
            raise MarketplaceError(
                f"{CATALOG_FILE} already exists in {self.config.slug}; "
                "refusing to overwrite it."
            )
        catalog = empty_catalog(
            name or self.config.name, description or self.config.description
        )
        readme = _marketplace_readme(self.config, catalog)
        branch = self.client.branch_info()
        if progress:
            progress(f"Initializing {CATALOG_FILE} in {self.config.slug}...")
        if branch is None:
            commit = self.client.create_first_file(
                CATALOG_FILE, Catalog(catalog).to_bytes(), "Initialize marketplace"
            )
            # An empty repository may be created with a different default
            # branch (for example `master`); follow it before the next commit.
            try:
                default_branch = str(
                    (self.client.repo_info() or {}).get("default_branch") or ""
                )
                if default_branch:
                    self.config.branch = default_branch
            except Exception:
                pass
            try:
                self.client.commit_files(
                    {"README.md": readme}, "Add marketplace README"
                )
            except Exception:
                pass
        else:
            commit = self.client.commit_files(
                {
                    CATALOG_FILE: Catalog(catalog).to_bytes(),
                    "README.md": readme,
                },
                "Initialize marketplace",
            )
        return {"commit": commit, "catalog": catalog}

    def test_connection(self) -> Dict[str, Any]:
        return self.client.test_connection()


def _marketplace_readme(config: MarketplaceConfig, catalog: Dict[str, Any]) -> bytes:
    text = f"""# {catalog.get('name', 'QAH Git Marketplace')}

This repository is a plugin registry for **Quantum Analysis Helper**, managed
by the *Git Plugin Marketplace* plugin.

Layout:

```text
index.json                              catalog
plugins/<id>/manifest.json              plugin manifest
plugins/<id>/README.md                  optional description
plugins/<id>/<version>/<id>-<version>.qplugin.zip
```

Do not edit `index.json` by hand while a publish is running. The plugin writes
the catalog and the ZIP in one Git commit.

Repository: `{config.slug}` (branch `{config.branch}`)

Generated by QAH Git Plugin Marketplace.
"""
    return text.encode("utf-8")


# ---------------------------------------------------------------------------
# Convenience formatting
# ---------------------------------------------------------------------------


def format_plugin_line(plugin: Dict[str, Any]) -> str:
    return (
        f"{plugin.get('name', plugin.get('id'))} "
        f"v{plugin.get('version', '?')} "
        f"[{plugin.get('category', '')}]"
    )


def format_installed_table(installed: Dict[str, Dict[str, Any]]) -> str:
    if not installed:
        return "No classic plugins installed."
    lines = [f"{'ID':<32} {'VERSION':<12} PATH", "-" * 90]
    for plugin in sorted(installed.values(), key=lambda item: item["id"]):
        lines.append(
            f"{plugin['id'][:32]:<32} {plugin['version'][:12]:<12} {plugin['path']}"
        )
    return "\n".join(lines)
