# git_plugin_marketplace/settings_dialog.py
"""Repository and credential settings for the Git Plugin Marketplace."""

from __future__ import annotations

import importlib.util
import sys
import traceback
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QThread, Signal, Qt
from PySide6.QtWidgets import (
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
)


def _load_core():
    try:
        from . import git_marketplace_core as core  # type: ignore

        return core
    except Exception:
        path = Path(__file__).with_name("git_marketplace_core.py")
        spec = importlib.util.spec_from_file_location("gpm_core_settings", path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        return module


class _Worker(QThread):
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, function, parent=None):
        super().__init__(parent)
        self._function = function

    def run(self):
        try:
            self.done.emit(self._function())
        except Exception:
            self.failed.emit(traceback.format_exc())


class SettingsDialog(QDialog):
    def __init__(self, parent=None, config=None):
        super().__init__(parent)
        self.core = _load_core()
        self._config = config or self.core.MarketplaceConfig()
        self._worker: Optional[_Worker] = None
        self.setWindowTitle("Git Marketplace settings")
        self.setMinimumWidth(560)
        self._build_ui()
        self._load(self._config)

    # -- UI --------------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)

        intro = QLabel(
            "The Git marketplace stores its catalog and plugin ZIPs in a GitHub "
            "repository. Reads work on public repositories; publishing and "
            "deleting need a token with <b>contents: write</b>."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        form = QFormLayout()
        self.owner = QLineEdit()
        self.owner.setPlaceholderText("GitHub user or organisation")
        self.repo = QLineEdit()
        self.repo.setPlaceholderText("repository name, e.g. qah-marketplace")
        self.branch = QLineEdit()
        self.branch.setPlaceholderText("main")
        self.token = QLineEdit()
        self.token.setEchoMode(QLineEdit.Password)
        self.token.setPlaceholderText(
            "optional: GITHUB_TOKEN / GH_TOKEN / gh auth token is used if empty"
        )
        self.remember = QCheckBox("Remember the token on this computer")
        self.remember.setChecked(True)

        form.addRow("Owner:", self.owner)
        form.addRow("Repository:", self.repo)
        form.addRow("Branch:", self.branch)
        form.addRow("Token:", self.token)
        form.addRow("", self.remember)
        layout.addLayout(form)

        self.url_label = QLabel()
        self.url_label.setTextFormat(Qt.PlainText)
        self.url_label.setWordWrap(True)
        layout.addWidget(self.url_label)

        advanced = QGroupBox("Advanced")
        advanced_form = QFormLayout(advanced)
        self.api_base = QLineEdit()
        self.api_base.setPlaceholderText(self.core.DEFAULT_API_BASE)
        self.cache_ttl = QSpinBox()
        self.cache_ttl.setRange(0, 86400)
        self.cache_ttl.setSuffix(" s")
        advanced_form.addRow("GitHub API base:", self.api_base)
        advanced_form.addRow("Catalog cache:", self.cache_ttl)
        layout.addWidget(advanced)

        self.status = QLabel("")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)

        actions = QHBoxLayout()
        self.test_button = QPushButton("Test connection")
        self.test_button.clicked.connect(self._test)
        actions.addWidget(self.test_button)
        self.init_button = QPushButton("Initialize repository")
        self.init_button.setToolTip(
            "Create index.json and README.md in an empty repository"
        )
        self.init_button.clicked.connect(self._initialize)
        actions.addWidget(self.init_button)
        actions.addStretch(1)

        buttons = QDialogButtonBox(
            QDialogButtonBox.Save | QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        actions.addWidget(buttons)
        layout.addLayout(actions)

        for widget in (self.owner, self.repo):
            widget.textChanged.connect(self._update_url)
        self.branch.textChanged.connect(self._update_url)

    def _load(self, config):
        self.owner.setText(config.owner)
        self.repo.setText(config.repo)
        self.branch.setText(config.branch or "main")
        self.token.setText(config.token)
        self.api_base.setText(config.api_base or self.core.DEFAULT_API_BASE)
        self.cache_ttl.setValue(int(config.cache_ttl or 0))
        self._update_url()

    def _update_url(self):
        owner = self.owner.text().strip()
        repo = self.repo.text().strip()
        if owner and repo:
            self.url_label.setText(f"Repository: https://github.com/{owner}/{repo}")
        else:
            self.url_label.setText("Repository: not configured")

    # -- config ----------------------------------------------------------
    def _build_config(self):
        return self.core.MarketplaceConfig(
            owner=self.owner.text().strip(),
            repo=self.repo.text().strip(),
            branch=self.branch.text().strip() or "main",
            token=self.token.text().strip(),
            api_base=self.api_base.text().strip() or self.core.DEFAULT_API_BASE,
            cache_ttl=int(self.cache_ttl.value()),
            name=self._config.name,
            description=self._config.description,
        )

    def config(self):
        return self._config

    def remember_token(self) -> bool:
        return self.remember.isChecked()

    def accept(self):
        if self._worker is not None and self._worker.isRunning():
            QMessageBox.information(
                self, "Busy", "Wait for the connection test to finish."
            )
            return
        config = self._build_config()
        try:
            config.validate()
        except Exception as exc:
            QMessageBox.warning(self, "Incomplete settings", str(exc))
            return
        self._config = config
        super().accept()

    def reject(self):
        self._detach_worker()
        super().reject()

    def closeEvent(self, event):
        self._detach_worker()
        super().closeEvent(event)

    def _detach_worker(self):
        worker = self._worker
        if worker is not None and worker.isRunning():
            worker.setParent(None)
            worker.finished.connect(worker.deleteLater)
        self._worker = None

    # -- actions ---------------------------------------------------------
    def _set_busy(self, busy: bool):
        for widget in (
            self.test_button,
            self.init_button,
            self.owner,
            self.repo,
            self.branch,
            self.token,
        ):
            widget.setEnabled(not busy)

    def _start(self, label, function, on_done):
        if self._worker is not None and self._worker.isRunning():
            return
        self.status.setText(label)
        self._set_busy(True)
        worker = _Worker(function, self)
        worker.done.connect(on_done)
        worker.failed.connect(self._on_failed)
        worker.finished.connect(lambda: self._set_busy(False))
        self._worker = worker
        worker.start()

    def _on_failed(self, text):
        self.status.setText("Failed")
        QMessageBox.critical(self, "Git marketplace", text)

    def _test(self):
        config = self._build_config()
        try:
            config.validate()
        except Exception as exc:
            QMessageBox.warning(self, "Incomplete settings", str(exc))
            return

        def operation():
            client = self.core.GitHubClient(config)
            return client.test_connection()

        def done(result):
            writable = "yes" if result.get("writable") else "no"
            branch = "exists" if result.get("branch_exists") else "missing"
            head = (result.get("head") or "")[:12]
            self.status.setText(
                f"Connected to {result.get('slug')} "
                f"({'private' if result.get('private') else 'public'}); "
                f"branch {result.get('branch')} {branch}, head {head or '-'}; "
                f"write access: {writable}"
            )

        self._start("Testing connection...", operation, done)

    def _initialize(self):
        config = self._build_config()
        try:
            config.validate()
        except Exception as exc:
            QMessageBox.warning(self, "Incomplete settings", str(exc))
            return
        answer = QMessageBox.question(
            self,
            "Initialize repository",
            f"Create index.json and README.md in {config.slug}?\n\n"
            "This is only for an empty marketplace repository.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return

        def operation():
            marketplace = self.core.Marketplace(config)
            return marketplace.initialize_marketplace()

        def done(result):
            self.status.setText(
                "Repository initialized (commit "
                f"{str(result.get('commit', ''))[:12]})."
            )
            QMessageBox.information(
                self, "Initialized", "The marketplace repository is ready."
            )

        self._start("Initializing repository...", operation, done)
