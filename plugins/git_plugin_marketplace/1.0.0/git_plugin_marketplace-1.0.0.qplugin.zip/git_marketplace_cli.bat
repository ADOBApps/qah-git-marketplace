@echo off
setlocal
set "HERE=%~dp0"

rem Prefer the Python launcher, fall back to python on PATH.
py -3 "%HERE%git_marketplace_cli.py" %*
if not errorlevel 9009 exit /b %ERRORLEVEL%

python "%HERE%git_marketplace_cli.py" %*
exit /b %ERRORLEVEL%
