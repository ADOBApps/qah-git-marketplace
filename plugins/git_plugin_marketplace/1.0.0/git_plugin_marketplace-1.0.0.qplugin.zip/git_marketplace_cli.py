#!/usr/bin/env python3
# git_plugin_marketplace/git_marketplace_cli.py
"""
Author: Acxel Orozco
Standalone CLI for the Git Plugin Marketplace (no Qt, no QAH imports).

Examples:
    py -3 git_marketplace_cli.py config --owner ADOBApps --repo qah-marketplace
    py -3 git_marketplace_cli.py doctor
    py -3 git_marketplace_cli.py list
    py -3 git_marketplace_cli.py install wheel_plugin_manager
    py -3 git_marketplace_cli.py publish "C:\\path\\to\\my_plugin" --changelog "First release"
    py -3 git_marketplace_cli.py delete my_plugin --version 1.0.0
    py -3 git_marketplace_cli.py init --name "QAH Git Marketplace"

This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

import git_marketplace_core as core  # noqa: E402


def _print_config(config: core.MarketplaceConfig) -> None:
    token = "yes" if core.resolve_token(config) else "no"
    print(f"Repository : {config.slug or '(not configured)'}")
    print(f"Branch     : {config.branch}")
    print(f"API base   : {config.api_base}")
    print(f"Token      : {token}")
    print(f"Config file: {core.config_path()}")
    print(f"QAH home   : {core.qah_home()}")
    print(f"Plugins    : {core.classic_plugins_dir(False)}")


def _cmd_doctor(args) -> int:
    config = core.load_config()
    print("Git Plugin Marketplace - doctor")
    print("=" * 64)
    _print_config(config)
    print()
    if not config.slug:
        print("No repository configured; use 'config --owner ... --repo ...'.")
        return 0
    try:
        info = core.Marketplace(config).test_connection()
    except Exception as exc:
        print(f"Connection: FAILED\n  {exc}")
        return 1
    print("Connection")
    print("-" * 64)
    print(f"  repository : {info.get('slug')} ({'private' if info.get('private') else 'public'})")
    print(f"  branch     : {info.get('branch')} ({'exists' if info.get('branch_exists') else 'missing'})")
    print(f"  head       : {info.get('head') or '-'}")
    print(f"  write      : {info.get('writable')}")
    print(f"  catalog    : {'present' if core.GitHubClient(config).catalog_bytes() is not None else 'MISSING (run init)'}")
    return 0


def _cmd_config(args) -> int:
    config = core.load_config()
    if args.show or not any(
        value is not None
        for value in (
            args.owner,
            args.repo_name,
            args.branch,
            args.token,
            args.api_base,
            args.cache_ttl,
        )
    ):
        _print_config(config)
        return 0
    if args.owner is not None:
        config.owner = args.owner.strip()
    if args.repo_name is not None:
        config.repo = args.repo_name.strip()
    if args.branch is not None:
        config.branch = args.branch.strip() or "main"
    if args.token is not None:
        config.token = args.token.strip()
    if args.clear_token:
        config.token = ""
    if args.api_base is not None:
        config.api_base = args.api_base.strip() or core.DEFAULT_API_BASE
    if args.cache_ttl is not None:
        config.cache_ttl = max(0, int(args.cache_ttl))
    path = core.save_config(config, remember_token=not args.no_remember_token)
    print(f"Saved to {path}")
    _print_config(core.load_config())
    return 0


def _cmd_list(args) -> int:
    config = core.load_config()
    market = core.Marketplace(config)
    plugins = market.refresh(force=args.refresh)
    if not plugins:
        print("The marketplace catalog is empty.")
        return 0
    print(f"{'ID':<32} {'VERSION':<10} {'CATEGORY':<14} NAME")
    print("-" * 96)
    for plugin in plugins:
        print(
            f"{plugin['id'][:32]:<32} {str(plugin.get('version',''))[:10]:<10} "
            f"{str(plugin.get('category',''))[:14]:<14} {plugin.get('name','')}"
        )
    return 0


def _cmd_info(args) -> int:
    market = core.Marketplace(core.load_config())
    plugin = market.get_plugin(args.plugin_id)
    if plugin is None:
        print(f"error: plugin not found: {args.plugin_id}", file=sys.stderr)
        return 1
    print(json.dumps(plugin, indent=2))
    return 0


def _cmd_install(args) -> int:
    market = core.Marketplace(core.load_config())
    target = market.install_plugin(
        args.plugin_id,
        args.version,
        target_dir=args.target,
        progress=print,
    )
    print(f"Installed into {target}")
    print("Restart QAH (or rescan plugins) to load it.")
    return 0


def _cmd_uninstall(args) -> int:
    market = core.Marketplace(core.load_config())
    print(market.uninstall_plugin(args.plugin_id))
    return 0


def _cmd_publish(args) -> int:
    market = core.Marketplace(core.load_config())
    metadata = {
        key: value
        for key, value in {
            "name": args.name,
            "author": args.author,
            "category": args.category,
            "description": args.description,
        }.items()
        if value
    }
    result = market.publish_plugin(
        args.folder,
        version=args.version,
        changelog=args.changelog,
        homepage=args.homepage,
        metadata=metadata or None,
        progress=print,
    )
    print(
        f"Published {result['id']} {result['version']} "
        f"({result['size']} bytes, sha256 {result['sha256'][:16]}...)"
    )
    print(f"Commit: {result['commit']}")
    print(f"Path  : {result['path']}")
    return 0


def _cmd_delete(args) -> int:
    market = core.Marketplace(core.load_config())
    version = None if args.all else args.version
    if not args.all and not version:
        print("error: pass --version or --all", file=sys.stderr)
        return 1
    result = market.delete_plugin(args.plugin_id, version, progress=print)
    print(f"Deleted {result['id']} {version or '(all versions)'}")
    print(f"Commit: {result['commit']}")
    return 0


def _cmd_init(args) -> int:
    market = core.Marketplace(core.load_config())
    result = market.initialize_marketplace(
        name=args.name or "", description=args.description or "", progress=print
    )
    print(f"Initialized marketplace (commit {result['commit']})")
    return 0


def _cmd_updates(args) -> int:
    market = core.Marketplace(core.load_config())
    updates = market.check_updates()
    if not updates:
        print("All installed plugins are up to date.")
        return 0
    for plugin_id, info in sorted(updates.items()):
        print(
            f"{plugin_id}: {info['current_version']} -> {info['new_version']}"
        )
    return 0


def _cmd_build(args) -> int:
    data, manifest, size = core.build_plugin_zip(args.folder)
    output = Path(args.out).expanduser() if args.out else Path.cwd()
    output.mkdir(parents=True, exist_ok=True)
    name = f"{manifest['id']}-{manifest['version']}.qplugin.zip"
    path = output / name
    path.write_bytes(data)
    print(f"Built {path} ({size} bytes, sha256 {core.sha256_bytes(data)})")
    return 0


def _cmd_validate(args) -> int:
    data, manifest, size = core.build_plugin_zip(args.folder)
    print(f"OK: {manifest['id']} {manifest['version']} ({size} bytes)")
    print(f"sha256: {core.sha256_bytes(data)}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="git_marketplace_cli.py",
        description="Git-backed plugin marketplace for Quantum Analysis Helper.",
    )
    parser.add_argument("--repo", dest="repo_override", help="owner/repository override")
    parser.add_argument("--branch", dest="branch_override", help="branch override")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("doctor", help="Show configuration and test the connection.")
    p.set_defaults(func=_cmd_doctor)

    p = sub.add_parser("config", help="Show or update the repository settings.")
    p.add_argument("--show", action="store_true")
    p.add_argument("--owner")
    p.add_argument("--repo-name", dest="repo_name")
    p.add_argument("--branch")
    p.add_argument("--token")
    p.add_argument("--clear-token", action="store_true")
    p.add_argument("--api-base")
    p.add_argument("--cache-ttl", type=int)
    p.add_argument("--no-remember-token", action="store_true")
    p.set_defaults(func=_cmd_config)

    p = sub.add_parser("list", help="List plugins in the catalog.")
    p.add_argument("--refresh", action="store_true", help="Ignore the cache.")
    p.set_defaults(func=_cmd_list)

    p = sub.add_parser("info", help="Show one catalog entry as JSON.")
    p.add_argument("plugin_id")
    p.set_defaults(func=_cmd_info)

    p = sub.add_parser("install", help="Download and install a plugin.")
    p.add_argument("plugin_id")
    p.add_argument("--version")
    p.add_argument("--target")
    p.set_defaults(func=_cmd_install)

    p = sub.add_parser("uninstall", help="Remove an installed plugin.")
    p.add_argument("plugin_id")
    p.set_defaults(func=_cmd_uninstall)

    p = sub.add_parser("publish", help="Package and publish a plugin folder.")
    p.add_argument("folder")
    p.add_argument("--version", help="Override the manifest version.")
    p.add_argument("--changelog", default="")
    p.add_argument("--homepage", default="")
    p.add_argument("--name", help="Override the manifest name.")
    p.add_argument("--author", help="Override the manifest author.")
    p.add_argument("--category", help="Override the manifest category.")
    p.add_argument("--description", help="Override the manifest description.")
    p.set_defaults(func=_cmd_publish)

    p = sub.add_parser("delete", help="Delete a version or a whole plugin.")
    p.add_argument("plugin_id")
    p.add_argument("--version")
    p.add_argument("--all", action="store_true")
    p.set_defaults(func=_cmd_delete)

    p = sub.add_parser("init", help="Create index.json in an empty repository.")
    p.add_argument("--name")
    p.add_argument("--description")
    p.set_defaults(func=_cmd_init)

    p = sub.add_parser("updates", help="Show updates for installed plugins.")
    p.set_defaults(func=_cmd_updates)

    p = sub.add_parser("build", help="Build a .qplugin.zip locally.")
    p.add_argument("folder")
    p.add_argument("--out")
    p.set_defaults(func=_cmd_build)

    p = sub.add_parser("validate", help="Validate and package a plugin locally.")
    p.add_argument("folder")
    p.set_defaults(func=_cmd_validate)

    return parser


def main(argv=None) -> int:
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

    parser = build_parser()
    args = parser.parse_args(argv)
    if getattr(args, "repo_override", None):
        os.environ[core.ENV_REPO] = args.repo_override
    if getattr(args, "branch_override", None):
        os.environ[core.ENV_BRANCH] = args.branch_override
    if not getattr(args, "func", None):
        parser.print_help()
        return 0
    try:
        return int(args.func(args))
    except core.MarketplaceError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
