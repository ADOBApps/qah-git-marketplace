# git_plugin_marketplace/__init__.py
"""
Author: Acxel Orozco
Git Plugin Marketplace - QAH plugin entry point.

An alternative to the Firebase Plugin Marketplace that stores the catalog and
plugin ZIP files in a Git repository (GitHub). See git_marketplace_core.py.

This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

from __future__ import annotations

import importlib
import importlib.util
import logging
import sys
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QObject
from PySide6.QtGui import QAction, QIcon
from PySide6.QtWidgets import QWidget

try:
    from plugins.libs.plugin_manager import PluginInfo
except Exception:  # some Windows builds use a different module layout
    PluginInfo = object  # type: ignore

_PLUGIN_ID = "git_plugin_marketplace"


def _load_sibling(name: str):
    """Import a helper in both package and standalone-plugin loading modes."""
    try:
        return importlib.import_module(f"{__name__}.{name}")
    except ImportError:
        path = Path(__file__).parent / f"{name}.py"
        spec = importlib.util.spec_from_file_location(f"{__name__}_{name}", path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        return module


_core = _load_sibling("git_marketplace_core")


class GitPluginMarketplace(QObject):
    """Entry point referenced by [project.entry-points."qah.plugins"]."""

    def __init__(self, plugin_info: PluginInfo):
        super().__init__()
        self.plugin_info = plugin_info
        self.ui_widget: Optional[QWidget] = None
        self.icon: Optional[QIcon] = None
        self.marketplace = None

        icon_path = Path(__file__).parent / "icon.svg"
        if icon_path.is_file():
            self.icon = QIcon(str(icon_path))

        self.reload_marketplace()

    # -- configuration ---------------------------------------------------
    def _plugin_config(self) -> dict:
        config = getattr(self.plugin_info, "config", None)
        return config if isinstance(config, dict) else {}

    def reload_marketplace(self):
        """(Re)build the marketplace from the current config."""
        config = _core.load_config(self._plugin_config())
        try:
            self.marketplace = _core.Marketplace(config)
        except Exception as exc:
            # An unconfigured marketplace must not stop QAH from loading the
            # plugin; the UI opens Settings instead.
            logging.info("Git marketplace not configured yet: %s", exc)
            self.marketplace = None

    def save_config(self, config) -> None:
        _core.save_config(config)
        self.reload_marketplace()

    # -- QAH lifecycle ---------------------------------------------------
    def initialize(self) -> bool:
        try:
            logging.info(
                "Initializing %s v%s", self.plugin_info.name, self.plugin_info.version
            )
            return True
        except Exception as exc:
            logging.error("Git marketplace initialization failed: %s", exc)
            return False

    def get_widget(self) -> Optional[QWidget]:
        if self.ui_widget is None:
            try:
                ui = _load_sibling("marketplace_widget")
                self.ui_widget = ui.MarketplaceWidget(self)
            except Exception as exc:
                logging.error("Could not build Git Plugin Marketplace: %s", exc)
                logging.debug("Traceback", exc_info=True)
                return None
        return self.ui_widget

    def get_menu_actions(self):
        action = QAction("Git Plugin Marketplace", self)
        if self.icon is not None:
            action.setIcon(self.icon)
        action.setToolTip("Discover, install and publish plugins from a Git registry")
        return [action]

    def cleanup(self):
        if self.ui_widget is not None:
            try:
                if hasattr(self.ui_widget, "cleanup"):
                    self.ui_widget.cleanup()
            finally:
                self.ui_widget.deleteLater()
                self.ui_widget = None


Plugin = GitPluginMarketplace
