# git_plugin_marketplace/publish_dialog.py
"""Publish (upload) a plugin folder to the Git marketplace."""

from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
)


def _load_core():
    try:
        from . import git_marketplace_core as core  # type: ignore

        return core
    except Exception:
        path = Path(__file__).with_name("git_marketplace_core.py")
        spec = importlib.util.spec_from_file_location("gpm_core_publish", path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        return module


class PublishDialog(QDialog):
    def __init__(self, parent=None, initial_folder: Optional[str] = None):
        super().__init__(parent)
        self.core = _load_core()
        self.setWindowTitle("Publish plugin to the Git marketplace")
        self.setMinimumWidth(640)
        self._build_ui()
        if initial_folder:
            self.folder.setText(initial_folder)
            self._load_manifest()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        intro = QLabel(
            "The folder is packaged as a <code>.qplugin.zip</code> (manifest at "
            "the archive root), committed to the repository and indexed. "
            "Existing versions with the same number are replaced."
        )
        intro.setWordWrap(True)
        intro.setTextFormat(Qt.RichText)
        layout.addWidget(intro)

        folder_row = QHBoxLayout()
        folder_row.addWidget(QLabel("Plugin folder:"))
        self.folder = QLineEdit()
        self.folder.setPlaceholderText("folder containing manifest.json and __init__.py")
        folder_row.addWidget(self.folder, 1)
        browse = QPushButton("Browse...")
        browse.clicked.connect(self._browse)
        folder_row.addWidget(browse)
        load = QPushButton("Load manifest")
        load.clicked.connect(self._load_manifest)
        folder_row.addWidget(load)
        layout.addLayout(folder_row)

        form = QFormLayout()
        self.plugin_id = QLineEdit()
        self.name = QLineEdit()
        self.version = QLineEdit()
        self.author = QLineEdit()
        self.category = QComboBox()
        self.category.setEditable(True)
        self.category.addItems(
            ["analysis", "development", "tools", "visualization", "other"]
        )
        self.homepage = QLineEdit()
        self.homepage.setPlaceholderText("optional project URL")
        form.addRow("Plugin id:", self.plugin_id)
        self.plugin_id.setReadOnly(True)
        self.plugin_id.setToolTip("Read from manifest.json; path names use this id.")
        form.addRow("Name:", self.name)
        form.addRow("Version:", self.version)
        form.addRow("Author:", self.author)
        form.addRow("Category:", self.category)
        form.addRow("Homepage:", self.homepage)
        layout.addLayout(form)

        layout.addWidget(QLabel("Description:"))
        self.description = QPlainTextEdit()
        self.description.setFixedHeight(70)
        layout.addWidget(self.description)

        layout.addWidget(QLabel("Changelog (optional):"))
        self.changelog = QPlainTextEdit()
        self.changelog.setFixedHeight(80)
        layout.addWidget(self.changelog)

        self.status = QLabel("")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)

        buttons = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        )
        buttons.button(QDialogButtonBox.Ok).setText("Publish")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    # -- actions ---------------------------------------------------------
    def _browse(self):
        folder = QFileDialog.getExistingDirectory(
            self, "Select the plugin project folder", str(Path.home())
        )
        if folder:
            self.folder.setText(folder)
            self._load_manifest()

    def _load_manifest(self):
        folder = Path(self.folder.text().strip().strip('"'))
        manifest_path = folder / "manifest.json"
        if not manifest_path.is_file():
            self.status.setText(f"No manifest.json in {folder}")
            return
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception as exc:
            self.status.setText(f"Cannot read manifest.json: {exc}")
            return
        self.plugin_id.setText(str(manifest.get("id", "")))
        self.name.setText(str(manifest.get("name", "")))
        self.version.setText(str(manifest.get("version", "")))
        self.author.setText(str(manifest.get("author", "")))
        self.category.setCurrentText(str(manifest.get("category", "tools")))
        self.description.setPlainText(str(manifest.get("description", "")))
        homepage = manifest.get("homepage") or manifest.get("repository") or ""
        if isinstance(homepage, dict):
            homepage = homepage.get("url", "")
        self.homepage.setText(str(homepage))
        self.status.setText("Manifest loaded.")

    def accept(self):
        folder = Path(self.folder.text().strip().strip('"'))
        if not folder.is_dir():
            QMessageBox.warning(self, "Missing folder", "Select a plugin folder.")
            return
        if not (folder / "manifest.json").is_file():
            QMessageBox.warning(
                self, "Missing manifest", f"{folder} has no manifest.json."
            )
            return
        if not (folder / "__init__.py").is_file():
            QMessageBox.warning(
                self, "Missing entry point", f"{folder} has no __init__.py."
            )
            return
        plugin_id = self.plugin_id.text().strip()
        if not self.core.PLUGIN_ID_RE.match(plugin_id):
            QMessageBox.warning(
                self,
                "Invalid id",
                "Use letters, digits, '.', '_' or '-' (no path separators).",
            )
            return
        if not self.version.text().strip():
            QMessageBox.warning(self, "Missing version", "Enter a version.")
            return
        super().accept()

    def data(self) -> dict:
        return {
            "folder": self.folder.text().strip().strip('"'),
            "version": self.version.text().strip(),
            "changelog": self.changelog.toPlainText().strip(),
            "homepage": self.homepage.text().strip(),
            "metadata": {
                "name": self.name.text().strip(),
                "author": self.author.text().strip(),
                "category": self.category.currentText().strip(),
                "description": self.description.toPlainText().strip(),
            },
        }
