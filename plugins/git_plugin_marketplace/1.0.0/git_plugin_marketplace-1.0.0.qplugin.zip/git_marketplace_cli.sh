#!/bin/sh
# Git Plugin Marketplace - POSIX launcher (Linux / macOS).
#
# Usage:
#   ./git_marketplace_cli.sh doctor
#   ./git_marketplace_cli.sh list
#   ./git_marketplace_cli.sh publish "/path/to/plugin" --changelog "First release"
#
# Override the interpreter with QAH_CLI_PYTHON=/path/to/python3.
set -u

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PYTHON=${QAH_CLI_PYTHON:-python3}

if ! command -v "$PYTHON" >/dev/null 2>&1; then
    PYTHON=python
fi

exec "$PYTHON" "$SCRIPT_DIR/git_marketplace_cli.py" "$@"
