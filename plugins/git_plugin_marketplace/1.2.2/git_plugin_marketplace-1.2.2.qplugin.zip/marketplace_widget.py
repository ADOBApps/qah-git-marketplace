# git_plugin_marketplace/marketplace_widget.py
"""PySide6 front-end for the Git Plugin Marketplace."""

from __future__ import annotations

import html
import importlib
import importlib.util
import json
import sys
import traceback
from datetime import datetime
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QThread, QTimer, Qt, QUrl, Signal
from PySide6.QtGui import QDesktopServices, QFont, QFontDatabase
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMenu,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QSplitter,
    QStyle,
    QTabWidget,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)


def _load_sibling(name: str):
    try:
        return importlib.import_module(f"{__name__}.{name}")
    except ImportError:
        path = Path(__file__).with_name(f"{name}.py")
        spec = importlib.util.spec_from_file_location(f"_gpm_{name}", path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        return module


core = _load_sibling("git_marketplace_core")
SettingsDialog = _load_sibling("settings_dialog").SettingsDialog
PublishDialog = _load_sibling("publish_dialog").PublishDialog


class _Task(QThread):
    log = Signal(str)
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, function, parent=None):
        super().__init__(parent)
        self._function = function

    def run(self):
        try:
            self.done.emit(self._function(self.log.emit))
        except Exception:
            self.failed.emit(traceback.format_exc())


class MarketplaceWidget(QWidget):
    def __init__(self, plugin):
        super().__init__()
        self.plugin = plugin
        self.plugins = []
        self.themes = []
        self.addons = []
        self.installed = {}
        self.installed_themes = {}
        self.installed_addons = {}
        self.updates = {}
        self.theme_updates = {}
        self.addon_updates = {}
        self._task: Optional[_Task] = None
        self._unconfigured_warned = False
        self.writable: Optional[bool] = None

        self._build_ui()
        self.load_installed()
        self._refresh_header()
        QTimer.singleShot(150, self._initial_refresh)

    # -- setup -----------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        header = QHBoxLayout()
        title = QLabel("<b>Git Plugin Marketplace</b>")
        title.setFont(QFont("Arial", 14))
        header.addWidget(title)
        self.repo_label = QLabel("")
        self.repo_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.repo_label.setStyleSheet("color: #6c757d;")
        header.addWidget(self.repo_label, 1)
        self.settings_btn = QPushButton("Settings")
        self.settings_btn.clicked.connect(self.open_settings)
        header.addWidget(self.settings_btn)
        layout.addLayout(header)

        top = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search plugins...")
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self.display_plugins)
        top.addWidget(self.search, 2)

        self.category = QComboBox()
        self.category.setMinimumWidth(150)
        self.category.currentTextChanged.connect(self.display_plugins)
        top.addWidget(self.category)
        self.kind_filter = QComboBox()
        self.kind_filter.addItems(["Plugins", "Themes", "Addons"])
        self.kind_filter.setMinimumWidth(100)
        self.kind_filter.currentTextChanged.connect(lambda _text: self._kind_changed())
        top.addWidget(self.kind_filter)

        self.refresh_btn = QPushButton("Refresh")
        self.refresh_btn.clicked.connect(lambda: self.refresh(force=True))
        top.addWidget(self.refresh_btn)

        self.update_all_btn = QPushButton("Update All")
        self.update_all_btn.setEnabled(False)
        self.update_all_btn.clicked.connect(self.update_all)
        top.addWidget(self.update_all_btn)

        self.publish_btn = QPushButton("Publish Plugin")
        self.publish_btn.clicked.connect(self.publish_plugin)
        top.addWidget(self.publish_btn)
        layout.addLayout(top)

        status = QHBoxLayout()
        self.status_dot = QLabel("●")
        self.status_dot.setStyleSheet("color: #27ae60;")
        status.addWidget(self.status_dot)
        self.status_label = QLabel("Ready")
        self.status_label.setStyleSheet("color: #6c757d;")
        status.addWidget(self.status_label, 1)
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.progress.setRange(0, 0)
        self.progress.setMaximumWidth(180)
        status.addWidget(self.progress)
        layout.addLayout(status)

        splitter = QSplitter(Qt.Horizontal)
        layout.addWidget(splitter, 1)

        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 0, 0)
        list_header = QLabel("Available plugins")
        list_header.setStyleSheet(
            "padding: 6px; background: #e9ecef; border-radius: 4px;"
        )
        left_layout.addWidget(list_header)
        self.plugin_list = QListWidget()
        self.plugin_list.setAlternatingRowColors(True)
        self.plugin_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.plugin_list.customContextMenuRequested.connect(self._context_menu)
        self.plugin_list.currentItemChanged.connect(self._selection_changed)
        self.plugin_list.itemDoubleClicked.connect(self._double_clicked)
        left_layout.addWidget(self.plugin_list, 1)
        splitter.addWidget(left)

        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        self.tabs = QTabWidget()

        details_tab = QWidget()
        details_layout = QVBoxLayout(details_tab)
        self.details = QTextBrowser()
        self.details.setOpenExternalLinks(True)
        self.details.setStyleSheet("QTextBrowser { border: 1px solid #dee2e6; }")
        details_layout.addWidget(self.details, 1)

        buttons = QHBoxLayout()
        self.install_btn = QPushButton("Install")
        self.install_btn.clicked.connect(self.install_selected)
        buttons.addWidget(self.install_btn)
        self.update_btn = QPushButton("Update")
        self.update_btn.clicked.connect(self.update_selected)
        buttons.addWidget(self.update_btn)
        self.uninstall_btn = QPushButton("Uninstall")
        self.uninstall_btn.clicked.connect(self.uninstall_selected)
        buttons.addWidget(self.uninstall_btn)
        buttons.addStretch(1)
        self.info_btn = QPushButton("Info")
        self.info_btn.clicked.connect(self.show_info)
        buttons.addWidget(self.info_btn)
        self.repo_btn = QPushButton("Open repository")
        self.repo_btn.clicked.connect(self.open_repo)
        buttons.addWidget(self.repo_btn)
        details_layout.addLayout(buttons)

        version_row = QHBoxLayout()
        version_row.addWidget(QLabel("Install version:"))
        self.version_combo = QComboBox()
        self.version_combo.setMinimumWidth(130)
        version_row.addWidget(self.version_combo)
        self.install_version_btn = QPushButton("Install this version")
        self.install_version_btn.setToolTip(
            "Install a specific version, including an older release. It replaces "
            "the current user plugin copy."
        )
        self.install_version_btn.clicked.connect(self.install_selected_version)
        version_row.addWidget(self.install_version_btn)
        version_row.addStretch(1)
        details_layout.addLayout(version_row)
        for button in (
            self.install_btn,
            self.update_btn,
            self.uninstall_btn,
            self.info_btn,
            self.install_version_btn,
        ):
            button.setEnabled(False)
        self.tabs.addTab(details_tab, "Details")

        activity_tab = QWidget()
        activity_layout = QVBoxLayout(activity_tab)
        self.activity = QPlainTextEdit()
        self.activity.setReadOnly(True)
        self.activity.setLineWrapMode(QPlainTextEdit.NoWrap)
        try:
            fixed = QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont)
        except Exception:
            fixed = QFontDatabase.systemFont(QFontDatabase.FixedFont)
        fixed.setPointSize(10)
        self.activity.setFont(fixed)
        activity_layout.addWidget(self.activity, 1)
        clear = QPushButton("Clear")
        clear.clicked.connect(self.activity.clear)
        activity_layout.addWidget(clear, 0, Qt.AlignRight)
        self.tabs.addTab(activity_tab, "Activity")
        right_layout.addWidget(self.tabs, 1)
        splitter.addWidget(right)
        splitter.setSizes([420, 680])

        self._log("Git Plugin Marketplace ready.")
        if self._config().slug:
            self._log(f"Repository: {self._config().slug} (branch {self._config().branch})")
        else:
            self._log("No repository configured. Open Settings to connect one.")

    # -- config / market -------------------------------------------------
    def _config(self):
        market = getattr(self.plugin, "marketplace", None)
        if market is not None:
            return market.config
        return core.load_config(self._plugin_config())

    def _plugin_config(self):
        config = getattr(getattr(self.plugin, "plugin_info", None), "config", None)
        return config if isinstance(config, dict) else {}

    def _marketplace(self):
        market = getattr(self.plugin, "marketplace", None)
        if market is None:
            try:
                self.plugin.reload_marketplace()
            except Exception:
                pass
            market = getattr(self.plugin, "marketplace", None)
        return market

    def _refresh_header(self):
        config = self._config()
        if config.slug:
            self.repo_label.setText(
                f"{config.slug}  ·  branch {config.branch}"
            )
        else:
            self.repo_label.setText("No repository configured")

    # -- logging / status ------------------------------------------------
    def _log(self, message: str = ""):
        text = str(message)
        stamp = datetime.now().strftime("%H:%M:%S")
        for index, line in enumerate(text.splitlines() or [""]):
            prefix = f"[{stamp}] " if index == 0 else "           "
            self.activity.appendPlainText(prefix + line)
        bar = self.activity.verticalScrollBar()
        bar.setValue(bar.maximum())

    def _status(self, text: str, state: str = "ready"):
        colors = {
            "ready": "#27ae60",
            "loading": "#f39c12",
            "error": "#e74c3c",
            "success": "#27ae60",
        }
        self.status_dot.setStyleSheet(
            f"color: {colors.get(state, '#6c757d')};"
        )
        self.status_label.setText(text)

    def _set_busy(self, busy: bool):
        for widget in (
            self.refresh_btn,
            self.update_all_btn,
            self.publish_btn,
            self.install_btn,
            self.update_btn,
            self.uninstall_btn,
            self.plugin_list,
        ):
            widget.setEnabled(not busy)
        self.progress.setVisible(busy)
        self.update_all_btn.setEnabled(not busy and bool(self.updates))
        if not busy:
            self._update_buttons()

    def _start(self, label: str, function, on_done):
        if self._task is not None and self._task.isRunning():
            QMessageBox.information(
                self, "Busy", "Another marketplace operation is still running."
            )
            return
        self._log("")
        self._log(label)
        self._status(label, "loading")
        task = _Task(function, self)
        task.log.connect(self._log)
        task.done.connect(on_done)
        task.failed.connect(self._on_failed)
        task.finished.connect(lambda t=task: self._on_finished(t))
        self._task = task
        self._set_busy(True)
        task.start()

    def _on_finished(self, task):
        # A done handler may have started a newer task before this finished
        # signal was delivered. Only the task that actually finished may be
        # cleared/deleted; deleting the current QThread while it runs aborts Qt.
        if self._task is task:
            self._task = None
            self._set_busy(False)
        task.deleteLater()

    def _on_failed(self, text: str):
        self._log("[Error] " + text)
        self._status("Operation failed", "error")
        if "index.json was not found" in text:
            QMessageBox.information(
                self,
                "Marketplace not initialized",
                "This repository has no index.json yet.\n\n"
                "Open Settings → Initialize repository to create the catalog.",
            )
        else:
            QMessageBox.critical(
                self, "Git marketplace", "See the Activity tab for the traceback."
            )

    # -- refresh ---------------------------------------------------------
    def _initial_refresh(self):
        if self._config().slug:
            self.refresh(force=False)

    def refresh(self, force: bool = True):
        market = self._marketplace()
        if market is None:
            self._status("No repository configured", "error")
            if not self._unconfigured_warned:
                self._unconfigured_warned = True
                QMessageBox.information(
                    self,
                    "Configure the marketplace",
                    "Open Settings and enter the GitHub repository that stores "
                    "the marketplace catalog (index.json).",
                )
            return

        def operation(progress):
            plugins = market.refresh(force=force, progress=progress)
            themes = market.themes(force=force, progress=progress)
            addons = market.addons(force=force, progress=progress)
            installed = market.installed_plugins()
            installed_themes = market.installed_themes()
            installed_addons = market.installed_addons()
            updates = market.check_updates()
            theme_updates = market.check_theme_updates()
            addon_updates = market.check_addon_updates()
            writable = None
            try:
                writable = market.test_connection().get("writable")
            except Exception:
                pass
            return (
                plugins,
                themes,
                addons,
                installed,
                installed_themes,
                installed_addons,
                updates,
                theme_updates,
                addon_updates,
                writable,
            )

        def done(result):
            (
                plugins,
                themes,
                addons,
                installed,
                installed_themes,
                installed_addons,
                updates,
                theme_updates,
                addon_updates,
                writable,
            ) = result
            self.plugins = plugins
            self.themes = themes
            self.addons = addons
            self.installed = installed
            self.installed_themes = installed_themes
            self.installed_addons = installed_addons
            self.updates = updates
            self.theme_updates = theme_updates
            self.addon_updates = addon_updates
            self.writable = writable
            self._rebuild_categories()
            self.display_plugins()
            self._status(
                f"Synced {len(plugins)} plugin(s), {len(themes)} theme(s) and "
                f"{len(addons)} addon(s) from {market.config.slug}",
                "success",
            )
            self.update_all_btn.setEnabled(
                bool(updates or theme_updates or addon_updates)
            )
            access = (
                "write (owner)" if writable else "read-only"
                if writable is not None
                else "unknown"
            )
            self._log(
                f"Catalog: {len(plugins)} plugin(s), {len(themes)} theme(s), "
                f"{len(addons)} addon(s), {len(installed)} plugins installed, "
                f"{len(updates)} plugin update(s), {len(theme_updates)} theme "
                f"update(s), {len(addon_updates)} addon update(s); access: {access}."
            )

        self._start("Refreshing marketplace...", operation, done)

    # -- installed / list ------------------------------------------------
    def load_installed(self):
        market = self._marketplace()
        try:
            self.installed = market.installed_plugins() if market else {}
        except Exception:
            self.installed = {}
        try:
            self.installed_themes = market.installed_themes() if market else {}
        except Exception:
            self.installed_themes = {}
        try:
            self.installed_addons = market.installed_addons() if market else {}
        except Exception:
            self.installed_addons = {}

    def _kind_changed(self):
        self._rebuild_categories()
        self.display_plugins()
        self._update_buttons()

    def _rebuild_categories(self):
        current = self.category.currentText() or "All Categories"
        categories = sorted(
            {
                str(plugin.get("category") or "other")
                for plugin in self._items()
                if plugin.get("category")
            }
        )
        self.category.blockSignals(True)
        self.category.clear()
        self.category.addItem("All Categories")
        for item in categories:
            self.category.addItem(item)
        index = self.category.findText(current)
        self.category.setCurrentIndex(max(index, 0))
        self.category.blockSignals(False)

    def display_plugins(self):
        self.plugin_list.clear()
        category = self.category.currentText()
        search = self.search.text().strip().lower()
        for plugin in self._items():
            if category and category != "All Categories":
                if str(plugin.get("category")) != category:
                    continue
            if search:
                haystack = " ".join(
                    str(plugin.get(key, ""))
                    for key in ("id", "name", "description", "author")
                ).lower()
                if search not in haystack:
                    continue
            installed = self._installed_for(plugin)
            update = self._updates_for(plugin)
            label = f"{plugin.get('name', plugin['id'])}  v{plugin.get('version')}"
            if self._is_theme(plugin):
                label = "Theme · " + label
            elif self._is_addon(plugin):
                label = "Addon · " + label
            if installed:
                label += f"  · installed v{installed['version']}"
            if update:
                label += "  · update available"
            item = QListWidgetItem(label)
            item.setData(Qt.UserRole, plugin)
            item.setToolTip(plugin.get("description", ""))
            if update:
                item.setIcon(
                    QApplication.style().standardIcon(QStyle.SP_BrowserReload)
                )
            elif installed:
                item.setIcon(
                    QApplication.style().standardIcon(QStyle.SP_DialogApplyButton)
                )
            else:
                item.setIcon(
                    QApplication.style().standardIcon(QStyle.SP_FileIcon)
                )
            self.plugin_list.addItem(item)
        if self.plugin_list.count() == 0:
            placeholder = QListWidgetItem("No plugins match the current filter")
            placeholder.setFlags(Qt.NoItemFlags)
            self.plugin_list.addItem(placeholder)

    def _is_theme(self, item) -> bool:
        return isinstance(item, dict) and (
            item.get("kind") == "theme" or item.get("type") == "theme"
        )

    def _is_addon(self, item) -> bool:
        return isinstance(item, dict) and (
            item.get("kind") == "addon" or item.get("type") == "addon"
        )

    def _items(self):
        kind = self.kind_filter.currentText()
        if kind == "Themes":
            return self.themes
        if kind == "Addons":
            return self.addons
        return self.plugins

    def _installed_for(self, item):
        if self._is_theme(item):
            return self.installed_themes.get(item["id"])
        if self._is_addon(item):
            return self.installed_addons.get(item["id"])
        return self.installed.get(item["id"])

    def _updates_for(self, item):
        if self._is_theme(item):
            return self.theme_updates.get(item["id"])
        if self._is_addon(item):
            return self.addon_updates.get(item["id"])
        return self.updates.get(item["id"])

    def _selected_plugin(self):
        item = self.plugin_list.currentItem()
        if item is None:
            return None
        data = item.data(Qt.UserRole)
        return data if isinstance(data, dict) else None

    def _selection_changed(self, current, _previous):
        plugin = current.data(Qt.UserRole) if current else None
        if not isinstance(plugin, dict):
            self.details.clear()
            self.version_combo.clear()
            self._update_buttons()
            return
        self.details.setHtml(self._details_html(plugin))
        self._populate_versions(plugin)
        self._update_buttons()

    def _populate_versions(self, plugin):
        current = self.version_combo.currentData()
        self.version_combo.clear()
        versions = list(plugin.get("versions") or [])
        if not versions and plugin.get("version"):
            versions = [{"version": plugin.get("version")}]
        for item in reversed(versions):
            version = str(item.get("version") or "")
            if not version:
                continue
            label = version
            published = str(item.get("published") or "")
            if published:
                label += f"  ({published[:10]})"
            self.version_combo.addItem(label, version)
        if current:
            index = self.version_combo.findData(current)
            if index >= 0:
                self.version_combo.setCurrentIndex(index)

    def _details_html(self, plugin) -> str:
        installed = self._installed_for(plugin)
        update = self._updates_for(plugin)
        status = "Not installed"
        if installed:
            status = f"Installed v{installed['version']}"
            if update:
                status += f" — update to v{update['new_version']} available"
        price = (
            "Free"
            if float(plugin.get("price") or 0) <= 0
            else f"{plugin.get('currency', 'USD')} {plugin.get('price')}"
        )
        deps = ", ".join(plugin.get("dependencies") or []) or "none"
        versions = plugin.get("versions") or []
        version_rows = "".join(
            "<tr>"
            f"<td>{html.escape(str(item.get('version')))}</td>"
            f"<td>{html.escape(str(item.get('published') or ''))}</td>"
            f"<td>{int(item.get('size') or 0) // 1024} KiB</td>"
            "<td>"
            + (
                html.escape(str(item.get("changelog") or ""))
                if item.get("changelog")
                else ""
            )
            + "</td></tr>"
            for item in reversed(versions)
        )
        homepage = plugin.get("homepage") or ""
        homepage_html = (
            f'<p><a href="{html.escape(homepage)}">{html.escape(homepage)}</a></p>'
            if homepage
            else ""
        )
        addon_html = ""
        if self._is_addon(plugin):
            capabilities = ", ".join(plugin.get("capabilities") or []) or "none declared"
            addon_html = (
                f"<p><b>Addon API:</b> {int(plugin.get('api_version', 1) or 1)}<br>"
                f"<b>Capabilities:</b> {html.escape(capabilities)}</p>"
            )
        return f"""
        <h2>{html.escape(str(plugin.get('name', plugin['id'])))}</h2>
        <p><b>id:</b> {html.escape(str(plugin['id']))}<br>
        <b>Kind:</b> {'Theme' if self._is_theme(plugin) else 'Addon' if self._is_addon(plugin) else 'Plugin'}<br>
        <b>Version:</b> {html.escape(str(plugin.get('version', '')))}<br>
        <b>Author:</b> {html.escape(str(plugin.get('author', '')))}<br>
        <b>Category:</b> {html.escape(str(plugin.get('category', '')))}<br>
        <b>Status:</b> {html.escape(status)}<br>
        <b>Preview:</b> {html.escape(str(plugin.get('preview_color', '')))}<br>
        <b>Price:</b> {html.escape(price)}<br>
        <b>Dependencies:</b> {html.escape(deps)}</p>
        {addon_html}
        <p>{html.escape(str(plugin.get('description', '')))}</p>
        {homepage_html}
        <h3>Versions</h3>
        <table cellspacing="0" cellpadding="4" border="0">
          <tr><th align="left">Version</th><th align="left">Published</th>
              <th align="left">Size</th><th align="left">Changelog</th></tr>
          {version_rows}
        </table>
        """

    def _update_buttons(self):
        plugin = self._selected_plugin()
        if plugin is None:
            for button in (
                self.install_btn,
                self.update_btn,
                self.uninstall_btn,
                self.info_btn,
            ):
                button.setEnabled(False)
            return
        installed = self._installed_for(plugin)
        update = self._updates_for(plugin)
        is_theme = self._is_theme(plugin)
        is_addon = self._is_addon(plugin)
        is_self = not is_theme and not is_addon and plugin.get("id") == "git_plugin_marketplace"
        is_protected = bool(
            not is_theme and not is_addon and installed and installed.get("source") != "user"
        )
        self.info_btn.setEnabled(True)
        self.install_btn.setEnabled(not installed and not is_self)
        self.update_btn.setEnabled(bool(update) and not is_protected and not is_self)
        # Never uninstall a plugin bundled with QAH.
        self.uninstall_btn.setEnabled(
            bool(
                installed
                and not is_self
                and (is_theme or is_addon or installed.get("source") == "user")
            )
        )
        self.install_version_btn.setEnabled(
            bool(self.version_combo.count()) and not is_protected and not is_self
        )
        if is_self:
            tip = (
                "Git Plugin Marketplace cannot update or remove itself while it is "
                "running. Use the system Plugin Marketplace or QAH's ZIP importer, "
                "or update it with QAH closed."
            )
            for button in (
                self.install_btn,
                self.update_btn,
                self.uninstall_btn,
                self.install_version_btn,
            ):
                button.setToolTip(tip)
        elif is_protected:
            source = str((installed or {}).get("source") or "managed")
            self.install_version_btn.setToolTip(
                f"This {source} plugin is managed outside the marketplace installer; "
                "it is protected from shadowing or blocking."
            )
        else:
            self.install_version_btn.setToolTip(
                "Install a specific version, including an older release. It "
                "replaces the current user plugin copy."
            )

    def _double_clicked(self, item):
        plugin = item.data(Qt.UserRole)
        if not isinstance(plugin, dict):
            return
        if self._installed_for(plugin):
            if self._updates_for(plugin):
                self.update_selected()
        else:
            self.install_selected()

    # -- actions ---------------------------------------------------------
    def install_selected(self):
        plugin = self._selected_plugin()
        if plugin:
            if self._is_theme(plugin):
                self._install_theme(plugin, update=False)
            elif self._is_addon(plugin):
                self._install_addon(plugin, update=False)
            else:
                self._install(plugin, update=False)

    def update_selected(self):
        plugin = self._selected_plugin()
        if plugin:
            if self._is_theme(plugin):
                self._install_theme(plugin, update=True)
            elif self._is_addon(plugin):
                self._install_addon(plugin, update=True)
            else:
                self._install(plugin, update=True)

    def install_selected_version(self):
        plugin = self._selected_plugin()
        if not plugin:
            return
        version = str(self.version_combo.currentData() or "")
        if not version:
            QMessageBox.information(
                self, "No version", "Select a version to install."
            )
            return
        if self._is_theme(plugin):
            self._install_theme(plugin, update=False, version=version)
        elif self._is_addon(plugin):
            self._install_addon(plugin, update=False, version=version)
        else:
            self._install(plugin, update=False, version=version)

    def _install_theme(self, theme, *, update: bool = False, version: Optional[str] = None):
        market = self._marketplace()
        if market is None:
            self.open_settings()
            return
        target_version = version or theme.get("version")
        action = "Update" if update else ("Reinstall" if self._installed_for(theme) else "Install")
        if version:
            action = f"Install version {version}"
        answer = QMessageBox.question(
            self,
            f"{action} theme",
            f"{action} theme {theme.get('name')} v{target_version}?\n\n"
            "It will be written to your user theme directory and Theme Manager "
            "will be refreshed.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes,
        )
        if answer != QMessageBox.Yes:
            return

        def operation(progress):
            return market.install_theme(theme["id"], version=version, progress=progress)

        def done(result):
            self._log(f"Theme installed: {result.get('id')} {result.get('version')}")
            self.load_installed()
            self.display_plugins()
            self._refresh_updates()
            self._refresh_theme_manager()
            self._rescan_qah()

        self._start(f"{action} theme {theme['id']}...", operation, done)

    def _install_addon(self, addon, *, update: bool = False, version: Optional[str] = None):
        market = self._marketplace()
        if market is None:
            self.open_settings()
            return
        target_version = version or addon.get("version")
        installed = self._installed_for(addon)
        action = "Update" if update else ("Reinstall" if installed else "Install")
        if version:
            action = f"Install version {version}"
        capabilities = ", ".join(addon.get("capabilities") or []) or "none declared"
        answer = QMessageBox.question(
            self,
            f"{action} Sentinel addon",
            f"{action} Sentinel addon {addon.get('name')} v{target_version}?\n\n"
            f"Capabilities: {capabilities}\n"
            f"Addon API: {addon.get('api_version', 1)}\n\n"
            "It is installed for Plugin Sentinel's Addons tab and only runs "
            "inside Sentinel's sandboxed addon host.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes,
        )
        if answer != QMessageBox.Yes:
            return

        def operation(progress):
            return market.install_addon(addon["id"], version=version, progress=progress)

        def done(target):
            self._log(f"{action} complete: {target}")
            self.load_installed()
            self.display_plugins()
            self._refresh_updates()
            self._refresh_sentinel_addons()

        self._start(f"{action} addon {addon['id']}...", operation, done)

    def _install(self, plugin, *, update: bool, version: Optional[str] = None):
        market = self._marketplace()
        if market is None:
            self.open_settings()
            return
        if plugin.get("id") == "git_plugin_marketplace":
            self._block_self_update()
            return
        installed = self.installed.get(plugin["id"])
        if installed and installed.get("source") != "user":
            source = str(installed.get("source") or "managed")
            QMessageBox.information(
                self,
                "Protected plugin",
                f"{plugin.get('name')} is a {source} plugin. It is managed outside "
                "the marketplace installer, so installing a user copy here could "
                "shadow or block it. Use the matching manager for that plugin.",
            )
            return
        target_version = version or plugin.get("version")
        action = "Update" if update else ("Reinstall" if installed else "Install")
        if version:
            action = f"Install version {version}"
        answer = QMessageBox.question(
            self,
            f"{action} plugin",
            f"{action} for {plugin.get('name')} v{target_version}?\n\n"
            "The plugin is downloaded from the configured Git repository and "
            "extracted into your user plugin folder. An existing user copy is "
            "replaced.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes,
        )
        if answer != QMessageBox.Yes:
            return

        def operation(progress):
            return market.install_plugin(
                plugin["id"], version=version, progress=progress
            )

        def done(target):
            self._log(f"{action} complete: {target}")
            self.load_installed()
            self.display_plugins()
            self._refresh_updates()
            self._rescan_qah()
            self._reload_plugin_after_install(plugin["id"])

        self._start(f"{action} {plugin['id']}...", operation, done)

    def uninstall_selected(self):
        plugin = self._selected_plugin()
        if not plugin:
            return
        market = self._marketplace()
        if market is None:
            return
        is_theme = self._is_theme(plugin)
        is_addon = self._is_addon(plugin)
        if plugin.get("id") == "git_plugin_marketplace" and not is_theme and not is_addon:
            self._block_self_update()
            return
        answer = QMessageBox.question(
            self,
            "Uninstall theme" if is_theme else "Uninstall addon" if is_addon else "Uninstall plugin",
            (
                f"Remove theme {plugin.get('name')} from your user theme folder?"
                if is_theme
                else f"Remove Sentinel addon {plugin.get('name')} from your addon folder?"
                if is_addon
                else f"Remove {plugin.get('name')} from your user plugin folder?\n\n"
                "Close QAH first if the plugin has loaded native libraries."
            ),
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return

        def operation(_progress):
            if is_theme:
                return market.uninstall_theme(plugin["id"])
            if is_addon:
                return market.uninstall_addon(plugin["id"])
            return market.uninstall_plugin(plugin["id"])

        def done(message):
            self._log(message)
            self.load_installed()
            self.display_plugins()
            self._refresh_updates()
            if is_theme:
                self._refresh_theme_manager()
            if is_addon:
                self._refresh_sentinel_addons()
            self._rescan_qah()

        self._start(f"Uninstalling {plugin['id']}...", operation, done)

    def _block_self_update(self):
        self._status("Self-update blocked", "error")
        QMessageBox.warning(
            self,
            "Git Plugin Marketplace cannot update itself",
            "The running Git Plugin Marketplace is protected from replacing or "
            "removing its own folder.\n\n"
            "It will never install, downgrade or uninstall itself while it is "
            "running, so a failed or incompatible update cannot damage the copy "
            "you are using.\n\n"
            "To update it, use one of these safe routes:\n"
            "• QAH's system Plugin Marketplace,\n"
            "• QAH's manual ZIP importer,\n"
            "• install it with QAH closed.\n\n"
            "Other plugins, themes and Sentinel addons can still be updated "
            "normally from this tab.",
        )

    def update_all(self):
        market = self._marketplace()
        if market is None:
            return
        plugin_updates = [
            item
            for item in self.updates.values()
            if (self.installed.get(item["plugin"]["id"]) or {}).get("source") == "user"
            and item["plugin"]["id"] != "git_plugin_marketplace"
        ]
        theme_updates = list(self.theme_updates.values())
        addon_updates = list(self.addon_updates.values())
        total = len(plugin_updates) + len(theme_updates) + len(addon_updates)
        if not total:
            QMessageBox.information(
                self,
                "Update all",
                "No user-plugin, theme or addon updates are available.\n\n"
                "System and wheel plugins are managed by their own installers, "
                "and Git Plugin Marketplace never updates itself while running.",
            )
            return
        answer = QMessageBox.question(
            self,
            "Update all",
            f"Install {total} update(s)?\n\n"
            f"• {len(plugin_updates)} user plugin(s)\n"
            f"• {len(theme_updates)} theme(s)\n"
            f"• {len(addon_updates)} Sentinel addon(s)\n\n"
            "Git Plugin Marketplace itself is excluded and protected.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes,
        )
        if answer != QMessageBox.Yes:
            return

        def operation(progress):
            done = []
            for item in plugin_updates:
                plugin = item["plugin"]
                progress(
                    f"Updating {plugin['id']} "
                    f"{item['current_version']} -> {item['new_version']}..."
                )
                try:
                    market.install_plugin(plugin["id"], progress=progress)
                    done.append(plugin["id"])
                except Exception as exc:
                    progress(f"  failed: {exc}")
            for item in theme_updates:
                theme = item["theme"]
                progress(
                    f"Updating theme {theme['id']} "
                    f"{item['current_version']} -> {item['new_version']}..."
                )
                try:
                    market.install_theme(theme["id"], progress=progress)
                    done.append(theme["id"])
                except Exception as exc:
                    progress(f"  failed: {exc}")
            for item in addon_updates:
                addon = item["addon"]
                progress(
                    f"Updating addon {addon['id']} "
                    f"{item['current_version']} -> {item['new_version']}..."
                )
                try:
                    market.install_addon(addon["id"], progress=progress)
                    done.append(addon["id"])
                except Exception as exc:
                    progress(f"  failed: {exc}")
            return done

        def done(updated):
            self._log(f"Updated {len(updated)} asset(s).")
            self.load_installed()
            self.display_plugins()
            self._refresh_updates()
            if theme_updates:
                self._refresh_theme_manager()
            if addon_updates:
                self._refresh_sentinel_addons()
            self._rescan_qah()

        self._start("Updating all assets...", operation, done)

    def _refresh_updates(self):
        market = self._marketplace()
        if market is None:
            return
        try:
            self.updates = market.check_updates()
        except Exception:
            self.updates = {}
        try:
            self.theme_updates = market.check_theme_updates()
        except Exception:
            self.theme_updates = {}
        try:
            self.addon_updates = market.check_addon_updates()
        except Exception:
            self.addon_updates = {}
        self.update_all_btn.setEnabled(
            bool(self.updates or self.theme_updates or self.addon_updates)
        )

    def publish_plugin(self, folder: Optional[str] = None):
        market = self._marketplace()
        if market is None:
            self.open_settings()
            return
        dialog = PublishDialog(
            self,
            initial_folder=folder,
            default_pr=not bool(self.writable),
        )
        if dialog.exec() != PublishDialog.Accepted:
            return
        data = dialog.data()

        if dialog.submit_as_pr():
            def operation(progress):
                return market.submit_pull_request(
                    data["folder"],
                    version=data["version"],
                    changelog=data["changelog"],
                    homepage=data["homepage"],
                    metadata=data.get("metadata"),
                    progress=progress,
                )

            def done(result):
                url = result.get("pr_url", "")
                self._log(
                    f"Pull request #{result.get('pr_number')} created: {url}"
                )
                self._log(f"Fork {result.get('fork')} branch {result.get('branch')}")
                self._status("Pull request opened", "success")
                QMessageBox.information(
                    self,
                    "Pull request created",
                    f"Pull request #{result.get('pr_number')} was opened.\n\n"
                    f"{url}\n\nThe repository owner must review and merge it.",
                )
                if url:
                    QDesktopServices.openUrl(QUrl(url))

            self._start(
                f"Submitting {Path(data['folder']).name} as a pull request...",
                operation,
                done,
            )
            return

        def operation(progress):
            return market.publish_plugin(
                data["folder"],
                version=data["version"],
                changelog=data["changelog"],
                homepage=data["homepage"],
                metadata=data.get("metadata"),
                progress=progress,
            )

        def done(result):
            self._log(
                f"Published {result['id']} {result['version']} "
                f"(commit {str(result.get('commit', ''))[:12]})"
            )
            self._status("Published successfully", "success")
            # Let the publish thread finish before starting the refresh task.
            QTimer.singleShot(250, lambda: self.refresh(force=True))

        self._start(f"Publishing {Path(data['folder']).name}...", operation, done)

    def delete_plugin(self, plugin):
        market = self._marketplace()
        if market is None:
            return
        if (
            plugin.get("id") == "git_plugin_marketplace"
            and not self._is_theme(plugin)
            and not self._is_addon(plugin)
        ):
            self._status("Delete blocked", "error")
            QMessageBox.warning(
                self,
                "Cannot delete the running marketplace",
                "Git Plugin Marketplace will not delete its own catalog entry from "
                "its own UI. This protects the copy you are using and the catalog "
                "entry that other users install from.\n\n"
                "Use the CLI or GitHub if you really intend to remove it.",
            )
            return
        box = QMessageBox(self)
        box.setWindowTitle("Delete from marketplace")
        box.setText(
            f"Delete {plugin.get('name')} from the Git catalog?\n\n"
            "Git history keeps old commits, but the plugin disappears from the "
            "marketplace for everyone."
        )
        version = str(plugin.get("version") or "")
        version_button = box.addButton(
            f"Delete version {version}", QMessageBox.DestructiveRole
        )
        all_button = box.addButton(
            "Delete all versions", QMessageBox.DestructiveRole
        )
        box.addButton(QMessageBox.Cancel)
        box.exec()
        clicked = box.clickedButton()
        if clicked not in (version_button, all_button):
            return
        target_version = version if clicked is version_button else None
        answer = QMessageBox.question(
            self,
            "Confirm deletion",
            "This cannot be undone from the plugin. Continue?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return

        def operation(progress):
            return market.delete_plugin(
                plugin["id"], target_version, progress=progress
            )

        def done(result):
            self._log(
                f"Deleted {result['id']} "
                f"{result.get('version') or '(all versions)'} "
                f"(commit {str(result.get('commit', ''))[:12]})"
            )
            self.refresh(force=True)

        self._start(f"Deleting {plugin['id']}...", operation, done)

    def show_info(self):
        plugin = self._selected_plugin()
        if not plugin:
            return
        text = json.dumps(plugin, indent=2)
        dialog = QMessageBox(self)
        dialog.setWindowTitle(f"Info: {plugin.get('name')}")
        dialog.setTextInteractionFlags(Qt.TextSelectableByMouse)
        dialog.setText(text[:6000])
        dialog.exec()

    def open_repo(self):
        config = self._config()
        if config.web_url:
            QDesktopServices.openUrl(QUrl(config.web_url))
        else:
            self.open_settings()

    def open_settings(self):
        market = self._marketplace()
        config = market.config if market else core.load_config(self._plugin_config())
        dialog = SettingsDialog(self, config=config)
        if dialog.exec() != SettingsDialog.Accepted:
            return
        new_config = dialog.config()
        try:
            core.save_config(new_config, remember_token=dialog.remember_token())
        except Exception as exc:
            QMessageBox.critical(self, "Settings", f"Could not save settings: {exc}")
            return
        self.plugin.reload_marketplace()
        if not dialog.remember_token() and new_config.token:
            # Keep the typed token for this session even when it is not saved.
            market = getattr(self.plugin, "marketplace", None)
            if market is not None:
                market.config.token = new_config.token
                market.client.token = new_config.token
        self._refresh_header()
        self._log(f"Repository set to {new_config.slug} (branch {new_config.branch}).")
        self.refresh(force=True)

    # -- context menu ----------------------------------------------------
    def _context_menu(self, position):
        item = self.plugin_list.itemAt(position)
        if item is None:
            return
        plugin = item.data(Qt.UserRole)
        if not isinstance(plugin, dict):
            return
        menu = QMenu(self)
        install = menu.addAction("Install / Update")
        uninstall = menu.addAction("Uninstall")
        menu.addSeparator()
        info = menu.addAction("Info")
        copy_id = menu.addAction("Copy plugin id")
        delete = menu.addAction("Delete from marketplace...")
        menu.addSeparator()
        open_repo = menu.addAction("Open repository")

        installed = self._installed_for(plugin)
        is_theme = self._is_theme(plugin)
        is_addon = self._is_addon(plugin)
        is_self = not is_theme and not is_addon and plugin.get("id") == "git_plugin_marketplace"
        install.setEnabled(bool(plugin["id"] not in self._installed_for(plugin)) and not is_self)
        uninstall.setEnabled(
            bool(
                installed
                and not is_self
                and (is_theme or is_addon or installed.get("source") == "user")
            )
        )
        delete.setEnabled(bool(self._config().slug))
        action = menu.exec(self.plugin_list.mapToGlobal(position))
        if action is install:
            self.install_selected()
        elif action is uninstall:
            self.uninstall_selected()
        elif action is info:
            self.show_info()
        elif action is copy_id:
            QApplication.clipboard().setText(plugin["id"])
            self._log(f"Copied id: {plugin['id']}")
        elif action is delete:
            self.delete_plugin(plugin)
        elif action is open_repo:
            self.open_repo()

    # -- QAH integration -------------------------------------------------
    def _plugin_manager(self):
        for widget in QApplication.topLevelWidgets():
            manager = getattr(widget, "plugin_manager", None)
            if manager is not None and hasattr(manager, "plugins"):
                return manager
        return None

    def _refresh_theme_manager(self):
        manager = self._plugin_manager()
        if manager is None:
            return
        plugin = manager.get_plugin("theme_manager") if hasattr(manager, "get_plugin") else None
        if plugin is None:
            return
        widget = getattr(plugin, "ui_widget", None)
        if widget is not None and hasattr(widget, "load_themes"):
            try:
                widget.load_themes()
                self._log("Theme Manager refreshed.")
            except Exception as exc:
                self._log(f"[Warning] Could not refresh Theme Manager: {exc}")

    def _refresh_sentinel_addons(self):
        manager = self._plugin_manager()
        if manager is None:
            return
        plugin = manager.get_plugin("plugin_sentinel") if hasattr(manager, "get_plugin") else None
        if plugin is None:
            return
        widget = getattr(plugin, "ui_widget", None)
        if widget is not None and hasattr(widget, "load_addons"):
            try:
                widget.load_addons()
                self._log("Plugin Sentinel Addons tab refreshed.")
            except Exception as exc:
                self._log(f"[Warning] Could not refresh Sentinel addons: {exc}")

    def _reload_plugin_after_install(self, plugin_id: str):
        manager = self._plugin_manager()
        if manager is None:
            return
        if plugin_id == "git_plugin_marketplace":
            self._log("Restart QAH to use the updated Git Plugin Marketplace.")
            return
        loaded = getattr(manager, "loaded_plugins", {}) or {}
        if plugin_id not in loaded:
            return
        info = (getattr(manager, "plugins", {}) or {}).get(plugin_id)
        source = str(getattr(info, "source", "") or "")
        if source != "user":
            self._log(f"{plugin_id} is not a user plugin; restart QAH to load the update.")
            return
        answer = QMessageBox.question(
            self,
            "Plugin updated",
            f"{getattr(info, 'name', plugin_id)} is currently loaded. QAH is still "
            "running the old code.\n\nReload it now?\n\n"
            "If it uses native libraries, choose 'No' and restart QAH instead.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            self._log("Update staged; restart QAH or reopen the plugin later.")
            return
        try:
            manager.unload_plugin(plugin_id)
            manager.load_plugin(plugin_id)
            self._log(f"Reloaded user plugin: {plugin_id}")
        except Exception as exc:
            self._log(f"[Warning] Could not reload {plugin_id}: {exc}")
            QMessageBox.information(
                self,
                "Reload failed",
                "Restart QAH to load the updated plugin.",
            )

    def _rescan_qah(self):
        try:
            from plugins.libs.plugin_manager import PluginManager  # type: ignore

            try:
                PluginManager().scan_plugins()
            except Exception:
                pass
        except Exception:
            pass
        try:
            for widget in QApplication.topLevelWidgets():
                manager = getattr(widget, "plugin_manager", None)
                if manager is None:
                    continue
                try:
                    if hasattr(widget, "_scan_plugins"):
                        widget._scan_plugins()
                    else:
                        manager.scan_plugins()
                    self._log("QAH plugin list rescanned.")
                    return
                except Exception as exc:
                    self._log(f"[Warning] QAH rescan failed: {exc}")
        except Exception:
            pass
        self._log("Restart QAH if the new plugin does not appear in the menu.")

    def cleanup(self):
        task = self._task
        if task is not None and task.isRunning():
            # Let the worker outlive the widget instead of destroying a running
            # QThread when QAH closes.
            task.setParent(None)
            task.finished.connect(task.deleteLater)
            self._task = None
