# Agent notes — post_process_plotter VASP layer

Working notes for the next agent. User-facing documentation is
`docs/documentation.tex`; this file is intentionally ignored by git.

## Status at 2026-11-12

- `vasp_charge.py` (pure Python) reads CHGCAR/LOCPOT/PARCHG/ELFCAR, writes
  CHGCAR and cube, and computes planar/macroscopic averages, vacuum levels,
  work function/IP, integration and interpolation.
- `vasp_charge_widget.py` is the "VASP Charge" tab.
- Tests: `test_vasp_charge.py` — synthetic files plus the real 934 MB CHGCAR
  and four LOCPOTs.
- Published 1.1.1 (commit `a81e7bf`) and installed locally. 1.1.1 is the one
  with the real-CHGCAR augmentation fix; 1.1.0 mis-parsed augmentation
  sections (it assumed one record per line).

## VASP format facts learned the hard way

1. **Blank line before the grid line.** After the ion coordinates there is an
   empty line, then `nx ny nz`. Never index the grid line as `8 + nions`.
2. **Augmentation sections are flat value arrays**, not one record per line:
   ```
   augmentation occupancies   1  33
     0.73490E+00 0.19516E+00 ...      (5 values per line, 33 values total)
   ```
   The last number on the header is the *number of values*, not the number of
   lines. There is one section per ion with augmentation data (432 in the
   Ti144O288 case).
3. **VASP 4 vs 5 headers.** Line 6 is either the species list or the counts.
   Test whether every token is an integer.
4. **Selective dynamics.** "Selective dynamics" is an extra line before
   "Direct"; coordinate lines then carry three flags.
5. **Spin-polarised CHGCAR** repeats the whole structure (grid + data +
   augmentation) for the magnetization block.
6. **`np.fromfile(handle, dtype=float, count=n, sep=" ")`** is the right
   primitive for huge text arrays: C-speed, exact count, no giant Python list.
   It **consumes trailing whitespace**, so do *not* call `readline()` after it
   to "finish the line" — the next readline already returns the augmentation
   header or the next grid line. (This cost an hour.)
7. **Units.** CHGCAR stores rho·V_cell: `sum(values)/npoints` = electrons,
   `value/volume` = e/Å³. LOCPOT is eV. ELFCAR is 0–1. Cube is bohr with
   e/bohr³ (density) or Hartree (potential).
8. **Array order.** VASP writes x fastest → reshape `(nz, ny, nx)`. Physical
   axis a is array axis 2, b is 1, c is 0. Do not average over the wrong axis.
9. **Non-orthogonal cells.** The grid is fractional; the plane spacing is
   `V/|b×c| / n`. The Ti144O288 cell is strongly non-orthogonal.
10. **Writing.** `np.savetxt` per block is memory-safe; building one string for
    53.8 M values is not.

## Validation anchors

- `vasp/analysis/work_function.py` is the reference implementation for LOCPOT.
  My planar average matches it exactly (max |Δ| = 0.0) and φ/IP match to
  1e-12 for four slabs.
- Ti144O288 CHGCAR: electrons 3456.000004 vs NELECT 3456.
- The 934 MB file takes ~38 s to read and 457 MB peak (float64); use
  `read_vasp_field(..., dtype=np.float32)` when only visualization matters.

## Decisions

- No Perl, no VTST dependency, no code copied. VTST scripts were used as a
  behavioural oracle only (see the citation section in the LaTeX docs).
- VTST's `chgsum.pl`/`chgdiff.pl` drop augmentation data and assume five
  values per line; this implementation keeps the file VASP-readable.
- `chgparavg.pl` is *not* a planar average (it averages two CHGCARs); the real
  planar average is a two-line NumPy reduction.
- No Bader implementation; if needed, detect the Henkelman `bader` binary and
  parse `ACF.dat` (C/Fortran, not Perl).

## Commands

```bash
python3 vasp_charge.py info FILE
python3 vasp_charge.py avg FILE --axis c --csv out.csv
python3 vasp_charge.py workfunction LOCPOT
python3 vasp_charge.py cube CHGCAR out.cube
python3 test_vasp_charge.py
TIO2_SN_VASP=~/TiO2-Sn/vasp python3 test_vasp_charge.py
```

Qt smoke test (no QAH needed):

```bash
PYTHONPATH=/usr/lib/regressionmaker/app_packages QT_QPA_PLATFORM=offscreen \
  python3 -c "import vasp_charge_widget as w; from PySide6.QtWidgets import QApplication; \
  app=QApplication([]); x=w.VaspChargeWidget(); x.load_path('LOCPOT'); print(len(x.canvas.figure.axes))"
```

## Pending

- 2D slices / isosurfaces in the tab.
- Bader import.
- QE/CP2K unification.
- Re-check `D old.zip` in `git status` before committing (pre-existing).
