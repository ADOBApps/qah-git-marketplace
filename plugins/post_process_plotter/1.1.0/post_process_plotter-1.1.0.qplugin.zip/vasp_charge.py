"""
VASP volumetric fields: read, write and analyse CHGCAR / LOCPOT / PARCHG / ELFCAR.

This is an independent Python implementation of the documented VASP file
formats. It replaces the Perl VTST helpers (chgsum.pl, chgdiff.pl, chg2cube.pl,
chgsplit.pl, chgvalue.pl) with a NumPy layer that:

* reads VASP 4/5/6 headers, blank lines and selective-dynamics flags;
* reads every data block (charge, magnetization, potential, ELF);
* keeps the augmentation-occupancy sections so a written file is still a
  VASP-compatible restart file;
* works on non-orthogonal cells (grid is fractional; planes use V/|b x c|);
* converts to Gaussian cube (bohr / e/bohr^3, or angstrom / e/A^3);
* computes planar and macroscopic averages, vacuum levels, work function and
  ionisation potential;
* integrates densities and interpolates values at arbitrary points.

No VTST code is copied. The Perl scripts are only used as a numerical oracle
when validating.

Units
-----
* CHGCAR / PARCHG store ``rho(r) * V_cell``; divide by ``|det A|`` for e/A^3 and
  ``sum(values)/N`` gives electrons.
* ELFCAR is dimensionless (0-1).
* LOCPOT stores the potential in eV.
* Gaussian cube is written in bohr with density in e/bohr^3 and potential in
  Hartree (the standard convention); ``units="angstrom"`` is available.

This file is part of QAH and is GPL-3.0-or-later.
"""

from __future__ import annotations

import argparse
import os
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

BOHR_TO_ANG = 0.529177210903
ANG_TO_BOHR = 1.0 / BOHR_TO_ANG
EV_TO_HARTREE = 1.0 / 27.211386245988

_ELEMENTS = (
    "H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co "
    "Ni Cu Zn Ga Ge As Se Br Kr Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb "
    "Te I Xe Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu Hf Ta W Re "
    "Os Ir Pt Au Hg Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U Np Pu Am Cm Bk Cf Es "
    "Fm Md No Lr Rf Db Sg Bh Hs Mt Ds Rg Cn Nh Fl Mc Lv Ts Og"
).split()
SYMBOL_TO_Z = {symbol: index + 1 for index, symbol in enumerate(_ELEMENTS)}

FIELD_KINDS = ("chgcar", "parchg", "elfcar", "locpot", "unknown")
DENSITY_KINDS = {"chgcar", "parchg", "elfcar"}


class VaspFieldError(ValueError):
    """Raised when a CHGCAR/LOCPOT-style file cannot be understood."""


def _text(line: bytes) -> str:
    return line.decode("utf-8", "replace").rstrip("\r\n")


def _is_int(token: bytes) -> bool:
    return re.fullmatch(rb"[+-]?\d+", token) is not None


def detect_kind(path: os.PathLike | str) -> str:
    """Guess the field type from the file name, then from its content."""
    name = Path(path).name.upper()
    if name.startswith("LOCPOT"):
        return "locpot"
    if name.startswith("PARCHG"):
        return "parchg"
    if name.startswith("ELFCAR"):
        return "elfcar"
    if name.startswith("CHGCAR"):
        return "chgcar"
    try:
        head = Path(path).read_bytes()[:4096].lower()
    except OSError:
        return "unknown"
    if b"locpot" in head or b"potential" in head:
        return "locpot"
    if b"elf" in head:
        return "elfcar"
    if b"charge density" in head:
        return "chgcar"
    return "unknown"


@dataclass
class VaspField:
    """A parsed VASP volumetric file (one or more data blocks)."""

    path: str
    kind: str
    comment: str
    cell: np.ndarray                      # 3x3, angstrom
    species: List[str]
    counts: List[int]
    coordinates: np.ndarray               # (nions, 3), as written (direct or cartesian)
    coordinate_mode: str                  # "direct" | "cartesian"
    scale: float
    grid: Tuple[int, int, int]            # (nx, ny, nz)
    blocks: List[np.ndarray]              # each (nz, ny, nx)
    block_labels: List[str] = field(default_factory=list)
    augmentation_raw: List[str] = field(default_factory=list)
    header_text: str = ""

    # -- basic properties -------------------------------------------------
    @property
    def natoms(self) -> int:
        return int(sum(self.counts))

    @property
    def npoints(self) -> int:
        return int(self.grid[0] * self.grid[1] * self.grid[2])

    @property
    def volume(self) -> float:
        return float(abs(np.linalg.det(self.cell)))

    @property
    def is_density(self) -> bool:
        return self.kind in DENSITY_KINDS

    @property
    def units(self) -> str:
        if self.kind == "locpot":
            return "eV (potential)"
        if self.kind == "elfcar":
            return "dimensionless (ELF)"
        return "rho * V_cell (divide by volume for e/A^3)"

    def block(self, index: int = 0) -> np.ndarray:
        if not self.blocks:
            raise VaspFieldError("No data block in this file.")
        if not -len(self.blocks) <= index < len(self.blocks):
            raise VaspFieldError(
                f"Block {index} out of range (file has {len(self.blocks)})."
            )
        return self.blocks[index]

    def density(self, index: int = 0) -> np.ndarray:
        """Physical density in e/A^3 (charge-like files only)."""
        if not self.is_density:
            raise VaspFieldError(f"{self.kind} is not a density field.")
        return self.block(index) / self.volume

    def electrons(self, index: int = 0) -> float:
        """Integral of the density over the cell (electron count)."""
        return float(self.block(index).sum() / self.npoints)

    def cartesian_coordinates(self) -> np.ndarray:
        if self.coordinate_mode == "direct":
            return self.coordinates @ self.cell
        return self.coordinates * self.scale

    def fractional_coordinates(self) -> np.ndarray:
        if self.coordinate_mode == "direct":
            return self.coordinates
        return (self.coordinates * self.scale) @ np.linalg.inv(self.cell)

    # -- geometry helpers -------------------------------------------------
    def plane_normal_length(self, axis: int) -> float:
        """Cell extent along the normal of the plane family (axis)."""
        return self.volume / self._plane_area(axis)

    def plane_spacing(self, axis: int) -> float:
        return self.plane_normal_length(axis) / self.grid[axis]

    def _plane_area(self, axis: int) -> float:
        if axis == 0:
            area = np.linalg.norm(np.cross(self.cell[1], self.cell[2]))
        elif axis == 1:
            area = np.linalg.norm(np.cross(self.cell[0], self.cell[2]))
        else:
            area = np.linalg.norm(np.cross(self.cell[0], self.cell[1]))
        if area <= 0:
            raise VaspFieldError("Degenerate cell vectors.")
        return float(area)


def _read_header(
    raw: bytes,
) -> Tuple[Dict, int, List[str]]:
    """Parse the POSCAR-like header. Returns (info, line_index, header_lines)."""
    lines = raw.splitlines(keepends=True)
    if len(lines) < 8:
        raise VaspFieldError("File is too short to be a VASP field.")

    cursor = 0

    def take() -> bytes:
        nonlocal cursor
        if cursor >= len(lines):
            raise VaspFieldError("Unexpected end of file in the header.")
        line = lines[cursor]
        cursor += 1
        return line

    take()                                      # comment
    scale = float(_text(take()).split()[0])
    cell = np.array(
        [[float(x) for x in _text(take()).split()[:3]] for _ in range(3)],
        dtype=float,
    ) * scale

    tokens = _text(take()).split()
    if tokens and all(re.fullmatch(r"[+-]?\d+", token) for token in tokens):
        species: List[str] = []
        counts = [int(token) for token in tokens]
    else:
        species = tokens
        counts = [int(token) for token in _text(take()).split()]

    line = _text(take()).strip()
    selective = line.lower().startswith("s")
    if selective:
        line = _text(take()).strip()
    if line.lower().startswith("d"):
        mode = "direct"
    elif line.lower().startswith(("c", "k")):
        mode = "cartesian"
    else:
        raise VaspFieldError(f"Unknown coordinate mode {line!r}.")

    natoms = int(sum(counts))
    coordinates = np.empty((natoms, 3), dtype=float)
    for index in range(natoms):
        parts = _text(take()).split()
        if len(parts) < 3:
            raise VaspFieldError(f"Bad coordinate line for atom {index + 1}.")
        coordinates[index] = [float(x) for x in parts[:3]]

    # The grid line is separated from the coordinates by blank lines.
    while cursor < len(lines) and not lines[cursor].strip():
        cursor += 1
    if cursor >= len(lines):
        raise VaspFieldError("Missing grid line.")

    info = {
        "scale": scale,
        "cell": cell,
        "species": species,
        "counts": counts,
        "coordinates": coordinates,
        "coordinate_mode": mode,
        "comment": _text(lines[0]).strip(),
    }
    # Everything before the grid line, verbatim.
    return info, cursor, [_text(line) for line in lines[:cursor]]


def _read_blocks(
    raw: bytes, start_index: int, header_line_count: int
) -> Tuple[List[Tuple[Tuple[int, int, int], np.ndarray]], List[str], str, int]:
    """Read every data block and its augmentation section.

    Returns ([(grid, array)], augmentation_raw, grid_line, line_index).
    """
    lines = raw.splitlines(keepends=True)
    cursor = start_index
    blocks: List[Tuple[Tuple[int, int, int], np.ndarray]] = []
    augmentations: List[str] = []
    grid_line = ""

    while True:
        if cursor >= len(lines):
            break
        if not lines[cursor].strip():
            cursor += 1
            continue
        tokens = lines[cursor].split()
        if len(tokens) < 3 or not all(_is_int(token) for token in tokens[:3]):
            break
        grid = (int(tokens[0]), int(tokens[1]), int(tokens[2]))
        grid_line = _text(lines[cursor])
        cursor += 1
        npoints = grid[0] * grid[1] * grid[2]

        start_byte = sum(len(line) for line in lines[:cursor])
        tail = raw[start_byte:]
        lowered = tail.lower()
        marker = lowered.find(b"augmentation")
        region = tail if marker < 0 else tail[:marker]

        values = np.fromstring(region, dtype=np.float64, sep=" ")
        if values.size < npoints:
            raise VaspFieldError(
                f"Grid {grid[0]}x{grid[1]}x{grid[2]} needs {npoints} values, "
                f"read {values.size}."
            )
        array = values[:npoints].reshape(grid[2], grid[1], grid[0])
        blocks.append((grid, array))

        if marker < 0:
            break

        # Augmentation occupancies: header line + one line per record. Keep the
        # raw text so a written file remains a valid VASP restart file.
        aug_start = start_byte + marker
        newline = raw.find(b"\n", aug_start)
        if newline < 0:
            break
        header_tokens = raw[aug_start:newline].split()
        try:
            records = int(header_tokens[-1])
        except (IndexError, ValueError):
            records = 0
        end = newline + 1
        for _ in range(records):
            next_newline = raw.find(b"\n", end)
            if next_newline < 0:
                end = len(raw)
                break
            end = next_newline + 1
        augmentations.append(raw[aug_start:end].decode("utf-8", "replace"))
        cursor = raw[:end].count(b"\n")

    return blocks, augmentations, grid_line, min(cursor, len(lines))


def read_vasp_field(path: os.PathLike | str) -> VaspField:
    """Read a CHGCAR, LOCPOT, PARCHG or ELFCAR file."""
    path = Path(path)
    raw = path.read_bytes()
    if not raw:
        raise VaspFieldError(f"{path.name} is empty.")

    info, grid_index, header_lines = _read_header(raw)
    blocks, augmentations, grid_line, _ = _read_blocks(
        raw, grid_index, len(header_lines)
    )
    if not blocks:
        raise VaspFieldError(f"No volumetric data found in {path.name}.")

    grid = blocks[0][0]
    arrays = [array for _, array in blocks]
    kind = detect_kind(path)
    labels = ["Total"] if kind != "chgcar" or len(arrays) == 1 else ["Total", "Magnetization"]
    if len(arrays) > len(labels):
        labels += [f"Block {index + 1}" for index in range(len(labels), len(arrays))]

    header_text = "\n".join(header_lines) + "\n" + grid_line + "\n"
    return VaspField(
        path=str(path),
        kind=kind,
        comment=info["comment"],
        cell=info["cell"],
        species=info["species"],
        counts=info["counts"],
        coordinates=info["coordinates"],
        coordinate_mode=info["coordinate_mode"],
        scale=info["scale"],
        grid=grid,
        blocks=arrays,
        block_labels=labels,
        augmentation_raw=augmentations,
        header_text=header_text,
    )


# -- analysis ---------------------------------------------------------------

def planar_average(
    data: VaspField, block: int = 0, axis: int = 2
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Average over the planes normal to ``axis`` (0=a, 1=b, 2=c).

    Returns ``(fractional_centres, distance_angstrom, average)``.
    """
    # The array is (nz, ny, nx) because VASP writes x fastest. Physical axis a
    # therefore lives on array axis 2, b on 1 and c on 0.
    array = data.block(block)
    if axis == 0:
        values = array.mean(axis=(0, 1))
    elif axis == 1:
        values = array.mean(axis=(0, 2))
    else:
        values = array.mean(axis=(1, 2))
    n = values.size
    spacing = data.plane_spacing(axis)
    distance = (np.arange(n) + 0.5) * spacing
    fractional = (np.arange(n) + 0.5) / n
    return fractional, distance, values


def macroscopic_average(values: np.ndarray, window: int = 3) -> np.ndarray:
    """Periodic moving average (the macroscopic average of the literature)."""
    window = max(1, int(window))
    if window == 1 or values.size == 0:
        return np.asarray(values, dtype=float)
    kernel = np.ones(window, dtype=float) / window
    padded = np.concatenate([values[-window:], values, values[:window]])
    smoothed = np.convolve(padded, kernel, mode="same")
    return smoothed[window : window + values.size]


def _ion_positions(data: VaspField, axis: int) -> np.ndarray:
    fractional = data.fractional_coordinates()
    return fractional[:, axis] * data.plane_normal_length(axis)


def vacuum_levels(
    data: VaspField,
    block: int = 0,
    axis: int = 2,
    margin: float = 1.5,
) -> Dict[str, float]:
    """Bottom/top vacuum plateaus (mean of the planar average in vacuum)."""
    _, distance, average = planar_average(data, block=block, axis=axis)
    positions = _ion_positions(data, axis)
    length = data.plane_normal_length(axis)
    low = positions.min()
    high = positions.max()
    bottom = (distance > 1.0) & (distance < low - margin)
    top = (distance > high + margin) & (distance < length - 1.0)
    return {
        "bottom": float(average[bottom].mean()) if bottom.any() else float("nan"),
        "top": float(average[top].mean()) if top.any() else float("nan"),
        "atom_min": float(low),
        "atom_max": float(high),
        "length": float(length),
    }


def fermi_from_outcar(path: os.PathLike | str) -> Optional[float]:
    """Last ``E-fermi`` line (VASP prints it once per ionic step)."""
    try:
        text = Path(path).read_text(errors="ignore")
    except OSError:
        return None
    values = [float(line.split()[2]) for line in text.splitlines() if "E-fermi" in line]
    return values[-1] if values else None


def vbm_from_eigenval(path: os.PathLike | str) -> Optional[float]:
    """Highest occupied band (VBM) from EIGENVAL."""
    try:
        lines = Path(path).read_text(errors="ignore").splitlines()
    except OSError:
        return None
    if len(lines) < 7:
        return None
    try:
        nelect, nk, nbands = (int(x) for x in lines[5].split()[:3])
    except (ValueError, IndexError):
        return None
    cursor = 6
    occupied: List[float] = []
    for _ in range(nk):
        while cursor < len(lines) and not lines[cursor].strip():
            cursor += 1
        cursor += 1  # k-point line
        for _ in range(nbands):
            while cursor < len(lines) and not lines[cursor].strip():
                cursor += 1
            if cursor >= len(lines):
                break
            parts = lines[cursor].split()
            cursor += 1
            try:
                energy, occupation = float(parts[1]), float(parts[2])
            except (ValueError, IndexError):
                continue
            if occupation > 0.5:
                occupied.append(energy)
    return max(occupied) if occupied else None


def work_function(
    data: VaspField,
    block: int = 0,
    axis: int = 2,
    margin: float = 1.5,
    e_fermi: Optional[float] = None,
    vbm: Optional[float] = None,
) -> Dict[str, float]:
    """Vacuum levels, work function and ionisation potential."""
    levels = vacuum_levels(data, block=block, axis=axis, margin=margin)
    vacuum = 0.5 * (levels["bottom"] + levels["top"])
    result = dict(levels)
    result["vacuum"] = float(vacuum)
    result["plateau_difference"] = float(levels["bottom"] - levels["top"])
    result["fermi"] = float(e_fermi) if e_fermi is not None else float("nan")
    result["vbm"] = float(vbm) if vbm is not None else float("nan")
    result["work_function"] = (
        float(vacuum - e_fermi) if e_fermi is not None else float("nan")
    )
    result["ionisation_potential"] = (
        float(vacuum - vbm) if vbm is not None else float("nan")
    )
    return result


def value_at_points(
    data: VaspField, points: Sequence[Sequence[float]], block: int = 0, cartesian: bool = True
) -> np.ndarray:
    """Trilinear interpolation, with periodic wrapping."""
    array = data.block(block)
    nz, ny, nx = array.shape
    points = np.atleast_2d(np.asarray(points, dtype=float))
    if cartesian:
        fractional = points @ np.linalg.inv(data.cell)
    else:
        fractional = points
    fractional = np.mod(fractional, 1.0)
    x = fractional[:, 0] * nx - 0.5
    y = fractional[:, 1] * ny - 0.5
    z = fractional[:, 2] * nz - 0.5
    i0 = np.floor(x).astype(int)
    j0 = np.floor(y).astype(int)
    k0 = np.floor(z).astype(int)
    fx, fy, fz = x - i0, y - j0, z - k0
    result = np.zeros(len(points), dtype=float)
    for di in (0, 1):
        for dj in (0, 1):
            for dk in (0, 1):
                weight = (
                    (fx if di else 1 - fx)
                    * (fy if dj else 1 - fy)
                    * (fz if dk else 1 - fz)
                )
                ii = np.mod(i0 + di, nx)
                jj = np.mod(j0 + dj, ny)
                kk = np.mod(k0 + dk, nz)
                result += weight * array[kk, jj, ii]
    return result


def combine_fields(
    first: VaspField,
    second: VaspField,
    factor_first: float = 1.0,
    factor_second: float = 1.0,
) -> VaspField:
    """Weighted combination of two fields (sum or difference)."""
    if first.grid != second.grid:
        raise VaspFieldError(f"Grids differ: {first.grid} vs {second.grid}.")
    if first.natoms != second.natoms:
        raise VaspFieldError("Atom counts differ.")
    if len(first.blocks) != len(second.blocks):
        raise VaspFieldError(
            f"Block counts differ: {len(first.blocks)} vs {len(second.blocks)}."
        )
    blocks = [
        factor_first * a + factor_second * b
        for a, b in zip(first.blocks, second.blocks)
    ]
    return VaspField(
        path=first.path,
        kind=first.kind,
        comment=f"{factor_first:g}*{Path(first.path).name} + "
        f"{factor_second:g}*{Path(second.path).name}",
        cell=first.cell,
        species=first.species,
        counts=first.counts,
        coordinates=first.coordinates,
        coordinate_mode=first.coordinate_mode,
        scale=first.scale,
        grid=first.grid,
        blocks=blocks,
        block_labels=list(first.block_labels),
        augmentation_raw=list(first.augmentation_raw),
        header_text=first.header_text,
    )


# -- writers ----------------------------------------------------------------

def _format_values(values: np.ndarray, per_line: int = 5, fmt: str = " %18.11E") -> str:
    flat = np.asarray(values, dtype=float).ravel()
    lines = []
    for start in range(0, flat.size, per_line):
        chunk = flat[start : start + per_line]
        lines.append("".join(fmt % value for value in chunk))
    return "\n".join(lines) + "\n"


def write_chgcar(
    data: VaspField,
    path: os.PathLike | str,
    blocks: Optional[Sequence[np.ndarray]] = None,
) -> str:
    """Write a VASP-compatible file (header, blocks, augmentation sections)."""
    path = Path(path)
    arrays = list(blocks) if blocks is not None else list(data.blocks)
    chunks = [data.header_text]
    for index, array in enumerate(arrays):
        chunks.append(_format_values(array))
        if index < len(data.augmentation_raw):
            chunks.append(data.augmentation_raw[index])
            if not chunks[-1].endswith("\n"):
                chunks[-1] += "\n"
    path.write_text("\n".join(chunk.rstrip("\n") for chunk in chunks) + "\n")
    return str(path)


def write_cube(
    data: VaspField,
    path: os.PathLike | str,
    block: int = 0,
    units: str = "bohr",
    comment: Optional[str] = None,
) -> str:
    """Write a Gaussian cube file.

    ``units='bohr'`` (default) follows the cube convention: coordinates in
    bohr, density in e/bohr^3 and potential in Hartree. ``units='angstrom'``
    keeps coordinates and density (e/A^3) / potential (eV) in metric units.
    """
    path = Path(path)
    array = data.block(block)
    nz, ny, nx = array.shape
    if units not in ("bohr", "angstrom"):
        raise VaspFieldError("units must be 'bohr' or 'angstrom'.")
    factor = ANG_TO_BOHR if units == "bohr" else 1.0

    if data.is_density:
        physical = data.density(block)
        if units == "bohr":
            physical = physical * (BOHR_TO_ANG ** 3)
        unit_text = "e/bohr^3" if units == "bohr" else "e/A^3"
        kind_text = "charge density"
    elif data.kind == "locpot":
        physical = array
        if units == "bohr":
            physical = physical * EV_TO_HARTREE
        unit_text = "Hartree" if units == "bohr" else "eV"
        kind_text = "potential"
    else:
        physical = array
        unit_text = data.units
        kind_text = data.kind

    # Cube loops x slowest, z fastest; VASP has x fastest.
    cube_values = np.asarray(physical).transpose(2, 1, 0).ravel()

    lines = []
    lines.append(comment or f"{kind_text} from {Path(data.path).name} [{unit_text}]")
    lines.append(f"units={units}; values={unit_text}; SEQItachi/post_process_plotter")
    lines.append(f"{data.natoms:5d} {0.0:12.6f} {0.0:12.6f} {0.0:12.6f}")
    axes = (
        (data.cell[0] / nx),
        (data.cell[1] / ny),
        (data.cell[2] / nz),
    )
    for count, vector in zip((nx, ny, nz), axes):
        lines.append(
            f"{count:5d} {vector[0] * factor:12.6f} "
            f"{vector[1] * factor:12.6f} {vector[2] * factor:12.6f}"
        )
    cartesian = data.cartesian_coordinates()
    for symbol, position in zip(_species_list(data), cartesian):
        z = SYMBOL_TO_Z.get(symbol, 0)
        lines.append(
            f"{z:5d} {float(z):12.6f} {position[0] * factor:12.6f} "
            f"{position[1] * factor:12.6f} {position[2] * factor:12.6f}"
        )
    # Cube files use six values per line.
    body = _format_values(cube_values, per_line=6, fmt=" %13.5E")
    path.write_text("\n".join(lines) + "\n" + body)
    return str(path)


def _species_list(data: VaspField) -> List[str]:
    if not data.species:
        return ["X"] * data.natoms
    symbols: List[str] = []
    for symbol, count in zip(data.species, data.counts):
        symbols.extend([symbol] * count)
    return symbols


# -- command line -----------------------------------------------------------

def _cmd_info(args: argparse.Namespace) -> int:
    data = read_vasp_field(args.file)
    print(f"file        : {data.path}")
    print(f"kind        : {data.kind} ({data.units})")
    print(f"comment     : {data.comment}")
    print(f"atoms       : {data.natoms} ({' '.join(f'{s}{c}' for s, c in zip(data.species, data.counts))})")
    print(f"grid        : {data.grid[0]} x {data.grid[1]} x {data.grid[2]} = {data.npoints:,}")
    print(f"cell volume : {data.volume:.6f} A^3")
    print(f"blocks      : {len(data.blocks)} ({', '.join(data.block_labels)})")
    for index, block in enumerate(data.blocks):
        label = data.block_labels[index] if index < len(data.block_labels) else str(index)
        print(
            f"  [{index}] {label:14s} min {block.min():.6g}  max {block.max():.6g}"
        )
        if data.is_density:
            print(f"       electrons   : {data.electrons(index):.6f}")
    return 0


def _cmd_avg(args: argparse.Namespace) -> int:
    data = read_vasp_field(args.file)
    axis = {"a": 0, "b": 1, "c": 2}[args.axis]
    fractional, distance, values = planar_average(data, block=args.block, axis=axis)
    if args.macroscopic > 1:
        values = macroscopic_average(values, args.macroscopic)
    print("# distance_A  average")
    for d, v in zip(distance, values):
        print(f"{d:.6f} {v:.8f}")
    if args.csv:
        np.savetxt(args.csv, np.column_stack([distance, values]), fmt="%.8f",
                   header="distance_A average")
        print(f"# wrote {args.csv}", file=sys.stderr)
    return 0


def _cmd_workfunction(args: argparse.Namespace) -> int:
    data = read_vasp_field(args.file)
    axis = {"a": 0, "b": 1, "c": 2}[args.axis]
    outcar = args.outcar
    if outcar is None:
        candidate = Path(data.path).with_name("OUTCAR")
        outcar = str(candidate) if candidate.is_file() else None
    eigenval = args.eigenval
    if eigenval is None:
        candidate = Path(data.path).with_name("EIGENVAL")
        eigenval = str(candidate) if candidate.is_file() else None
    e_fermi = args.fermi if args.fermi is not None else (
        fermi_from_outcar(outcar) if outcar else None
    )
    vbm = vbm_from_eigenval(eigenval) if eigenval else None
    result = work_function(
        data, block=args.block, axis=axis, margin=args.margin,
        e_fermi=e_fermi, vbm=vbm,
    )
    for key, value in result.items():
        print(f"{key:20s} {value:.6f}")
    if abs(result["plateau_difference"]) > 0.2:
        print(
            "# note: plateaus differ by "
            f"{result['plateau_difference']:.2f} eV (dipole/asymmetry); "
            "use LDIPOL/IDIPOL and LVHAR=.TRUE. for a publication value.",
            file=sys.stderr,
        )
    return 0


def _cmd_cube(args: argparse.Namespace) -> int:
    data = read_vasp_field(args.file)
    print(write_cube(data, args.output, block=args.block, units=args.units))
    return 0


def _cmd_combine(args: argparse.Namespace) -> int:
    first = read_vasp_field(args.first)
    second = read_vasp_field(args.second)
    combined = combine_fields(first, second, args.factor_first, args.factor_second)
    write_chgcar(combined, args.output)
    print(args.output)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Read and analyse VASP CHGCAR / LOCPOT / PARCHG / ELFCAR files."
    )
    sub = parser.add_subparsers(dest="command", required=True)

    info = sub.add_parser("info", help="header, grid, blocks and value ranges")
    info.add_argument("file")
    info.set_defaults(func=_cmd_info)

    avg = sub.add_parser("avg", help="planar average along an axis")
    avg.add_argument("file")
    avg.add_argument("--axis", choices=list("abc"), default="c")
    avg.add_argument("--block", type=int, default=0)
    avg.add_argument("--macroscopic", type=int, default=1)
    avg.add_argument("--csv", default=None)
    avg.set_defaults(func=_cmd_avg)

    work = sub.add_parser("workfunction", help="vacuum levels, work function, IP")
    work.add_argument("file")
    work.add_argument("--axis", choices=list("abc"), default="c")
    work.add_argument("--block", type=int, default=0)
    work.add_argument("--margin", type=float, default=1.5)
    work.add_argument("--outcar", default=None)
    work.add_argument("--eigenval", default=None)
    work.add_argument("--fermi", type=float, default=None)
    work.set_defaults(func=_cmd_workfunction)

    cube = sub.add_parser("cube", help="write a Gaussian cube file")
    cube.add_argument("file")
    cube.add_argument("output")
    cube.add_argument("--block", type=int, default=0)
    cube.add_argument("--units", choices=["bohr", "angstrom"], default="bohr")
    cube.set_defaults(func=_cmd_cube)

    for name, function, help_text in (
        ("sum", _cmd_combine, "weighted sum of two fields"),
        ("diff", _cmd_combine, "second minus first field"),
    ):
        combine = sub.add_parser(name, help=help_text)
        combine.add_argument("first")
        combine.add_argument("second")
        combine.add_argument("output")
        combine.add_argument("--factor-first", type=float, default=1.0)
        combine.add_argument(
            "--factor-second", type=float, default=1.0 if name == "sum" else -1.0
        )
        combine.set_defaults(func=_cmd_combine)

    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
