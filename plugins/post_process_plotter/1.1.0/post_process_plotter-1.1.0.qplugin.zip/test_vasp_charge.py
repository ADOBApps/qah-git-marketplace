#!/usr/bin/env python3
"""Self-tests for vasp_charge.py (no Qt, no VASP needed).

Run:
    python3 test_vasp_charge.py

It builds small synthetic CHGCAR files (one spin channel and two), checks the
round trip, the arithmetic, the cube export and the interpolator, then checks
the real LOCPOT files in the thesis tree when they are available.
"""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import vasp_charge as vc  # noqa: E402

THESIS_LOCPOT = [
    ("slab36/pristine", 4.2703, 4.5140),
    ("slab72_2x1/sn1_surface_4pct", 4.0991, 4.4579),
    ("slab72_2x1/sn2_surface_near_8pct", 4.0626, 4.4161),
    ("slab36/sn_test_8pct", 4.3032, 4.4825),
]
# Optional: point this at a VASP tree to enable the real-file regression.
THESIS = Path(os.environ.get("TIO2_SN_VASP", ""))


def _synthetic(path: Path, spin: bool = False) -> tuple[np.ndarray, np.ndarray]:
    nx, ny, nz = 4, 3, 5
    n = nx * ny * nz
    # CHGCAR stores rho*V, so sum(values)/npoints is the electron count.
    total = np.arange(n, dtype=float) + 1.0
    total *= n / total.sum()      # exactly one electron
    magnet = np.linspace(-0.5, 0.5, n)

    lines = []
    lines.append("synthetic CHGCAR")
    lines.append("   1.0000000000000000")
    lines.append("     4.000000    0.000000    0.000000")
    lines.append("     0.000000    3.000000    0.000000")
    lines.append("     0.000000    0.000000    5.000000")
    lines.append("   H")
    lines.append("     2")
    lines.append("Direct")
    lines.append("  0.000000  0.000000  0.000000")
    lines.append("  0.500000  0.500000  0.500000")
    lines.append("")
    lines.append(f"   {nx}   {ny}   {nz}")
    lines.append(vc._format_values(total).rstrip("\n"))
    lines.append("")
    lines.append("augmentation occupancies   1   2")
    lines.append("     1   0   0.10000000")
    lines.append("     2   1   0.20000000")
    lines.append("")
    if spin:
        lines.append(f"   {nx}   {ny}   {nz}")
        lines.append(vc._format_values(magnet).rstrip("\n"))
        lines.append("")
        lines.append("augmentation occupancies   1   2")
        lines.append("     1   0   0.01000000")
        lines.append("     2   1   0.02000000")
        lines.append("")
    path.write_text("\n".join(lines) + "\n")
    return total.reshape(nz, ny, nx), magnet.reshape(nz, ny, nx)


def test_reader() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "CHGCAR"
        total, _ = _synthetic(path)
        data = vc.read_vasp_field(path)
        assert data.kind == "chgcar", data.kind
        assert data.grid == (4, 3, 5), data.grid
        assert data.npoints == 60
        assert data.natoms == 2
        assert data.coordinate_mode == "direct"
        assert data.blocks[0].shape == (5, 3, 4)
        assert np.allclose(data.blocks[0], total)
        assert abs(data.electrons() - 1.0) < 1e-8
        assert len(data.augmentation_raw) == 1
        print("PASS reader: grid, shape, electrons, augmentation")


def test_spin_blocks() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "CHGCAR"
        _, magnet = _synthetic(path, spin=True)
        data = vc.read_vasp_field(path)
        assert len(data.blocks) == 2, len(data.blocks)
        assert data.block_labels == ["Total", "Magnetization"]
        assert np.allclose(data.blocks[1], magnet)
        assert len(data.augmentation_raw) == 2
        print("PASS spin: two blocks and two augmentation sections")


def test_roundtrip_and_arithmetic() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "CHGCAR"
        total, _ = _synthetic(path)
        data = vc.read_vasp_field(path)
        out = Path(tmp) / "CHGCAR_copy"
        vc.write_chgcar(data, out)
        again = vc.read_vasp_field(out)
        assert again.grid == data.grid
        assert np.allclose(again.blocks[0], total)
        assert len(again.augmentation_raw) == 1

        doubled = vc.combine_fields(data, data)
        assert np.allclose(doubled.blocks[0], 2 * total)
        assert abs(doubled.electrons() - 2.0) < 1e-8
        summed = Path(tmp) / "CHGCAR_sum"
        vc.write_chgcar(doubled, summed)
        assert abs(vc.read_vasp_field(summed).electrons() - 2.0) < 1e-8

        zero = vc.combine_fields(data, data, 1.0, -1.0)
        assert np.allclose(zero.blocks[0], 0.0, atol=1e-12)
        print("PASS arithmetic: copy, sum, difference")


def test_cube() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "CHGCAR"
        total, _ = _synthetic(path)
        data = vc.read_vasp_field(path)
        cube = Path(tmp) / "density.cube"
        vc.write_cube(data, cube, units="bohr")

        from cube_parser import CubeParser

        parsed = CubeParser().parse(str(cube))
        assert parsed["shape"] == (4, 3, 5), parsed["shape"]
        expected = (total / data.volume) * (vc.BOHR_TO_ANG ** 3)
        assert np.allclose(parsed["data"], expected.transpose(2, 1, 0), atol=1e-8)
        # atoms were written in bohr; the parser converts back to angstrom
        assert np.allclose(
            parsed["atoms"], data.cartesian_coordinates(), atol=1e-5
        )
        print("PASS cube: shape, density units, atom positions")


def test_interpolation() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "CHGCAR"
        _synthetic(path)
        data = vc.read_vasp_field(path)
        points = np.array([[0.1, 0.2, 0.3], [0.9, 0.5, 0.7]])
        # A constant field must be reproduced exactly everywhere.
        data.blocks[0] = np.full_like(data.blocks[0], 2.5)
        assert np.allclose(vc.value_at_points(data, points), 2.5)
        # Translation by a lattice vector must not change the value.
        shifted = vc.value_at_points(data, points + data.cell[2])
        assert np.allclose(vc.value_at_points(data, points), shifted, atol=1e-12)
        print("PASS interpolation: constant field, periodic wrap")


def test_real_locpot() -> None:
    if not str(THESIS) or not THESIS.is_dir():
        print("SKIP real LOCPOT (thesis tree not found)")
        return
    checked = 0
    for relative, expected_phi, expected_ip in THESIS_LOCPOT:
        folder = THESIS / relative
        locpot = folder / "LOCPOT"
        if not locpot.is_file() or locpot.stat().st_size == 0:
            continue
        data = vc.read_vasp_field(locpot)
        result = vc.work_function(
            data,
            e_fermi=vc.fermi_from_outcar(folder / "OUTCAR"),
            vbm=vc.vbm_from_eigenval(folder / "EIGENVAL"),
        )
        assert abs(result["work_function"] - expected_phi) < 1e-3, (
            relative,
            result["work_function"],
            expected_phi,
        )
        assert abs(result["ionisation_potential"] - expected_ip) < 1e-3, (
            relative,
            result["ionisation_potential"],
            expected_ip,
        )
        fractional, distance, average = vc.planar_average(data)
        assert average.size == data.grid[2]
        assert np.isfinite(average).all()
        checked += 1
    if checked:
        print(f"PASS real LOCPOT: {checked} slabs match the reference work functions")
    else:
        print("SKIP real LOCPOT (set TIO2_SN_VASP to the VASP tree)")


def main() -> int:
    test_reader()
    test_spin_blocks()
    test_roundtrip_and_arithmetic()
    test_cube()
    test_interpolation()
    test_real_locpot()
    print("ALL TESTS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
