"""
Parsers for Quantum ESPRESSO output files
This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

QAH is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

import numpy as np
import re
from typing import Dict, List, Tuple, Optional
from pathlib import Path
import logging


class QEBandsParser:
    """Parse Quantum ESPRESSO band structure output files"""
    
    def __init__(self):
        self.ry2ev = 13.605693
        
    def parse(self, file_path: str) -> Dict:
        """
        Parse QE bands file (usually .gnu or bands.out)
        
        Supports:
        - GNU formatted bands (from bands.x)
        - plot bands format
        - bands.dat format
        
        Returns:
            Dictionary with:
                - kpoints: array of k-point indices or distances
                - bands: 2D array [n_bands, n_kpoints] of energies (eV)
                - kpath: cumulative distances for plotting
                - special_points: list of k-point labels if available
        """
        with open(file_path, 'r') as f:
            lines = f.readlines()
        
        # Detect format
        first_line = lines[0].strip()
        
        if first_line.startswith('#') and 'k' in first_line.lower():
            # GNU format from bands.x
            return self._parse_gnu_format(lines)
        elif '&plot' in ''.join(lines[:10]).lower():
            # Plot format
            return self._parse_plot_format(lines)
        else:
            # Try as simple column data
            return self._parse_simple_format(lines)
    
    def _parse_gnu_format(self, lines: List[str]) -> Dict:
        """Parse GNU formatted bands (k-point index in first column)"""
        data = []
        for line in lines:
            line = line.strip()
            if line and not line.startswith('#'):
                parts = line.split()
                if len(parts) >= 2:
                    data.append([float(x) for x in parts])
        
        data = np.array(data)
        
        # First column is k-point index, rest are bands
        k_indices = data[:, 0]
        bands = data[:, 1:].T  # Transpose to get [n_bands, n_kpoints]
        
        # Find unique k-points (for multiple bands per k-point)
        unique_k, inverse = np.unique(k_indices, return_inverse=True)
        n_kpoints = len(unique_k)
        n_bands = bands.shape[0]
        
        # Reorganize bands by k-point
        bands_reorg = np.zeros((n_bands, n_kpoints))
        for i, k_idx in enumerate(inverse):
            bands_reorg[:, k_idx] = bands[:, i]
        
        # Create cumulative k-point distance (simple index-based)
        kpath = np.arange(n_kpoints)
        
        return {
            'kpoints': kpath,
            'kpoints_raw': k_indices,
            'bands': bands_reorg * self.ry2ev,  # Convert to eV
            'n_kpoints': n_kpoints,
            'n_bands': n_bands,
            'format': 'gnu',
            'metadata': {'source': 'qe', 'type': 'bands'}
        }
    
    def _parse_plot_format(self, lines: List[str]) -> Dict:
        """Parse plot bands format with special points"""
        data_lines = []
        special_points = []
        in_data = False
        
        for line in lines:
            line = line.strip()
            if line.startswith('&plot'):
                in_data = True
                continue
            if line.startswith('/'):
                in_data = False
                continue
            
            if in_data and line and not line.startswith('!'):
                parts = line.split()
                if len(parts) >= 2:
                    # Check if this is a special point marker
                    if len(parts) >= 3 and parts[2].isalpha():
                        special_points.append({
                            'position': float(parts[0]),
                            'label': parts[2]
                        })
                    data_lines.append([float(parts[0]), float(parts[1])])
        
        data = np.array(data_lines)
        
        # Separate kpoints and bands
        kpoints = data[:, 0]
        bands = data[:, 1].reshape(-1, len(np.unique(kpoints))).T * self.ry2ev
        
        return {
            'kpoints': np.unique(kpoints),
            'kpath': kpoints,
            'bands': bands,
            'special_points': special_points,
            'n_kpoints': len(np.unique(kpoints)),
            'n_bands': bands.shape[0],
            'format': 'plot',
            'metadata': {'source': 'qe', 'type': 'bands'}
        }
    
    def _parse_simple_format(self, lines: List[str]) -> Dict:
        """Parse simple two-column format (k-point, energy)"""
        data = []
        for line in lines:
            line = line.strip()
            if line and not line.startswith('#'):
                parts = line.split()
                if len(parts) == 2:
                    data.append([float(parts[0]), float(parts[1])])
        
        data = np.array(data)
        
        # Group by k-point
        kpoints = data[:, 0]
        unique_k = np.unique(kpoints)
        n_kpoints = len(unique_k)
        n_bands = len(data) // n_kpoints
        
        bands = data[:, 1].reshape(n_bands, n_kpoints) * self.ry2ev
        
        return {
            'kpoints': unique_k,
            'kpath': kpoints,
            'bands': bands,
            'n_kpoints': n_kpoints,
            'n_bands': n_bands,
            'format': 'simple',
            'metadata': {'source': 'qe', 'type': 'bands'}
        }


class QEDOSParser:
    """Parse Quantum ESPRESSO DOS output files"""
    
    def __init__(self):
        self.ry2ev = 13.605693
        
    def parse(self, file_path: str) -> Dict:
        """
        Parse QE DOS file (usually .dos or .dat)
        
        Returns:
            Dictionary with:
                - energy: array of energies (eV)
                - dos: array of DOS values
                - integrated_dos: array of integrated DOS (if available)
                - fermi_energy: Fermi energy (if found in header)
        """
        with open(file_path, 'r') as f:
            lines = f.readlines()
        
        # Try to extract Fermi energy from header
        fermi_energy = None
        data_start = 0
        
        for i, line in enumerate(lines):
            if 'fermi' in line.lower() or 'efermi' in line.lower():
                match = re.search(r'[-+]?\d*\.?\d+', line)
                if match:
                    fermi_energy = float(match.group()) * self.ry2ev
            if line.strip() and not line.startswith('#'):
                data_start = i
                break
        
        # Parse data
        data = []
        for line in lines[data_start:]:
            line = line.strip()
            if line and not line.startswith('#'):
                parts = line.split()
                if len(parts) >= 2:
                    data.append([float(x) for x in parts[:3]])  # Energy, DOS, (optionally) IDOS
        
        data = np.array(data)
        
        result = {
            'energy': data[:, 0] * self.ry2ev,  # Convert to eV
            'dos': data[:, 1],
            'n_points': len(data),
            'metadata': {'source': 'qe', 'type': 'dos'}
        }
        
        if data.shape[1] >= 3:
            result['integrated_dos'] = data[:, 2]
        
        if fermi_energy is not None:
            result['fermi_energy'] = fermi_energy
        
        return result


class QEPDOSParser:
    """Parse Quantum ESPRESSO PDOS output files"""
    
    def __init__(self):
        self.ry2ev = 13.605693
        
    def parse(self, file_path: str) -> Dict:
        """
        Parse QE PDOS file (from projwfc.x)
        
        Format typically:
        # E (eV)  ldos(s)  ldos(p)  ldos(d)  ...
        
        Returns:
            Dictionary with:
                - energy: array of energies (eV)
                - projections: dict of orbital projections
                - total: total DOS
                - fermi_energy: Fermi energy (if found)
        """
        with open(file_path, 'r') as f:
            lines = f.readlines()
        
        # Parse header to get orbital labels
        orbital_labels = []
        data_start = 0
        
        for i, line in enumerate(lines):
            if line.startswith('#') and 'E' in line:
                # Extract labels from header
                parts = line.strip().split()
                if len(parts) > 2:
                    orbital_labels = parts[2:]  # Skip '#' and 'E'
                data_start = i + 1
                break
        
        # Parse data
        data = []
        for line in lines[data_start:]:
            line = line.strip()
            if line and not line.startswith('#'):
                parts = line.split()
                if len(parts) >= 2:
                    data.append([float(x) for x in parts])
        
        data = np.array(data)
        
        # Organize projections
        projections = {}
        if len(orbital_labels) == data.shape[1] - 1:
            for i, label in enumerate(orbital_labels):
                projections[label] = data[:, i + 1]
        
        # Calculate total
        total = np.sum([data[:, i+1] for i in range(len(orbital_labels))], axis=0)
        
        return {
            'energy': data[:, 0] * self.ry2ev,  # Convert to eV
            'projections': projections,
            'total': total,
            'orbital_labels': orbital_labels,
            'n_points': len(data),
            'n_orbitals': len(orbital_labels),
            'metadata': {'source': 'qe', 'type': 'pdos'}
        }


class QEPotentialParser:
    """Parse Quantum ESPRESSO potential files (from pp.x)"""
    
    def __init__(self):
        self.ry2ev = 13.605693
        self.bohr2ang = 0.529177210903
        
    def parse(self, file_path: str) -> Dict:
        """
        Parse QE potential file (usually .dat or .xsf)
        
        Returns:
            Dictionary with:
                - z: array of z-coordinates (Angstrom)
                - potential: array of potential values (eV)
                - metadata: additional information
        """
        with open(file_path, 'r') as f:
            lines = f.readlines()
        
        # Check if it's XSF format
        if any('BEGIN_BLOCK_DATAGRID_3D' in line for line in lines[:10]):
            return self._parse_xsf_format(lines)
        else:
            # Assume simple two-column format
            return self._parse_simple_format(lines)
    
    def _parse_simple_format(self, lines: List[str]) -> Dict:
        """Parse simple two-column format (z, potential)"""
        data = []
        for line in lines:
            line = line.strip()
            if line and not line.startswith('#'):
                parts = line.split()
                if len(parts) >= 2:
                    data.append([float(parts[0]), float(parts[1])])
        
        data = np.array(data)
        
        # Convert coordinates to Angstrom if in Bohr
        z = data[:, 0]
        if np.max(z) > 100:  # Likely in Bohr
            z = z * self.bohr2ang
        
        return {
            'z': z,
            'potential': data[:, 1] * self.ry2ev,  # Convert to eV
            'raw_z': data[:, 0],
            'raw_potential': data[:, 1],
            'n_points': len(data),
            'metadata': {'source': 'qe', 'type': 'potential', 'format': 'simple'}
        }
    
    def _parse_xsf_format(self, lines: List[str]) -> Dict:
        """Parse XSF format for 3D data"""
        in_datagrid = False
        grid_dims = None
        grid_data = []
        
        for line in lines:
            line = line.strip()
            
            if 'BEGIN_DATAGRID_3D' in line:
                in_datagrid = True
                continue
            elif 'END_DATAGRID_3D' in line:
                in_datagrid = False
                continue
            
            if in_datagrid:
                if grid_dims is None:
                    # First line after BEGIN_DATAGRID_3D is number of grid points
                    parts = line.split()
                    if len(parts) == 3:
                        grid_dims = [int(x) for x in parts]
                else:
                    # Collect grid data
                    parts = line.split()
                    grid_data.extend([float(x) for x in parts])
        
        if grid_dims is not None and grid_data:
            # Reshape grid data
            data_3d = np.array(grid_data).reshape(grid_dims)
            
            # Average over x and y to get 1D profile
            profile = np.mean(data_3d, axis=(0, 1))
            
            # Create z coordinates
            z = np.linspace(0, grid_dims[2], grid_dims[2]) * self.bohr2ang
            
            return {
                'z': z,
                'potential': profile * self.ry2ev,
                'data_3d': data_3d,
                'grid_dims': grid_dims,
                'n_points': len(profile),
                'metadata': {'source': 'qe', 'type': 'potential', 'format': 'xsf'}
            }
        
        # Fallback to simple format
        return self._parse_simple_format(lines)


# Convenience functions

def parse_qe_bands(file_path: str) -> Dict:
    """Convenience function to parse QE bands"""
    parser = QEBandsParser()
    return parser.parse(file_path)


def parse_qe_dos(file_path: str) -> Dict:
    """Convenience function to parse QE DOS"""
    parser = QEDOSParser()
    return parser.parse(file_path)


def parse_qe_pdos(file_path: str) -> Dict:
    """Convenience function to parse QE PDOS"""
    parser = QEPDOSParser()
    return parser.parse(file_path)


def parse_qe_potential(file_path: str) -> Dict:
    """Convenience function to parse QE potential"""
    parser = QEPotentialParser()
    return parser.parse(file_path)


# Unit test example
if __name__ == "__main__":
    import sys
    
    def test_parser(parser_func, file_path):
        try:
            data = parser_func(file_path)
            logging.info(f"Successfully parsed: {file_path}")
            logging.info(f"Keys: {list(data.keys())}")
            if 'bands' in data:
                logging.info(f"Bands shape: {data['bands'].shape}")
            if 'energy' in data:
                logging.info(f"Energy range: {data['energy'].min():.2f} to {data['energy'].max():.2f} eV")
            if 'z' in data:
                logging.info(f"Z range: {data['z'].min():.2f} to {data['z'].max():.2f} Ang")
            return True
        except Exception as e:
            logging.info(f"Error parsing {file_path}: {e}")
            return False
    
    # Example usage
    if len(sys.argv) > 1:
        file_path = sys.argv[1]
        
        # Try to detect and parse
        if 'bands' in file_path.lower():
            test_parser(parse_qe_bands, file_path)
        elif 'dos' in file_path.lower():
            test_parser(parse_qe_dos, file_path)
        elif 'pdos' in file_path.lower():
            test_parser(parse_qe_pdos, file_path)
        else:
            test_parser(parse_qe_potential, file_path)