"""
Unified analyzer for both QE and CP2K formats
This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

QAH is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

import numpy as np
from typing import Dict, Any
from pathlib import Path

from .file_detector import FileFormatDetector
from .cp2k_bands_parser import parse_cp2k_bands
from .cp2k_dos_parser import parse_cp2k_dos
from .cp2k_pdos_parser import parse_cp2k_pdos
from .cube_parser import parse_cube


class UnifiedAnalyzer:
    """Analyze files from both QE and CP2K"""
    
    def __init__(self):
        self.detector = FileFormatDetector()
    
    def analyze(self, file_path: str, options: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze file based on detected format"""
        fmt, metadata = self.detector.detect_format(file_path)
        
        if fmt == 'cp2k_bands':
            return self._analyze_cp2k_bands(file_path, options)
        elif fmt == 'cp2k_dos':
            return self._analyze_cp2k_dos(file_path, options)
        elif fmt == 'cp2k_pdos':
            return self._analyze_cp2k_pdos(file_path, options)
        elif fmt == 'cube':
            return self._analyze_cube(file_path, options)
        elif fmt.startswith('qe_'):
            return self._analyze_qe(file_path, options, fmt)
        else:
            # Try to guess from extension
            return self._analyze_by_extension(file_path, options)
    
    def _analyze_cp2k_bands(self, file_path: str, options: Dict) -> Dict:
        """Analyze CP2K bands file"""
        data = parse_cp2k_bands(file_path)
        
        # Prepare results for UI
        results = {
            'format': 'CP2K Bands',
            'n_kpoints': data['n_kpoints'],
            'n_bands': data['n_bands'],
            'plot_data': {
                'X': data['kpoints'].tolist(),
                'Y': data['bands'].T.tolist(),  # Transpose for plotting
                'type': 'bands',
                'special_points': data.get('special_point_ticks', [])
            }
        }
        
        # Add metadata
        if 'fermi_energy' in data:
            results['fermi_energy'] = data['fermi_energy']
        
        return results
    
    def _analyze_cp2k_dos(self, file_path: str, options: Dict) -> Dict:
        """Analyze CP2K DOS file"""
        data = parse_cp2k_dos(file_path)
        
        results = {
            'format': 'CP2K DOS',
            'n_points': data['n_points'],
            'fermi_energy': data['fermi_energy'],
            'plot_data': {
                'X': data['energy'].tolist(),
                'Y': data['dos'].tolist(),
                'type': 'dos'
            }
        }
        
        return results
    
    def _analyze_cp2k_pdos(self, file_path: str, options: Dict) -> Dict:
        """Analyze CP2K PDOS file"""
        data = parse_cp2k_pdos(file_path)
        
        results = {
            'format': 'CP2K PDOS',
            'atomic_kind': data['atomic_kind'],
            'n_states': data['n_states'],
            'fermi_energy': data['fermi_energy'],
            'plot_data': {
                'X': data['eigenvalues'].tolist(),
                'Y': data['projections'],
                'orbital_sums': data['orbital_sums'],
                'type': 'pdos'
            }
        }
        
        return results
    
    def _analyze_cube(self, file_path: str, options: Dict) -> Dict:
        """Analyze cube file"""
        data = parse_cube(file_path)
        
        # Get profile data
        profile = data['profile']
        
        results = {
            'format': 'Cube',
            'shape': data['shape'],
            'natoms': len(data['atoms']),
            'plot_data': {
                'X': profile['z'].tolist(),
                'Y': (profile['value'] * self.detector.HA2EV).tolist(),
                'type': 'potential',
                'x_label': 'Distance (Angstrom)',
                'y_label': 'Potential (eV)'
            }
        }
        
        return results
    
    def _analyze_qe(self, file_path: str, options: Dict, fmt: str) -> Dict:
        """Analyze QE file"""
        from .analyzer import PP_X1DPlotterAnalyzer
        analyzer = PP_X1DPlotterAnalyzer()
        return analyzer.analyze(file_path, options)
    
    def _analyze_by_extension(self, file_path: str, options: Dict) -> Dict:
        """Analyze by file extension"""
        ext = Path(file_path).suffix.lower()
        
        if ext == '.bs':
            return self._analyze_cp2k_bands(file_path, options)
        elif ext == '.dos':
            return self._analyze_cp2k_dos(file_path, options)
        elif ext == '.pdos':
            return self._analyze_cp2k_pdos(file_path, options)
        elif ext == '.cube':
            return self._analyze_cube(file_path, options)
        else:
            # Default to QE analysis
            from .analyzer import PP_X1DPlotterAnalyzer
            analyzer = PP_X1DPlotterAnalyzer()
            return analyzer.analyze(file_path, options)