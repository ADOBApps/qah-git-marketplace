#!/usr/bin/env python3
"""Widget tests for the VASP Charge tab (offscreen, no QAH required).

Run:
    QT_QPA_PLATFORM=offscreen python3 test_widget.py

Requires PySide6 and matplotlib. Skips cleanly when Qt is missing.
"""

from __future__ import annotations

import os
import sys
import tempfile
import time
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

try:
    from PySide6.QtGui import QIcon
    from PySide6.QtWidgets import QApplication
except Exception as exc:  # pragma: no cover - Qt is optional for core tests
    print(f"SKIP widget tests: PySide6 not available ({exc})")
    raise SystemExit(0)

import test_vasp_charge as vasp_tests  # noqa: E402
import vasp_charge_widget as widget_module  # noqa: E402

app = QApplication.instance() or QApplication([])
widget_module.QMessageBox.warning = staticmethod(lambda *a, **k: None)
widget_module.QMessageBox.information = staticmethod(lambda *a, **k: None)


def pump(seconds: float = 5.0, until=None) -> None:
    deadline = time.time() + seconds
    while time.time() < deadline:
        app.processEvents()
        if until is not None and until():
            return
        time.sleep(0.01)


def test_blocking_load() -> None:
    widget = widget_module.VaspChargeWidget()
    widget.show()
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "CHGCAR"
        vasp_tests._synthetic(path, spin=True)
        widget.load_path(str(path), blocking=True)
        assert widget.data is not None
        assert widget.data.grid == (4, 3, 5)
        assert widget.block_combo.count() == 2
        assert not widget.progress_bar.isVisible()
        assert len(widget.canvas.figure.axes) == 1
    widget.close()
    print("PASS widget blocking load")


def test_async_progress() -> None:
    widget = widget_module.VaspChargeWidget()
    widget.show()
    try:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "CHGCAR"
            vasp_tests._synthetic(path, spin=True)
            widget.load_path(str(path))
            assert widget.progress_bar.isVisible(), "progress bar must appear immediately"
            pump(10.0, until=lambda: widget.data is not None and widget._thread is None)
            assert widget.data is not None
            assert not widget.progress_bar.isVisible()
            assert widget.load_button.isEnabled()
    finally:
        if widget._loader is not None:
            widget._loader.cancel()
        if widget._thread is not None:
            widget._thread.quit()
            widget._thread.wait(5000)
        widget.close()
    print("PASS widget async load + progress bar")


def test_icon() -> None:
    icon_path = HERE / "icon.svg"
    assert icon_path.is_file()
    icon = QIcon(str(icon_path))
    assert not icon.isNull()
    print("PASS icon loads")


def test_work_function() -> None:
    thesis = Path(os.environ.get("TIO2_SN_VASP", ""))
    locpot = thesis / "slab36/pristine/LOCPOT" if str(thesis) else None
    if not locpot or not locpot.is_file():
        print("SKIP widget work function (set TIO2_SN_VASP)")
        return
    widget = widget_module.VaspChargeWidget()
    widget.show()
    widget.load_path(str(locpot), blocking=True)
    widget._compute_work_function()
    assert "4.2703" in widget.results.toPlainText()
    assert len(widget.canvas.figure.axes[0].lines) >= 4
    widget.close()
    print("PASS widget work function (4.2703 eV)")


def main() -> int:
    test_icon()
    test_blocking_load()
    test_async_progress()
    test_work_function()
    print("ALL WIDGET TESTS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
