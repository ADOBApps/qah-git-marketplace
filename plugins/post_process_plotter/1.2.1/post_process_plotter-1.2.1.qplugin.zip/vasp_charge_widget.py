"""
VASP charge / potential tab for Post Process Plotter.

Reads CHGCAR, LOCPOT, PARCHG and ELFCAR with the pure-Python layer in
``vasp_charge.py`` (no Perl), plots planar averages, computes vacuum levels and
the work function, and exports CSV, plots and Gaussian cube files.

This file is part of QAH and is GPL-3.0-or-later.
"""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np

from PySide6.QtCore import QObject, QThread, Qt, Signal
from PySide6.QtWidgets import (
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

try:  # relative import when loaded as part of the plugin
    from .vasp_charge import (
        VaspFieldError,
        fermi_from_outcar,
        macroscopic_average,
        planar_average,
        read_vasp_field,
        vbm_from_eigenval,
        work_function,
        write_cube,
    )
except ImportError:  # standalone import for tests
    from vasp_charge import (  # type: ignore
        VaspFieldError,
        fermi_from_outcar,
        macroscopic_average,
        planar_average,
        read_vasp_field,
        vbm_from_eigenval,
        work_function,
        write_cube,
    )

try:
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
    from matplotlib.figure import Figure

    MATPLOTLIB_OK = True
except Exception:  # pragma: no cover - QAH always ships matplotlib
    FigureCanvasQTAgg = None  # type: ignore
    Figure = None  # type: ignore
    MATPLOTLIB_OK = False


class _FieldLoader(QObject):
    """Load a volumetric file in a worker thread."""

    progress = Signal(int, str)
    finished = Signal(object)
    failed = Signal(str)

    def __init__(self, path: str):
        super().__init__()
        self.path = path
        self._cancelled = False

    def cancel(self) -> None:
        self._cancelled = True

    def run(self) -> None:
        try:
            data = read_vasp_field(
                self.path,
                progress=lambda fraction, message: self.progress.emit(
                    int(max(0.0, min(1.0, fraction)) * 100), message
                ),
                should_cancel=lambda: self._cancelled,
            )
            self.finished.emit(data)
        except Exception as exc:  # noqa: BLE001 - surfaced to the user
            self.failed.emit(str(exc))


class VaspChargeWidget(QWidget):
    """Tab widget: VASP volumetric fields."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.data = None
        self._vbm: Optional[float] = None
        self._result: Dict[str, float] = {}
        self._thread: Optional[QThread] = None
        self._loader: Optional[_FieldLoader] = None

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        # -- file ---------------------------------------------------------
        file_group = QGroupBox("VASP field (CHGCAR / LOCPOT / PARCHG / ELFCAR)")
        file_layout = QVBoxLayout(file_group)
        row = QHBoxLayout()
        self.path_edit = QLineEdit()
        self.path_edit.setPlaceholderText("Select a CHGCAR, LOCPOT, PARCHG or ELFCAR file…")
        self.browse_button = QPushButton("Browse…")
        self.load_button = QPushButton("Load")
        row.addWidget(self.path_edit, 1)
        row.addWidget(self.browse_button)
        row.addWidget(self.load_button)
        file_layout.addLayout(row)

        progress_row = QHBoxLayout()
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setVisible(False)
        self.progress_bar.setToolTip(
            "Reading progress. A 934 MB CHGCAR with 53.8 million grid points "
            "takes about 40 s."
        )
        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.setVisible(False)
        self.cancel_button.clicked.connect(self._cancel_load)
        progress_row.addWidget(self.progress_bar, 1)
        progress_row.addWidget(self.cancel_button)
        file_layout.addLayout(progress_row)

        self.info_label = QLabel("No file loaded.")
        self.info_label.setWordWrap(True)
        self.info_label.setStyleSheet("font-family: monospace;")
        file_layout.addWidget(self.info_label)
        layout.addWidget(file_group)

        # -- plot controls -------------------------------------------------
        plot_group = QGroupBox("Planar average")
        plot_layout = QVBoxLayout(plot_group)
        form = QFormLayout()
        form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)

        self.axis_combo = QComboBox()
        self.axis_combo.addItems(["c (z)", "b (y)", "a (x)"])
        form.addRow("Axis:", self.axis_combo)

        self.block_combo = QComboBox()
        self.block_combo.addItem("Total")
        form.addRow("Block:", self.block_combo)

        self.smooth_spin = QSpinBox()
        self.smooth_spin.setRange(1, 99)
        self.smooth_spin.setValue(1)
        self.smooth_spin.setToolTip(
            "Periodic moving-average window in grid points (1 = raw planar average)."
        )
        form.addRow("Macroscopic window:", self.smooth_spin)

        self.fermi_spin = QDoubleSpinBox()
        self.fermi_spin.setRange(-100.0, 100.0)
        self.fermi_spin.setDecimals(4)
        self.fermi_spin.setSingleStep(0.1)
        self.fermi_spin.setSuffix(" eV")
        self.fermi_spin.setToolTip(
            "Fermi energy. Loaded from OUTCAR next to the field when available; "
            "edit it to override."
        )
        form.addRow("Fermi energy:", self.fermi_spin)

        self.margin_spin = QDoubleSpinBox()
        self.margin_spin.setRange(0.0, 20.0)
        self.margin_spin.setDecimals(2)
        self.margin_spin.setSingleStep(0.1)
        self.margin_spin.setValue(1.5)
        self.margin_spin.setSuffix(" Å")
        self.margin_spin.setToolTip(
            "Vacuum is taken at least this far from the outermost atom."
        )
        form.addRow("Vacuum margin:", self.margin_spin)
        plot_layout.addLayout(form)

        buttons = QHBoxLayout()
        self.plot_button = QPushButton("Plot")
        self.work_button = QPushButton("Work function")
        self.csv_button = QPushButton("Export CSV…")
        self.png_button = QPushButton("Save plot…")
        self.cube_button = QPushButton("Export cube…")
        for button in (
            self.plot_button,
            self.work_button,
            self.csv_button,
            self.png_button,
            self.cube_button,
        ):
            buttons.addWidget(button)
        buttons.addStretch(1)
        plot_layout.addLayout(buttons)
        layout.addWidget(plot_group)

        # -- canvas --------------------------------------------------------
        if MATPLOTLIB_OK:
            self.canvas = FigureCanvasQTAgg(Figure(figsize=(7.0, 3.4)))
            self.canvas.setMinimumHeight(280)
            layout.addWidget(self.canvas, 1)
        else:
            self.canvas = None
            layout.addWidget(QLabel("matplotlib is not available, so plots are disabled."))

        # -- results -------------------------------------------------------
        results_group = QGroupBox("Results")
        results_layout = QVBoxLayout(results_group)
        self.results = QPlainTextEdit()
        self.results.setReadOnly(True)
        self.results.setMaximumHeight(150)
        self.results.setPlaceholderText(
            "Load a file and press “Work function” to see vacuum levels, "
            "work function and ionisation potential."
        )
        results_layout.addWidget(self.results)
        layout.addWidget(results_group)

        self.status = QLabel("Ready.")
        self.status.setStyleSheet("color:#6b7280;")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        layout.addStretch(1)

        scroll.setWidget(content)
        outer.addWidget(scroll)

        self.browse_button.clicked.connect(self._browse)
        self.load_button.clicked.connect(self._load_from_edit)
        self.plot_button.clicked.connect(self._plot)
        self.work_button.clicked.connect(self._compute_work_function)
        self.csv_button.clicked.connect(self._export_csv)
        self.png_button.clicked.connect(self._save_plot)
        self.cube_button.clicked.connect(self._export_cube)

    # -- loading ----------------------------------------------------------
    def _browse(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Open VASP field",
            str(Path.home()),
            "VASP fields (CHGCAR* LOCPOT* PARCHG* ELFCAR*);;All files (*)",
        )
        if path:
            self.path_edit.setText(path)
            self.load_path(path)

    def _load_from_edit(self) -> None:
        path = self.path_edit.text().strip()
        if path:
            self.load_path(path)

    def load_path(self, path: str, blocking: bool = False) -> None:
        """Load a field. ``blocking=True`` is used by tests and short files."""
        path = str(path)
        if blocking:
            self._result = {}
            self._vbm = None
            try:
                data = read_vasp_field(path)
            except (OSError, VaspFieldError) as exc:
                QMessageBox.warning(self, "VASP field", f"Could not read {path}:\n{exc}")
                return
            self._apply_loaded(data, path)
            return
        if self._thread is not None and self._thread.isRunning():
            self.status.setText("A file is already loading; cancel it first.")
            return
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(True)
        self.cancel_button.setVisible(True)
        self.load_button.setEnabled(False)
        self.status.setText(f"Loading {Path(path).name}…")
        self._thread = QThread(self)
        self._loader = _FieldLoader(path)
        self._loader.moveToThread(self._thread)
        self._thread.started.connect(self._loader.run)
        self._loader.progress.connect(self._on_load_progress)
        self._loader.finished.connect(self._on_load_finished)
        self._loader.failed.connect(self._on_load_failed)
        self._loader.finished.connect(self._thread.quit)
        self._loader.failed.connect(self._thread.quit)
        self._thread.finished.connect(self._cleanup_loader)
        self._thread.start()

    def _on_load_progress(self, percent: int, message: str) -> None:
        self.progress_bar.setValue(percent)
        self.progress_bar.setFormat(f"{percent}% — {message}")

    def _on_load_finished(self, data) -> None:
        self._end_load_ui()
        self._apply_loaded(data, data.path)

    def _on_load_failed(self, message: str) -> None:
        self._end_load_ui()
        if "cancel" in message.lower():
            self.status.setText("Load cancelled.")
        else:
            self.status.setText("Load failed.")
            QMessageBox.warning(self, "VASP field", message)

    def _cancel_load(self) -> None:
        if self._loader is not None:
            self._loader.cancel()
            self.status.setText("Cancelling…")

    def _end_load_ui(self) -> None:
        self.progress_bar.setVisible(False)
        self.cancel_button.setVisible(False)
        self.load_button.setEnabled(True)

    def _cleanup_loader(self) -> None:
        if self._loader is not None:
            self._loader.deleteLater()
        if self._thread is not None:
            self._thread.deleteLater()
        self._loader = None
        self._thread = None

    def _apply_loaded(self, data, path: str) -> None:
        self._result = {}
        self._vbm = None
        self.data = data
        self.path_edit.setText(str(path))
        self.info_label.setText(
            "\n".join(
                [
                    f"kind      : {data.kind} — {data.units}",
                    f"comment   : {data.comment}",
                    f"atoms     : {data.natoms} ({' '.join(f'{s}{c}' for s, c in zip(data.species, data.counts))})",
                    f"grid      : {data.grid[0]} × {data.grid[1]} × {data.grid[2]} = {data.npoints:,}",
                    f"volume    : {data.volume:.4f} Å³",
                    f"blocks    : {len(data.blocks)} ({', '.join(data.block_labels)})",
                ]
            )
        )
        self.block_combo.clear()
        for label in data.block_labels or ["Total"]:
            self.block_combo.addItem(label)
        self._load_reference(str(Path(path).parent))
        self.status.setText(f"Loaded {Path(path).name}.")
        self.results.clear()
        self._plot()

    def _load_reference(self, folder: str) -> None:
        self._vbm = None
        outcar = Path(folder) / "OUTCAR"
        if outcar.is_file():
            fermi = fermi_from_outcar(outcar)
            if fermi is not None:
                self.fermi_spin.setValue(fermi)
                self.status.setText(f"Fermi energy {fermi:.4f} eV read from OUTCAR.")
        eigenval = Path(folder) / "EIGENVAL"
        if eigenval.is_file():
            self._vbm = vbm_from_eigenval(eigenval)

    # -- analysis ---------------------------------------------------------
    def _axis_index(self) -> int:
        return {"a (x)": 0, "b (y)": 1, "c (z)": 2}[self.axis_combo.currentText()]

    def _plot(self) -> None:
        if self.data is None or self.canvas is None:
            return
        axis = self._axis_index()
        block = max(0, self.block_combo.currentIndex())
        try:
            _, distance, average = planar_average(self.data, block=block, axis=axis)
        except VaspFieldError as exc:
            self.status.setText(str(exc))
            return
        window = int(self.smooth_spin.value())
        plotted = macroscopic_average(average, window) if window > 1 else average

        figure = self.canvas.figure
        figure.clear()
        ax = figure.add_subplot(111)
        ax.plot(distance, plotted, color="#2563eb", lw=1.3, label="planar average")
        if self._result:
            ax.axhline(self._result["bottom"], color="#9ca3af", lw=0.8, ls="--")
            ax.axhline(self._result["top"], color="#9ca3af", lw=0.8, ls="--")
            ax.axhline(self._result["vacuum"], color="#dc2626", lw=0.8, ls=":")
            ax.annotate(
                f"φ = {self._result['work_function']:.2f} eV",
                xy=(0.02, 0.12),
                xycoords="axes fraction",
                fontsize=9,
                color="#dc2626",
                bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.8},
            )
        ax.set_xlabel(f"distance along {'abc'[axis]} / Å")
        ax.set_ylabel("planar average" + (" / eV" if self.data.kind == "locpot" else ""))
        ax.set_title(f"{Path(self.data.path).name} — {'abc'[axis]} axis")
        figure.tight_layout()
        self.canvas.draw_idle()

    def _compute_work_function(self) -> None:
        if self.data is None:
            self.status.setText("Load a LOCPOT (or ELFCAR) first.")
            return
        fermi = float(self.fermi_spin.value())
        try:
            result = work_function(
                self.data,
                block=max(0, self.block_combo.currentIndex()),
                axis=self._axis_index(),
                margin=float(self.margin_spin.value()),
                e_fermi=fermi,
                vbm=self._vbm,
            )
        except VaspFieldError as exc:
            self.status.setText(str(exc))
            return
        self._result = result
        lines = [
            f"V_vac bottom   : {result['bottom']:.4f} eV",
            f"V_vac top      : {result['top']:.4f} eV",
            f"V_vac (mean)   : {result['vacuum']:.4f} eV",
            f"plateau diff   : {result['plateau_difference']:+.4f} eV",
            f"E_Fermi        : {result['fermi']:.4f} eV",
            f"work function  : {result['work_function']:.4f} eV",
        ]
        if not np.isnan(result["vbm"]):
            lines.append(f"VBM            : {result['vbm']:.4f} eV")
            lines.append(f"ionisation pot.: {result['ionisation_potential']:.4f} eV")
        if abs(result["plateau_difference"]) > 0.2:
            lines.append(
                "note: plateaus differ by > 0.2 eV (dipole/asymmetric slab); "
                "use LDIPOL/IDIPOL and LVHAR=.TRUE. for a publication value."
            )
        self.results.setPlainText("\n".join(lines))
        self.status.setText("Work function computed.")
        self._plot()

    # -- exports ----------------------------------------------------------
    def _export_csv(self) -> None:
        if self.data is None:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export planar average", str(Path.home() / "planar_average.csv"),
            "CSV (*.csv);;All files (*)",
        )
        if not path:
            return
        axis = self._axis_index()
        _, distance, average = planar_average(
            self.data, block=max(0, self.block_combo.currentIndex()), axis=axis
        )
        window = int(self.smooth_spin.value())
        if window > 1:
            average = macroscopic_average(average, window)
        try:
            with open(path, "w", encoding="utf-8", newline="") as handle:
                handle.write(f"# file,{self.data.path}\n")
                handle.write(f"# axis,{'abc'[axis]}\n")
                handle.write(f"# macroscopic_window,{window}\n")
                writer = csv.writer(handle)
                writer.writerow(["distance_A", "average"])
                for d, v in zip(distance, average):
                    writer.writerow([f"{float(d):.6f}", f"{float(v):.8f}"])
        except OSError as exc:
            QMessageBox.warning(self, "VASP field", str(exc))
            return
        self.status.setText(f"Wrote {path}")

    def _save_plot(self) -> None:
        if self.canvas is None:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save plot", str(Path.home() / "vasp_planar_average.pdf"),
            "PDF (*.pdf);;PNG (*.png);;SVG (*.svg)",
        )
        if not path:
            return
        try:
            self.canvas.figure.savefig(path, dpi=300, bbox_inches="tight")
        except Exception as exc:  # pragma: no cover - I/O errors
            QMessageBox.warning(self, "VASP field", str(exc))
            return
        self.status.setText(f"Saved {path}")

    def _export_cube(self) -> None:
        if self.data is None:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Gaussian cube",
            str(Path.home() / (Path(self.data.path).name + ".cube")),
            "Cube (*.cube);;All files (*)",
        )
        if not path:
            return
        try:
            write_cube(
                self.data,
                path,
                block=max(0, self.block_combo.currentIndex()),
                units="bohr",
            )
        except (OSError, VaspFieldError) as exc:
            QMessageBox.warning(self, "VASP field", str(exc))
            return
        self.status.setText(f"Wrote {path}")
