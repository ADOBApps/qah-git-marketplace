#!/usr/bin/env python3
"""
Terminal interface for Post Process Plotter (no Qt, no QAH required).

Supported inputs
----------------
* VASP: CHGCAR, LOCPOT, PARCHG, ELFCAR (via vasp_charge)
* Quantum ESPRESSO: bands (.gnu/plot), DOS, PDOS, potential (pp.x)
* CP2K: bands (.bs), DOS, PDOS, cube potentials

Examples
--------
    python post_process_cli.py doctor
    python post_process_cli.py detect LOCPOT
    python post_process_cli.py bands bands.gnu --plot bands.png
    python post_process_cli.py dos dos.dat --csv dos.csv
    python post_process_cli.py pdos pdos.dat --plot pdos.pdf
    python post_process_cli.py potential pot.dat --plot pot.png
    python post_process_cli.py vasp info CHGCAR
    python post_process_cli.py vasp workfunction LOCPOT
    python post_process_cli.py vasp avg LOCPOT --axis c --csv profile.csv

Every command accepts ``--json``; data commands accept ``--csv`` and ``--plot``.

This file is part of QAH and is GPL-3.0-or-later.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

import numpy as np

PLUGIN_DIR = Path(__file__).resolve().parent
if str(PLUGIN_DIR) not in sys.path:
    sys.path.insert(0, str(PLUGIN_DIR))

try:  # package import (inside QAH)
    from .file_detector import FileFormatDetector
    from .cp2k_bands_parser import parse_cp2k_bands
    from .cp2k_dos_parser import parse_cp2k_dos
    from .cp2k_pdos_parser import parse_cp2k_pdos
    from .cube_parser import parse_cube
    from .qe_parsers import (
        parse_qe_bands,
        parse_qe_dos,
        parse_qe_pdos,
        parse_qe_potential,
    )
    from . import vasp_charge
except ImportError:  # script import
    from file_detector import FileFormatDetector  # type: ignore
    from cp2k_bands_parser import parse_cp2k_bands  # type: ignore
    from cp2k_dos_parser import parse_cp2k_dos  # type: ignore
    from cp2k_pdos_parser import parse_cp2k_pdos  # type: ignore
    from cube_parser import parse_cube  # type: ignore
    from qe_parsers import (  # type: ignore
        parse_qe_bands,
        parse_qe_dos,
        parse_qe_pdos,
        parse_qe_potential,
    )
    import vasp_charge  # type: ignore


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _manifest_version() -> str:
    try:
        manifest = json.loads((PLUGIN_DIR / "manifest.json").read_text())
        return str(manifest.get("version", "?"))
    except Exception:
        return "?"


def _jsonable(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    if isinstance(value, np.ndarray):
        return _jsonable(value.tolist())
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    return value


def _detect(path: Path) -> tuple[str, Dict[str, Any]]:
    """Detect the format, falling back to the file name for VASP fields."""
    fmt, metadata = FileFormatDetector.detect_format(str(path))
    if fmt != "unknown":
        return fmt, metadata
    name = path.name.upper()
    if name.startswith(("CHGCAR", "LOCPOT", "PARCHG", "ELFCAR")):
        return "vasp_field", {"format": "volume", "source": "vasp"}
    return fmt, metadata


def _plot_series(series: Sequence[tuple[str, np.ndarray, np.ndarray]], path: str,
                 xlabel: str, ylabel: str, title: str, dpi: int = 200) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    figure, axis = plt.subplots(figsize=(7.0, 3.8))
    for label, x, y in series:
        axis.plot(x, y, lw=1.1, label=label)
    if len(series) > 1 and len(series) <= 12:
        axis.legend(fontsize=7, frameon=False)
    axis.set_xlabel(xlabel)
    axis.set_ylabel(ylabel)
    axis.set_title(title)
    figure.tight_layout()
    figure.savefig(path, dpi=dpi, bbox_inches="tight")
    plt.close(figure)
    print(f"wrote {path}")


def _write_csv(path: str, header: Sequence[str], columns: Sequence[np.ndarray]) -> None:
    data = np.column_stack([np.asarray(column, dtype=float) for column in columns])
    np.savetxt(path, data, fmt="%.8f", header=" ".join(header), comments="# ")
    print(f"wrote {path}")


def _venn(array: np.ndarray) -> np.ndarray:
    return np.asarray(array, dtype=float)


# ---------------------------------------------------------------------------
# commands
# ---------------------------------------------------------------------------

def cmd_doctor(args: argparse.Namespace) -> int:
    import platform

    info = {
        "plugin_version": _manifest_version(),
        "python": platform.python_version(),
        "platform": platform.platform(),
        "numpy": np.__version__,
        "matplotlib": None,
        "pyside6": importlib.util.find_spec("PySide6") is not None,
        "formats": [
            "VASP CHGCAR/LOCPOT/PARCHG/ELFCAR",
            "QE bands/DOS/PDOS/potential",
            "CP2K bands/DOS/PDOS/cube",
        ],
    }
    try:
        import matplotlib

        info["matplotlib"] = matplotlib.__version__
    except Exception:
        pass
    if args.json:
        print(json.dumps(info, indent=2))
    else:
        for key, value in info.items():
            print(f"{key:16s}: {value}")
    return 0


def cmd_detect(args: argparse.Namespace) -> int:
    path = Path(args.file)
    if not path.is_file():
        print(f"error: {path} not found", file=sys.stderr)
        return 1
    fmt, metadata = _detect(path)
    result = {"file": str(path), "format": fmt, "metadata": _jsonable(metadata)}
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(f"file   : {path}")
        print(f"format : {fmt}")
        for key, value in (metadata or {}).items():
            print(f"  {key}: {value}")
    return 0 if fmt != "unknown" else 2


def _parse_bands(path: Path, fmt: str) -> Dict[str, Any]:
    if fmt.startswith("cp2k"):
        return parse_cp2k_bands(str(path))
    return parse_qe_bands(str(path))


def cmd_bands(args: argparse.Namespace) -> int:
    path = Path(args.file)
    fmt, _ = _detect(path)
    try:
        data = _parse_bands(path, fmt)
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    bands = np.atleast_2d(np.asarray(data["bands"], dtype=float))
    if bands.shape[0] > bands.shape[1]:
        bands = bands.T
    kpoints = np.asarray(data.get("kpoints", np.arange(bands.shape[1])), dtype=float)
    if kpoints.size != bands.shape[1]:
        kpoints = np.arange(bands.shape[1])
    result = {
        "file": str(path),
        "format": fmt,
        "n_kpoints": int(bands.shape[1]),
        "n_bands": int(bands.shape[0]),
        "energy_min": float(bands.min()),
        "energy_max": float(bands.max()),
        "fermi_energy": data.get("fermi_energy"),
    }
    if args.json:
        print(json.dumps(_jsonable(result), indent=2))
    else:
        for key, value in result.items():
            print(f"{key:14s}: {value}")
    if args.csv:
        _write_csv(args.csv, ["k"] + [f"band{i+1}" for i in range(bands.shape[0])],
                   [kpoints] + [bands[index] for index in range(bands.shape[0])])
    if args.plot:
        series = [(f"band {index+1}", kpoints, bands[index]) for index in range(bands.shape[0])]
        _plot_series(series, args.plot, "k-path", "E / eV",
                     f"{path.name} — {bands.shape[0]} bands", args.dpi)
    return 0


def cmd_dos(args: argparse.Namespace) -> int:
    path = Path(args.file)
    fmt, _ = _detect(path)
    try:
        data = parse_cp2k_dos(str(path)) if fmt.startswith("cp2k") else parse_qe_dos(str(path))
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    energy = np.asarray(data["energy"], dtype=float)
    dos = np.asarray(data["dos"], dtype=float)
    result = {
        "file": str(path),
        "format": fmt,
        "n_points": int(energy.size),
        "energy_min": float(energy.min()),
        "energy_max": float(energy.max()),
        "dos_max": float(dos.max()),
        "fermi_energy": data.get("fermi_energy"),
    }
    if args.json:
        print(json.dumps(_jsonable(result), indent=2))
    else:
        for key, value in result.items():
            print(f"{key:14s}: {value}")
    if args.csv:
        columns = [energy, dos]
        header = ["E_eV", "dos"]
        if data.get("integrated_dos") is not None:
            columns.append(np.asarray(data["integrated_dos"], dtype=float))
            header.append("integrated_dos")
        _write_csv(args.csv, header, columns)
    if args.plot:
        _plot_series([("DOS", energy, dos)], args.plot, "E / eV", "DOS",
                     f"{path.name} — DOS", args.dpi)
    return 0


def cmd_pdos(args: argparse.Namespace) -> int:
    path = Path(args.file)
    fmt, _ = _detect(path)
    try:
        data = parse_cp2k_pdos(str(path)) if fmt.startswith("cp2k") else parse_qe_pdos(str(path))
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    if fmt.startswith("cp2k"):
        energy = np.asarray(data["eigenvalues"], dtype=float)
        series_map = data.get("orbital_sums") or {}
    else:
        energy = np.asarray(data["energy"], dtype=float)
        series_map = data.get("projections") or {}
    result = {
        "file": str(path),
        "format": fmt,
        "n_points": int(energy.size),
        "n_series": len(series_map),
        "labels": list(series_map)[:20],
        "fermi_energy": data.get("fermi_energy"),
    }
    if args.json:
        print(json.dumps(_jsonable(result), indent=2))
    else:
        for key, value in result.items():
            print(f"{key:14s}: {value}")
    if args.csv:
        labels = list(series_map)
        columns = [energy] + [np.asarray(series_map[label], dtype=float) for label in labels]
        _write_csv(args.csv, ["E_eV"] + labels, columns)
    if args.plot and series_map:
        series = [(str(label), energy, np.asarray(values, dtype=float))
                  for label, values in list(series_map.items())[:20]]
        _plot_series(series, args.plot, "E / eV", "PDOS",
                     f"{path.name} — projected DOS", args.dpi)
    return 0


def cmd_potential(args: argparse.Namespace) -> int:
    path = Path(args.file)
    fmt, _ = _detect(path)
    try:
        if fmt == "cube":
            data = parse_cube(str(path))
            profile = data["profile"]
            z = np.asarray(profile["z"], dtype=float)
            values = np.asarray(profile["value"], dtype=float) * 27.21138602
        else:
            data = parse_qe_potential(str(path))
            z = np.asarray(data["z"], dtype=float)
            values = np.asarray(data["potential"], dtype=float)
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    result = {
        "file": str(path),
        "format": fmt,
        "n_points": int(z.size),
        "z_min": float(z.min()),
        "z_max": float(z.max()),
        "potential_min": float(values.min()),
        "potential_max": float(values.max()),
    }
    if args.json:
        print(json.dumps(_jsonable(result), indent=2))
    else:
        for key, value in result.items():
            print(f"{key:14s}: {value}")
    if args.csv:
        _write_csv(args.csv, ["distance", "potential"], [z, values])
    if args.plot:
        _plot_series([("potential", z, values)], args.plot, "distance / Å",
                     "potential / eV", f"{path.name} — planar average", args.dpi)
    return 0


def cmd_vasp(args: argparse.Namespace) -> int:
    return int(vasp_charge.main(args.vasp_args))


# ---------------------------------------------------------------------------
# parser
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="post_process_cli",
        description="Terminal interface for Post Process Plotter "
        "(VASP, Quantum ESPRESSO and CP2K post-processing).",
    )
    parser.add_argument("--version", action="version",
                        version=f"post_process_plotter {_manifest_version()}")
    subparsers = parser.add_subparsers(dest="command", required=True)

    doctor = subparsers.add_parser("doctor", help="environment and capabilities")
    doctor.add_argument("--json", action="store_true")
    doctor.set_defaults(func=cmd_doctor)

    detect = subparsers.add_parser("detect", help="identify a file")
    detect.add_argument("file")
    detect.add_argument("--json", action="store_true")
    detect.set_defaults(func=cmd_detect)

    def data_parser(name: str, function, help_text: str):
        item = subparsers.add_parser(name, help=help_text)
        item.add_argument("file")
        item.add_argument("--json", action="store_true")
        item.add_argument("--csv", default=None, help="write the data table")
        item.add_argument("--plot", default=None, help="write a PNG/PDF/SVG figure")
        item.add_argument("--dpi", type=int, default=200)
        item.set_defaults(func=function)
        return item

    data_parser("bands", cmd_bands, "band structure (QE or CP2K)")
    data_parser("dos", cmd_dos, "total DOS (QE or CP2K)")
    data_parser("pdos", cmd_pdos, "projected DOS (QE or CP2K)")
    data_parser("potential", cmd_potential, "planar potential (QE or cube)")

    vasp = subparsers.add_parser("vasp", help="VASP volumetric fields (see 'vasp --help')")
    vasp.add_argument("vasp_args", nargs=argparse.REMAINDER)
    vasp.set_defaults(func=cmd_vasp)

    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
