#!/usr/bin/env python3
"""
Author: Acxel Orozco
Date: 06/11/2023 (Started)
Last modification: 05/01/2024
Description: Enhanced Band Structure Plotting Widget with live preview and k-points viewer,
now including multiple plotting styles, bandgap calculation, and matplotlib window display.
Features:
- Better organized UI with notebook tabs
- Live plotting preview
- Live k-points table view
- Removed external file handler dependencies
- Improved validation
- More intuitive workflow
- Separate buttons for different band plot styles (Pure, Fermi, Final)
- Dedicated "Save Plot" button for flexible saving
- Bandgap energy calculation
- Matplotlib window display option
- NEW: Data previewer
- REVISED: Bandgap calculation based on user's code
- NEW: Added option for both manual and automatic bandgap calculation
- NEW: Added a tab to explain the bandgap calculation methods
 - Quantum Analysis Helper (QAH)

QAH is a python software for plot and analyze Quantum Espresso DOS, 
PDOS and Bands structures with a friendly GUI and extensive plugins.

This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

QAH is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

import os
# import sys
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import json
import weakref
import logging
from pathlib import Path

from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QLineEdit, QPushButton, QRadioButton, QGroupBox, QSpinBox, QDoubleSpinBox,
    QTreeWidget, QTreeWidgetItem, QTabWidget, QFileDialog, QMessageBox, QDialog,
    QScrollArea, QSizePolicy, QHeaderView, QDialogButtonBox, QTextEdit, QCheckBox
)
from PySide6.QtCore import Qt, Signal, QObject, QEvent
from PySide6.QtGui import QFont, QDoubleValidator

# Configure logging
# logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

class BandsDataProcessor:
    def __init__(self, bands_file, kpoints_data):
        self.bands_file = bands_file
        self.kpoints_data = kpoints_data
        # logging.debug(f"BandsDataProcessor initialized with bands_file: {bands_file}")
        
    def validate_and_process(self, fermi_energy, vb_lower, vb_upper, cb_lower, cb_upper, calculation_mode):
        """Read actual bands data from file"""
        if not Path(self.bands_file).exists():
            raise FileNotFoundError(f"Bands file not found: {self.bands_file}")
        
        try:
            # Leer datos reales del archivo de bandas
            data = np.loadtxt(self.bands_file)
            
            # Asumimos que la primera columna son kpoints y las demás son bandas
            kpoints = np.unique(data[:, 0])
            bands = np.reshape(data[:, 1], (-1, len(kpoints)))
            
            # Calcular Fermi energy (promedio entre min y max como aproximación)
            all_energies = bands.flatten()
            energy_min = np.nanmin(all_energies)
            energy_max = np.nanmax(all_energies)
            
            # Use the selected calculation method
            if calculation_mode == 'manual':
                bandgap_info = self._calculate_bandgap_from_user_logic(bands, fermi_energy, vb_lower, vb_upper, cb_lower, cb_upper)
            elif calculation_mode == 'automatic':
                bandgap_info = self._calculate_bandgap_automatic(bands, fermi_energy)
            else:
                bandgap_info = {"has_bandgap": False, "message": "Invalid calculation mode."}
            
            return {
                "bands": bands,
                "bands_cleaned": bands, # No cleaning, return original data
                "kpoints": kpoints,
                "fermi_energy": fermi_energy,
                "energy_range": (energy_min, energy_max),
                "bandgap_info": bandgap_info
            }
            
        except Exception as e:
            raise ValueError(f"Error reading bands file {self.bands_file}: {e}")

    def _calculate_bandgap_from_user_logic(self, bands, fermi_energy, vb_lower, vb_upper, cb_lower, cb_upper):
        """
        Calculates bandgap based on the user's provided logic using
        pre-defined energy ranges.
        """
        try:
            # Shift all bands to be relative to Fermi energy
            fermi_bands = bands - fermi_energy
            
            # Create masks for valence and conduction bands
            vb_mask = (fermi_bands >= vb_lower) & (fermi_bands <= vb_upper)
            cb_mask = (fermi_bands >= cb_lower) & (fermi_bands <= cb_upper)
            
            # Find max VB and min CB energy within the specified ranges
            vb_arr = fermi_bands[vb_mask]
            cb_arr = fermi_bands[cb_mask]
            
            if not vb_arr.size or not cb_arr.size:
                return {
                    "E_vb": 0.0,
                    "E_cb": 0.0,
                    "bandgap": 0.0,
                    "is_direct": False,
                    "has_bandgap": False,
                    "message": "Could not find any bands in the specified energy ranges."
                }
            
            vb_max_value = np.max(vb_arr)
            cb_min_value = np.min(cb_arr)
            
            # Find the k-point index for the band extrema.
            # This is a bit tricky, since np.where returns multiple indices.
            idx_vb_flat = np.where(fermi_bands == vb_max_value)[0]
            idx_cb_flat = np.where(fermi_bands == cb_min_value)[0]
            
            # Get the k-point index from the flat index
            num_k_points = bands.shape[1]
            k_idx_vbm = idx_vb_flat[0] % num_k_points
            k_idx_cbm = idx_cb_flat[0] % num_k_points

            bandgap = cb_min_value - vb_max_value
            is_direct = (k_idx_vbm == k_idx_cbm)
            
            if bandgap > 1e-6: # Use a small tolerance
                return {
                    "E_vb": vb_max_value,
                    "E_cb": cb_min_value,
                    "bandgap": bandgap,
                    "is_direct": is_direct,
                    "has_bandgap": True,
                    "message": "Calculated using manual ranges."
                }
            else:
                return {
                    "E_vb": 0.0,
                    "E_cb": 0.0,
                    "bandgap": 0.0,
                    "is_direct": False,
                    "has_bandgap": False,
                    "message": "No bandgap detected in the specified manual ranges (metallic or zero-gap)."
                }
            
        except Exception as e:
            logging.error(f"Error in user-based bandgap calculation: {e}")
            return {
                "E_vb": 0.0,
                "E_cb": 0.0,
                "bandgap": 0.0,
                "is_direct": False,
                "has_bandgap": False,
                "message": f"Manual calculation failed with error: {str(e)}"
            }

    def _calculate_bandgap_automatic(self, bands, fermi_energy):
        """
        Calculates bandgap automatically by finding the VBM and CBM.
        This is a robust rule-based approach.
        """
        try:
            fermi_bands = bands - fermi_energy
            
            # Find all energies below and above Fermi level
            vb_energies = fermi_bands[fermi_bands <= 0]
            cb_energies = fermi_bands[fermi_bands >= 0]
            
            if not vb_energies.size or not cb_energies.size:
                return {
                    "E_vb": 0.0,
                    "E_cb": 0.0,
                    "bandgap": 0.0,
                    "is_direct": False,
                    "has_bandgap": False,
                    "message": "Could not find bands on both sides of the Fermi level."
                }
            
            # The highest energy below Fermi is the VBM
            vbm = np.max(vb_energies)
            
            # The lowest energy above Fermi is the CBM
            cbm = np.min(cb_energies)
            
            bandgap = cbm - vbm
            
            # Find the k-point indices for VBM and CBM
            num_k_points = bands.shape[1]
            k_idx_vbm = np.where(fermi_bands == vbm)[0][0] % num_k_points
            k_idx_cbm = np.where(fermi_bands == cbm)[0][0] % num_k_points
            
            is_direct = (k_idx_vbm == k_idx_cbm)

            if bandgap > 1e-6: # Check if there is a real gap
                return {
                    "E_vb": vbm,
                    "E_cb": cbm,
                    "bandgap": bandgap,
                    "is_direct": is_direct,
                    "has_bandgap": True,
                    "message": "Calculated using automatic method."
                }
            else:
                return {
                    "E_vb": vbm,
                    "E_cb": cbm,
                    "bandgap": 0.0,
                    "is_direct": False,
                    "has_bandgap": False,
                    "message": "No bandgap detected (metallic or zero-gap)."
                }
            
        except Exception as e:
            logging.error(f"Error in automatic bandgap calculation: {e}")
            return {
                "E_vb": 0.0,
                "E_cb": 0.0,
                "bandgap": 0.0,
                "is_direct": False,
                "has_bandgap": False,
                "message": f"Automatic calculation failed with error: {str(e)}"
            }

class BandsMaker:
    def __init__(self, bands_data_dict, fermi, vb_lower, vb_upper, cb_lower, cb_upper):
        self.bands_data = bands_data_dict
        self.fermi = fermi
        self.vb_lower = vb_lower
        self.vb_upper = vb_upper
        self.cb_lower = cb_lower
        self.cb_upper = cb_upper
        self.bandgap_info = bands_data_dict.get("bandgap_info", {})
        
        # Calculate automatic suggestions based on the actual data
        self._calculate_suggestions()
        
    def _calculate_suggestions(self):
        """Calculate suggested band ranges based on actual data"""
        bands = self.bands_data["bands_cleaned"]
        all_energies = bands.flatten()
        
        # Find the approximate band gap
        below_fermi = all_energies[all_energies <= self.fermi]
        above_fermi = all_energies[all_energies >= self.fermi]
        
        if len(below_fermi) > 0 and len(above_fermi) > 0:
            self.suggested_vb_upper = np.nanmax(below_fermi) - self.fermi
            self.suggested_vb_lower = np.nanmin(below_fermi) - self.fermi
            self.suggested_cb_lower = np.nanmin(above_fermi) - self.fermi
            self.suggested_cb_upper = np.nanmax(above_fermi) - self.fermi
        else:
            # Default values if they can't be calculated
            self.suggested_vb_lower = -2.0
            self.suggested_vb_upper = -1.0
            self.suggested_cb_lower = 1.0
            self.suggested_cb_upper = 2.0
        
    def plot_pure_bands(self, ax):
        """Plot bands without any energy reference"""
        bands = self.bands_data["bands_cleaned"]
        kpoints = self.bands_data["kpoints"]
        
        # Plot all bands
        for i in range(bands.shape[0]):
            ax.plot(kpoints, bands[i, :], 'b-', alpha=0.7, linewidth=1.0)
        
        ax.set_title("Pure Band Structure")
        ax.set_xlabel('Wave Vector')
        ax.set_ylabel('Energy (eV)')
        ax.grid(True, alpha=0.3)
        
        # Show bandgap information in the title if available
        if self.bandgap_info.get('has_bandgap', False):
            gap_type = "Direct" if self.bandgap_info.get('is_direct', False) else "Indirect"
            ax.set_title(f"Pure Band Structure\nBandgap: {self.bandgap_info['bandgap']:.3f} eV ({gap_type})")
        
    def plot_fermi_bands(self, ax):
        """Plot bands referenced to Fermi energy"""
        bands = self.bands_data["bands_cleaned"]
        kpoints = self.bands_data["kpoints"]
        
        # Plot all bands relative to Fermi energy
        for i in range(bands.shape[0]):
            ax.plot(kpoints, bands[i, :] - self.fermi, 'r-', alpha=0.7, linewidth=1.0)
        
        ax.axhline(y=0, color='k', linestyle='--', linewidth=1.5, label='Fermi Level (0 eV)')
        ax.set_title("Fermi-Referenced Band Structure")
        ax.set_xlabel('Wave Vector')
        ax.set_ylabel('Energy - E$_F$ (eV)')
        ax.grid(True, alpha=0.3)
        ax.legend()
        
        # Show bandgap information
        if self.bandgap_info.get('has_bandgap', False):
            gap_type = "Direct" if self.bandgap_info.get('is_direct', False) else "Indirect"
            ax.set_title(f"Fermi-Referenced Band Structure\nBandgap: {self.bandgap_info['bandgap']:.3f} eV ({gap_type})")
        
    def plot_final_bands_old(self, ax):
        """Plot bands with band regions highlighted"""
        bands = self.bands_data["bands_cleaned"]
        kpoints = self.bands_data["kpoints"]
        
        # Plot all bands relative to Fermi energy
        for i in range(bands.shape[0]):
            ax.plot(kpoints, bands[i, :] - self.fermi, 'g-', alpha=0.7, linewidth=1.0)
        
        # Add shaded regions for bands
        ax.axhspan(self.vb_lower, self.vb_upper, 
                  color='blue', alpha=0.2, label='Valence Band')
        ax.axhspan(self.cb_lower, self.cb_upper, 
                  color='red', alpha=0.2, label='Conduction Band')
        ax.axhline(y=0, color='k', linestyle='--', linewidth=1.5, label='Fermi Level (0 eV)')
        
        ax.set_title("Band Structure with Highlighted Regions")
        ax.set_xlabel('Wave Vector')
        ax.set_ylabel('Energy - E$_F$ (eV)')
        ax.grid(True, alpha=0.3)
        ax.legend()
        
        # Show bandgap information
        if self.bandgap_info.get('has_bandgap', False):
            gap_type = "Direct" if self.bandgap_info.get('is_direct', False) else "Indirect"
            ax.set_title(f"Band Structure with Highlighted Regions\nBandgap: {self.bandgap_info['bandgap']:.3f} eV ({gap_type})")

    def plot_final_bands(self, ax):
        """
        Enhanced plot_final_bands with advanced features from Method 1.
        Maintains full compatibility with existing BandsMaker class.
        """
        bands = self.bands_data["bands_cleaned"]
        kpoints = self.bands_data["kpoints"]
        
        # --- Try to get advanced data if available (Method 1 features) ---
        # Check if we have occupation data for better VBM/CBM detection
        has_advanced_data = hasattr(self, 'occupations') and self.occupations is not None
        
        if has_advanced_data and hasattr(self, 'energies') and self.energies is not None:
            # Use Method 1's intelligent VBM/CBM detection
            vbm_mask = self.occupations > 0.1
            if np.any(vbm_mask):
                vbm_val = np.max(self.energies[vbm_mask])
                vbm_idx = np.unravel_index(
                    np.argmax(self.energies * vbm_mask - 1e10 * (~vbm_mask)), 
                    self.energies.shape
                )
            else:
                vbm_val = self.fermi
                vbm_idx = (0, 0)
            
            cbm_mask = self.occupations <= 0.1
            if np.any(cbm_mask):
                cbm_val = np.min(self.energies[cbm_mask])
                cbm_idx = np.unravel_index(
                    np.argmin(self.energies * cbm_mask + 1e10 * (~cbm_mask)), 
                    self.energies.shape
                )
            else:
                cbm_val = self.fermi
                cbm_idx = (0, 0)
            
            bandgap = cbm_val - vbm_val
            is_direct = (vbm_idx[0] == cbm_idx[0])
            vbm_energy_rel = vbm_val - self.fermi
            cbm_energy_rel = cbm_val - self.fermi
            
            # Update bandgap_info with more accurate data
            if bandgap > 1e-6:
                self.bandgap_info = {
                    "has_bandgap": True,
                    "bandgap": bandgap,
                    "is_direct": is_direct,
                    "E_vb": vbm_energy_rel,
                    "E_cb": cbm_energy_rel,
                    "message": "Calculated using enhanced occupation-based method."
                }
        else:
            # Fall back to existing bandgap_info
            vbm_energy_rel = self.bandgap_info.get('E_vb', 0)
            cbm_energy_rel = self.bandgap_info.get('E_cb', 0)
            bandgap = self.bandgap_info.get('bandgap', 0)
            is_direct = self.bandgap_info.get('is_direct', False)
        
        # --- Plot all bands relative to Fermi energy ---
        for i in range(bands.shape[0]):
            # Optional: Color bands by occupation if data available
            if has_advanced_data and hasattr(self, 'occupations'):
                avg_occ = np.mean(self.occupations[:, i])
                color = 'blue' if avg_occ > 0.5 else 'red'
            else:
                color = 'g-'
            
            ax.plot(kpoints, bands[i, :] - self.fermi, 
                color=color, alpha=0.7, linewidth=1.0)
        
        # --- Enhanced: Calculate and use proper k-point distances if coordinates available ---
        if hasattr(self, 'k_coords') and self.k_coords is not None and len(self.k_coords) > 0:
            # Calculate actual distances along k-path
            distances = [0.0]
            ticks = [0.0]
            tick_labels = []
            
            if hasattr(self, 'special_points') and self.special_points and self.special_points[0]:
                tick_labels.append(self.special_points[0])
            
            for i in range(1, len(self.k_coords)):
                d = np.linalg.norm(self.k_coords[i] - self.k_coords[i-1])
                distances.append(distances[-1] + d)
                if hasattr(self, 'special_points') and self.special_points and self.special_points[i]:
                    ticks.append(distances[-1])
                    tick_labels.append(self.special_points[i])
            
            # Re-plot with proper x-axis scaling
            ax.clear()
            for i in range(bands.shape[0]):
                if has_advanced_data and hasattr(self, 'occupations'):
                    avg_occ = np.mean(self.occupations[:, i])
                    color = 'blue' if avg_occ > 0.5 else 'red'
                else:
                    color = 'green'
                ax.plot(distances, bands[i, :] - self.fermi, 
                    color=color, alpha=0.7, linewidth=1.0)
            
            # Add vertical lines at symmetry points
            for tick in ticks:
                ax.axvline(tick, color='black', lw=0.5, alpha=0.3)
            ax.set_xticks(ticks)
            ax.set_xticklabels(tick_labels, fontsize=12, fontweight='bold')
            x_axis_label = 'Wave Vector'
        else:
            distances = kpoints
            x_axis_label = 'Wave Vector'
        
        # --- Add shaded regions for bands (using existing ranges) ---
        ax.axhspan(self.vb_lower, self.vb_upper, 
                color='blue', alpha=0.2, label='Valence Band')
        ax.axhspan(self.cb_lower, self.cb_upper, 
                color='red', alpha=0.2, label='Conduction Band')
        
        # --- Mark VBM and CBM points (enhanced) ---
        if has_advanced_data and hasattr(self, 'k_coords') and self.k_coords is not None:
            # Use the actual indices from occupation detection
            if 'vbm_idx' in locals():
                vbm_k = distances[vbm_idx[0]] if isinstance(distances, list) else distances[vbm_idx[0]]
                cbm_k = distances[cbm_idx[0]] if isinstance(distances, list) else distances[cbm_idx[0]]
                ax.scatter(vbm_k, vbm_energy_rel, color='blue', s=100, 
                        edgecolors='black', zorder=5, label='VBM')
                ax.scatter(cbm_k, cbm_energy_rel, color='red', s=100, 
                        edgecolors='black', zorder=5, label='CBM')
        
        # --- Reference line ---
        ax.axhline(y=0, color='k', linestyle='--', linewidth=1.5, label='Fermi Level (0 eV)')
        
        # --- Labels and formatting ---
        ax.set_xlabel(x_axis_label)
        ax.set_ylabel('Energy - E$_F$ (eV)')
        ax.grid(True, alpha=0.3)
        
        # --- Enhanced title with bandgap information ---
        if bandgap > 1e-6:
            gap_type = "Direct" if is_direct else "Indirect"
            title = f"Band Structure with Highlighted Regions\nBandgap: {bandgap:.3f} eV ({gap_type})"
        else:
            title = "Band Structure with Highlighted Regions"
        
        ax.set_title(title)
        
        # --- Legend (remove duplicates) ---
        handles, labels = ax.get_legend_handles_labels()
        by_label = dict(zip(labels, handles))
        ax.legend(by_label.values(), by_label.keys(), loc='upper right', frameon=True)

    def get_bandgap_info(self):
        """Return bandgap information as formatted string"""
        info = self.bandgap_info
        
        info_string = ""
        if info.get('has_bandgap', False):
            gap_type = "Direct" if info.get('is_direct', False) else "Indirect"
            info_string = (f"Bandgap Information:\n"
                           f"Calculation Method: {info.get('message', 'N/A')}\n"
                           f"Type: {gap_type}\n"
                           f"E_vb (Valence Band Max): {info['E_vb']:.4f} eV (relative to Fermi)\n"
                           f"E_cb (Conduction Band Min): {info['E_cb']:.4f} eV (relative to Fermi)\n"
                           f"Bandgap (E_gap = E_cb - E_vb): {info['bandgap']:.4f} eV\n\n")
        else:
            info_string = info.get('message', "No bandgap detected (metallic or zero-gap).")
            
        return info_string


class CustomMessageBox(QDialog):
    def __init__(self, title, message, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setModal(True)
        
        layout = QVBoxLayout(self)
        
        # Message text
        self.message_label = QLabel(message)
        self.message_label.setWordWrap(True)
        layout.addWidget(self.message_label)
        
        # Button frame
        button_layout = QHBoxLayout()
        
        # Copy button
        self.copy_button = QPushButton("Copy")
        self.copy_button.clicked.connect(self.copy_message)
        button_layout.addWidget(self.copy_button)
        
        # Status label
        self.copy_status_label = QLabel("")
        button_layout.addWidget(self.copy_status_label)
        
        # OK button
        self.ok_button = QPushButton("OK")
        self.ok_button.clicked.connect(self.accept)
        button_layout.addWidget(self.ok_button)
        
        layout.addLayout(button_layout)
        
    def copy_message(self):
        # Copy text to clipboard
        QApplication.clipboard().setText(self.message_label.text())
        self.copy_status_label.setText("Copied!")

class DataPreviewTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.layout = QVBoxLayout(self)
        self.tree_widget = QTreeWidget()
        self.tree_widget.setColumnCount(1) # Start with one column for k-points
        self.tree_widget.setHeaderLabels(["k-points"])
        self.layout.addWidget(self.tree_widget)

    def update_data(self, kpoints, bands):
        self.tree_widget.clear()
        
        # Clear previous headers
        self.tree_widget.setHeaderLabels([])
        
        # Set up new headers
        headers = ["k-point"]
        for i in range(bands.shape[0]):
            headers.append(f"Band {i+1}")
        self.tree_widget.setColumnCount(len(headers))
        self.tree_widget.setHeaderLabels(headers)

        # Populate the tree widget with data
        for i in range(len(kpoints)):
            item = QTreeWidgetItem(self.tree_widget)
            item.setText(0, f"{kpoints[i]:.4f}")
            for j in range(bands.shape[0]):
                value = bands[j, i]
                text = f"{value:.4f}" if not np.isnan(value) else "NaN"
                item.setText(j + 1, text)
                
class BandsWidget(QWidget):
    """
    PySide6 widget for plotting and analyzing band structures.
    """
    def __init__(self, parent=None, initial_dir=None):
        super().__init__(parent)
        self.initial_dir = initial_dir
        
        # Initialize components
        self._setup_variables()
        self._create_widgets()
        self._setup_layout()
        self._connect_signals()
        
        self.bands_maker = None
        self.bands_data = None
        self.kpoints_data = None

    def closeEvent(self, event):
        """Clean up matplotlib resources when widget is closed."""
        if hasattr(self, 'fig'):
            plt.close(self.fig)
        event.accept()

    def _setup_variables(self):
        """Initialize all variables and other attributes."""
        # Path variables
        self.input_file_path = ""
        self.kpoints_file_path = ""
        
        # K-points mode variable (file or manual)
        self.kpoints_mode = 'file'
        
        # Manual k-points input variables
        self.manual_kpoints = []
        
        # Energy variables
        self.fermi_energy = 0.0 # Valor inicial por defecto
        self.vb_lower = -2.0
        self.vb_upper = -1.0
        self.cb_lower = 1.0
        self.cb_upper = 2.0
        
        # Plot range variables
        self.y_min = -6
        self.y_max = 4
        self.x_min = 0
        self.x_max = 5

    def _create_widgets(self):
        """Create all widget components."""
        # Font configuration
        self.myfont = QFont("Times", 12)
        
        # Create tab widget
        self.tab_widget = QTabWidget()
        
        # Main tab
        self.main_tab = QWidget()
        self._create_main_tab()
        
        # Advanced tab
        self.advanced_tab = QWidget()
        self._create_advanced_tab()
        
        # Manual K-points tab
        self.manual_kpoints_tab = QWidget()
        self._create_manual_kpoints_tab()

        # Plot Preview tab
        self.plot_tab = QWidget()
        self._create_plot_preview_tab()

        # K-points File Preview tab
        self.kpoints_file_preview_tab = QWidget()
        self._create_kpoints_file_preview_tab()
        
        # Bandgap Info tab
        self.bandgap_tab = QWidget()
        self._create_bandgap_tab()

        # NEW: Data Preview tab
        self.data_preview_tab = DataPreviewTab()

        # NEW: Bandgap Explanation tab
        self.bandgap_explanation_tab = QWidget()
        self._create_bandgap_explanation_tab()

        # Add tabs to tab widget
        self.tab_widget.addTab(self.main_tab, "Main")
        self.tab_widget.addTab(self.manual_kpoints_tab, "Manual K-points")
        self.tab_widget.addTab(self.kpoints_file_preview_tab, "K-points File Preview")
        self.tab_widget.addTab(self.data_preview_tab, "Data Preview")
        self.tab_widget.addTab(self.advanced_tab, "Plot settings")
        self.tab_widget.addTab(self.plot_tab, "Plot Preview")
        self.tab_widget.addTab(self.bandgap_tab, "Bandgap Info")
        self.tab_widget.addTab(self.bandgap_explanation_tab, "Bandgap Explanation")
        
        # Action buttons
        self._create_action_buttons()

    def _create_main_tab(self):
        """Create widgets for main tab."""
        layout = QVBoxLayout(self.main_tab)
        
        # Input file section
        input_file_label = QLabel("Input File:")
        layout.addWidget(input_file_label)
        
        input_file_layout = QHBoxLayout()
        self.input_file_entry = QLineEdit()
        self.browse_input_button = QPushButton("Browse")
        self.browse_input_button.clicked.connect(self._browse_input_file)
        
        input_file_layout.addWidget(self.input_file_entry)
        input_file_layout.addWidget(self.browse_input_button)
        layout.addLayout(input_file_layout)
        
        # Fermi energy section
        fermi_layout = QHBoxLayout()
        fermi_label = QLabel("Fermi Energy (eV):")
        self.fermi_spinbox = QDoubleSpinBox()
        self.fermi_spinbox.setDecimals(3)
        self.fermi_spinbox.setRange(-1000, 1000)
        self.fermi_spinbox.setSingleStep(0.00001)
        self.fermi_spinbox.setValue(self.fermi_energy)
        self.search_fermi_button = QPushButton("Search in .out")
        self.search_fermi_button.clicked.connect(self._search_fermi_in_out_file)
        
        fermi_layout.addWidget(fermi_label)
        fermi_layout.addWidget(self.fermi_spinbox)
        fermi_layout.addWidget(self.search_fermi_button)
        layout.addLayout(fermi_layout)
        
        # K-points section
        kpoints_group = QGroupBox("K-points Configuration")
        kpoints_layout = QVBoxLayout(kpoints_group)
        
        self.kpoints_file_radio = QRadioButton("Use k-points.json file")
        kpoints_layout.addWidget(self.kpoints_file_radio)
        
        self.kpoints_manual_radio = QRadioButton("Define k-points manually")
        self.kpoints_manual_radio.setChecked(True)
        kpoints_layout.addWidget(self.kpoints_manual_radio)
        
        kpoints_file_layout = QHBoxLayout()
        self.kpoints_file_entry = QLineEdit()
        self.kpoints_file_entry.setEnabled(False)
        self.browse_kpoints_button = QPushButton("Browse")
        self.browse_kpoints_button.clicked.connect(self._browse_kpoints_file)
        self.browse_kpoints_button.setEnabled(False)
        
        kpoints_file_layout.addWidget(self.kpoints_file_entry)
        kpoints_file_layout.addWidget(self.browse_kpoints_button)
        kpoints_layout.addLayout(kpoints_file_layout)
        
        layout.addWidget(kpoints_group)
        
        # Connect radio buttons to toggle function
        self.kpoints_file_radio.toggled.connect(self._toggle_kpoints_mode)
        self.kpoints_manual_radio.toggled.connect(self._toggle_kpoints_mode)
        
        # Bandgap calculation method section
        bandgap_group = QGroupBox("Bandgap Calculation Method")
        bandgap_layout = QVBoxLayout(bandgap_group)

        self.calc_auto_radio = QRadioButton("Automatic")
        self.calc_auto_radio.setChecked(True)
        self.calc_manual_radio = QRadioButton("Manual (Use ranges from 'Plot settings' tab)")

        bandgap_layout.addWidget(self.calc_auto_radio)
        bandgap_layout.addWidget(self.calc_manual_radio)
        layout.addWidget(bandgap_group)

        self.calc_auto_radio.toggled.connect(self._toggle_bandgap_calc_mode)
        
        # Matplotlib window option
        self.matplotlib_window_checkbox = QCheckBox("Show plot in separate matplotlib window")
        # layout.addWidget(self.matplotlib_window_checkbox)

    def _create_advanced_tab(self):
        """Create widgets for advanced tab."""
        layout = QGridLayout(self.advanced_tab)
        
        row_idx = 0
        
        # Fermi energy
        layout.addWidget(QLabel("Fermi Energy (eV):"), row_idx, 0)
        self.fermi_spinbox_adv = QDoubleSpinBox()
        self.fermi_spinbox_adv.setDecimals(3)
        self.fermi_spinbox_adv.setRange(-1000, 1000)
        self.fermi_spinbox_adv.setSingleStep(0.0001)
        self.fermi_spinbox_adv.setValue(self.fermi_energy)
        layout.addWidget(self.fermi_spinbox_adv, row_idx, 1)
        row_idx += 1
        
        # Valence band range
        layout.addWidget(QLabel("Valence Band Range:"), row_idx, 0, 1, 2)
        row_idx += 1
        
        layout.addWidget(QLabel("  Lower:"), row_idx, 0)
        self.vb_lower_spinbox = QDoubleSpinBox()
        self.vb_lower_spinbox.setRange(-1000, 1000)
        self.vb_lower_spinbox.setSingleStep(0.1)
        self.vb_lower_spinbox.setValue(self.vb_lower)
        layout.addWidget(self.vb_lower_spinbox, row_idx, 1)
        row_idx += 1
        
        layout.addWidget(QLabel("  Upper:"), row_idx, 0)
        self.vb_upper_spinbox = QDoubleSpinBox()
        self.vb_upper_spinbox.setRange(-1000, 1000)
        self.vb_upper_spinbox.setSingleStep(0.1)
        self.vb_upper_spinbox.setValue(self.vb_upper)
        layout.addWidget(self.vb_upper_spinbox, row_idx, 1)
        row_idx += 1
        
        # Conduction band range
        layout.addWidget(QLabel("Conduction Band Range:"), row_idx, 0, 1, 2)
        row_idx += 1
        
        layout.addWidget(QLabel("  Lower:"), row_idx, 0)
        self.cb_lower_spinbox = QDoubleSpinBox()
        self.cb_lower_spinbox.setRange(-1000, 1000)
        self.cb_lower_spinbox.setSingleStep(0.1)
        self.cb_lower_spinbox.setValue(self.cb_lower)
        layout.addWidget(self.cb_lower_spinbox, row_idx, 1)
        row_idx += 1
        
        layout.addWidget(QLabel("  Upper:"), row_idx, 0)
        self.cb_upper_spinbox = QDoubleSpinBox()
        self.cb_upper_spinbox.setRange(-1000, 1000)
        self.cb_upper_spinbox.setSingleStep(0.1)
        self.cb_upper_spinbox.setValue(self.cb_upper)
        layout.addWidget(self.cb_upper_spinbox, row_idx, 1)
        row_idx += 1
        
        # Plot range controls
        layout.addWidget(QLabel("Plot Range (eV):"), row_idx, 0, 1, 2)
        row_idx += 1
        
        layout.addWidget(QLabel("  Y min:"), row_idx, 0)
        self.y_min_spinbox = QDoubleSpinBox()
        self.y_min_spinbox.setRange(-1000, 1000)
        self.y_min_spinbox.setSingleStep(0.1)
        self.y_min_spinbox.setValue(self.y_min)
        layout.addWidget(self.y_min_spinbox, row_idx, 1)
        row_idx += 1
        
        layout.addWidget(QLabel("  Y max:"), row_idx, 0)
        self.y_max_spinbox = QDoubleSpinBox()
        self.y_max_spinbox.setRange(-1000, 1000)
        self.y_max_spinbox.setSingleStep(0.1)
        self.y_max_spinbox.setValue(self.y_max)
        layout.addWidget(self.y_max_spinbox, row_idx, 1)

    def _create_manual_kpoints_tab(self):
        """Create the table view and input fields for manual k-points data."""
        layout = QVBoxLayout(self.manual_kpoints_tab)
        
        # Tree widget for k-points
        self.manual_kpoints_tree = QTreeWidget()
        self.manual_kpoints_tree.setHeaderLabels(["Label", "k_x", "k_y", "k_z"])
        self.manual_kpoints_tree.header().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.manual_kpoints_tree)
        
        # Input frame
        input_frame = QWidget()
        input_layout = QGridLayout(input_frame)
        
        # Label input
        input_layout.addWidget(QLabel("Label:"), 0, 0)
        self.manual_label_input = QLineEdit()
        input_layout.addWidget(self.manual_label_input, 0, 1, 1, 3)
        
        # Coordinate inputs
        input_layout.addWidget(QLabel("k_x:"), 1, 0)
        self.manual_x_input = QLineEdit("0.0")
        self.manual_x_input.setValidator(QDoubleValidator())
        input_layout.addWidget(self.manual_x_input, 1, 1)
        
        input_layout.addWidget(QLabel("k_y:"), 1, 2)
        self.manual_y_input = QLineEdit("0.0")
        self.manual_y_input.setValidator(QDoubleValidator())
        input_layout.addWidget(self.manual_y_input, 1, 3)
        
        input_layout.addWidget(QLabel("k_z:"), 2, 0)
        self.manual_z_input = QLineEdit("0.0")
        self.manual_z_input.setValidator(QDoubleValidator())
        input_layout.addWidget(self.manual_z_input, 2, 1)
        
        # Buttons
        self.add_kpoint_button = QPushButton("Add Point")
        self.add_kpoint_button.clicked.connect(self._add_manual_kpoint)
        input_layout.addWidget(self.add_kpoint_button, 3, 0, 1, 2)
        
        self.clear_kpoints_button = QPushButton("Clear All")
        self.clear_kpoints_button.clicked.connect(self._clear_manual_kpoints)
        input_layout.addWidget(self.clear_kpoints_button, 3, 2, 1, 2)
        
        layout.addWidget(input_frame)

    def _create_plot_preview_tab(self):
        """Create the matplotlib plot area."""
        layout = QVBoxLayout(self.plot_tab)
        
        # Create matplotlib figure and canvas
        self.fig = Figure(figsize=(8, 5), layout='constrained')
        self.ax = self.fig.add_subplot(111)
        self.canvas = FigureCanvas(self.fig)
        
        layout.addWidget(self.canvas)

    def _create_kpoints_file_preview_tab(self):
        """Create the table view for k-points data from file."""
        layout = QVBoxLayout(self.kpoints_file_preview_tab)
        
        # Tree widget for k-points from file
        self.kpoints_tree = QTreeWidget()
        self.kpoints_tree.setHeaderLabels(["Label", "k_x", "k_y", "k_z"])
        self.kpoints_tree.header().setSectionResizeMode(QHeaderView.Stretch)
        
        layout.addWidget(self.kpoints_tree)

    def _create_bandgap_tab(self):
        """Create the bandgap information display."""
        layout = QVBoxLayout(self.bandgap_tab)
        
        self.bandgap_text = QTextEdit()
        self.bandgap_text.setReadOnly(True)
        self.bandgap_text.setPlaceholderText("Bandgap information will appear here after analysis")
        
        layout.addWidget(self.bandgap_text)

    def _create_bandgap_explanation_tab(self):
        """Create the bandgap explanation display tab."""
        layout = QVBoxLayout(self.bandgap_explanation_tab)
        
        explanation_text = QTextEdit()
        explanation_text.setReadOnly(True)
        explanation_text.setHtml("""
            <h3>Bandgap Calculation Methods</h3>
            <hr>
            <h4>1. Automatic Method</h4>
            <p>This method is the default and most robust option. It automatically scans all bands to find the <b>valence band global maximum (VBM)</b> and the <b>conduction band global minimum (CBM)</b>.</p>
            <ul>
            <li><b>Operation:</b> The algorithm identifies the VBM as the highest energy that is equal to or lower than the Fermi level (0 eV on the relative scale). Similarly, the CBM is identified as the lowest energy that is equal to or above the Fermi level. The <b>bandgap</b> is calculated as the difference between these two energies.</li>
            <li><b>Advantages:</b> It does not require any manual configuration. It is ideal for obtaining a value of the fundamental bandgap of the material quickly and accurately, without the need to define energy ranges manually.</li>
            </ul>
            <h4>2. Manual Method</h4>
            <p>This method gives you full control over the energy regions for the <i>bandgap</i> calculation. It requires the user to define the energy ranges for the valence and conduction bands in the <b>‘Plot settings’</b> tab.</p> <p>.
            <ul>
                <li><b>Working:</b> The algorithm will search for the highest energy within your defined valence bandgap range and the lowest energy within your defined conduction bandgap range. The <b>bandgap</b> will be the difference between these two values.</li>
                <li><b>Advantages:</b> It is useful for analyzing indirect <i>bandgaps</i> or for examining the spacing between specific valence and conduction bands that are not the fundamental VBM and CBM. It allows you to ignore other bands that might be close to the Fermi level.</li>
            </ul>
        """)
        explanation_text.setPlaceholderText("Bandgap explanation will appear here.")
        
        layout.addWidget(explanation_text)


    def _create_action_buttons(self):
        """Create action buttons."""
        self.action_layout = QHBoxLayout()
        
        self.pure_bands_button = QPushButton("Pure Bands")
        self.pure_bands_button.clicked.connect(lambda: self._run_analysis('pure'))
        self.action_layout.addWidget(self.pure_bands_button)
        
        self.fermi_bands_button = QPushButton("Fermi Bands")
        self.fermi_bands_button.clicked.connect(lambda: self._run_analysis('fermi'))
        self.action_layout.addWidget(self.fermi_bands_button)
        
        self.final_bands_button = QPushButton("Final Bands")
        self.final_bands_button.clicked.connect(lambda: self._run_analysis('final'))
        self.action_layout.addWidget(self.final_bands_button)
        
        self.save_plot_button = QPushButton("Save Plot")
        self.save_plot_button.clicked.connect(self._save_plot)
        self.action_layout.addWidget(self.save_plot_button)
        
        self.clear_plot_button = QPushButton("Clear Plot")
        self.clear_plot_button.clicked.connect(self._clear_plot)
        self.action_layout.addWidget(self.clear_plot_button)
        
        self.close_button = QPushButton("Close")
        self.close_button.clicked.connect(self.close)
        # self.action_layout.addWidget(self.close_button)

    def _setup_layout(self):
        """Arrange widgets in the frame."""
        main_layout = QVBoxLayout(self)
        main_layout.addWidget(self.tab_widget)
        main_layout.addLayout(self.action_layout)

    def _connect_signals(self):
        """Connect signals to slots."""
        self.kpoints_file_radio.toggled.connect(self._toggle_kpoints_mode)
        self.kpoints_manual_radio.toggled.connect(self._toggle_kpoints_mode)
        self.calc_auto_radio.toggled.connect(self._toggle_bandgap_calc_mode)

        # Connect main Fermi spinbox to advanced one
        self.fermi_spinbox.valueChanged.connect(self.fermi_spinbox_adv.setValue)
        self.fermi_spinbox_adv.valueChanged.connect(self.fermi_spinbox.setValue)

    def _toggle_bandgap_calc_mode(self, checked):
        """Enable/disable manual bandgap range spinboxes based on radio button state."""
        if checked: # Automatic is checked
            self.vb_lower_spinbox.setEnabled(False)
            self.vb_upper_spinbox.setEnabled(False)
            self.cb_lower_spinbox.setEnabled(False)
            self.cb_upper_spinbox.setEnabled(False)
        else: # Manual is checked
            self.vb_lower_spinbox.setEnabled(True)
            self.vb_upper_spinbox.setEnabled(True)
            self.cb_lower_spinbox.setEnabled(True)
            self.cb_upper_spinbox.setEnabled(True)

    def _show_custom_messagebox(self, title, message):
        """Creates and displays a custom message box with a copy button."""
        dialog = CustomMessageBox(title, message, self)
        dialog.exec()

    def _search_fermi_in_out_file(self):
        """Searches for Fermi energy in a Quantum ESPRESSO or CP2K output file."""
        filepath, _ = QFileDialog.getOpenFileName(
            self,
            "Select output file (.out)",
            self.initial_dir if self.initial_dir else str(Path.cwd()),
            "Output files (*.out);;CP2K PDOS (*.pdos);;All files (*.*)"
        )
        if filepath:
            try:
                with open(filepath, 'r') as f:
                    for line in f:
                        if 'Fermi energy is' in line:
                            # As per user's confirmation, use parts[4]
                            parts = line.split()
                            fermi_value = float(parts[4])
                            self.fermi_spinbox.setValue(fermi_value)
                            self._show_custom_messagebox("Success", f"Fermi energy found and updated: {fermi_value:.4f} eV")
                            return
                        # CP2K style
                        elif 'Fermi energy:' in line:
                            parts = line.split()
                            fermi_value = float(parts[2]) * 27.21138602
                            self.fermi_spinbox.setValue(fermi_value)
                            self._show_custom_messagebox("Success", f"Fermi energy found and updated: {fermi_value:.4f} eV")
                            return
                        # CP2K PDOS style
                        elif '# Projected DOS' in line:
                            parts = line.split()
                            fermi_value = float(parts[15]) * 27.21138602
                            self.fermi_spinbox.setValue(fermi_value)
                            self._show_custom_messagebox("Success", f"Fermi energy found and updated: {fermi_value:.4f} eV")
                            return
                self._show_custom_messagebox("Error", "Could not find 'Fermi energy' line in the file.")
            except FileNotFoundError:
                self._show_custom_messagebox("File Error", f"The file was not found: {filepath}")
            except Exception as e:
                self._show_custom_messagebox("Error", f"An error occurred while reading the file: {e}")

    def _browse_input_file(self):
        """Handle browse for input file."""
        filepath, _ = QFileDialog.getOpenFileName(
            self,
            "Select bands.out file",
            self.initial_dir if self.initial_dir else str(Path.cwd()),
            "GNU file (*.gnu);;Bands output (*.out);;All files (*.*)"
        )
        if filepath:
            self.input_file_entry.setText(filepath)

    def _browse_kpoints_file(self):
        """Handle browse for k-points file and update the table."""
        filepath, _ = QFileDialog.getOpenFileName(
            self,
            "Select k-points.json file",
            self.initial_dir if self.initial_dir else str(Path.cwd()),
            "K-points JSON (*.json);;All files (*.*)"
        )
        if filepath:
            self.kpoints_file_entry.setText(filepath)
            self._load_kpoints_data_to_table(filepath)

    def _load_kpoints_data_to_table(self, filepath):
        """Loads and displays k-points data from the 'kpoints' dictionary in the table view."""
        # Clear existing data from the treeview
        self.kpoints_tree.clear()

        try:
            with open(filepath, 'r') as f:
                data = json.load(f)

            # Check for the correct key and data type
            if "kpoints" not in data or not isinstance(data.get("kpoints"), dict):
                self._show_custom_messagebox(
                    "Invalid File Format", 
                    "The selected JSON file does not contain a 'kpoints' dictionary."
                )
                return

            # Iterate through the dictionary of k-points
            for label, coords in data["kpoints"].items():
                # Ensure coordinates are a list of at least 3 elements
                if not isinstance(coords, list):
                    coords = []

                coords = (coords + [0.0, 0.0, 0.0])[:3]
                
                item = QTreeWidgetItem(self.kpoints_tree)
                item.setText(0, label)
                item.setText(1, f"{coords[0]:.4f}")
                item.setText(2, f"{coords[1]:.4f}")
                item.setText(3, f"{coords[2]:.4f}")

        except FileNotFoundError:
            self._show_custom_messagebox("Error", "File not found.")
        except json.JSONDecodeError:
            self._show_custom_messagebox("Error", "The selected file is not a valid JSON file.")
        except Exception as e:
            self._show_custom_messagebox("Error", f"An error occurred while loading the file: {e}")

    def _toggle_kpoints_mode(self):
        """Toggle k-points file entry and button state based on the selected radio button."""
        if self.kpoints_file_radio.isChecked():
            self.kpoints_file_entry.setEnabled(True)
            self.browse_kpoints_button.setEnabled(True)
            self.kpoints_mode = 'file'
        else:
            self.kpoints_file_entry.setEnabled(False)
            self.browse_kpoints_button.setEnabled(False)
            self.kpoints_mode = 'manual'

    def _add_manual_kpoint(self):
        """Adds a new k-point from the input fields to the Treeview."""
        label = self.manual_label_input.text().strip()
        try:
            k_x = float(self.manual_x_input.text())
            k_y = float(self.manual_y_input.text())
            k_z = float(self.manual_z_input.text())
            
            if not label:
                self._show_custom_messagebox("Input Error", "K-point label cannot be empty.")
                return
            
            item = QTreeWidgetItem(self.manual_kpoints_tree)
            item.setText(0, label)
            item.setText(1, f"{k_x:.4f}")
            item.setText(2, f"{k_y:.4f}")
            item.setText(3, f"{k_z:.4f}")
            
            # Clear input fields after adding
            self.manual_label_input.clear()
            self.manual_x_input.setText("0.0")
            self.manual_y_input.setText("0.0")
            self.manual_z_input.setText("0.0")
            
        except ValueError:
            self._show_custom_messagebox("Input Error", "Please enter valid numeric values for k-point coordinates.")

    def _clear_manual_kpoints(self):
        """Clears all entries from the manual k-points Treeview."""
        self.manual_kpoints_tree.clear()

    def _validate_inputs(self):
        """Validate all required inputs."""
        if not self.input_file_entry.text():
            self._show_custom_messagebox("Input Required", "Please select an input file")
            return False
            
        # Verify that the file exists
        input_file = self.input_file_entry.text()
        if not Path(input_file).exists():
            self._show_custom_messagebox("File Error", f"Input file does not exist:\n{input_file}")
            return False
            
        # Also verify that it is readable
        if not os.access(input_file, os.R_OK):
            self._show_custom_messagebox("File Error", f"No read permissions for file:\n{input_file}")
            return False
            
        if self.kpoints_mode == 'file':
            if not self.kpoints_file_entry.text():
                self._show_custom_messagebox("Input Required", "Please select a k-points file")
                return False
            
            # Verify that the kpoints file exists
            kpoints_file = self.kpoints_file_entry.text()
            if not Path(kpoints_file).exists():
                self._show_custom_messagebox("File Error", f"K-points file does not exist:\n{kpoints_file}")
                return False
                
            if not os.access(kpoints_file, os.R_OK):
                self._show_custom_messagebox("File Error", f"No read permissions for k-points file:\n{kpoints_file}")
                return False
        
        if self.kpoints_mode == 'manual' and self.manual_kpoints_tree.topLevelItemCount() == 0:
            self._show_custom_messagebox("Input Required", "Please add at least one k-point manually.")
            return False
        
        if self.calc_manual_radio.isChecked():
            if self.vb_lower_spinbox.value() >= self.vb_upper_spinbox.value():
                self._show_custom_messagebox("Invalid Range", "Valence band lower must be less than upper")
                return False
                
            if self.cb_lower_spinbox.value() >= self.cb_upper_spinbox.value():
                self._show_custom_messagebox("Invalid Range", "Conduction band lower must be less than upper")
                return False
            
        return True

    def _run_analysis(self, plot_type):
        """Execute band structure analysis and plot."""
        if not self._validate_inputs():
            return
        
        input_file = self.input_file_entry.text()
        kpoints_file = None

        # logging.debug(f"Starting analysis with plot_type: {plot_type}")
        # logging.debug(f"Input file: {input_file}")
        # logging.debug(f"Kpoints mode: {self.kpoints_mode}")

        if self.kpoints_mode == 'file':
            kpoints_file = self.kpoints_file_entry.text()
            try:
                with open(kpoints_file, 'r') as f:
                    kpoints_dict = json.load(f).get("kpoints", {})
                # logging.debug(f"Loaded {len(kpoints_dict)} k-points from file")
            except Exception as e:
                self._show_custom_messagebox("Error", f"Failed to read k-points file: {e}")
                logging.error(f"Error reading k-points file: {e}")
                return
        else: # 'manual'
            manual_kpoints_data = {}
            for i in range(self.manual_kpoints_tree.topLevelItemCount()):
                item = self.manual_kpoints_tree.topLevelItem(i)
                label = item.text(0)
                k_x = float(item.text(1))
                k_y = float(item.text(2))
                k_z = float(item.text(3))
                manual_kpoints_data[label] = [k_x, k_y, k_z]
            kpoints_dict = manual_kpoints_data
            # logging.debug(f"Using {len(manual_kpoints_data)} manual k-points")

        # Determine calculation mode
        calc_mode = 'manual' if self.calc_manual_radio.isChecked() else 'automatic'

        try:
            # New data processing class for robustness
            bands_processor = BandsDataProcessor(bands_file=input_file, kpoints_data=kpoints_dict)
            
            # Pass user-defined ranges and calculation mode to the processor
            bands_data_dict = bands_processor.validate_and_process(
                fermi_energy=self.fermi_spinbox.value(),
                vb_lower=self.vb_lower_spinbox.value(),
                vb_upper=self.vb_upper_spinbox.value(),
                cb_lower=self.cb_lower_spinbox.value(),
                cb_upper=self.cb_upper_spinbox.value(),
                calculation_mode=calc_mode
            )

            # Update the Data Preview tab with the original data
            self.data_preview_tab.update_data(bands_data_dict["kpoints"], bands_data_dict["bands"])

            self.bands_maker = BandsMaker(
                bands_data_dict=bands_data_dict,
                fermi=self.fermi_spinbox.value(),
                vb_lower=self.vb_lower_spinbox.value(),
                vb_upper=self.vb_upper_spinbox.value(),
                cb_lower=self.cb_lower_spinbox.value(),
                cb_upper=self.cb_upper_spinbox.value()
            )

            self._update_advanced_tab_with_suggestions()

            self.ax.clear()
            self.ax.set_xlabel('Wave Vector')
            self.ax.set_ylabel('Energy (eV)')
            self.ax.set_title("Band Structure")
            self.ax.grid(True, alpha=0.3)

            if plot_type == 'pure':
                self.bands_maker.plot_pure_bands(self.ax)
            elif plot_type == 'fermi':
                self.bands_maker.plot_fermi_bands(self.ax)
            elif plot_type == 'final':
                self.bands_maker.plot_final_bands(self.ax)
            
            # Usar los valores de los spinboxes para los límites
            self.ax.set_ylim(self.y_min_spinbox.value(), self.y_max_spinbox.value())
            
            # Ajustar automáticamente los límites x basados en los kpoints
            kpoints = bands_data_dict["kpoints"]
            if len(kpoints) > 0:
                self.ax.set_xlim(np.min(kpoints), np.max(kpoints))
            
            self.canvas.draw()
            
            # Mostrar información del bandgap
            self._update_bandgap_info()
            
            # Mostrar en ventana de matplotlib si está seleccionado
            if self.matplotlib_window_checkbox.isChecked():
                self._show_matplotlib_window(plot_type)
            
            self.tab_widget.setCurrentIndex(5)  # Switch to plot preview tab
            
            self._show_custom_messagebox("Analysis Complete", "Band structure plotted successfully!")
            logging.info("Band structure analysis completed successfully")
        
        except ValueError as e:
            # Handle the specific data mismatch error with a custom message
            self._show_custom_messagebox(
                "Data Mismatch Error", 
                f"There was a data mismatch issue:\n\n{e}\n\n"
                f"Suggestions:\n"
                f"1. Check the number of k-points in your k-points file/manual entry.\n"
                f"2. Verify the number of bands in your bands.out file matches your calculation (e.g., from the `NBND` parameter)."
            )
            logging.error(f"Data mismatch error: {e}")
        
        except FileNotFoundError as e:
            error_msg = f"File not found: {e.filename if hasattr(e, 'filename') else str(e)}"
            self._show_custom_messagebox("File Error", error_msg)
            logging.error(f"File not found error: {e}")
        
        except KeyError as e:
            error_msg = f"Missing key in data: {e}"
            self._show_custom_messagebox("Key Error", error_msg)
            logging.error(f"Key error: {e}")
            
        except Exception as e:
            error_msg = f"Unexpected error: {str(e)}\n\nType: {type(e).__name__}"
            self._show_custom_messagebox("Error", error_msg)
            logging.error(f"Unexpected error: {e}", exc_info=True)

    def _update_advanced_tab_with_suggestions(self):
        """
        Updates the advanced tab spinboxes with suggested band values.
        """
        if self.calc_manual_radio.isChecked():
            return
            
        if hasattr(self.bands_maker, 'suggested_vb_lower'):
            self.vb_lower_spinbox.setValue(self.bands_maker.suggested_vb_lower)
        if hasattr(self.bands_maker, 'suggested_vb_upper'):
            self.vb_upper_spinbox.setValue(self.bands_maker.suggested_vb_upper)

        if hasattr(self.bands_maker, 'suggested_cb_lower'):
            self.cb_lower_spinbox.setValue(self.bands_maker.suggested_cb_lower)
        if hasattr(self.bands_maker, 'suggested_cb_upper'):
            self.cb_upper_spinbox.setValue(self.bands_maker.suggested_cb_upper)

    def _update_bandgap_info(self):
        """Update the bandgap information tab with calculated values."""
        if self.bands_maker:
            bandgap_info = self.bands_maker.get_bandgap_info()
            self.bandgap_text.setPlainText(bandgap_info)
            self.tab_widget.setCurrentIndex(6)  # Switch to bandgap info tab

    def _show_matplotlib_window(self, plot_type):
        """Show the plot in a separate matplotlib window."""
        try:
            fig, ax = plt.subplots(figsize=(10, 6))
            
            if plot_type == 'pure':
                self.bands_maker.plot_pure_bands(ax)
            elif plot_type == 'fermi':
                self.bands_maker.plot_fermi_bands(ax)
            elif plot_type == 'final':
                self.bands_maker.plot_final_bands(ax)
            
            # Aplicar los mismos límites que en la vista previa
            ax.set_ylim(self.y_min_spinbox.value(), self.y_max_spinbox.value())
            
            plt.tight_layout()
            plt.show()
            
        except Exception as e:
            logging.error(f"Error showing matplotlib window: {e}")

    def _save_plot(self):
        """Opens a file dialog to save the current matplotlib figure."""
        if not self.ax.has_data():
            self._show_custom_messagebox("Nothing to Save", "Please generate a plot first before trying to save it.")
            return

        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Plot",
            "",
            "PNG files (*.png);;PDF files (*.pdf);;SVG files (*.svg);;All files (*.*)"
        )
        if file_path:
            try:
                self.fig.savefig(file_path, bbox_inches='tight', dpi=300)
                self._show_custom_messagebox("Success", f"Plot saved to:\n{file_path}")
                logging.info(f"Plot saved to: {file_path}")
            except Exception as e:
                self._show_custom_messagebox("Error", f"Failed to save plot: {e}")
                logging.error(f"Error saving plot: {e}")

    def _clear_plot(self):
        """Clear the current plot."""
        self.ax.clear()
        self.ax.set_xlabel('Wave Vector')
        self.ax.set_ylabel('Energy (eV)')
        self.ax.set_title("Band Structure")
        self.ax.grid(True, alpha=0.3)
        self.canvas.draw()
        self.bandgap_text.clear()


# if __name__ == "__main__":
#     # Example usage
#     app = QApplication(sys.argv)
#     window = QMainWindow()
#     central_widget = BandsWidget()
#     window.setCentralWidget(central_widget)
#     window.setWindowTitle("Band Structure Analyzer")
#     window.resize(1000, 700)
#     window.show()
#     sys.exit(app.exec())