"""
Parser for CP2K PDOS (.pdos) files
This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

QAH is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

import numpy as np
import re
from typing import Dict, List, Optional


class CP2KPDOSParser:
    """Parse CP2K projected DOS output files"""
    
    def __init__(self):
        self.ha2ev = 27.21138602
        
    def parse(self, file_path: str) -> Dict:
        """
        Parse CP2K .pdos file
        
        Returns:
            Dictionary with:
                - eigenvalues: array of MO energies (eV)
                - occupations: array of occupations
                - projections: dict of orbital projections
                - fermi_energy: Fermi energy (eV)
                - atomic_kind: kind of atom
                - metadata: additional information
        """
        with open(file_path, 'r') as f:
            lines = f.readlines()
        
        # Extract metadata from header
        atomic_kind = None
        fermi_au = None
        orbital_labels = []
        data_start = 0
        
        for i, line in enumerate(lines):
            if line.startswith('# Projected DOS for atomic kind'):
                match = re.search(r'atomic kind (\w+).*E\(Fermi\) =\s*([\d\.\-]+)', line)
                if match:
                    atomic_kind = match.group(1)
                    fermi_au = float(match.group(2))
            
            elif line.startswith('#     MO Eigenvalue [a.u.]'):
                # Extract orbital labels from header
                parts = line.strip().split()
                if len(parts) > 4:
                    orbital_labels = parts[4:]  # Skip MO, Eigenvalue, Occupation
                data_start = i + 1
                break
        
        # Parse data
        eigenvalues = []
        occupations = []
        
        # Initialize projections dictionary with empty lists
        projections = {label: [] for label in orbital_labels}
        
        for line in lines[data_start:]:
            line = line.strip()
            if line and not line.startswith('#'):
                parts = line.split()
                if len(parts) >= 3:
                    # First number is index (skip), then eigenvalue, occupation
                    try:
                        idx = int(parts[0])
                        eigenvalue = float(parts[1])
                        occupation = float(parts[2])
                        
                        eigenvalues.append(eigenvalue)
                        occupations.append(occupation)
                        
                        # Parse orbital projections
                        for j, label in enumerate(orbital_labels):
                            if j + 3 < len(parts):
                                projections[label].append(float(parts[j + 3]))
                            else:
                                # If missing data, append 0
                                projections[label].append(0.0)
                    except (ValueError, IndexError):
                        # Skip malformed lines
                        continue
        
        # Convert to numpy arrays, handling empty arrays
        eigenvalues = np.array(eigenvalues) if eigenvalues else np.array([])
        occupations = np.array(occupations) if occupations else np.array([])
        
        for label in projections:
            projections[label] = np.array(projections[label]) if projections[label] else np.array([])
        
        # Convert energy to eV
        eigenvalues_ev = eigenvalues * self.ha2ev if eigenvalues.size > 0 else eigenvalues
        fermi_ev = fermi_au * self.ha2ev if fermi_au is not None else None
        
        # Sum by orbital type (s, p, d) - with shape checking
        orbital_sums = self._sum_by_orbital_type(projections)
        
        return {
            'eigenvalues_au': eigenvalues,
            'eigenvalues': eigenvalues_ev,
            'occupations': occupations,
            'projections': projections,
            'orbital_sums': orbital_sums,
            'fermi_energy_au': fermi_au,
            'fermi_energy': fermi_ev,
            'atomic_kind': atomic_kind,
            'n_states': len(eigenvalues),
            'metadata': {
                'source': 'cp2k',
                'type': 'pdos'
            }
        }
    
    def _sum_by_orbital_type(self, projections: Dict) -> Dict:
        """Sum projections by orbital type (s, p, d) with shape checking"""
        sums = {}
        
        # Get a reference shape from a non-empty array
        ref_shape = None
        for arr in projections.values():
            if arr.size > 0:
                ref_shape = arr.shape
                break
        
        if ref_shape is None:
            return sums  # No data at all
        
        # s orbitals
        s_sum = np.zeros(ref_shape)
        s_orbitals = ['s']
        has_s = False
        for key in s_orbitals:
            if key in projections and projections[key].size > 0:
                if projections[key].shape == ref_shape:
                    s_sum += projections[key]
                    has_s = True
        if has_s:
            sums['s'] = s_sum
        
        # p orbitals (px, py, pz)
        p_sum = np.zeros(ref_shape)
        p_orbitals = ['px', 'py', 'pz']
        has_p = False
        for key in p_orbitals:
            if key in projections and projections[key].size > 0:
                if projections[key].shape == ref_shape:
                    p_sum += projections[key]
                    has_p = True
        if has_p:
            sums['p'] = p_sum
        
        # d orbitals (d-2, d-1, d0, d+1, d+2)
        d_sum = np.zeros(ref_shape)
        d_orbitals = ['d-2', 'd-1', 'd0', 'd+1', 'd+2']
        has_d = False
        for key in d_orbitals:
            if key in projections and projections[key].size > 0:
                if projections[key].shape == ref_shape:
                    d_sum += projections[key]
                    has_d = True
        if has_d:
            sums['d'] = d_sum
        
        # Also add individual orbital projections for flexibility
        for key, arr in projections.items():
            if arr.size > 0:
                sums[key] = arr
        
        return sums


def parse_cp2k_pdos(file_path: str) -> Dict:
    """Convenience function to parse CP2K PDOS"""
    parser = CP2KPDOSParser()
    return parser.parse(file_path)