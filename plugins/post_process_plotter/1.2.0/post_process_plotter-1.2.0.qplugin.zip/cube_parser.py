"""
Parser for Gaussian cube files (CP2K output)
Based on ASE cube file format
This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

QAH is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

import numpy as np
import re
from typing import Dict, List, Tuple, Optional
from pathlib import Path


class CubeParser:
    """Parse Gaussian cube files for electrostatic potential/charge density"""
    
    def __init__(self):
        self.bohr2ang = 0.529177210903
        self.ha2ev = 27.21138602
        
    def parse(self, file_path: str) -> Dict:
        """
        Parse cube file
        
        Returns:
            Dictionary with:
                - data: 3D numpy array of values
                - atoms: list of atomic coordinates
                - atomic_numbers: list of atomic numbers
                - origin: origin coordinates
                - axes: grid axes vectors
                - shape: grid dimensions
                - metadata: additional information
        """
        with open(file_path, 'r') as f:
            lines = f.readlines()
        
        # Parse header (first 2 lines are comments)
        comment1 = lines[0].strip()
        comment2 = lines[1].strip()
        
        # Parse number of atoms and origin
        line = lines[2].strip().split()
        natoms = int(line[0])
        origin = np.array([float(x) for x in line[1:4]])
        
        # Parse grid dimensions and axes
        nx, ny, nz = 0, 0, 0
        axes = []
        
        line = lines[3].strip().split()
        nx = int(line[0])
        axes.append(np.array([float(x) for x in line[1:4]]))
        
        line = lines[4].strip().split()
        ny = int(line[0])
        axes.append(np.array([float(x) for x in line[1:4]]))
        
        line = lines[5].strip().split()
        nz = int(line[0])
        axes.append(np.array([float(x) for x in line[1:4]]))
        
        # Parse atoms
        atoms = []
        atomic_numbers = []
        for i in range(natoms):
            line = lines[6 + i].strip().split()
            atomic_number = int(line[0])
            charge = float(line[1])
            position = np.array([float(x) for x in line[2:5]])
            
            atoms.append(position)
            atomic_numbers.append(atomic_number)
        
        # Parse data (fortran-style, 6 values per line)
        data_lines = lines[6 + natoms:]
        data_values = []
        
        for line in data_lines:
            line = line.strip()
            if line:
                values = [float(x) for x in line.split()]
                data_values.extend(values)
        
        # Reshape data
        data = np.array(data_values).reshape(nx, ny, nz)
        
        # Convert to Angstroms if needed
        atoms_ang = np.array(atoms) * self.bohr2ang
        origin_ang = origin * self.bohr2ang
        axes_ang = [ax * self.bohr2ang for ax in axes]
        
        # Calculate 1D profile along specified axis
        profile_data = self._calculate_1d_profile(data, axes_ang, origin_ang)
        
        return {
            'data': data,
            'data_units': 'atomic' if 'potential' in comment1.lower() else 'e/Bohr^3',
            'atoms': atoms_ang,
            'atomic_numbers': atomic_numbers,
            'origin': origin_ang,
            'origin_au': origin,
            'axes': axes_ang,
            'axes_au': axes,
            'shape': (nx, ny, nz),
            'profile': profile_data,
            'metadata': {
                'comment1': comment1,
                'comment2': comment2,
                'source': 'cp2k',
                'type': 'cube'
            }
        }
    
    def _calculate_1d_profile(self, data_3d: np.ndarray, axes: List[np.ndarray], 
                               origin: np.ndarray, axis: int = 2) -> Dict:
        """
        Calculate 1D profile by averaging over perpendicular planes
        Used for workfunction calculation
        """
        # Average over first two dimensions (x and y)
        profile = np.mean(data_3d, axis=(0, 1))
        
        # Calculate z coordinates
        nz = data_3d.shape[2]
        z_coords = np.linspace(origin[axis], 
                                origin[axis] + axes[axis][axis] * nz, 
                                nz)
        
        return {
            'z': z_coords,
            'value': profile,
            'axis': axis
        }
    
    def calculate_workfunction(self, cube_data: Dict, fermi_energy: float, 
                                vacuum_threshold: float = 5.0) -> Dict:
        """
        Calculate workfunction from cube file
        
        Args:
            cube_data: parsed cube data
            fermi_energy: Fermi energy in eV
            vacuum_threshold: distance from top surface to start vacuum region (Angstrom)
        
        Returns:
            Dictionary with workfunction results
        """
        profile = cube_data['profile']
        z = profile['z']
        v = profile['value'] * self.ha2ev  # Convert to eV
        
        # Find vacuum region (top portion of cell)
        z_max = z[-1]
        vacuum_start = z_max - vacuum_threshold
        vacuum_mask = z >= vacuum_start
        
        if not np.any(vacuum_mask):
            vacuum_mask = z >= z_max * 0.8  # Fallback: top 20%
        
        # Calculate vacuum level
        v_vacuum = v[vacuum_mask]
        v_vacuum_avg = np.mean(v_vacuum)
        v_vacuum_std = np.std(v_vacuum)
        
        # Calculate workfunction
        work_function = v_vacuum_avg - fermi_energy
        
        return {
            'fermi_energy': fermi_energy,
            'vacuum_level': v_vacuum_avg,
            'work_function': work_function,
            'vacuum_std': v_vacuum_std,
            'vacuum_region': (z[vacuum_mask][0], z[vacuum_mask][-1]),
            'profile_data': {
                'z': z,
                'potential': v
            }
        }


def parse_cube(file_path: str) -> Dict:
    """Convenience function to parse cube file"""
    parser = CubeParser()
    return parser.parse(file_path)