"""
Unified analyzer for VASP, Quantum ESPRESSO and CP2K post-processing output.

The result dictionaries keep the ``plot_data`` layout used by the widgets:
``X``, ``Y`` and ``type``. VASP volumetric files are analysed through
``vasp_charge`` (planar average and, when possible, work function).

This file is part of QAH and is GPL-3.0-or-later.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

import numpy as np

try:  # package import inside QAH
    from .file_detector import FileFormatDetector
    from .cp2k_bands_parser import parse_cp2k_bands
    from .cp2k_dos_parser import parse_cp2k_dos
    from .cp2k_pdos_parser import parse_cp2k_pdos
    from .cube_parser import parse_cube
    from .qe_parsers import (
        parse_qe_bands,
        parse_qe_dos,
        parse_qe_pdos,
        parse_qe_potential,
    )
    from . import vasp_charge
except ImportError:  # standalone use
    from file_detector import FileFormatDetector  # type: ignore
    from cp2k_bands_parser import parse_cp2k_bands  # type: ignore
    from cp2k_dos_parser import parse_cp2k_dos  # type: ignore
    from cp2k_pdos_parser import parse_cp2k_pdos  # type: ignore
    from cube_parser import parse_cube  # type: ignore
    from qe_parsers import (  # type: ignore
        parse_qe_bands,
        parse_qe_dos,
        parse_qe_pdos,
        parse_qe_potential,
    )
    import vasp_charge  # type: ignore


class UnifiedAnalyzer:
    """Analyze VASP, QE and CP2K files with one entry point."""

    def __init__(self):
        self.detector = FileFormatDetector()

    def analyze(self, file_path: str, options: Dict[str, Any] | None = None) -> Dict[str, Any]:
        options = options or {}
        fmt, metadata = self.detector.detect_format(file_path)
        if fmt == "vasp_field":
            return self._analyze_vasp(file_path, options)
        if fmt == "cp2k_bands":
            return self._analyze_cp2k_bands(file_path, options)
        if fmt == "cp2k_dos":
            return self._analyze_cp2k_dos(file_path, options)
        if fmt == "cp2k_pdos":
            return self._analyze_cp2k_pdos(file_path, options)
        if fmt == "cube":
            return self._analyze_cube(file_path, options)
        if fmt.startswith("qe_"):
            return self._analyze_qe(file_path, options, fmt)
        return self._analyze_by_extension(file_path, options)

    # -- VASP --------------------------------------------------------------
    def _analyze_vasp(self, file_path: str, options: Dict) -> Dict:
        data = vasp_charge.read_vasp_field(file_path)
        axis = options.get("axis", 2)
        _, distance, average = vasp_charge.planar_average(data, axis=axis)
        result: Dict[str, Any] = {
            "format": f"VASP {data.kind.upper()}",
            "kind": data.kind,
            "grid": list(data.grid),
            "natoms": data.natoms,
            "volume": data.volume,
            "blocks": data.block_labels,
            "units": data.units,
            "plot_data": {
                "X": distance.tolist(),
                "Y": average.tolist(),
                "type": "potential" if data.kind == "locpot" else "dos",
                "x_label": "distance / Å",
                "y_label": "value",
            },
        }
        if data.is_density:
            result["electrons"] = data.electrons()
        if data.kind == "locpot":
            folder = Path(file_path).parent
            outcar = folder / "OUTCAR"
            eigenval = folder / "EIGENVAL"
            fermi = vasp_charge.fermi_from_outcar(outcar) if outcar.is_file() else None
            vbm = vasp_charge.vbm_from_eigenval(eigenval) if eigenval.is_file() else None
            if fermi is not None:
                result.update(
                    vasp_charge.work_function(
                        data, axis=axis, e_fermi=fermi, vbm=vbm
                    )
                )
        return result

    # -- CP2K --------------------------------------------------------------
    def _analyze_cp2k_bands(self, file_path: str, options: Dict) -> Dict:
        data = parse_cp2k_bands(file_path)
        result = {
            "format": "CP2K Bands",
            "n_kpoints": data.get("n_kpoints"),
            "n_bands": data.get("n_bands"),
            "plot_data": {
                "X": np.asarray(data["kpoints"]).tolist(),
                "Y": np.asarray(data["bands"]).T.tolist(),
                "type": "bands",
                "special_points": data.get("special_point_ticks", []),
            },
        }
        if "fermi_energy" in data:
            result["fermi_energy"] = data["fermi_energy"]
        return result

    def _analyze_cp2k_dos(self, file_path: str, options: Dict) -> Dict:
        data = parse_cp2k_dos(file_path)
        return {
            "format": "CP2K DOS",
            "n_points": data["n_points"],
            "fermi_energy": data.get("fermi_energy"),
            "plot_data": {
                "X": np.asarray(data["energy"]).tolist(),
                "Y": np.asarray(data["dos"]).tolist(),
                "type": "dos",
            },
        }

    def _analyze_cp2k_pdos(self, file_path: str, options: Dict) -> Dict:
        data = parse_cp2k_pdos(file_path)
        return {
            "format": "CP2K PDOS",
            "atomic_kind": data.get("atomic_kind"),
            "n_states": data.get("n_states"),
            "fermi_energy": data.get("fermi_energy"),
            "plot_data": {
                "X": np.asarray(data["eigenvalues"]).tolist(),
                "Y": data.get("projections"),
                "orbital_sums": data.get("orbital_sums"),
                "type": "pdos",
            },
        }

    # -- cube --------------------------------------------------------------
    def _analyze_cube(self, file_path: str, options: Dict) -> Dict:
        data = parse_cube(file_path)
        profile = data["profile"]
        return {
            "format": "Cube",
            "shape": data["shape"],
            "natoms": len(data["atoms"]),
            "plot_data": {
                "X": np.asarray(profile["z"]).tolist(),
                "Y": (np.asarray(profile["value"]) * 27.21138602).tolist(),
                "type": "potential",
                "x_label": "Distance / Å",
                "y_label": "Potential / eV",
            },
        }

    # -- Quantum ESPRESSO --------------------------------------------------
    def _analyze_qe(self, file_path: str, options: Dict, fmt: str) -> Dict:
        if fmt == "qe_bands":
            data = parse_qe_bands(file_path)
            return {
                "format": "QE Bands",
                "n_kpoints": data.get("n_kpoints"),
                "n_bands": data.get("n_bands"),
                "plot_data": {
                    "X": np.asarray(data["kpoints"]).tolist(),
                    "Y": np.asarray(data["bands"]).tolist(),
                    "type": "bands",
                },
            }
        if fmt == "qe_dos":
            data = parse_qe_dos(file_path)
            return {
                "format": "QE DOS",
                "n_points": data.get("n_points"),
                "fermi_energy": data.get("fermi_energy"),
                "plot_data": {
                    "X": np.asarray(data["energy"]).tolist(),
                    "Y": np.asarray(data["dos"]).tolist(),
                    "type": "dos",
                },
            }
        if fmt == "qe_pdos":
            data = parse_qe_pdos(file_path)
            return {
                "format": "QE PDOS",
                "n_orbitals": data.get("n_orbitals"),
                "plot_data": {
                    "X": np.asarray(data["energy"]).tolist(),
                    "Y": data.get("projections"),
                    "type": "pdos",
                },
            }
        data = parse_qe_potential(file_path)
        return {
            "format": "QE Potential",
            "plot_data": {
                "X": np.asarray(data["z"]).tolist(),
                "Y": np.asarray(data["potential"]).tolist(),
                "type": "potential",
                "x_label": "Distance / Å",
                "y_label": "Potential / eV",
            },
        }

    def _analyze_by_extension(self, file_path: str, options: Dict) -> Dict:
        suffix = Path(file_path).suffix.lower()
        mapping = {
            ".bs": ("cp2k_bands", self._analyze_cp2k_bands),
            ".dos": ("cp2k_dos", self._analyze_cp2k_dos),
            ".pdos": ("cp2k_pdos", self._analyze_cp2k_pdos),
            ".cube": ("cube", self._analyze_cube),
        }
        if suffix in mapping:
            return mapping[suffix][1](file_path, options)
        # Last resort: let the QE parsers try, as the legacy code did.
        try:
            return self._analyze_qe(file_path, options, "qe_bands")
        except Exception:
            raise ValueError(
                f"Could not recognise {Path(file_path).name}. "
                "Use 'post_process_cli.py detect' to inspect it."
            )
