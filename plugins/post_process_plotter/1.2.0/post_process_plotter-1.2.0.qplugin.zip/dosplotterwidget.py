#!/usr/bin/env python3
"""
Author: Acxel Orozco
Date: 15/08/25
Description: Density of States Plotting Widget
Features:
- Tabbed interface for better organization
- Multiple plot types (regular and shifted)
- Customizable plot ranges
- Project folder management
- Improved error handling
This file is part of Quantum Analysis Helper.
Quantum Analysis Helper is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Quantum Analysis Helper is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QLineEdit, QPushButton, QComboBox, QDoubleSpinBox, QSpinBox,
    QTabWidget, QFileDialog, QMessageBox, QGroupBox, QSizePolicy
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont


class DOSPlotterWidget(QWidget):
    def __init__(self, parent=None, initial_dir=None):
        super().__init__(parent)
        self.initial_dir = initial_dir
        
        # Initialize components
        self._setup_variables()
        self._create_widgets()
        self._setup_layout()
        self._connect_signals()
        
        self.dir_path = ""
        self.neo_path = ""

    def _setup_variables(self):
        """Initialize all variables"""
        # Path variables
        self.project_path = ""
        self.file_path = ""
        
        # Energy variables
        self.fermi_E = 9.405
        
        # Plot range variables
        self.xmin = -20
        self.xmax = 20
        self.ymin = 0
        self.ymax = 10  # Will auto-scale if 0
        
        # Plot style variables
        self.line_color = "blue"
        self.fill_color = "blue"
        self.line_width = 0.75
        self.fill_alpha = 0.25

    def _create_widgets(self):
        """Create all widget components"""
        # Font configuration
        self.myfont = QFont("Times", 12)
        
        # Create tab widget
        self.tab_widget = QTabWidget()
        
        # Main tab
        self.main_tab = QWidget()
        self._create_main_tab()
        
        # Advanced tab
        self.advanced_tab = QWidget()
        self._create_advanced_tab()
        
        # Style tab
        self.style_tab = QWidget()
        self._create_style_tab()
        
        # Add tabs to tab widget
        self.tab_widget.addTab(self.main_tab, "Main")
        self.tab_widget.addTab(self.advanced_tab, "Ranges")
        self.tab_widget.addTab(self.style_tab, "Style")
        
        # Action buttons
        self._create_action_buttons()

    def _create_main_tab(self):
        """Create widgets for main tab"""
        layout = QVBoxLayout(self.main_tab)
        
        # Project folder section
        layout.addWidget(QLabel("Project Folder:"))
        self.project_entry = QLineEdit()
        self.project_entry.setFont(self.myfont)
        layout.addWidget(self.project_entry)
        
        # DOS file section
        layout.addWidget(QLabel("DOS File:"))
        self.file_entry = QLineEdit()
        self.file_entry.setFont(self.myfont)
        layout.addWidget(self.file_entry)
        
        # Fermi energy
        layout.addWidget(QLabel("Fermi Energy (eV):"))
        self.fermi_spinbox = QDoubleSpinBox()
        self.fermi_spinbox.setValue(self.fermi_E)
        self.fermi_spinbox.setDecimals(3)
        self.fermi_spinbox.setRange(-100.00, 100.00)
        self.fermi_spinbox.setFont(self.myfont)
        layout.addWidget(self.fermi_spinbox)

    def _create_advanced_tab(self):
        """Create widgets for advanced tab"""
        layout = QVBoxLayout(self.advanced_tab)
        
        # X-axis range
        layout.addWidget(QLabel("X-axis Range:"))
        x_frame = QWidget()
        x_layout = QHBoxLayout(x_frame)
        x_layout.setContentsMargins(0, 0, 0, 0)
        
        x_layout.addWidget(QLabel("Min:"))
        self.xmin_spinbox = QDoubleSpinBox()
        self.xmin_spinbox.setMinimum(-1000.0)
        self.xmin_spinbox.setValue(self.xmin)
        x_layout.addWidget(self.xmin_spinbox)
        
        x_layout.addWidget(QLabel("Max:"))
        self.xmax_spinbox = QDoubleSpinBox()
        self.xmax_spinbox.setValue(self.xmax)
        x_layout.addWidget(self.xmax_spinbox)
        
        layout.addWidget(x_frame)
        
        # Y-axis range
        layout.addWidget(QLabel("Y-axis Range (0=auto):"))
        y_frame = QWidget()
        y_layout = QHBoxLayout(y_frame)
        y_layout.setContentsMargins(0, 0, 0, 0)
        
        y_layout.addWidget(QLabel("Min:"))
        self.ymin_spinbox = QDoubleSpinBox()
        self.ymin_spinbox.setMinimum(-1000.0)
        self.ymin_spinbox.setValue(self.ymin)
        y_layout.addWidget(self.ymin_spinbox)
        
        y_layout.addWidget(QLabel("Max:"))
        self.ymax_spinbox = QDoubleSpinBox()
        self.ymax_spinbox.setValue(self.ymax)
        y_layout.addWidget(self.ymax_spinbox)
        
        layout.addWidget(y_frame)
        
        # Add stretch to push content to top
        layout.addStretch()

    def _create_style_tab(self):
        """Create widgets for style tab"""
        layout = QVBoxLayout(self.style_tab)
        
        # Line style
        layout.addWidget(QLabel("Line Style:"))
        line_frame = QWidget()
        line_layout = QHBoxLayout(line_frame)
        line_layout.setContentsMargins(0, 0, 0, 0)
        
        line_layout.addWidget(QLabel("Color:"))
        self.line_color_combo = QComboBox()
        self.line_color_combo.addItems(["blue", "red", "green", "black", "purple", "orange"])
        self.line_color_combo.setCurrentText(self.line_color)
        line_layout.addWidget(self.line_color_combo)
        
        line_layout.addWidget(QLabel("Width:"))
        self.line_width_spinbox = QDoubleSpinBox()
        self.line_width_spinbox.setValue(self.line_width)
        self.line_width_spinbox.setRange(0.1, 5)
        self.line_width_spinbox.setSingleStep(0.1)
        line_layout.addWidget(self.line_width_spinbox)
        
        layout.addWidget(line_frame)
        
        # Fill style
        layout.addWidget(QLabel("Fill Style:"))
        fill_frame = QWidget()
        fill_layout = QHBoxLayout(fill_frame)
        fill_layout.setContentsMargins(0, 0, 0, 0)
        
        fill_layout.addWidget(QLabel("Color:"))
        self.fill_color_combo = QComboBox()
        self.fill_color_combo.addItems(["blue", "red", "green", "black", "purple", "orange"])
        self.fill_color_combo.setCurrentText(self.fill_color)
        fill_layout.addWidget(self.fill_color_combo)
        
        fill_layout.addWidget(QLabel("Alpha:"))
        self.fill_alpha_spinbox = QDoubleSpinBox()
        self.fill_alpha_spinbox.setValue(self.fill_alpha)
        self.fill_alpha_spinbox.setRange(0.1, 1)
        self.fill_alpha_spinbox.setSingleStep(0.1)
        fill_layout.addWidget(self.fill_alpha_spinbox)
        
        layout.addWidget(fill_frame)
        
        # Add stretch to push content to top
        layout.addStretch()

    def _create_action_buttons(self):
        """Create action buttons"""
        self.action_layout = QHBoxLayout()
        
        self.browse_button = QPushButton("Browse DOS File")
        self.browse_button.clicked.connect(self._browse_file)
        self.action_layout.addWidget(self.browse_button)
        
        self.regular_dos_button = QPushButton("Plot Regular DOS")
        self.regular_dos_button.clicked.connect(lambda: self._plot_dos(shifted=False))
        self.action_layout.addWidget(self.regular_dos_button)
        
        self.shifted_dos_button = QPushButton("Plot Shifted DOS")
        self.shifted_dos_button.clicked.connect(lambda: self._plot_dos(shifted=True))
        self.action_layout.addWidget(self.shifted_dos_button)
        
        self.close_button = QPushButton("Close")
        self.close_button.clicked.connect(self.hide)
        # self.action_layout.addWidget(self.close_button)

    def _setup_layout(self):
        """Arrange widgets in the frame"""
        main_layout = QVBoxLayout(self)
        main_layout.addWidget(self.tab_widget)
        main_layout.addLayout(self.action_layout)

    def _connect_signals(self):
        """Connect signals to slots"""
        # Connect spinbox value changes to update variables
        self.fermi_spinbox.valueChanged.connect(self._update_fermi_energy)
        self.xmin_spinbox.valueChanged.connect(self._update_xmin)
        self.xmax_spinbox.valueChanged.connect(self._update_xmax)
        self.ymin_spinbox.valueChanged.connect(self._update_ymin)
        self.ymax_spinbox.valueChanged.connect(self._update_ymax)
        
        # Connect combo box changes
        self.line_color_combo.currentTextChanged.connect(self._update_line_color)
        self.fill_color_combo.currentTextChanged.connect(self._update_fill_color)
        
        # Connect spinbox changes for style
        self.line_width_spinbox.valueChanged.connect(self._update_line_width)
        self.fill_alpha_spinbox.valueChanged.connect(self._update_fill_alpha)

    def _update_fermi_energy(self, value):
        self.fermi_E = value

    def _update_xmin(self, value):
        self.xmin = value

    def _update_xmax(self, value):
        self.xmax = value

    def _update_ymin(self, value):
        self.ymin = value

    def _update_ymax(self, value):
        self.ymax = value

    def _update_line_color(self, color):
        self.line_color = color

    def _update_fill_color(self, color):
        self.fill_color = color

    def _update_line_width(self, width):
        self.line_width = width

    def _update_fill_alpha(self, alpha):
        self.fill_alpha = alpha

    def _browse_file(self):
        """Browse for DOS file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select DOS File",
            self.initial_dir if self.initial_dir else str(Path.cwd()),
            "DAT files (*.dat);;All files (*.*)"
        )
        if file_path:
            self.file_entry.setText(file_path)
            self.file_path = file_path

    def _validate_inputs(self):
        """Validate all required inputs"""
        if not self.file_entry.text():
            QMessageBox.warning(self, "Input Required", "Please select a DOS file")
            return False
            
        if not Path(self.file_entry.text()).is_file():
            QMessageBox.warning(self, "File Error", "The selected file does not exist")
            return False
            
        return True

    def _get_output_directory(self):
        """Get or create output directory"""
        # Use the initial_dir passed to the widget's constructor, with a fallback
        project_path = self.initial_dir if self.initial_dir else str(Path.cwd())
        
        reply = QMessageBox.question(
            self,
            "Output Directory",
            "Would you like to use the current project folder?",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            self.dir_path = project_path
            self.project_entry.setText(self.dir_path)
        else:
            self.dir_path = QFileDialog.getExistingDirectory(
                self,
                "Select output folder",
                project_path
            )
            if not self.dir_path:
                return False
            self.project_entry.setText(self.dir_path)
        
        # Create DOS subdirectory if needed
        dos_path = Path(self.dir_path, "results", "dos")
        if Path(dos_path).exists():
            self.neo_path = dos_path
        else:
            Path(dos_path).mkdir(parents=True, exist_ok=True)
            self.neo_path = dos_path
            
        return True

    def _plot_dos(self, shifted=False):
        """Plot DOS data"""
        if not self._validate_inputs():
            return
            
        if not self._get_output_directory():
            return
            
        try:
            fermi_E = self.fermi_E
            xmin = self.xmin
            xmax = self.xmax
            ymin = self.ymin
            ymax = self.ymax
            
            # Load data
            n_energy, dos, _ = np.loadtxt(self.file_path, unpack=True)
            
            fig = plt.figure(figsize=(12, 6))
            
            if shifted:
                energy = np.subtract(n_energy, fermi_E)
                plt.plot(
                    energy, dos,
                    linewidth=self.line_width,
                    color=self.line_color
                )
                plt.xlabel(r'$E-E_{Fermi}$ (eV)')
                plt.xlim(xmin - fermi_E, xmax - fermi_E)
                plt.title("Density of States (Shifted by Fermi Energy)")
                plot_name = "dos_shifted"
            else:
                plt.plot(
                    n_energy, dos,
                    linewidth=self.line_width,
                    color=self.line_color
                )
                plt.xlabel('Energy (eV)')
                plt.xlim(xmin, xmax)
                plt.axvline(
                    x=fermi_E,
                    linewidth=0.5,
                    color='k',
                    linestyle=(0, (8, 10))
                )
                plt.text(
                    fermi_E, 4,
                    'Fermi energy',
                    fontsize='medium',
                    rotation=90
                )
                plt.fill_between(
                    n_energy, 0, dos,
                    where=(n_energy < fermi_E),
                    facecolor=self.fill_color,
                    alpha=self.fill_alpha
                )
                plt.title("Density of States")
                plot_name = "dos_regular"
            
            plt.yticks([])
            plt.ylabel('DOS')
            
            # Set Y limits if specified
            if ymax > 0:
                plt.ylim(ymin, ymax)
            
            plt.tight_layout()
            
            # Save plots
            plt.savefig(Path(self.neo_path, f"{plot_name}.png"))
            plt.savefig(Path(self.neo_path, f"{plot_name}.pdf"))
            plt.show()
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to plot data:\n{str(e)}")


if __name__ == "__main__":
    # Example usage
    from PySide6.QtWidgets import QApplication, QMainWindow
    import sys
    
    app = QApplication(sys.argv)
    window = QMainWindow()
    central_widget = DOSPlotterWidget()
    window.setCentralWidget(central_widget)
    window.show()
    sys.exit(app.exec())