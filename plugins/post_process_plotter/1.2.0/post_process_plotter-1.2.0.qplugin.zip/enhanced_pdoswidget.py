"""
Enhanced PDOS Widget with CP2K support
Using composition pattern
This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

QAH is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

import numpy as np
from pathlib import Path
import matplotlib.pyplot as plt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
    QComboBox, QGroupBox, QFileDialog, QMessageBox,
    QCheckBox
)
from PySide6.QtCore import Qt

from .file_detector import FileFormatDetector
from .cp2k_pdos_parser import parse_cp2k_pdos
from .qe_parsers import parse_qe_pdos
from .pdosplotterwidget import PDOSPlotterWidget


class EnhancedPDOSWidget(QWidget):
    """Enhanced PDOS widget using composition"""
    
    def __init__(self, parent=None, initial_dir=None):
        super().__init__(parent)
        
        # Store parameters
        self.initial_dir = initial_dir
        self.current_format = None
        self.current_file = None
        self.data = None
        self.pdos_data = {}  # Store parsed PDOS data for multiple files
        
        # Create the original PDOS widget as a child
        self.original_widget = PDOSPlotterWidget(self, initial_dir)
        
        # Create our enhanced UI
        self._setup_ui()
        
        # Connect signals
        self._connect_signals()
        
        # Conversion factors
        self.ha2ev = 27.21138602
        self.ry2ev = 13.605693
    
    def _setup_ui(self):
        """Setup the enhanced UI"""
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Create control panel for CP2K features
        control_panel = QWidget()
        control_layout = QHBoxLayout(control_panel)
        control_layout.setContentsMargins(5, 5, 5, 5)
        
        # Format indicator
        control_layout.addWidget(QLabel("Format:"))
        self.format_label = QLabel("Unknown")
        self.format_label.setStyleSheet("font-weight: bold; color: #2c3e50; padding-right: 10px;")
        control_layout.addWidget(self.format_label)
        
        # Unit conversion
        control_layout.addWidget(QLabel("Energy:"))
        self.energy_units = QComboBox()
        self.energy_units.addItems(["eV", "Ha", "Ry"])
        self.energy_units.setCurrentText("eV")
        self.energy_units.setFixedWidth(60)
        control_layout.addWidget(self.energy_units)
        
        control_layout.addStretch()
        
        # Add control panel to main layout
        main_layout.addWidget(control_panel)
        
        # Add orbital selection for CP2K
        orbital_panel = QWidget()
        orbital_layout = QHBoxLayout(orbital_panel)
        orbital_layout.setContentsMargins(5, 0, 5, 5)
        
        orbital_layout.addWidget(QLabel("Show orbitals:"))
        self.show_s = QCheckBox("s")
        self.show_s.setChecked(True)
        orbital_layout.addWidget(self.show_s)
        
        self.show_p = QCheckBox("p")
        self.show_p.setChecked(True)
        orbital_layout.addWidget(self.show_p)
        
        self.show_d = QCheckBox("d")
        self.show_d.setChecked(True)
        orbital_layout.addWidget(self.show_d)
        
        orbital_layout.addStretch()
        
        main_layout.addWidget(orbital_panel)
        
        # Add the original widget
        main_layout.addWidget(self.original_widget)
    
    def _connect_signals(self):
        """Connect signals"""
        # Connect unit changes
        self.energy_units.currentTextChanged.connect(self._on_units_changed)
        
        # Connect orbital checkboxes
        self.show_s.stateChanged.connect(self._on_orbital_selection_changed)
        self.show_p.stateChanged.connect(self._on_orbital_selection_changed)
        self.show_d.stateChanged.connect(self._on_orbital_selection_changed)
        
        # Override the original widget's file adder
        try:
            self.original_widget.add_files_button.clicked.disconnect()
        except:
            pass
        self.original_widget.add_files_button.clicked.connect(self._enhanced_add_files)
        
        # Override plot buttons
        try:
            self.original_widget.plot_energy_button.clicked.disconnect()
            self.original_widget.plot_efermi_button.clicked.disconnect()
        except:
            pass
        
        self.original_widget.plot_energy_button.clicked.connect(self._enhanced_plot_energy)
        self.original_widget.plot_efermi_button.clicked.connect(self._enhanced_plot_efermi)
    
    def _enhanced_add_files(self):
        """Enhanced file adder with format detection"""
        files, _ = QFileDialog.getOpenFileNames(
            self,
            "Select PDOS files",
            self.initial_dir if self.initial_dir else str(Path.home()),
            "Supported files (*.pdos *.dat *.txt);;CP2K PDOS (*.pdos);;DAT files (*.dat);;All files (*.*)"
        )
        
        for file_path in files:
            if file_path not in self.original_widget.file_paths:
                # Detect format
                fmt, _ = FileFormatDetector.detect_format(file_path)
                
                if fmt == 'cp2k_pdos':
                    # Parse CP2K format
                    data = parse_cp2k_pdos(file_path)
                    self.pdos_data[file_path] = data
                    
                    # Update format label for first file
                    if len(self.original_widget.file_paths) == 0:
                        self.format_label.setText('CP2K PDOS')
                    
                    # Update Fermi energy if available
                    if data.get('fermi_energy') and len(self.original_widget.file_paths) == 0:
                        self.original_widget.fermi_spinbox.setValue(data['fermi_energy'])
                        self.original_widget.fermi_E = data['fermi_energy']
                    
                elif fmt == 'qe_pdos':
                    # Parse QE format
                    data = parse_qe_pdos(file_path)
                    self.pdos_data[file_path] = data
                    
                    if len(self.original_widget.file_paths) == 0:
                        self.format_label.setText('QE PDOS')
                
                # Add to original widget's list
                self.original_widget.file_paths.append(file_path)
                self.original_widget.file_listbox.addItem(Path(file_path).name)
    
    def _get_plot_data(self, file_path):
        """Get plot data for a file based on format"""
        if file_path not in self.pdos_data:
            # Fallback to original data loader
            energy, pdos = self.original_widget.data_loader(file_path)
            return energy, [('total', pdos)]
        
        data = self.pdos_data[file_path]
        
        # Convert energy units
        energy_unit = self.energy_units.currentText().lower()
        if energy_unit == 'ev':
            energy = data['eigenvalues']
        elif energy_unit == 'ha':
            energy = data['eigenvalues_au']
        elif energy_unit == 'ry':
            energy = data['eigenvalues_au'] * self.ha2ev / self.ry2ev
        
        # Get selected orbital sums
        orbital_sums = data.get('orbital_sums', {})
        selected = []
        
        if self.show_s.isChecked() and 's' in orbital_sums:
            selected.append(('s', orbital_sums['s']))
        if self.show_p.isChecked() and 'p' in orbital_sums:
            selected.append(('p', orbital_sums['p']))
        if self.show_d.isChecked() and 'd' in orbital_sums:
            selected.append(('d', orbital_sums['d']))
        
        # If no orbitals selected, use total
        if not selected and 'projections' in data:
            total = np.zeros_like(data['eigenvalues'])
            for proj in data['projections'].values():
                total += proj
            selected.append(('total', total))
        
        return energy, selected
    
    def _on_units_changed(self):
        """Handle unit conversion changes"""
        # Just trigger a replot if there's data
        if self.original_widget.file_paths:
            self._on_orbital_selection_changed()
    
    def _on_orbital_selection_changed(self):
        """Handle orbital selection changes"""
        # This will be called when checkboxes change
        # The actual replot happens in the plot methods
        pass
    
    def _enhanced_plot_energy(self):
        """Enhanced plot DOS vs Energy"""
        if not self.original_widget.file_paths:
            QMessageBox.critical(self, "Error", "No files selected!")
            return
        
        try:
            plt.figure(figsize=(12, 6))
            colors = self.original_widget._get_colors(len(self.original_widget.file_paths) * 3)
            
            color_idx = 0
            for file_path in self.original_widget.file_paths:
                energy, orbitals = self._get_plot_data(file_path)
                
                # Get Fermi energy in correct units
                fermi = self.original_widget.fermi_E
                energy_unit = self.energy_units.currentText().lower()
                if energy_unit != 'ev':
                    if energy_unit == 'ha':
                        fermi_plot = fermi / self.ha2ev
                    elif energy_unit == 'ry':
                        fermi_plot = fermi / self.ry2ev
                else:
                    fermi_plot = fermi
                
                # Plot each orbital
                for orbital_name, orbital_data in orbitals:
                    label = self.original_widget._get_legend_label(file_path)
                    if len(orbitals) > 1:
                        label = f"{label} - {orbital_name}"
                    
                    plt.plot(energy, orbital_data, linewidth=0.75,
                            color=colors[color_idx % len(colors)], label=label)
                    plt.fill_between(energy, 0, orbital_data, where=(energy < fermi_plot),
                                   facecolor=colors[color_idx % len(colors)], alpha=0.25)
                    color_idx += 1
            
            plt.yticks([])
            plt.xlabel(f'Energy ({self.energy_units.currentText()})')
            plt.ylabel(self.original_widget.yaxis_label)
            plt.title(self.original_widget.plot_title)
            
            # Add Fermi line
            plt.axvline(x=fermi_plot, linewidth=0.5, color='k', linestyle=(0, (8, 10)))
            plt.text(fermi_plot, plt.ylim()[1]*0.5, 'Fermi energy', 
                    fontsize='medium', rotation=90)
            
            # Set axis limits
            plt.xlim(float(self.original_widget.xmin1), float(self.original_widget.xmax1))
            if float(self.original_widget.ymax1) > 0:
                plt.ylim(0, float(self.original_widget.ymax1))
            
            plt.legend(frameon=False, loc=self.original_widget.legend_position, ncol=2)
            plt.tight_layout()
            plt.show()
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred:\n{str(e)}")
    
    def _enhanced_plot_efermi(self):
        """Enhanced plot DOS vs E-Efermi"""
        if not self.original_widget.file_paths:
            QMessageBox.critical(self, "Error", "No files selected!")
            return
        
        try:
            plt.figure(figsize=(12, 6))
            colors = self.original_widget._get_colors(len(self.original_widget.file_paths) * 3)
            
            color_idx = 0
            for file_path in self.original_widget.file_paths:
                energy, orbitals = self._get_plot_data(file_path)
                
                # Get Fermi energy in correct units
                fermi = self.original_widget.fermi_E
                energy_unit = self.energy_units.currentText().lower()
                if energy_unit != 'ev':
                    if energy_unit == 'ha':
                        fermi_plot = fermi / self.ha2ev
                    elif energy_unit == 'ry':
                        fermi_plot = fermi / self.ry2ev
                else:
                    fermi_plot = fermi
                
                e_efermi = energy - fermi_plot
                
                # Plot each orbital
                for orbital_name, orbital_data in orbitals:
                    label = self.original_widget._get_legend_label(file_path)
                    if len(orbitals) > 1:
                        label = f"{label} - {orbital_name}"
                    
                    plt.plot(orbital_data, e_efermi, linewidth=0.75,
                            color=colors[color_idx % len(colors)], label=label)
                    color_idx += 1
            
            plt.xlabel(self.original_widget.xaxis_label)
            plt.ylabel(r'$E-E_{Fermi}$ (eV)')
            plt.title(self.original_widget.plot_title)
            
            # Set axis limits
            plt.xlim(0, float(self.original_widget.xmax2))
            plt.ylim(float(self.original_widget.ymin2), float(self.original_widget.ymax2))
            
            plt.legend(frameon=False, loc=self.original_widget.legend_position)
            plt.tight_layout()
            plt.show()
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred:\n{str(e)}")