"""
Author: Acxel Orozco
Date: [20/09/2025]
Last modification: [20/09/2025]
State: Developing

1. Tab Interface:
Files: Input/output files selection

Analysis: Analysis parameters (threshold vacuum, Fermi energy)

Graph: Full graph customization

Results: Results display and preview

2. Advanced Functionalities:
Automatic Fermi energy extraction from SCF files.

Intelligent Vacuum Region Detection

Real-time preview of graphs.

Full appearance customization

Robust error handling

Quantum Analysis Helper (QAH)

QAH is a python software for plot and analyze Quantum Espresso DOS, 
PDOS and Bands structures with a friendly GUI and extensive plugins.

This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

QAH is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from pathlib import Path

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QLineEdit, QPushButton, QComboBox, QDoubleSpinBox, QSpinBox,
    QTabWidget, QFileDialog, QMessageBox, QGroupBox, QSizePolicy,
    QTreeWidget, QTreeWidgetItem, QHeaderView, QAbstractItemView,
    QCheckBox, QScrollArea, QTextEdit
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont

class PotentialAnalyzerWidget(QWidget):
    def __init__(self, parent=None, initial_dir=None):
        super().__init__(parent)
        self.initial_dir = initial_dir
        
        # Initialize components
        self._setup_variables()
        self._create_widgets()
        self._setup_layout()
        self._connect_signals()
        
        self.potential_data = None
        self.fermi_energy = None

    def _setup_variables(self):
        """Initialize all variables"""
        self.potential_file = ""
        self.scf_file = ""
        self.output_file = "potential_results.txt"
        self.plot_file = "potential_plot.png"
        
        # Analysis parameters
        self.vacuum_threshold = 25.0
        self.fermi_energy_custom = None
        
        # Plot parameters
        self.plot_title = "Electrostatic Potential"
        self.fig_width = 10
        self.fig_height = 6
        self.fig_dpi = 300
        self.line_color = "blue"
        self.line_width = 2.0

    def _create_widgets(self):
        """Create all widget components"""
        # Font configuration
        self.myfont = QFont("Times", 10)
        
        # Create tab widget
        self.tab_widget = QTabWidget()
        
        # Main tab
        self.main_tab = QWidget()
        self._create_main_tab()
        
        # Analysis tab
        self.analysis_tab = QWidget()
        self._create_analysis_tab()
        
        # Plot tab
        self.plot_tab = QWidget()
        self._create_plot_tab()
        
        # Results tab
        self.results_tab = QWidget()
        self._create_results_tab()
        
        # Add tabs to tab widget
        self.tab_widget.addTab(self.main_tab, "Files")
        self.tab_widget.addTab(self.analysis_tab, "Analysis")
        self.tab_widget.addTab(self.plot_tab, "Graph")
        self.tab_widget.addTab(self.results_tab, "Results")
        
        # Action buttons
        self._create_action_buttons()

    def _create_main_tab(self):
        """Create widgets for main tab"""
        layout = QVBoxLayout(self.main_tab)
        
        # Potential file section
        layout.addWidget(QLabel("Potential File:"))
        
        potential_layout = QHBoxLayout()
        self.potential_file_entry = QLineEdit()
        self.potential_file_entry.setFont(self.myfont)
        potential_layout.addWidget(self.potential_file_entry)
        
        self.browse_potential_button = QPushButton("Browse")
        self.browse_potential_button.setFixedWidth(80)
        potential_layout.addWidget(self.browse_potential_button)
        
        layout.addLayout(potential_layout)
        
        # SCF file section
        layout.addWidget(QLabel("SCF File (optional):"))
        
        scf_layout = QHBoxLayout()
        self.scf_file_entry = QLineEdit()
        self.scf_file_entry.setFont(self.myfont)
        scf_layout.addWidget(self.scf_file_entry)
        
        self.browse_scf_button = QPushButton("Browse")
        self.browse_scf_button.setFixedWidth(80)
        scf_layout.addWidget(self.browse_scf_button)
        
        layout.addLayout(scf_layout)
        
        # Output file section
        layout.addWidget(QLabel("Results File:"))
        self.output_file_entry = QLineEdit(self.output_file)
        self.output_file_entry.setFont(self.myfont)
        layout.addWidget(self.output_file_entry)
        
        layout.addStretch()

    def _create_analysis_tab(self):
        """Create widgets for analysis tab"""
        layout = QVBoxLayout(self.analysis_tab)
        
        # Vacuum threshold
        layout.addWidget(QLabel("Vacuum Threshold (Å):"))
        self.vacuum_threshold_spinbox = QDoubleSpinBox()
        self.vacuum_threshold_spinbox.setRange(0, 100)
        self.vacuum_threshold_spinbox.setSingleStep(1.0)
        self.vacuum_threshold_spinbox.setValue(self.vacuum_threshold)
        layout.addWidget(self.vacuum_threshold_spinbox)
        
        # Fermi energy options
        layout.addWidget(QLabel("Fermi Energy:"))
        
        fermi_layout = QHBoxLayout()
        fermi_layout.addWidget(QLabel("Custom Value (eV):"))
        self.fermi_energy_spinbox = QDoubleSpinBox()
        self.fermi_energy_spinbox.setRange(-100, 100)
        self.fermi_energy_spinbox.setSingleStep(0.1)
        fermi_layout.addWidget(self.fermi_energy_spinbox)
        
        layout.addLayout(fermi_layout)
        
        self.auto_fermi_checkbox = QCheckBox("Extract automatically from SCF file")
        self.auto_fermi_checkbox.setChecked(True)
        layout.addWidget(self.auto_fermi_checkbox)
        
        layout.addStretch()

    def _create_plot_tab(self):
        """Create widgets for plot tab"""
        layout = QVBoxLayout(self.plot_tab)
        
        # Plot title
        layout.addWidget(QLabel("Graph Title:"))
        self.plot_title_edit = QLineEdit(self.plot_title)
        self.plot_title_edit.setFont(self.myfont)
        layout.addWidget(self.plot_title_edit)
        
        # Figure size
        layout.addWidget(QLabel("Graph Size (inches):"))
        
        size_layout = QHBoxLayout()
        size_layout.addWidget(QLabel("Width:"))
        self.fig_width_spinbox = QDoubleSpinBox()
        self.fig_width_spinbox.setRange(4, 20)
        self.fig_width_spinbox.setSingleStep(0.5)
        self.fig_width_spinbox.setValue(self.fig_width)
        size_layout.addWidget(self.fig_width_spinbox)
        
        size_layout.addWidget(QLabel("Height:"))
        self.fig_height_spinbox = QDoubleSpinBox()
        self.fig_height_spinbox.setRange(4, 20)
        self.fig_height_spinbox.setSingleStep(0.5)
        self.fig_height_spinbox.setValue(self.fig_height)
        size_layout.addWidget(self.fig_height_spinbox)
        
        layout.addLayout(size_layout)
        
        # DPI
        layout.addWidget(QLabel("Resolution (DPI):"))
        self.dpi_spinbox = QSpinBox()
        self.dpi_spinbox.setRange(50, 600)
        self.dpi_spinbox.setSingleStep(50)
        self.dpi_spinbox.setValue(self.fig_dpi)
        layout.addWidget(self.dpi_spinbox)
        
        # Line properties
        layout.addWidget(QLabel("Line Properties:"))
        
        line_layout = QHBoxLayout()
        line_layout.addWidget(QLabel("Color:"))
        self.line_color_combo = QComboBox()
        self.line_color_combo.addItems(["blue", "red", "green", "black", "purple", "orange", "cyan", "magenta"])
        self.line_color_combo.setCurrentText(self.line_color)
        line_layout.addWidget(self.line_color_combo)
        
        line_layout.addWidget(QLabel("Width:"))
        self.line_width_spinbox = QDoubleSpinBox()
        self.line_width_spinbox.setRange(0.5, 5.0)
        self.line_width_spinbox.setSingleStep(0.1)
        self.line_width_spinbox.setValue(self.line_width)
        line_layout.addWidget(self.line_width_spinbox)
        
        layout.addLayout(line_layout)
        
        # Plot filename
        layout.addWidget(QLabel("Graph File:"))
        self.plot_file_edit = QLineEdit(self.plot_file)
        self.plot_file_edit.setFont(self.myfont)
        layout.addWidget(self.plot_file_edit)
        
        layout.addStretch()

    def _create_results_tab(self):
        """Create widgets for results tab"""
        layout = QVBoxLayout(self.results_tab)
        
        # Results text area
        layout.addWidget(QLabel("Analysis Results:"))
        self.results_text = QTextEdit()
        self.results_text.setReadOnly(True)
        self.results_text.setFont(QFont("Courier", 9))
        layout.addWidget(self.results_text)
        
        # Matplotlib canvas for preview
        layout.addWidget(QLabel("Graph Preview:"))
        self.figure = Figure(figsize=(6, 4))
        self.canvas = FigureCanvas(self.figure)
        self.canvas.setMinimumSize(400, 300)
        layout.addWidget(self.canvas)

    def _create_action_buttons(self):
        """Create action buttons"""
        self.action_layout = QHBoxLayout()
        
        self.analyze_button = QPushButton("Analyze Potential")
        self.action_layout.addWidget(self.analyze_button)
        
        self.save_button = QPushButton("Save Results")
        self.action_layout.addWidget(self.save_button)
        
        self.plot_button = QPushButton("Generate Graph")
        self.action_layout.addWidget(self.plot_button)
        
        # New button to open graph in external window
        self.open_graph_button = QPushButton("Open Graph in Window")
        self.action_layout.addWidget(self.open_graph_button)
        
        self.close_button = QPushButton("Close")
        # self.action_layout.addWidget(self.close_button)

    def _setup_layout(self):
        """Arrange widgets in the frame"""
        main_layout = QVBoxLayout(self)
        main_layout.addWidget(self.tab_widget)
        main_layout.addLayout(self.action_layout)

    def _connect_signals(self):
        """Connect signals to slots"""
        # File operations
        self.browse_potential_button.clicked.connect(self._browse_potential_file)
        self.browse_scf_button.clicked.connect(self._browse_scf_file)
        
        # Analysis operations
        self.analyze_button.clicked.connect(self._analyze_potential)
        self.save_button.clicked.connect(self._save_results)
        self.plot_button.clicked.connect(self._generate_plot)
        self.open_graph_button.clicked.connect(self._open_graph_external)
        self.close_button.clicked.connect(self.hide)
        
        # Value updates
        self.vacuum_threshold_spinbox.valueChanged.connect(self._update_vacuum_threshold)
        self.fermi_energy_spinbox.valueChanged.connect(self._update_fermi_energy)
        self.plot_title_edit.textChanged.connect(self._update_plot_title)
        self.fig_width_spinbox.valueChanged.connect(self._update_fig_width)
        self.fig_height_spinbox.valueChanged.connect(self._update_fig_height)
        self.dpi_spinbox.valueChanged.connect(self._update_fig_dpi)
        self.line_color_combo.currentTextChanged.connect(self._update_line_color)
        self.line_width_spinbox.valueChanged.connect(self._update_line_width)

    def _update_vacuum_threshold(self, value):
        self.vacuum_threshold = value

    def _update_fermi_energy(self, value):
        self.fermi_energy_custom = value

    def _update_plot_title(self, text):
        self.plot_title = text

    def _update_fig_width(self, value):
        self.fig_width = value

    def _update_fig_height(self, value):
        self.fig_height = value

    def _update_fig_dpi(self, value):
        self.fig_dpi = value

    def _update_line_color(self, text):
        self.line_color = text

    def _update_line_width(self, value):
        self.line_width = value

    def _browse_potential_file(self):
        """Browse for potential file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Potential File",
            self.initial_dir if self.initial_dir else str(Path.home()),
            "DAT files (*.dat);;Text files (*.txt);;All files (*.*)"
        )
        if file_path:
            self.potential_file_entry.setText(file_path)

    def _browse_scf_file(self):
        """Browse for SCF file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select SCF File",
            self.initial_dir if self.initial_dir else str(Path.home()),
            "OUT files (*.out);;Text files (*.txt);;All files (*.*)"
        )
        if file_path:
            self.scf_file_entry.setText(file_path)

    def _extract_fermi_energy(self, scf_file):
        """Extract Fermi energy from SCF output file"""
        try:
            with open(scf_file, 'r') as f:
                for line in f:
                    if "the Fermi energy is" in line:
                        parts = line.split()
                        return float(parts[4])
            
            # Try alternative patterns
            with open(scf_file, 'r') as f:
                content = f.read()
                import re
                patterns = [
                    r"Fermi energy\s*[:=]\s*([\d\.\-]+)",
                    r"E_Fermi\s*[:=]\s*([\d\.\-]+)",
                    r"fermi energy\s*[:=]\s*([\d\.\-]+)"
                ]
                
                for pattern in patterns:
                    match = re.search(pattern, content, re.IGNORECASE)
                    if match:
                        return float(match.group(1))
                        
            return None
            
        except Exception as e:
            QMessageBox.warning(self, "Warning", f"Could not extract Fermi energy: {str(e)}")
            return None

    def _analyze_potential(self):
        """Analyze potential data"""
        potential_file = self.potential_file_entry.text()
        if not potential_file:
            QMessageBox.warning(self, "Required Input", "Please select a potential file")
            return
            
        try:
            # Load potential data
            self.potential_data = np.loadtxt(potential_file)
            z = self.potential_data[:, 0]
            v = self.potential_data[:, 1] * 13.605693

            # Find vacuum region
            vacuum_mask = z > self.vacuum_threshold
            if not np.any(vacuum_mask):
                QMessageBox.warning(self, "Analysis Failed", 
                                  f"No vacuum region found (z > {self.vacuum_threshold} Å)")
                return

            # Calculate vacuum properties
            v_vacuum = v[vacuum_mask]
            # v_vacuum_avg = np.mean(v_vacuum)
            # Or, if you want to be fancy and average the top 5% of values:
            v_vacuum_avg = np.mean(np.sort(v)[-int(len(v)*0.05):])
            # v_vacuum_std = np.std(v_vacuum)
            v_vacuum_std = np.std(v[v > (v_vacuum_avg - 0.01)]) # STD of just the top plateau

            # Get Fermi energy
            if self.auto_fermi_checkbox.isChecked() and self.scf_file_entry.text():
                self.fermi_energy = self._extract_fermi_energy(self.scf_file_entry.text())
            else:
                self.fermi_energy = self.fermi_energy_spinbox.value()

            if self.fermi_energy is None:
                QMessageBox.warning(self, "Fermi Energy", 
                                  "Could not obtain Fermi energy. Please use a custom value.")
                return

            # Calculate work function
            work_function = v_vacuum_avg - self.fermi_energy

            # Display results
            results_text = f"""POTENTIAL ANALYSIS RESULTS
==========================================
Analyzed file: {Path(potential_file).name}
Vacuum threshold: {self.vacuum_threshold} Å

FERMI ENERGY: {self.fermi_energy:.6f} eV

VACUUM POTENTIAL:
  Average value: {v_vacuum_avg:.6f} eV
  Standard deviation: {v_vacuum_std:.6f} eV
  Region: z = {z[vacuum_mask][0]:.1f} to {z[vacuum_mask][-1]:.1f} Å

WORK FUNCTION: {work_function:.6f} eV

=========================================="""
            
            self.results_text.setPlainText(results_text)
            self.tab_widget.setCurrentWidget(self.results_tab)
            
            # Update preview plot
            self._update_preview_plot(z, v, v_vacuum_avg)
            
            QMessageBox.information(self, "Analysis Completed", 
                                  "Potential analysis completed successfully")
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error in analysis:\n{str(e)}")

    def _update_preview_plot(self, z, v, v_vacuum_avg):
        """Update the preview plot"""
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        
        ax.plot(z, v, color=self.line_color, linewidth=self.line_width, 
               label='Electrostatic potential')
        
        if self.fermi_energy is not None:
            ax.axhline(y=self.fermi_energy, color='green', linestyle='--',
                      label=f'Fermi: {self.fermi_energy:.3f} eV')
        
        ax.axhline(y=v_vacuum_avg, color='red', linestyle='--',
                  label=f'Vacuum: {v_vacuum_avg:.3f} eV')
        
        ax.set_xlabel('Z coordinate (Å)')
        ax.set_ylabel('Electrostatic potential (eV)')
        ax.set_title('Preview - Potential along')
        ax.grid(True, alpha=0.3)
        ax.legend()
        
        self.canvas.draw()

    def _create_plot_figure(self, z, v, v_vacuum_avg):
        """Create and return a matplotlib figure with the plot"""
        fig, ax = plt.subplots(figsize=(self.fig_width, self.fig_height))
        
        ax.plot(z, v, color=self.line_color, linewidth=self.line_width,
                label='Electrostatic potential')
        
        if self.fermi_energy is not None:
            ax.axhline(y=self.fermi_energy, color='green', linestyle='--',
                       label=f'Fermi level: {self.fermi_energy:.3f} eV')
        
        ax.axhline(y=v_vacuum_avg, color='red', linestyle='--',
                   label=f'Vacuum level: {v_vacuum_avg:.3f} eV')
        
        ax.set_xlabel('Z coordinate (Å)')
        ax.set_ylabel('Electrostatic potential (eV)')
        ax.set_title(self.plot_title)
        ax.grid(True, alpha=0.3)
        ax.legend()
        plt.tight_layout()
        
        return fig

    def _generate_plot(self):
        """Generate and save the final plot"""
        if self.potential_data is None:
            QMessageBox.warning(self, "Data Required", "You must first analyze the data")
            return
            
        try:
            z = self.potential_data[:, 0]
            v = self.potential_data[:, 1]
            
            # Find vacuum region
            vacuum_mask = z > self.vacuum_threshold
            v_vacuum = v[vacuum_mask]
            v_vacuum_avg = np.mean(v_vacuum)
            
            # Create and save figure
            fig = self._create_plot_figure(z, v, v_vacuum_avg)
            
            # Save plot
            plot_file = self.plot_file_edit.text()
            fig.savefig(plot_file, dpi=self.fig_dpi, bbox_inches='tight')
            plt.close(fig)
            
            QMessageBox.information(self, "Graph Saved", 
                                  f"Graph saved to:\n{plot_file}")
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error generating graph:\n{str(e)}")

    def _open_graph_external(self):
        """Open the graph in an external matplotlib window"""
        if self.potential_data is None:
            QMessageBox.warning(self, "Data Required", "You must first analyze the data")
            return
            
        try:
            z = self.potential_data[:, 0]
            v = self.potential_data[:, 1]
            
            # Find vacuum region
            vacuum_mask = z > self.vacuum_threshold
            v_vacuum = v[vacuum_mask]
            v_vacuum_avg = np.mean(v_vacuum)
            
            # Create and show figure in external window
            fig = self._create_plot_figure(z, v, v_vacuum_avg)
            
            # Set window title
            fig.canvas.manager.set_window_title(f"Potential Analysis - {self.plot_title}")
            
            # Show the figure
            plt.show()
            
            QMessageBox.information(self, "Graph Opened", 
                                  "Graph opened in external window. Close the window when done.")
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error opening graph:\n{str(e)}")

    def _save_results(self):
        """Save results to file"""
        if not self.results_text.toPlainText():
            QMessageBox.warning(self, "No Results", "No results to save")
            return
            
        try:
            output_file = self.output_file_entry.text()
            with open(output_file, 'w') as f:
                f.write(self.results_text.toPlainText())
            
            QMessageBox.information(self, "Results Saved", 
                                  f"Results saved to:\n{output_file}")
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error saving results:\n{str(e)}")


# if __name__ == "__main__":
#     from PySide6.QtWidgets import QApplication, QMainWindow
#     import sys
    
#     app = QApplication(sys.argv)
#     window = QMainWindow()
#     window.setWindowTitle("Quantum Analyzer Helper - Potential Analyzer")
#     window.resize(800, 600)
    
#     central_widget = PotentialAnalyzerWidget()
#     window.setCentralWidget(central_widget)
#     window.show()
    
#     sys.exit(app.exec())