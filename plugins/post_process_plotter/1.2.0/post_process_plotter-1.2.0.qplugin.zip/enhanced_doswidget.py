"""
Enhanced DOS Widget with CP2K support
Using composition pattern to avoid multiple inheritance issues
This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

QAH is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

import numpy as np
from pathlib import Path
import matplotlib.pyplot as plt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
    QComboBox, QGroupBox, QFileDialog, QMessageBox
)
from PySide6.QtCore import Qt

from .file_detector import FileFormatDetector
from .cp2k_dos_parser import parse_cp2k_dos
from .qe_parsers import parse_qe_dos
from .dosplotterwidget import DOSPlotterWidget


class EnhancedDOSWidget(QWidget):
    """Enhanced DOS widget using composition - supports both QE and CP2K"""
    
    def __init__(self, parent=None, initial_dir=None):
        super().__init__(parent)
        
        # Store parameters
        self.initial_dir = initial_dir
        self.current_format = None
        self.current_file = None
        self.data = None
        
        # Create the original DOS widget as a child
        self.original_widget = DOSPlotterWidget(self, initial_dir)
        
        # Create our enhanced UI
        self._setup_ui()
        
        # Connect signals
        self._connect_signals()
        
        # Store original data for unit conversion
        self.original_energy = None
        self.original_dos = None
        
        # Conversion factors
        self.ha2ev = 27.21138602
        self.ry2ev = 13.605693
    
    def _setup_ui(self):
        """Setup the enhanced UI"""
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Create control panel for CP2K features
        control_panel = QWidget()
        control_layout = QHBoxLayout(control_panel)
        control_layout.setContentsMargins(5, 5, 5, 5)
        
        # Format indicator
        control_layout.addWidget(QLabel("Format:"))
        self.format_label = QLabel("Unknown")
        self.format_label.setStyleSheet("font-weight: bold; color: #2c3e50; padding-right: 10px;")
        control_layout.addWidget(self.format_label)
        
        # Unit conversion
        control_layout.addWidget(QLabel("Energy Units:"))
        self.energy_units = QComboBox()
        self.energy_units.addItems(["eV", "Ha", "Ry"])
        self.energy_units.setCurrentText("eV")
        self.energy_units.setFixedWidth(60)
        control_layout.addWidget(self.energy_units)
        
        control_layout.addStretch()
        
        # Add control panel to main layout
        main_layout.addWidget(control_panel)
        
        # Add the original widget
        main_layout.addWidget(self.original_widget)
    
    def _connect_signals(self):
        """Connect signals"""
        # Connect unit changes
        self.energy_units.currentTextChanged.connect(self._on_units_changed)
        
        # Override the original widget's browse button
        try:
            self.original_widget.browse_button.clicked.disconnect()
        except:
            pass
        self.original_widget.browse_button.clicked.connect(self._enhanced_browse_file)
        
        # Connect to the original widget's plot buttons to intercept
        try:
            self.original_widget.regular_dos_button.clicked.disconnect()
            self.original_widget.shifted_dos_button.clicked.disconnect()
        except:
            pass
        
        self.original_widget.regular_dos_button.clicked.connect(lambda: self._enhanced_plot(shifted=False))
        self.original_widget.shifted_dos_button.clicked.connect(lambda: self._enhanced_plot(shifted=True))
    
    def _enhanced_browse_file(self):
        """Enhanced file browser with format detection"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select DOS File",
            self.initial_dir if self.initial_dir else str(Path.home()),
            "Supported files (*.dos *.dat *.txt);;CP2K DOS (*.dos);;DAT files (*.dat);;All files (*.*)"
        )
        if file_path:
            self.current_file = file_path
            self.original_widget.file_entry.setText(file_path)
            self.original_widget.file_path = file_path
            
            # Detect format
            self._detect_format(file_path)
            
            # Load data
            self._load_dos_data(file_path)
    
    def _detect_format(self, file_path):
        """Detect file format"""
        fmt, _ = FileFormatDetector.detect_format(file_path)
        self.current_format = fmt
        
        # Update format label
        format_names = {
            'cp2k_dos': 'CP2K DOS',
            'qe_dos': 'QE DOS',
        }
        self.format_label.setText(format_names.get(fmt, 'Unknown'))
    
    def _load_dos_data(self, file_path):
        """Load DOS data with format detection"""
        try:
            if self.current_format == 'cp2k_dos':
                # Parse CP2K format
                self.data = parse_cp2k_dos(file_path)
                
                # Store original data
                self.original_energy = self.data['energy'].copy()
                self.original_dos = self.data['dos'].copy()
                
                # Set data in original widget
                self.original_widget.energy = self.original_energy
                self.original_widget.dos = self.original_dos
                
                # Update Fermi energy
                if self.data.get('fermi_energy'):
                    self.original_widget.fermi_spinbox.setValue(self.data['fermi_energy'])
                    self.original_widget.fermi_E = self.data['fermi_energy']
                
                QMessageBox.information(self, "Success", 
                    f"Loaded CP2K DOS file with {self.data['n_points']} points")
                
            elif self.current_format == 'qe_dos':
                # Parse QE format
                self.data = parse_qe_dos(file_path)
                
                self.original_energy = self.data['energy'].copy()
                self.original_dos = self.data['dos'].copy()
                
                self.original_widget.energy = self.original_energy
                self.original_widget.dos = self.original_dos
                
                if 'fermi_energy' in self.data:
                    self.original_widget.fermi_spinbox.setValue(self.data['fermi_energy'])
                    self.original_widget.fermi_E = self.data['fermi_energy']
                
                QMessageBox.information(self, "Success", "Loaded QE DOS file")
            
            # Enable plot buttons
            self.original_widget.regular_dos_button.setEnabled(True)
            self.original_widget.shifted_dos_button.setEnabled(True)
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load file: {str(e)}")
    
    def _on_units_changed(self):
        """Handle unit conversion changes"""
        if self.original_energy is None:
            return
        
        energy_unit = self.energy_units.currentText().lower()
        
        if energy_unit == 'ev':
            self.original_widget.energy = self.original_energy
        elif energy_unit == 'ha':
            self.original_widget.energy = self.original_energy / self.ha2ev
        elif energy_unit == 'ry':
            self.original_widget.energy = self.original_energy / self.ry2ev
    
    def _enhanced_plot(self, shifted=False):
        """Enhanced plotting with unit awareness"""
        if self.original_energy is None:
            QMessageBox.warning(self, "No Data", "Please load a DOS file first")
            return
        
        try:
            # Get current units
            energy_unit = self.energy_units.currentText()
            
            # Convert Fermi energy if needed
            fermi = self.original_widget.fermi_E
            if energy_unit.lower() != 'ev':
                if energy_unit.lower() == 'ha':
                    fermi_plot = fermi / self.ha2ev
                elif energy_unit.lower() == 'ry':
                    fermi_plot = fermi / self.ry2ev
            else:
                fermi_plot = fermi
            
            plt.figure(figsize=(12, 6))
            
            if shifted:
                energy_shifted = self.original_widget.energy - fermi_plot
                plt.plot(energy_shifted, self.original_widget.dos, 
                        linewidth=self.original_widget.line_width, 
                        color=self.original_widget.line_color)
                plt.xlabel(f'Energy - E_F ({energy_unit})')
                plt.xlim(self.original_widget.xmin - fermi_plot, 
                        self.original_widget.xmax - fermi_plot)
                plt.title("Density of States (Shifted by Fermi Energy)")
            else:
                plt.plot(self.original_widget.energy, self.original_widget.dos, 
                        linewidth=self.original_widget.line_width, 
                        color=self.original_widget.line_color)
                plt.axvline(x=fermi_plot, linewidth=0.5, color='k', linestyle='--')
                plt.text(fermi_plot, 4, 'Fermi energy', fontsize='medium', rotation=90)
                plt.fill_between(self.original_widget.energy, 0, self.original_widget.dos, 
                               where=(self.original_widget.energy < fermi_plot),
                               facecolor=self.original_widget.fill_color, 
                               alpha=self.original_widget.fill_alpha)
                plt.xlabel(f'Energy ({energy_unit})')
                plt.xlim(self.original_widget.xmin, self.original_widget.xmax)
                plt.title("Density of States")
            
            plt.yticks([])
            plt.ylabel('DOS')
            
            # Set Y limits if specified
            if self.original_widget.ymax > 0:
                plt.ylim(self.original_widget.ymin, self.original_widget.ymax)
            
            plt.tight_layout()
            plt.show()
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to plot data:\n{str(e)}")