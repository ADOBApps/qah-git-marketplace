"""
File Format Detector for Quantum ESPRESSO and CP2K output files
This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

QAH is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

import re
from pathlib import Path
from typing import Optional, Tuple, Dict

class FileFormatDetector:
    """Auto-detect if file is from QE or CP2K"""
    
    # Format signatures
    QE_BANDS_SIGNATURES = [
        (r'#\s+k\b', 'QE bands (gnu format)'),
        (r'#\s+k\s+[0-9]+', 'QE bands (gnu format)'),
        (r'&plot', 'QE bands (plot)'),
        (r'begin\s+plot', 'QE bands')
    ]
    
    CP2K_BANDS_SIGNATURES = [
        (r'# Set \d+: \d+ special points, \d+ k-points, \d+ bands', 'CP2K bands'),
        (r'#  Special point \d+\s+[\d\.\-]+\s+[\d\.\-]+\s+[\d\.\-]+\s+\w+', 'CP2K bands'),
        (r'#  Point \d+\s+Spin \d+:', 'CP2K bands')
    ]
    
    QE_DOS_SIGNATURES = [
        (r'#\s*e\s*\(\s*ev\s*\)\s+dos', 'QE DOS'),
        (r'#\s*e\s*\(\s*ry\s*\)\s+dos', 'QE DOS'),
        (r'#\s+energy\s+dos', 'QE DOS')
    ]
    
    CP2K_DOS_SIGNATURES = [
        (r'# DOS at iteration step i = \d+, E_Fermi\[a\.u\.\] =', 'CP2K DOS'),
        (r'#\s+Energy\[a\.u\.\]\s+Density\s+Occupation', 'CP2K DOS')
    ]
    
    QE_PDOS_SIGNATURES = [
        (r'#\s*e\s*\(\s*(ev|ry)\s*\)\s+ldos', 'QE PDOS'),
        (r'#\s+energy\s+ldos', 'QE PDOS')
    ]
    
    CP2K_PDOS_SIGNATURES = [
        (r'# Projected DOS for atomic kind \w+ at iteration step i = \d+, E\(Fermi\) =', 'CP2K PDOS'),
        (r'#\s+MO\s+Eigenvalue\s+\[a\.u\.\]\s+Occupation\s+s\s+py\s+pz\s+px', 'CP2K PDOS')
    ]
    
    CUBE_SIGNATURES = [
        (r'^\s*[\d\.\-]+\s+[\d\.\-]+\s+[\d\.\-]+\s+[\d\.\-]+\s*$', 'Cube header'),
        (r'^\s*\d+\s+[\d\.\-]+\s+[\d\.\-]+\s+[\d\.\-]+\s*$', 'Cube grid')
    ]
    
    # Conversion factors
    HA2EV = 27.21138602
    BOHR2ANG = 0.529177210903
    
    @classmethod
    def detect_format(cls, file_path: str) -> Tuple[str, Dict]:
        """
        Detect file format and return format type and metadata
        
        Returns:
            Tuple of (format_type, metadata)
            format_type: 'vasp_field', 'vasp_text', 'qe_bands', 'cp2k_bands',
                        'qe_dos', 'cp2k_dos', 'qe_pdos', 'cp2k_pdos', 'cube',
                        'unknown'
        """
        if not Path(file_path).exists():
            return 'unknown', {}

        # VASP volumetric files and text outputs are recognised by name: their
        # first lines look like a POSCAR, so content signatures are ambiguous.
        name = Path(file_path).name.upper()
        vasp_fields = {
            'CHGCAR': ('chgcar', 'charge density'),
            'LOCPOT': ('locpot', 'local potential'),
            'PARCHG': ('parchg', 'band-decomposed charge'),
            'ELFCAR': ('elfcar', 'electron localisation function'),
        }
        for prefix, (kind, description) in vasp_fields.items():
            if name.startswith(prefix):
                return 'vasp_field', {
                    'format': 'volume', 'source': 'vasp',
                    'kind': kind, 'description': description,
                }
        for prefix in ('OUTCAR', 'POSCAR', 'CONTCAR', 'DOSCAR', 'EIGENVAL'):
            if name.startswith(prefix):
                return 'vasp_text', {
                    'format': 'text', 'source': 'vasp',
                    'kind': prefix.lower(),
                }

        # Check by extension first
        ext = Path(file_path).suffix.lower()
        if ext == '.cube':
            return 'cube', {'format': 'cube', 'source': 'cp2k'}
        
        # Read first few lines for content analysis
        try:
            with open(file_path, 'r') as f:
                first_lines = [f.readline() for _ in range(20)]
                content = '\n'.join(first_lines)
        except:
            return 'unknown', {}
        
        metadata = {'format': 'unknown', 'source': 'unknown'}
        
        # Check for CP2K bands
        for pattern, desc in cls.CP2K_BANDS_SIGNATURES:
            if re.search(pattern, content, re.IGNORECASE):
                metadata = cls._extract_cp2k_bands_metadata(first_lines)
                metadata.update({'format': 'bands', 'source': 'cp2k'})
                return 'cp2k_bands', metadata
        
        # Check for CP2K DOS
        for pattern, desc in cls.CP2K_DOS_SIGNATURES:
            if re.search(pattern, content, re.IGNORECASE):
                metadata = cls._extract_cp2k_dos_metadata(first_lines)
                metadata.update({'format': 'dos', 'source': 'cp2k'})
                return 'cp2k_dos', metadata
        
        # Check for CP2K PDOS
        for pattern, desc in cls.CP2K_PDOS_SIGNATURES:
            if re.search(pattern, content, re.IGNORECASE):
                metadata = cls._extract_cp2k_pdos_metadata(first_lines)
                metadata.update({'format': 'pdos', 'source': 'cp2k'})
                return 'cp2k_pdos', metadata
        
        # Check for QE bands
        for pattern, desc in cls.QE_BANDS_SIGNATURES:
            if re.search(pattern, content, re.IGNORECASE):
                return 'qe_bands', {'format': 'bands', 'source': 'qe'}
        
        # Check for QE DOS
        for pattern, desc in cls.QE_DOS_SIGNATURES:
            if re.search(pattern, content, re.IGNORECASE):
                return 'qe_dos', {'format': 'dos', 'source': 'qe'}
        
        # Check for QE PDOS
        for pattern, desc in cls.QE_PDOS_SIGNATURES:
            if re.search(pattern, content, re.IGNORECASE):
                return 'qe_pdos', {'format': 'pdos', 'source': 'qe'}
        
        return 'unknown', metadata
    
    @classmethod
    def _extract_cp2k_bands_metadata(cls, lines):
        """Extract metadata from CP2K bands file header"""
        metadata = {}
        for line in lines[:5]:
            # Extract number of sets, k-points, bands
            match = re.search(r'# Set \d+: (\d+) special points, (\d+) k-points, (\d+) bands', line)
            if match:
                metadata['n_special'] = int(match.group(1))
                metadata['n_kpoints'] = int(match.group(2))
                metadata['n_bands'] = int(match.group(3))
            
            # Extract special points
            match = re.search(r'#  Special point \d+\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+(\w+)', line)
            if match:
                if 'special_points' not in metadata:
                    metadata['special_points'] = []
                metadata['special_points'].append({
                    'x': float(match.group(1)),
                    'y': float(match.group(2)),
                    'z': float(match.group(3)),
                    'label': match.group(4)
                })
        return metadata
    
    @classmethod
    def _extract_cp2k_dos_metadata(cls, lines):
        """Extract metadata from CP2K DOS file header"""
        metadata = {}
        for line in lines[:3]:
            # Extract Fermi energy
            match = re.search(r'E_Fermi\[a\.u\.\] =\s*([\d\.\-]+)', line)
            if match:
                fermi_au = float(match.group(1))
                metadata['fermi_energy_au'] = fermi_au
                metadata['fermi_energy_ev'] = fermi_au * cls.HA2EV
        return metadata
    
    @classmethod
    def _extract_cp2k_pdos_metadata(cls, lines):
        """Extract metadata from CP2K PDOS file header"""
        metadata = {}
        for line in lines[:3]:
            # Extract atomic kind and Fermi energy
            match = re.search(r'atomic kind (\w+).*E\(Fermi\) =\s*([\d\.\-]+)', line)
            if match:
                metadata['atomic_kind'] = match.group(1)
                fermi_au = float(match.group(2))
                metadata['fermi_energy_au'] = fermi_au
                metadata['fermi_energy_ev'] = fermi_au * cls.HA2EV
        return metadata


def detect_file_format(file_path: str) -> str:
    """Convenience function to detect file format"""
    fmt, _ = FileFormatDetector.detect_format(file_path)
    return fmt