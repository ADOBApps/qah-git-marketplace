"""
Enhanced Band Structure Widget with CP2K support
Using composition pattern to avoid multiple inheritance issues
This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

QAH is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

import numpy as np
from pathlib import Path
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
    QComboBox, QGroupBox, QFileDialog, QMessageBox
)
from PySide6.QtCore import Qt

from .file_detector import FileFormatDetector
from .cp2k_bands_parser import parse_cp2k_bands
from .qe_parsers import parse_qe_bands
from .bandswidget import BandsWidget


class EnhancedBandsWidget(QWidget):
    """Enhanced band structure widget using composition"""
    
    def __init__(self, parent=None, initial_dir=None):
        super().__init__(parent)
        
        # Store parameters
        self.initial_dir = initial_dir
        self.current_format = None
        self.current_file = None
        self.data = None
        
        # Create the original bands widget as a child
        self.original_widget = BandsWidget(self, initial_dir)
        
        # Create our enhanced UI
        self._setup_ui()
        
        # Connect signals
        self._connect_signals()
        
        # Store original data for unit conversion
        self.original_bands = None
        self.original_kpoints = None
        self.special_points = None
        
        # Conversion factors
        self.ha2ev = 27.21138602
        self.ry2ev = 13.605693
    
    def _setup_ui(self):
        """Setup the enhanced UI"""
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Create control panel for CP2K features
        control_panel = QWidget()
        control_layout = QHBoxLayout(control_panel)
        control_layout.setContentsMargins(5, 5, 5, 5)
        
        # Format indicator
        control_layout.addWidget(QLabel("Format:"))
        self.format_label = QLabel("Unknown")
        self.format_label.setStyleSheet("font-weight: bold; color: #2c3e50; padding-right: 10px;")
        control_layout.addWidget(self.format_label)
        
        # Unit conversion
        control_layout.addWidget(QLabel("Energy:"))
        self.energy_units = QComboBox()
        self.energy_units.addItems(["eV", "Ha", "Ry"])
        self.energy_units.setCurrentText("eV")
        self.energy_units.setFixedWidth(60)
        control_layout.addWidget(self.energy_units)
        
        control_layout.addWidget(QLabel("Length:"))
        self.length_units = QComboBox()
        self.length_units.addItems(["Angstrom", "Bohr"])
        self.length_units.setCurrentText("Angstrom")
        self.length_units.setFixedWidth(80)
        control_layout.addWidget(self.length_units)
        
        control_layout.addStretch()
        
        # Add control panel to main layout
        main_layout.addWidget(control_panel)
        
        # Add the original widget
        main_layout.addWidget(self.original_widget)
    
    def _connect_signals(self):
        """Connect signals"""
        # Connect unit changes
        self.energy_units.currentTextChanged.connect(self._on_units_changed)
        self.length_units.currentTextChanged.connect(self._on_units_changed)
        
        # Override the original widget's browse button
        try:
            self.original_widget.browse_input_button.clicked.disconnect()
        except:
            pass
        self.original_widget.browse_input_button.clicked.connect(self._enhanced_browse_input_file)
        
        # Connect to the original widget's plot buttons to intercept
        try:
            self.original_widget.pure_bands_button.clicked.disconnect()
            self.original_widget.fermi_bands_button.clicked.disconnect()
            self.original_widget.final_bands_button.clicked.disconnect()
        except:
            pass
        
        self.original_widget.pure_bands_button.clicked.connect(lambda: self._enhanced_plot('pure'))
        self.original_widget.fermi_bands_button.clicked.connect(lambda: self._enhanced_plot('fermi'))
        self.original_widget.final_bands_button.clicked.connect(lambda: self._enhanced_plot('final'))
    
    def _enhanced_browse_input_file(self):
        """Enhanced file browser with format detection"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Bands File",
            self.initial_dir if self.initial_dir else "",
            "Supported files (*.bs *.gnu *.out *.dat);;CP2K bands (*.bs);;GNU files (*.gnu);;Bands output (*.out);;All files (*.*)"
        )
        if file_path:
            self.current_file = file_path
            self.original_widget.input_file_entry.setText(file_path)
            
            # Detect format
            self._detect_format(file_path)
            
            # Load data
            self._load_bands_data(file_path)
    
    def _detect_format(self, file_path):
        """Detect file format"""
        fmt, _ = FileFormatDetector.detect_format(file_path)
        self.current_format = fmt
        
        # Update format label
        format_names = {
            'cp2k_bands': 'CP2K Bands',
            'qe_bands': 'QE Bands',
        }
        self.format_label.setText(format_names.get(fmt, 'Unknown'))
    
    def _load_bands_data_old(self, file_path):
        """Load bands data with format detection"""
        try:
            if self.current_format == 'cp2k_bands':
                # Parse CP2K format
                self.data = parse_cp2k_bands(file_path)
                
                # Store original data
                self.original_bands = self.data['bands'].copy()
                self.original_kpoints = self.data['kpoints'].copy()
                
                # Store special points
                if 'special_point_ticks' in self.data:
                    self.special_points = self.data['special_point_ticks']
                
                # Update Fermi energy if available
                if 'fermi_energy' in self.data:
                    self.original_widget.fermi_spinbox.setValue(self.data['fermi_energy'])
                    self.original_widget.fermi_spinbox_adv.setValue(self.data['fermi_energy'])
                
                # Set data in original widget
                self.original_widget.bands_data = self.original_bands
                self.original_widget.kpoints = self.original_kpoints
                
                QMessageBox.information(self, "Success", 
                    f"Loaded CP2K bands file with {self.data['n_bands']} bands and {self.data['n_kpoints']} k-points")
                
            elif self.current_format == 'qe_bands':
                # Parse QE format
                self.data = parse_qe_bands(file_path)
                
                self.original_bands = self.data['bands'].copy()
                self.original_kpoints = self.data.get('kpath', self.data['kpoints'])
                
                if 'special_points' in self.data:
                    self.special_points = self.data['special_points']
                
                # Set data in original widget
                self.original_widget.bands_data = self.original_bands
                self.original_widget.kpoints = self.original_kpoints
                
                QMessageBox.information(self, "Success", "Loaded QE bands file")
            
            # Enable plot buttons
            self.original_widget.pure_bands_button.setEnabled(True)
            self.original_widget.fermi_bands_button.setEnabled(True)
            self.original_widget.final_bands_button.setEnabled(True)
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load file: {str(e)}")
    
    def _load_bands_data(self, file_path):
        """Load bands data with format detection"""
        try:
            if self.current_format == 'cp2k_bands':
                # Parse CP2K format
                self.data = parse_cp2k_bands(file_path)
                
                # Store original data
                self.original_bands = self.data['bands'].copy()
                
                # Get kpoints (cumulative distances)
                if 'kpoints' in self.data:
                    self.original_kpoints = self.data['kpoints'].copy()
                else:
                    # Fallback to index-based kpoints
                    self.original_kpoints = np.arange(self.data['n_kpoints'])
                
                # Store special points
                if 'special_point_ticks' in self.data:
                    self.special_points = self.data['special_point_ticks']
                    # Also store in original widget for tick marks
                    self.original_widget.special_points = self.special_points
                
                # Update Fermi energy if available
                if 'fermi_energy' in self.data:
                    self.original_widget.fermi_spinbox.setValue(self.data['fermi_energy'])
                    self.original_widget.fermi_spinbox_adv.setValue(self.data['fermi_energy'])
                
                # Set data in original widget
                self.original_widget.bands_data = self.original_bands
                self.original_widget.kpoints = self.original_kpoints
                
                # Force update of the data preview if it exists
                if hasattr(self.original_widget, 'data_preview_tab'):
                    self.original_widget.data_preview_tab.update_data(
                        self.original_kpoints, self.original_bands
                    )
                
                QMessageBox.information(self, "Success", 
                    f"Loaded CP2K bands file with {self.data['n_bands']} bands and {self.data['n_kpoints']} k-points")
                
            elif self.current_format == 'qe_bands':
                # Parse QE format
                self.data = parse_qe_bands(file_path)
                
                self.original_bands = self.data['bands'].copy()
                self.original_kpoints = self.data.get('kpath', self.data['kpoints'])
                
                if 'special_points' in self.data:
                    self.special_points = self.data['special_points']
                    self.original_widget.special_points = self.special_points
                
                # Set data in original widget
                self.original_widget.bands_data = self.original_bands
                self.original_widget.kpoints = self.original_kpoints
                
                QMessageBox.information(self, "Success", "Loaded QE bands file")
            
            # Enable plot buttons
            self.original_widget.pure_bands_button.setEnabled(True)
            self.original_widget.fermi_bands_button.setEnabled(True)
            self.original_widget.final_bands_button.setEnabled(True)
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load file: {str(e)}")
            import traceback
            traceback.print_exc()

    def _on_units_changed(self):
        """Handle unit conversion changes"""
        if self.original_bands is None:
            return
        
        # Convert energy units
        energy_unit = self.energy_units.currentText().lower()
        
        if energy_unit == 'ev':
            self.original_widget.bands_data = self.original_bands
        elif energy_unit == 'ha':
            self.original_widget.bands_data = self.original_bands / self.ha2ev
        elif energy_unit == 'ry':
            self.original_widget.bands_data = self.original_bands / self.ry2ev
        
        # Update plot if exists
        if hasattr(self.original_widget, 'ax') and self.original_widget.ax.has_data():
            self._update_plot_labels()
            self.original_widget.canvas.draw()
    
    def _update_plot_labels(self):
        """Update plot labels with current units"""
        if not hasattr(self.original_widget, 'ax'):
            return
        
        energy_unit = self.energy_units.currentText()
        length_unit = self.length_units.currentText()
        
        self.original_widget.ax.set_xlabel(f'Wave Vector ({length_unit}⁻¹)')
        self.original_widget.ax.set_ylabel(f'Energy ({energy_unit})')
        
        # Update special point ticks
        if self.special_points:
            ticks = [sp['position'] for sp in self.special_points]
            labels = [sp['label'] for sp in self.special_points]
            self.original_widget.ax.set_xticks(ticks)
            self.original_widget.ax.set_xticklabels(labels)
    
    def _enhanced_plot_old(self, plot_type):
        """Enhanced plotting with unit awareness"""
        if self.original_bands is None:
            QMessageBox.warning(self, "No Data", "Please load a bands file first")
            return
        
        # Clear the axis
        self.original_widget.ax.clear()
        
        # Get current units
        energy_unit = self.energy_units.currentText().lower()
        fermi = self.original_widget.fermi_spinbox.value()
        
        # Convert Fermi energy if needed
        if energy_unit != 'ev':
            if energy_unit == 'ha':
                fermi_plot = fermi / self.ha2ev
                vb_lower = self.original_widget.vb_lower / self.ha2ev
                vb_upper = self.original_widget.vb_upper / self.ha2ev
                cb_lower = self.original_widget.cb_lower / self.ha2ev
                cb_upper = self.original_widget.cb_upper / self.ha2ev
            elif energy_unit == 'ry':
                fermi_plot = fermi / self.ry2ev
                vb_lower = self.original_widget.vb_lower / self.ry2ev
                vb_upper = self.original_widget.vb_upper / self.ry2ev
                cb_lower = self.original_widget.cb_lower / self.ry2ev
                cb_upper = self.original_widget.cb_upper / self.ry2ev
        else:
            fermi_plot = fermi
            vb_lower = self.original_widget.vb_lower
            vb_upper = self.original_widget.vb_upper
            cb_lower = self.original_widget.cb_lower
            cb_upper = self.original_widget.cb_upper
        
        bands_data = self.original_widget.bands_data
        kpoints = self.original_widget.kpoints
        
        if plot_type == 'pure':
            for i in range(bands_data.shape[0]):
                self.original_widget.ax.plot(kpoints, bands_data[i, :], 
                                            'b-', alpha=0.7, linewidth=1.0)
            self.original_widget.ax.set_title("Pure Band Structure")
            
        elif plot_type == 'fermi':
            for i in range(bands_data.shape[0]):
                self.original_widget.ax.plot(kpoints, bands_data[i, :] - fermi_plot, 
                                            'r-', alpha=0.7, linewidth=1.0)
            self.original_widget.ax.axhline(y=0, color='k', linestyle='--', 
                                           linewidth=1.5, label=f'Fermi Level')
            self.original_widget.ax.set_title("Fermi-Referenced Band Structure")
            self.original_widget.ax.legend()
            
        elif plot_type == 'final':
            for i in range(bands_data.shape[0]):
                self.original_widget.ax.plot(kpoints, bands_data[i, :] - fermi_plot, 
                                            'g-', alpha=0.7, linewidth=1.0)
            
            self.original_widget.ax.axhspan(vb_lower, vb_upper, color='blue', 
                                           alpha=0.2, label='Valence Band')
            self.original_widget.ax.axhspan(cb_lower, cb_upper, color='red', 
                                           alpha=0.2, label='Conduction Band')
            self.original_widget.ax.axhline(y=0, color='k', linestyle='--', 
                                           linewidth=1.5, label=f'Fermi Level')
            self.original_widget.ax.set_title("Band Structure with Highlighted Regions")
            self.original_widget.ax.legend()
        
        # Update labels
        self._update_plot_labels()
        
        # Apply y-axis limits
        self.original_widget.ax.set_ylim(
            self.original_widget.y_min_spinbox.value(), 
            self.original_widget.y_max_spinbox.value()
        )
        self.original_widget.ax.grid(True, alpha=0.3)
        self.original_widget.canvas.draw()
        
        # Switch to plot tab
        self.original_widget.tab_widget.setCurrentIndex(5)

    def _enhanced_plot(self, plot_type):
        """Enhanced plotting with unit awareness"""
        if self.original_bands is None:
            QMessageBox.warning(self, "No Data", "Please load a bands file first")
            return
        
        # Clear the axis
        self.original_widget.ax.clear()
        
        # Get current units
        energy_unit = self.energy_units.currentText().lower()
        fermi = self.original_widget.fermi_spinbox.value()
        
        # Convert Fermi energy if needed
        if energy_unit != 'ev':
            if energy_unit == 'ha':
                fermi_plot = fermi / self.ha2ev
                vb_lower = self.original_widget.vb_lower / self.ha2ev
                vb_upper = self.original_widget.vb_upper / self.ha2ev
                cb_lower = self.original_widget.cb_lower / self.ha2ev
                cb_upper = self.original_widget.cb_upper / self.ha2ev
            elif energy_unit == 'ry':
                fermi_plot = fermi / self.ry2ev
                vb_lower = self.original_widget.vb_lower / self.ry2ev
                vb_upper = self.original_widget.vb_upper / self.ry2ev
                cb_lower = self.original_widget.cb_lower / self.ry2ev
                cb_upper = self.original_widget.cb_upper / self.ry2ev
        else:
            fermi_plot = fermi
            vb_lower = self.original_widget.vb_lower
            vb_upper = self.original_widget.vb_upper
            cb_lower = self.original_widget.cb_lower
            cb_upper = self.original_widget.cb_upper
        
        bands_data = self.original_widget.bands_data
        kpoints = self.original_widget.kpoints
        
        # Debug print
        print(f"Plotting - Kpoints shape: {kpoints.shape if hasattr(kpoints, 'shape') else len(kpoints)}")
        print(f"Plotting - Bands shape: {bands_data.shape}")
        
        if plot_type == 'pure':
            for i in range(bands_data.shape[0]):
                self.original_widget.ax.plot(kpoints, bands_data[i, :], 
                                            'b-', alpha=0.7, linewidth=1.0)
            self.original_widget.ax.set_title("Pure Band Structure")
            
        elif plot_type == 'fermi':
            for i in range(bands_data.shape[0]):
                self.original_widget.ax.plot(kpoints, bands_data[i, :] - fermi_plot, 
                                            'r-', alpha=0.7, linewidth=1.0)
            self.original_widget.ax.axhline(y=0, color='k', linestyle='--', 
                                        linewidth=1.5, label=f'Fermi Level')
            self.original_widget.ax.set_title("Fermi-Referenced Band Structure")
            self.original_widget.ax.legend()
            
        elif plot_type == 'final':
            for i in range(bands_data.shape[0]):
                self.original_widget.ax.plot(kpoints, bands_data[i, :] - fermi_plot, 
                                            'g-', alpha=0.7, linewidth=1.0)
            
            self.original_widget.ax.axhspan(vb_lower, vb_upper, color='blue', 
                                        alpha=0.2, label='Valence Band')
            self.original_widget.ax.axhspan(cb_lower, cb_upper, color='red', 
                                        alpha=0.2, label='Conduction Band')
            self.original_widget.ax.axhline(y=0, color='k', linestyle='--', 
                                        linewidth=1.5, label=f'Fermi Level')
            self.original_widget.ax.set_title("Band Structure with Highlighted Regions")
            self.original_widget.ax.legend()
        
        # Update labels
        self._update_plot_labels()
        
        # Apply y-axis limits
        self.original_widget.ax.set_ylim(
            self.original_widget.y_min_spinbox.value(), 
            self.original_widget.y_max_spinbox.value()
        )
        
        # Set x-axis limits
        if len(kpoints) > 0:
            self.original_widget.ax.set_xlim(np.min(kpoints), np.max(kpoints))
        
        self.original_widget.ax.grid(True, alpha=0.3)
        self.original_widget.canvas.draw()
        
        # Switch to plot tab
        self.original_widget.tab_widget.setCurrentIndex(5)