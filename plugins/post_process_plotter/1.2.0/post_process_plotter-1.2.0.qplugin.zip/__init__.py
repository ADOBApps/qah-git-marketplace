"""
Post Process Plotter: QE, CP2K and VASP post-processing.
This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

QAH is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

from pathlib import Path
from typing import Optional, Dict, Any
import logging

from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QTabWidget,
    QScrollArea,
)
from PySide6.QtGui import QIcon, QAction
from PySide6.QtCore import Qt, Signal, QObject

from plugins.libs.plugin_manager import PluginInfo

# Import enhanced widgets
from .enhanced_bandswidget import EnhancedBandsWidget
from .enhanced_doswidget import EnhancedDOSWidget
from .enhanced_pdoswidget import EnhancedPDOSWidget
from .enhanced_potentialwidget import EnhancedPotentialWidget
from .vasp_charge_widget import VaspChargeWidget



class PostProcessPlotter(QObject):
    """Main plugin class with CP2K support"""
    
    # Signals for communication with the main app
    analysis_started = Signal(str)
    analysis_completed = Signal(dict)
    error_occurred = Signal(str)

    def __init__(self, plugin_info: PluginInfo):
        super().__init__()
        self.plugin_info = plugin_info
        self.ui_widget = None
        self.icon = None
        
        # Load icon if available
        plugin_dir = Path(__file__).parent
        for icon_name in ("icon.svg", "icon.png"):
            icon_path = plugin_dir / icon_name
            if icon_path.exists():
                self.icon = QIcon(str(icon_path))
                break

    def initialize(self):
        """Initialize the plugin"""
        try:
            logging.info(f"Initializing {self.plugin_info.name} version: {self.plugin_info.version}")
            return True
        except Exception as e:
            logging.error(f"Failed to initialize plugin: {e}")
            return False

    def get_widget(self) -> Optional[QWidget]:
        """Get the main UI widget for this plugin"""
        if self.ui_widget is None:
            try:
                # Create main widget with tabs for different analysis types
                self.ui_widget = QWidget()
                layout = QVBoxLayout(self.ui_widget)
                
                # Create tab widget
                tab_widget = QTabWidget()
                
                # Every tab is scrollable: the plugin must stay usable at
                # 700x500, and the embedded plot canvases are large.
                self.bands_widget = EnhancedBandsWidget()
                tab_widget.addTab(self._wrap_scroll(self.bands_widget), "Band Structure")

                self.dos_widget = EnhancedDOSWidget()
                tab_widget.addTab(self._wrap_scroll(self.dos_widget), "DOS")

                self.pdos_widget = EnhancedPDOSWidget()
                tab_widget.addTab(self._wrap_scroll(self.pdos_widget), "PDOS")

                self.potential_widget = EnhancedPotentialWidget()
                tab_widget.addTab(self._wrap_scroll(self.potential_widget), "Work Function")

                self.vasp_charge_widget = VaspChargeWidget()
                tab_widget.addTab(self.vasp_charge_widget, "VASP Charge")
                
                layout.addWidget(tab_widget)
                
            except Exception as e:
                logging.error(f"Failed to initialize widget: {e}")
                return None
                
        return self.ui_widget

    @staticmethod
    def _wrap_scroll(widget: QWidget) -> QScrollArea:
        area = QScrollArea()
        area.setWidgetResizable(True)
        area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        area.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        area.setWidget(widget)
        return area

    def get_menu_action(self):
        """Get menu action for this plugin"""
        
        action = QAction(self.plugin_info.name, None)
        if self.icon:
            action.setIcon(self.icon)
        action.triggered.connect(self.open_analyzer)
        return action
    
    def open_analyzer(self):
        """Open the analyzer widget"""
        widget = self.get_widget()
        if widget:
            self.analysis_started.emit(self.plugin_info.name)
            return widget
        return None
    
    def analyze_file(self, file_path: str, options: Dict[str, Any] = None) -> Dict[str, Any]:
        """Analyze a file (supports both QE and CP2K formats)"""
        try:
            from .analyzer import UnifiedAnalyzer
            analyzer = UnifiedAnalyzer()
            return analyzer.analyze(file_path, options or {})
        except Exception as e:
            self.error_occurred.emit(str(e))
            raise
    
    def cleanup(self):
        """Cleanup resources"""
        if self.ui_widget:
            self.ui_widget.deleteLater()
            self.ui_widget = None


# Plugin factory function (required by plugin manager)
Plugin = PostProcessPlotter