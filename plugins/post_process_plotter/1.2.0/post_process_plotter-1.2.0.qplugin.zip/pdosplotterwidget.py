"""
Author: Acxel Orozco
Date: 15/08/25
Description: Density of States Plotting Widget
Features:
- Tabbed interface for better organization
- Multiple plot types (regular and shifted)
- Customizable plot ranges
- Project folder management
- Improved error handling
This file is part of Quantum Analysis Helper.
Quantum Analysis Helper is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Quantum Analysis Helper is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QLineEdit, QPushButton, QComboBox, QDoubleSpinBox, QSpinBox,
    QTabWidget, QFileDialog, QMessageBox, QGroupBox, QSizePolicy,
    QListWidget, QListWidgetItem, QScrollArea, QAbstractItemView
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont


class PDOSPlotterWidget(QWidget):
    def __init__(self, parent=None, initial_dir=None):
        super().__init__(parent)
        self.initial_dir = initial_dir
        
        # Variables to store file paths and parameters
        self.file_paths = []
        self.fermi_E = 8.4847
        
        # Axis limits variables
        self.xmin1 = -13
        self.xmax1 = 13
        self.ymax1 = 0  # 0 means auto
        
        self.xmax2 = 50
        self.ymin2 = 0
        self.ymax2 = 12
        
        # Graph customization variables
        self.plot_title = "Projected Density Of States"
        self.xaxis_label = "Energy (eV)"
        self.yaxis_label = "DOS"
        self.legend_position = "best"
        self.color_scheme = "default"
        
        # Legend customization - dictionary to store custom legend names
        self.custom_legends = {}
        
        # Initialize components
        self._create_widgets()
        self._setup_layout()
        self._connect_signals()

    def closeEvent(self, event):
        """Clean up matplotlib resources when widget is closed."""
        plt.close('all')
        event.accept()

    def _create_widgets(self):
        """Create all widget components"""
        # Create tab widget
        self.tab_widget = QTabWidget()
        
        # Main tab
        self.main_tab = QWidget()
        self._create_main_tab()
        
        # Settings tab
        self.settings_tab = QWidget()
        self._create_settings_tab()
        
        # Graph options tab
        self.graph_tab = QWidget()
        self._create_graph_tab()
        
        # Legend customization tab
        self.legend_tab = QWidget()
        self._create_legend_tab()
        
        # Add tabs to tab widget
        self.tab_widget.addTab(self.main_tab, "Files")
        self.tab_widget.addTab(self.settings_tab, "Settings")
        self.tab_widget.addTab(self.graph_tab, "Graph Options")
        self.tab_widget.addTab(self.legend_tab, "Legend Customization")
        
        # Action buttons
        self._create_action_buttons()
    
    def _create_main_tab(self):
        """Create widgets for main tab"""
        layout = QVBoxLayout(self.main_tab)
        
        # File selection frame
        file_group = QGroupBox("Select .dat Files")
        file_layout = QVBoxLayout(file_group)
        
        # Listbox with scrollbar
        self.file_listbox = QListWidget()
        self.file_listbox.setSelectionMode(QAbstractItemView.SingleSelection)
        file_layout.addWidget(self.file_listbox)
        
        # File buttons frame
        file_btn_layout = QHBoxLayout()
        
        self.add_files_button = QPushButton("Add Files")
        file_btn_layout.addWidget(self.add_files_button)
        
        self.remove_file_button = QPushButton("Remove Selected")
        file_btn_layout.addWidget(self.remove_file_button)
        
        file_layout.addLayout(file_btn_layout)
        layout.addWidget(file_group)
        
        # Fermi energy frame
        fermi_group = QGroupBox("Fermi Energy (eV)")
        fermi_layout = QVBoxLayout(fermi_group)
        
        self.fermi_spinbox = QDoubleSpinBox()
        self.fermi_spinbox.setValue(self.fermi_E)
        self.fermi_spinbox.setDecimals(3)
        self.fermi_spinbox.setRange(-100.00, 100.00)
        fermi_layout.addWidget(self.fermi_spinbox)
        
        layout.addWidget(fermi_group)
    
    def _create_settings_tab(self):
        """Create widgets for settings tab"""
        layout = QVBoxLayout(self.settings_tab)
        
        # Plot 1 settings
        plot1_group = QGroupBox("DOS vs Energy Settings")
        plot1_layout = QGridLayout(plot1_group)
        
        plot1_layout.addWidget(QLabel("X min:"), 0, 0)
        self.xmin1_spinbox = QDoubleSpinBox()
        self.xmin1_spinbox.setMinimum(-1000.0)
        self.xmin1_spinbox.setValue(self.xmin1)
        plot1_layout.addWidget(self.xmin1_spinbox, 0, 1)
        
        plot1_layout.addWidget(QLabel("X max:"), 0, 2)
        self.xmax1_spinbox = QDoubleSpinBox()
        self.xmax1_spinbox.setMinimum(-1000.0)
        self.xmax1_spinbox.setValue(self.xmax1)
        plot1_layout.addWidget(self.xmax1_spinbox, 0, 3)
        
        plot1_layout.addWidget(QLabel("Y max (0=auto):"), 1, 0, 1, 2)
        self.ymax1_spinbox = QDoubleSpinBox()
        self.ymax1_spinbox.setValue(self.ymax1)
        plot1_layout.addWidget(self.ymax1_spinbox, 1, 2, 1, 2)
        
        layout.addWidget(plot1_group)
        
        # Plot 2 settings
        plot2_group = QGroupBox("DOS vs E-Efermi Settings")
        plot2_layout = QGridLayout(plot2_group)
        
        plot2_layout.addWidget(QLabel("X max:"), 0, 0)
        self.xmax2_spinbox = QDoubleSpinBox()
        self.xmax2_spinbox.setValue(self.xmax2)
        plot2_layout.addWidget(self.xmax2_spinbox, 0, 1)
        
        plot2_layout.addWidget(QLabel("Y min:"), 1, 0)
        self.ymin2_spinbox = QDoubleSpinBox()
        self.ymin2_spinbox.setMinimum(-1000.0)
        self.ymin2_spinbox.setValue(self.ymin2)
        plot2_layout.addWidget(self.ymin2_spinbox, 1, 1)
        
        plot2_layout.addWidget(QLabel("Y max:"), 2, 0)
        self.ymax2_spinbox = QDoubleSpinBox()
        self.ymax2_spinbox.setValue(self.ymax2)
        plot2_layout.addWidget(self.ymax2_spinbox, 2, 1)
        
        layout.addWidget(plot2_group)
        layout.addStretch()
    
    def _create_graph_tab(self):
        """Create widgets for graph customization tab"""
        layout = QVBoxLayout(self.graph_tab)
        
        # Title and labels frame
        labels_group = QGroupBox("Labels")
        labels_layout = QGridLayout(labels_group)
        
        labels_layout.addWidget(QLabel("Plot Title:"), 0, 0)
        self.title_edit = QLineEdit(self.plot_title)
        labels_layout.addWidget(self.title_edit, 0, 1)
        
        labels_layout.addWidget(QLabel("X-axis Label:"), 1, 0)
        self.xaxis_edit = QLineEdit(self.xaxis_label)
        labels_layout.addWidget(self.xaxis_edit, 1, 1)
        
        labels_layout.addWidget(QLabel("Y-axis Label:"), 2, 0)
        self.yaxis_edit = QLineEdit(self.yaxis_label)
        labels_layout.addWidget(self.yaxis_edit, 2, 1)
        
        layout.addWidget(labels_group)
        
        # Legend and color frame
        style_group = QGroupBox("Style")
        style_layout = QGridLayout(style_group)
        
        style_layout.addWidget(QLabel("Legend Position:"), 0, 0)
        self.legend_combo = QComboBox()
        self.legend_combo.addItems(["best", "upper right", "upper left", "lower left", 
                                  "lower right", "right", "center left", "center right", 
                                  "lower center", "upper center", "center"])
        self.legend_combo.setCurrentText(self.legend_position)
        style_layout.addWidget(self.legend_combo, 0, 1)
        
        style_layout.addWidget(QLabel("Color Scheme:"), 1, 0)
        self.color_combo = QComboBox()
        self.color_combo.addItems(["default", "viridis", "plasma", "inferno", "magma", 
                                 "cividis", "tab10", "Set1", "Set2", "Set3"])
        self.color_combo.setCurrentText(self.color_scheme)
        style_layout.addWidget(self.color_combo, 1, 1)
        
        layout.addWidget(style_group)
        layout.addStretch()
    
    def _create_legend_tab(self):
        """Create widgets for legend customization tab"""
        layout = QVBoxLayout(self.legend_tab)
        
        # Current selection frame
        selection_group = QGroupBox("Selected File")
        selection_layout = QVBoxLayout(selection_group)
        
        self.selected_file_label = QLabel("No file selected")
        selection_layout.addWidget(self.selected_file_label)
        
        layout.addWidget(selection_group)
        
        # Legend customization frame
        legend_group = QGroupBox("Custom Legend Text")
        legend_layout = QGridLayout(legend_group)
        
        legend_layout.addWidget(QLabel("Custom Name:"), 0, 0)
        self.legend_edit = QLineEdit()
        legend_layout.addWidget(self.legend_edit, 0, 1)
        
        self.apply_legend_button = QPushButton("Apply to Selected")
        legend_layout.addWidget(self.apply_legend_button, 0, 2)
        
        layout.addWidget(legend_group)
        
        # Legend preview frame
        preview_group = QGroupBox("Legend Preview")
        preview_layout = QVBoxLayout(preview_group)
        
        self.legend_listbox = QListWidget()
        preview_layout.addWidget(self.legend_listbox)
        
        layout.addWidget(preview_group)
        
        # Button to clear all custom legends
        self.clear_legends_button = QPushButton("Clear All Custom Legends")
        layout.addWidget(self.clear_legends_button)
    
    def _create_action_buttons(self):
        """Create action buttons"""
        self.action_layout = QHBoxLayout()
        
        self.plot_energy_button = QPushButton("Plot DOS vs Energy")
        self.action_layout.addWidget(self.plot_energy_button)
        
        self.plot_efermi_button = QPushButton("Plot DOS vs E-Efermi")
        self.action_layout.addWidget(self.plot_efermi_button)
        
        self.close_button = QPushButton("Close")
        # self.action_layout.addWidget(self.close_button)
    
    def _setup_layout(self):
        """Arrange widgets in the frame"""
        main_layout = QVBoxLayout(self)
        main_layout.addWidget(self.tab_widget)
        main_layout.addLayout(self.action_layout)
    
    def _connect_signals(self):
        """Connect signals to slots"""
        # File operations
        self.add_files_button.clicked.connect(self.add_files)
        self.remove_file_button.clicked.connect(self.remove_file)
        self.file_listbox.currentRowChanged.connect(self._on_file_select)
        
        # Legend operations
        self.apply_legend_button.clicked.connect(self._apply_custom_legend)
        self.clear_legends_button.clicked.connect(self._clear_all_legends)
        
        # Plot operations
        self.plot_energy_button.clicked.connect(self.plot_dos_vs_energy)
        self.plot_efermi_button.clicked.connect(self.plot_dos_vs_efermi)
        self.close_button.clicked.connect(self.hide)
        
        # Value updates
        self.fermi_spinbox.valueChanged.connect(self._update_fermi_energy)
        self.xmin1_spinbox.valueChanged.connect(self._update_xmin1)
        self.xmax1_spinbox.valueChanged.connect(self._update_xmax1)
        self.ymax1_spinbox.valueChanged.connect(self._update_ymax1)
        self.xmax2_spinbox.valueChanged.connect(self._update_xmax2)
        self.ymin2_spinbox.valueChanged.connect(self._update_ymin2)
        self.ymax2_spinbox.valueChanged.connect(self._update_ymax2)
        
        self.title_edit.textChanged.connect(self._update_plot_title)
        self.xaxis_edit.textChanged.connect(self._update_xaxis_label)
        self.yaxis_edit.textChanged.connect(self._update_yaxis_label)
        self.legend_combo.currentTextChanged.connect(self._update_legend_position)
        self.color_combo.currentTextChanged.connect(self._update_color_scheme)

    def _update_fermi_energy(self, value):
        self.fermi_E = value

    def _update_xmin1(self, value):
        self.xmin1 = value

    def _update_xmax1(self, value):
        self.xmax1 = value

    def _update_ymax1(self, value):
        self.ymax1 = value

    def _update_xmax2(self, value):
        self.xmax2 = value

    def _update_ymin2(self, value):
        self.ymin2 = value

    def _update_ymax2(self, value):
        self.ymax2 = value

    def _update_plot_title(self, text):
        self.plot_title = text

    def _update_xaxis_label(self, text):
        self.xaxis_label = text

    def _update_yaxis_label(self, text):
        self.yaxis_label = text

    def _update_legend_position(self, text):
        self.legend_position = text

    def _update_color_scheme(self, text):
        self.color_scheme = text

    def _on_file_select(self, row):
        """Handle file selection in listbox"""
        if row >= 0 and row < len(self.file_paths):
            file_path = self.file_paths[row]
            filename = Path(file_path).name
            self.selected_file_label.setText(f"Selected: {filename}")
            
            # Load existing custom legend if available
            if file_path in self.custom_legends:
                self.legend_edit.setText(self.custom_legends[file_path])
            else:
                self.legend_edit.clear()
    
    def _apply_custom_legend(self):
        """Apply custom legend text to selected file"""
        row = self.file_listbox.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Warning", "Please select a file first!")
            return
        
        file_path = self.file_paths[row]
        custom_text = self.legend_edit.text().strip()
        
        if custom_text:
            self.custom_legends[file_path] = custom_text
            self._update_legend_preview()
            QMessageBox.information(self, "Success", f"Custom legend applied to {Path(file_path).name}")
        else:
            # Remove custom legend if empty text
            if file_path in self.custom_legends:
                del self.custom_legends[file_path]
                self._update_legend_preview()
                QMessageBox.information(self, "Info", f"Custom legend removed from {Path(file_path).name}")
    
    def _update_legend_preview(self):
        """Update the legend preview listbox"""
        self.legend_listbox.clear()
        for file_path, legend_text in self.custom_legends.items():
            filename = Path(file_path).name
            self.legend_listbox.addItem(f"{filename}: {legend_text}")
    
    def _clear_all_legends(self):
        """Clear all custom legends"""
        if self.custom_legends:
            self.custom_legends.clear()
            self._update_legend_preview()
            self.legend_edit.clear()
            QMessageBox.information(self, "Info", "All custom legends cleared")
    
    def add_files(self):
        files, _ = QFileDialog.getOpenFileNames(
            self,
            "Select .dat files",
            self.initial_dir if self.initial_dir else str(Path.cwd()),
            "DAT files (*.dat);;All files (*.*)"
        )
        for file in files:
            if file.endswith('.dat') and file not in self.file_paths:
                self.file_paths.append(file)
                self.file_listbox.addItem(Path(file).name)
    
    def remove_file(self):
        row = self.file_listbox.currentRow()
        if row >= 0:
            file_path = self.file_paths[row]
            # Remove custom legend if it exists
            if file_path in self.custom_legends:
                del self.custom_legends[file_path]
                self._update_legend_preview()
            
            self.file_listbox.takeItem(row)
            self.file_paths.pop(row)
    
    def data_loader(self, fname):
        data = np.loadtxt(fname)
        energy = data[:, 0]
        pdos = data[:, 1]  # ldos col, total contribution for a given orbital
        return energy, pdos
    
    def _get_colors(self, num_colors):
        """Get color palette based on selected scheme"""
        scheme = self.color_scheme
        
        if scheme == "default":
            return ['green', 'red', 'blue', 'orange', 'purple', 'brown', 'pink', 'gray']
        elif scheme in ['viridis', 'plasma', 'inferno', 'magma', 'cividis']:
            cmap = plt.get_cmap(scheme)
            return [cmap(i / max(1, num_colors - 1)) for i in range(num_colors)]
        elif scheme in ['tab10', 'Set1', 'Set2', 'Set3']:
            cmap = plt.get_cmap(scheme)
            return [cmap(i % cmap.N) for i in range(num_colors)]
        else:
            return ['green', 'red', 'blue', 'orange', 'purple', 'brown', 'pink', 'gray']
    
    def _get_legend_label(self, file_path):
        """Get legend label for a file, using custom text if available"""
        if file_path in self.custom_legends:
            return self.custom_legends[file_path]
        else:
            return Path(file_path).stem
    
    def plot_dos_vs_energy(self):
        if not self.file_paths:
            QMessageBox.critical(self, "Error", "No files selected!")
            return
        
        try:
            fermi_E = self.fermi_E
            plt.figure(figsize=(12, 6))
            
            colors = self._get_colors(len(self.file_paths))
            
            for i, file in enumerate(self.file_paths):
                energy, pdos = self.data_loader(file)
                label = self._get_legend_label(file)
                plt.plot(energy, pdos, linewidth=0.75, color=colors[i % len(colors)], label=label)
                plt.fill_between(energy, 0, pdos, where=(energy < fermi_E), 
                               facecolor=colors[i % len(colors)], alpha=0.25)
            
            plt.yticks([])
            plt.xlabel(self.xaxis_label)
            plt.ylabel(self.yaxis_label)
            plt.title(self.plot_title)
            plt.axvline(x=fermi_E, linewidth=0.5, color='k', linestyle=(0, (8, 10)))
            plt.text(fermi_E, plt.ylim()[1]*0.5, 'Fermi energy', fontsize='medium', rotation=90)
            
            # Set axis limits
            plt.xlim(float(self.xmin1), float(self.xmax1))
            if float(self.ymax1) > 0:
                plt.ylim(0, float(self.ymax1))
            
            plt.legend(frameon=False, loc=self.legend_position)
            plt.tight_layout()
            plt.show()
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred:\n{str(e)}")
    
    def plot_dos_vs_efermi(self):
        if not self.file_paths:
            QMessageBox.critical(self, "Error", "No files selected!")
            return
        
        try:
            fermi_E = self.fermi_E
            plt.figure(figsize=(12, 6))
            
            colors = self._get_colors(len(self.file_paths))
            
            for i, file in enumerate(self.file_paths):
                energy, pdos = self.data_loader(file)
                e_efermi = np.subtract(energy, fermi_E)
                label = self._get_legend_label(file)
                plt.plot(pdos, e_efermi, linewidth=0.75, color=colors[i % len(colors)], label=label)
            
            plt.xlabel(self.xaxis_label)
            plt.ylabel(r'$E-E_{Fermi}$ (eV)')
            plt.title(self.plot_title)
            
            # Set axis limits
            plt.xlim(0, float(self.xmax2))
            plt.ylim(float(self.ymin2), float(self.ymax2))
            
            plt.legend(frameon=False, loc=self.legend_position)
            plt.tight_layout()
            plt.show()
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred:\n{str(e)}")


if __name__ == "__main__":
    # Example usage
    from PySide6.QtWidgets import QApplication, QMainWindow
    import sys
    
    app = QApplication(sys.argv)
    window = QMainWindow()
    central_widget = PDOSPlotterWidget()
    window.setCentralWidget(central_widget)
    window.show()
    sys.exit(app.exec())