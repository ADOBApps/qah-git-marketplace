"""
Enhanced Potential Widget with CP2K cube file support
Using composition pattern
This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

QAH is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

import numpy as np
from pathlib import Path
import matplotlib.pyplot as plt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
    QComboBox, QGroupBox, QFileDialog, QMessageBox
)
from PySide6.QtCore import Qt

from .file_detector import FileFormatDetector
from .cube_parser import CubeParser, parse_cube
from .qe_parsers import parse_qe_potential
from .potentialwidget import PotentialAnalyzerWidget


class EnhancedPotentialWidget(QWidget):
    """Enhanced potential widget using composition"""
    
    def __init__(self, parent=None, initial_dir=None):
        super().__init__(parent)
        
        # Store parameters
        self.initial_dir = initial_dir
        self.current_format = None
        self.current_file = None
        self.data = None
        self.cube_data = None
        
        # Create the original potential widget as a child
        self.original_widget = PotentialAnalyzerWidget(self, initial_dir)
        
        # Create our enhanced UI
        self._setup_ui()
        
        # Connect signals
        self._connect_signals()
        
        # Store original data
        self.original_z = None
        self.original_potential = None
        
        # Conversion factors
        self.ha2ev = 27.21138602
        self.bohr2ang = 0.529177210903
    
    def _setup_ui(self):
        """Setup the enhanced UI"""
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Create control panel for CP2K features
        control_panel = QWidget()
        control_layout = QHBoxLayout(control_panel)
        control_layout.setContentsMargins(5, 5, 5, 5)
        
        # Format indicator
        control_layout.addWidget(QLabel("Format:"))
        self.format_label = QLabel("Unknown")
        self.format_label.setStyleSheet("font-weight: bold; color: #2c3e50; padding-right: 10px;")
        control_layout.addWidget(self.format_label)
        
        # Cube-specific settings
        control_layout.addWidget(QLabel("Averaging axis:"))
        self.avg_axis_combo = QComboBox()
        self.avg_axis_combo.addItems(["Z", "X", "Y"])
        self.avg_axis_combo.setCurrentText("Z")
        self.avg_axis_combo.setFixedWidth(60)
        control_layout.addWidget(self.avg_axis_combo)
        
        control_layout.addStretch()
        
        # Add control panel to main layout
        main_layout.addWidget(control_panel)
        
        # Add the original widget
        main_layout.addWidget(self.original_widget)
        
        # Update browse button text
        self.original_widget.browse_potential_button.setText("Browse File")
    
    def _connect_signals(self):
        """Connect signals"""
        # Connect axis selection
        self.avg_axis_combo.currentTextChanged.connect(self._on_axis_changed)
        
        # Override the original widget's browse button
        try:
            self.original_widget.browse_potential_button.clicked.disconnect()
        except:
            pass
        self.original_widget.browse_potential_button.clicked.connect(self._enhanced_browse_file)
        
        # Override analyze button
        try:
            self.original_widget.analyze_button.clicked.disconnect()
        except:
            pass
        self.original_widget.analyze_button.clicked.connect(self._enhanced_analyze)
    
    def _enhanced_browse_file(self):
        """Enhanced file browser with format detection"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Potential File",
            self.initial_dir if self.initial_dir else str(Path.home()),
            "Supported files (*.dat *.cube *.txt *.xsf);;Cube files (*.cube);;DAT files (*.dat);;XSF files (*.xsf);;All files (*.*)"
        )
        if file_path:
            self.current_file = file_path
            self.original_widget.potential_file_entry.setText(file_path)
            
            # Detect format
            self._detect_format(file_path)
    
    def _detect_format(self, file_path):
        """Detect file format"""
        fmt, _ = FileFormatDetector.detect_format(file_path)
        self.current_format = fmt
        
        # Update format label
        format_names = {
            'cube': 'CP2K Cube',
            'qe_potential': 'QE Potential',
        }
        self.format_label.setText(format_names.get(fmt, 'Unknown'))
    
    def _load_cube_data(self, file_path):
        """Load cube file data"""
        try:
            self.cube_data = parse_cube(file_path)
            
            # Get profile for selected axis
            self._update_profile_for_axis()
            
            # Store original data
            profile = self.cube_data['profile']
            self.original_z = profile['z'].copy()
            self.original_potential = profile['value'].copy() * self.ha2ev
            
            return True
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load cube file: {str(e)}")
            return False
    
    def _update_profile_for_axis(self):
        """Update profile for selected axis"""
        if self.cube_data is None:
            return
        
        axis_map = {"Z": 2, "X": 0, "Y": 1}
        axis = axis_map[self.avg_axis_combo.currentText()]
        
        data_3d = self.cube_data['data']
        axes = self.cube_data['axes_au']
        origin = self.cube_data['origin_au']
        
        if axis == 0:  # X
            profile_1d = np.mean(data_3d, axis=(1, 2))
            coords = np.linspace(origin[0], origin[0] + axes[0][0] * data_3d.shape[0], 
                                data_3d.shape[0]) * self.bohr2ang
        elif axis == 1:  # Y
            profile_1d = np.mean(data_3d, axis=(0, 2))
            coords = np.linspace(origin[1], origin[1] + axes[1][1] * data_3d.shape[1], 
                                data_3d.shape[1]) * self.bohr2ang
        else:  # Z
            profile_1d = np.mean(data_3d, axis=(0, 1))
            coords = np.linspace(origin[2], origin[2] + axes[2][2] * data_3d.shape[2], 
                                data_3d.shape[2]) * self.bohr2ang
        
        self.cube_data['profile'] = {
            'z': coords,
            'value': profile_1d,
            'axis': axis
        }
    
    def _on_axis_changed(self):
        """Handle axis selection change"""
        if self.current_format == 'cube' and self.cube_data is not None:
            self._update_profile_for_axis()
            self.original_z = self.cube_data['profile']['z']
            self.original_potential = self.cube_data['profile']['value'] * self.ha2ev
    
    def _enhanced_analyze(self):
        """Enhanced analysis for cube files"""
        potential_file = self.original_widget.potential_file_entry.text()
        if not potential_file:
            QMessageBox.warning(self, "Required Input", "Please select a potential file")
            return
        
        try:
            if self.current_format == 'cube':
                self._analyze_cube_file()
            else:
                # Let original widget handle QE files by calling its method
                # But we need to ensure it has the file path
                self.original_widget.potential_file = potential_file
                self.original_widget._analyze_potential()
                
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error in analysis:\n{str(e)}")
    
    def _analyze_cube_file(self):
        """Analyze cube file for workfunction"""
        # Load cube data if not already loaded
        if self.cube_data is None:
            if not self._load_cube_data(self.current_file):
                return
        
        # Get Fermi energy
        if self.original_widget.auto_fermi_checkbox.isChecked() and self.original_widget.scf_file_entry.text():
            fermi_energy = self.original_widget._extract_fermi_energy(self.original_widget.scf_file_entry.text())
        else:
            fermi_energy = self.original_widget.fermi_energy_spinbox.value()
        
        if fermi_energy is None:
            QMessageBox.warning(self, "Fermi Energy", 
                              "Could not obtain Fermi energy. Please use a custom value.")
            return
        
        # Calculate workfunction
        parser = CubeParser()
        wf_results = parser.calculate_workfunction(
            self.cube_data, 
            (fermi_energy * self.ha2ev),
            self.original_widget.vacuum_threshold
        )
        
        # Store data for plotting
        self.original_widget.potential_data = np.column_stack([
            self.original_z, 
            self.original_potential
        ])
        
        # Display results
        results_text = f"""WORK FUNCTION ANALYSIS FROM CUBE FILE
==========================================
Analyzed file: {Path(self.current_file).name}
Averaging axis: {self.avg_axis_combo.currentText()}
Vacuum threshold: {self.original_widget.vacuum_threshold} Å

FERMI ENERGY: {(fermi_energy * self.ha2ev):.6f} eV

VACUUM POTENTIAL:
  Average value: {wf_results['vacuum_level']:.6f} eV
  Standard deviation: {wf_results['vacuum_std']:.6f} eV
  Region: {wf_results['vacuum_region'][0]:.1f} to {wf_results['vacuum_region'][1]:.1f} Å

WORK FUNCTION: {wf_results['work_function']:.6f} eV

=========================================="""
        
        self.original_widget.results_text.setPlainText(results_text)
        self.original_widget.tab_widget.setCurrentWidget(self.original_widget.results_tab)
        
        # Update preview plot
        self.original_widget._update_preview_plot(
            self.original_z,
            self.original_potential,
            wf_results['vacuum_level']
        )
        
        QMessageBox.information(self, "Analysis Completed", 
                              "Work function analysis completed successfully")