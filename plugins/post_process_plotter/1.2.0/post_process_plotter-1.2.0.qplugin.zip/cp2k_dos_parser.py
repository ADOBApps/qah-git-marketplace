"""
Parser for CP2K DOS (.dos) files
This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

QAH is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

import numpy as np
import re
from typing import Dict, Optional, Tuple


class CP2KDOSParser:
    """Parse CP2K DOS output files"""
    
    def __init__(self):
        self.ha2ev = 27.21138602
        
    def parse(self, file_path: str) -> Dict:
        """
        Parse CP2K .dos file
        
        Returns:
            Dictionary with:
                - energy: array of energies (eV)
                - dos: array of DOS values
                - occupation: array of occupations
                - fermi_energy: Fermi energy (eV)
                - metadata: additional information
        """
        with open(file_path, 'r') as f:
            lines = f.readlines()
        
        # Extract Fermi energy from header
        fermi_au = None
        data_start = 0
        
        for i, line in enumerate(lines):
            if line.startswith('# DOS at iteration'):
                match = re.search(r'E_Fermi\[a\.u\.\] =\s*([\d\.\-]+)', line)
                if match:
                    fermi_au = float(match.group(1))
            elif line.startswith('#  Energy[a.u.]'):
                data_start = i + 1
                break
        
        # Parse data
        energies = []
        densities = []
        occupations = []
        
        for line in lines[data_start:]:
            line = line.strip()
            if line and not line.startswith('#'):
                parts = line.split()
                if len(parts) >= 3:
                    energies.append(float(parts[0]))
                    densities.append(float(parts[1]))
                    occupations.append(float(parts[2]))
        
        # Convert to numpy arrays
        energies = np.array(energies)
        densities = np.array(densities)
        occupations = np.array(occupations)
        
        # Convert energy to eV
        energies_ev = energies * self.ha2ev
        
        # Convert Fermi energy to eV
        fermi_ev = fermi_au * self.ha2ev if fermi_au is not None else None
        
        return {
            'energy_au': energies,
            'energy': energies_ev,
            'dos': densities,
            'occupation': occupations,
            'fermi_energy_au': fermi_au,
            'fermi_energy': fermi_ev,
            'n_points': len(energies),
            'metadata': {
                'source': 'cp2k',
                'type': 'dos'
            }
        }


def parse_cp2k_dos(file_path: str) -> Dict:
    """Convenience function to parse CP2K DOS"""
    parser = CP2KDOSParser()
    return parser.parse(file_path)