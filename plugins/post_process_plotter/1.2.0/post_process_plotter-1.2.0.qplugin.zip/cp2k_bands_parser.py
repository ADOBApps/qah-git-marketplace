"""
Parser for CP2K band structure (.bs) files
This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

QAH is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

import numpy as np
import re
from typing import Dict, List, Tuple, Optional
from pathlib import Path


class CP2KBandsParser:
    """Parse CP2K band structure output files"""
    
    def __init__(self):
        self.ha2ev = 27.21138602
        
    def parse(self, file_path: str) -> Dict:
        """
        Parse CP2K .bs file
        
        Returns:
            Dictionary with:
                - kpoints: array of cumulative k-point distances
                - bands: 2D array [n_bands, n_kpoints] of energies (eV)
                - band_occupations: occupations for each band (optional)
                - special_points: list of dicts with coordinates and labels
                - kpath: list of segments with start/end points
                - metadata: additional information
        """
        with open(file_path, 'r') as f:
            lines = f.readlines()
        
        # Parse header and data
        result = self._parse_bs_content(lines)
        
        # Convert energies to eV (they're already in eV from the file)
        # No conversion needed since the file shows "Energy [eV]"
        
        # Calculate cumulative k-point distances
        if 'kpoints_cartesian' in result and len(result['kpoints_cartesian']) > 0:
            kpoints = result['kpoints_cartesian']
            result['kpoints'] = self._calculate_kpath_distances(kpoints)
            
            # Generate tick positions for special points
            result['special_point_ticks'] = self._get_special_point_ticks(
                result['kpoints'], 
                result.get('special_points', []),
                result.get('kpoint_sets', [])
            )
        
        return result
    
    def _parse_bs_content(self, lines: List[str]) -> Dict:
        """Parse the content of a .bs file"""
        result = {
            'sets': [],
            'kpoints': [],
            'kpoints_cartesian': [],
            'bands': [],
            'band_occupations': [],
            'special_points': [],
            'kpoint_sets': [],
            'metadata': {}
        }
        
        i = 0
        current_set = 0
        n_kpoints_per_set = []
        kpoints_per_set = []
        bands_per_set = []
        all_bands = []  # Store all bands data
        
        # First pass: collect all band data
        current_kpoint_bands = []
        current_kpoint_occ = []
        in_bands_section = False
        
        for line in lines:
            line = line.strip()
            
            # Parse set header to get number of bands
            if line.startswith('# Set'):
                match = re.search(r'# Set \d+: \d+ special points, \d+ k-points, (\d+) bands', line)
                if match:
                    n_bands = int(match.group(1))
                    result['n_bands'] = n_bands
                continue
            
            # Parse special point
            if line.startswith('#  Special point'):
                match = re.search(r'#  Special point \d+\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+(\w+)', line)
                if match:
                    sp = {
                        'x': float(match.group(1)),
                        'y': float(match.group(2)),
                        'z': float(match.group(3)),
                        'label': match.group(4)
                    }
                    # Avoid duplicates
                    if not any(s['x'] == sp['x'] and s['y'] == sp['y'] and s['z'] == sp['z'] 
                              for s in result['special_points']):
                        result['special_points'].append(sp)
                continue
            
            # Parse k-point header
            if line.startswith('#  Point'):
                # Store previous k-point's bands if any
                if current_kpoint_bands:
                    all_bands.append(current_kpoint_bands)
                    if current_kpoint_occ:
                        result['band_occupations'].append(current_kpoint_occ)
                
                # Parse k-point coordinates
                match = re.search(r'#  Point \d+\s+Spin \d+:\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)', line)
                if match:
                    kx = float(match.group(1))
                    ky = float(match.group(2))
                    kz = float(match.group(3))
                    result['kpoints_cartesian'].append([kx, ky, kz])
                
                current_kpoint_bands = []
                current_kpoint_occ = []
                in_bands_section = True
                continue
            
            # Parse band data
            if in_bands_section and line and line[0].isdigit():
                parts = line.split()
                if len(parts) >= 3:
                    try:
                        band_idx = int(parts[0])
                        energy = float(parts[1])
                        occupation = float(parts[2])
                        current_kpoint_bands.append(energy)
                        current_kpoint_occ.append(occupation)
                    except (ValueError, IndexError):
                        continue
        
        # Add the last k-point's bands
        if current_kpoint_bands:
            all_bands.append(current_kpoint_bands)
            if current_kpoint_occ:
                result['band_occupations'].append(current_kpoint_occ)
        
        # Convert to numpy array
        if all_bands:
            # Determine number of bands from first k-point
            n_bands = len(all_bands[0])
            n_kpoints = len(all_bands)
            
            # Create bands array [n_bands, n_kpoints]
            bands_array = np.zeros((n_bands, n_kpoints))
            
            for k_idx, kpoint_bands in enumerate(all_bands):
                for band_idx, energy in enumerate(kpoint_bands):
                    if band_idx < n_bands:
                        bands_array[band_idx, k_idx] = energy
            
            result['bands'] = bands_array
            result['n_kpoints'] = n_kpoints
            result['n_bands'] = n_bands
        
        # Also store in the format expected by the original widget
        if 'bands' in result and result['bands'].size > 0:
            # Also create the format expected by BandsWidget
            result['bands_for_plot'] = result['bands']
        
        return result
    
    def _calculate_kpath_distances(self, kpoints: List[List[float]]) -> np.ndarray:
        """Calculate cumulative distances along k-path"""
        kpoints = np.array(kpoints)
        n_kpoints = len(kpoints)
        
        if n_kpoints == 0:
            return np.array([])
        
        distances = np.zeros(n_kpoints)
        for i in range(1, n_kpoints):
            # Calculate distance between consecutive k-points in reciprocal space
            diff = kpoints[i] - kpoints[i-1]
            dist = np.linalg.norm(diff)
            distances[i] = distances[i-1] + dist
        
        return distances
    
    def _get_special_point_ticks(self, kpath: np.ndarray, special_points: List[Dict], 
                                  kpoint_sets: List[int]) -> List[Dict]:
        """Get tick positions for special points on the k-path"""
        ticks = []
        
        if not special_points or len(kpoint_sets) == 0 or len(kpath) == 0:
            return ticks
        
        # Special points are at the boundaries of sets
        k_idx = 0
        for i, n_kpoints in enumerate(kpoint_sets):
            if i < len(special_points) and k_idx < len(kpath):
                ticks.append({
                    'position': float(kpath[k_idx]),  # Convert to float for JSON serialization
                    'label': special_points[i % len(special_points)]['label']
                })
            k_idx += n_kpoints
        
        # Add the last point if not already added
        if len(special_points) > 0 and k_idx > 0 and k_idx-1 < len(kpath):
            last_pos = float(kpath[-1])
            # Check if we already have a tick at this position
            if not any(abs(t['position'] - last_pos) < 1e-6 for t in ticks):
                last_idx = min(len(special_points) - 1, len(kpoint_sets) - 1)
                ticks.append({
                    'position': last_pos,
                    'label': special_points[last_idx]['label']
                })
        
        return ticks


def parse_cp2k_bands(file_path: str) -> Dict:
    """Convenience function to parse CP2K bands"""
    parser = CP2KBandsParser()
    return parser.parse(file_path)