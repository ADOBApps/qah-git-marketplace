#!/usr/bin/env python3
"""Self-tests for post_process_cli.py and analyzer.py (no Qt required).

Run:
    python3 test_cli.py

Creates small synthetic QE/CP2K/VASP inputs, runs the CLI as a subprocess and
checks the outputs. Set TIO2_SN_VASP to a VASP tree to also test a real LOCPOT.
"""

from __future__ import annotations

import os
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import test_vasp_charge as vasp_tests  # noqa: E402
from analyzer import UnifiedAnalyzer  # noqa: E402

CLI = HERE / "post_process_cli.py"
THESIS = Path(os.environ.get("TIO2_SN_VASP", ""))


def run(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, str(CLI), *args],
        capture_output=True,
        text=True,
        cwd=str(HERE),
    )


def make_samples(folder: Path) -> dict:
    samples = {
        "bands": folder / "bands.gnu",
        "dos": folder / "dos.dat",
        "pdos": folder / "pdos.dat",
        "cp2k_dos": folder / "cp2k.dos",
        "potential": folder / "potential.dat",
    }
    samples["bands"].write_text(
        "# k index, bands (Ry)\n"
        "0  -0.50  0.10  0.30\n"
        "1  -0.45  0.15  0.35\n"
        "2  -0.40  0.20  0.40\n"
        "3  -0.35  0.25  0.45\n"
    )
    samples["dos"].write_text(
        "# E (Ry)  dos\n0.00 1.0\n0.05 2.0\n0.10 3.5\n0.15 2.5\n0.20 1.2\n"
    )
    samples["pdos"].write_text(
        "# E (eV) ldos(s) ldos(p) ldos(d)\n"
        "0.00 1.0 0.2 0.1\n0.05 1.5 0.4 0.2\n0.10 2.0 0.8 0.3\n"
    )
    samples["cp2k_dos"].write_text(
        "# DOS at iteration step i = 0, E_Fermi[a.u.] = 0.200000\n"
        "#  Energy[a.u.]  Density  Occupation\n"
        "-0.50 1.0 2.0\n-0.25 2.0 2.0\n0.00 3.0 1.0\n0.25 1.5 0.0\n"
    )
    samples["potential"].write_text(
        "# z(Ang) V(Ry)\n0.0 0.10\n5.0 0.12\n10.0 0.09\n15.0 0.11\n"
    )
    chgcar = folder / "CHGCAR"
    vasp_tests._synthetic(chgcar, spin=True)
    samples["chgcar"] = chgcar
    return samples


def test_doctor() -> None:
    result = run("doctor")
    assert result.returncode == 0, result.stderr
    assert "plugin_version" in result.stdout
    print("PASS cli doctor")


def test_detect(samples: dict) -> None:
    expected = {
        "bands": "qe_bands",
        "dos": "qe_dos",
        "pdos": "qe_pdos",
        "cp2k_dos": "cp2k_dos",
        "chgcar": "vasp_field",
    }
    for key, fmt in expected.items():
        result = run("detect", str(samples[key]), "--json")
        assert result.returncode == 0, (key, result.stderr)
        assert f'"format": "{fmt}"' in result.stdout, (key, result.stdout)
    print("PASS cli detect (5 formats)")


def test_data_commands(samples: dict) -> None:
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cases = [
            ("bands", ["--csv", str(tmp_path / "b.csv"), "--plot", str(tmp_path / "b.png")]),
            ("dos", ["--csv", str(tmp_path / "d.csv")]),
            ("pdos", ["--csv", str(tmp_path / "p.csv")]),
            ("potential", ["--csv", str(tmp_path / "v.csv"), "--plot", str(tmp_path / "v.png")]),
        ]
        for key, extra in cases:
            result = run(key, str(samples[key]), *extra)
            assert result.returncode == 0, (key, result.stderr)
            assert "n_points" in result.stdout or "n_kpoints" in result.stdout
        assert (tmp_path / "b.csv").stat().st_size > 0
        assert (tmp_path / "b.png").stat().st_size > 0
        assert (tmp_path / "d.csv").stat().st_size > 0
        assert (tmp_path / "p.csv").stat().st_size > 0
        assert (tmp_path / "v.png").stat().st_size > 0
        cp2k = run("dos", str(samples["cp2k_dos"]), "--json")
        assert cp2k.returncode == 0 and "fermi_energy" in cp2k.stdout
    print("PASS cli bands/dos/pdos/potential with CSV and plots")


def test_vasp_commands(samples: dict) -> None:
    result = run("vasp", "info", str(samples["chgcar"]))
    assert result.returncode == 0, result.stderr
    assert "electrons" in result.stdout and "1.000000" in result.stdout
    with tempfile.TemporaryDirectory() as tmp:
        csv = Path(tmp) / "avg.csv"
        result = run("vasp", "avg", str(samples["chgcar"]), "--axis", "c", "--csv", str(csv))
        assert result.returncode == 0, result.stderr
        assert csv.stat().st_size > 0
        cube = Path(tmp) / "field.cube"
        result = run("vasp", "cube", str(samples["chgcar"]), str(cube))
        assert result.returncode == 0, result.stderr
        assert cube.stat().st_size > 0
    print("PASS cli vasp info/avg/cube")


def test_analyzer(samples: dict) -> None:
    analyzer = UnifiedAnalyzer()
    result = analyzer.analyze(str(samples["chgcar"]))
    assert result["format"] == "VASP CHGCAR"
    assert result["grid"] == [4, 3, 5]
    assert abs(result["electrons"] - 1.0) < 1e-8
    assert len(result["plot_data"]["Y"]) == 5
    bands = analyzer.analyze(str(samples["bands"]))
    assert bands["plot_data"]["type"] == "bands"
    dos = analyzer.analyze(str(samples["dos"]))
    assert dos["plot_data"]["type"] == "dos"
    print("PASS analyzer VASP/QE dispatch")


def test_real_locpot() -> None:
    if not str(THESIS) or not THESIS.is_dir():
        print("SKIP real LOCPOT (set TIO2_SN_VASP)")
        return
    locpot = THESIS / "slab36/pristine/LOCPOT"
    if not locpot.is_file():
        print("SKIP real LOCPOT (file not found)")
        return
    result = run("vasp", "workfunction", str(locpot))
    assert result.returncode == 0, result.stderr
    assert "4.270" in result.stdout
    analyzed = UnifiedAnalyzer().analyze(str(locpot))
    assert abs(analyzed["work_function"] - 4.270257) < 1e-3
    print("PASS real LOCPOT through CLI and analyzer")


def main() -> int:
    test_doctor()
    with tempfile.TemporaryDirectory() as tmp:
        samples = make_samples(Path(tmp))
        test_detect(samples)
        test_data_commands(samples)
        test_vasp_commands(samples)
        test_analyzer(samples)
    test_real_locpot()
    print("ALL CLI TESTS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
