"""
Base classes for unified plotting widgets supporting both QE and CP2K
This file is part of QAH.
QAH is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

QAH is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Copyright (C) [2026] Acxel David Orozco Baldomero
"""

import numpy as np
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox
from PySide6.QtCore import Signal

from .file_detector import detect_file_format, FileFormatDetector


class UnifiedPlotterBase(QWidget):
    """Base class for all plotters with dual QE/CP2K support"""
    
    format_changed = Signal(str)  # Emitted when file format changes
    
    def __init__(self, parent=None, initial_dir=None):
        # super().__init__(parent)
        self.initial_dir = initial_dir
        self.current_format = None
        self.current_file = None
        self.data = None
        
        # Conversion factors
        self.ha2ev = FileFormatDetector.HA2EV
        self.bohr2ang = FileFormatDetector.BOHR2ANG
    
    def detect_format(self, file_path: str) -> str:
        """Detect file format"""
        fmt, _ = FileFormatDetector.detect_format(file_path)
        self.current_format = fmt
        self.format_changed.emit(fmt)
        return fmt
    
    def load_file(self, file_path: str) -> bool:
        """
        Load file based on detected format
        Override in derived classes
        """
        self.current_file = file_path
        fmt = self.detect_format(file_path)
        
        if fmt.startswith('cp2k_bands'):
            from .cp2k_bands_parser import parse_cp2k_bands
            self.data = parse_cp2k_bands(file_path)
        elif fmt.startswith('cp2k_dos'):
            from .cp2k_dos_parser import parse_cp2k_dos
            self.data = parse_cp2k_dos(file_path)
        elif fmt.startswith('cp2k_pdos'):
            from .cp2k_pdos_parser import parse_cp2k_pdos
            self.data = parse_cp2k_pdos(file_path)
        elif fmt == 'cube':
            from .cube_parser import parse_cube
            self.data = parse_cube(file_path)
        elif fmt.startswith('qe_'):
            # Use existing QE parsers
            from .qe_parsers import parse_qe_bands, parse_qe_dos, parse_qe_pdos
            if fmt == 'qe_bands':
                self.data = parse_qe_bands(file_path)
            elif fmt == 'qe_dos':
                self.data = parse_qe_dos(file_path)
            elif fmt == 'qe_pdos':
                self.data = parse_qe_pdos(file_path)
        else:
            return False
        
        return True
    
    def add_format_indicator(self, layout):
        """Add format indicator to UI"""
        format_layout = QHBoxLayout()
        format_layout.addWidget(QLabel("File Format:"))
        
        self.format_label = QLabel("Unknown")
        self.format_label.setStyleSheet("font-weight: bold;")
        format_layout.addWidget(self.format_label)
        
        format_layout.addStretch()
        layout.addLayout(format_layout)
        
        # Connect signal
        self.format_changed.connect(self._update_format_display)
    
    def _update_format_display(self, fmt: str):
        """Update format display"""
        format_names = {
            'cp2k_bands': 'CP2K Bands',
            'cp2k_dos': 'CP2K DOS',
            'cp2k_pdos': 'CP2K PDOS',
            'cube': 'CP2K Cube',
            'qe_bands': 'Quantum ESPRESSO Bands',
            'qe_dos': 'Quantum ESPRESSO DOS',
            'qe_pdos': 'Quantum ESPRESSO PDOS'
        }
        self.format_label.setText(format_names.get(fmt, 'Unknown'))


class UnitConverter:
    """Handle unit conversions for different codes"""
    
    HA2EV = 27.21138602
    RY2EV = 13.605693
    BOHR2ANG = 0.529177210903
    
    @staticmethod
    def convert_energy(value: float, from_units: str, to_units: str = 'eV') -> float:
        """Convert energy between different units"""
        if from_units == to_units:
            return value
        
        # Convert to eV first
        if from_units == 'Ha':
            value_ev = value * UnitConverter.HA2EV
        elif from_units == 'Ry':
            value_ev = value * UnitConverter.RY2EV
        elif from_units == 'eV':
            value_ev = value
        else:
            return value
        
        # Convert from eV to target
        if to_units == 'eV':
            return value_ev
        elif to_units == 'Ha':
            return value_ev / UnitConverter.HA2EV
        elif to_units == 'Ry':
            return value_ev / UnitConverter.RY2EV
        else:
            return value_ev
    
    @staticmethod
    def convert_length(value: float, from_units: str, to_units: str = 'Ang') -> float:
        """Convert length between different units"""
        if from_units == to_units:
            return value
        
        # Convert to Angstrom first
        if from_units == 'Bohr':
            value_ang = value * UnitConverter.BOHR2ANG
        elif from_units == 'Ang':
            value_ang = value
        else:
            return value
        
        # Convert from Angstrom to target
        if to_units == 'Ang':
            return value_ang
        elif to_units == 'Bohr':
            return value_ang / UnitConverter.BOHR2ANG
        else:
            return value_ang