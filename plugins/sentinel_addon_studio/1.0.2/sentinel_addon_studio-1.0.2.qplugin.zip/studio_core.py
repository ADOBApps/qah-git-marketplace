"""Core helpers for Sentinel Addon Studio.

Addon Studio is a developer plugin: it scaffolds `.qah` addon projects, runs
them through Plugin Sentinel's isolated addon host, builds `.qah` packages and
publishes them through the Git Plugin Marketplace CLI.
"""

from __future__ import annotations

import hashlib
import importlib
import importlib.util
import json
import os
import re
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional

ADDON_FORMAT = "qah-sentinel-addon"
ADDON_API_VERSION = 1
ID_RE = re.compile(r"^[a-z][a-z0-9_]{2,63}$")
VERSION_RE = re.compile(r"^[0-9A-Za-z][0-9A-Za-z._+-]{0,63}$")
CAPABILITIES = [
    "read-files",
    "write-files",
    "network",
    "findings",
    "report",
    "policy",
    "watchdog",
]
SKIP_DIRS = {
    "__pycache__",
    ".git",
    ".hg",
    ".svn",
    "build",
    "dist",
    ".venv",
    "venv",
    "node_modules",
}
SKIP_SUFFIXES = (".pyc", ".pyo", ".qah", ".stable", ".old", ".tmp")

CODE_TEMPLATE = '''"""Sentinel addon: {name}.

This code runs only inside Plugin Sentinel's isolated addon host.
Return a JSON-serializable dictionary from run(context).
"""

from pathlib import Path


def run(context):
    findings = []
    for target in context.get("targets", []):
        path = Path(target)
        if not path.exists():
            findings.append({{
                "severity": "warning",
                "title": "Missing target",
                "detail": str(path),
            }})
            continue
        if path.is_file():
            size = path.stat().st_size
            findings.append({{
                "severity": "info",
                "title": f"{{path.name}}: {{size}} bytes",
                "detail": str(path),
            }})
        else:
            findings.append({{
                "severity": "info",
                "title": f"Folder: {{path.name}}",
                "detail": str(path),
            }})
    return {{
        "status": "ok",
        "summary": f"{{len(findings)}} target(s) checked",
        "findings": findings,
        "report": "",
        "data": {{}},
    }}
'''

README_TEMPLATE = """# {name}

Sentinel addon built with **Sentinel Addon Studio**.

```text
id          : {addon_id}
version     : {version}
api_version : {api_version}
author      : {author}
entry       : {entry}
capabilities: {capabilities}
```

## Install

Import the built `.qah` in **Plugin Sentinel → Addons → Import .qah…**, or
publish it and install it from the **Git Plugin Marketplace → Addons** tab.

## API

```python
def run(context):
    return {{
        "status": "ok",
        "summary": "what happened",
        "findings": [],
        "report": "optional markdown",
        "data": {{}},
    }}
```

Context keys: `addon_id`, `addon_name`, `addon_version`, `api_version`,
`capabilities`, `addon_dir`, `data_dir`, `workdir`, `targets`, `config`.

Addons never run inside Sentinel's process. Subprocesses, native libraries,
registry access and undeclared network access are blocked.
"""


def state_dir() -> Path:
    override = os.environ.get("QAH_ADDON_STUDIO_HOME")
    root = Path(override).expanduser() if override else Path.home() / "QAH" / "sentinel_addon_studio"
    root.mkdir(parents=True, exist_ok=True)
    return root


def projects_dir(create: bool = True) -> Path:
    root = state_dir() / "projects"
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def package_dir(create: bool = True) -> Path:
    root = state_dir() / "packages"
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def _classic_plugins_dir() -> Path:
    try:
        from plugins.libs import plugin_paths  # type: ignore

        return Path(plugin_paths.classic_plugins_dir())
    except Exception:
        return Path.home() / "QAH" / "plugins" / "python_plugins"


def _system_plugins_dir() -> Optional[Path]:
    try:
        from plugins.libs import plugin_manager  # type: ignore

        return Path(plugin_manager.__file__).resolve().parents[1] / "python_plugins"
    except Exception:
        return None


def find_plugin_folder(plugin_id: str) -> Optional[Path]:
    roots = [_classic_plugins_dir()]
    system = _system_plugins_dir()
    if system is not None:
        roots.append(system)
    for root in roots:
        direct = root / plugin_id
        if (direct / "manifest.json").is_file():
            return direct
        try:
            for manifest in root.rglob("manifest.json"):
                if manifest.parent.name == plugin_id:
                    return manifest.parent
        except OSError:
            continue
    return None


def _load_module_from_plugin(plugin_id: str, module_name: str):
    folder = find_plugin_folder(plugin_id)
    if folder is not None:
        parent = folder.parent
        if str(parent) not in sys.path:
            sys.path.insert(0, str(parent))
        importlib.invalidate_caches()
    return importlib.import_module(f"{plugin_id}.{module_name}")


def load_sentinel_addons():
    try:
        return _load_module_from_plugin("plugin_sentinel", "sentinel_addons")
    except Exception as exc:
        raise RuntimeError(
            "Plugin Sentinel is not installed or could not be loaded, so the "
            f"addon cannot be tested: {exc}"
        ) from exc


# -- project files -----------------------------------------------------------


def manifest_for(meta: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "format": ADDON_FORMAT,
        "id": str(meta.get("id") or "").strip(),
        "name": str(meta.get("name") or meta.get("id") or "").strip(),
        "version": str(meta.get("version") or "1.0.0").strip(),
        "api_version": ADDON_API_VERSION,
        "author": str(meta.get("author") or "").strip(),
        "description": str(meta.get("description") or "").strip(),
        "main": str(meta.get("main") or "main.py").strip(),
        "entry": str(meta.get("entry") or "run").strip(),
        "timeout": int(meta.get("timeout", 30) or 30),
        "capabilities": [str(item) for item in (meta.get("capabilities") or [])],
    }


def create_project(meta: Dict[str, Any]) -> Path:
    addon_id = str(meta.get("id") or "").strip()
    if not ID_RE.fullmatch(addon_id):
        raise ValueError("Addon id must be lowercase letters, digits and underscores.")
    folder = Path(meta.get("folder") or (projects_dir() / addon_id)).expanduser()
    if folder.exists() and any(folder.iterdir()):
        raise ValueError(f"Folder is not empty: {folder}")
    folder.mkdir(parents=True, exist_ok=True)
    manifest = manifest_for(meta)
    (folder / "addon.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    (folder / "main.py").write_text(
        CODE_TEMPLATE.format(
            name=manifest["name"] or addon_id,
            addon_id=addon_id,
        ),
        encoding="utf-8",
    )
    (folder / "README.md").write_text(
        README_TEMPLATE.format(
            name=manifest["name"] or addon_id,
            addon_id=addon_id,
            version=manifest["version"],
            api_version=ADDON_API_VERSION,
            author=manifest["author"],
            entry=manifest["entry"],
            capabilities=", ".join(manifest["capabilities"]) or "none",
        ),
        encoding="utf-8",
    )
    return folder


def save_project(folder: Path, meta: Dict[str, Any], code: str, readme: str = "") -> Path:
    folder = Path(folder).expanduser()
    folder.mkdir(parents=True, exist_ok=True)
    manifest = manifest_for(meta)
    (folder / "addon.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    main = str(meta.get("main") or "main.py")
    (folder / main).write_text(code, encoding="utf-8")
    if readme:
        (folder / "README.md").write_text(readme, encoding="utf-8")
    return folder


def load_project(folder: Path) -> Dict[str, Any]:
    folder = Path(folder).expanduser()
    manifest = json.loads((folder / "addon.json").read_text(encoding="utf-8"))
    main = str(manifest.get("main") or "main.py")
    code = (folder / main).read_text(encoding="utf-8") if (folder / main).is_file() else ""
    readme_path = folder / "README.md"
    readme = readme_path.read_text(encoding="utf-8") if readme_path.is_file() else ""
    return {"folder": str(folder), "manifest": manifest, "code": code, "readme": readme}


# -- validation and packaging ------------------------------------------------


def validate_project(folder: Path) -> List[str]:
    folder = Path(folder).expanduser()
    errors: List[str] = []
    manifest_path = folder / "addon.json"
    if not manifest_path.is_file():
        return ["addon.json is missing"]
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception as exc:
        return [f"addon.json is not valid JSON: {exc}"]
    if not isinstance(manifest, dict):
        return ["addon.json is not an object"]
    if manifest.get("format") != ADDON_FORMAT:
        errors.append(f"format must be {ADDON_FORMAT!r}")
    addon_id = str(manifest.get("id") or "")
    if not ID_RE.fullmatch(addon_id):
        errors.append("id must be lowercase letters, digits and underscores")
    for field in ("name", "author", "description"):
        if not str(manifest.get(field) or "").strip():
            errors.append(f"{field} is required")
    if not VERSION_RE.fullmatch(str(manifest.get("version") or "")):
        errors.append("version is invalid")
    try:
        api_version = int(manifest.get("api_version", 0))
    except Exception:
        api_version = -1
    if api_version != ADDON_API_VERSION:
        errors.append(f"api_version must be {ADDON_API_VERSION}")
    main = str(manifest.get("main") or "main.py")
    if not (folder / main).is_file():
        errors.append(f"main file {main!r} is missing")
    entry = str(manifest.get("entry") or "run")
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", entry):
        errors.append("entry must be a Python function name")
    caps = manifest.get("capabilities")
    if not isinstance(caps, list):
        errors.append("capabilities must be a list")
    else:
        unknown = sorted(set(str(item) for item in caps) - set(CAPABILITIES))
        if unknown:
            errors.append("unknown capabilities: " + ", ".join(unknown))
    try:
        timeout = int(manifest.get("timeout", 30))
        if not 1 <= timeout <= 300:
            errors.append("timeout must be between 1 and 300 seconds")
    except Exception:
        errors.append("timeout must be an integer")
    return errors


def build_package(folder: Path, output: Optional[Path] = None) -> Dict[str, Any]:
    folder = Path(folder).expanduser()
    errors = validate_project(folder)
    if errors:
        raise ValueError("; ".join(errors))
    manifest = json.loads((folder / "addon.json").read_text(encoding="utf-8"))
    addon_id = str(manifest["id"])
    version = str(manifest["version"])
    if output is None:
        output = package_dir() / f"{addon_id}-{version}.qah"
    output = Path(output).expanduser()
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(folder.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(folder)
            if any(part in SKIP_DIRS for part in rel.parts):
                continue
            if path.name.endswith(SKIP_SUFFIXES) or path.name == ".qah_install.json":
                continue
            archive.write(path, rel.as_posix())
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    return {
        "path": str(output),
        "id": addon_id,
        "version": version,
        "size": output.stat().st_size,
        "sha256": digest,
    }


# -- Sentinel test -----------------------------------------------------------


def test_project(folder: Path, targets: Optional[List[str]] = None, timeout: Optional[int] = None) -> Dict[str, Any]:
    module = load_sentinel_addons()
    return module.run_addon_folder(folder, targets=targets or [], timeout=timeout)


# -- publish -----------------------------------------------------------------


def _marketplace_cli() -> Path:
    folder = find_plugin_folder("git_plugin_marketplace")
    if folder is None:
        raise RuntimeError(
            "Git Plugin Marketplace is not installed. Install it before publishing addons."
        )
    cli = folder / "git_marketplace_cli.py"
    if not cli.is_file():
        raise RuntimeError(f"Marketplace CLI not found: {cli}")
    return cli


def marketplace_info() -> Dict[str, Any]:
    """Read the marketplace config without exposing or printing the token."""
    try:
        cli = _marketplace_cli()
    except Exception as exc:
        return {"available": False, "error": str(exc), "slug": "", "branch": ""}
    folder = cli.parent
    module_path = folder / "git_marketplace_core.py"
    try:
        spec = importlib.util.spec_from_file_location(
            "_sentinel_studio_marketplace_core", module_path
        )
        if spec is None or spec.loader is None:
            raise RuntimeError(f"Cannot load {module_path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        config = module.load_config()
        return {
            "available": True,
            "cli": str(cli),
            "slug": getattr(config, "slug", ""),
            "branch": getattr(config, "branch", "master"),
            "token_saved": bool(getattr(config, "token", "")),
        }
    except Exception as exc:
        return {
            "available": True,
            "cli": str(cli),
            "slug": "",
            "branch": "",
            "error": str(exc),
            "token_saved": False,
        }


def publish_project(folder: Path, *, version: str = "", changelog: str = "") -> Dict[str, Any]:
    cli = _marketplace_cli()
    command = [sys.executable, str(cli), "publish-addon", str(Path(folder).expanduser())]
    if version:
        command += ["--version", version]
    command += ["--changelog", changelog or "Published with Sentinel Addon Studio"]
    kwargs: Dict[str, Any] = {}
    if os.name == "nt":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    proc = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=900,
        **kwargs,
    )
    output = (proc.stdout or "") + (proc.stderr or "")
    return {
        "returncode": proc.returncode,
        "output": output.strip(),
        "command": " ".join(command),
    }
