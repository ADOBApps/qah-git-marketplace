"""PySide6 workbench for Sentinel Addon Studio."""

from __future__ import annotations

import json
import traceback
from pathlib import Path
from typing import Any, Dict, List, Optional

from PySide6.QtCore import QRect, QRegularExpression, QSize, Qt, QThread, QUrl, Signal
from PySide6.QtGui import (
    QAction,
    QColor,
    QDesktopServices,
    QFont,
    QKeySequence,
    QPainter,
    QShortcut,
    QSyntaxHighlighter,
    QTextCharFormat,
)
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSpinBox,
    QSplitter,
    QTabWidget,
    QToolBar,
    QVBoxLayout,
    QWidget,
)

from . import studio_core as core

CAPABILITY_HELP = {
    "read-files": "Receive and read target paths (read-only).",
    "write-files": "Write only inside the addon data directory.",
    "network": "Allow network sockets (blocked by default).",
    "findings": "Return structured findings.",
    "report": "Return a markdown/text report.",
    "policy": "Intended for policy-oriented addons.",
    "watchdog": "Intended for watchdog-oriented addons.",
}


class LineNumberArea(QWidget):
    def __init__(self, editor):
        super().__init__(editor)
        self.editor = editor

    def sizeHint(self):
        return QSize(self.editor.line_number_area_width(), 0)

    def paintEvent(self, event):
        self.editor.line_number_area_paint_event(event)


class CodeEditor(QPlainTextEdit):
    """Plain-text editor with a line-number gutter."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.line_number_area = LineNumberArea(self)
        self.blockCountChanged.connect(self._update_width)
        self.updateRequest.connect(self._update_area)
        self.cursorPositionChanged.connect(self._update_width)
        self._update_width(0)

    def line_number_area_width(self) -> int:
        digits = max(2, len(str(max(1, self.blockCount()))))
        return 10 + self.fontMetrics().horizontalAdvance("9") * digits

    def _update_width(self, _count=0):
        self.setViewportMargins(self.line_number_area_width(), 0, 0, 0)

    def _update_area(self, rect, dy):
        if dy:
            self.line_number_area.scroll(0, dy)
        else:
            self.line_number_area.update(
                0, rect.y(), self.line_number_area.width(), rect.height()
            )
        if rect.contains(self.viewport().rect()):
            self._update_width(0)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        cr = self.contentsRect()
        self.line_number_area.setGeometry(
            QRect(cr.left(), cr.top(), self.line_number_area_width(), cr.height())
        )

    def line_number_area_paint_event(self, event):
        painter = QPainter(self.line_number_area)
        painter.fillRect(event.rect(), QColor("#f3f4f6"))
        block = self.firstVisibleBlock()
        number = block.blockNumber()
        top = int(
            self.blockBoundingGeometry(block).translated(self.contentOffset()).top()
        )
        bottom = top + int(self.blockBoundingRect(block).height())
        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                painter.setPen(QColor("#6b7280"))
                painter.drawText(
                    0,
                    top,
                    self.line_number_area.width() - 6,
                    self.fontMetrics().height(),
                    Qt.AlignmentFlag.AlignRight,
                    str(number + 1),
                )
            block = block.next()
            top = bottom
            bottom = top + int(self.blockBoundingRect(block).height())
            number += 1
        painter.end()


class PythonHighlighter(QSyntaxHighlighter):
    def __init__(self, document):
        super().__init__(document)
        self.rules = []
        keyword = QTextCharFormat()
        keyword.setForeground(QColor("#1f4e79"))
        keyword.setFontWeight(QFont.Weight.Bold)
        for word in (
            "and", "as", "assert", "async", "await", "break", "class", "continue",
            "def", "del", "elif", "else", "except", "False", "finally", "for",
            "from", "global", "if", "import", "in", "is", "lambda", "None",
            "nonlocal", "not", "or", "pass", "raise", "return", "True", "try",
            "while", "with", "yield",
        ):
            self.rules.append((QRegularExpression(r"\b" + word + r"\b"), keyword))
        builtin = QTextCharFormat()
        builtin.setForeground(QColor("#7c3aed"))
        for word in (
            "abs", "all", "any", "bool", "bytes", "dict", "enumerate", "filter",
            "float", "format", "frozenset", "getattr", "hasattr", "int", "isinstance",
            "iter", "len", "list", "map", "max", "min", "object", "open", "print",
            "range", "repr", "reversed", "set", "sorted", "str", "sum", "super",
            "tuple", "type", "zip",
        ):
            self.rules.append((QRegularExpression(r"\b" + word + r"\b"), builtin))
        self_ref = QTextCharFormat()
        self_ref.setForeground(QColor("#b45309"))
        self_ref.setFontItalic(True)
        self.rules.append((QRegularExpression(r"\bself\b"), self_ref))
        string = QTextCharFormat()
        string.setForeground(QColor("#a31515"))
        self.rules.append((QRegularExpression(r'"[^"\\]*(?:\\.[^"\\]*)*"'), string))
        self.rules.append((QRegularExpression(r"'[^'\\]*(?:\\.[^'\\]*)*'"), string))
        comment = QTextCharFormat()
        comment.setForeground(QColor("#2e7d32"))
        comment.setFontItalic(True)
        self.rules.append((QRegularExpression(r"#[^\n]*"), comment))
        number = QTextCharFormat()
        number.setForeground(QColor("#0f766e"))
        self.rules.append((QRegularExpression(r"\b[0-9]+(?:\.[0-9]+)?\b"), number))
        decorator = QTextCharFormat()
        decorator.setForeground(QColor("#b45309"))
        self.rules.append(
            (QRegularExpression(r"@[A-Za-z_][A-Za-z0-9_.]*"), decorator)
        )

    def highlightBlock(self, text):
        for pattern, fmt in self.rules:
            iterator = pattern.globalMatch(text)
            while iterator.hasNext():
                match = iterator.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), fmt)


class StudioWorker(QThread):
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, function, parent=None):
        super().__init__(parent)
        self._function = function

    def run(self):
        try:
            self.done.emit(self._function())
        except Exception:
            self.failed.emit(traceback.format_exc())


class AddonStudioWidget(QWidget):
    def __init__(self, plugin, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.folder: Optional[Path] = None
        self.worker: Optional[StudioWorker] = None
        self._build_ui()
        self._new_defaults()
        self._refresh_marketplace_status()

    # -- UI --------------------------------------------------------------
    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        header = QHBoxLayout()
        title = QLabel("<b>Sentinel Addon Studio</b>")
        title.setFont(QFont("Segoe UI", 15, QFont.Weight.Bold))
        header.addWidget(title)
        subtitle = QLabel(
            "Scaffold, test in Sentinel's sandbox, package .qah and publish"
        )
        subtitle.setStyleSheet("color:#6b7280;")
        subtitle.setWordWrap(True)
        subtitle.setSizePolicy(
            QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred
        )
        header.addWidget(subtitle, 1)
        self.status = QLabel("New addon")
        self.status.setStyleSheet("color:#6b7280;")
        header.addWidget(self.status)
        layout.addLayout(header)

        self.toolbar = QToolBar()
        self.toolbar.setMovable(False)
        self.toolbar.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
        for label, slot in (
            ("New project", self.new_project),
            ("Open folder…", self.open_project),
            ("Save", self.save_project),
            ("Validate", self.validate_project),
            ("Build .qah", self.build_package),
            ("Install in Sentinel", self.install_in_sentinel),
            ("Test in Sentinel", self.test_project),
            ("Publish to Marketplace", self.publish_project),
        ):
            action = QAction(label, self)
            action.triggered.connect(lambda _checked=False, callback=slot: callback())
            self.toolbar.addAction(action)
        layout.addWidget(self.toolbar)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        layout.addWidget(splitter, 1)

        left_layout = QVBoxLayout()
        left_layout.setContentsMargins(0, 0, 0, 0)

        self.tabs = QTabWidget()

        project_box = QGroupBox("Project")
        form = QFormLayout(project_box)
        self.folder_edit = QLineEdit()
        self.folder_edit.setPlaceholderText("Project folder")
        folder_row = QHBoxLayout()
        folder_row.addWidget(self.folder_edit, 1)
        browse = QPushButton("Browse…")
        browse.clicked.connect(self.browse_folder)
        folder_row.addWidget(browse)
        form.addRow("Folder:", folder_row)
        self.id_edit = QLineEdit("my_sentinel_addon")
        form.addRow("Addon id:", self.id_edit)
        self.name_edit = QLineEdit("My Sentinel Addon")
        form.addRow("Name:", self.name_edit)
        self.version_edit = QLineEdit("1.0.0")
        form.addRow("Version:", self.version_edit)
        self.author_edit = QLineEdit("")
        form.addRow("Author:", self.author_edit)
        self.entry_edit = QLineEdit("run")
        form.addRow("Entry:", self.entry_edit)
        self.timeout_spin = QSpinBox()
        self.timeout_spin.setRange(1, 300)
        self.timeout_spin.setValue(30)
        self.timeout_spin.setSuffix(" s")
        form.addRow("Timeout:", self.timeout_spin)
        self.description_edit = QPlainTextEdit()
        self.description_edit.setFixedHeight(60)
        form.addRow("Description:", self.description_edit)
        left_layout.addWidget(project_box)

        caps_box = QGroupBox("Capabilities")
        caps_layout = QGridLayout(caps_box)
        self.capability_boxes: Dict[str, QCheckBox] = {}
        for index, name in enumerate(core.CAPABILITIES):
            box = QCheckBox(name)
            box.setToolTip(CAPABILITY_HELP.get(name, ""))
            self.capability_boxes[name] = box
            caps_layout.addWidget(box, index // 2, index % 2)
        left_layout.addWidget(caps_box)

        test_box = QGroupBox("Test targets")
        test_layout = QVBoxLayout(test_box)
        self.targets_edit = QPlainTextEdit()
        self.targets_edit.setFixedHeight(64)
        self.targets_edit.setPlaceholderText(
            "One file or folder per line. Requires read-files; leave empty to test without targets."
        )
        test_layout.addWidget(self.targets_edit)
        target_row = QHBoxLayout()
        add_file = QPushButton("Add file…")
        add_file.clicked.connect(self._add_file_target)
        target_row.addWidget(add_file)
        add_folder = QPushButton("Add folder…")
        add_folder.clicked.connect(self._add_folder_target)
        target_row.addWidget(add_folder)
        target_row.addStretch(1)
        test_layout.addLayout(target_row)
        left_layout.addWidget(test_box)

        deploy_box = QGroupBox("Deploy")
        deploy_layout = QVBoxLayout(deploy_box)
        self.marketplace_status = QLabel("Checking marketplace configuration…")
        self.marketplace_status.setWordWrap(True)
        self.marketplace_status.setStyleSheet("color:#6b7280;")
        deploy_layout.addWidget(self.marketplace_status)
        self.package_path = QLineEdit()
        self.package_path.setReadOnly(True)
        self.package_path.setPlaceholderText("Built .qah package path")
        deploy_layout.addWidget(self.package_path)
        deploy_row = QHBoxLayout()
        check = QPushButton("Check Marketplace")
        check.clicked.connect(self._refresh_marketplace_status)
        deploy_row.addWidget(check)
        open_packages = QPushButton("Open packages")
        open_packages.clicked.connect(self._open_packages_folder)
        deploy_row.addWidget(open_packages)
        copy_path = QPushButton("Copy .qah path")
        copy_path.clicked.connect(self._copy_package_path)
        deploy_row.addWidget(copy_path)
        deploy_row.addStretch(1)
        deploy_layout.addLayout(deploy_row)
        left_layout.addWidget(deploy_box)
        left_layout.addStretch(1)

        left_panel = QWidget()
        left_panel.setLayout(left_layout)
        # Keep the form at its natural height so a vertical scrollbar appears on
        # short screens instead of compressing fields.
        left_panel.setMinimumHeight(left_layout.sizeHint().height())
        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setFrameShape(QFrame.Shape.NoFrame)
        left_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        left_scroll.setWidget(left_panel)
        left_scroll.setMinimumWidth(340)
        splitter.addWidget(left_scroll)

        self.tabs = QTabWidget()
        code_page = QWidget()
        code_layout = QVBoxLayout(code_page)
        code_layout.setContentsMargins(0, 0, 0, 0)
        self.code_edit = CodeEditor()
        self.code_edit.setFont(QFont("Consolas", 10))
        self.code_edit.setTabStopDistance(32)
        self.python_highlighter = PythonHighlighter(self.code_edit.document())
        self.code_edit.cursorPositionChanged.connect(self._update_cursor_status)
        code_layout.addWidget(self.code_edit, 1)
        self.cursor_label = QLabel("Ln 1, Col 1")
        self.cursor_label.setStyleSheet("color:#6b7280; padding:2px;")
        code_layout.addWidget(self.cursor_label)
        self._add_scroll_tab(self.tabs, code_page, "main.py")

        self.readme_edit = QPlainTextEdit()
        self.readme_edit.setFont(QFont("Consolas", 9))
        self._add_scroll_tab(self.tabs, self.readme_edit, "README.md")

        self.manifest_view = QPlainTextEdit()
        self.manifest_view.setReadOnly(True)
        self.manifest_view.setFont(QFont("Consolas", 9))
        self._add_scroll_tab(self.tabs, self.manifest_view, "addon.json")

        self.log_view = QPlainTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setFont(QFont("Consolas", 9))
        self._add_scroll_tab(self.tabs, self.log_view, "Activity")
        splitter.addWidget(self.tabs)
        splitter.setSizes([360, 760])
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)

        QShortcut(QKeySequence.StandardKey.Save, self, activated=self.save_project)
        QShortcut(QKeySequence("Ctrl+B"), self, activated=self.build_package)
        QShortcut(QKeySequence("Ctrl+T"), self, activated=self.test_project)
        QShortcut(QKeySequence("Ctrl+I"), self, activated=self.install_in_sentinel)
        QShortcut(
            QKeySequence("Ctrl+Shift+P"), self, activated=self.publish_project
        )

        layout.activate()
        content.setMinimumHeight(max(200, int(layout.sizeHint().height())))
        content.setMinimumWidth(0)
        self.content_scroll = QScrollArea()
        self.content_scroll.setWidgetResizable(True)
        self.content_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.content_scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAsNeeded
        )
        self.content_scroll.setVerticalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAsNeeded
        )
        self.content_scroll.setWidget(content)
        outer.addWidget(self.content_scroll)

    def _add_scroll_tab(self, tabs, page, title):
        if page.layout() is not None:
            page.layout().activate()
        page.ensurePolished()
        page.setMinimumHeight(max(120, int(page.sizeHint().height())))
        page.setMinimumWidth(0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setWidget(page)
        tabs.addTab(scroll, title)
        return scroll

    def _new_defaults(self):
        base = core.projects_dir() / "my_sentinel_addon"
        self.folder_edit.setText(str(base))
        self._refresh_manifest_preview()

    # -- state -----------------------------------------------------------
    def _meta(self) -> Dict[str, Any]:
        return {
            "folder": self.folder_edit.text().strip(),
            "id": self.id_edit.text().strip(),
            "name": self.name_edit.text().strip(),
            "version": self.version_edit.text().strip(),
            "author": self.author_edit.text().strip(),
            "description": self.description_edit.toPlainText().strip(),
            "main": "main.py",
            "entry": self.entry_edit.text().strip() or "run",
            "timeout": int(self.timeout_spin.value()),
            "capabilities": [
                name for name, box in self.capability_boxes.items() if box.isChecked()
            ],
        }

    def _set_meta(self, manifest: Dict[str, Any], folder: Path):
        self.folder_edit.setText(str(folder))
        self.id_edit.setText(str(manifest.get("id") or ""))
        self.name_edit.setText(str(manifest.get("name") or ""))
        self.version_edit.setText(str(manifest.get("version") or "1.0.0"))
        self.author_edit.setText(str(manifest.get("author") or ""))
        self.description_edit.setPlainText(str(manifest.get("description") or ""))
        self.entry_edit.setText(str(manifest.get("entry") or "run"))
        try:
            self.timeout_spin.setValue(int(manifest.get("timeout", 30) or 30))
        except Exception:
            self.timeout_spin.setValue(30)
        selected = set(str(item) for item in (manifest.get("capabilities") or []))
        for name, box in self.capability_boxes.items():
            box.setChecked(name in selected)
        self._refresh_manifest_preview()

    def _refresh_manifest_preview(self):
        meta = self._meta()
        meta.pop("folder", None)
        self.manifest_view.setPlainText(json.dumps(core.manifest_for(meta), indent=2))

    def _append_log(self, text: str):
        self.log_view.appendPlainText(text.rstrip())
        self.log_view.verticalScrollBar().setValue(
            self.log_view.verticalScrollBar().maximum()
        )
        self.tabs.setCurrentWidget(self.log_view)

    def _busy(self, message: str):
        self.status.setText(message)
        self._append_log(message)

    def _update_cursor_status(self):
        cursor = self.code_edit.textCursor()
        self.cursor_label.setText(
            f"Ln {cursor.blockNumber() + 1}, Col {cursor.columnNumber() + 1}"
        )

    def _refresh_marketplace_status(self):
        try:
            info = core.marketplace_info()
        except Exception as exc:
            info = {"available": False, "error": str(exc)}
        if info.get("slug"):
            token = "token saved" if info.get("token_saved") else "gh/env token"
            self.marketplace_status.setText(
                f"Marketplace: {info['slug']} @ {info.get('branch', 'master')} · {token}"
            )
            self.marketplace_status.setStyleSheet("color:#15803d;")
        else:
            self.marketplace_status.setText(
                "Marketplace not configured. Open Git Plugin Marketplace → "
                "Settings and set the repository/token first."
            )
            self.marketplace_status.setStyleSheet("color:#b45309;")

    def _open_packages_folder(self):
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(core.package_dir())))

    def _copy_package_path(self):
        path = self.package_path.text().strip()
        if not path:
            QMessageBox.information(
                self, "Package path", "Build or install the addon first."
            )
            return
        QApplication.clipboard().setText(path)
        self._append_log(f"Copied package path: {path}")

    # -- project actions -------------------------------------------------
    def browse_folder(self):
        path = QFileDialog.getExistingDirectory(
            self, "Select addon project folder", self.folder_edit.text() or str(Path.home())
        )
        if path:
            self.folder_edit.setText(path)
            if (Path(path) / "addon.json").is_file():
                self._open_folder(Path(path))

    def new_project(self):
        meta = self._meta()
        if not meta["folder"]:
            meta["folder"] = str(core.projects_dir() / meta["id"])
        try:
            folder = core.create_project(meta)
        except Exception as exc:
            QMessageBox.critical(self, "New addon project", str(exc))
            return
        self.folder = folder
        project = core.load_project(folder)
        self._set_meta(project["manifest"], folder)
        self.code_edit.setPlainText(project["code"])
        self.readme_edit.setPlainText(project["readme"])
        self.status.setText(f"Created {folder}")
        self._append_log(f"Created addon project: {folder}")
        self.tabs.setCurrentIndex(0)

    def open_project(self):
        path = QFileDialog.getExistingDirectory(
            self, "Open addon project", str(core.projects_dir())
        )
        if path:
            self._open_folder(Path(path))

    def _open_folder(self, folder: Path):
        try:
            project = core.load_project(folder)
        except Exception as exc:
            QMessageBox.critical(self, "Open addon project", str(exc))
            return
        self.folder = folder
        self._set_meta(project["manifest"], folder)
        self.code_edit.setPlainText(project["code"])
        self.readme_edit.setPlainText(project["readme"])
        self.status.setText(f"Opened {folder}")
        self._append_log(f"Opened addon project: {folder}")
        self.tabs.setCurrentIndex(0)

    def validate_project(self) -> bool:
        if not self.save_project():
            return False
        folder = Path(self.folder_edit.text()).expanduser()
        errors = core.validate_project(folder)
        if errors:
            QMessageBox.warning(
                self,
                "Validate addon",
                "Fix these problems:\n\n" + "\n".join(f"- {item}" for item in errors),
            )
            self._append_log("Validation failed:\n" + "\n".join(errors))
            return False
        self.status.setText("Addon is valid")
        self._append_log(f"Validation OK: {folder}")
        return True

    def save_project(self) -> bool:
        folder_text = self.folder_edit.text().strip()
        if not folder_text:
            QMessageBox.warning(self, "Save addon", "Choose a project folder.")
            return False
        folder = Path(folder_text).expanduser()
        try:
            core.save_project(
                folder,
                self._meta(),
                self.code_edit.toPlainText(),
                self.readme_edit.toPlainText(),
            )
        except Exception as exc:
            QMessageBox.critical(self, "Save addon", str(exc))
            return False
        self.folder = folder
        self.status.setText(f"Saved {folder}")
        self._append_log(f"Saved addon project: {folder}")
        self._refresh_manifest_preview()
        return True

    def _add_file_target(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Add test target file", str(Path.home()), "All files (*)"
        )
        if path:
            self._append_target(path)

    def _add_folder_target(self):
        path = QFileDialog.getExistingDirectory(self, "Add test target folder")
        if path:
            self._append_target(path)

    def _append_target(self, path: str):
        current = self.targets_edit.toPlainText().strip()
        self.targets_edit.setPlainText((current + "\n" if current else "") + path)

    def _targets(self) -> List[str]:
        return [
            line.strip()
            for line in self.targets_edit.toPlainText().splitlines()
            if line.strip()
        ]

    # -- build / install / test -----------------------------------------
    def build_package(self) -> Optional[Dict[str, Any]]:
        if not self.save_project():
            return None
        folder = Path(self.folder_edit.text()).expanduser()
        try:
            result = core.build_package(folder)
        except Exception as exc:
            QMessageBox.critical(self, "Build addon", str(exc))
            return None
        self._append_log(
            f"Built {result['path']}\n"
            f"  size  : {result['size']} bytes\n"
            f"  sha256: {result['sha256']}"
        )
        self.status.setText("Package built")
        self.package_path.setText(str(result["path"]))
        answer = QMessageBox.question(
            self,
            "Addon package built",
            f"{result['path']}\n\n"
            f"{result['size']} bytes\nSHA256: {result['sha256']}\n\n"
            "Open the package folder?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer == QMessageBox.Yes:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(result["path"]).parent)))
        return result

    def install_in_sentinel(self):
        result = self.build_package()
        if result is None:
            return
        try:
            sentinel = core.load_sentinel_addons()
            addon = sentinel.install_addon_archive(Path(result["path"]), source="studio")
            sentinel.pin_addon(addon["id"])
        except Exception as exc:
            QMessageBox.critical(self, "Install in Sentinel", str(exc))
            return
        self._append_log(
            f"Installed {result['id']} {result['version']} in Plugin Sentinel and pinned its hash."
        )
        self.status.setText("Installed in Plugin Sentinel")
        QMessageBox.information(
            self,
            "Installed in Sentinel",
            f"Installed {result['id']} {result['version']} in Plugin Sentinel and "
            "pinned its hash. Open Plugin Sentinel → Addons to run it.",
        )

    def test_project(self):
        if not self.save_project():
            return
        folder = Path(self.folder_edit.text()).expanduser()
        targets = self._targets()
        timeout = int(self.timeout_spin.value())
        if self.worker is not None and self.worker.isRunning():
            QMessageBox.information(self, "Test addon", "A task is already running.")
            return
        self._busy(f"Testing {folder.name} in Sentinel's addon sandbox…")
        worker = StudioWorker(
            lambda: core.test_project(folder, targets=targets, timeout=timeout), self
        )
        worker.done.connect(self._on_test_done)
        worker.failed.connect(self._on_worker_failed)
        worker.finished.connect(worker.deleteLater)
        self.worker = worker
        worker.start()

    def _on_test_done(self, result: Dict[str, Any]):
        self.worker = None
        lines = [
            f"Status   : {result.get('status')}",
            f"Duration : {result.get('duration')} s",
            f"Detail   : {result.get('detail', '')}",
        ]
        if result.get("summary"):
            lines += ["", "Summary", "-------", str(result["summary"])]
        findings = result.get("findings") or []
        lines.append(f"\nFindings: {len(findings)}")
        for finding in findings[:100]:
            if isinstance(finding, dict):
                severity = finding.get("severity") or finding.get("level") or "info"
                title = finding.get("title") or finding.get("message") or finding
                lines.append(f"  [{severity}] {title}")
        if result.get("report"):
            lines += ["", "Report", "------", str(result["report"])[:20000]]
        if result.get("data"):
            lines += ["", "Data", "----", json.dumps(result["data"], indent=2)[:20000]]
        violations = result.get("violations") or []
        if violations:
            lines.append(f"\nSandbox violations: {len(violations)}")
            lines.extend(
                f"  {item.get('event', '')}: {item.get('detail', '')}"
                for item in violations[:30]
            )
        if result.get("stderr"):
            lines += ["", "stderr", "------", str(result["stderr"])[-4000:]]
        self._append_log("\n".join(lines))
        self.status.setText(f"Test status: {result.get('status')}")
        if result.get("status") not in ("ok", "warning"):
            QMessageBox.warning(
                self,
                "Addon test",
                f"The addon returned status {result.get('status')}.\n\n"
                + str(result.get("detail") or "See the Activity tab."),
            )

    # -- publish ---------------------------------------------------------
    def publish_project(self):
        if not self.save_project():
            return
        folder = Path(self.folder_edit.text()).expanduser()
        errors = core.validate_project(folder)
        if errors:
            QMessageBox.warning(
                self, "Publish addon", "Fix the addon first:\n\n" + "\n".join(f"• {item}" for item in errors)
            )
            return
        meta = self._meta()
        info = core.marketplace_info()
        if not info.get("slug"):
            self._refresh_marketplace_status()
            QMessageBox.warning(
                self,
                "Marketplace not configured",
                "Publishing is delegated to Git Plugin Marketplace, but no "
                "repository is configured.\n\n"
                "Open Git Plugin Marketplace → Settings, set owner/repository/"
                "branch and the token, then try again.",
            )
            return
        changelog, ok = QInputDialog.getMultiLineText(
            self,
            "Publish Sentinel addon",
            f"Publish {meta['name']} {meta['version']} to "
            f"{info.get('slug')} @ {info.get('branch')}?\n\n"
            "Changelog:",
            "Published with Sentinel Addon Studio",
        )
        if not ok:
            return
        answer = QMessageBox.question(
            self,
            "Confirm publish",
            f"Build and publish {meta['id']} {meta['version']}?\n\n"
            f"Repository: {info.get('slug')} @ {info.get('branch')}\n"
            f"Capabilities: {', '.join(meta['capabilities']) or 'none'}\n\n"
            "This writes one commit to the configured marketplace repository.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return
        if self.worker is not None and self.worker.isRunning():
            QMessageBox.information(self, "Publish addon", "A task is already running.")
            return
        self._busy(f"Publishing {meta['id']} {meta['version']}…")
        worker = StudioWorker(
            lambda: core.publish_project(
                folder,
                version=meta["version"],
                changelog=changelog,
            ),
            self,
        )
        worker.done.connect(self._on_publish_done)
        worker.failed.connect(self._on_worker_failed)
        worker.finished.connect(worker.deleteLater)
        self.worker = worker
        worker.start()

    def _on_publish_done(self, result: Dict[str, Any]):
        self.worker = None
        output = str(result.get("output") or "")
        self._append_log("Publish output:\n" + output)
        if result.get("returncode") == 0:
            self.status.setText("Published")
            self._refresh_marketplace_status()
            QMessageBox.information(
                self,
                "Addon published",
                "The addon was published to the Git Marketplace.\n\n"
                "Open Git Plugin Marketplace → Addons and Refresh to see it.",
            )
        else:
            self.status.setText("Publish failed")
            QMessageBox.critical(
                self,
                "Publish failed",
                f"The marketplace CLI exited with {result.get('returncode')}.\n\n"
                + output[-4000:],
            )

    def _on_worker_failed(self, message: str):
        self.worker = None
        self.status.setText("Task failed")
        self._append_log(message)
        QMessageBox.critical(self, "Addon Studio", message[-4000:])

    # -- lifecycle -------------------------------------------------------
    def cleanup(self):
        worker = self.worker
        if worker is not None:
            worker.wait(5000)
            if worker.isRunning():
                worker.setParent(None)
                worker.finished.connect(worker.deleteLater)
            else:
                worker.deleteLater()
        self.worker = None
