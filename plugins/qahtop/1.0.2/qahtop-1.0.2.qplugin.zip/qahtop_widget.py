"""QAHtop - htop-style process viewer with optional psutil detection.

The plugin is read-only: it lists processes and system metrics, but it never
ends or modifies a process. It first tries an injected Wheel Plugin Manager
vendor path, then normal psutil, then tasklist/ps fallbacks.
"""

from __future__ import annotations

import csv
import importlib
import io
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from PySide6.QtCore import Qt, QThread, QTimer, Signal
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

MAX_ROWS = 500
REFRESH_INTERVAL_MS = 3000
_PSUTIL = None
_PSUTIL_TRIED = False
_LAST_CPU: Optional[tuple] = None


# ---------------------------------------------------------------------------
# Optional dependency bootstrap
# ---------------------------------------------------------------------------


def qah_home() -> Path:
    override = os.environ.get("QAH_HOME")
    return Path(override).expanduser() if override else Path.home() / "QAH"


def activate_vendor(targets=("qahtop", "global")) -> List[str]:
    """Insert injected dependency directories into sys.path."""
    root = qah_home() / "plugins" / "vendor"
    added = []
    for target in targets:
        path = root / target
        if path.is_dir() and str(path) not in sys.path:
            sys.path.insert(0, str(path))
            added.append(str(path))
    if added:
        importlib.invalidate_caches()
    return added


def probe_psutil(force: bool = False):
    """Return the psutil module, activating vendor paths first when needed."""
    global _PSUTIL, _PSUTIL_TRIED
    if force or not _PSUTIL_TRIED:
        _PSUTIL_TRIED = True
        activate_vendor()
        try:
            import psutil  # type: ignore
            _PSUTIL = psutil
        except Exception:
            _PSUTIL = None
    return _PSUTIL


# ---------------------------------------------------------------------------
# System and process snapshots
# ---------------------------------------------------------------------------


def _windows_memory() -> Optional[float]:
    try:
        import ctypes

        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [
                ("dwLength", ctypes.c_ulong),
                ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong),
                ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]

        status = MEMORYSTATUSEX()
        status.dwLength = ctypes.sizeof(status)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status))
        return float(status.dwMemoryLoad)
    except Exception:
        return None


def _linux_memory() -> Optional[float]:
    try:
        values = {}
        for line in Path("/proc/meminfo").read_text(encoding="utf-8").splitlines():
            key, _, value = line.partition(":")
            values[key.strip()] = int(value.split()[0])
        total = values.get("MemTotal", 0)
        available = values.get("MemAvailable", values.get("MemFree", 0))
        if total:
            return 100.0 * (total - available) / total
    except Exception:
        pass
    return None


def _fallback_cpu() -> Optional[float]:
    try:
        if os.name != "nt":
            load = os.getloadavg()[0]
            cpus = os.cpu_count() or 1
            return max(0.0, min(100.0, 100.0 * load / cpus))
    except Exception:
        pass
    return None


def _fallback_processes() -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    try:
        if os.name == "nt":
            output = subprocess.check_output(
                ["tasklist", "/FO", "CSV", "/NH"],
                text=True,
                errors="replace",
                timeout=10,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            for row in csv.reader(io.StringIO(output)):
                if len(row) < 5:
                    continue
                try:
                    pid = int(row[1])
                except ValueError:
                    continue
                memory_kb = 0.0
                try:
                    memory_kb = float(row[4].replace(" K", "").replace(",", "").strip())
                except ValueError:
                    pass
                rows.append({
                    "pid": pid,
                    "name": row[0],
                    "user": "",
                    "cpu": 0.0,
                    "memory_mb": memory_kb / 1024.0,
                    "threads": 0,
                    "status": row[2],
                })
        else:
            output = subprocess.check_output(
                ["ps", "-eo", "pid=,comm=,user=,%cpu=,%mem=,rss=,stat="],
                text=True,
                errors="replace",
                timeout=10,
            )
            for line in output.splitlines():
                parts = line.split(None, 6)
                if len(parts) < 7:
                    continue
                try:
                    rows.append({
                        "pid": int(parts[0]),
                        "name": parts[1],
                        "user": parts[2],
                        "cpu": float(parts[3]),
                        "memory_mb": float(parts[5]) / 1024.0,
                        "threads": 0,
                        "status": parts[6],
                    })
                except ValueError:
                    continue
    except Exception:
        pass
    return rows


def collect_snapshot(force_fallback: bool = False) -> Dict[str, Any]:
    global _LAST_CPU
    psutil_module = None if force_fallback else probe_psutil()
    rows: List[Dict[str, Any]] = []
    cpu = None
    memory = None
    source = "fallback"

    if psutil_module is not None:
        source = "psutil"
        try:
            cpu = float(psutil_module.cpu_percent(interval=None))
        except Exception:
            cpu = None
        try:
            memory = float(psutil_module.virtual_memory().percent)
        except Exception:
            memory = None
        try:
            for process in psutil_module.process_iter(
                ["pid", "name", "username", "cpu_percent", "memory_info",
                 "num_threads", "status"]
            ):
                try:
                    info = process.info
                    mem = info.get("memory_info")
                    rows.append({
                        "pid": int(info.get("pid") or 0),
                        "name": str(info.get("name") or ""),
                        "user": str(info.get("username") or ""),
                        "cpu": float(info.get("cpu_percent") or 0.0),
                        "memory_mb": float(getattr(mem, "rss", 0) or 0) / (1024.0 * 1024.0),
                        "threads": int(info.get("num_threads") or 0),
                        "status": str(info.get("status") or ""),
                    })
                except Exception:
                    continue
        except Exception:
            rows = []
    else:
        rows = _fallback_processes()
        if os.name == "nt":
            memory = _windows_memory()
        else:
            memory = _linux_memory()
        cpu = _fallback_cpu()

    try:
        disk = shutil.disk_usage(str(Path.home()))
        disk_text = (
            f"{disk.used / (1024**3):.1f}/{disk.total / (1024**3):.1f} GiB "
            f"({100.0 * disk.used / disk.total:.0f}%)"
        )
    except Exception:
        disk_text = "—"

    rows = rows[:MAX_ROWS]
    return {
        "source": source,
        "psutil_version": getattr(psutil_module, "__version__", "") if psutil_module else "",
        "vendor_paths": activate_vendor(),
        "cpu": cpu,
        "memory": memory,
        "disk": disk_text,
        "processes": rows,
        "process_count": len(rows),
        "timestamp": time.strftime("%H:%M:%S"),
    }


# ---------------------------------------------------------------------------
# Worker and UI
# ---------------------------------------------------------------------------


class SnapshotWorker(QThread):
    done = Signal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)

    def run(self):
        try:
            self.done.emit(collect_snapshot())
        except Exception as exc:
            self.done.emit({
                "source": "error",
                "cpu": None,
                "memory": None,
                "disk": "—",
                "processes": [],
                "process_count": 0,
                "error": str(exc),
                "timestamp": time.strftime("%H:%M:%S"),
            })


class QAHtopWidget(QWidget):
    COLUMNS = ("PID", "Process", "User", "CPU %", "Memory MB", "Threads", "Status")

    def __init__(self, plugin=None, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.worker: Optional[SnapshotWorker] = None
        self._rows: List[Dict[str, Any]] = []
        self._last_snapshot: Dict[str, Any] = {}
        self._paused = False
        self._build_ui()
        self._refresh()

    # -- UI --------------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        header = QHBoxLayout()
        title = QLabel("<b>QAHtop</b>")
        title.setFont(QFont("Segoe UI", 15, QFont.Weight.Bold))
        header.addWidget(title)
        subtitle = QLabel("htop-style process monitor · read-only")
        subtitle.setStyleSheet("color:#6b7280;")
        header.addWidget(subtitle, 1)
        self.dependency_badge = QLabel("Detecting psutil…")
        self.dependency_badge.setStyleSheet("color:#b45309;")
        header.addWidget(self.dependency_badge)
        layout.addLayout(header)

        metrics = QHBoxLayout()
        self.cpu_label = QLabel("CPU —")
        self.memory_label = QLabel("Memory —")
        self.disk_label = QLabel("Disk —")
        self.process_label = QLabel("Processes —")
        self.updated_label = QLabel("Updated —")
        for widget in (
            self.cpu_label, self.memory_label, self.disk_label,
            self.process_label, self.updated_label,
        ):
            widget.setStyleSheet(
                "padding:3px 8px; background:#eef2ff; border-radius:5px;"
            )
            metrics.addWidget(widget)
        metrics.addStretch(1)
        layout.addLayout(metrics)

        controls = QHBoxLayout()
        self.filter_edit = QLineEdit()
        self.filter_edit.setPlaceholderText("Filter by process name, user or PID…")
        self.filter_edit.setClearButtonEnabled(True)
        self.filter_edit.textChanged.connect(self._render)
        controls.addWidget(self.filter_edit, 2)
        controls.addWidget(QLabel("Sort:"))
        self.sort_combo = QComboBox()
        self.sort_combo.addItems(["CPU", "Memory", "PID", "Name"])
        self.sort_combo.currentTextChanged.connect(lambda _text: self._render())
        controls.addWidget(self.sort_combo)
        controls.addWidget(QLabel("Refresh:"))
        self.interval_combo = QComboBox()
        self.interval_combo.addItem("3 s", 3000)
        self.interval_combo.addItem("1.5 s", 1500)
        self.interval_combo.addItem("5 s", 5000)
        self.interval_combo.currentIndexChanged.connect(self._interval_changed)
        controls.addWidget(self.interval_combo)
        self.pause_button = QPushButton("Pause")
        self.pause_button.setCheckable(True)
        self.pause_button.toggled.connect(self._toggle_pause)
        controls.addWidget(self.pause_button)
        refresh = QPushButton("Refresh")
        refresh.clicked.connect(self._refresh)
        controls.addWidget(refresh)
        detect = QPushButton("Detect dependencies")
        detect.setToolTip(
            "Re-scan injected Wheel Plugin Manager vendor paths and try psutil "
            "again without restarting QAH."
        )
        detect.clicked.connect(self._detect_dependencies)
        controls.addWidget(detect)
        layout.addLayout(controls)

        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(list(self.COLUMNS))
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setWordWrap(False)
        self.table.setSortingEnabled(False)
        self.table.setTextElideMode(Qt.TextElideMode.ElideRight)
        header = self.table.horizontalHeader()
        header.setStretchLastSection(False)
        header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        for column, width in (
            (0, 72), (2, 140), (3, 72), (4, 96), (5, 76), (6, 96)
        ):
            self.table.setColumnWidth(column, width)
        layout.addWidget(self.table, 1)

        self.status = QLabel("QAHtop ready.")
        self.status.setStyleSheet("color:#6b7280;")
        layout.addWidget(self.status)

        self.timer = QTimer(self)
        self.timer.setInterval(REFRESH_INTERVAL_MS)
        self.timer.timeout.connect(self._refresh)
        self.timer.start()

    # -- refresh ---------------------------------------------------------
    def _interval_changed(self):
        interval = int(self.interval_combo.currentData() or REFRESH_INTERVAL_MS)
        self.timer.setInterval(interval)

    def _toggle_pause(self, paused: bool):
        self._paused = paused
        self.pause_button.setText("Resume" if paused else "Pause")
        if paused:
            self.timer.stop()
            self.status.setText("Paused")
        else:
            self.timer.start()
            self._refresh()

    def _refresh(self):
        if self._paused or not self.isVisible():
            return
        if self.worker is not None and self.worker.isRunning():
            return
        worker = SnapshotWorker(self)
        worker.done.connect(self._on_snapshot)
        worker.finished.connect(worker.deleteLater)
        self.worker = worker
        worker.start()

    def showEvent(self, event):
        super().showEvent(event)
        if not self._paused:
            self.timer.start()
            self._refresh()

    def hideEvent(self, event):
        self.timer.stop()
        super().hideEvent(event)

    def _on_snapshot(self, snapshot: Dict[str, Any]):
        self.worker = None
        self._last_snapshot = snapshot
        self._rows = snapshot.get("processes") or []
        source = snapshot.get("source", "fallback")
        version = snapshot.get("psutil_version", "")
        if source == "psutil":
            self.dependency_badge.setText(
                f"psutil {version}" if version else "psutil available"
            )
            self.dependency_badge.setStyleSheet("color:#15803d;")
        else:
            self.dependency_badge.setText("fallback (no psutil)")
            self.dependency_badge.setStyleSheet("color:#b45309;")
        self.cpu_label.setText(
            "CPU —" if snapshot.get("cpu") is None else f"CPU {snapshot['cpu']:.1f}%"
        )
        self.memory_label.setText(
            "Memory —" if snapshot.get("memory") is None
            else f"Memory {snapshot['memory']:.1f}%"
        )
        self.disk_label.setText(f"Disk {snapshot.get('disk', '—')}")
        self.process_label.setText(f"Processes {snapshot.get('process_count', 0)}")
        self.updated_label.setText(f"Updated {snapshot.get('timestamp', '—')}")
        self._render()
        if snapshot.get("error"):
            self.status.setText(f"Snapshot error: {snapshot['error']}")

    def _sorted_rows(self):
        sort = self.sort_combo.currentText()
        rows = list(self._rows)
        if sort == "Memory":
            rows.sort(key=lambda row: row.get("memory_mb", 0), reverse=True)
        elif sort == "PID":
            rows.sort(key=lambda row: row.get("pid", 0))
        elif sort == "Name":
            rows.sort(key=lambda row: str(row.get("name", "")).lower())
        else:
            rows.sort(key=lambda row: row.get("cpu", 0), reverse=True)
        text = self.filter_edit.text().strip().lower()
        if text:
            rows = [
                row for row in rows
                if text in str(row.get("name", "")).lower()
                or text in str(row.get("user", "")).lower()
                or text in str(row.get("pid", ""))
            ]
        return rows

    def _render(self):
        selected_pid = None
        current = self.table.currentRow()
        if current >= 0:
            item = self.table.item(current, 0)
            if item is not None:
                selected_pid = item.text()
        scroll = self.table.verticalScrollBar().value()
        rows = self._sorted_rows()
        self.table.setUpdatesEnabled(False)
        try:
            self.table.setRowCount(len(rows))
            select_row = -1
            for index, row in enumerate(rows):
                values = [
                    str(row.get("pid", "")),
                    str(row.get("name", "")),
                    str(row.get("user", "")),
                    f"{float(row.get('cpu', 0) or 0):.1f}",
                    f"{float(row.get('memory_mb', 0) or 0):.1f}",
                    str(row.get("threads", "")),
                    str(row.get("status", "")),
                ]
                for column, value in enumerate(values):
                    item = QTableWidgetItem(value)
                    if column in (3, 4):
                        item.setTextAlignment(
                            Qt.AlignmentFlag.AlignRight
                            | Qt.AlignmentFlag.AlignVCenter
                        )
                    self.table.setItem(index, column, item)
                if selected_pid is not None and values[0] == selected_pid:
                    select_row = index
                if values[0] == str(os.getpid()):
                    for column in range(len(self.COLUMNS)):
                        self.table.item(index, column).setBackground(QColor("#dbeafe"))
            if select_row >= 0:
                self.table.selectRow(select_row)
            self.table.verticalScrollBar().setValue(scroll)
        finally:
            self.table.setUpdatesEnabled(True)
        self.status.setText(
            f"{len(rows)} process(es) shown · source: "
            f"{self._last_snapshot.get('source', '—')}"
        )

    def _detect_dependencies(self):
        activate_vendor()
        psutil_module = probe_psutil(force=True)
        if psutil_module is None:
            self.dependency_badge.setText("fallback (no psutil)")
            self.dependency_badge.setStyleSheet("color:#b45309;")
            QMessageBox.information(
                self,
                "QAHtop dependencies",
                "psutil is not available yet.\n\n"
                "Install it with Wheel Plugin Manager:\n"
                "Package: psutil\nTarget: global\n\n"
                "Then press Detect dependencies again or refresh QAHtop.",
            )
            return
        self.dependency_badge.setText(f"psutil {psutil_module.__version__}")
        self.dependency_badge.setStyleSheet("color:#15803d;")
        self.status.setText("psutil detected; refreshing snapshot…")
        self._refresh()

    def cleanup(self):
        self.timer.stop()
        if self.worker is not None:
            self.worker.wait(3000)
            if self.worker.isRunning():
                self.worker.setParent(None)
                self.worker.finished.connect(self.worker.deleteLater)
            else:
                self.worker.deleteLater()
        self.worker = None
