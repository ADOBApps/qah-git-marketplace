# qahtop/__init__.py
"""QAHtop - a small htop-style process viewer for QAH.

Read-only process monitor. Uses psutil when available; otherwise falls back to
tasklist/ps. It can activate an injected Wheel Plugin Manager vendor path so a
dependency installed after QAH startup is detected on refresh.

GPLv3 or later.
"""

from __future__ import annotations

import importlib
import importlib.util
import logging
import sys
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QObject
from PySide6.QtGui import QAction, QIcon
from PySide6.QtWidgets import QWidget

try:
    from plugins.libs.plugin_manager import PluginInfo
except Exception:
    PluginInfo = object  # type: ignore


def _load_sibling(name: str):
    try:
        return importlib.import_module(f"{__name__}.{name}")
    except ImportError:
        path = Path(__file__).parent / f"{name}.py"
        spec = importlib.util.spec_from_file_location(f"{__name__}_{name}", path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        return module


class QAHtopPlugin(QObject):
    def __init__(self, plugin_info: PluginInfo):
        super().__init__()
        self.plugin_info = plugin_info
        self.ui_widget: Optional[QWidget] = None
        self.icon: Optional[QIcon] = None
        icon_path = Path(__file__).parent / "icon.svg"
        if icon_path.is_file():
            self.icon = QIcon(str(icon_path))

    def initialize(self) -> bool:
        try:
            logging.info(
                "Initializing %s v%s", self.plugin_info.name, self.plugin_info.version
            )
            return True
        except Exception as exc:
            logging.error("QAHtop initialization failed: %s", exc)
            return False

    def get_widget(self) -> Optional[QWidget]:
        if self.ui_widget is None:
            try:
                ui = _load_sibling("qahtop_widget")
                self.ui_widget = ui.QAHtopWidget(self)
            except Exception as exc:
                logging.error("Could not build QAHtop: %s", exc)
                logging.debug("Traceback", exc_info=True)
                return None
        return self.ui_widget

    def get_menu_actions(self):
        action = QAction("QAHtop", self)
        if self.icon is not None:
            action.setIcon(self.icon)
        action.setToolTip("htop-style QAH process and system monitor")
        return [action]

    def cleanup(self):
        if self.ui_widget is not None:
            try:
                if hasattr(self.ui_widget, "cleanup"):
                    self.ui_widget.cleanup()
            finally:
                self.ui_widget.deleteLater()
                self.ui_widget = None


Plugin = QAHtopPlugin
